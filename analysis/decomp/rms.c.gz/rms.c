// ==== main @ 01010024

/* WARNING: This function may have set the stack pointer */
/* WARNING: Removing unreachable block (ram,0x01010f14) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined8 main(void)

{
  undefined4 unaff_D7;
  int extraout_A0;
  
  DAT_0f00b006 = 0x30;
  DAT_0f00b007 = 0xf;
  DAT_0f00b003 = 0xff;
  DAT_01052298 = 0x1400000;
  DAT_01052294 = 0x1000000;
  DAT_01052290 = 0x101006c;
  mcbinit();
  DAT_01052290 = 0x101007c;
  memcbctl = unaff_D7;
  FUN_01010126();
  *(code **)(extraout_A0 + 0x84) = _syscall;
  *(undefined1 **)(extraout_A0 + 0x88) = &_sys2call;
  *(undefined1 **)(extraout_A0 + 0x8c) = &trap3;
  *(undefined1 **)(extraout_A0 + 0x90) = &trap4;
  *(undefined1 **)(extraout_A0 + 0x94) = &trap5;
  *(code **)(extraout_A0 + 0x98) = trap6;
  *(code **)(extraout_A0 + 0x9c) = trap7;
  DAT_01052290 = 0x10100b2;
  _mclear();
  DAT_01052290 = 0x10100b8;
  _syssetup();
  DAT_01052290 = 0x10100be;
  sgen();
  cswon = 1;
  DAT_01052290 = 0x1010f22;
  _dispch();
  cswon = 0;
  return *_DAT_00000084;
}


// ==== FUN_01010126 @ 01010126

void FUN_01010126(void)

{
  short sVar1;
  int in_A0;
  undefined4 *puVar2;
  undefined4 *in_VBR;
  
  nmiproc = *(undefined4 *)(in_A0 + 0x7c);
  *in_VBR = irqcom;
  in_VBR[1] = irqcom;
  if ((DAT_0f00b002 & 0x80) == 0) {
    _busjmp = *(undefined4 *)(in_A0 + 8);
    _adrjmp = *(undefined4 *)(in_A0 + 0xc);
    in_VBR[2] = &LAB_010101ee;
    in_VBR[3] = &LAB_01010238;
  }
  puVar2 = in_VBR + 4;
  sVar1 = 4;
  do {
    *puVar2 = irqcom;
    do {
      do {
        sVar1 = sVar1 + 1;
        puVar2 = puVar2 + 1;
      } while (sVar1 == 9);
    } while (((sVar1 == 0x2d) || (sVar1 == 0x2e)) || (sVar1 == 0x2f));
  } while (sVar1 != 0x100);
  *(undefined4 *)(in_A0 + 0x7c) = nmiproc;
  return;
}


// ==== restart @ 010101ba

void restart(void)

{
  reset();
  main();
  return;
}


// ==== _sysstp @ 010101c2

void _sysstp(void)

{
  DAT_01055742 = 0;
  DAT_0f00b003 = DAT_0f00b003 & 0xfe;
  DAT_0105573e = &DAT_010101e6;
  DAT_0105573c = 0x2000;
  return;
}


// ==== led0on @ 01010284

void led0on(void)

{
  DAT_0f00b003 = DAT_0f00b003 & 0xfe;
  return;
}


// ==== led0off @ 01010296

void led0off(void)

{
  DAT_0f00b003 = DAT_0f00b003 | 1;
  return;
}


// ==== led1on @ 010102a8

void led1on(void)

{
  DAT_0f00b003 = DAT_0f00b003 & 0xfd;
  return;
}


// ==== led2on @ 010102ba

void led2on(void)

{
  DAT_0f00b003 = DAT_0f00b003 & 0xfb;
  return;
}


// ==== led3on @ 010102cc

void led3on(void)

{
  DAT_0f00b003 = DAT_0f00b003 & 0xf7;
  return;
}


// ==== led4on @ 010102de

void led4on(void)

{
  DAT_0f00b003 = DAT_0f00b003 & 0xef;
  return;
}


// ==== led5on @ 010102f0

void led5on(void)

{
  DAT_0f00b003 = DAT_0f00b003 & 0xdf;
  return;
}


// ==== led6on @ 01010302

void led6on(void)

{
  DAT_0f00b003 = DAT_0f00b003 & 0xbf;
  return;
}


// ==== led7on @ 01010314

void led7on(void)

{
  DAT_0f00b003 = DAT_0f00b003 & 0x7f;
  return;
}


// ==== led1off @ 01010326

void led1off(void)

{
  DAT_0f00b003 = DAT_0f00b003 | 2;
  return;
}


// ==== led2off @ 01010338

void led2off(void)

{
  DAT_0f00b003 = DAT_0f00b003 | 4;
  return;
}


// ==== led3off @ 0101034a

void led3off(void)

{
  DAT_0f00b003 = DAT_0f00b003 | 8;
  return;
}


// ==== led4off @ 0101035c

void led4off(void)

{
  DAT_0f00b003 = DAT_0f00b003 | 0x10;
  return;
}


// ==== led5off @ 0101036e

void led5off(void)

{
  DAT_0f00b003 = DAT_0f00b003 | 0x20;
  return;
}


// ==== led6off @ 01010380

void led6off(void)

{
  DAT_0f00b003 = DAT_0f00b003 | 0x40;
  return;
}


// ==== led7off @ 01010392

void led7off(void)

{
  DAT_0f00b003 = DAT_0f00b003 | 0x80;
  return;
}


// ==== c_copy @ 010103a4

void c_copy(undefined1 *param_1,undefined1 *param_2,int param_3)

{
  for (; param_3 != 0; param_3 = param_3 + -1) {
    *param_1 = *param_2;
    param_1 = param_1 + 1;
    param_2 = param_2 + 1;
  }
  return;
}


// ==== crc16 @ 0101086c

undefined8 crc16(void)

{
  undefined4 in_D0;
  undefined4 in_D1;
  
  return CONCAT44(in_D0,in_D1);
}


// ==== _settcb @ 010108b4

undefined4 _settcb(void)

{
  __m68k_trap(0xe);
  return 0;
}


// ==== _setecb @ 010108bc

undefined4 _setecb(void)

{
  __m68k_trap(0xe);
  return 1;
}


// ==== _setrcb @ 010108c0

undefined4 _setrcb(void)

{
  __m68k_trap(0xe);
  return 2;
}


// ==== _setpcb @ 010108c4

undefined4 _setpcb(void)

{
  __m68k_trap(0xe);
  return 3;
}


// ==== _setdcb @ 010108c8

undefined4 _setdcb(void)

{
  __m68k_trap(0xe);
  return 4;
}


// ==== _setetcb @ 010108cc

undefined4 _setetcb(void)

{
  __m68k_trap(0xe);
  return 5;
}


// ==== _setbk @ 010108d0

char _setbk(void)

{
  if (DAT_00000400 == '\x02') {
    __m68k_trap(0xe);
    return '\x06';
  }
  return DAT_00000400;
}


// ==== _setlcb @ 010108e4

undefined4 _setlcb(void)

{
  __m68k_trap(0xe);
  return 7;
}


// ==== _setedcb @ 010108e8

undefined4 _setedcb(void)

{
  __m68k_trap(0xe);
  return 8;
}


// ==== _setdque @ 010108ec

undefined4 _setdque(void)

{
  __m68k_trap(0xe);
  return 9;
}


// ==== _setmemb @ 010108f0

char _setmemb(void)

{
  if (DAT_00000400 == '\x02') {
    __m68k_trap(0xe);
    return '\n';
  }
  return DAT_00000400;
}


// ==== dmaaget @ 01010904

void dmaaget(undefined1 param_1)

{
  DAT_0f008000 = param_1;
  intwait();
  return;
}


// ==== dmahset @ 01010924

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void dmahset(undefined1 param_1,undefined4 param_2,short param_3)

{
  if (param_2._0_1_ == '\0') {
    DAT_0f00c000 = 0xc0;
  }
  else {
    DAT_0f00c000 = 0xc1;
  }
  DAT_0f008000 = param_1;
  intwait();
  DAT_0f008007 = param_2._1_1_;
  intwait();
  _DAT_0f008004 = param_2._2_2_;
  intwait();
  _DAT_0f008002 = param_3 + -1;
  intwait();
  return;
}


// ==== dmafc @ 01010982

void dmafc(undefined4 param_1)

{
  if (param_1._0_1_ == '\0') {
    DAT_0f00c000 = 0xc0;
  }
  else {
    DAT_0f00c000 = 0xc1;
  }
  return;
}


// ==== stfdcnfg @ 010109a4

void stfdcnfg(int param_1,undefined4 param_2)

{
  *(undefined4 *)(&fdcnfg + param_1 * 4) = param_2;
  set_dden(param_1);
  gvfdcnfg();
  return;
}


// ==== gvfdcnfg @ 010109ce

void gvfdcnfg(void)

{
  return;
}


// ==== fdcwait @ 010109e0

void fdcwait(void)

{
  FUN_01010a1e();
  FUN_01010a1e();
  FUN_01010a1e();
  FUN_01010a1e();
  FUN_01010a1e();
  FUN_01010a1e();
  FUN_01010a1e();
  FUN_01010a1e();
  FUN_01010a1e();
  FUN_01010a1e();
  return;
}


// ==== FUN_01010a1e @ 01010a1e

void FUN_01010a1e(void)

{
  return;
}


// ==== rtcwait @ 01010a48

void rtcwait(void)

{
  return;
}


// ==== intwait @ 01010a5c

void intwait(void)

{
  return;
}


// ==== SCSIWait @ 01010a5e

void SCSIWait(void)

{
  return;
}


// ==== piowait @ 01010a62

void piowait(void)

{
  return;
}


// ==== irqcom @ 01010a64

/* WARNING: This function may have set the stack pointer */
/* WARNING: Removing unreachable block (ram,0x01010f14) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined8 irqcom(ushort param_1)

{
  code *pcVar1;
  undefined4 extraout_D1;
  undefined4 *unaff_D7;
  undefined8 *puVar2;
  ushort in_stack_00000000;
  undefined1 *local_44;
  undefined1 local_40 [4];
  undefined4 uStack_3c;
  
  _mskon();
  led0off();
  local_44 = local_40;
  pcVar1 = *(code **)(&_ivvct + (param_1 & 0xfff));
  uStack_3c = extraout_D1;
  if (pcVar1 == (code *)0x0) {
    local_44 = (undefined1 *)(param_1 & 0xfff);
    un_log();
    DAT_0f00b003 = 0x11;
    local_44 = (undefined1 *)0x1010b18;
    _mskoff();
    local_44 = (undefined1 *)0x1010b1e;
    led0off();
    puVar2 = (undefined8 *)local_40;
  }
  else {
    if (((in_stack_00000000 & 0x700) == 0) && (mflag != 4)) {
      DAT_01052250 = &local_44;
      _scount = 1;
      DAT_0105224c = 0x1010ada;
      _t_func = pcVar1;
      _mskoff();
      DAT_0105224c = 0x1010adc;
      (*pcVar1)();
      _scount = 0;
      cswon = 1;
      DAT_0105224c = 0x1010f22;
      _dispch();
      cswon = 0;
      return *(undefined8 *)*unaff_D7;
    }
    if (_scount == 0) {
      _scount = 1;
      DAT_0105224c = 0x1010b52;
      DAT_01052250 = (undefined1 **)local_44;
      _mskoff();
      DAT_0105224c = 0x1010b54;
      (*pcVar1)();
      _scount = 0;
      puVar2 = (undefined8 *)DAT_01052250;
    }
    else {
      local_44 = (undefined1 *)0x1010b68;
      _mskoff();
      local_44 = (undefined1 *)0x1010b6a;
      (*pcVar1)();
      puVar2 = (undefined8 *)local_40;
    }
  }
  return *puVar2;
}


// ==== l_copy @ 01010b70

void l_copy(undefined4 *param_1,undefined4 *param_2,int param_3)

{
  for (; param_3 != 0; param_3 = param_3 + -1) {
    *param_1 = *param_2;
    param_1 = param_1 + 1;
    param_2 = param_2 + 1;
  }
  return;
}


// ==== set_srp @ 01010b90

/* WARNING: Control flow encountered unimplemented instructions */

void set_srp(undefined4 param_1,undefined4 param_2)

{
  crpdata = param_1;
  DAT_010413f8 = param_2;
                    /* WARNING: Unimplemented instruction - Truncating control flow here */
  halt_unimplemented();
}


// ==== set_crp @ 01010baa

/* WARNING: Control flow encountered unimplemented instructions */

void set_crp(undefined4 param_1,undefined4 param_2)

{
  crpdata = param_1;
  DAT_010413f8 = param_2;
                    /* WARNING: Unimplemented instruction - Truncating control flow here */
  halt_unimplemented();
}


// ==== set_tt0 @ 01010bc4

/* WARNING: Control flow encountered unimplemented instructions */

void set_tt0(void)

{
                    /* WARNING: Unimplemented instruction - Truncating control flow here */
  halt_unimplemented();
}


// ==== set_tt1 @ 01010bcc

/* WARNING: Control flow encountered unimplemented instructions */

void set_tt1(void)

{
                    /* WARNING: Unimplemented instruction - Truncating control flow here */
  halt_unimplemented();
}


// ==== set_tc @ 01010bd4

/* WARNING: Control flow encountered unimplemented instructions */

void set_tc(void)

{
                    /* WARNING: Unimplemented instruction - Truncating control flow here */
  halt_unimplemented();
}


// ==== set_cacr @ 01010bdc

undefined4 set_cacr(undefined4 param_1)

{
  return param_1;
}


// ==== set_caar @ 01010be6

undefined4 set_caar(undefined4 param_1)

{
  return param_1;
}


// ==== set_vbr @ 01010bf8

void set_vbr(void)

{
  return;
}


// ==== get_srp @ 01010c02

/* WARNING: Control flow encountered unimplemented instructions */

void get_srp(void)

{
                    /* WARNING: Unimplemented instruction - Truncating control flow here */
  halt_unimplemented();
}


// ==== get_crp @ 01010c0e

/* WARNING: Control flow encountered unimplemented instructions */

void get_crp(void)

{
                    /* WARNING: Unimplemented instruction - Truncating control flow here */
  halt_unimplemented();
}


// ==== get_tt0 @ 01010c1a

/* WARNING: Control flow encountered unimplemented instructions */

void get_tt0(void)

{
                    /* WARNING: Unimplemented instruction - Truncating control flow here */
  halt_unimplemented();
}


// ==== get_tt1 @ 01010c28

/* WARNING: Control flow encountered unimplemented instructions */

void get_tt1(void)

{
                    /* WARNING: Unimplemented instruction - Truncating control flow here */
  halt_unimplemented();
}


// ==== get_tc @ 01010c36

/* WARNING: Control flow encountered unimplemented instructions */

void get_tc(void)

{
                    /* WARNING: Unimplemented instruction - Truncating control flow here */
  halt_unimplemented();
}


// ==== get_cacr @ 01010c44

void get_cacr(void)

{
  return;
}


// ==== get_caar @ 01010c4a

void get_caar(void)

{
  return;
}


// ==== get_mmusr @ 01010c50

/* WARNING: Control flow encountered unimplemented instructions */

void get_mmusr(void)

{
                    /* WARNING: Unimplemented instruction - Truncating control flow here */
  halt_unimplemented();
}


// ==== get_vbr @ 01010c60

void get_vbr(void)

{
  return;
}


// ==== _salloc @ 01010c68

undefined4 _salloc(int param_1)

{
  undefined4 uVar1;
  
  uVar1 = *(undefined4 *)(param_1 + 4);
  _saloc();
  return uVar1;
}


// ==== _salocnf @ 01010c82

undefined4 _salocnf(uint param_1)

{
  int iVar1;
  undefined4 in_D0;
  int iVar2;
  int unaff_D7;
  undefined4 uStack_14;
  
  DAT_01041406 = 1;
  uStack_14 = in_D0;
  if (param_1 != 0) {
    if (0x400 < (int)param_1) {
      uStack_14 = 1;
      falloc(param_1);
      if (unaff_D7 != 0) {
        return 1;
      }
    }
    iVar2 = (int)param_1 >> 5;
    if ((param_1 & 0x1f) != 0) {
      iVar2 = iVar2 + 1;
    }
    iVar1 = -(int)dsa_total;
    if (iVar2 <= iVar1 + 0x960) {
      if ((iVar2 < 0x960 - DAT_01041404) && (search(), iVar1 != -0x960)) {
        return uStack_14;
      }
      search();
      if (iVar1 != -0x960) {
        return uStack_14;
      }
    }
  }
  __m68k_trapv();
  return uStack_14;
}


// ==== _saloc @ 01010c90

undefined4 _saloc(uint param_1)

{
  int iVar1;
  undefined4 in_D0;
  int iVar2;
  int unaff_D7;
  undefined4 local_14;
  
  DAT_01041406 = 0;
  local_14 = in_D0;
  if (param_1 != 0) {
    if (0x400 < (int)param_1) {
      local_14 = 0;
      falloc(param_1);
      if (unaff_D7 != 0) {
        return 0;
      }
    }
    iVar2 = (int)param_1 >> 5;
    if ((param_1 & 0x1f) != 0) {
      iVar2 = iVar2 + 1;
    }
    iVar1 = -(int)dsa_total;
    if (iVar2 <= iVar1 + 0x960) {
      if ((iVar2 < 0x960 - DAT_01041404) && (search(), iVar1 != -0x960)) {
        return local_14;
      }
      search();
      if (iVar1 != -0x960) {
        return local_14;
      }
    }
  }
  __m68k_trapv();
  return local_14;
}


// ==== search @ 01010d3a

int search(void)

{
  undefined4 *puVar1;
  int in_D0;
  int iVar2;
  short sVar4;
  ushort uVar5;
  uint uVar3;
  int unaff_D4;
  short sVar7;
  uint uVar6;
  byte *pbVar8;
  undefined *puVar9;
  
  iVar2 = in_D0;
  do {
    if (0x960 - iVar2 <= unaff_D4) {
      return in_D0;
    }
    sVar4 = 0;
    pbVar8 = &dsa_dir + iVar2;
    while( true ) {
      if (*pbVar8 != 0) break;
      sVar4 = sVar4 + 1;
      sVar7 = (short)unaff_D4;
      pbVar8 = pbVar8 + 1;
      if (sVar4 == sVar7) {
        DAT_01041404 = sVar7 + (short)iVar2;
        dsa_total = sVar7 + dsa_total;
        (&dsa_dir)[iVar2] = (byte)unaff_D4;
        uVar3 = unaff_D4 << 3;
        uVar6 = unaff_D4 - 1;
        puVar9 = &DAT_01059cc5 + iVar2;
        if (uVar6 != 0) {
          do {
            *puVar9 = 1;
            uVar5 = (short)uVar6 - 1;
            uVar6 = (uint)uVar5;
            puVar9 = puVar9 + 1;
          } while (uVar5 != 0);
        }
        if (DAT_01041406 != 0) {
          return in_D0;
        }
        uVar5 = (ushort)uVar3;
        DAT_01041406 = 0;
        puVar1 = (undefined4 *)(&dsabuf + iVar2 * 0x20);
        while (uVar5 != 0) {
          *puVar1 = 0;
          uVar5 = (short)uVar3 - 1;
          uVar3 = (uint)uVar5;
          puVar1 = puVar1 + 1;
        }
        return in_D0;
      }
    }
    iVar2 = CONCAT22((short)((uint)iVar2 >> 0x10),sVar4 + (ushort)*pbVar8 + (short)iVar2);
  } while( true );
}


// ==== _sfree @ 01010ddc

undefined4 _sfree(int param_1)

{
  undefined4 uVar1;
  
  uVar1 = *(undefined4 *)(param_1 + 4);
  _sfre();
  return uVar1;
}


// ==== _sfre @ 01010dfa

int _sfre(int param_1)

{
  undefined1 *puVar1;
  uint uVar2;
  
  ffree();
  if (param_1 == 0) {
    uVar2 = (uint)bRam00fd6f92;
    if (bRam00fd6f92 != 0) {
      dsa_total = dsa_total - (ushort)bRam00fd6f92;
      puVar1 = (undefined1 *)0xfd6f92;
      for (; uVar2 != 0; uVar2 = uVar2 - 1) {
        *puVar1 = 0;
        puVar1 = puVar1 + 1;
      }
    }
  }
  return param_1;
}


// ==== sqrroot @ 01010e54

void sqrroot(uint param_1)

{
  bool bVar1;
  uint uVar2;
  uint uVar3;
  int iVar4;
  short sVar5;
  
  uVar3 = 0;
  iVar4 = 0;
  sVar5 = 0x10;
  do {
    iVar4 = iVar4 * 2;
    bVar1 = (int)param_1 < 0;
    uVar2 = param_1 & 0x7fffffff;
    param_1 = param_1 << 2;
    uVar3 = (uVar3 << 1 | (uint)bVar1) << 1 | (uint)(uVar2 >> 0x1e != 0);
    if (iVar4 + 1U <= uVar3) {
      uVar3 = uVar3 - (iVar4 + 1U);
      iVar4 = iVar4 + 2;
    }
    sVar5 = sVar5 + -1;
  } while (sVar5 != 0);
  return;
}


// ==== _syscall @ 01010e98

long _syscall(long __sysno,...)

{
  code *pcVar1;
  int in_D0;
  undefined4 unaff_D7;
  undefined4 *puVar2;
  undefined4 in_A0;
  int **ppiVar3;
  long *plVar4;
  ushort in_stack_00000000;
  int *local_44;
  int aiStack_40 [2];
  
  if ((short)in_D0 == 0x3b) {
    if (0x640 < dsa_total) {
      return CONCAT22((short)((uint)in_D0 >> 0x10),dsa_total);
    }
    in_D0 = 0xb;
  }
  local_44 = aiStack_40;
  ppiVar3 = &local_44;
  puVar2 = (undefined4 *)(CONCAT22((short)((uint)unaff_D7 >> 0x10),in_stack_00000000) & 0xffff0700);
  if ((in_stack_00000000 & 0x700) == 0) {
    cswon = 1;
    ppiVar3 = (int **)0x1052254;
  }
  aiStack_40[0] = in_D0;
  *(int ***)((int)ppiVar3 + -4) = &local_44;
  *(undefined4 *)((int)ppiVar3 + -8) = in_A0;
  pcVar1 = *(code **)(&UNK_0101106e + in_D0 * 4);
  *(undefined4 *)((int)ppiVar3 + -0xc) = 0x1010efc;
  (*pcVar1)();
  *(undefined4 **)(*(int *)((int)ppiVar3 + -4) + 0x20) = puVar2;
  if (cswon == 1) {
    *(undefined4 *)((int)ppiVar3 + -8) = 0x1010f22;
    _dispch();
    plVar4 = (long *)*puVar2;
    cswon = 0;
  }
  else {
    plVar4 = (long *)((int)ppiVar3 + 4);
  }
  return *plVar4;
}


// ==== trap6 @ 01011036

void trap6(void)

{
  led7on();
  return;
}


// ==== trap7 @ 0101103e

void trap7(void)

{
  led7off();
  return;
}


// ==== _mskon @ 01011046

void _mskon(void)

{
  char in_XF;
  char in_NF;
  char in_ZF;
  char in_VF;
  byte in_CF;
  
  _savesr = (ushort)(byte)(in_XF << 4 | in_NF << 3 | in_ZF << 2 | in_VF << 1 | in_CF);
  return;
}


// ==== _mskoff @ 01011054

void _mskoff(void)

{
  return;
}


// ==== bntcplsn @ 01011190

void bntcplsn(int param_1,int param_2,byte param_3)

{
  if ((Flvids & 2) == 0) {
    if (((param_3 & 1) != 0) && (-1 < param_2 + param_1 + -0x2782e0)) {
      return;
    }
  }
  else if (-1 < param_2 + param_1 + -0x20f580) {
    return;
  }
  return;
}


// ==== bntcmnsn @ 010111e0

void bntcmnsn(int param_1,int param_2,byte param_3)

{
  if (param_1 < param_2) {
    if ((Flvids & 2) != 0) {
      return;
    }
    if ((param_3 & 1) != 0) {
      return;
    }
  }
  return;
}


// ==== bntcmlt @ 01011220

void bntcmlt(void)

{
  return;
}


// ==== bntcmltn @ 01011242

/* WARNING: Removing unreachable block (ram,0x01011292) */

void bntcmltn(uint param_1,uint param_2,byte param_3)

{
  uint uVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  
  uVar2 = (param_1 >> 0x10) * (param_2 & 0xffff);
  uVar4 = (param_1 & 0xffff) * (param_2 & 0xffff);
  uVar3 = uVar2 * 0x10000 | uVar2 >> 0x10;
  uVar1 = uVar3 + uVar4;
  if ((ushort)((short)(uVar2 >> 0x10) + (ushort)CARRY4(uVar3,uVar4)) == 0) {
    if ((Flvids & 2) == 0) {
      if (((param_3 & 1) == 0) && (uVar1 < 0x278d00)) {
        return;
      }
    }
    else if (uVar1 < 0x20f580) {
      return;
    }
  }
  return;
}


// ==== bntcdvdr @ 01011294

void bntcdvdr(void)

{
  uint extraout_D1;
  int unaff_D2;
  
  FUN_010112b2();
  if (extraout_D1 < unaff_D2 + 1U >> 1) {
    return;
  }
  return;
}


// ==== FUN_010112b2 @ 010112b2

void FUN_010112b2(void)

{
  uint uVar1;
  uint uVar2;
  uint uVar3;
  uint uVar4;
  uint uVar5;
  uint uVar6;
  short sVar8;
  uint uVar7;
  uint uVar9;
  int unaff_A6;
  
  uVar1 = *(uint *)(unaff_A6 + 0xc);
  if (uVar1 == 0) {
    return;
  }
  uVar9 = 0x10000;
  if (uVar1 < 0x10000) {
    return;
  }
  uVar7 = *(uint *)(unaff_A6 + 8);
  uVar6 = uVar7 >> 0x10;
  uVar5 = -uVar1;
  do {
    sVar8 = (short)uVar7;
    uVar7 = (uint)(ushort)(sVar8 << 1);
    uVar4 = uVar6 << 1 | (uint)(sVar8 < 0);
    uVar2 = uVar5 + uVar4;
    uVar6 = uVar2;
    if (!CARRY4(uVar5,uVar4)) {
      uVar6 = uVar2 + uVar1;
    }
    uVar3 = uVar9 & 0x80000000;
    uVar9 = uVar9 << 1 | (uint)(CARRY4(uVar5,uVar4) || uVar2 < uVar5);
  } while (uVar3 == 0);
  return;
}


// ==== bntcdvdu @ 0101130a

void bntcdvdu(void)

{
  int extraout_D1;
  
  FUN_010112b2();
  if (extraout_D1 == 0) {
    return;
  }
  return;
}


// ==== bntcdvdd @ 01011322

void bntcdvdd(void)

{
  FUN_010112b2();
  return;
}


// ==== bntccmp @ 01011330

void bntccmp(undefined4 param_1,undefined4 param_2,byte param_3)

{
  if ((Flvids & 2) != 0) {
    return;
  }
  if ((param_3 & 1) == 0) {
    return;
  }
  return;
}


// ==== FUN_0101136a @ 0101136a

void FUN_0101136a(void)

{
  return;
}


// ==== FUN_0101138a @ 0101138a

void FUN_0101138a(void)

{
  return;
}


// ==== bntccmpq @ 010113aa

void bntccmpq(int param_1,int param_2)

{
  uint uVar1;
  
  uVar1 = param_1 - param_2;
  if (param_1 < param_2) {
    if (0x13c67f < -uVar1 && uVar1 != 0xffec3980) {
      return;
    }
  }
  else if (uVar1 < 0x13c680) {
    return;
  }
  return;
}


// ==== FUN_01011494 @ 01011494

void FUN_01011494(uint param_1,uint param_2)

{
  uint uVar1;
  
  uVar1 = param_1 - param_2;
  if (param_1 < param_2) {
    uVar1 = uVar1 + 0x20f580;
  }
  if (uVar1 < 0x107ac0) {
    return;
  }
  return;
}


// ==== FUN_010114be @ 010114be

void FUN_010114be(uint param_1,uint param_2)

{
  uint uVar1;
  
  uVar1 = param_1 - param_2;
  if (param_1 < param_2) {
    uVar1 = uVar1 + 0x2782e0;
  }
  if (uVar1 < 0x13c170) {
    return;
  }
  return;
}


// ==== bntcnrms @ 010114e8

void bntcnrms(uint param_1,byte param_2)

{
  uint uVar1;
  int iVar2;
  
  if ((int)param_1 < 0) {
    if ((Flvids & 2) == 0) {
      if ((param_2 & 1) == 0) {
        uVar1 = 0x9e340000;
      }
      else {
        uVar1 = 0x9e0b8000;
      }
    }
    else {
      uVar1 = 0x83d60000;
    }
    param_1 = uVar1 + param_1;
  }
  else if ((Flvids & 2) == 0) {
    if ((param_2 & 1) == 0) {
      uVar1 = 0x9e340000;
    }
    else {
      uVar1 = 0x9e0b8000;
    }
  }
  else {
    uVar1 = 0x83d60000;
  }
  iVar2 = 0xb;
  do {
    if (uVar1 <= param_1) {
      param_1 = param_1 - uVar1;
    }
    uVar1 = uVar1 >> 1;
    iVar2 = iVar2 + -1;
  } while (iVar2 != 0);
  return;
}


// ==== bntcnorm @ 01011532

void bntcnorm(uint param_1,byte param_2)

{
  uint uVar1;
  int iVar2;
  
  if ((Flvids & 2) == 0) {
    if ((param_2 & 1) == 0) {
      uVar1 = 0x9e340000;
    }
    else {
      uVar1 = 0x9e0b8000;
    }
  }
  else {
    uVar1 = 0x83d60000;
  }
  iVar2 = 0xb;
  do {
    if (uVar1 <= param_1) {
      param_1 = param_1 - uVar1;
    }
    uVar1 = uVar1 >> 1;
    iVar2 = iVar2 + -1;
  } while (iVar2 != 0);
  return;
}


// ==== blkread @ 01011584

void blkread(undefined1 param_1,int param_2,ushort param_3,byte param_4)

{
  byte bVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  int unaff_D7;
  undefined4 uVar5;
  byte local_13;
  undefined1 auStack_e [4];
  undefined1 local_a;
  undefined1 local_9;
  undefined1 local_8;
  undefined1 local_6;
  undefined1 local_5;
  
  local_13 = 0;
  if (param_4 != 0) {
    do {
      bVar1 = (char)(((uint)param_3 << 2) / 0x1a) + 1;
      uVar3 = ((uint)param_3 << 2) % 0x1a;
      local_a = (undefined1)((int)((bVar1 - 1) * 6 + 1) % 0x1a);
      local_5 = (undefined1)(((uint)bVar1 * 6 + 1) % 0x1a);
      local_6 = local_a;
      if ((uVar3 == 0x18) && ((bVar1 & 1) != 0)) {
        local_9 = 2;
        local_8 = 1;
        rqfdsilv(param_1,&local_a,auStack_e);
        if (unaff_D7 != 0) {
          return;
        }
        rqfdscrd(param_1,bVar1,0,0x18,2,param_2 + (uint)local_13 * 0x200,auStack_e);
        local_a = local_5;
        rqfdsilv(param_1,&local_a,auStack_e);
        iVar2 = (uint)local_13 * 0x200 + 0x100;
        uVar5 = 2;
        uVar3 = 0;
        uVar4 = bVar1 + 1;
      }
      else {
        local_9 = 2;
        local_8 = 1;
        rqfdsilv(param_1,&local_a,auStack_e);
        if (unaff_D7 != 0) {
          return;
        }
        iVar2 = (uint)local_13 * 0x200;
        uVar5 = 4;
        uVar4 = (uint)bVar1;
      }
      rqfdscrd(param_1,uVar4,0,uVar3,uVar5,param_2 + iVar2,auStack_e);
      if (unaff_D7 != 0) {
        edl_echk();
        return;
      }
      param_3 = param_3 + 1;
      local_13 = local_13 + 1;
    } while (local_13 < param_4);
  }
  return;
}


// ==== edl_echk @ 0101174a

void edl_echk(uint param_1,char param_2)

{
  byte bVar1;
  int iVar2;
  
  iVar2 = 0;
  if ((param_1 != 0) && ((param_1 & 0x7c000000) == 0)) {
    if (param_2 == '\0') {
      if ((param_1 & 0x48989) != 0) {
        bVar1 = 0;
        do {
          if ((param_1 & 1 << (bVar1 & 0x1f)) != 0) {
            switch(bVar1) {
            case 0:
            case 8:
              iVar2 = -8;
              break;
            case 3:
            case 0xb:
              iVar2 = -5;
              break;
            case 7:
            case 0xf:
              iVar2 = -4;
              break;
            case 0x12:
              iVar2 = -0x2d;
            }
            if (iVar2 != 0) {
              return;
            }
          }
          bVar1 = bVar1 + 1;
        } while (bVar1 < 0x20);
      }
    }
    else if ((param_1 & 0x4c9c9) != 0) {
      bVar1 = 0;
      do {
        if ((param_1 & 1 << (bVar1 & 0x1f)) != 0) {
          switch(bVar1) {
          case 0:
          case 8:
            iVar2 = -8;
            break;
          case 3:
          case 0xb:
            iVar2 = -5;
            break;
          case 6:
          case 0xe:
            iVar2 = -0x2e;
            break;
          case 7:
          case 0xf:
            iVar2 = -4;
            break;
          case 0x12:
            iVar2 = -0x2d;
          }
          if (iVar2 != 0) {
            return;
          }
        }
        bVar1 = bVar1 + 1;
      } while (bVar1 < 0x20);
    }
  }
  return;
}


// ==== blkwrite @ 01011850

void blkwrite(undefined1 param_1,int param_2,ushort param_3,byte param_4)

{
  byte bVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  int unaff_D7;
  undefined4 uVar5;
  byte local_13;
  undefined1 auStack_e [4];
  undefined1 local_a;
  undefined1 local_9;
  undefined1 local_8;
  undefined1 local_6;
  undefined1 local_5;
  
  local_13 = 0;
  if (param_4 != 0) {
    do {
      bVar1 = (char)(((uint)param_3 << 2) / 0x1a) + 1;
      uVar3 = ((uint)param_3 << 2) % 0x1a;
      local_a = (undefined1)((int)((bVar1 - 1) * 6 + 1) % 0x1a);
      local_5 = (undefined1)(((uint)bVar1 * 6 + 1) % 0x1a);
      local_6 = local_a;
      if ((uVar3 == 0x18) && ((bVar1 & 1) != 0)) {
        local_9 = 2;
        local_8 = 1;
        rqfdsilv(param_1,&local_a,auStack_e);
        if (unaff_D7 != 0) {
          return;
        }
        rqfdscwr(param_1,bVar1,0,0x18,2,param_2 + (uint)local_13 * 0x200,auStack_e);
        local_a = local_5;
        rqfdsilv(param_1,&local_a,auStack_e);
        iVar2 = (uint)local_13 * 0x200 + 0x100;
        uVar5 = 2;
        uVar3 = 0;
        uVar4 = bVar1 + 1;
      }
      else {
        local_9 = 2;
        local_8 = 1;
        rqfdsilv(param_1,&local_a,auStack_e);
        if (unaff_D7 != 0) {
          return;
        }
        iVar2 = (uint)local_13 * 0x200;
        uVar5 = 4;
        uVar4 = (uint)bVar1;
      }
      rqfdscwr(param_1,uVar4,0,uVar3,uVar5,param_2 + iVar2,auStack_e);
      if (unaff_D7 != 0) {
        edl_echk();
        return;
      }
      param_3 = param_3 + 1;
      local_13 = local_13 + 1;
    } while (local_13 < param_4);
  }
  return;
}


// ==== cp_proc @ 01011a18

/* WARNING: Removing unreachable block (ram,0x01011dc0) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void cp_proc(void)

{
  int iVar1;
  int unaff_D7;
  char *pcVar2;
  char *pcVar3;
  
  if (f_mode != 2) {
    return;
  }
  iVar1 = f_tcb * 0x34;
  sbuff = 2;
  DAT_0108795c = 0;
  _DAT_0108795a = *(undefined2 *)(&tbl_ccmd + f_pno * 2);
  switch(f_pno) {
  case 1:
  case 2:
  case 3:
    cpydata(*(undefined4 *)(&DAT_01078660 + iVar1),&DAT_0108795d,4);
    pcVar2 = &DAT_01087961;
    break;
  default:
    pcVar2 = &DAT_0108795e;
    _DAT_0108795d = CONCAT11((&DAT_01078638)[iVar1],DAT_0108795e);
    break;
  case 0x1a:
  case 0x24:
    pcVar2 = &DAT_0108795e;
    _DAT_0108795d = CONCAT11((char)*(undefined2 *)(&DAT_0107865a + iVar1),DAT_0108795e);
    break;
  case 0x25:
    _DAT_0108795d = (undefined2)*(undefined4 *)(&DAT_0107865c + iVar1);
    pcVar2 = &DAT_0108795f;
  }
  pcVar3 = pcVar2;
  switch(f_pno) {
  case 8:
  case 0x24:
    pcVar3 = pcVar2 + 1;
    *pcVar2 = (char)*(undefined4 *)(&DAT_0107865c + iVar1);
    break;
  case 10:
    pcVar3 = pcVar2 + 1;
    *pcVar2 = (&DAT_01078639)[iVar1];
    break;
  case 0xd:
  case 0x11:
  case 0x1e:
  case 0x1f:
    cpydata(&DAT_01078652 + iVar1,pcVar2,2);
    pcVar3 = pcVar2 + 2;
    break;
  case 0x10:
    cpydata(*(undefined4 *)(&DAT_01078660 + iVar1),pcVar2,0xc);
    pcVar3 = pcVar2 + 0xc;
    break;
  case 0x16:
    pcVar3 = pcVar2 + 2;
    pcVar2[0] = '\0';
    pcVar2[1] = '<';
    break;
  case 0x1c:
  case 0x20:
  case 0x21:
  case 0x22:
  case 0x23:
  case 0x36:
  case 0x37:
  case 0x38:
    cpydata(iVar1 + 0x107863a,pcVar2,0xb);
    pcVar3 = pcVar2 + 0xb;
    break;
  case 0x39:
    pcVar3 = pcVar2 + 1;
    *pcVar2 = (char)*(undefined2 *)(&DAT_0107865a + iVar1);
  }
  pcVar2 = pcVar3;
  switch(f_pno) {
  case 8:
    cpydata(*(undefined4 *)(&DAT_01078660 + iVar1),pcVar3,0xc);
    pcVar2 = pcVar3 + 0xc;
    break;
  case 10:
  case 0x20:
    pcVar2 = pcVar3 + 1;
    *pcVar3 = (char)*(undefined4 *)(&DAT_0107865c + iVar1);
    break;
  case 0xd:
  case 0x11:
    cpydata(&DAT_01078654 + iVar1,pcVar3,2);
    pcVar2 = pcVar3 + 2;
    break;
  case 0x21:
    cpydata(iVar1 + 0x1078646,pcVar3,0xb);
    pcVar2 = pcVar3 + 0xb;
    break;
  case 0x22:
  case 0x37:
    pcVar2 = pcVar3 + 1;
    *pcVar3 = (&DAT_01078639)[iVar1];
    break;
  case 0x24:
    cpydata(&DAT_01078656 + iVar1,pcVar3,4);
    pcVar2 = pcVar3 + 4;
    break;
  case 0x39:
    pcVar2 = pcVar3 + 1;
    *pcVar3 = (char)*(undefined2 *)(&DAT_01078652 + iVar1);
  }
  if (f_pno != 0x22) {
    if (f_pno < 0x23) {
      if (f_pno == 0xd) {
        cpydata(iVar1 + 0x1078658,pcVar2,2);
        pcVar2 = pcVar2 + 2;
      }
      goto LAB_01011d44;
    }
    if (f_pno != 0x37) {
      if (f_pno == 0x39) {
        *pcVar2 = (char)*(undefined2 *)(&DAT_01078654 + iVar1);
        if (1 < (byte)(&DAT_01078638)[iVar1]) {
          *pcVar2 = *pcVar2 + '\x01';
        }
        pcVar3 = pcVar2 + 1;
        pcVar2 = pcVar2 + 2;
        *pcVar3 = (char)*(undefined4 *)(&DAT_01078656 + iVar1);
      }
      goto LAB_01011d44;
    }
  }
  cpydata(iVar1 + 0x1078646,pcVar2,0xb);
  pcVar2 = pcVar2 + 0xb;
LAB_01011d44:
  DAT_01087959 = (char)pcVar2 + -0x5a;
  setcrcs(&DAT_01087959,0,0,0);
  idc_req(&sbuff,0xa0);
  if (((unaff_D7 == 0) && (f_pno == 0x11)) && ((byte)(&DAT_01078638)[iVar1] < 2)) {
    malloc((((uint)*(ushort *)(&DAT_01078654 + iVar1) - (uint)*(ushort *)(&DAT_01078652 + iVar1)) +
           1) * 0x20);
    dirbuf = 0;
  }
  return;
}


// ==== ctcinit @ 01011ddc

void ctcinit(void)

{
  ini_pit0();
  ini_pit1(0x34);
  return;
}


// ==== ini_pit0 @ 01011df4

void ini_pit0(void)

{
  DAT_0f002003 = 0x34;
  intwait();
  DAT_0f002000 = 0xff;
  intwait();
  DAT_0f002000 = 0xff;
  intwait();
  DAT_0f002003 = 0x74;
  intwait();
  DAT_0f002001 = 0x40;
  intwait();
  DAT_0f002001 = 0x9c;
  intwait();
  DAT_0f002003 = 0xb4;
  intwait();
  return;
}


// ==== ini_pit1 @ 01011e50

void ini_pit1(undefined1 param_1)

{
  DAT_0f005003 = 0x34;
  intwait();
  DAT_0f005003 = 0x76;
  intwait();
  DAT_0f005003 = 0xb4;
  intwait();
  DAT_0f005002 = param_1;
  intwait();
  DAT_0f005002 = 0;
  intwait();
  return;
}


// ==== pit0get @ 01011e9a

void pit0get(void)

{
  DAT_0f002003 = 0xd2;
  intwait();
  lsbdata = DAT_0f002000;
  intwait();
  msbdata = DAT_0f002000;
  intwait();
  return;
}


// ==== pit0chk @ 01011ed2

void pit0chk(void)

{
  DAT_0f002003 = 0xd2;
  intwait();
  lsbdata = DAT_0f002000;
  intwait();
  msbdata = DAT_0f002000;
  intwait();
  return;
}


// ==== _crdcb @ 01011f44

uint _crdcb(int param_1)

{
  int iVar1;
  uint uVar2;
  undefined4 uVar3;
  byte *pbVar4;
  
  uVar2 = *(uint *)(param_1 + 0xc) & 0x7f;
  if (uVar2 < 0x20) {
    iVar1 = uVar2 * 0x14;
    pbVar4 = &dcbtbl + iVar1;
    uVar2 = CONCAT31((int3)((uint)iVar1 >> 8),*pbVar4);
    if (*pbVar4 == 0) {
      *pbVar4 = 1;
      *(short *)(&DAT_01057866 + iVar1) = (short)*(undefined4 *)(param_1 + 0xc);
      *(undefined4 *)(&DAT_01057868 + iVar1) = *(undefined4 *)(param_1 + 8);
      if (*(int *)(param_1 + 4) == 0) {
        uVar2 = *pbVar4 | 0x80;
      }
      else {
        *pbVar4 = *pbVar4 | 2;
        uVar3 = (**(code **)(param_1 + 4))(*(undefined4 *)(param_1 + 0xc));
        uVar2 = CONCAT31((int3)((uint)uVar3 >> 8),*pbVar4) & 0xfffffffd;
      }
      *pbVar4 = (byte)uVar2;
    }
  }
  return uVar2;
}


// ==== _dsemsg @ 01011fc6

uint _dsemsg(int param_1)

{
  uint uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  undefined2 *unaff_D7;
  byte *pbVar5;
  
  uVar4 = *(uint *)(param_1 + 8) & 0x7f;
  if (uVar4 < 0x20) {
    iVar3 = uVar4 * 0x14;
    pbVar5 = &dcbtbl + iVar3;
    uVar4 = (uint)*pbVar5;
    if ((*pbVar5 != 0) &&
       ((*(char *)(etcb + 3) == (&DAT_01057865)[iVar3] ||
        (uVar4 = (uint)(byte)(&DAT_01057865)[iVar3], (&DAT_01057865)[iVar3] == 0)))) {
      uVar1 = *(uint *)(param_1 + 4);
      uVar4 = _salocnf(uVar1 + 8);
      if (unaff_D7 != (undefined2 *)0x0) {
        *(undefined1 *)(unaff_D7 + 1) = *(undefined1 *)(etcb + 3);
        *(char *)((int)unaff_D7 + 3) = (char)*(undefined4 *)(param_1 + 8);
        *unaff_D7 = (short)uVar1;
        c_copy(unaff_D7 + 4,*(undefined4 *)(param_1 + 0xc),uVar1 & 0xffff);
        iVar2 = *(int *)(&DAT_01057870 + iVar3);
        if (iVar2 == 0) {
          *(undefined2 **)(&DAT_0105786c + iVar3) = unaff_D7;
          *(undefined2 **)(&DAT_01057870 + iVar3) = unaff_D7;
        }
        else {
          *(undefined2 **)(&DAT_01057870 + iVar3) = unaff_D7;
          *(undefined2 **)(iVar2 + 4) = unaff_D7;
        }
        *(undefined4 *)(unaff_D7 + 2) = 0;
        uVar4 = (uint)*pbVar5;
        if ((char)*pbVar5 < '\0') {
          *pbVar5 = *pbVar5 & 0x7f;
          uVar4 = dcbqin(pbVar5);
        }
      }
    }
  }
  return uVar4;
}


// ==== _devalc @ 010120b4

uint _devalc(int param_1)

{
  int iVar1;
  undefined3 uVar2;
  uint uVar3;
  
  uVar3 = *(uint *)(param_1 + 4) & 0x7f;
  if (uVar3 < 0x20) {
    iVar1 = uVar3 * 0x14;
    uVar2 = (undefined3)((uint)iVar1 >> 8);
    uVar3 = CONCAT31(uVar2,(&dcbtbl)[iVar1]);
    if (((&dcbtbl)[iVar1] != '\0') &&
       ((uVar3 = CONCAT31(uVar2,(&DAT_01057865)[iVar1]), (&DAT_01057865)[iVar1] == '\0' ||
        (uVar3 = CONCAT31(uVar2,(&DAT_01057865)[iVar1]),
        *(char *)(etcb + 3) == (&DAT_01057865)[iVar1])))) {
      (&DAT_01057865)[iVar1] = *(undefined1 *)(etcb + 3);
    }
  }
  return uVar3;
}


// ==== _devdalc @ 0101211a

uint _devdalc(int param_1)

{
  int iVar1;
  undefined3 uVar2;
  uint uVar3;
  
  uVar3 = *(uint *)(param_1 + 4) & 0x7f;
  if (uVar3 < 0x20) {
    iVar1 = uVar3 * 0x14;
    uVar2 = (undefined3)((uint)iVar1 >> 8);
    uVar3 = CONCAT31(uVar2,(&dcbtbl)[iVar1]);
    if (((&dcbtbl)[iVar1] != '\0') &&
       (uVar3 = CONCAT31(uVar2,(&DAT_01057865)[iVar1]),
       *(char *)(etcb + 3) == (&DAT_01057865)[iVar1])) {
      (&DAT_01057865)[iVar1] = 0;
    }
  }
  return uVar3;
}


// ==== _dlremsg @ 01012172

void _dlremsg(int param_1)

{
  dr_com(*(undefined4 *)(param_1 + 4),*(undefined4 *)(param_1 + 8),*(undefined4 *)(param_1 + 0xc));
  return;
}


// ==== _dremsg @ 01012190

void _dremsg(int param_1)

{
  dr_com(*(undefined4 *)(param_1 + 4),0,*(undefined4 *)(param_1 + 8));
  return;
}


// ==== dr_com @ 010121ac

uint dr_com(uint param_1,int param_2,undefined4 param_3)

{
  ushort *puVar1;
  int iVar2;
  int iVar3;
  
  param_1 = param_1 & 0x7f;
  if (param_1 < 0x20) {
    iVar3 = param_1 * 0x14;
    param_1 = CONCAT31((int3)((uint)iVar3 >> 8),(&dcbtbl)[iVar3]);
    if ((&dcbtbl)[iVar3] != '\0') {
      if (*(int *)(&DAT_0105786c + iVar3) == 0) {
        param_1 = 0;
      }
      else {
        puVar1 = *(ushort **)(&DAT_0105786c + iVar3);
        if ((param_2 == 0) || (param_1 = *puVar1 + 8, (int)param_1 <= param_2)) {
          c_copy(param_3,puVar1,*puVar1 + 8);
          iVar2 = *(int *)(puVar1 + 2);
          *(int *)(&DAT_0105786c + iVar3) = iVar2;
          if (iVar2 == 0) {
            *(undefined4 *)(&DAT_01057870 + iVar3) = 0;
            *(undefined4 *)(&DAT_0105786c + iVar3) = 0;
          }
          param_1 = _sfre(puVar1);
        }
      }
    }
  }
  return param_1;
}


// ==== _iodone @ 01012248

uint _iodone(int param_1)

{
  int iVar1;
  uint uVar2;
  byte *pbVar3;
  
  uVar2 = *(uint *)(param_1 + 4) & 0x7f;
  if (uVar2 < 0x20) {
    iVar1 = uVar2 * 0x14;
    pbVar3 = &dcbtbl + iVar1;
    uVar2 = CONCAT31((int3)((uint)iVar1 >> 8),*pbVar3);
    if (*pbVar3 != 0) {
      if (*(int *)(&DAT_0105786c + iVar1) == 0) {
        uVar2 = *pbVar3 | 0x80;
        *pbVar3 = (byte)uVar2;
      }
      else {
        uVar2 = dcbqin(pbVar3);
      }
      if ((edcb != 0) && (uVar2 = (uint)*(ushort *)(edcb + 2), *(uint *)(param_1 + 4) == uVar2)) {
        edcb = 0;
        mflag = mflag & 0xfffb;
      }
    }
  }
  return uVar2;
}


// ==== _dioreq @ 010122ce

uint _dioreq(int param_1)

{
  char cVar1;
  int iVar2;
  uint uVar3;
  
  uVar3 = *(uint *)(param_1 + 4) & 0x7f;
  if (uVar3 < 0x20) {
    iVar2 = uVar3 * 0x14;
    cVar1 = (&dcbtbl)[iVar2];
    uVar3 = CONCAT31((int3)((uint)iVar2 >> 8),cVar1);
    if (cVar1 != '\0') {
      uVar3 = dcbqin(&dcbtbl + iVar2);
    }
  }
  return uVar3;
}


// ==== dcbqin @ 01012312

void dcbqin(int param_1)

{
  int iVar1;
  int iVar2;
  
  for (iVar1 = dcbque; (iVar2 = iVar1, param_1 != iVar1 && (iVar2 = 0, iVar1 != 0));
      iVar1 = *(int *)(iVar1 + 0x10)) {
  }
  if (param_1 != iVar2) {
    if (DAT_01057f6c == 0) {
      dcbque = param_1;
    }
    else {
      *(int *)(DAT_01057f6c + 0x10) = param_1;
    }
    DAT_01057f6c = param_1;
    *(undefined4 *)(param_1 + 0x10) = 0;
  }
  return;
}


// ==== _dispch @ 0101235c

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

uint _dispch(undefined4 param_1)

{
  undefined2 *puVar1;
  int iVar2;
  int iVar3;
  byte bVar4;
  ushort *puVar5;
  undefined2 extraout_D0u;
  uint uVar6;
  uint uVar7;
  
  puVar5 = etcb;
  uVar7 = 7;
  if (mflag == 2) {
    *(undefined4 *)(etcb + 0x1c) = param_1;
    iVar3 = (uint)*(byte *)(etcb + 1) * 8;
    if (*(int *)(&lcb + iVar3) == 0) {
      *(ushort **)(&lcb + iVar3) = etcb;
      *(ushort **)(&DAT_01057f7c + iVar3) = etcb;
    }
    else {
      iVar2 = *(int *)(&DAT_01057f7c + iVar3);
      *(ushort **)(&DAT_01057f7c + iVar3) = etcb;
      *(ushort **)(iVar2 + 4) = etcb;
    }
    *etcb = *etcb & 0xfff0 | 0x8002;
    etcb[2] = 0;
    etcb[3] = 0;
    mflag = 0;
  }
  else if (mflag < 3) {
    if (mflag == 1) {
      while( true ) {
        uVar6 = (uint)*(byte *)(etcb + 1);
        if ((*(byte *)(etcb + 1) == uVar7) && (dcbque == 0)) goto LAB_010123fc;
        if ((*(int *)(&lcb + uVar7 * 8) != 0) || (dcbque != 0)) break;
        uVar7 = uVar7 - 1;
      }
      *(undefined4 *)(etcb + 0x1c) = param_1;
      *puVar5 = *puVar5 & 0xfff0 | 0x8002;
      bVar4 = *(byte *)(puVar5 + 1);
      uVar6 = *(uint *)(&lcb + (uint)bVar4 * 8);
      *(uint *)(puVar5 + 2) = uVar6;
      if (uVar6 == 0) {
        *(ushort **)(&DAT_01057f7c + (uint)bVar4 * 8) = puVar5;
      }
      *(ushort **)(&lcb + (uint)bVar4 * 8) = puVar5;
      mflag = 0;
LAB_010123fc:
      if (mflag == 1) {
        return uVar6;
      }
    }
  }
  else if (mflag == 4) {
    return 4;
  }
  uVar6 = dcbque;
  etcb = (ushort *)0x0;
  if (dcbque == 0) {
    edcb = 0;
    for (; -1 < (int)uVar7; uVar7 = uVar7 - 1) {
      puVar1 = *(undefined2 **)(&lcb + uVar7 * 8);
      if (puVar1 != (undefined2 *)0x0) {
        iVar3 = *(int *)(puVar1 + 2);
        etcb = puVar1;
        *(int *)(&lcb + uVar7 * 8) = iVar3;
        if (iVar3 == 0) {
          *(undefined4 *)(&DAT_01057f7c + uVar7 * 8) = 0;
        }
        mmusetup(*(undefined1 *)((int)puVar1 + 0x49));
        uVar7 = CONCAT22(extraout_D0u,*puVar1) & 0xfffffff0 | 0x800f;
        *puVar1 = (short)uVar7;
        mflag = 1;
        if (*(char *)(puVar1 + 1) != '\0') {
          mflag = 1;
          return CONCAT31((int3)(uVar7 >> 8),*(char *)(puVar1 + 1));
        }
        if (*(uint *)(puVar1 + 6) == 0) {
          *(undefined4 *)(puVar1 + 6) = 0x12;
          return 0;
        }
        mflag = 1;
        return *(uint *)(puVar1 + 6);
      }
    }
    cswon = 0;
    uVar7 = _sysstp();
  }
  else {
    testpt();
    _DAT_01052688 = *(undefined2 *)(uVar6 + 2);
    DAT_01052686 = 0;
    DAT_01052684 = 0xdc;
    DAT_01052682 = 0x101;
    _DAT_01052676 = &DAT_01052682;
    DAT_01052636 = &DAT_0105263a;
    _DAT_0105267a = 0x2000;
    _DAT_0105267c = *(undefined4 *)(uVar6 + 4);
    _DAT_01052680 = 0;
    uVar7 = *(uint *)(uVar6 + 0x10);
    if (uVar7 == 0) {
      DAT_01057f6c = 0;
    }
    mflag = 4;
    edcb = uVar6;
    dcbque = uVar7;
  }
  return uVar7;
}


// ==== testpt @ 01012560

void testpt(void)

{
  return;
}


// ==== un_log @ 01012568

void un_log(int param_1)

{
  *(short *)(&unintbf + unintpt * 2) = (short)(param_1 >> 2);
  unintpt = unintpt + 1 & 0xf;
  return;
}


// ==== dcon_off @ 01012594

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void dcon_off(void)

{
  _DAT_0f008008 = 0x234;
  intwait();
  return;
}


// ==== dcon_on @ 010125ac

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void dcon_on(void)

{
  _DAT_0f008008 = 0x230;
  intwait();
  return;
}


// ==== dcon_ons @ 010125c4

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void dcon_ons(void)

{
  _DAT_0f008008 = 0x230;
  intwait();
  return;
}


// ==== dmsk_set @ 010125dc

void dmsk_set(byte param_1)

{
  byte bVar1;
  
  bVar1 = DAT_0f00800e;
  intwait();
  DAT_0f00800e = param_1 | bVar1;
  intwait();
  return;
}


// ==== dmsk_rst @ 01012608

void dmsk_rst(byte param_1)

{
  byte bVar1;
  
  bVar1 = DAT_0f00800e;
  intwait();
  DAT_0f00800e = ~param_1 & bVar1;
  intwait();
  return;
}


// ==== dreq_set @ 01012636

void dreq_set(byte param_1)

{
  byte bVar1;
  
  bVar1 = DAT_0f00800f;
  intwait();
  DAT_0f00800f = param_1 | bVar1;
  intwait();
  return;
}


// ==== dreq_rst @ 01012662

void dreq_rst(byte param_1)

{
  byte bVar1;
  
  bVar1 = DAT_0f00800f;
  intwait();
  DAT_0f00800f = ~param_1 & bVar1;
  intwait();
  return;
}


// ==== dmod_writ @ 01012690

void dmod_writ(void)

{
  DAT_0f00800b = 8;
  intwait();
  return;
}


// ==== dmod_hwri @ 010126a8

void dmod_hwri(void)

{
  DAT_0f00800b = 8;
  intwait();
  return;
}


// ==== dmod_read @ 010126c0

void dmod_read(void)

{
  DAT_0f00800b = 4;
  intwait();
  return;
}


// ==== dmod_hrea @ 010126d8

void dmod_hrea(void)

{
  DAT_0f00800b = 4;
  intwait();
  return;
}


// ==== dmainit @ 010126f0

void dmainit(void)

{
  dmaportpu(&DAT_01041490);
  return;
}


// ==== FUN_01012704 @ 01012704

int FUN_01012704(undefined4 param_1,int param_2)

{
  return param_2 << 1;
}


// ==== FUN_01012722 @ 01012722

void FUN_01012722(byte *param_1,int param_2,uint param_3)

{
  *param_1 = *param_1 & ~(byte)(3 << (param_2 << 1 & 0x3fU));
  *param_1 = *param_1 | (byte)((param_3 & 3) << (param_2 << 1 & 0x3fU));
  return;
}


// ==== ini_swpt @ 01012752

void ini_swpt(void)

{
  fill(&DAT_010414a8,0x10,0);
  return;
}


// ==== FUN_0101276c @ 0101276c

undefined1 FUN_0101276c(undefined4 param_1,undefined4 param_2)

{
  undefined1 uVar1;
  uint uVar2;
  undefined *puVar3;
  
  puVar3 = &DAT_010414a8;
  uVar2 = 0;
  do {
    uVar1 = 0;
    if (puVar3[1] != '\0') {
      uVar1 = FUN_01012886(puVar3,param_1,param_2);
    }
    puVar3 = puVar3 + 2;
    uVar2 = uVar2 + 1;
  } while (uVar2 < 8);
  return uVar1;
}


// ==== FUN_010127ae @ 010127ae

void FUN_010127ae(undefined *param_1,uint param_2)

{
  int iVar1;
  
  iVar1 = 8;
  do {
    if (param_2 == (byte)param_1[1]) {
      return;
    }
    param_1 = param_1 + 2;
    if ((undefined *)0x10414b7 < param_1) {
      param_1 = &DAT_010414a8;
    }
    iVar1 = iVar1 + -1;
  } while (iVar1 != 0);
  return;
}


// ==== FUN_010127f4 @ 010127f4

void FUN_010127f4(uint param_1)

{
  if (param_1 != 0) {
    FUN_010127ae(&DAT_010414a8 + (param_1 & 7) * 2,param_1);
  }
  return;
}


// ==== FUN_01012822 @ 01012822

void FUN_01012822(uint param_1)

{
  undefined1 *unaff_D7;
  
  FUN_010127ae(&DAT_010414a8 + (param_1 & 7) * 2,0);
  if (unaff_D7 != (undefined1 *)0x0) {
    unaff_D7[1] = (char)param_1;
    *unaff_D7 = 0;
  }
  return;
}


// ==== FUN_0101285a @ 0101285a

uint FUN_0101285a(undefined4 param_1,undefined4 param_2,int param_3)

{
  uint uVar1;
  uint unaff_D7;
  
  FUN_01012704(param_1,param_2);
  if (param_3 == 0) {
    uVar1 = unaff_D7 & 1;
  }
  else {
    uVar1 = (unaff_D7 & 2) >> 1;
  }
  return uVar1;
}


// ==== FUN_01012886 @ 01012886

void FUN_01012886(undefined4 param_1,undefined4 param_2,uint param_3)

{
  uint unaff_D7;
  
  FUN_01012704(param_1,param_2);
  FUN_01012722(param_1,param_2,param_3 & 3 | unaff_D7);
  return;
}


// ==== FUN_010128c2 @ 010128c2

void FUN_010128c2(int param_1,undefined4 param_2)

{
  if (param_1 != 0) {
    FUN_01012722(param_1,param_2,0);
  }
  return;
}


// ==== dchg_lgs @ 010128de

/* WARNING: Removing unreachable block (ram,0x01012938) */

void dchg_lgs(undefined4 param_1,undefined4 param_2)

{
  int iVar1;
  int unaff_D7;
  
  iVar1 = 0;
  FUN_010127f4(param_1);
  if (unaff_D7 == 0) {
    FUN_01012822(param_1);
    iVar1 = -1;
  }
  if ((-1 < iVar1) && (FUN_0101285a(), unaff_D7 == 0)) {
    chk_dchg(param_2);
    FUN_0101285a();
  }
  return;
}


// ==== dchg_ack @ 0101296c

void dchg_ack(undefined4 param_1,undefined4 param_2)

{
  int iVar1;
  uint unaff_D7;
  
  iVar1 = 0;
  FUN_010127f4(param_1);
  if (unaff_D7 == 0) {
    FUN_01012822(param_1);
    iVar1 = -1;
  }
  if (iVar1 < 0) {
    return;
  }
  chk_dchg(param_2);
  if (unaff_D7 != 0) {
    clr_dchg(param_2);
    FUN_0101276c(param_2,unaff_D7 | unaff_D7 << 1);
    if ((unaff_D7 != 0) && (unaff_D7 != 0)) goto LAB_010129e4;
  }
  FUN_010128c2();
LAB_010129e4:
  FUN_0101285a();
  return;
}


// ==== chk_dchg @ 01012a00

/* WARNING: Removing unreachable block (ram,0x01012a3a) */

void chk_dchg(byte param_1)

{
  int unaff_D7;
  
  is8fd((int)(char)param_1);
  if (unaff_D7 == 0) {
    is8fd((int)(char)param_1);
    DAT_0f00b000 = param_1 | 0x80;
    piowait();
    piowait();
  }
  return;
}


// ==== clr_dchg @ 01012a88

/* WARNING: Removing unreachable block (ram,0x01012ac4) */

void clr_dchg(byte param_1)

{
  byte bVar1;
  int iVar2;
  int unaff_D7;
  
  is8fd((int)(char)param_1);
  if (unaff_D7 == 0) {
    is8fd((int)(char)param_1);
    DAT_0f00b000 = param_1 | 0x80;
    piowait();
    iVar2 = (int)(char)param_1;
    DAT_0f00b001 = (&fddpad)[iVar2 * 4] | 0x10;
    (&fddpad)[iVar2 * 4] = DAT_0f00b001;
    piowait();
    DAT_0f00b001 = (&fddpad)[iVar2 * 4] & 0xef;
    (&fddpad)[iVar2 * 4] = DAT_0f00b001;
    piowait();
    bVar1 = ~DAT_0f00b004;
    piowait();
    (&DAT_010442da)[iVar2 * 4] = -((bVar1 & 2) != 0) & 1;
  }
  return;
}


// ==== halt @ 01012b3c

void halt(void)

{
  do {
                    /* WARNING: Do nothing block with infinite loop */
  } while( true );
}


// ==== halt2 @ 01012b46

void halt2(void)

{
  do {
                    /* WARNING: Do nothing block with infinite loop */
  } while( true );
}


// ==== inihard @ 01012b50

void inihard(void)

{
  spfIdent();
  spfset(2,0,0);
  supsio3();
  dfltgpmd();
  inigp123();
  return;
}


// ==== supsio3 @ 01012b7e

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void supsio3(void)

{
  uint uVar1;
  short sVar2;
  int iVar3;
  ushort unaff_D2w;
  uint uVar4;
  ushort local_12 [7];
  
  iVar3 = 20000;
  do {
    iVar3 = iVar3 + -1;
  } while (0 < iVar3);
  iVar3 = 0;
  do {
    local_12[iVar3] = *(ushort *)(&DAT_0fff93fe + iVar3 * 0x1000);
    if ((unaff_D2w & 0xf000) == 0x2000) {
      *(undefined2 *)(iVar3 * 0x1000 + 0xfff93c0) = 1;
    }
    iVar3 = iVar3 + 1;
  } while (iVar3 < 7);
  iVar3 = 20000;
  do {
    iVar3 = iVar3 + -1;
  } while (0 < iVar3);
  _S3potrdy = 0;
  uVar4 = 0;
  do {
    if ((local_12[(int)uVar4 >> 2] & 0xf000) == 0x2000) {
      uVar1 = uVar4;
      if ((int)uVar4 < 0) {
        uVar1 = uVar4 + 3;
      }
      if (((uint)local_12[(int)uVar4 >> 2] & 1 << (-((uVar1 & 0xfffffffc) - uVar4) & 0x1f)) != 0) {
        _S3potrdy = 1 << (uVar4 & 0x3f) | _S3potrdy;
        iVar3 = (&sio3port)[uVar4];
        sVar2 = (short)(uVar4 << 1);
        *(short *)(iVar3 + 900) = sVar2 + 0x60;
        *(short *)(iVar3 + 0x386) = sVar2 + 0x61;
        *(undefined2 *)(iVar3 + 0x382) = 0xa77;
      }
    }
    ivaridc(uVar4 + 0xc0);
    uVar4 = uVar4 + 1;
  } while ((int)uVar4 < 0x1c);
  return;
}


// ==== supas12 @ 01012c50

void supas12(undefined4 *param_1)

{
  if (((DAT_0ff01fd7 & 0xf0) == 0x10) || ((DAT_0ff01fd7 & 0xf0) == 0x30)) {
    *param_1 = 0xff01fe1;
  }
  else {
    *param_1 = 0;
  }
  param_1[1] = 0xfff1fe9;
  param_1[2] = 0xfff1fd9;
  param_1[3] = 0xfff1fff;
  param_1[4] = 0xfff1ff7;
  param_1[5] = 0xfff1ff7;
  param_1[6] = gpi123;
  return;
}


// ==== supas34 @ 01012cb4

void supas34(undefined4 *param_1)

{
  *param_1 = 0xff01001;
  param_1[1] = 0xff01201;
  param_1[2] = 0xff01e01;
  param_1[3] = 0xff01e05;
  param_1[4] = 0xff01e09;
  param_1[5] = 0xff01e07;
  param_1[6] = gpi123_34;
  return;
}


// ==== spfIdent @ 01012cf6

void spfIdent(void)

{
  undefined1 uVar1;
  
  uVar1 = DAT_0fff1001;
  DAT_0fff1001 = 'U';
  eepSettle();
  if (DAT_0fff1001 == 'U') {
    DAT_0fff1001 = -0x56;
    eepSettle();
    if (((DAT_0fff1001 != -0x56) && ((DAT_0ff01fd7 & 0xf0) != 0x10)) &&
       ((DAT_0ff01fd7 & 0xf0) != 0x30)) {
      supas34(&theSpfIO);
      goto LAB_01012d94;
    }
  }
  else if (((DAT_0ff01fd7 & 0xf0) != 0x10) && ((DAT_0ff01fd7 & 0xf0) != 0x30)) {
    supas34(&theSpfIO);
    goto LAB_01012d94;
  }
  supas12(&theSpfIO);
LAB_01012d94:
  DAT_0fff1001 = uVar1;
  eepSettle();
  return;
}


// ==== isSPF1or2 @ 01012dac

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void isSPF1or2(void)

{
  return;
}


// ==== eepSettle @ 01012e10

void eepSettle(void)

{
  int iVar1;
  
  iVar1 = 0;
  do {
    iVar1 = iVar1 + 1;
  } while (iVar1 < 0x4000);
  return;
}


// ==== edl_clos @ 01012e24

/* WARNING: Removing unreachable block (ram,0x01013014) */
/* WARNING: Removing unreachable block (ram,0x01013034) */

void edl_clos(short param_1)

{
  undefined2 *puVar1;
  int iVar2;
  char cVar3;
  byte bVar4;
  int iVar5;
  int iVar6;
  int iVar7;
  short sVar8;
  uint uVar9;
  uint unaff_D7;
  int local_12;
  ushort local_a;
  short local_8;
  short local_6;
  
  iVar6 = param_1 * 0x26;
  cVar3 = (&fcb)[iVar6];
  bVar4 = cVar3 - 4;
  iVar7 = (uint)bVar4 * 0x2a;
  if (((&dph)[iVar7] != '\0') && ((&DAT_01042b8a)[iVar6] != '\0')) {
    if (bVar4 == 0) {
      local_12 = d0_buf;
    }
    else {
      local_12 = d1_buf;
    }
    iVar5 = segtbl + (uint)bVar4 * 0x14;
    segread(cVar3,(int)(char)(&DAT_01042b96)[iVar6],1);
    if (-1 < (int)unaff_D7) {
      puVar1 = (undefined2 *)
               ((unaff_D7 & 0xff) * 0x400 + local_12 + 10 +
               (uint)*(ushort *)(&DAT_01042b3a + iVar7) * ((char)(&DAT_01042b97)[iVar6] + -1));
      mvshort(*puVar1,&local_6);
      if (local_6 == 0x100) {
        if (((*(short *)(&DAT_01042ba2 + iVar6) != 0) && (*(short *)(&DAT_01042ba2 + iVar6) != -1))
           && (blkwrite(cVar3,*(undefined4 *)(&DAT_01042baa + iVar6),
                        *(undefined2 *)(&DAT_01042b9a + iVar6),1), unaff_D7 != 0)) {
          return;
        }
        mvshort(0x400,puVar1);
        *(undefined2 *)(&DAT_01042ba8 + iVar6) = 0x400;
        mvshort(puVar1[4],&local_8);
        if (*(short *)(&DAT_01042ba6 + iVar6) == 0) {
          mvshort(*(undefined2 *)(&DAT_01042ba4 + iVar6),puVar1 + 4);
        }
        else {
          mvshort(*(ushort *)(&DAT_01042ba4 + iVar6) + 1,puVar1 + 4);
        }
        *(undefined2 *)(iVar5 + 10 + (unaff_D7 & 0xff) * 2) = 1;
        segcheck(cVar3,*(undefined2 *)(&DAT_01042b3e + iVar7));
        if (unaff_D7 == 0xffffffff) {
          segread(cVar3,*(undefined2 *)(&DAT_01042b3e + iVar7),0);
          return;
        }
        uVar9 = unaff_D7 & 0xff;
        if (*(short *)(&DAT_01042ba6 + iVar6) == 0) {
          sVar8 = *(short *)(&DAT_01042ba4 + iVar6);
        }
        else {
          sVar8 = *(short *)(&DAT_01042ba4 + iVar6) + 1;
        }
        local_8 = local_8 - sVar8;
        iVar2 = uVar9 * 0x400 + local_12 + 10 +
                (uint)*(ushort *)(&DAT_01042b3a + iVar7) * (*(ushort *)(&DAT_01042b40 + iVar7) - 1);
        mvshort(*(undefined2 *)(iVar2 + 8),&local_a);
        local_a = local_8 + local_a;
        mvshort(local_a,iVar2 + 8);
        *(uint *)(&DAT_01042b42 + iVar7) = (uint)local_a << 9;
        *(undefined2 *)(iVar5 + 10 + uVar9 * 2) = 1;
        segwrite(cVar3,uVar9,0);
        if (unaff_D7 != 0) {
          return;
        }
      }
      (&DAT_01042b8a)[iVar6] = 0;
    }
  }
  return;
}


// ==== edl_confi @ 01013150

void edl_confi(void)

{
  undefined1 auStack_8 [4];
  
  rqfdstfg(4,0,0,0x80,0x1a,0x4d,1,auStack_8);
  rqfdstfg(5,0,0,0x80,0x1a,0x4d,1,auStack_8);
  return;
}


// ==== edl_dcnfg @ 010131b8

void edl_dcnfg(void)

{
  return;
}


// ==== edl_fcpy @ 010131c8

void edl_fcpy(int param_1,undefined4 param_2,int param_3,undefined4 param_4)

{
  ushort uVar1;
  ushort uVar2;
  ushort uVar3;
  undefined *puVar4;
  undefined *unaff_D7;
  undefined4 uVar5;
  short sVar6;
  
  if ((param_1 != param_3) || (cmpstr(param_2,param_4), unaff_D7 != (undefined *)0x1)) {
    uVar1 = *(ushort *)(&DAT_01042ab2 + param_1 * 0x2a);
    uVar2 = *(ushort *)(&DAT_01042ab2 + param_3 * 0x2a);
    if (uVar1 <= uVar2) {
      malloc(0x1400);
      if (unaff_D7 == (undefined *)0x0) {
        uVar5 = 0x200;
        puVar4 = &bufofrw;
      }
      else {
        uVar5 = 0x1400;
        puVar4 = unaff_D7;
      }
      edl_open(param_1,param_2);
      if ((int)unaff_D7 < 0) {
        freelm(puVar4);
      }
      else {
        sVar6 = (short)unaff_D7;
        edlcreat(param_3,param_4,*(undefined4 *)(&DAT_01042b9c + sVar6 * 0x26));
        if ((int)unaff_D7 < 0) {
          edl_clos((int)sVar6);
          freelm(puVar4);
        }
        else {
          do {
            edl_read((int)sVar6,uVar5,puVar4);
            if ((int)unaff_D7 < 0) {
              freelm(puVar4);
              edl_srch(param_1,param_2);
              if ((int)unaff_D7 < 0) {
                edl_clos((int)sVar6);
                edl_fhfr((int)sVar6);
                freelm(puVar4);
                return;
              }
              fill(puVar4,uVar2,0);
              uVar3 = uVar2;
              if (0x28 < uVar2) {
                uVar3 = 0x28;
              }
              fill(puVar4,uVar3,0x20);
              if ((uVar1 != 0) &&
                 (edl_rxb(param_1,unaff_D7,unaff_D7,uVar1,puVar4), (int)unaff_D7 < 0)) {
                edl_clos((int)sVar6);
                edl_fhfr((int)sVar6);
                freelm(puVar4);
                return;
              }
              edl_srch(param_3,param_4);
              if ((int)unaff_D7 < 0) {
                edl_clos((int)sVar6);
                edl_fhfr((int)sVar6);
                freelm(puVar4);
                return;
              }
              if ((uVar2 != 0) && (edl_wxb(param_3), (int)unaff_D7 < 0)) {
                edl_clos((int)sVar6);
                edl_fhfr((int)sVar6);
                freelm(puVar4);
                return;
              }
              edl_clos((int)sVar6);
              if ((int)unaff_D7 < 0) {
                edl_fhfr((int)sVar6);
              }
              edl_clos((int)sVar6);
              if ((int)unaff_D7 < 0) {
                edl_fhfr((int)sVar6);
                return;
              }
              return;
            }
            edlwrite((int)sVar6);
          } while (-1 < (int)unaff_D7);
          edl_clos((int)sVar6);
          edl_fhfr((int)sVar6);
          freelm(puVar4);
        }
      }
    }
  }
  return;
}


// ==== freelm @ 010134aa

void freelm(undefined *param_1)

{
  if (param_1 != &bufofrw) {
    mfree(param_1);
  }
  return;
}


// ==== edl_fhfr @ 010134c8

void edl_fhfr(short param_1)

{
  char cVar1;
  byte bVar2;
  int iVar3;
  int iVar4;
  uint unaff_D7;
  int iVar5;
  
  iVar3 = param_1 * 0x26;
  cVar1 = (&fcb)[iVar3];
  bVar2 = cVar1 - 4;
  if (bVar2 == 0) {
    iVar4 = d0_buf;
  }
  else {
    iVar4 = d1_buf;
  }
  iVar5 = segtbl + (uint)bVar2 * 0x14;
  if ((&DAT_01042b8a)[iVar3] != '\0') {
    if (*(short *)(&DAT_01042ba8 + iVar3) == 0x100) {
      segcheck(cVar1,(int)(char)(&DAT_01042b96)[iVar3]);
      if (unaff_D7 == 0xffffffff) {
        segread(cVar1,(int)(char)(&DAT_01042b96)[iVar3],0);
        return;
      }
      mvshort(0x200,(unaff_D7 & 0xff) * 0x400 + iVar4 + 10 +
                    (uint)*(ushort *)(&DAT_01042b3a + (uint)bVar2 * 0x2a) *
                    ((char)(&DAT_01042b97)[iVar3] + -1));
      *(undefined2 *)(iVar5 + 10 + (unaff_D7 & 0xff) * 2) = 1;
    }
    (&DAT_01042b8a)[iVar3] = 0;
  }
  return;
}


// ==== edl_init @ 010135ec

/* WARNING: Removing unreachable block (ram,0x01013784) */

undefined4 edl_init(char param_1,int param_2)

{
  char cVar4;
  int iVar1;
  uint uVar2;
  undefined4 uVar3;
  char cVar6;
  byte bVar7;
  int iVar5;
  int iVar8;
  uint unaff_D7;
  char *pcVar9;
  undefined1 auStack_8 [4];
  
  pcVar9 = &dph + (uint)(byte)(param_1 - 4) * 0x2a;
  uVar3 = *(undefined4 *)(param_2 + 0x28);
  cVar4 = (char)uVar3;
  cVar6 = (char)*(undefined2 *)(param_2 + 0x24);
  if ((cVar6 != '\x01') && (cVar6 != '\0')) {
    return uVar3;
  }
  if ((cVar4 != '\x02') && (cVar4 != '\x03')) {
    return uVar3;
  }
  bVar7 = (byte)unaff_D7;
  if (cVar6 == '\x01') {
    if (*pcVar9 == '\0') {
      rqfdslct(param_1,auStack_8);
      if ((unaff_D7 != 0) && ((unaff_D7 & 0xc9) != 0)) {
        if ((char)bVar7 < '\0') {
          return 0xfffffffc;
        }
        return 0xfffffff8;
      }
    }
    else {
      *pcVar9 = '\0';
      fre_proc(param_1,1);
    }
    fill(&buff,0x1460,0);
    form_d_ma(&buff);
    iVar8 = 0;
    do {
      iVar1 = 0x50;
      iVar5 = 0;
      do {
        (&buff)[iVar1] = (char)iVar8;
        iVar1 = iVar1 + 0xba;
        iVar5 = iVar5 + 1;
      } while (iVar5 < 0x1a);
      rqfdtrwr(param_1,iVar8,0,&buff,0x1460,auStack_8);
      iVar8 = iVar8 + 1;
      form_e_ch();
      if (unaff_D7 != 0) goto LAB_01013a3a;
    } while (iVar8 < 0x4d);
    fill(&wbuf,0x80,0);
    cpybuf(&DAT_010135cc,&wbuf,4);
    rqfdscwr(param_1,0,0,7,1,&wbuf,auStack_8);
    form_e_ch();
  }
  else {
    if (*pcVar9 == '\0') {
      return CONCAT31((int3)((uint)uVar3 >> 8),*pcVar9);
    }
    *pcVar9 = '\0';
    fre_proc(param_1,1);
  }
  if (cVar4 == '\x03') {
    fill(&wbuf,0x200,0);
    mvshort(6,&DAT_01042b08);
    mvshort(0x8ea9,&DAT_01042b0a);
    fill(&DAT_01042b0c,0xc,0x20);
    strlen(*(char **)(param_2 + 0x32));
    if (bVar7 < 0xd) {
      uVar2 = unaff_D7 & 0xff;
    }
    else {
      uVar2 = 0xc;
    }
    cpybuf(*(undefined4 *)(param_2 + 0x32),&DAT_01042b0c,uVar2);
    cpybuf("BVE-5000 EDL",&DAT_01042b18,0xc);
    cpybuf("V2.00       ",&DAT_01042b24,0xc);
    blkwrite(param_1,&wbuf,1,1);
    if (unaff_D7 != 0) goto LAB_01013a3a;
    fill(&wbuf,0x200,0);
    mvshort(4,&wbuf);
    DAT_01042936 = 0;
    mvshort(1,&DAT_01042938);
    mvshort(0x2c,&DAT_0104293a);
    mvshort(0xe,&DAT_0104293c);
    mvshort(0x200,&DAT_0104293e);
    mvshort(0x1e0,&DAT_01042946);
    DAT_01042948 = 0;
    DAT_0104294a = 0;
    mvshort(0x800,&DAT_01042978);
    blkwrite(param_1,&wbuf,6,1);
  }
  else {
    fill(&wbuf,0x200,0xe5);
    fill(&DAT_01042b0c,0xc,0x20);
    strlen(*(char **)(param_2 + 0x32));
    if (bVar7 < 0xd) {
      uVar2 = unaff_D7 & 0xff;
    }
    else {
      uVar2 = 0xc;
    }
    cpybuf(*(undefined4 *)(param_2 + 0x32),&DAT_01042b0c,uVar2);
    blkwrite(param_1,&wbuf,1,1);
    if (unaff_D7 != 0) goto LAB_01013a3a;
    fill(&wbuf,0x200,0);
    mvshort(0x1f,&wbuf);
    DAT_01042936 = 0;
    mvshort(1,&DAT_01042938);
    DAT_0104293a = 0;
    mvshort(0x44,&DAT_0104293c);
    mvshort(0x200,&DAT_0104293e);
    mvshort(0x1aa,&DAT_01042946);
    DAT_01042948 = 0;
    DAT_0104294a = 0;
    mvshort(0x800,&DAT_0104294c);
    blkwrite(param_1,&wbuf,6,1);
  }
  if (unaff_D7 == 0) {
    uVar3 = rqfdrels(param_1,auStack_8);
    return uVar3;
  }
LAB_01013a3a:
  uVar3 = rqfdrels(param_1,auStack_8);
  return uVar3;
}


// ==== form_d_ma @ 01013a62

void form_d_ma(undefined1 *param_1)

{
  int iVar1;
  int iVar2;
  undefined1 *puVar3;
  undefined1 *puVar4;
  
  iVar2 = 0;
  do {
    puVar3 = param_1 + 1;
    *param_1 = 0xff;
    iVar2 = iVar2 + 1;
    param_1 = puVar3;
  } while (iVar2 < 0x28);
  iVar2 = 0;
  do {
    puVar4 = puVar3;
    *puVar4 = 0;
    iVar2 = iVar2 + 1;
    puVar3 = puVar4 + 1;
  } while (iVar2 < 6);
  puVar4[1] = 0xfc;
  iVar2 = 0;
  puVar3 = puVar4 + 2;
  do {
    puVar4 = puVar3 + 1;
    *puVar3 = 0xff;
    iVar2 = iVar2 + 1;
    puVar3 = puVar4;
  } while (iVar2 < 0x1a);
  iVar2 = 0;
  do {
    iVar1 = 0;
    do {
      puVar3 = puVar4;
      *puVar3 = 0;
      iVar1 = iVar1 + 1;
      puVar4 = puVar3 + 1;
    } while (iVar1 < 6);
    puVar3[1] = 0xfe;
    puVar3[2] = 0;
    puVar3[3] = 0;
    puVar3[4] = (char)iVar2 + '\x01';
    puVar3[5] = 0;
    puVar3[6] = 0xf7;
    iVar1 = 0;
    puVar3 = puVar3 + 7;
    do {
      puVar4 = puVar3 + 1;
      *puVar3 = 0xff;
      iVar1 = iVar1 + 1;
      puVar3 = puVar4;
    } while (iVar1 < 0xb);
    iVar1 = 0;
    do {
      puVar3 = puVar4;
      *puVar3 = 0;
      iVar1 = iVar1 + 1;
      puVar4 = puVar3 + 1;
    } while (iVar1 < 6);
    puVar3[1] = 0xfb;
    iVar1 = 0;
    puVar3 = puVar3 + 2;
    do {
      puVar4 = puVar3;
      *puVar4 = 0xe5;
      iVar1 = iVar1 + 1;
      puVar3 = puVar4 + 1;
    } while (iVar1 < 0x80);
    puVar4[1] = 0xf7;
    iVar1 = 0;
    puVar3 = puVar4 + 2;
    do {
      puVar4 = puVar3 + 1;
      *puVar3 = 0xff;
      iVar1 = iVar1 + 1;
      puVar3 = puVar4;
    } while (iVar1 < 0x1b);
    iVar2 = iVar2 + 1;
  } while (iVar2 < 0x1a);
  iVar2 = 0;
  do {
    *puVar4 = 0xff;
    iVar2 = iVar2 + 1;
    puVar4 = puVar4 + 1;
  } while (iVar2 < 0x133);
  return;
}


// ==== form_e_ch @ 01013b12

undefined4 form_e_ch(uint param_1)

{
  undefined4 uVar1;
  
  if ((param_1 & 0xffd9) == 0) {
    uVar1 = 0;
  }
  else {
    uVar1 = edl_echk(param_1,1);
  }
  return uVar1;
}


// ==== edl_kind @ 01013b38

void edl_kind(void)

{
  return;
}


// ==== edl_open @ 01013b7c

/* WARNING: Removing unreachable block (ram,0x01013c80) */
/* WARNING: Removing unreachable block (ram,0x01013cc2) */
/* WARNING: Removing unreachable block (ram,0x01013cca) */
/* WARNING: Removing unreachable block (ram,0x01013cd6) */
/* WARNING: Removing unreachable block (ram,0x01013c2a) */

void edl_open(char param_1,undefined4 param_2)

{
  int unaff_D7;
  undefined1 local_19;
  undefined1 local_18 [2];
  undefined1 local_16 [2];
  undefined1 auStack_14 [10];
  undefined1 auStack_a [6];
  
  if ((((&dph)[(uint)(byte)(param_1 - 4) * 0x2a] != '\0') && (fcbchk(), unaff_D7 != -1)) &&
     (namset(param_2,auStack_14), unaff_D7 == 0)) {
    fasc_rdx(auStack_14,auStack_a);
    chk_open(param_1,auStack_14);
    srh_fnam(param_1,auStack_a,local_16,local_18,&local_19);
  }
  return;
}


// ==== edl_pack @ 01013d44

/* WARNING: Removing unreachable block (ram,0x01013fa0) */
/* WARNING: Removing unreachable block (ram,0x01013f7e) */
/* WARNING: Removing unreachable block (ram,0x01013fbe) */
/* WARNING: Removing unreachable block (ram,0x01013fce) */
/* WARNING: Removing unreachable block (ram,0x01013fd6) */
/* WARNING: Removing unreachable block (ram,0x01013ff0) */
/* WARNING: Removing unreachable block (ram,0x01014010) */
/* WARNING: Removing unreachable block (ram,0x010140e4) */
/* WARNING: Removing unreachable block (ram,0x010140dc) */

void edl_pack(char param_1)

{
  int iVar1;
  int iVar2;
  int unaff_D7;
  short sVar3;
  short sVar4;
  undefined1 local_15;
  short local_14;
  undefined2 local_12;
  undefined2 local_10;
  byte local_d;
  short local_c;
  short local_a;
  undefined2 local_8;
  undefined2 local_6;
  
  iVar2 = (uint)(byte)(param_1 - 4U) * 0x2a;
  if ((&dph)[iVar2] != '\0') {
    iVar1 = segtbl + (uint)(byte)(param_1 - 4U) * 0x14;
    local_6 = 1;
    local_8 = 1;
    local_a = *(short *)(&DAT_01042b36 + iVar2) +
              *(short *)(&DAT_01042b54 + iVar2) * *(short *)(&DAT_01042b38 + iVar2);
    while (srh_file(param_1,&local_6,&local_8,&local_a,&local_c,&local_d,0), unaff_D7 == 0) {
      if (4 < *(ushort *)(&DAT_01042b58 + iVar2)) {
        segcopy(param_1,local_d,4);
        local_d = 4;
      }
      local_10 = local_6;
      local_12 = local_8;
      local_14 = local_a;
      local_c = 0;
      srh_file(param_1,&local_10,&local_12,&local_14,&local_c,&local_15,1);
      if (4 < *(ushort *)(&DAT_01042b58 + iVar2)) {
        segcheck(param_1,*(undefined2 *)(iVar1 + (uint)local_d * 2));
        local_d = 0;
        segback(param_1,4,0);
      }
      ex_dir(param_1,local_6,local_8,local_d,local_10,local_12,local_15);
      sVar4 = local_14;
      sVar3 = local_a;
      if (local_c != 0) {
        do {
          blkread(param_1,workbuf,sVar4,1);
          blkwrite(param_1,workbuf,sVar3,1);
          local_c = local_c + -1;
          sVar4 = sVar4 + 1;
          sVar3 = sVar3 + 1;
        } while (local_c != 0);
        local_c = 0;
      }
    }
  }
  return;
}


// ==== arng_blk @ 010140fc

void arng_blk(char param_1)

{
  short sVar1;
  short sVar2;
  byte bVar3;
  ushort uVar4;
  int iVar5;
  int iVar6;
  uint uVar7;
  uint unaff_D7;
  int iVar8;
  int iVar9;
  short *psVar10;
  byte local_21;
  int local_1a;
  byte local_13;
  undefined1 uStack_12;
  undefined1 local_11;
  undefined2 local_10;
  short local_e;
  short local_c;
  undefined1 auStack_a [6];
  
  bVar3 = param_1 - 4;
  iVar6 = (uint)bVar3 * 0x2a;
  if (bVar3 == 0) {
    local_1a = d0_buf;
  }
  else {
    local_1a = d1_buf;
  }
  iVar5 = segtbl + (uint)bVar3 * 0x14;
  iVar9 = seginf + (uint)bVar3 * 0x40;
  sVar1 = *(short *)(&DAT_01042b58 + iVar6);
  *(undefined2 *)(&DAT_01042b58 + iVar6) = 1;
  fill(iVar9,0x20,0);
  fill(iVar9 + 0x20,0x20,0);
  local_10 = 1;
  local_21 = 0;
  while( true ) {
    segread(param_1,local_10,1);
    if ((int)unaff_D7 < 0) {
      return;
    }
    *(undefined1 *)(iVar9 + (uint)local_21) = (undefined1)local_10;
    local_13 = (byte)unaff_D7;
    cnt_ent(param_1,unaff_D7 & 0xff);
    *(byte *)(iVar9 + 0x1f + (uint)local_10) = (byte)unaff_D7;
    iVar8 = (uint)local_13 * 0x400 + local_1a;
    get_segca(param_1,(uint)local_13,&local_c);
    if (local_10 == 1) {
      psVar10 = &local_e;
      sVar2 = *(short *)(iVar8 + 8);
    }
    else {
      psVar10 = (short *)(iVar8 + 8);
      sVar2 = local_e;
    }
    mvshort(sVar2,psVar10);
    local_e = local_c + local_e;
    *(undefined2 *)(iVar5 + 10 + (uint)local_13 * 2) = 1;
    *(ushort *)(&DAT_01042b3e + iVar6) = local_10;
    mvshort(*(undefined2 *)(iVar8 + 2),&local_10);
    if (local_10 == 0) break;
    if (*(ushort *)(&DAT_01042b58 + iVar6) < local_10) {
      *(ushort *)(&DAT_01042b58 + iVar6) = local_10;
    }
    local_21 = local_21 + 1;
  }
  *(short *)(&DAT_01042b40 + iVar6) =
       *(char *)(iVar9 + 0x1f + (uint)*(ushort *)(&DAT_01042b3e + iVar6)) + 1;
  if (*(short *)(&DAT_01042b58 + iVar6) != sVar1) {
    segcheck(param_1,1);
    if (unaff_D7 == 0xffffffff) {
      segread(param_1,1,0);
      return;
    }
    mvshort(*(undefined2 *)(&DAT_01042b58 + iVar6),local_1a + 4 + unaff_D7 * 0x400);
    *(undefined2 *)(iVar5 + 10 + unaff_D7 * 2) = 1;
  }
  uVar7 = 0;
  do {
    iVar6 = uVar7 * 0x26;
    if (((&DAT_01042b8a)[iVar6] == '\x01') && ((&fcb)[iVar6] == param_1)) {
      fasc_rdx(iVar6 + 0x1042b8b,auStack_a);
      srh_fnam(param_1,auStack_a,&local_10,&uStack_12,&local_13);
      if ((int)unaff_D7 < 1) {
        return;
      }
      (&DAT_01042b96)[iVar6] = (undefined1)local_10;
      (&DAT_01042b97)[iVar6] = local_11;
      *(short *)(&DAT_01042b9a + iVar6) =
           *(short *)(&DAT_01042b9a + iVar6) - *(short *)(&DAT_01042b98 + iVar6);
      calc_bloc(param_1,(int)(char)(&DAT_01042b96)[iVar6],(int)(char)(&DAT_01042b97)[iVar6],
                &DAT_01042b98 + iVar6);
      *(short *)(&DAT_01042b9a + iVar6) =
           *(short *)(&DAT_01042b98 + iVar6) + *(short *)(&DAT_01042b9a + iVar6);
    }
    uVar4 = (short)uVar7 + 1;
    uVar7 = (uint)uVar4;
  } while (uVar4 < 4);
  return;
}


// ==== ex_dir @ 010143c0

void ex_dir(char param_1,undefined4 param_2,ushort param_3,byte param_4,undefined4 param_5,
           ushort param_6,byte param_7)

{
  int iVar1;
  undefined1 uVar2;
  byte bVar3;
  int iVar4;
  uint uVar5;
  ushort uVar6;
  int iVar7;
  int iVar8;
  
  bVar3 = param_1 - 4;
  iVar4 = (uint)bVar3 * 0x2a;
  if (bVar3 == 0) {
    iVar7 = d0_buf;
  }
  else {
    iVar7 = d1_buf;
  }
  iVar8 = segtbl + (uint)bVar3 * 0x14;
  iVar1 = (uint)param_4 * 0x400 + iVar7 + 10 +
          (uint)*(ushort *)(&DAT_01042b3a + iVar4) * (param_3 - 1);
  iVar7 = (uint)param_7 * 0x400 + iVar7 + 10 +
          (uint)*(ushort *)(&DAT_01042b3a + iVar4) * (param_6 - 1);
  uVar6 = 0;
  if (*(short *)(&DAT_01042b3a + iVar4) != 0) {
    do {
      uVar5 = (uint)uVar6;
      uVar2 = *(undefined1 *)(iVar1 + uVar5);
      *(undefined1 *)(iVar1 + uVar5) = *(undefined1 *)(iVar7 + uVar5);
      *(undefined1 *)(iVar7 + uVar5) = uVar2;
      uVar6 = uVar6 + 1;
    } while (*(ushort *)(&DAT_01042b3a + iVar4) != uVar6);
  }
  *(undefined2 *)(iVar8 + 10 + (uint)param_4 * 2) = 1;
  *(undefined2 *)(iVar8 + 10 + (uint)param_7 * 2) = 1;
  return;
}


// ==== edl_read @ 010144a0

void edl_read(short param_1,ushort param_2,int param_3)

{
  int iVar1;
  undefined1 uVar2;
  ushort uVar3;
  int iVar4;
  int unaff_D7;
  
  iVar4 = param_1 * 0x26;
  uVar2 = (&fcb)[iVar4];
  if (((&DAT_01042b8a)[iVar4] != '\0') &&
     (*(short *)(&DAT_01042b94 + iVar4) != *(short *)(&DAT_01042ba0 + iVar4))) {
    iVar1 = *(int *)(&DAT_01042baa + iVar4);
    do {
      if ((int)(uint)param_2 < (int)(0x200 - (uint)*(ushort *)(&DAT_01042ba2 + iVar4))) {
        if (param_2 == 0) {
          return;
        }
        if (*(short *)(&DAT_01042b9a + iVar4) == -1) {
          *(undefined2 *)(&DAT_01042b9a + iVar4) = *(undefined2 *)(&DAT_01042b98 + iVar4);
        }
        if ((*(short *)(&DAT_01042ba2 + iVar4) == 0) &&
           (blkread(uVar2,iVar1,*(undefined2 *)(&DAT_01042b9a + iVar4),1), unaff_D7 != 0)) {
          return;
        }
        cpybuf(iVar1 + (uint)*(ushort *)(&DAT_01042ba2 + iVar4),param_3,param_2);
        *(ushort *)(&DAT_01042ba2 + iVar4) = param_2 + *(short *)(&DAT_01042ba2 + iVar4);
        return;
      }
      if (*(short *)(&DAT_01042b9a + iVar4) == -1) {
        *(undefined2 *)(&DAT_01042b9a + iVar4) = *(undefined2 *)(&DAT_01042b98 + iVar4);
      }
      uVar3 = 0x200 - *(short *)(&DAT_01042ba2 + iVar4);
      if (uVar3 < 0x200) {
        cpybuf(iVar1 + (uint)*(ushort *)(&DAT_01042ba2 + iVar4),param_3,uVar3);
      }
      else {
        blkread(uVar2,param_3,*(undefined2 *)(&DAT_01042b9a + iVar4),1);
        if (unaff_D7 != 0) {
          return;
        }
      }
      param_3 = (uint)uVar3 + param_3;
      param_2 = param_2 - uVar3;
      *(undefined2 *)(&DAT_01042ba2 + iVar4) = 0;
      *(short *)(&DAT_01042b9a + iVar4) = *(short *)(&DAT_01042b9a + iVar4) + 1;
      *(short *)(&DAT_01042ba0 + iVar4) = *(short *)(&DAT_01042ba0 + iVar4) + 1;
    } while (*(short *)(&DAT_01042b94 + iVar4) != *(short *)(&DAT_01042ba0 + iVar4));
  }
  return;
}


// ==== edl_srch @ 0101462c

/* WARNING: Removing unreachable block (ram,0x010146c0) */
/* WARNING: Removing unreachable block (ram,0x01014694) */

void edl_srch(char param_1,undefined4 param_2)

{
  int unaff_D7;
  undefined1 uStack_19;
  undefined1 auStack_18 [2];
  undefined1 auStack_16 [2];
  undefined1 auStack_14 [10];
  undefined1 auStack_a [6];
  
  if (((&dph)[(uint)(byte)(param_1 - 4) * 0x2a] != '\0') &&
     (namset(param_2,auStack_14), unaff_D7 == 0)) {
    fasc_rdx(auStack_14,auStack_a);
    srh_fnam(param_1,auStack_a,auStack_16,auStack_18,&uStack_19);
  }
  return;
}


// ==== srh_fnam @ 010146d2

void srh_fnam(char param_1,short *param_2,short *param_3,short *param_4,undefined1 *param_5)

{
  int unaff_D7;
  undefined2 *puVar1;
  int iVar2;
  int local_16;
  short local_c;
  short local_a;
  short local_8;
  short local_6;
  
  if ((byte)(param_1 - 4U) == 0) {
    local_16 = d0_buf;
  }
  else {
    local_16 = d1_buf;
  }
  *param_3 = 1;
LAB_01014722:
  *param_4 = 1;
  segread(param_1,*param_3,1);
  if (unaff_D7 < 0) {
    return;
  }
  *param_5 = (char)unaff_D7;
  iVar2 = unaff_D7 * 0x400 + local_16;
  puVar1 = (undefined2 *)(iVar2 + 10);
  do {
    mvshort(*puVar1,&local_c);
    if (local_c != 0x200) {
      if (local_c == 0x800) break;
      cpyword(puVar1 + 1,&local_a,3);
      if (((*param_2 == local_a) && (param_2[1] == local_8)) && (param_2[2] == local_6)) {
        return;
      }
    }
    puVar1 = (undefined2 *)
             ((uint)*(ushort *)(&DAT_01042b3a + (uint)(byte)(param_1 - 4U) * 0x2a) + (int)puVar1);
    *param_4 = *param_4 + 1;
  } while( true );
  mvshort(*(undefined2 *)(iVar2 + 2),&local_c);
  if (local_c == 0) {
    return;
  }
  *param_3 = local_c;
  goto LAB_01014722;
}


// ==== srh_seri @ 0101480a

void srh_seri(char param_1,ushort param_2,ushort *param_3,ushort *param_4,undefined1 *param_5)

{
  byte bVar1;
  ushort uVar2;
  byte bVar3;
  int unaff_D7;
  int iVar4;
  
  iVar4 = seginf + (uint)(byte)(param_1 - 4) * 0x40;
  bVar3 = 0;
  while( true ) {
    bVar1 = *(byte *)(iVar4 + (uint)bVar3);
    if (bVar1 == 0) {
      return;
    }
    uVar2 = (ushort)*(char *)(iVar4 + 0x1f + (uint)bVar1);
    if (param_2 <= uVar2) break;
    param_2 = param_2 - uVar2;
    bVar3 = bVar3 + 1;
  }
  *param_3 = (ushort)bVar1;
  *param_4 = param_2;
  segread(param_1,*param_3,1);
  if (unaff_D7 < 0) {
    return;
  }
  *param_5 = (char)unaff_D7;
  return;
}


// ==== next_ent @ 01014890

void next_ent(char param_1,short *param_2,ushort *param_3,byte *param_4)

{
  undefined2 *puVar1;
  int iVar2;
  int unaff_D7;
  int iVar3;
  int local_10;
  short local_6;
  
  iVar2 = (uint)(byte)(param_1 - 4U) * 0x2a;
  if ((byte)(param_1 - 4U) == 0) {
    local_10 = d0_buf;
  }
  else {
    local_10 = d1_buf;
  }
  do {
    segread(param_1,*param_2,1);
    if (unaff_D7 < 0) {
      return;
    }
    iVar3 = unaff_D7 * 0x400 + local_10;
    *param_4 = (byte)unaff_D7;
    while( true ) {
      *param_3 = *param_3 + 1;
      puVar1 = (undefined2 *)
               ((uint)*param_4 * 0x400 + local_10 + 10 +
               (uint)*(ushort *)(&DAT_01042b3a + iVar2) * (*param_3 - 1));
      mvshort(*puVar1,&local_6);
      if (local_6 == 0x400) {
        return;
      }
      if (local_6 == -0x7c00) {
        return;
      }
      if (local_6 == 0x800) break;
      if (local_6 == 0x200) {
        mvshort(*(undefined2 *)((int)puVar1 + (uint)*(ushort *)(&DAT_01042b3a + iVar2)),&local_6);
        if (local_6 != 0x800) {
          return;
        }
        mvshort(*(undefined2 *)(iVar3 + 2),&local_6);
        if (local_6 != 0) {
          return;
        }
      }
    }
    mvshort(*(undefined2 *)(iVar3 + 2),&local_6);
    if (local_6 == 0) {
      return;
    }
    *param_2 = local_6;
    *param_3 = 0;
  } while( true );
}


// ==== srh_file @ 010149ee

void srh_file(char param_1,short *param_2,ushort *param_3,short *param_4,short *param_5,
             byte *param_6,char param_7)

{
  undefined2 *puVar1;
  int iVar2;
  int unaff_D7;
  int iVar3;
  short local_6;
  
  if ((byte)(param_1 - 4U) == 0) {
    iVar2 = d0_buf;
  }
  else {
    iVar2 = d1_buf;
  }
  segread(param_1,*param_2,1);
  if (-1 < unaff_D7) {
    iVar3 = unaff_D7 * 0x400 + iVar2;
    *param_6 = (byte)unaff_D7;
    mvshort(*(undefined2 *)(iVar3 + 8),&local_6);
    *param_4 = *param_4 - local_6;
    while( true ) {
      while( true ) {
        puVar1 = (undefined2 *)
                 ((uint)*param_6 * 0x400 + iVar2 + 10 +
                 (uint)*(ushort *)(&DAT_01042b3a + (uint)(byte)(param_1 - 4U) * 0x2a) *
                 (*param_3 - 1));
        mvshort(*puVar1,&local_6);
        if (local_6 != 0x800) break;
        mvshort(*(undefined2 *)(iVar3 + 2),&local_6);
        if (local_6 == 0) {
          return;
        }
        *param_2 = local_6;
        *param_3 = 1;
        *param_4 = 0;
        segread(param_1,*param_2,1);
        if (unaff_D7 < 0) {
          return;
        }
        iVar3 = unaff_D7 * 0x400 + iVar2;
        *param_6 = (byte)unaff_D7;
      }
      if (((param_7 == '\0') && (local_6 == 0x200)) || ((param_7 != '\0' && (local_6 != 0x200))))
      break;
      mvshort(puVar1[4],&local_6);
      *param_4 = local_6 + *param_4;
      *param_5 = local_6 + *param_5;
      *param_3 = *param_3 + 1;
    }
    mvshort(puVar1[4],param_5);
    mvshort(*(undefined2 *)(iVar3 + 8),&local_6);
    *param_4 = local_6 + *param_4;
  }
  return;
}


// ==== fasc_rdx @ 01014bcc

void fasc_rdx(int param_1,int param_2)

{
  int unaff_D7;
  
  con_asc_r(param_1,param_2);
  if (unaff_D7 == 0) {
    con_asc_r(param_1 + 3,param_2 + 2);
    con_asc_r(param_1 + 6,param_2 + 4);
  }
  return;
}


// ==== con_asc_r @ 01014c22

void con_asc_r(char *param_1,short *param_2)

{
  int unaff_D7;
  short local_6;
  
  ascrdx((int)param_1[2],&local_6);
  if (unaff_D7 == 0) {
    *param_2 = local_6;
    ascrdx((int)param_1[1],&local_6);
    *param_2 = *param_2 + local_6 * 0x28;
    ascrdx((int)*param_1,&local_6);
    *param_2 = *param_2 + local_6 * 0x640;
  }
  return;
}


// ==== ascrdx @ 01014ca6

void ascrdx(char param_1,short *param_2)

{
  if ((param_1 < 'A') || ('Z' < param_1)) {
    if ((param_1 < '0') || ('9' < param_1)) {
      if (param_1 == ' ') {
        *param_2 = 0;
      }
      else if (param_1 == '$') {
        *param_2 = 0x1b;
      }
      else if (param_1 == '.') {
        *param_2 = 0x1c;
      }
    }
    else {
      *param_2 = param_1 + -0x12;
    }
  }
  else {
    *param_2 = param_1 + -0x40;
  }
  return;
}


// ==== edlcreat @ 01014d0c

/* WARNING: Removing unreachable block (ram,0x01015328) */
/* WARNING: Removing unreachable block (ram,0x01014e7e) */
/* WARNING: Removing unreachable block (ram,0x01014ee2) */
/* WARNING: Removing unreachable block (ram,0x01014eea) */
/* WARNING: Removing unreachable block (ram,0x01014ec4) */
/* WARNING: Removing unreachable block (ram,0x01014f10) */
/* WARNING: Removing unreachable block (ram,0x01014f36) */
/* WARNING: Removing unreachable block (ram,0x01014f58) */
/* WARNING: Removing unreachable block (ram,0x010150c0) */
/* WARNING: Removing unreachable block (ram,0x010150d0) */
/* WARNING: Removing unreachable block (ram,0x010150e0) */
/* WARNING: Removing unreachable block (ram,0x01015124) */
/* WARNING: Removing unreachable block (ram,0x01014fa4) */
/* WARNING: Removing unreachable block (ram,0x010150e8) */
/* WARNING: Removing unreachable block (ram,0x0101510a) */
/* WARNING: Removing unreachable block (ram,0x01015110) */
/* WARNING: Removing unreachable block (ram,0x01015122) */
/* WARNING: Removing unreachable block (ram,0x0101512e) */
/* WARNING: Removing unreachable block (ram,0x01015312) */
/* WARNING: Removing unreachable block (ram,0x01015346) */
/* WARNING: Removing unreachable block (ram,0x0101535c) */
/* WARNING: Removing unreachable block (ram,0x01015388) */
/* WARNING: Removing unreachable block (ram,0x0101533e) */

void edlcreat(char param_1,undefined4 param_2,ushort param_3)

{
  int iVar1;
  int unaff_D7;
  undefined1 local_19;
  undefined1 local_18 [2];
  undefined1 auStack_16 [2];
  undefined1 auStack_14 [10];
  undefined1 auStack_a [6];
  
  iVar1 = (uint)(byte)(param_1 - 4) * 0x2a;
  if (((((&dph)[iVar1] != '\0') && ((uint)param_3 <= *(uint *)(&DAT_01042b42 + iVar1))) &&
      (fcbchk(), unaff_D7 != -1)) && (namset(param_2,auStack_14), unaff_D7 == 0)) {
    fasc_rdx(auStack_14,auStack_a);
    chk_open(param_1,auStack_14);
    srh_fnam(param_1,auStack_a,auStack_16,local_18,&local_19);
  }
  return;
}


// ==== get_segca @ 010153b0

void get_segca(char param_1,byte param_2,short *param_3)

{
  int iVar1;
  undefined2 *puVar2;
  short local_6;
  
  if ((byte)(param_1 - 4U) == 0) {
    iVar1 = d0_buf;
  }
  else {
    iVar1 = d1_buf;
  }
  puVar2 = (undefined2 *)(iVar1 + 10 + (uint)param_2 * 0x400);
  *param_3 = 0;
  while( true ) {
    mvshort(*puVar2,&local_6);
    if (local_6 == 0x800) break;
    mvshort(puVar2[4],&local_6);
    *param_3 = local_6 + *param_3;
    puVar2 = (undefined2 *)
             ((uint)*(ushort *)(&DAT_01042b3a + (uint)(byte)(param_1 - 4U) * 0x2a) + (int)puVar2);
  }
  return;
}


// ==== set_fcb @ 01015452

void set_fcb(undefined1 param_1,undefined4 param_2,undefined2 param_3,undefined2 param_4,
            undefined2 param_5,ushort param_6,undefined1 param_7)

{
  int iVar1;
  
  iVar1 = (uint)param_6 * 0x26;
  (&fcb)[iVar1] = param_1;
  cpybuf(param_2,iVar1 + 0x1042b8b,9);
  *(undefined2 *)(&DAT_01042b94 + iVar1) = param_3;
  (&DAT_01042b96)[iVar1] = (char)param_4;
  (&DAT_01042b97)[iVar1] = (char)param_5;
  calc_bloc(param_1,param_4,param_5,&DAT_01042b98 + iVar1,param_7);
  *(undefined2 *)(&DAT_01042b9a + iVar1) = 0xffff;
  *(uint *)(&DAT_01042b9c + iVar1) = (uint)*(ushort *)(&DAT_01042b94 + iVar1) << 9;
  *(undefined2 *)(&DAT_01042ba0 + iVar1) = 0;
  *(undefined2 *)(&DAT_01042ba2 + iVar1) = 0;
  return;
}


// ==== calc_bloc @ 010154f4

void calc_bloc(char param_1,undefined4 param_2,short param_3,short *param_4,byte param_5)

{
  int iVar1;
  undefined2 *puVar2;
  short local_8;
  short local_6;
  
  if ((byte)(param_1 - 4U) == 0) {
    iVar1 = d0_buf;
  }
  else {
    iVar1 = d1_buf;
  }
  puVar2 = (undefined2 *)(iVar1 + 10 + (uint)param_5 * 0x400);
  *param_4 = 0;
  local_8 = 1;
  if (param_3 != 1) {
    do {
      mvshort(*puVar2,&local_6);
      if (local_6 == 0x800) {
        return;
      }
      mvshort(puVar2[4],&local_6);
      *param_4 = local_6 + *param_4;
      puVar2 = (undefined2 *)
               ((uint)*(ushort *)(&DAT_01042b3a + (uint)(byte)(param_1 - 4U) * 0x2a) + (int)puVar2);
      local_8 = local_8 + 1;
    } while (param_3 != local_8);
  }
  mvshort(*(undefined2 *)((uint)param_5 * 0x400 + iVar1 + 8),&local_8);
  *param_4 = local_8 + *param_4;
  return;
}


// ==== chk_open @ 010155d6

void chk_open(char param_1,undefined4 param_2)

{
  int iVar1;
  ushort uVar2;
  int unaff_D7;
  
  uVar2 = 0;
  while( true ) {
    iVar1 = (uint)uVar2 * 0x26;
    if ((((&DAT_01042b8a)[iVar1] == '\x01') && (param_1 == (&fcb)[iVar1])) &&
       (cmpbuf(param_2,iVar1 + 0x1042b8b,9), unaff_D7 == 1)) break;
    uVar2 = uVar2 + 1;
    if (3 < uVar2) {
      return;
    }
  }
  return;
}


// ==== edldelet @ 0101563c

/* WARNING: Removing unreachable block (ram,0x01015724) */
/* WARNING: Removing unreachable block (ram,0x01015772) */
/* WARNING: Removing unreachable block (ram,0x01015786) */
/* WARNING: Removing unreachable block (ram,0x0101577a) */
/* WARNING: Removing unreachable block (ram,0x01015766) */
/* WARNING: Removing unreachable block (ram,0x010156d0) */

void edldelet(char param_1,undefined4 param_2)

{
  int unaff_D7;
  undefined1 local_19;
  undefined1 local_18 [2];
  undefined1 auStack_16 [2];
  undefined1 auStack_14 [10];
  undefined1 auStack_a [6];
  
  if (((&dph)[(uint)(byte)(param_1 - 4) * 0x2a] != '\0') &&
     (namset(param_2,auStack_14), unaff_D7 == 0)) {
    fasc_rdx(auStack_14,auStack_a);
    chk_open(param_1,auStack_14);
    srh_fnam(param_1,auStack_a,auStack_16,local_18,&local_19);
  }
  return;
}


// ==== edldemnt @ 010157ac

/* WARNING: Removing unreachable block (ram,0x0101580c) */

void edldemnt(char param_1)

{
  byte bVar1;
  int unaff_D7;
  char *pcVar2;
  
  bVar1 = param_1 - 4;
  pcVar2 = &dph + (uint)bVar1 * 0x2a;
  if ((*pcVar2 != '\0') && (fcbdrvch(param_1), unaff_D7 == 0)) {
    segwrite(param_1,0,2);
    fill(segtbl + (uint)bVar1 * 0x14,0x14,0);
    fill(seginf + (uint)bVar1 * 0x40,0x40,0);
    *pcVar2 = '\0';
    fill(pcVar2,0x2a,0);
    fre_proc(param_1,0);
  }
  return;
}


// ==== fcbdrvch @ 01015874

undefined4 fcbdrvch(char param_1)

{
  undefined3 uVar1;
  int iVar2;
  undefined4 uVar3;
  byte bVar4;
  
  bVar4 = 0;
  while( true ) {
    iVar2 = (uint)bVar4 * 0x26;
    uVar1 = (undefined3)((uint)iVar2 >> 8);
    uVar3 = CONCAT31(uVar1,(&DAT_01042b8a)[iVar2]);
    if (((&DAT_01042b8a)[iVar2] != '\0') &&
       (uVar3 = CONCAT31(uVar1,(&fcb)[iVar2]), param_1 == (&fcb)[iVar2])) break;
    bVar4 = bVar4 + 1;
    if (3 < bVar4) {
      return uVar3;
    }
  }
  return uVar3;
}


// ==== edldos @ 010158b4

void edldos(void)

{
  int unaff_D7;
  undefined4 uVar1;
  undefined1 auStack_3e [2];
  undefined1 local_3c;
  undefined1 local_36;
  undefined1 local_34;
  undefined1 local_33;
  undefined1 auStack_32 [12];
  undefined1 auStack_26 [12];
  undefined2 local_1a;
  undefined2 local_18;
  undefined4 local_16;
  short local_12;
  int in_stack_fffffff4;
  int in_stack_fffffff8;
  
  edl_confi();
  fill(&dph,0x54,0);
  fill(&fcb,0xbe,0);
  do {
    while (remsg(auStack_3e), unaff_D7 < 0) {
      wtmsg();
    }
    s_ltopa(local_3c,in_stack_fffffff4);
    s_ltopa(local_3c,in_stack_fffffff8);
    switch(local_36) {
    case 1:
      edlcreat(local_34,auStack_32,local_16);
      goto LAB_01015bc0;
    case 2:
      edl_open(local_34,auStack_32);
      break;
    case 3:
      edl_clos((int)local_12);
      goto LAB_01015c3e;
    case 4:
      edl_read((int)local_12,local_16,unaff_D7);
      goto LAB_01015bc0;
    case 5:
      edlwrite((int)local_12,local_16,unaff_D7);
      goto LAB_01015bc0;
    case 6:
      edldelet(local_34,auStack_32);
      break;
    case 7:
      edlresum(local_34,local_1a);
      break;
    case 8:
      edlrenam(local_34,auStack_32,auStack_26);
      goto LAB_01015bc0;
    case 9:
      edlmount(local_34);
      goto LAB_01015c3e;
    case 10:
      edldemnt(local_34);
      goto LAB_01015c3e;
    case 0xb:
      edlsghdr(local_34,unaff_D7);
      break;
    case 0xc:
      edl_srch(local_34,auStack_32);
      break;
    case 0xd:
      edl_dire(local_34,local_1a,local_18,unaff_D7);
      goto LAB_01015bea;
    case 0xe:
      edl_rxb(local_34,local_1a,local_18,local_16,unaff_D7);
      goto LAB_01015b0a;
    case 0xf:
      edl_wxb(local_34,local_1a,local_18,local_16,unaff_D7);
LAB_01015b0a:
      *(int *)unaff_D7 = unaff_D7;
      goto switchD_01015948_caseD_16;
    case 0x10:
      edlremai(local_34);
      goto LAB_01015c3e;
    case 0x11:
      edlgtvol(local_34,unaff_D7);
      break;
    case 0x12:
      edlptvol(local_34,unaff_D7);
      break;
    case 0x13:
      edl_kind(local_34);
      goto LAB_01015c3e;
    case 0x14:
      edl_init(local_34,auStack_3e);
      break;
    case 0x15:
      edl_pack(local_34);
      goto LAB_01015c3e;
    default:
      goto switchD_01015948_caseD_16;
    case 0x17:
      edlvolcp(local_34,local_33,auStack_3e);
LAB_01015bc0:
      *(int *)unaff_D7 = unaff_D7;
      goto switchD_01015948_caseD_16;
    case 0x18:
      edldstat(local_34);
      goto LAB_01015c3e;
    case 0x19:
      edl_fcpy(local_34,auStack_32,local_33,auStack_26);
LAB_01015bea:
      *(int *)unaff_D7 = unaff_D7;
      goto switchD_01015948_caseD_16;
    case 0x1a:
      uVar1 = 1;
      goto LAB_01015bfe;
    case 0x1b:
      uVar1 = 0;
LAB_01015bfe:
      edlrwsct(local_34,(int)local_12,local_18,local_16,unaff_D7,uVar1);
      *(int *)unaff_D7 = unaff_D7;
      goto switchD_01015948_caseD_16;
    case 0x1d:
      edl_dcnfg(local_34);
LAB_01015c3e:
      *(int *)unaff_D7 = unaff_D7;
      goto switchD_01015948_caseD_16;
    }
    *(int *)unaff_D7 = unaff_D7;
switchD_01015948_caseD_16:
    post(local_3c,0x4000000);
    in_stack_fffffff4 = unaff_D7;
    in_stack_fffffff8 = unaff_D7;
  } while( true );
}


// ==== edldstat @ 01015c68

uint edldstat(int param_1)

{
  byte bVar1;
  uint uVar2;
  uint unaff_D7;
  undefined1 auStack_8 [4];
  
  if ((&dph)[(param_1 + -4) * 0x2a] == 0) {
    rqfdslct(param_1,auStack_8);
    if ((unaff_D7 & 0x7c000101) != 0) {
      return unaff_D7 & 0x7c000101;
    }
  }
  mayiwr_d(param_1);
  bVar1 = (&dph)[(param_1 + -4) * 0x2a];
  uVar2 = (uint)bVar1;
  if (bVar1 == 0) {
    uVar2 = rqfdrels(param_1,auStack_8);
  }
  return uVar2;
}


// ==== edlgtvol @ 01015ce8

undefined1 edlgtvol(char param_1,undefined4 param_2)

{
  undefined1 uVar1;
  int iVar2;
  
  iVar2 = (uint)(byte)(param_1 - 4) * 0x2a;
  if ((&dph)[iVar2] == '\0') {
    uVar1 = 0;
  }
  else {
    uVar1 = cpybuf(iVar2 + 0x1042b46,param_2,0xd);
  }
  return uVar1;
}


// ==== edlmount @ 01015d46

/* WARNING: Removing unreachable block (ram,0x01015f70) */
/* WARNING: Removing unreachable block (ram,0x01015dc8) */
/* WARNING: Removing unreachable block (ram,0x01015ddc) */
/* WARNING: Removing unreachable block (ram,0x01015e02) */
/* WARNING: Removing unreachable block (ram,0x01015e06) */
/* WARNING: Removing unreachable block (ram,0x01015e2e) */
/* WARNING: Removing unreachable block (ram,0x010160a8) */

void edlmount(char param_1)

{
  bool bVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  byte bVar5;
  uint unaff_D7;
  int iVar6;
  undefined2 *puVar7;
  int iVar8;
  undefined4 uVar9;
  byte local_1b;
  ushort local_e;
  undefined2 local_c;
  ushort local_a;
  undefined1 auStack_8 [4];
  
  bVar5 = param_1 - 4;
  iVar3 = (uint)bVar5 * 0x2a;
  if (((&dph)[iVar3] != '\x01') && (malloc(0x1400), bufp1 = unaff_D7, unaff_D7 != 0)) {
    mountchk();
    uVar2 = bufp1;
    if (unaff_D7 == 0) {
      malloc(0x800);
      bufp2 = unaff_D7;
      mfree(bufp1);
    }
    else {
      if (bVar5 == 0) {
        d0_save = bufp1;
        d0_buf = bufp1;
      }
      else {
        d1_save = bufp1;
        d1_buf = bufp1;
      }
      rqfdslct(param_1,auStack_8);
      if ((unaff_D7 & 0xc9) == 0) {
        blkread(param_1,workbuf,1,1);
        if (unaff_D7 == 0) {
          iVar4 = segtbl + (uint)bVar5 * 0x14;
          fill(iVar4,0x14,0);
          puVar7 = (undefined2 *)(uVar2 + 0x1000);
          seg1rw(param_1,1,4,0);
          mvshort(*puVar7,&local_a);
          cmpbuf("BVE-5000 EDL",workbuf + 0x1e4,0xc);
          cmpbuf("DECRT11",workbuf + 0x1f0,7);
          if ((local_a == 0) || (0x1f < local_a)) {
            fre_proc(param_1,0);
            return;
          }
          (&DAT_01042b35)[iVar3] = 2;
          fill(iVar3 + 0x1042b46,0xd,0);
          cpybuf(workbuf + 0x1d8,iVar3 + 0x1042b46,0xc);
          *(undefined2 *)(&DAT_01042b36 + iVar3) = 6;
          *(undefined2 *)(&DAT_01042b38 + iVar3) = 2;
          cpyword(puVar7,&DAT_01042b54 + iVar3,5);
          local_e = *(short *)(&DAT_01042b5a + iVar3) + 0xe;
          *(ushort *)(&DAT_01042b3a + iVar3) = local_e;
          local_a = (ushort)(0x3f6 / local_e);
          if ((short)(0x3f6 % (uint)local_e) == 0) {
            local_a = local_a - 1;
          }
          *(ushort *)(&DAT_01042b3c + iVar3) = local_a;
          iVar6 = seginf + (uint)bVar5 * 0x40;
          fill(iVar6,0x40,0);
          local_c = 1;
          bVar1 = false;
          local_1b = 0;
          do {
            segread(param_1,local_c,1);
            bVar5 = 0;
            do {
              *(undefined1 *)(iVar6 + (uint)local_1b) = (undefined1)local_c;
              cnt_ent(param_1,(uint)bVar5);
              *(undefined1 *)(iVar6 + 0x1f + (uint)local_c) = 0;
              iVar8 = (uint)bVar5 * 0x400 + uVar2;
              mvshort(*(undefined2 *)(iVar8 + 2),&local_c);
              if (local_c == 0) {
                bVar1 = true;
                break;
              }
              bVar5 = bVar5 + 1;
              local_1b = local_1b + 1;
            } while (bVar5 < 4);
            if (bVar1) {
              *(undefined2 *)(&DAT_01042b3e + iVar3) = *(undefined2 *)(iVar4 + (uint)bVar5 * 2);
              *(undefined2 *)(iVar4 + 8) = 0;
              *(short *)(&DAT_01042b40 + iVar3) =
                   *(char *)(iVar6 + 0x1f + (uint)*(ushort *)(&DAT_01042b3e + iVar3)) + 1;
              iVar6 = (*(ushort *)(&DAT_01042b40 + iVar3) - 1) *
                      (*(ushort *)(&DAT_01042b5a + iVar3) + 0xe);
              iVar4 = iVar6 + 0x12;
              if (iVar4 < 0) {
                iVar4 = iVar6 + 0x13;
              }
              local_a = (ushort)(iVar4 >> 1);
              mvshort(*(undefined2 *)(iVar8 + (iVar4 >> 1 & 0xffffU) * 2),&local_e);
              *(uint *)(&DAT_01042b42 + iVar3) = (uint)local_e << 9;
              (&dph)[iVar3] = '\x01';
              return;
            }
          } while( true );
        }
        uVar9 = 0;
      }
      else {
        uVar9 = 1;
      }
      fre_proc(param_1,uVar9);
    }
  }
  return;
}


// ==== cnt_ent @ 010161b4

short cnt_ent(char param_1,byte param_2)

{
  undefined2 *puVar1;
  ushort uVar2;
  ushort uVar3;
  int iVar4;
  short sVar5;
  int iVar6;
  uint uVar7;
  short local_6;
  
  iVar4 = (uint)(byte)(param_1 - 4U) * 0x2a;
  if ((byte)(param_1 - 4U) == 0) {
    iVar6 = d0_buf;
  }
  else {
    iVar6 = d1_buf;
  }
  iVar6 = (uint)param_2 * 0x400 + iVar6;
  uVar2 = *(ushort *)(&DAT_01042b3a + iVar4);
  uVar7 = 0;
  sVar5 = 0;
  if (*(ushort *)(&DAT_01042b3c + iVar4) != 0xffffffff) {
    do {
      puVar1 = (undefined2 *)(iVar6 + 10 + uVar2 * uVar7);
      sVar5 = mvshort(*puVar1,&local_6);
      if (local_6 == 0x800) {
        return sVar5;
      }
      if (((local_6 == 0x200) &&
          (sVar5 = mvshort(*(undefined2 *)((int)puVar1 + (uint)uVar2),&local_6), local_6 == 0x800))
         && (sVar5 = *(short *)(iVar6 + 2), sVar5 == 0)) {
        return 0;
      }
      uVar3 = (short)uVar7 + 1;
      uVar7 = (uint)uVar3;
    } while ((uint)uVar3 < *(ushort *)(&DAT_01042b3c + iVar4) + 1);
  }
  return sVar5;
}


// ==== fre_proc @ 01016298

void fre_proc(char param_1,char param_2)

{
  int unaff_D7;
  undefined1 auStack_8 [4];
  
  if (param_2 == '\0') {
    rqfdrels(param_1,auStack_8);
  }
  if (param_1 == '\x04') {
    mfree(d0_save);
    d0_save = 0;
    d0_buf = 0;
  }
  else {
    mfree(d1_save);
    d1_save = 0;
    d1_buf = 0;
  }
  mountchk();
  if (unaff_D7 == 0) {
    mfree(bufp2);
    mfree(workbuf);
    bufp2 = 0;
    workbuf = 0;
  }
  return;
}


// ==== mountchk @ 01016330

undefined4 mountchk(void)

{
  undefined4 uVar1;
  byte bVar2;
  
  bVar2 = 0;
  do {
    uVar1 = CONCAT31((int3)((uint)bVar2 * 0x2a >> 8),(&dph)[(uint)bVar2 * 0x2a]);
    if ((&dph)[(uint)bVar2 * 0x2a] != '\0') {
      return uVar1;
    }
    bVar2 = bVar2 + 1;
  } while (bVar2 < 2);
  return uVar1;
}


// ==== edlptvol @ 01016360

/* WARNING: Removing unreachable block (ram,0x0101644a) */

void edlptvol(char param_1,char *param_2)

{
  uint uVar1;
  int iVar2;
  uint unaff_D7;
  undefined1 auStack_10 [12];
  
  iVar2 = (uint)(byte)(param_1 - 4) * 0x2a;
  if ((&dph)[iVar2] != '\0') {
    fill(auStack_10,0xc,0x20);
    strlen(param_2);
    if ((byte)unaff_D7 < 0xd) {
      uVar1 = unaff_D7 & 0xff;
    }
    else {
      uVar1 = 0xc;
    }
    cpybuf(param_2,auStack_10,uVar1);
    blkread(param_1,workbuf,1,1);
    if (unaff_D7 == 0) {
      cpybuf(auStack_10,workbuf + 0x1d8,0xc);
      cpybuf(auStack_10,iVar2 + 0x1042b46,0xc);
      blkwrite(param_1,workbuf,1,1);
    }
  }
  return;
}


// ==== edlremai @ 0101645c

undefined1 edlremai(char param_1)

{
  return (&dph)[(uint)(byte)(param_1 - 4) * 0x2a];
}


// ==== edlrenam @ 01016494

/* WARNING: Removing unreachable block (ram,0x01016594) */
/* WARNING: Removing unreachable block (ram,0x010165d6) */
/* WARNING: Removing unreachable block (ram,0x010165e4) */
/* WARNING: Removing unreachable block (ram,0x010165ee) */
/* WARNING: Removing unreachable block (ram,0x0101660e) */
/* WARNING: Removing unreachable block (ram,0x01016614) */
/* WARNING: Removing unreachable block (ram,0x01016638) */
/* WARNING: Removing unreachable block (ram,0x01016648) */
/* WARNING: Removing unreachable block (ram,0x0101668c) */
/* WARNING: Removing unreachable block (ram,0x010166a6) */
/* WARNING: Removing unreachable block (ram,0x010166b0) */
/* WARNING: Removing unreachable block (ram,0x010166d4) */
/* WARNING: Removing unreachable block (ram,0x010166ee) */

void edlrenam(char param_1,undefined4 param_2,undefined4 param_3)

{
  int unaff_D7;
  undefined1 local_29;
  undefined1 local_28 [2];
  undefined1 auStack_26 [2];
  undefined1 auStack_24 [10];
  undefined1 auStack_1a [10];
  undefined1 auStack_10 [6];
  undefined1 auStack_a [6];
  
  if (((&dph)[(uint)(byte)(param_1 - 4) * 0x2a] != '\0') &&
     (namset(param_2,auStack_1a), unaff_D7 == 0)) {
    fasc_rdx(auStack_1a,auStack_a);
    namset(param_3,auStack_24);
    fasc_rdx(auStack_24,auStack_10);
    chk_open(param_1,auStack_1a);
    srh_fnam(param_1,auStack_a,auStack_26,local_28,&local_29);
  }
  return;
}


// ==== edlresum @ 01016740

/* WARNING: Removing unreachable block (ram,0x01016892) */
/* WARNING: Removing unreachable block (ram,0x010168d6) */
/* WARNING: Removing unreachable block (ram,0x010168f0) */
/* WARNING: Removing unreachable block (ram,0x010168fa) */
/* WARNING: Removing unreachable block (ram,0x0101691e) */
/* WARNING: Removing unreachable block (ram,0x01016938) */

void edlresum(char param_1,undefined2 param_2)

{
  undefined2 *puVar1;
  int iVar2;
  int iVar3;
  int unaff_D7;
  undefined1 local_17;
  undefined1 local_16 [2];
  undefined1 auStack_14 [2];
  short local_12;
  byte local_f;
  ushort local_e;
  undefined1 auStack_c [2];
  undefined1 auStack_a [6];
  
  iVar2 = (uint)(byte)(param_1 - 4U) * 0x2a;
  if ((&dph)[iVar2] != '\0') {
    if ((byte)(param_1 - 4U) == 0) {
      iVar3 = d0_buf;
    }
    else {
      iVar3 = d1_buf;
    }
    srh_seri(param_1,param_2,auStack_c,&local_e,&local_f);
    if (unaff_D7 == 0) {
      puVar1 = (undefined2 *)
               ((uint)local_f * 0x400 + iVar3 + 10 +
               (uint)*(ushort *)(&DAT_01042b3a + iVar2) * (local_e - 1));
      mvshort(*puVar1,&local_12);
      if (local_12 == 0x200) {
        if (4 < *(ushort *)(&DAT_01042b58 + iVar2)) {
          segcopy(param_1,local_f,4);
          local_f = 4;
        }
        cpyword(puVar1 + 1,auStack_a,3);
        srh_fnam(param_1,auStack_a,auStack_14,local_16,&local_17);
      }
    }
  }
  return;
}


// ==== edl_rxb @ 01016984

void edl_rxb(undefined1 param_1,undefined2 param_2,undefined2 param_3,undefined2 param_4,
            undefined4 param_5)

{
  rw_ent(param_1,param_2,param_3,param_4,param_5,0);
  return;
}


// ==== edl_wxb @ 010169d6

void edl_wxb(undefined1 param_1,undefined2 param_2,undefined2 param_3,undefined2 param_4,
            undefined4 param_5)

{
  rw_ent(param_1,param_2,param_3,param_4,param_5,1);
  return;
}


// ==== edl_dire @ 01016a2a

void edl_dire(undefined1 param_1,undefined2 param_2,undefined2 param_3,undefined4 param_4)

{
  rw_ent(param_1,param_2,param_3,0,param_4,2);
  return;
}


// ==== rw_ent @ 01016a72

/* WARNING: Removing unreachable block (ram,0x01016c4a) */

void rw_ent(char param_1,ushort param_2,ushort param_3,ushort param_4,int param_5,char param_6)

{
  int iVar1;
  byte bVar2;
  int iVar3;
  int iVar4;
  int unaff_D7;
  int unaff_A4;
  int unaff_A5;
  int iVar5;
  ushort local_1e;
  int local_18;
  byte local_9;
  ushort local_8;
  undefined1 auStack_6 [2];
  
  bVar2 = param_1 - 4;
  iVar4 = (uint)bVar2 * 0x2a;
  if ((&dph)[iVar4] != '\0') {
    if (bVar2 == 0) {
      local_18 = d0_buf;
    }
    else {
      local_18 = d1_buf;
    }
    iVar3 = segtbl + (uint)bVar2 * 0x14;
    if (((param_6 != '\0') && (param_6 != '\x01')) ||
       ((*(short *)(&DAT_01042b5a + iVar4) != 0 && (param_4 <= *(ushort *)(&DAT_01042b5a + iVar4))))
       ) {
      if (param_2 == 0) {
        param_2 = 1;
        local_1e = 10000;
      }
      else {
        local_1e = param_3;
      }
      srh_seri(param_1,param_2,auStack_6,&local_8,&local_9);
      if ((unaff_D7 != -3) && (unaff_D7 == 0)) {
        iVar5 = param_5;
        if ((param_6 != '\0') && (iVar5 = unaff_A5, param_6 == '\x02')) {
          unaff_A4 = param_5;
        }
        while( true ) {
          iVar1 = (uint)local_9 * 0x400 + local_18 + 10 +
                  (uint)*(ushort *)(&DAT_01042b3a + iVar4) * (local_8 - 1);
          if (param_6 == '\0') {
            cpydata(iVar1 + 0xe,iVar5,(uint)param_4);
            iVar5 = (uint)param_4 + iVar5;
          }
          else if (param_6 == '\x01') {
            cpydata(param_5,iVar1 + 0xe,param_4);
            *(undefined2 *)(iVar3 + 10 + (uint)local_9 * 2) = 1;
          }
          else {
            cpyword(iVar1,unaff_A4,7);
            unaff_A4 = unaff_A4 + 0x10;
          }
          param_2 = param_2 + 1;
          if (local_1e < param_2) break;
          next_ent(param_1,auStack_6,&local_8,&local_9);
        }
      }
    }
  }
  return;
}


// ==== edlrwsct @ 01016c58

uint edlrwsct(int param_1,int param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5,
             int param_6)

{
  uint uVar1;
  uint unaff_D7;
  undefined4 local_c;
  undefined1 local_8;
  undefined1 local_7;
  undefined1 local_6;
  
  if ((&DAT_01042a8c)[param_1 * 0x2a] != '\x01') {
    rqfdslct(param_1);
    if ((unaff_D7 & 0xc9) != 0) {
      return unaff_D7 & 0xc9;
    }
  }
  if (param_2 != 0) {
    local_8 = (undefined1)(((param_2 + -1) * 6 + 1) % 0x1a);
    local_7 = 2;
    local_6 = 1;
    uVar1 = rqfdsilv(param_1,&local_8,&local_c);
    if (unaff_D7 != 0) {
      return uVar1;
    }
  }
  if (param_6 == 1) {
    rqfdscrd(param_1,param_2,0,param_3,param_4,param_5,&local_c);
  }
  else {
    rqfdscwr(param_1,param_2,0,param_3,param_4,param_5,&local_c);
  }
  if ((&DAT_01042a8c)[param_1 * 0x2a] == '\x01') {
    uVar1 = 1;
    if (param_6 != 1) {
      uVar1 = fre_proc(param_1,1);
    }
  }
  else {
    uVar1 = rqfdrels(param_1,local_c);
  }
  return uVar1;
}


// ==== edlsghdr @ 01016d6c

undefined1 edlsghdr(char param_1,undefined4 param_2)

{
  undefined1 uVar1;
  int iVar2;
  
  iVar2 = (uint)(byte)(param_1 - 4) * 0x2a;
  if ((&dph)[iVar2] == '\0') {
    uVar1 = 0;
  }
  else {
    uVar1 = cpybuf(&DAT_01042b54 + iVar2,param_2,10);
  }
  return uVar1;
}


// ==== edlvolcp @ 01016dbc

/* WARNING: Removing unreachable block (ram,0x01016f08) */
/* WARNING: Removing unreachable block (ram,0x01016ed0) */
/* WARNING: Removing unreachable block (ram,0x01016e94) */

undefined4 edlvolcp(int param_1,int param_2)

{
  char cVar1;
  undefined3 uVar2;
  undefined4 uVar3;
  int iVar4;
  int iVar5;
  undefined *unaff_D7;
  int iVar6;
  undefined *puVar7;
  undefined1 auStack_c [4];
  undefined1 local_8;
  undefined1 local_7;
  undefined1 local_6;
  
  local_8 = 1;
  local_7 = 2;
  local_6 = 1;
  uVar2 = (undefined3)((uint)(param_2 * 0x2a) >> 8);
  uVar3 = CONCAT31(uVar2,(&DAT_01042a8c)[param_1 * 0x2a]);
  if (((&DAT_01042a8c)[param_1 * 0x2a] != '\0') &&
     (cVar1 = (&DAT_01042a8c)[param_2 * 0x2a], uVar3 = CONCAT31(uVar2,cVar1), cVar1 != '\0')) {
    malloc(0x400);
    if (unaff_D7 == (undefined *)0x0) {
      iVar6 = 1;
      puVar7 = &bufofrw;
    }
    else {
      iVar6 = 0x1a;
      puVar7 = unaff_D7;
    }
    (&DAT_01042a8c)[param_2 * 0x2a] = '\0';
    rqfdsilv(param_1,&local_8,auStack_c);
    edl_echk();
    if (unaff_D7 == (undefined *)0x0) {
      rqfdsilv(param_2,&local_8,auStack_c);
      edl_echk();
      iVar5 = 0;
      do {
        iVar4 = 0;
        do {
          rqfdscrd(param_1,iVar5,0,iVar4,iVar6,puVar7,auStack_c);
          edl_echk();
          rqfdscwr(param_2,iVar5,0,iVar4,iVar6,puVar7,auStack_c);
          edl_echk();
          if (iVar6 == 0x1a) break;
          iVar4 = iVar4 + 1;
        } while (iVar4 < 0x1a);
        iVar5 = iVar5 + 1;
      } while (iVar5 < 0x4d);
    }
    freelm(puVar7);
    uVar3 = fre_proc(param_2,0);
  }
  return uVar3;
}


// ==== edlwrite @ 01016f5c

void edlwrite(short param_1,ushort param_2,int param_3)

{
  int iVar1;
  undefined1 uVar2;
  ushort uVar3;
  int iVar4;
  int unaff_D7;
  int local_c;
  
  iVar4 = param_1 * 0x26;
  uVar2 = (&fcb)[iVar4];
  if (((&DAT_01042b8a)[iVar4] != '\0') &&
     (*(short *)(&DAT_01042b94 + iVar4) != *(short *)(&DAT_01042ba0 + iVar4))) {
    local_c = param_3;
    iVar1 = *(int *)(&DAT_01042baa + iVar4);
    do {
      if ((int)(uint)param_2 < (int)(0x200 - (uint)*(ushort *)(&DAT_01042ba2 + iVar4))) {
        if (param_2 == 0) {
          return;
        }
        if (*(short *)(&DAT_01042b9a + iVar4) == -1) {
          *(undefined2 *)(&DAT_01042b9a + iVar4) = *(undefined2 *)(&DAT_01042b98 + iVar4);
        }
        if (*(short *)(&DAT_01042ba2 + iVar4) == 0) {
          fill(iVar1,0x200,0);
        }
        cpybuf(local_c,iVar1 + (uint)*(ushort *)(&DAT_01042ba2 + iVar4),param_2);
        *(ushort *)(&DAT_01042ba2 + iVar4) = param_2 + *(short *)(&DAT_01042ba2 + iVar4);
        if (*(short *)(&DAT_01042ba4 + iVar4) != *(short *)(&DAT_01042ba0 + iVar4)) {
          return;
        }
        if (*(ushort *)(&DAT_01042ba6 + iVar4) < *(ushort *)(&DAT_01042ba2 + iVar4)) {
          *(undefined2 *)(&DAT_01042ba6 + iVar4) = *(undefined2 *)(&DAT_01042ba2 + iVar4);
          return;
        }
        return;
      }
      if (*(short *)(&DAT_01042b9a + iVar4) == -1) {
        *(undefined2 *)(&DAT_01042b9a + iVar4) = *(undefined2 *)(&DAT_01042b98 + iVar4);
      }
      uVar3 = 0x200 - *(short *)(&DAT_01042ba2 + iVar4);
      if (uVar3 < 0x200) {
        if (*(short *)(&DAT_01042ba2 + iVar4) == 0) {
          fill(iVar1,0x200,0);
        }
        cpybuf(local_c,iVar1 + (uint)*(ushort *)(&DAT_01042ba2 + iVar4),uVar3);
        blkwrite(uVar2,iVar1,*(undefined2 *)(&DAT_01042b9a + iVar4),1);
      }
      else {
        blkwrite(uVar2,local_c,*(undefined2 *)(&DAT_01042b9a + iVar4),1);
      }
      if (unaff_D7 != 0) {
        return;
      }
      local_c = (uint)uVar3 + local_c;
      param_2 = param_2 - uVar3;
      *(short *)(&DAT_01042b9a + iVar4) = *(short *)(&DAT_01042b9a + iVar4) + 1;
      *(short *)(&DAT_01042ba0 + iVar4) = *(short *)(&DAT_01042ba0 + iVar4) + 1;
      *(undefined2 *)(&DAT_01042ba2 + iVar4) = 0;
      if (*(ushort *)(&DAT_01042ba4 + iVar4) < *(ushort *)(&DAT_01042ba0 + iVar4)) {
        *(short *)(&DAT_01042ba4 + iVar4) = *(short *)(&DAT_01042ba4 + iVar4) + 1;
        *(undefined2 *)(&DAT_01042ba6 + iVar4) = *(undefined2 *)(&DAT_01042ba2 + iVar4);
      }
    } while (*(short *)(&DAT_01042b94 + iVar4) != *(short *)(&DAT_01042ba0 + iVar4));
  }
  return;
}


// ==== inieepdv @ 01017148

void inieepdv(undefined4 param_1)

{
  DAT_010436d0 = (undefined1)param_1;
  eepwk = 0x49;
  iodone(param_1);
  return;
}


// ==== eepdev @ 0101716e

void eepdev(void)

{
  uint uVar1;
  uint *unaff_D7;
  
  _mskon();
  uVar1 = eep_start;
  eep_start = 0;
  _mskoff();
  if ((uVar1 & 1) != 0) {
    wr_epcel();
    goto LAB_01017258;
  }
  dremsg(DAT_010436d0,&eepmsg);
  if (-1 < (int)unaff_D7) {
    s_ltopa(DAT_010436d8,DAT_010436e8);
    DAT_010436e8 = unaff_D7;
    s_ltopa(DAT_010436d8,DAT_010436de);
    DAT_010436de = unaff_D7;
    if (DAT_010436e6 == 'R') {
      rd_epall();
      goto LAB_01017258;
    }
    if (DAT_010436e6 == 'W') {
      wr_epall();
      goto LAB_01017258;
    }
  }
  unaff_D7 = (uint *)0x55;
LAB_01017258:
  if ((unaff_D7 != (uint *)0x55) && (eepwk = unaff_D7, unaff_D7 == (uint *)0x49)) {
    *DAT_010436e8 = (uint)DAT_010436d4;
    post(DAT_010436d8,0x200);
    iodone(DAT_010436d0);
  }
  return;
}


// ==== rd_epall @ 010172aa

void rd_epall(undefined1 *param_1,ushort param_2,ushort param_3)

{
  int iVar1;
  undefined1 *puVar2;
  
  if (0x7ff < param_2) {
    param_2 = 0x800;
  }
  puVar2 = (undefined1 *)(param_2 + 0xf00a000);
  iVar1 = param_2 - 0x800;
  DAT_010436d4 = param_3;
  if (-(uint)param_3 == iVar1 || -iVar1 < (int)(uint)param_3) {
    param_3 = 0x800 - param_2;
    DAT_010436d4 = param_3;
  }
  for (; param_3 != 0; param_3 = param_3 - 1) {
    *param_1 = *puVar2;
    iVar1 = 0;
    do {
      iVar1 = iVar1 + 1;
    } while (iVar1 < 100);
    puVar2 = puVar2 + 1;
    param_1 = param_1 + 1;
  }
  return;
}


// ==== wr_epall @ 01017318

void wr_epall(undefined4 param_1,undefined2 param_2,undefined2 param_3)

{
  undefined2 unaff_D7w;
  
  iniepwr(param_1,param_2,param_3);
  DAT_010436d4 = unaff_D7w;
  wr_epcel();
  return;
}


// ==== iniepwr @ 01017348

void iniepwr(undefined4 param_1,ushort param_2,ushort param_3)

{
  if (0x7ff < param_2) {
    param_2 = 0x800;
  }
  DAT_010436d1 = 0;
  if (-(uint)param_3 == param_2 - 0x800 || (int)-(param_2 - 0x800) < (int)(uint)param_3) {
    param_3 = 0x800 - param_2;
  }
  DAT_010436d2 = param_3;
  DAT_010436cc = param_2 + 0xf00a000;
  DAT_010436c8 = param_1;
  return;
}


// ==== wr_epcel @ 010173b0

undefined4 wr_epcel(void)

{
  undefined4 uVar1;
  
  if (eepwk == 0x53) {
    if ((DAT_010436d1 < 2) || (*DAT_010436c8 == *DAT_010436cc)) {
      DAT_010436cc = DAT_010436cc + 1;
      DAT_010436c8 = DAT_010436c8 + 1;
      DAT_010436d2 = DAT_010436d2 + -1;
      DAT_010436d1 = 0;
    }
    else {
      DAT_010436d1 = DAT_010436d1 + 1;
    }
  }
  if (*DAT_010436c8 == *DAT_010436cc) {
    do {
      if (DAT_010436d2 == 0) break;
      DAT_010436cc = DAT_010436cc + 1;
      DAT_010436c8 = DAT_010436c8 + 1;
      DAT_010436d2 = DAT_010436d2 + -1;
    } while (*DAT_010436c8 == *DAT_010436cc);
  }
  if (DAT_010436d2 == 0) {
    uVar1 = 0x49;
  }
  else {
    *DAT_010436cc = *DAT_010436c8;
    timer(eepwrdy,2);
    uVar1 = 0x53;
  }
  return uVar1;
}


// ==== eepwrdy @ 0101746a

void eepwrdy(void)

{
  _mskon();
  eep_start = eep_start | 1;
  _mskoff();
  dioreq(DAT_010436d0);
  return;
}


// ==== eepIndex @ 01017496

void eepIndex(void)

{
  return;
}


// ==== falloc @ 010174a8

void falloc(int param_1,int param_2)

{
  short sVar1;
  short *psVar2;
  
  if (param_1 < 0x801) {
    sVar1 = 0x10;
    psVar2 = &fio_buf;
    do {
      if (*psVar2 == 0) {
        *psVar2 = 1;
        if (param_2 == 0) {
          return;
        }
        fill(psVar2 + 1,param_1,0);
        return;
      }
      sVar1 = sVar1 + -1;
      psVar2 = psVar2 + 0x401;
    } while (sVar1 != 0);
  }
  return;
}


// ==== ffree @ 010174fc

void ffree(undefined2 *param_1)

{
  short sVar1;
  undefined2 *puVar2;
  
  if (&fio_buf < param_1) {
    sVar1 = 0x10;
    puVar2 = &fio_buf;
    do {
      if (param_1 == puVar2 + 1) {
        *puVar2 = 0;
        return;
      }
      sVar1 = sVar1 + -1;
      puVar2 = puVar2 + 0x401;
    } while (sVar1 != 0);
  }
  return;
}


// ==== fcbchk @ 01017530

int fcbchk(void)

{
  int iVar1;
  
  iVar1 = 0;
  do {
    if ((&DAT_01042b8a)[iVar1 * 0x26] == '\0') break;
    iVar1 = iVar1 + 1;
  } while (iVar1 < 4);
  if (iVar1 == 4) {
    iVar1 = -1;
  }
  return iVar1;
}


// ==== fdrestor @ 01017564

undefined8 fdrestor(int param_1,int param_2)

{
  bool bVar1;
  byte bVar3;
  undefined4 uVar2;
  undefined4 uVar4;
  uint unaff_D7;
  
  bVar1 = false;
  if ((3 < param_1) && (param_1 < 6)) {
    bVar1 = true;
  }
  if (param_2 == 0) {
    bVar3 = 0;
  }
  else {
    bVar3 = 4;
  }
  imgFDC = !bVar1 | 8U | bVar3;
  DAT_0f007000 = imgFDC;
  fdcwait();
  uVar2 = FDC_wait(0x96);
  if ((unaff_D7 & 0x40) == 0) {
    uVar4 = 0xffffffff;
  }
  else {
    uVar4 = 0xfffffffe;
  }
  uVar2 = CONCAT31((int3)((uint)uVar2 >> 8),DAT_0f007000);
  (&DAT_010442d9)[param_1 * 4] = DAT_0f007001;
  return CONCAT44(uVar2,uVar4);
}


// ==== fdtrksk @ 010175ec

void fdtrksk(int param_1,int param_2,int param_3)

{
  bool bVar1;
  char cVar2;
  byte bVar3;
  
  bVar1 = false;
  if ((3 < param_1) && (param_1 < 6)) {
    bVar1 = true;
  }
  if (param_2 < (int)((*(uint *)(param_1 * 4 + 0x10442f1) & 0x7fffffff) >> 0x18)) {
    if (param_2 < 0x2c) {
      DAT_0f00b001 = (&fddpad)[param_1 * 4] & 0x7f;
    }
    else {
      DAT_0f00b001 = (&fddpad)[param_1 * 4] | 0x80;
    }
    (&fddpad)[param_1 * 4] = DAT_0f00b001;
    piowait();
    if (param_2 < 0x3c) {
      DAT_0f00b001 = (&fddpad)[param_1 * 4] & 0xf7;
    }
    else {
      DAT_0f00b001 = (&fddpad)[param_1 * 4] | 8;
    }
    (&fddpad)[param_1 * 4] = DAT_0f00b001;
    if (param_1 != last_fdd) {
      DAT_0f007001 = (&DAT_010442d9)[param_1 * 4];
      fdcwait();
    }
    DAT_0f007003 = (undefined1)param_2;
    if (param_3 == 0) {
      bVar3 = 0xfb;
    }
    else {
      bVar3 = 0xff;
    }
    DAT_01043709 = (!bVar1 | 0x1cU) & bVar3;
    imgFDC = DAT_01043709;
    DAT_0f007000 = DAT_01043709;
    FDC_wait(0x96);
    if (param_3 == 0) {
      wait((void *)0x0);
    }
    cVar2 = DAT_0f007001;
    last_fdd = param_1;
    (&DAT_010442d9)[param_1 * 4] = DAT_0f007001;
    last_trk = (int)cVar2;
  }
  return;
}


// ==== fdrecalb @ 0101775a

void fdrecalb(undefined4 param_1)

{
  uint unaff_D7;
  
  fdrestor(param_1,1);
  if (((unaff_D7 & 0x81) == 0) && ((unaff_D7 & 0x18) != 0)) {
    fdtrksk(param_1,0x14,0);
    fdrestor(param_1,0);
  }
  return;
}


// ==== fdrtrysk @ 010177ac

uint fdrtrysk(int param_1,int param_2)

{
  char *pcVar1;
  uint3 uVar2;
  undefined4 in_D0;
  uint uVar3;
  undefined4 uVar4;
  short sVar5;
  uint unaff_D7;
  
  pcVar1 = &DAT_010442db + param_1 * 4;
  uVar2 = (uint3)((uint)in_D0 >> 8);
  if ((((*pcVar1 != '\x01') ||
       ((uVar3 = CONCAT31(uVar2,imgFDC) & 0xfffffff0, (byte)uVar3 < 0x61 &&
        (uVar3 = (uint)uVar2 << 8, (DAT_0f007000 & 0x99) != 0)))) ||
      ((uVar3 = CONCAT31((int3)(uVar3 >> 8),imgFDC) & 0xffffffc0, (char)uVar3 == -0x80 &&
       (uVar3 = CONCAT31((int3)(uVar3 >> 8),DAT_0f007000) & 0xffffff3e, (DAT_0f007000 & 0x3e) != 0))
      )) || ((param_1 != last_fdd || (param_2 != last_trk)))) {
    sVar5 = 0;
    do {
      fdtrksk(param_1,param_2,1);
      if ((unaff_D7 & 0x81) != 0) {
        return unaff_D7 & 0x81;
      }
      if ((unaff_D7 & 0x10000000) != 0) {
        return 0;
      }
      if ((unaff_D7 & 0x18) == 0) {
        return 0;
      }
      if (*pcVar1 == '\0') {
        uVar4 = fdrecalb(param_1);
        unaff_D7 = unaff_D7 & 0x81;
        uVar3 = CONCAT31((int3)((uint)uVar4 >> 8),-(unaff_D7 == 0)) & 0xffffff01;
        *pcVar1 = (char)uVar3;
      }
      else {
        uVar3 = fdrestor(param_1,0);
      }
      sVar5 = sVar5 + 1;
    } while (sVar5 < 3);
  }
  return uVar3;
}


// ==== fdsector @ 01017884

uint fdsector(int param_1,int param_2,undefined4 param_3,int param_4,undefined1 param_5,byte param_6
             ,undefined4 param_7)

{
  byte bVar2;
  uint uVar1;
  byte bVar3;
  uint unaff_D7;
  
  if (param_1 == 0x20) {
    bVar3 = 0x82;
  }
  else if (param_1 == 0x21) {
    bVar3 = 0xa2;
  }
  else if (param_1 == 0x22) {
    bVar3 = 0xa3;
  }
  else {
    bVar3 = 0;
  }
  fdrtrysk(param_2,param_3);
  uVar1 = unaff_D7 & 0x10000099;
  if (uVar1 == 0) {
    setfdsid(param_2,param_4);
    if (param_4 == 0) {
      bVar2 = 0;
    }
    else {
      bVar2 = 8;
    }
    i_sctct = 0;
    i_hwmny = param_6;
    if ((bVar3 & 0xe0) == 0x80) {
      i_dmadir = 4;
    }
    else {
      i_dmadir = 8;
    }
    i_pbuf = param_7;
    dmacreq = param_7;
    uVar1 = 0x80 << ((*(uint *)(&fdcnfg + param_2 * 4) & 0x3fffffff) >> 0x1c);
    i_xct = (undefined2)uVar1;
    DAT_010436f4 = uVar1 & 0xffff;
    i_lvidx = param_5;
    i_pilv = &ileavtbl + param_2 * 0x20;
    if (param_6 != 0) {
      do {
        fdrwd1s(bVar2 | bVar3,param_2,param_3,&dmacreq);
        if ((unaff_D7 & 0xff99) != 0) {
          return unaff_D7 & 0xff99;
        }
        uVar1 = 0;
      } while (i_sctct < i_hwmny);
    }
  }
  return uVar1;
}


// ==== fdrwd1s @ 010179de

undefined8 fdrwd1s(undefined1 param_1,undefined4 param_2,undefined4 param_3,undefined4 *param_4)

{
  uint uVar1;
  short sVar2;
  uint unaff_D7;
  uint uVar3;
  
  sVar2 = 0;
  uVar3 = 0;
  do {
    _fdrwd1s(param_1,param_4);
    uVar1 = unaff_D7 & 0x81;
    if ((uVar1 != 0) || (uVar1 = 0, (unaff_D7 & 0x7e) == 0)) break;
    fdrtrysk(param_2,param_3);
    uVar1 = unaff_D7 & 0x81;
    uVar3 = unaff_D7;
    if (uVar1 != 0) break;
    *param_4 = i_pbuf;
    sVar2 = sVar2 + 1;
  } while (sVar2 < 3);
  return CONCAT44(uVar1,uVar3);
}


// ==== _fdrwd1s @ 01017a56

undefined8 _fdrwd1s(byte param_1,undefined4 *param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  uint unaff_D7;
  
  dcon_off();
  dmahset(3,*param_2,param_2[2]);
  if ((param_1 & 0xe0) == 0x80) {
    dmod_read();
  }
  else {
    dmod_writ();
  }
  dmsk_rst(8);
  dcon_on();
  DAT_0f007002 = *(undefined1 *)(i_pilv + (uint)i_lvidx);
  imgFDC = param_1;
  DAT_0f007000 = param_1;
  fdcwait();
  uVar1 = FDC_wait((uint)i_hwmny * 0x78);
  if ((unaff_D7 & 0x40) == 0) {
    uVar2 = 0xffffffff;
  }
  else {
    uVar2 = 0xfffffffe;
  }
  return CONCAT44(CONCAT31((int3)((uint)uVar1 >> 8),DAT_0f007000),uVar2);
}


// ==== fdirq @ 01017b0e

void fdirq(void)

{
  byte bVar1;
  int iVar2;
  
  bVar1 = imgFDC;
  if ((((imgFDC & 0xc0) == 0x80) && (DAT_0f007000 == 0)) &&
     (i_sctct = i_sctct + 1, i_sctct < i_hwmny)) {
    fdcwait();
    i_lvidx = i_lvidx + 1;
    DAT_0f007002 = *(undefined1 *)(i_pilv + (uint)i_lvidx);
    i_pbuf = (uint)i_xct + i_pbuf;
    dcon_off();
    dmahset(3,i_pbuf,i_xct);
  }
  else {
    if ((DAT_0f007000 & 0x81) != 0) {
      iVar2 = 0;
      do {
        fdcwait();
        if ((DAT_0f007000 & 0x81) == 0) break;
        iVar2 = iVar2 + 1;
      } while (iVar2 < 0x10000);
    }
    fdcwait();
    if ((((DAT_0f007000 & 0x81) != 0) || ((bVar1 & 0xc0) != 0x80)) ||
       (i_sctct = i_sctct + 1, i_hwmny <= i_sctct)) {
      post(3,0x40);
      return;
    }
    fdcwait();
    i_lvidx = i_lvidx + 1;
    DAT_0f007002 = *(undefined1 *)(i_pilv + (uint)i_lvidx);
    i_pbuf = (uint)i_xct + i_pbuf;
    dcon_off();
    dmahset(3,i_pbuf,i_xct);
  }
  if (i_dmadir == '\x04') {
    dmod_read();
  }
  else {
    dmod_writ();
  }
  dmsk_rst(8);
  dcon_on();
  DAT_0f007000 = bVar1;
  imgFDC = bVar1;
  return;
}


// ==== fdadrrd @ 01017cb8

undefined5 fdadrrd(undefined4 param_1,undefined4 param_2)

{
  undefined4 uVar1;
  uint unaff_D7;
  
  dcon_off();
  dmahset(3,param_2,6);
  dmod_read();
  dmsk_rst(8);
  dcon_on();
  imgFDC = 0xc0;
  DAT_0f007000 = 0xc0;
  fdcwait();
  FDC_wait(0x78);
  if ((unaff_D7 & 0x40) == 0) {
    uVar1 = 0xffffffff;
  }
  else {
    uVar1 = 0xfffffffe;
  }
  return CONCAT14(DAT_0f007000,uVar1);
}


// ==== fdtrkrd @ 01017d2c

void fdtrkrd(void)

{
  return;
}


// ==== fdtrkwr @ 01017d36

uint fdtrkwr(int param_1,int param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5)

{
  uint uVar1;
  uint unaff_D7;
  
  uVar1 = (*(uint *)(param_1 * 4 + 0x10442f1) & 0x7fffffff) >> 0x18;
  if (param_2 < (int)uVar1) {
    fdtrksk(param_1,param_2,0);
    uVar1 = unaff_D7 & 0x10000099;
    if (uVar1 == 0) {
      dcon_off();
      dmahset(3,param_4,param_5);
      dmod_writ();
      dmsk_rst(8);
      dcon_on();
      setfdsid(param_1,param_3);
      imgFDC = 0xf4;
      DAT_0f007000 = 0xf4;
      fdcwait();
      FDC_wait(0x78);
      uVar1 = (uint)DAT_0f007000;
    }
  }
  return uVar1;
}


// ==== isufd @ 01017dfc

undefined4 isufd(int param_1)

{
  undefined4 uVar1;
  
  uVar1 = 0;
  if ((-1 < param_1) && (param_1 < 4)) {
    uVar1 = 1;
  }
  return uVar1;
}


// ==== is8fd @ 01017e18

undefined4 is8fd(int param_1)

{
  undefined4 uVar1;
  
  uVar1 = 0;
  if ((3 < param_1) && (param_1 < 6)) {
    uVar1 = 1;
  }
  return uVar1;
}


// ==== FDC_wait @ 01017e36

uint FDC_wait(void)

{
  uint unaff_D7;
  
  devtrp(0,2,4);
  do {
    wait((void *)0x0);
  } while ((unaff_D7 & 0x50000040) == 0);
  return unaff_D7 & 0x50000040;
}


// ==== fddwait @ 01017e74

void fddwait(void)

{
  uint unaff_D7;
  
  timer(wtch_fdd,0x14);
  do {
    wait((void *)0x0);
  } while ((unaff_D7 & 0x50000040) == 0);
  can_time(wtch_fdd);
  return;
}


// ==== wtch_fdd @ 01017ec2

void wtch_fdd(void)

{
  if (DAT_0f007000 < '\0') {
    timer(wtch_fdd,0x14);
  }
  else {
    post(3,0x40);
  }
  return;
}


// ==== isprtctd @ 01017ef6

uint isprtctd(undefined4 param_1)

{
  uint uVar1;
  byte bVar2;
  uint unaff_D7;
  
  bVar2 = 0x80;
  is8fd(param_1);
  if (unaff_D7 == 1) {
    bVar2 = 0x90;
  }
  DAT_0f00b000 = (byte)param_1 | bVar2;
  piowait();
  fdtrksk(param_1,DAT_0f007001,0);
  if ((char)unaff_D7 < '\0') {
    uVar1 = 0xffffffff;
  }
  else {
    uVar1 = unaff_D7 & 0x40;
  }
  return uVar1;
}


// ==== drini @ 01017f5a

void drini(int param_1)

{
  short sVar1;
  byte bVar2;
  int unaff_D7;
  undefined *puVar3;
  
  bVar2 = 0x80;
  is8fd(param_1);
  if (unaff_D7 == 1) {
    bVar2 = 0x90;
  }
  DAT_0f00b000 = (byte)param_1 | bVar2;
  DAT_0f00b001 = 0xdf;
  piowait();
  (&fddpad)[param_1 * 4] = 0;
  DAT_0f00b001 = 0;
  stfdcnfg(param_1,ivfdcnfg);
  sVar1 = 0;
  puVar3 = &ileavtbl + param_1 * 0x20;
  do {
    *puVar3 = (char)sVar1;
    sVar1 = sVar1 + 1;
    puVar3 = puVar3 + 1;
  } while (sVar1 < 0x20);
  return;
}


// ==== fdreleas @ 01017fdc

void fdreleas(int param_1)

{
  byte bVar1;
  byte bVar2;
  int unaff_D7;
  
  bVar1 = (&fddpad)[param_1 * 4];
  bVar2 = 0x80;
  is8fd(param_1);
  if (unaff_D7 == 1) {
    bVar2 = 0x90;
  }
  DAT_0f00b000 = (byte)param_1 | bVar2;
  piowait();
  DAT_01043711 = bVar1;
  DAT_0f00b001 = bVar1;
  piowait();
  DAT_0f00b001 = bVar1 & 0xdb;
  (&fddpad)[param_1 * 4] = DAT_0f00b001;
  is8fd(param_1);
  if (unaff_D7 != 0) {
    bVar1 = 0x80;
    is8fd(0);
    if (unaff_D7 == 1) {
      bVar1 = 0x90;
    }
    DAT_0f00b000 = bVar1;
    piowait();
  }
  return;
}


// ==== fdselect @ 0101807c

void fdselect(int param_1)

{
  undefined4 uVar1;
  byte bVar2;
  byte bVar3;
  int unaff_D7;
  
  bVar2 = (&fddpad)[param_1 * 4];
  (&fddpad)[param_1 * 4] = bVar2 | 0x20;
  bVar3 = 0x80;
  is8fd(param_1);
  if (unaff_D7 == 1) {
    bVar3 = 0x90;
  }
  DAT_0f00b000 = (byte)param_1 | bVar3;
  isufd(param_1);
  if (unaff_D7 == 0) {
    bVar2 = bVar2 | 0x23;
  }
  else {
    fdbitrat();
    bVar2 = (byte)unaff_D7 | bVar2 & 0xfd | 0x20;
  }
  DAT_0f00b001 = bVar2 & 0xfb;
  piowait();
  DAT_01043711 = bVar2 | 4;
  DAT_0f00b001 = DAT_01043711;
  (&fddpad)[param_1 * 4] = DAT_01043711;
  isufd(param_1);
  if (unaff_D7 == 0) {
    uVar1 = 200;
  }
  else {
    uVar1 = 100;
  }
  fddwait(uVar1);
  if ((DAT_0f007000 & 0x80) != 0) {
    fdreleas(param_1);
  }
  return;
}


// ==== dvlpilvt @ 01018154

void dvlpilvt(int param_1,byte param_2,char param_3,char param_4)

{
  uint uVar1;
  bool bVar2;
  byte *pbVar3;
  byte bVar4;
  byte bVar5;
  byte bVar6;
  bool bVar7;
  byte local_7;
  
  bVar4 = -(char)((int)*(undefined4 *)(&fdcnfg + param_1 * 4) >> 0x1f);
  uVar1 = *(uint *)(&fdcnfg + param_1 * 4);
  bVar5 = (byte)((uVar1 & 0xfffffff) >> 0x17);
  bVar7 = bVar4 == 0;
  bVar2 = true;
  pbVar3 = &ileavtbl + param_1 * 0x20;
  bVar6 = param_2;
  for (; bVar4 < (byte)(bVar5 + bVar7); bVar4 = bVar4 + 1) {
    if (bVar5 < bVar6) {
      bVar6 = (byte)((uint)(int)(short)(ushort)bVar6 %
                    (uint)(int)(short)(ushort)((uVar1 & 0xfffffff) >> 0x17));
    }
    local_7 = param_2;
    if (bVar2) {
      bVar2 = false;
    }
    else if (bVar6 == param_2) {
      bVar6 = param_4 + bVar6;
      local_7 = bVar6;
    }
    *pbVar3 = bVar6;
    bVar6 = param_3 + bVar6;
    param_2 = local_7;
    pbVar3 = pbVar3 + 1;
  }
  return;
}


// ==== setfdsid @ 010181f8

void setfdsid(int param_1,int param_2)

{
  if (param_2 == 0) {
    DAT_0f00b001 = (&fddpad)[param_1 * 4] & 0xbf;
  }
  else {
    DAT_0f00b001 = (&fddpad)[param_1 * 4] | 0x40;
  }
  (&fddpad)[param_1 * 4] = DAT_0f00b001;
  piowait();
  return;
}


// ==== set_dden @ 01018234

void set_dden(int param_1)

{
  byte bVar1;
  
  if (*(int *)(&fdcnfg + param_1 * 4) << 1 < 0) {
    bVar1 = (&fddpad)[param_1 * 4] & 0xfe;
  }
  else {
    bVar1 = (&fddpad)[param_1 * 4] | 1;
  }
  (&fddpad)[param_1 * 4] = bVar1;
  return;
}


// ==== rd_brbit @ 01018270

void rd_brbit(void)

{
  bit_rate = ~DAT_0f00a7ff & 1;
  return;
}


// ==== wr_brbit @ 0101828e

void wr_brbit(undefined4 param_1,byte param_2)

{
  eepIndex(&DAT_0f00a7ff);
  bit_rate = param_2 & 1;
  wr_eep();
  return;
}


// ==== fdstprat @ 010182da

void fdstprat(void)

{
  return;
}


// ==== fdbitrat @ 010182e4

void fdbitrat(void)

{
  return;
}


// ==== fdreset @ 010182f8

void fdreset(void)

{
  byte bVar1;
  int unaff_D7;
  
  last_fdd = 0;
  last_trk = 0x80;
  bVar1 = 0x80;
  is8fd(0);
  if (unaff_D7 == 1) {
    bVar1 = 0x90;
  }
  DAT_0f00b000 = (byte)last_fdd | bVar1;
  return;
}


// ==== fdtsk @ 0101833c

/* WARNING: Removing unreachable block (ram,0x010183b8) */

void fdtsk(void)

{
  int iVar1;
  byte bVar2;
  undefined1 uVar3;
  uint uVar4;
  uint *unaff_D7;
  undefined1 auStack_32 [2];
  undefined1 local_30;
  byte local_2a;
  byte local_29;
  uint *local_24;
  uint *local_14;
  
  iVar1 = 0;
  do {
    drini(iVar1);
    (&DAT_010442d9)[iVar1 * 4] = 0;
    clr_dchg(iVar1);
    fdselect(iVar1);
    unaff_D7 = (uint *)((uint)unaff_D7 & 0x81);
    if (unaff_D7 == (uint *)0x0) {
      fdrecalb(iVar1);
      (&DAT_010442db)[iVar1 * 4] = 1;
      fdreleas(iVar1);
    }
    else {
      (&DAT_010442db)[iVar1 * 4] = 0;
    }
    iVar1 = iVar1 + 1;
  } while (iVar1 < 6);
  fdreset();
  do {
    remsg(auStack_32);
    s_ltopa(local_30,local_24);
    local_24 = unaff_D7;
    s_ltopa(local_30,local_14);
    local_14 = unaff_D7;
    is8fd(local_29);
    if ((unaff_D7 == (uint *)0x0) || ((local_2a & 0xf0) != 0)) {
      bVar2 = 0x80;
      is8fd(local_29);
      if (unaff_D7 == (uint *)0x1) {
        bVar2 = 0x90;
      }
      uVar4 = (uint)local_29;
      DAT_0f00b000 = local_29 | bVar2;
      if (((local_2a & 0xf0) != 0) && (((&fddpad)[uVar4 * 4] & 4) != 0)) {
        uVar3 = 0x40;
        is8fd(uVar4);
        if (unaff_D7 == (uint *)0x1) {
          uVar3 = 0x60;
        }
        DAT_0f007000 = 0xfe;
        imgFDC = 0xfe;
        DAT_0f00b001 = (&fddpad)[uVar4 * 4] | 0x20;
        DAT_010442d4 = uVar3;
        DAT_010443cb = uVar3;
        DAT_0f007003 = uVar3;
        (&fddpad)[uVar4 * 4] = DAT_0f00b001;
        fddwait(0x1e);
      }
    }
    dcdfdreq(local_30,&local_2a);
    *local_14 = (uint)unaff_D7;
    post(local_30,0x40);
    DAT_0f00b001 = fddpad & 0xdf;
    fddpad = DAT_0f00b001;
  } while( true );
}


// ==== dcdfdreq @ 01018518

uint dcdfdreq(undefined4 param_1,byte *param_2)

{
  int iVar1;
  int iVar2;
  int iVar3;
  byte bVar5;
  uint uVar4;
  byte bVar6;
  uint unaff_D7;
  byte bVar7;
  uint uVar8;
  uint local_18;
  
  bVar5 = param_2[1];
  bVar6 = (&fddpad)[(uint)param_2[1] * 4];
  uVar4 = (uint)*param_2;
  bVar7 = (byte)unaff_D7;
  switch(*param_2) {
  case 0:
    uVar4 = fdreset();
    break;
  case 1:
    uVar4 = stfdcnfg(param_2[1],*(undefined4 *)(param_2 + 0xe));
    break;
  case 2:
    uVar4 = gvfdcnfg(param_2[1]);
    break;
  case 3:
    uVar4 = dchg_lgs(param_1,param_2[1]);
    break;
  case 4:
    uVar4 = dchg_ack(param_1,param_2[1]);
    break;
  case 5:
    uVar4 = isprtctd(param_2[1]);
    break;
  case 6:
    uVar4 = dvlpilvt(param_2[1],param_2[0x12],param_2[0x13],param_2[0x14]);
    break;
  case 7:
    uVar4 = fdselect(param_2[1]);
    break;
  case 8:
    uVar4 = fdreleas(param_2[1]);
    break;
  case 9:
    uVar4 = rd_brbit(param_2[1]);
    break;
  case 10:
    wr_brbit(param_2[1],*(undefined4 *)(param_2 + 10));
    uVar4 = isufd(param_2[1]);
    if (unaff_D7 == 1) {
      (&fddpad)[(uint)param_2[1] * 4] = (&fddpad)[(uint)param_2[1] * 4] & 0xfd;
      fdbitrat();
      uVar4 = (uint)param_2[1];
      (&fddpad)[uVar4 * 4] = (&fddpad)[uVar4 * 4] | 1;
    }
    break;
  default:
    break;
  case 0x10:
    if ((&DAT_010442db)[(uint)bVar5 * 4] == 0) {
      fdrecalb(param_2[1]);
      bVar6 = -((unaff_D7 & 0x81) == 0) & 1;
      uVar4 = (uint)bVar6;
      (&DAT_010442db)[(uint)bVar5 * 4] = bVar6;
    }
    else {
      uVar4 = fdrestor(param_2[1],1);
    }
    break;
  case 0x11:
    uVar4 = fdrecalb(param_2[1]);
    break;
  case 0x12:
    uVar4 = fdrtrysk(param_2[1],param_2[2]);
    break;
  case 0x20:
  case 0x21:
  case 0x22:
    fdsector(*param_2,param_2[1],param_2[2],param_2[3],param_2[4],param_2[5],
             *(undefined4 *)(param_2 + 6));
    uVar4 = 0;
    if ((((unaff_D7 & 0x7e99) != 0) && (uVar4 = isufd(param_2[1]), unaff_D7 != 0)) &&
       ((*param_2 == 0x20 || (uVar4 = unaff_D7 & 0x4040, uVar4 == 0)))) {
      bit_rate = ~bit_rate;
      wr_brbit(param_2[1],bit_rate);
      fdbitrat();
      DAT_0f00b001 = bVar7 | bVar6 & 0xfd;
      (&fddpad)[(uint)param_2[1] * 4] = DAT_0f00b001;
      uVar4 = fdsector(*param_2,param_2[1],param_2[2],param_2[3],param_2[4],param_2[5],
                       *(undefined4 *)(param_2 + 6));
    }
    break;
  case 0x30:
    uVar4 = fdadrrd(param_2[1],*(undefined4 *)(param_2 + 6));
    break;
  case 0x31:
    uVar4 = fdtrkrd(param_2[1],param_2[2],param_2[3],*(undefined4 *)(param_2 + 6),
                    *(undefined4 *)(param_2 + 10));
    break;
  case 0x32:
    uVar4 = fdtrkwr(param_2[1],param_2[2],param_2[3],*(undefined4 *)(param_2 + 6),
                    *(undefined4 *)(param_2 + 10));
    break;
  case 0x40:
  case 0x41:
    iVar1 = *(int *)(param_2 + 0x1a);
    iVar2 = *(int *)(iVar1 + 8);
    uVar8 = *(uint *)(param_2 + 0x22);
    iVar3 = *(int *)(param_2 + 0x1e);
    uVar4 = (uint)*param_2;
    if (*param_2 == 0x40) {
      *param_2 = 0x20;
    }
    else {
      *param_2 = 0x21;
    }
    for (; uVar8 != 0; uVar8 = uVar8 - param_2[5]) {
      u_sidxge(iVar2,iVar3);
      param_2[2] = (byte)(unaff_D7 >> 0x10);
      param_2[3] = (byte)(unaff_D7 >> 8);
      param_2[4] = bVar7 - (char)((int)*(undefined4 *)(iVar1 + 0x24) >> 0x1f);
      local_18 = (uint)*(ushort *)(iVar2 + 0x1c);
      if (uVar8 < local_18 - (unaff_D7 & 0xff)) {
        bVar5 = (byte)uVar8;
      }
      else {
        bVar5 = (char)*(undefined2 *)(iVar2 + 0x1c) - bVar7;
      }
      param_2[5] = bVar5;
      fdsector(*param_2,param_2[1],param_2[2],param_2[3],param_2[4],param_2[5],
               *(undefined4 *)(param_2 + 6));
      if ((((unaff_D7 & 0x7e99) != 0) && (isufd(param_2[1]), unaff_D7 != 0)) &&
         ((*param_2 == 0x20 || ((unaff_D7 & 0x4040) == 0)))) {
        bit_rate = ~bit_rate;
        wr_brbit(param_2[1],bit_rate);
        fdbitrat();
        bVar6 = bVar7 | bVar6 & 0xfd;
        (&fddpad)[(uint)param_2[1] * 4] = bVar6;
        DAT_0f00b001 = bVar6;
        fdsector(*param_2,param_2[1],param_2[2],param_2[3],param_2[4],param_2[5],
                 *(undefined4 *)(param_2 + 6));
      }
      iVar3 = (uint)param_2[5] + iVar3;
      local_18 = (uint)*(ushort *)(iVar2 + 0xc);
      uVar4 = *(int *)(param_2 + 6) + local_18 * param_2[5];
      *(uint *)(param_2 + 6) = uVar4;
    }
  }
  return uVar4;
}


// ==== gecb @ 01018b4c

void gecb(void)

{
  return;
}


// ==== getrcb @ 01018b78

void getrcb(void)

{
  return;
}


// ==== gettcb @ 01018b9c

void gettcb(void)

{
  return;
}


// ==== FUN_01018bc4 @ 01018bc4

uint FUN_01018bc4(int param_1)

{
  uint uVar1;
  
  uVar1 = param_1 * 0x10;
  if (0x7fff < uVar1) {
    uVar1 = CONCAT22((short)(uVar1 >> 0x10),0x7fff);
  }
  return uVar1;
}


// ==== setPIT @ 01018be4

void setPIT(undefined2 param_1,undefined4 param_2)

{
  undefined2 unaff_D7w;
  undefined1 *puVar1;
  
  switch(param_1) {
  case 1:
    DAT_010443cd = DAT_010443cd & 0xfe;
    puVar1 = DAT_010414bc;
    break;
  case 2:
    puVar1 = DAT_010414bc + 2;
    DAT_010443cd = DAT_010443cd & 0xfd;
    break;
  case 3:
    puVar1 = DAT_010414bc + 4;
    DAT_010443cd = DAT_010443cd & 0xfb;
    break;
  case 4:
    if (theSpfIO == (undefined1 *)0x0) {
      return;
    }
    DAT_010443cd = DAT_010443cd & 0xf7;
    puVar1 = theSpfIO;
    break;
  case 5:
    if (((DAT_0ff01fd7 & 0xf0) != 0x10) && ((DAT_0ff01fd7 & 0xf0) != 0x30)) {
      return;
    }
    if (theSpfIO == (undefined1 *)0x0) {
      return;
    }
    DAT_010443cd = DAT_010443cd & 0xef;
    puVar1 = theSpfIO + 2;
    break;
  case 6:
    if (((DAT_0ff01fd7 & 0xf0) != 0x10) && ((DAT_0ff01fd7 & 0xf0) != 0x30)) {
      return;
    }
    if (theSpfIO == (undefined1 *)0x0) {
      return;
    }
    DAT_010443cd = DAT_010443cd & 0xdf;
    puVar1 = theSpfIO + 4;
    break;
  default:
    goto switchD_01018c00_default;
  }
  FUN_01018bc4(param_2);
  *puVar1 = (char)unaff_D7w;
  *puVar1 = (char)((ushort)unaff_D7w >> 8);
switchD_01018c00_default:
  return;
}


// ==== dfltgpmd @ 01018cee

void dfltgpmd(void)

{
  DAT_010443cc = 0;
  *DAT_010414cc = 0;
  return;
}


// ==== setGPPMOD @ 01018d04

void setGPPMOD(ushort param_1,char param_2)

{
  byte abStack_b [7];
  
  abStack_b[1] = 1;
  abStack_b[2] = 2;
  abStack_b[3] = 4;
  abStack_b[4] = 8;
  abStack_b[5] = 0x10;
  abStack_b[6] = 0x20;
  if (param_2 == '\0') {
    DAT_010443cc = abStack_b[param_1] | DAT_010443cc;
  }
  else {
    DAT_010443cc = ~abStack_b[param_1] & DAT_010443cc;
  }
  *DAT_010414cc = DAT_010443cc;
  return;
}


// ==== inigp123 @ 01018d68

void inigp123(void)

{
  short sVar1;
  short sVar2;
  short sVar3;
  
  if (theSpfIO == 0) {
    sVar3 = 3;
  }
  else if (((DAT_0ff01fd7 & 0xf0) == 0x10) || ((DAT_0ff01fd7 & 0xf0) == 0x30)) {
    sVar3 = 4;
  }
  else {
    sVar3 = 6;
  }
  DAT_010443cd = 0;
  sVar1 = 0;
  do {
    *(byte *)(DAT_010414bc + 6) = (byte)sVar1 | 0x38;
    sVar1 = sVar1 + 0x40;
  } while (sVar1 < 0xc0);
  if (theSpfIO != 0) {
    if (((DAT_0ff01fd7 & 0xf0) == 0x10) || ((DAT_0ff01fd7 & 0xf0) == 0x30)) {
      sVar1 = 0x40;
    }
    else {
      sVar1 = 0xc0;
    }
    sVar2 = 0;
    if (sVar1 != 0) {
      do {
        *(byte *)(theSpfIO + 6) = (byte)sVar2 | 0x38;
        sVar2 = sVar2 + 0x40;
      } while (sVar2 < sVar1);
    }
  }
  for (sVar1 = 1; sVar1 <= sVar3; sVar1 = sVar1 + 1) {
    setGPPMOD((int)sVar1,1);
  }
  for (sVar1 = 1; sVar1 <= sVar3; sVar1 = sVar1 + 1) {
    setPIT((int)sVar1,10);
  }
  return;
}


// ==== SPF3_PIT_ @ 01018e56

void SPF3_PIT_(void)

{
  int iVar1;
  
  iVar1 = 0;
  do {
    iVar1 = iVar1 + 1;
  } while (iVar1 < 10);
  return;
}


// ==== gpi123_34 @ 01018e68

void gpi123_34(short param_1)

{
  undefined1 uVar1;
  undefined1 uVar2;
  
  uVar1 = *DAT_010414bc;
  SPF3_PIT_();
  uVar2 = *DAT_010414bc;
  SPF3_PIT_();
  if (CONCAT11(uVar2,uVar1) < 3) {
    DAT_010443cd = DAT_010443cd & 0xfe;
  }
  uVar1 = DAT_010414bc[2];
  SPF3_PIT_();
  uVar2 = DAT_010414bc[2];
  SPF3_PIT_();
  if (CONCAT11(uVar2,uVar1) < 3) {
    DAT_010443cd = DAT_010443cd & 0xfd;
  }
  uVar1 = DAT_010414bc[4];
  SPF3_PIT_();
  uVar2 = DAT_010414bc[4];
  SPF3_PIT_();
  if (CONCAT11(uVar2,uVar1) < 3) {
    DAT_010443cd = DAT_010443cd & 0xfb;
  }
  uVar1 = *theSpfIO;
  SPF3_PIT_();
  uVar2 = *theSpfIO;
  SPF3_PIT_();
  if (CONCAT11(uVar2,uVar1) < 3) {
    DAT_010443cd = DAT_010443cd & 0xf7;
  }
  DAT_010443cd = DAT_010443cd | (byte)(1 << (param_1 - 1U & 0x3f));
  DAT_0ff01e03 = DAT_010443cd;
  return;
}


// ==== gpi123 @ 01018f64

void gpi123(undefined2 param_1,undefined1 param_2,char param_3)

{
  undefined1 *puVar1;
  
  if (param_3 == '\0') {
    switch(param_1) {
    case 1:
      puVar1 = &DAT_0fff1ff9;
      break;
    case 2:
      puVar1 = &DAT_0fff1ffb;
      break;
    case 3:
      puVar1 = &DAT_0fff1ffd;
      break;
    case 4:
      if (((DAT_0ff01fd7 & 0xf0) != 0x10) && ((DAT_0ff01fd7 & 0xf0) != 0x30)) {
        return;
      }
      puVar1 = &DAT_0ff01fd1;
      break;
    default:
      goto switchD_01018f88_default;
    }
    *puVar1 = param_2;
  }
  else {
    switch(param_1) {
    case 1:
      DAT_0fff1ff9 = 1;
      break;
    case 2:
      DAT_0fff1ffb = 1;
      break;
    case 3:
      DAT_0fff1ffd = 1;
      break;
    case 4:
      if (((DAT_0ff01fd7 & 0xf0) == 0x10) || ((DAT_0ff01fd7 & 0xf0) == 0x30)) {
        DAT_0ff01fd1 = 1;
      }
    }
  }
switchD_01018f88_default:
  return;
}


// ==== spf5selec @ 01019048

void spf5selec(int param_1)

{
  if (((DAT_0ff01fd7 & 0xf0) == 0x10) || ((DAT_0ff01fd7 & 0xf0) == 0x30)) {
    if (param_1 == 0) {
      DAT_0ff01fd3 = 0;
    }
    else {
      if (param_1 != 1) {
        return;
      }
      DAT_0ff01fd3 = 8;
    }
  }
  return;
}


// ==== h_chdir @ 01019096

void h_chdir(undefined4 param_1,undefined1 param_2,undefined4 param_3)

{
  int unaff_D7;
  
  h_dph(param_2);
  if (unaff_D7 == 0) {
    unaff_D7 = -10;
  }
  else {
    h_pwlench(param_3);
    if (-1 < unaff_D7) {
      malloc(0x100);
      if (unaff_D7 == 0) {
        unaff_D7 = -0x34;
      }
      else {
        h_pwpwd();
        h_chdsub();
        if (unaff_D7 < 0) {
          h_chdsub();
          if (unaff_D7 < 0) {
            cpydata(&DAT_01019094);
            h_chdsub();
          }
        }
        mfree();
      }
    }
  }
  mkdoserr(param_2,unaff_D7);
  return;
}


// ==== h_chdsub @ 01019164

void h_chdsub(undefined4 param_1,undefined1 param_2,undefined4 param_3)

{
  bool bVar1;
  int iVar2;
  int unaff_D7;
  undefined1 auStack_10 [12];
  
  bVar1 = true;
  iVar2 = 0;
  do {
    if (iVar2 < 0) {
      return;
    }
    h_pwanap(param_3,auStack_10);
    iVar2 = unaff_D7;
    switch(unaff_D7) {
    case 1:
      h_cdrdwn(param_1,param_2,auStack_10);
      break;
    case 2:
      h_cdrup(param_1,param_2);
      break;
    case 3:
      h_cdrrt(param_1,param_2);
      break;
    case 4:
      iVar2 = 0;
    default:
      bVar1 = false;
    }
  } while (bVar1);
  return;
}


// ==== h_cdrup @ 010191fa

void h_cdrup(undefined4 param_1,undefined1 param_2)

{
  int unaff_D7;
  
  h_pwup(param_1);
  h_cdrlod(param_1,param_2);
  if (unaff_D7 < 0) {
    h_cdrrt(param_1,param_2);
  }
  return;
}


// ==== h_cdrdwn @ 0101923e

void h_cdrdwn(undefined4 param_1,undefined1 param_2,undefined4 param_3)

{
  int unaff_D7;
  
  h_cdrchk(param_1,param_3);
  if (-1 < unaff_D7) {
    h_pwdwn(param_1,param_3,(int)(short)unaff_D7);
    if (-1 < unaff_D7) {
      h_cdrlod(param_1,param_2);
      if (unaff_D7 < 0) {
        h_cdrrt(param_1,param_2);
      }
    }
  }
  return;
}


// ==== h_cdrchk @ 010192a6

int h_cdrchk(undefined4 param_1,undefined4 param_2)

{
  int unaff_D7;
  short sVar1;
  
  h_scanent(param_1,param_2,0x7e);
  sVar1 = (short)unaff_D7;
  if (-1 < sVar1) {
    h_chkent(param_1,(int)sVar1);
    if (unaff_D7 != 0) {
      return (int)sVar1;
    }
  }
  return -3;
}


// ==== h_cdrrt @ 010192ec

void h_cdrrt(undefined4 param_1,undefined1 param_2)

{
  h_pwrt(param_1);
  h_cdrlod(param_1,param_2);
  return;
}


// ==== h_cdrlod @ 0101931c

void h_cdrlod(undefined4 param_1,undefined1 param_2)

{
  int unaff_D7;
  
  h_cdrfls(param_1,param_2);
  if (-1 < unaff_D7) {
    h_cdrchg(param_1,param_2);
  }
  return;
}


// ==== h_cdrfls @ 01019356

void h_cdrfls(int param_1,undefined1 param_2)

{
  byte bVar1;
  int unaff_D7;
  
  bVar1 = *(byte *)(*(int *)(param_1 + 0x24) + 6);
  if ((((bVar1 & 1) != 0) && ((char)bVar1 < '\0')) && (h_cdropn(param_1,param_2,1), -1 < unaff_D7))
  {
    h_cdrwr((int)(short)unaff_D7);
    h_cdrcls((int)(short)unaff_D7);
  }
  return;
}


// ==== h_cdropn @ 010193be

void h_cdropn(int param_1,undefined1 param_2)

{
  int unaff_D7;
  
  h_nwfcb(param_2,(int)*(char *)(param_1 + 0x32));
  if (unaff_D7 != 0) {
    h_setfcb();
    h_pwfent(param_1);
    h_opnfent();
    if ((short)unaff_D7 < 0) {
      h_zapfcb();
    }
  }
  return;
}


// ==== h_opnfent @ 0101942e

void h_opnfent(int param_1,short param_2)

{
  int unaff_D7;
  
  h_skdir(*(undefined4 *)(param_1 + 4),(int)param_2);
  if ((unaff_D7 != 0) && (h_opnfcb(param_1), -1 < unaff_D7)) {
    h_fcbqin(param_1);
  }
  return;
}


// ==== h_cdrwr @ 01019490

void h_cdrwr(short param_1)

{
  undefined2 *puVar1;
  undefined2 uVar2;
  uint unaff_D7;
  
  h_fcb((int)param_1);
  if (unaff_D7 != 0) {
    puVar1 = *(undefined2 **)(*(int *)(unaff_D7 + 4) + 0x24);
    h_wrsub();
    if (-1 < (int)unaff_D7) {
      *puVar1 = *(undefined2 *)(unaff_D7 + 0x1e);
      uVar2 = (undefined2)(unaff_D7 >> 1);
      puVar1[4] = uVar2;
      puVar1[6] = uVar2;
      puVar1[5] = 0;
      *(byte *)(puVar1 + 3) = *(byte *)(puVar1 + 3) & 0x7f;
    }
  }
  return;
}


// ==== h_cdrcls @ 010194fe

void h_cdrcls(short param_1)

{
  int unaff_D7;
  
  h_fcb((int)param_1);
  h_clsfcb();
  if (-1 < unaff_D7) {
    h_putdir(*(undefined4 *)(unaff_D7 + 4),(int)*(char *)(unaff_D7 + 0x1b));
  }
  h_fcbqout();
  return;
}


// ==== h_cdrchg @ 0101954c

void h_cdrchg(undefined4 param_1,undefined1 param_2)

{
  int unaff_D7;
  
  h_cdropn(param_1,param_2,0);
  if (-1 < unaff_D7) {
    h_cdrrd((int)(short)unaff_D7);
    h_cdrcls((int)(short)unaff_D7);
  }
  return;
}


// ==== h_cdrrd @ 0101959a

void h_cdrrd(short param_1)

{
  undefined2 *puVar1;
  undefined2 uVar2;
  uint uVar3;
  uint unaff_D7;
  
  h_fcb((int)param_1);
  if (unaff_D7 != 0) {
    puVar1 = *(undefined2 **)(*(int *)(unaff_D7 + 4) + 0x24);
    h_rdsub();
    uVar3 = unaff_D7;
    if (unaff_D7 == 0xfffffff4) {
      uVar3 = 0;
    }
    if (-1 < (int)uVar3) {
      *puVar1 = *(undefined2 *)(unaff_D7 + 0x1e);
      uVar2 = (undefined2)(uVar3 >> 1);
      puVar1[4] = uVar2;
      puVar1[6] = uVar2;
      puVar1[5] = 0;
      *(byte *)(puVar1 + 3) = *(byte *)(puVar1 + 3) & 0x7f;
      *(byte *)(puVar1 + 3) = *(byte *)(puVar1 + 3) | 1;
    }
  }
  return;
}


// ==== h_fcb @ 01019618

void h_fcb(void)

{
  return;
}


// ==== h_fnchk @ 01019640

void h_fnchk(int param_1)

{
  int unaff_D7;
  
  h_fnck(param_1,8);
  if (-1 < unaff_D7) {
    h_fnck(param_1 + 8,3);
  }
  return;
}


// ==== h_fnck @ 0101967a

void h_fnck(char *param_1,int param_2)

{
  bool bVar1;
  int iVar2;
  int unaff_D7;
  
  bVar1 = false;
  iVar2 = 0;
  while( true ) {
    while( true ) {
      if (param_2 <= iVar2) {
        return;
      }
      iVar2 = iVar2 + 1;
      if (*param_1 != ' ') break;
      bVar1 = true;
      param_1 = param_1 + 1;
    }
    if (bVar1) break;
    h_fnlit((int)*param_1);
    param_1 = param_1 + 1;
    if (unaff_D7 == 0) {
      return;
    }
  }
  return;
}


// ==== h_fnlit @ 010196c6

void h_fnlit(void)

{
  return;
}


// ==== h_opnmod @ 01019744

undefined4 h_opnmod(short param_1)

{
  undefined4 uVar1;
  
  if (param_1 == 0x7f) {
    param_1 = 2;
  }
  if (param_1 == 0) {
    uVar1 = 1;
  }
  else {
    if (param_1 != 1) {
      if (param_1 == 2) {
        return 3;
      }
      if (param_1 != 0x4000) {
        return 0;
      }
    }
    uVar1 = 2;
  }
  return uVar1;
}


// ==== h_clrfcb @ 0101977e

void h_clrfcb(undefined4 *param_1,undefined1 param_2,undefined1 param_3)

{
  param_1[1] = 0;
  param_1[2] = 0;
  *param_1 = 0;
  *(undefined1 *)((int)param_1 + 0x1a) = 0;
  *(undefined1 *)((int)param_1 + 0x1b) = param_2;
  *(undefined1 *)(param_1 + 7) = param_3;
  *(undefined1 *)(param_1 + 3) = 0;
  *(undefined2 *)((int)param_1 + 0x1e) = 0;
  *(undefined2 *)(param_1 + 8) = 0;
  return;
}


// ==== h_nwfcb @ 010197b4

char h_nwfcb(undefined1 param_1,undefined1 param_2)

{
  int iVar1;
  char cVar2;
  undefined *puVar3;
  
  puVar3 = &h_fcbtbl;
  iVar1 = 0;
  do {
    cVar2 = puVar3[0x1b];
    if (cVar2 == '\0') break;
    puVar3 = puVar3 + 0x22;
    iVar1 = iVar1 + 1;
  } while (iVar1 < 0xc);
  if (iVar1 < 0xc) {
    h_clrfcb(puVar3,param_1,param_2);
    cVar2 = (char)iVar1;
    puVar3[0x1a] = cVar2;
  }
  return cVar2;
}


// ==== h_setfcb @ 0101980e

void h_setfcb(int param_1,undefined4 param_2,undefined4 param_3)

{
  *(undefined4 *)(param_1 + 8) = param_3;
  *(undefined4 *)(param_1 + 4) = param_2;
  return;
}


// ==== h_fcbqin @ 01019826

void h_fcbqin(undefined4 *param_1)

{
  int *piVar1;
  undefined4 *puVar2;
  
  piVar1 = (int *)param_1[1];
  puVar2 = (undefined4 *)piVar1[1];
  if (param_1 != (undefined4 *)0x0) {
    *param_1 = 0;
    if (*piVar1 == 0) {
      piVar1[1] = (int)param_1;
      *piVar1 = (int)param_1;
    }
    else {
      *puVar2 = param_1;
      piVar1[1] = (int)param_1;
    }
  }
  return;
}


// ==== h_fcbqout @ 01019852

void h_fcbqout(int *param_1)

{
  int iVar1;
  int *piVar2;
  int *piVar3;
  int *piVar4;
  int *piVar5;
  int *piVar6;
  
  piVar2 = (int *)param_1[1];
  piVar6 = (int *)0x0;
  if (((param_1 != (int *)0x0) && (piVar2 != (int *)0x0)) &&
     (piVar3 = piVar2, piVar5 = (int *)*piVar2, (int *)*piVar2 != (int *)0x0)) {
    while (piVar4 = piVar5, param_1 != piVar4) {
      piVar3 = piVar4;
      piVar6 = piVar4;
      piVar5 = (int *)*piVar4;
    }
    iVar1 = *piVar4;
    *piVar3 = iVar1;
    if (iVar1 == 0) {
      piVar2[1] = (int)piVar6;
    }
  }
  return;
}


// ==== h_mkdird @ 01019898

/* WARNING: Removing unreachable block (ram,0x010199c6) */
/* WARNING: Removing unreachable block (ram,0x010199f4) */

void h_mkdird(undefined1 param_1,undefined1 param_2,undefined4 param_3)

{
  int unaff_D7;
  int iVar1;
  int iVar2;
  
  h_dph(param_2);
  h_mapscn(*(undefined4 *)(unaff_D7 + 0x28),0,(int)*(short *)(*(int *)(unaff_D7 + 0x1c) + 10));
  if ((unaff_D7 < 0) || (h_pwlench(param_3), unaff_D7 < 0)) {
    mkdoserr(param_2);
  }
  else {
    malloc(0x100);
    iVar1 = 0;
    iVar2 = 0;
    if ((unaff_D7 == 0) ||
       ((malloc(0x100), iVar2 = unaff_D7, unaff_D7 == 0 ||
        (malloc(0x100), iVar1 = unaff_D7, unaff_D7 == 0)))) {
      mkdoserr(param_2,0xffffffcc);
    }
    else {
      h_pwdirn(param_3,unaff_D7);
      if (unaff_D7 == 1) {
        h_pwpwd();
        h_chdsub();
        h_create(param_1,param_2);
        dosstt();
        h_close(param_1,1);
        h_chdsub();
      }
      else {
        h_create(param_1,param_2);
        dosstt();
        if (-1 < unaff_D7) {
          h_close(param_1,(int)(short)unaff_D7);
        }
      }
    }
    if (unaff_D7 != 0) {
      mfree();
    }
    if (iVar2 != 0) {
      mfree(iVar2);
    }
    if (iVar1 != 0) {
      mfree(iVar1);
    }
  }
  return;
}


// ==== h_create @ 01019a8e

void h_create(undefined1 param_1,undefined1 param_2,int param_3,ushort param_4)

{
  int iVar1;
  int unaff_D7;
  
  h_dph(param_2);
  iVar1 = 0;
  if (unaff_D7 == 0) {
    iVar1 = -0x34;
    goto LAB_01019b22;
  }
  if (param_4 == 0x7f) {
LAB_01019aea:
    h_mapscn(*(undefined4 *)(unaff_D7 + 0x28),0,(int)*(short *)(*(int *)(unaff_D7 + 0x1c) + 10));
    if (unaff_D7 < 0) {
      iVar1 = -0x37;
    }
  }
  else {
    if (param_4 < 0x80) {
      if ((param_4 < 3) && (param_4 != 0)) goto LAB_01019aea;
    }
    else if (param_4 == 0x4000) {
      if (7 < *(short *)(*(int *)(unaff_D7 + 0x24) + 0x12)) {
        iVar1 = -0x36;
      }
      goto LAB_01019b22;
    }
    iVar1 = -10;
  }
LAB_01019b22:
  if (-1 < iVar1) {
    if ((((param_4 != 0x7f) && (h_fnchk(param_3), iVar1 = unaff_D7, -1 < unaff_D7)) &&
        (param_4 == 0x4000)) && (cmpbuf(param_3 + 8,&DAT_01019a8a,3), unaff_D7 == 0)) {
      iVar1 = -10;
    }
    if (-1 < iVar1) {
      h_nwfcb(param_1,param_2);
      if (unaff_D7 == 0) {
        iVar1 = -2;
      }
      else {
        h_setfcb();
        h_cresub();
        if (unaff_D7 < 0) {
          h_zapfcb();
          iVar1 = unaff_D7;
        }
        else {
          iVar1 = (int)*(char *)(unaff_D7 + 0x1a);
        }
      }
    }
  }
  mkdoserr(param_2,iVar1);
  return;
}


// ==== h_cresub @ 01019be4

void h_cresub(uint param_1,uint param_2,int param_3,ushort param_4,byte param_5)

{
  uint uVar1;
  short sVar2;
  int unaff_D7;
  uint *puVar3;
  int local_30;
  uint local_2c;
  uint local_28;
  uint local_24;
  short local_8;
  
  uVar1 = *(uint *)(param_1 + 4);
  if (param_4 == 0x7f) {
    local_24 = param_2;
    local_28 = param_1;
    local_2c = 0x1019c12;
    h_crevln();
    if (unaff_D7 < 0) {
      return;
    }
    local_24 = 0x7f;
    local_28 = param_3;
    local_2c = param_1;
    local_30 = 0x1019c2c;
    h_nwfile();
    if (-1 < unaff_D7) {
      local_24 = 0xffffffff;
      local_28 = 0;
      local_30 = 0x1019c42;
      local_2c = uVar1;
      h_fenmap();
      local_30 = -1;
      h_eenmst(param_1);
      return;
    }
    local_24 = (uint)local_8;
    puVar3 = &local_24;
  }
  else {
    local_28 = param_2;
    local_2c = param_1;
    local_30 = 0x1019c74;
    local_24 = (uint)param_4;
    h_newdir();
    if (unaff_D7 < 0) {
      return;
    }
    sVar2 = (short)unaff_D7;
    local_24 = (uint)param_5;
    local_30 = 0x1019c98;
    local_2c = uVar1;
    local_28 = (int)sVar2;
    h_lnadd();
    if (unaff_D7 < 0) {
      return;
    }
    local_28 = param_3;
    local_2c = param_1;
    local_30 = 0x1019cae;
    local_24 = (uint)param_4;
    h_nwfile();
    if (-1 < unaff_D7) {
      local_24 = 0xffffffff;
      local_30 = 0x1019cc4;
      local_2c = uVar1;
      local_28 = (int)sVar2;
      h_fenmap();
      local_30 = -1;
      h_eenmst(param_1);
      local_24 = param_1;
      local_28 = 0x1019d18;
      h_fcbqin();
      return;
    }
    if (*(short *)(param_1 + 0xe) != 0) {
      local_24 = 0;
      local_28 = param_1;
      local_2c = 0x1019cea;
      h_mapcnt();
    }
    local_24 = (uint)param_5;
    local_30 = 0x1019d02;
    local_2c = uVar1;
    local_28 = (int)sVar2;
    h_lndel();
    puVar3 = (uint *)&local_30;
    local_30 = (int)sVar2;
  }
  *(undefined4 *)((int)puVar3 + -4) = *(undefined4 *)(param_1 + 4);
  *(undefined4 *)((int)puVar3 + -8) = 0x1019d0e;
  h_ersdir();
  return;
}


// ==== h_newdir @ 01019d24

/* WARNING: Removing unreachable block (ram,0x01019d8a) */

void h_newdir(int param_1,undefined4 param_2,undefined2 param_3)

{
  int unaff_D7;
  
  h_scanent(*(undefined4 *)(param_1 + 4),param_2,param_3);
  if ((unaff_D7 < 1) && (unaff_D7 == -3)) {
    h_credir(*(undefined4 *)(param_1 + 4),param_2,param_3);
  }
  return;
}


// ==== h_credir @ 01019d9c

void h_credir(int param_1,undefined4 param_2,undefined2 param_3)

{
  int unaff_D7;
  
  h_opndir(param_1,param_3);
  if (unaff_D7 != 0) {
    cpydata(param_2);
    h_chkent(param_1,(int)*(short *)(unaff_D7 + 0x18));
    if (unaff_D7 < 1) {
      *(byte *)(*(int *)(param_1 + 8) + 4) = *(byte *)(*(int *)(param_1 + 8) + 4) | 0x80;
    }
    else {
      *(byte *)(*(int *)(param_1 + 0x20) + 4) = *(byte *)(*(int *)(param_1 + 0x20) + 4) | 0x80;
      redwat(unaff_D7 + 0x10);
    }
  }
  return;
}


// ==== h_opndir @ 01019e28

void h_opndir(int param_1,short param_2)

{
  short sVar1;
  short sVar2;
  int iVar3;
  int unaff_D7;
  
  iVar3 = *(int *)(param_1 + 0x1c);
  if (param_2 == 0x4000) {
    sVar2 = *(short *)(iVar3 + 0xc) / 8;
    if (0 < *(short *)(iVar3 + 0xc) % 8) {
      sVar2 = sVar2 + 1;
    }
    sVar1 = *(short *)(iVar3 + 0xe);
    iVar3 = *(int *)(param_1 + 0x2c) + (int)sVar2;
  }
  else {
    sVar1 = *(short *)(iVar3 + 0xc);
    iVar3 = *(int *)(param_1 + 0x2c);
  }
  h_mapscn(iVar3,1,(int)sVar1);
  if (0 < unaff_D7) {
    iVar3 = unaff_D7;
    if (param_2 == 0x4000) {
      iVar3 = unaff_D7 + 0x4000;
    }
    h_skdir(param_1,iVar3);
    if ((unaff_D7 != 0) && ((*(byte *)(unaff_D7 + 0xb) & 1) != 0)) {
      *(undefined1 *)(unaff_D7 + 0xb) = 0;
      *(undefined4 *)(unaff_D7 + 0xc) = 0;
      *(short *)(unaff_D7 + 0x18) = (short)iVar3;
      *(undefined1 *)(unaff_D7 + 0xb) = 0;
      *(undefined2 *)(unaff_D7 + 0x1c) = 0;
      *(undefined2 *)(unaff_D7 + 0x1e) = 0;
    }
  }
  return;
}


// ==== h_crevln @ 01019ee0

void h_crevln(int param_1,undefined4 param_2)

{
  int iVar1;
  int unaff_D7;
  
  h_skdir(*(undefined4 *)(param_1 + 4),0);
  h_skeeh(*(undefined4 *)(param_1 + 4),0);
  if (unaff_D7 != 0) {
    cpydata(param_2);
    *(undefined4 *)(unaff_D7 + 0xc) = 0;
    *(undefined2 *)(unaff_D7 + 0x1c) = 0;
    *(undefined2 *)(unaff_D7 + 0x1e) = 0;
    *(undefined2 *)(unaff_D7 + 0x18) = 0;
    *(undefined1 *)(unaff_D7 + 0xb) = 0x10;
    iVar1 = *(int *)(*(int *)(param_1 + 4) + 8);
    *(byte *)(iVar1 + 4) = *(byte *)(iVar1 + 4) | 0x80;
  }
  return;
}


// ==== h_nwfile @ 01019f58

void h_nwfile(int param_1,undefined4 param_2,undefined2 param_3)

{
  short unaff_D7w;
  
  h_bkcnt(*(undefined4 *)(*(int *)(param_1 + 4) + 0x1c),param_2);
  h_setmap(param_1,(int)unaff_D7w);
  if (-1 < unaff_D7w) {
    *(short *)(param_1 + 0x20) = unaff_D7w;
    *(short *)(param_1 + 0xe) = unaff_D7w;
    *(undefined4 *)(param_1 + 0x12) = 0;
    *(undefined2 *)(param_1 + 0x10) = 0;
    *(undefined4 *)(param_1 + 0x16) = 0;
    h_opnmod(param_3);
    *(char *)(param_1 + 0xc) = (char)unaff_D7w;
  }
  return;
}


// ==== h_open @ 01019fd2

void h_open(undefined1 param_1,undefined1 param_2,undefined4 param_3,short param_4)

{
  int iVar1;
  int unaff_D7;
  
  h_dph(param_2);
  iVar1 = 0;
  if (param_4 != 0x7f) {
    h_fnchk(param_3);
    iVar1 = unaff_D7;
  }
  if (-1 < iVar1) {
    h_nwfcb(param_1,param_2);
    if (unaff_D7 == 0) {
      iVar1 = -2;
    }
    else {
      h_setfcb();
      h_opnsub();
      if (unaff_D7 < 0) {
        h_zapfcb();
        iVar1 = unaff_D7;
      }
      else {
        h_fcbqin();
        iVar1 = (int)*(char *)(unaff_D7 + 0x1a);
      }
    }
  }
  mkdoserr(param_2,iVar1);
  return;
}


// ==== h_opnsub @ 0101a092

void h_opnsub(int param_1,undefined4 param_2,undefined2 param_3)

{
  undefined4 uVar1;
  int unaff_D7;
  
  uVar1 = *(undefined4 *)(param_1 + 4);
  h_scanent(uVar1,param_2,param_3);
  if (((-1 < unaff_D7) && (h_skdir(uVar1,(int)(short)unaff_D7), unaff_D7 != 0)) &&
     (h_opnfcb(param_1), -1 < unaff_D7)) {
    h_scanfcb(param_1);
  }
  return;
}


// ==== h_opnfcb @ 0101a112

void h_opnfcb(int param_1,int param_2,undefined2 param_3)

{
  int unaff_D7;
  int iVar1;
  
  *(undefined2 *)(param_1 + 0x10) = 0;
  *(undefined2 *)(param_1 + 0x20) = *(undefined2 *)(param_2 + 0x1c);
  *(undefined2 *)(param_1 + 0x1e) = *(undefined2 *)(param_2 + 0x18);
  *(undefined4 *)(param_1 + 0x12) = *(undefined4 *)(param_2 + 0xc);
  *(undefined2 *)(param_1 + 0xe) = *(undefined2 *)(param_2 + 0x1a);
  *(undefined4 *)(param_1 + 0x16) = 0;
  h_opnmod(param_3);
  *(char *)(param_1 + 0xc) = (char)unaff_D7;
  if ((*(byte *)(param_1 + 0xc) & 3) == 2) {
    *(undefined4 *)(param_2 + 0xc) = 0;
    *(undefined4 *)(param_1 + 0x12) = 0;
    *(byte *)(param_1 + 0xc) = *(byte *)(param_1 + 0xc) | 0x80;
    h_chkent(*(undefined4 *)(param_1 + 4),(int)*(short *)(param_2 + 0x18));
    if (unaff_D7 < 1) {
      iVar1 = *(int *)(*(int *)(param_1 + 4) + 8);
    }
    else {
      iVar1 = *(int *)(*(int *)(param_1 + 4) + 0x20);
    }
    *(byte *)(iVar1 + 4) = *(byte *)(iVar1 + 4) | 0x80;
  }
  return;
}


// ==== h_scanfcb @ 0101a1bc

void h_scanfcb(int param_1)

{
  undefined4 *puVar1;
  int *piVar2;
  short sVar3;
  int unaff_D7;
  
  piVar2 = *(int **)(param_1 + 4);
  puVar1 = (undefined4 *)*piVar2;
  sVar3 = *(short *)((int)puVar1 + 0x1e);
  h_skdir(piVar2,(int)*(short *)(param_1 + 0x1e));
  if (unaff_D7 != 0) {
    while (((puVar1 != (undefined4 *)0x0 && (h_skdir(piVar2,(int)sVar3), unaff_D7 != 0)) &&
           (cmpbuf(), unaff_D7 == 0))) {
      puVar1 = (undefined4 *)*puVar1;
    }
  }
  return;
}


// ==== h_close @ 0101a24a

void h_close(undefined1 param_1,short param_2)

{
  int iVar1;
  int iVar2;
  int unaff_D7;
  
  h_fcb((int)param_2);
  iVar1 = *(int *)(unaff_D7 + 4);
  iVar2 = 0;
  h_clsfcb();
  if (((unaff_D7 != -0x2e) && (unaff_D7 != -0x2d)) && (unaff_D7 != -4)) {
    h_putdir(iVar1,param_1);
    iVar2 = unaff_D7;
  }
  h_fcbqout();
  if (-1 < unaff_D7) {
    if (iVar2 == 0) {
      unaff_D7 = (int)param_2;
    }
    else {
      unaff_D7 = iVar2;
    }
  }
  mkdoserr((int)*(char *)(iVar1 + 0x32),unaff_D7);
  return;
}


// ==== h_clsfcb @ 0101a2ce

void h_clsfcb(int param_1)

{
  int unaff_D7;
  short sVar1;
  int iVar2;
  
  h_skdir(*(undefined4 *)(param_1 + 4),(int)*(short *)(param_1 + 0x1e));
  h_bkcnt(*(undefined4 *)(*(int *)(param_1 + 4) + 0x1c),*(undefined4 *)(param_1 + 0x12));
  sVar1 = (short)unaff_D7;
  if ((((*(byte *)(param_1 + 0xc) & 2) != 0) && (*(char *)(param_1 + 0xc) < '\0')) &&
     (unaff_D7 != 0)) {
    *(short *)(unaff_D7 + 0x1a) = sVar1;
    *(undefined4 *)(unaff_D7 + 0xc) = *(undefined4 *)(param_1 + 0x12);
    h_resmap(param_1,(int)sVar1);
    if (-1 < unaff_D7) {
      if (sVar1 < 0xd) {
        *(undefined2 *)(unaff_D7 + 0x1e) = *(undefined2 *)(unaff_D7 + 0x1c);
      }
      else {
        h_srhblk(param_1,sVar1 + -1);
        if (-1 < unaff_D7) {
          *(short *)(unaff_D7 + 0x1e) = sVar1;
        }
      }
    }
    redwat(unaff_D7 + 0x10);
    h_chkent(*(undefined4 *)(param_1 + 4),(int)*(short *)(unaff_D7 + 0x18));
    if (unaff_D7 < 1) {
      iVar2 = *(int *)(*(int *)(param_1 + 4) + 8);
    }
    else {
      iVar2 = *(int *)(*(int *)(param_1 + 4) + 0x20);
    }
    *(byte *)(iVar2 + 4) = *(byte *)(iVar2 + 4) | 0x80;
  }
  h_zapfcb(param_1,1);
  return;
}


// ==== h_putdir @ 0101a3be

void h_putdir(undefined4 param_1)

{
  h_exxfls(param_1);
  h_eehswp(param_1);
  h_exxfls(param_1);
  h_eehswp(param_1);
  h_sghfls(param_1);
  h_sghswp(param_1);
  h_sghfls(param_1);
  h_sghswp(param_1);
  h_drhfls(param_1);
  return;
}


// ==== h_bkord @ 0101a450

uint h_bkord(undefined4 param_1,uint param_2)

{
  uint unaff_D7;
  
  h_bkbyt(param_1,1);
  return param_2 / unaff_D7;
}


// ==== h_ftlby @ 0101a472

void h_ftlby(void)

{
  return;
}


// ==== h_ftlbk @ 0101a486

void h_ftlbk(void)

{
  return;
}


// ==== h_bknum @ 0101a49c

undefined4 h_bknum(int param_1)

{
  undefined4 uVar1;
  int unaff_D7;
  
  h_skeeh(*(undefined4 *)(param_1 + 4),(int)*(short *)(param_1 + 0x20));
  uVar1 = 0xfffffff7;
  if (unaff_D7 != 0) {
    uVar1 = CONCAT22(0xffff,*(undefined2 *)(unaff_D7 + 8 + (*(short *)(param_1 + 0x10) % 0xc) * 2));
  }
  return uVar1;
}


// ==== h_bkcnt @ 0101a4e0

uint h_bkcnt(undefined4 param_1,uint param_2)

{
  uint uVar1;
  uint unaff_D7;
  
  h_bkbyt(param_1,1);
  uVar1 = param_2 / unaff_D7;
  if (0 < (int)(param_2 % unaff_D7)) {
    uVar1 = CONCAT22((short)(uVar1 >> 0x10),(short)uVar1 + 1);
  }
  return uVar1;
}


// ==== h_eexnum @ 0101a514

short h_eexnum(int param_1,short param_2,short param_3)

{
  undefined4 uVar1;
  int iVar2;
  short sVar3;
  int unaff_D7;
  
  uVar1 = *(undefined4 *)(param_1 + 4);
  if (param_3 < 0) {
    sVar3 = -param_3;
  }
  else {
    sVar3 = param_3;
  }
  iVar2 = 0;
  do {
    if (sVar3 <= iVar2) {
      return param_2;
    }
    if ((param_2 < 0) || (h_skeeh(uVar1,(int)param_2), unaff_D7 == 0)) {
      param_2 = -9;
    }
    else {
      if (param_3 < 0) {
        param_2 = *(short *)(unaff_D7 + 4);
      }
      else {
        param_2 = *(short *)(unaff_D7 + 6);
      }
      if (param_2 < 1) {
        return -0xc;
      }
    }
    iVar2 = iVar2 + 1;
  } while( true );
}


// ==== h_dirsrch @ 0101a5d8

void h_dirsrch(undefined1 param_1)

{
  int iVar1;
  int unaff_D7;
  
  h_dph(param_1);
  iVar1 = -10;
  if (unaff_D7 != 0) {
    if (*(char *)(unaff_D7 + 0x33) < '\x01') {
      iVar1 = -4;
    }
    else {
      h_scanent();
      if (unaff_D7 < 1) {
        iVar1 = -3;
      }
      else {
        h_lncrnt();
        iVar1 = unaff_D7;
      }
    }
  }
  mkdoserr(param_1,iVar1);
  return;
}


// ==== h_lncrnt @ 0101a646

void h_lncrnt(int param_1,short param_2)

{
  short sVar1;
  int iVar2;
  int unaff_D7;
  short *psVar3;
  
  h_chkent(param_1,(int)param_2);
  if (-1 < unaff_D7) {
    sVar1 = *(short *)(*(int *)(param_1 + 0x24) + 8);
    iVar2 = 0;
    for (psVar3 = *(short **)(*(int *)(param_1 + 0x24) + 2);
        ((iVar2 < sVar1 && (h_chkent(param_1,(int)*psVar3), -1 < unaff_D7)) && (*psVar3 != param_2))
        ; psVar3 = psVar3 + 1) {
      iVar2 = iVar2 + 1;
    }
  }
  return;
}


// ==== h_direxp @ 0101a6cc

void h_direxp(undefined1 param_1,short param_2,short param_3,undefined4 param_4,ushort param_5)

{
  int iVar1;
  int iVar2;
  uint unaff_D7;
  int iVar3;
  
  h_dph(param_1);
  if ((((unaff_D7 == 0) || (param_3 < param_2)) || (param_2 < 1)) || (param_3 < 1)) {
    iVar3 = -10;
  }
  else if (*(char *)(unaff_D7 + 0x33) < '\x01') {
    iVar3 = -4;
  }
  else {
    iVar1 = (int)*(short *)(*(int *)(unaff_D7 + 0x24) + 8);
    if (iVar1 < param_2) {
      iVar3 = 0;
    }
    else {
      iVar3 = 0;
      iVar2 = 0;
      if (0 < iVar1) {
        do {
          if (((int)(short)(param_3 + -1) - (int)(short)(param_2 + -1)) + 1 <= iVar3) break;
          h_chkent();
          if ((int)unaff_D7 < 0) {
LAB_0101a7a6:
            iVar3 = -9;
            break;
          }
          if ((unaff_D7 == param_5) && ((short)(param_2 + -1) <= iVar2)) {
            h_skdir();
            if ((unaff_D7 == 0) || ((*(byte *)(unaff_D7 + 0xb) & 1) != 0)) goto LAB_0101a7a6;
            cpybuf();
            iVar3 = iVar3 + 1;
          }
          iVar2 = iVar2 + 1;
        } while (iVar2 < iVar1);
      }
    }
  }
  mkdoserr(param_1,iVar3);
  return;
}


// ==== h_delet @ 0101a7ee

void h_delet(undefined1 param_1,undefined1 param_2,undefined4 param_3)

{
  int unaff_D7;
  undefined1 auStack_26 [34];
  
  h_fnchk(param_3);
  if (-1 < unaff_D7) {
    h_dph(param_2);
    h_clrfcb(auStack_26,param_1,param_2);
    h_setfcb(auStack_26);
    h_delsub(auStack_26,param_3);
    if (-1 < unaff_D7) {
      h_putdir();
    }
  }
  mkdoserr(param_2);
  return;
}


// ==== h_delsub @ 0101a880

void h_delsub(int param_1,undefined4 param_2)

{
  int unaff_D7;
  
  h_opnsub(param_1,param_2,2);
  if ((unaff_D7 != 0) && (0 < unaff_D7)) {
    h_deldir(*(undefined4 *)(param_1 + 4));
  }
  return;
}


// ==== h_deldir @ 0101a8c2

int h_deldir(int param_1,short param_2)

{
  int iVar1;
  int unaff_D7;
  
  h_skdir(param_1,(int)param_2);
  iVar1 = -9;
  if (unaff_D7 != 0) {
    *(byte *)(unaff_D7 + 0xb) = *(byte *)(unaff_D7 + 0xb) | 0x80;
    *(byte *)(*(int *)(param_1 + 8) + 4) = *(byte *)(*(int *)(param_1 + 8) + 4) | 0x80;
    iVar1 = (int)param_2;
  }
  return iVar1;
}


// ==== h_resume @ 0101a90e

void h_resume(undefined1 param_1,undefined1 param_2,short param_3)

{
  short *psVar1;
  int unaff_D7;
  int iVar2;
  undefined1 auStack_26 [34];
  
  h_dph(param_2);
  psVar1 = (short *)(*(int *)(*(int *)(unaff_D7 + 0x24) + 2) + -2 + param_3 * 2);
  iVar2 = -10;
  if (0 < *psVar1) {
    h_clrfcb(auStack_26,param_1,param_2);
    h_setfcb(auStack_26);
    h_rsmsub(auStack_26,(int)*psVar1);
    iVar2 = unaff_D7;
    if (-1 < unaff_D7) {
      h_putdir();
      if (-1 < unaff_D7) {
        iVar2 = (int)(short)unaff_D7;
      }
    }
  }
  mkdoserr(param_2,iVar2);
  return;
}


// ==== h_rsmsub @ 0101a9b6

void h_rsmsub(int param_1,short param_2)

{
  undefined4 uVar1;
  int unaff_D7;
  undefined1 auStack_10 [12];
  
  uVar1 = *(undefined4 *)(param_1 + 4);
  h_skdir(uVar1,(int)param_2);
  if (unaff_D7 != 0) {
    cpybuf();
    h_delsub(param_1,auStack_10);
    if ((-1 < unaff_D7) || (unaff_D7 == -3)) {
      h_rsmdir(uVar1,(int)param_2);
    }
  }
  return;
}


// ==== h_rsmdir @ 0101aa36

void h_rsmdir(int param_1,short param_2)

{
  int unaff_D7;
  
  h_skdir(param_1,(int)param_2);
  if (unaff_D7 != 0) {
    *(byte *)(unaff_D7 + 0xb) = *(byte *)(unaff_D7 + 0xb) & 0x7f;
    *(byte *)(*(int *)(param_1 + 8) + 4) = *(byte *)(*(int *)(param_1 + 8) + 4) | 0x80;
  }
  return;
}


// ==== h_erdird @ 0101aa8a

/* WARNING: Removing unreachable block (ram,0x0101ab6a) */
/* WARNING: Removing unreachable block (ram,0x0101ab9a) */

void h_erdird(undefined1 param_1,undefined1 param_2,undefined4 param_3)

{
  int iVar1;
  int unaff_D7;
  int iVar2;
  int iVar3;
  
  h_dph(param_2);
  iVar1 = 0;
  iVar3 = 0;
  iVar2 = 0;
  h_pwlench(param_3);
  if ((((unaff_D7 < 0) || (malloc(0x100), iVar1 = unaff_D7, unaff_D7 == 0)) ||
      (malloc(0x100), iVar3 = unaff_D7, unaff_D7 == 0)) ||
     (malloc(0x100), iVar2 = unaff_D7, unaff_D7 == 0)) {
    mkdoserr(param_2);
    unaff_D7 = iVar1;
  }
  else {
    h_pwdirn(param_3);
    if (unaff_D7 == 1) {
      h_pwpwd(1);
      h_chdsub(1,param_1);
      h_erdsub(param_1,param_2);
      h_chdsub(1,param_1);
    }
    else {
      h_erdsub(param_1,param_2);
    }
  }
  if (unaff_D7 != 0) {
    mfree(unaff_D7);
  }
  if (iVar3 != 0) {
    mfree(iVar3);
  }
  if (iVar2 != 0) {
    mfree(iVar2);
  }
  return;
}


// ==== h_erdsub @ 0101ac0c

void h_erdsub(undefined1 param_1,undefined1 param_2,undefined4 param_3)

{
  uint unaff_D7;
  undefined4 uVar1;
  
  h_dph(param_2);
  h_scanent();
  if ((int)unaff_D7 < 0) {
    mkdoserr(param_2);
  }
  else {
    if ((unaff_D7 & 0x4000) == 0) {
      uVar1 = 0xfffffffd;
    }
    else {
      h_skdir();
      if (unaff_D7 == 0) {
        uVar1 = 0xfffffff7;
      }
      else {
        if (*(int *)(unaff_D7 + 0xc) == 0) {
          h_erase(param_1,param_2,param_3);
          return;
        }
        uVar1 = 0xffffffc7;
      }
    }
    mkdoserr(param_2,uVar1);
  }
  return;
}


// ==== h_erase @ 0101acae

void h_erase(undefined1 param_1,undefined1 param_2,undefined4 param_3)

{
  int unaff_D7;
  undefined1 auStack_26 [34];
  
  h_fnchk(param_3);
  if (-1 < unaff_D7) {
    h_dph(param_2);
    h_clrfcb(auStack_26,param_1,param_2);
    h_setfcb(auStack_26);
    h_erssub(auStack_26,param_3,param_1);
    if (-1 < unaff_D7) {
      h_putdir();
    }
  }
  mkdoserr(param_2);
  return;
}


// ==== h_erssub @ 0101ad42

void h_erssub(int param_1,undefined4 param_2,undefined1 param_3)

{
  short sVar1;
  int unaff_D7;
  int iVar2;
  
  iVar2 = *(int *)(param_1 + 4);
  h_opnsub(param_1,param_2,0x7e);
  if (-1 < unaff_D7) {
    sVar1 = (short)unaff_D7;
    h_skdir(iVar2,(int)sVar1);
    if (unaff_D7 != 0) {
      H_OpenCmn(param_3,(int)*(char *)(iVar2 + 0x32));
      dosstt();
      if (-1 < unaff_D7) {
        *(byte *)(unaff_D7 + 0xb) = *(byte *)(unaff_D7 + 0xb) | 0x80;
        h_chkent(iVar2,(int)sVar1);
        if (unaff_D7 == 0x4000) {
          iVar2 = *(int *)(iVar2 + 0x20);
        }
        else {
          iVar2 = *(int *)(iVar2 + 8);
        }
        *(byte *)(iVar2 + 4) = *(byte *)(iVar2 + 4) | 0x80;
        h_pckdir(param_1,(int)sVar1,param_3,(int)sVar1);
        h_close(param_3,(int)sVar1);
        if ((-1 < unaff_D7) && (dosstt(), unaff_D7 < 0)) {
          dosstt();
        }
      }
    }
  }
  return;
}


// ==== h_rename @ 0101ae40

void h_rename(undefined1 param_1,undefined1 param_2,undefined4 param_3,undefined4 param_4)

{
  int unaff_D7;
  undefined1 auStack_26 [34];
  
  h_fnchk(param_3);
  if (-1 < unaff_D7) {
    h_fnchk(param_4);
    if (-1 < unaff_D7) {
      h_dph(param_2);
      h_clrfcb(auStack_26,param_1,param_2);
      h_setfcb(auStack_26);
      h_rnmsub(auStack_26,param_3,param_4);
      if (-1 < unaff_D7) {
        h_putdir();
      }
    }
  }
  mkdoserr(param_2);
  return;
}


// ==== h_rnmsub @ 0101aee4

void h_rnmsub(int param_1,undefined4 param_2,undefined4 param_3)

{
  int unaff_D7;
  int iVar1;
  
  iVar1 = *(int *)(param_1 + 4);
  h_scanent(iVar1,param_3,0);
  if ((unaff_D7 < 1) && (h_opnsub(param_1,param_2,2), -1 < unaff_D7)) {
    h_skdir(iVar1,(int)(short)unaff_D7);
    if (unaff_D7 != 0) {
      cpydata(param_3);
      if ((short)unaff_D7 < 0x4001) {
        iVar1 = *(int *)(iVar1 + 8);
      }
      else {
        iVar1 = *(int *)(iVar1 + 0x20);
      }
      *(byte *)(iVar1 + 4) = *(byte *)(iVar1 + 4) | 0x80;
    }
  }
  return;
}


// ==== h_getvol @ 0101af74

void h_getvol(undefined1 param_1,undefined1 *param_2)

{
  undefined4 uVar1;
  int unaff_D7;
  
  h_dph(param_1);
  uVar1 = 0xfffffff6;
  if (unaff_D7 != 0) {
    if (*(char *)(unaff_D7 + 0x33) < '\x01') {
      uVar1 = 0xfffffffc;
    }
    else {
      h_skdir();
      if (unaff_D7 == 0) {
        uVar1 = 0xfffffff7;
      }
      else {
        uVar1 = 0xb;
        cpydata();
        param_2 = param_2 + 0xb;
      }
      *param_2 = 0;
    }
  }
  mkdoserr(param_1,uVar1);
  return;
}


// ==== h_putvol @ 0101afe6

void h_putvol(undefined4 param_1,undefined1 param_2,char *param_3)

{
  uint uVar1;
  uint uVar2;
  uint unaff_D7;
  
  h_dph(param_2);
  strlen(param_3);
  if (unaff_D7 < 0xb) {
    strlen(param_3);
    uVar1 = unaff_D7;
  }
  else {
    uVar1 = 0xb;
  }
  h_fnck(param_3,uVar1);
  uVar2 = unaff_D7;
  if (-1 < (int)unaff_D7) {
    uVar2 = 0;
    h_skdir();
    if (unaff_D7 == 0) {
      uVar2 = 0xfffffff7;
    }
    else {
      cpydata(param_3);
      fill(unaff_D7 + uVar1,0xb - uVar1,0x20);
      *(byte *)(*(int *)(unaff_D7 + 8) + 4) = *(byte *)(*(int *)(unaff_D7 + 8) + 4) | 0x80;
    }
    if (-1 < (int)uVar2) {
      redwat(unaff_D7 + 0x10);
      *(byte *)(*(int *)(unaff_D7 + 8) + 4) = *(byte *)(*(int *)(unaff_D7 + 8) + 4) | 0x80;
      h_putdir();
      uVar2 = unaff_D7;
    }
  }
  mkdoserr(param_2,uVar2);
  return;
}


// ==== h_pack @ 0101b0d8

void h_pack(undefined1 param_1,undefined1 param_2)

{
  short sVar1;
  int unaff_D7;
  undefined1 auStack_26 [34];
  
  h_dph(param_2);
  h_clrfcb(auStack_26,param_1,param_2);
  h_setfcb(auStack_26);
  malloc(0x900);
  if (unaff_D7 == 0) {
    unaff_D7 = -0x34;
  }
  else {
    H_OpenCmn(param_1,param_2);
    dosstt();
    if (-1 < unaff_D7) {
      cpydata(*(undefined4 *)(*(int *)(unaff_D7 + 0x24) + 2));
      sVar1 = *(short *)(*(int *)(unaff_D7 + 0x24) + 8);
      while ((0 < sVar1 &&
             (h_pckdir(auStack_26,(int)*(short *)(unaff_D7 + -2 + sVar1 * 2),param_1,
                       (int)(short)unaff_D7), -1 < unaff_D7))) {
        sVar1 = sVar1 + -1;
      }
      mfree();
      h_close(param_1,(int)(short)unaff_D7);
      if ((-1 < unaff_D7) && (dosstt(), unaff_D7 < 0)) {
        dosstt();
      }
    }
  }
  mkdoserr(param_2,unaff_D7);
  return;
}


// ==== h_pckdir @ 0101b23c

void h_pckdir(int param_1,short param_2,undefined1 param_3,short param_4)

{
  int iVar1;
  undefined1 uVar2;
  int unaff_D7;
  
  iVar1 = *(int *)(param_1 + 4);
  uVar2 = *(undefined1 *)(iVar1 + 0x32);
  h_skdir(iVar1,(int)param_2);
  if ((unaff_D7 != 0) && (*(char *)(unaff_D7 + 0xb) < '\0')) {
    cpydata();
    *(short *)(param_1 + 0x1e) = param_2;
    h_opnfcb(param_1);
    if (-1 < unaff_D7) {
      h_chkent(iVar1,(int)param_2);
      if (unaff_D7 != 0x4000) {
        h_rwcmnt(param_3,uVar2,(int)param_4,(int)param_2,0x28,
                 "                                        ",2);
      }
      if ((-1 < unaff_D7) && (h_mapcnt(param_1,0), -1 < unaff_D7)) {
        h_lndel(iVar1,(int)param_2,param_3);
        if (-1 < unaff_D7) {
          h_ersdir(iVar1,(int)param_2);
        }
      }
    }
  }
  return;
}


// ==== h_ersdir @ 0101b348

undefined4 h_ersdir(int param_1,short param_2)

{
  undefined1 *unaff_D7;
  int iVar1;
  
  h_chkent(param_1,(int)param_2);
  if (-1 < (int)unaff_D7) {
    if (unaff_D7 == (undefined1 *)0x4000) {
      iVar1 = *(int *)(param_1 + 0x20);
    }
    else {
      iVar1 = *(int *)(param_1 + 8);
    }
    h_skdir(param_1,(int)param_2);
    if (unaff_D7 != (undefined1 *)0x0) {
      *unaff_D7 = 0xdf;
      unaff_D7[0xb] = 1;
      *(byte *)(iVar1 + 4) = *(byte *)(iVar1 + 4) | 0x80;
      return 0;
    }
  }
  return 0xfffffff7;
}


// ==== h_fcopy @ 0101b3b8

void h_fcopy(undefined1 param_1,undefined1 param_2,undefined4 param_3,undefined1 param_4,
            undefined4 param_5)

{
  int iVar1;
  short sVar2;
  int unaff_D7;
  short local_10;
  short local_e;
  
  h_open(param_1,param_2,param_3,0);
  dosstt();
  if (-1 < unaff_D7) {
    sVar2 = (short)unaff_D7;
    h_create(param_1,param_4,param_5,1,0x800);
    dosstt();
    if (unaff_D7 == -1) {
      h_open(param_1,param_4,param_5,1);
      dosstt();
    }
    else if (-1 < unaff_D7) {
      local_e = *(short *)(&DAT_0104449a + sVar2 * 0x22);
      iVar1 = (int)sVar2;
      local_10 = *(short *)(&DAT_0104449a + iVar1 * 0x22);
      h_fcpsub(param_1,(int)sVar2,iVar1);
      dosstt();
      h_close(param_1,iVar1);
      if (((unaff_D7 == -0xc) || (-1 < unaff_D7)) && (dosstt(), 0 < unaff_D7)) {
        dosstt();
      }
    }
    h_close(param_1,(int)sVar2);
  }
  if ((unaff_D7 == -0xc) || (-1 < unaff_D7)) {
    h_copyexb(param_1,param_2,(int)local_e,(int)local_10);
    mkdoserr(param_2);
  }
  return;
}


// ==== h_fcpsub @ 0101b542

void h_fcpsub(undefined1 param_1,short param_2,short param_3)

{
  size_t __size;
  undefined1 *unaff_D7;
  undefined1 *puVar1;
  bool bVar2;
  undefined1 auStack_204 [512];
  
  puVar1 = (undefined1 *)0x0;
  h_fcb((int)param_2);
  if (*(uint *)(unaff_D7 + 0x12) < 0xc000) {
    __size = *(size_t *)(unaff_D7 + 0x12);
  }
  else {
    __size = 0xc000;
  }
  while ((0x200 < (int)__size && (malloc(__size), puVar1 = unaff_D7, unaff_D7 == (undefined1 *)0x0))
        ) {
    __size = (int)__size >> 1;
  }
  bVar2 = puVar1 != (undefined1 *)0x0;
  if (!bVar2) {
    puVar1 = auStack_204;
  }
  do {
    h_read(param_1,(int)param_2,__size,puVar1);
    dosstt();
    if ((int)unaff_D7 < 1) break;
    h_write(param_1,(int)param_3);
    dosstt();
  } while (-1 < (int)unaff_D7);
  if (bVar2) {
    mfree(puVar1);
  }
  return;
}


// ==== h_copyexb @ 0101b618

void h_copyexb(undefined1 param_1,undefined1 param_2,short param_3,short param_4)

{
  short sVar1;
  int unaff_D7;
  undefined1 auStack_2c [40];
  
  H_OpenCmn(param_1,param_2);
  dosstt();
  if (-1 < unaff_D7) {
    sVar1 = (short)unaff_D7;
    h_rwcmnt(param_1,param_2,(int)sVar1,(int)param_3,0x28,auStack_2c,1);
    if (-1 < unaff_D7) {
      h_rwcmnt(param_1,param_2,(int)sVar1,(int)param_4,0x28,auStack_2c,2);
    }
    h_close(param_1,(int)sVar1);
    if (-1 < unaff_D7) {
      dosstt();
      if (unaff_D7 < 0) {
        dosstt();
      }
    }
  }
  return;
}


// ==== hddos @ 0101b6e4

void hddos(void)

{
  int iVar1;
  int unaff_D7;
  undefined1 auStack_38 [2];
  undefined1 local_36;
  undefined1 auStack_30 [36];
  int in_stack_fffffff4;
  int in_stack_fffffff8;
  
  hdinit();
  iVar1 = 0;
  do {
    h_dph(iVar1);
    cpybuf(&h_ivdph);
    *(char *)(unaff_D7 + 0x32) = (char)iVar1;
    iVar1 = iVar1 + 1;
  } while (iVar1 < 2);
  iVar1 = 0;
  do {
    h_fcb(iVar1);
    cpybuf(&h_ivfcb);
    *(char *)(unaff_D7 + 0x1a) = (char)iVar1;
    iVar1 = iVar1 + 1;
  } while (iVar1 < 0xc);
  do {
    while( true ) {
      remsg(auStack_38);
      if (unaff_D7 < 0) break;
      s_ltopa(local_36,in_stack_fffffff4);
      s_ltopa(local_36,in_stack_fffffff8);
      dcdhddr(auStack_30,local_36);
      *(int *)unaff_D7 = unaff_D7;
      post(local_36,0x10);
      in_stack_fffffff4 = unaff_D7;
      in_stack_fffffff8 = unaff_D7;
    }
    wtmsg();
  } while( true );
}


// ==== dcdhddr @ 0101b7d8

void dcdhddr(short *param_1,undefined1 param_2)

{
  undefined1 uVar1;
  undefined4 uVar2;
  
  switch(*(undefined1 *)(param_1 + 1)) {
  case 1:
    h_mount(param_2,*(undefined1 *)((int)param_1 + 3));
    break;
  case 2:
    h_info(*(undefined1 *)((int)param_1 + 3),*(undefined4 *)(param_1 + 0x12));
    break;
  case 3:
    h_kind(*(undefined1 *)((int)param_1 + 3));
    break;
  case 4:
    h_demnt(param_2,*(undefined1 *)((int)param_1 + 3));
    break;
  default:
    uVar2 = 0xfffffff6;
    uVar1 = *(undefined1 *)((int)param_1 + 3);
    goto LAB_0101bd34;
  case 8:
    h_dirsrch(*(undefined1 *)((int)param_1 + 3),(int)param_1 + 5);
    break;
  case 9:
    h_direxp(*(undefined1 *)((int)param_1 + 3),param_1[0xe],param_1[0xf],
             *(undefined4 *)(param_1 + 0x12),0);
    break;
  case 0xb:
    h_getvol(*(undefined1 *)((int)param_1 + 3),*(undefined4 *)(param_1 + 0x12));
    break;
  case 0xc:
    h_putvol(param_2,*(undefined1 *)((int)param_1 + 3),*(undefined4 *)(param_1 + 0x12));
    break;
  case 0xd:
    h_delet(param_2,*(undefined1 *)((int)param_1 + 3),(int)param_1 + 5);
    break;
  case 0xe:
    h_resume(param_2,*(undefined1 *)((int)param_1 + 3),param_1[0xe]);
    break;
  case 0xf:
    h_dstat(param_2,*(undefined1 *)((int)param_1 + 3));
    break;
  case 0x11:
    h_open(param_2,*(undefined1 *)((int)param_1 + 3),(int)param_1 + 5,param_1[0xe]);
    break;
  case 0x12:
    h_close(param_2,(int)*param_1);
    break;
  case 0x13:
    h_create(param_2,*(undefined1 *)((int)param_1 + 3),(int)param_1 + 5,param_1[0xe],
             *(undefined4 *)(param_1 + 0x10));
    break;
  case 0x14:
    h_rename(param_2,*(undefined1 *)((int)param_1 + 3),(int)param_1 + 5,param_1 + 8);
    break;
  case 0x15:
    h_erase(param_2,*(undefined1 *)((int)param_1 + 3),(int)param_1 + 5);
    break;
  case 0x18:
    h_pack(param_2,*(undefined1 *)((int)param_1 + 3));
    break;
  case 0x19:
    h_rdexb(param_2,*(undefined1 *)((int)param_1 + 3),param_1[0xe],param_1[0xf],
            *(undefined4 *)(param_1 + 0x10),*(undefined4 *)(param_1 + 0x12));
    break;
  case 0x1a:
    h_wrexb(param_2,*(undefined1 *)((int)param_1 + 3),param_1[0xe],param_1[0xf],
            *(undefined4 *)(param_1 + 0x10),*(undefined4 *)(param_1 + 0x12));
    break;
  case 0x21:
    h_read(param_2,(int)*param_1,*(undefined4 *)(param_1 + 0x10),*(undefined4 *)(param_1 + 0x12));
    break;
  case 0x22:
    h_write(param_2,(int)*param_1,*(undefined4 *)(param_1 + 0x10),*(undefined4 *)(param_1 + 0x12));
    break;
  case 0x23:
    h_seek(param_2,(int)*param_1,param_1[0xe],*(undefined4 *)(param_1 + 0x10));
    break;
  case 0x30:
    h_initv(param_2,*(undefined1 *)((int)param_1 + 3),param_1[0xe],*(undefined4 *)(param_1 + 0x10),
            *(undefined4 *)(param_1 + 0x12));
    break;
  case 0x31:
    uVar2 = 0xfffffffc;
    uVar1 = 7;
LAB_0101bd34:
    mkdoserr(uVar1,uVar2);
    break;
  case 0x32:
    h_fcopy(param_2,*(undefined1 *)((int)param_1 + 3),(int)param_1 + 5,*(undefined1 *)(param_1 + 2),
            param_1 + 8);
    break;
  case 0x3a:
    h_remain(*(undefined1 *)((int)param_1 + 3));
    break;
  case 0x3b:
    h_reman2(*(undefined1 *)((int)param_1 + 3));
    break;
  case 0x40:
    h_dcnfg(*(undefined1 *)((int)param_1 + 3));
    break;
  case 0x41:
    h_rdsct(*(undefined1 *)((int)param_1 + 3),(int)*param_1,param_1[0xe],param_1[0xf],
            *(undefined4 *)(param_1 + 0x10),*(undefined4 *)(param_1 + 0x12));
    break;
  case 0x42:
    h_wrsct(param_2,*(undefined1 *)((int)param_1 + 3),(int)*param_1,param_1[0xe],param_1[0xf],
            *(undefined4 *)(param_1 + 0x10),*(undefined4 *)(param_1 + 0x12));
    break;
  case 0x43:
    h_mkdird(param_2,*(undefined1 *)((int)param_1 + 3),*(undefined4 *)(param_1 + 0x12));
    h_direrr();
    break;
  case 0x44:
    h_erdird(param_2,*(undefined1 *)((int)param_1 + 3),*(undefined4 *)(param_1 + 0x12));
    h_direrr();
    break;
  case 0x45:
    h_chdir(param_2,*(undefined1 *)((int)param_1 + 3),*(undefined4 *)(param_1 + 0x12));
    h_direrr();
    break;
  case 0x46:
    h_pwd(param_2,*(undefined1 *)((int)param_1 + 3),*(undefined4 *)(param_1 + 0x12));
    break;
  case 0x47:
    h_direxp(*(undefined1 *)((int)param_1 + 3),param_1[0xe],param_1[0xf],
             *(undefined4 *)(param_1 + 0x12),0x4000);
  }
  return;
}


// ==== h_direrr @ 0101bd42

void h_direrr(undefined4 param_1)

{
  uint uVar1;
  uint unaff_D7;
  
  errdrive(param_1);
  uVar1 = unaff_D7 & 0xff;
  dosstt(param_1);
  switch(unaff_D7) {
  case 0xffffffd4:
  case 0xffffffd5:
  case 0xfffffff5:
    unaff_D7 = 0xffffffc9;
    break;
  case 0xfffffffd:
    unaff_D7 = 0xffffffc8;
  }
  mkdoserr(uVar1,unaff_D7);
  return;
}


// ==== h_initfen @ 0101be04

undefined4 h_initfen(int param_1,int param_2,int param_3,int *param_4,int param_5)

{
  ushort *puVar1;
  ushort uVar2;
  short sVar3;
  undefined2 extraout_D0u;
  undefined4 uVar4;
  ushort uVar5;
  int iVar6;
  int unaff_D7;
  short *psVar7;
  int iVar8;
  
  puVar1 = *(ushort **)(param_1 + 0x1c);
  uVar2 = *puVar1;
  uVar5 = *(ushort *)(param_2 + 0x18);
  if ((uVar5 & 0x4000) != 0) {
    uVar5 = puVar1[6] + 0xc000 + uVar5;
  }
  h_maonof((int)(short)uVar5,*(undefined4 *)(param_1 + 0x2c),0xffffffff);
  uVar4 = CONCAT22(extraout_D0u,*(short *)(param_2 + 0x1a));
  if (0 < *(short *)(param_2 + 0x1a)) {
    iVar8 = (int)*(short *)(param_2 + 0x1c);
    do {
      if (((*param_4 < 0) || (iVar8 < *param_4)) ||
         ((int)((param_5 * (uint)uVar2 >> 5) + *param_4) <= iVar8)) {
        iVar6 = (uint)*(byte *)((int)puVar1 + 7) + (uint)(iVar8 << 5) / (uint)*puVar1;
        *param_4 = (uint)(*puVar1 >> 5) * (iVar6 - (uint)*(byte *)((int)puVar1 + 7));
        uVar4 = h_rwstrn(2,(int)*(char *)(param_1 + 0x32),iVar6,param_5,param_3);
        if (unaff_D7 < 0) {
          return uVar4;
        }
      }
      h_maonof(iVar8,*(undefined4 *)(param_1 + 0x28),0xffffffff);
      iVar6 = 0xc;
      psVar7 = (short *)(param_3 + 8 + (*param_4 - iVar8) * -0x20);
      while ((*psVar7 != 0 && (iVar6 = iVar6 + -1, -1 < iVar6))) {
        if (data_map == -1) {
          data_map = *psVar7;
          DAT_01046b82 = *psVar7;
        }
        else if (DAT_01046b82 + 1 == (int)*psVar7) {
          DAT_01046b82 = *psVar7;
        }
        else {
          h_mbset(param_1,(int)data_map,((int)DAT_01046b82 - (int)data_map) + 1);
          data_map = *psVar7;
          DAT_01046b82 = *psVar7;
        }
        psVar7 = psVar7 + 1;
      }
      iVar8 = (*param_4 - iVar8) * -0x20;
      sVar3 = *(short *)(param_3 + 6 + iVar8);
      uVar4 = CONCAT22((short)((uint)iVar8 >> 0x10),sVar3);
      iVar8 = (int)sVar3;
    } while (iVar8 != 0);
  }
  return uVar4;
}


// ==== h_ifent @ 0101bfa2

char * h_ifent(int param_1,char *param_2,int param_3,short param_4,int param_5,ushort param_6)

{
  ushort *puVar1;
  undefined1 uVar2;
  char *pcVar3;
  int iVar4;
  uint uVar5;
  int unaff_D7;
  char *pcVar6;
  int iVar7;
  undefined4 local_8;
  
  local_8 = 0xffffffff;
  data_map = -1;
  DAT_01046b82 = -1;
  puVar1 = *(ushort **)(param_1 + 0x1c);
  iVar4 = param_3;
  if (param_3 < 0) {
    iVar4 = param_3 + 1;
  }
  iVar4 = (iVar4 >> 1) / (int)(uint)*puVar1;
  if (param_3 < 0) {
    param_3 = param_3 + 1;
  }
  iVar7 = 0;
  pcVar3 = param_2 + (param_3 >> 1);
  while (0 < param_4) {
    pcVar3 = (char *)h_rwstrn(2,(int)*(char *)(param_1 + 0x32),
                              param_5 + (uint)(iVar7 << 5) / (uint)*puVar1,iVar4,param_2);
    if (unaff_D7 < 0) {
      return pcVar3;
    }
    pcVar3 = (char *)((uint)*puVar1 * iVar4);
    pcVar6 = param_2;
    for (uVar5 = (uint)pcVar3 >> 5; (0 < param_4 && (0 < (int)uVar5)); uVar5 = uVar5 - 1) {
      pcVar3 = (char *)(uint)param_6;
      if (param_6 != *(ushort *)(pcVar6 + 0x18)) goto LAB_0101c0c2;
      uVar2 = (undefined1)(param_6 >> 8);
      pcVar3 = (char *)(uint)CONCAT11(uVar2,*pcVar6);
      if (*pcVar6 == '\0') goto LAB_0101c0c2;
      pcVar3 = (char *)(uint)CONCAT11(uVar2,pcVar6[0xb]);
      if (((pcVar6[0xb] & 1U) == 0) &&
         (pcVar3 = (char *)h_initfen(param_1,pcVar6,param_2 + (param_3 >> 1),&local_8,iVar4),
         unaff_D7 < 0)) {
        return pcVar3;
      }
      pcVar6 = pcVar6 + 0x20;
      iVar7 = iVar7 + 1;
      param_4 = param_4 + -1;
      param_6 = param_6 + 1;
    }
  }
LAB_0101c0c2:
  if (data_map != -1) {
    pcVar3 = (char *)h_mbset(param_1,(int)data_map,((int)DAT_01046b82 - (int)data_map) + 1);
  }
  return pcVar3;
}


// ==== h_initmap @ 0101c0f2

void h_initmap(int param_1,undefined4 param_2,undefined4 param_3)

{
  uint uVar1;
  int unaff_D7;
  
  uVar1 = (uint)*(ushort *)(*(int *)(param_1 + 0x1c) + 0x10) /
          (uint)*(byte *)(*(int *)(param_1 + 0x1c) + 8);
  if ((uint)*(ushort *)(*(int *)(param_1 + 0x1c) + 0x10) %
      (uint)*(byte *)(*(int *)(param_1 + 0x1c) + 8) != 0) {
    uVar1 = uVar1 + 1;
  }
  h_mbset(param_1,0,uVar1);
  h_ifent(param_1,param_2,param_3,(int)*(short *)(*(int *)(param_1 + 0x1c) + 0xc),
          (uint)*(byte *)(*(int *)(param_1 + 0x1c) + 7) +
          (uint)((int)*(short *)(*(int *)(param_1 + 0x1c) + 10) << 5) /
          (uint)**(ushort **)(param_1 + 0x1c),0);
  if (-1 < unaff_D7) {
    h_ifent(param_1,param_2,param_3,(int)*(short *)(*(int *)(param_1 + 0x1c) + 0xe),
            (uint)((int)*(short *)(*(int *)(param_1 + 0x1c) + 10) << 5) /
            (uint)**(ushort **)(param_1 + 0x1c) + (uint)*(byte *)(*(int *)(param_1 + 0x1c) + 7) +
            (uint)((int)*(short *)(*(int *)(param_1 + 0x1c) + 0xc) << 5) /
            (uint)**(ushort **)(param_1 + 0x1c),0x4000);
  }
  return;
}


// ==== h_initv @ 0101c242

/* WARNING: Removing unreachable block (ram,0x0101c33a) */

void h_initv(undefined1 param_1,undefined1 param_2,char param_3)

{
  int iVar1;
  int unaff_D7;
  char *pcVar2;
  undefined1 auStack_28 [8];
  undefined1 auStack_20 [28];
  
  h_dph(param_2);
  iVar1 = 0;
  if (*(char *)(unaff_D7 + 0x33) < '\x01') {
    h_motor(0xb,param_2);
    iVar1 = unaff_D7;
  }
  if (-1 < iVar1) {
    h_zapall(param_2,param_1,0);
    h_dskcfg(param_2);
    if (param_3 != '\0') {
      if (unaff_D7 == 0) {
        iVar1 = -10;
      }
      else {
        h_format(param_2);
        iVar1 = unaff_D7;
      }
    }
    if (-1 < iVar1) {
      if ('\x01' < DAT_00000400) {
        h_inquiry(param_2,auStack_28);
        cmpbuf(auStack_20,&DAT_0101c214,3);
        if (unaff_D7 == 0) {
          cmpbuf(auStack_20,&DAT_0101c224,4);
          pcVar2 = "/OTHER-TYP1";
        }
        else {
          pcVar2 = "/NEC  -TYP1";
        }
        cpybuf(pcVar2,s__01046b84,0xb);
      }
      h_mkdir(param_1,param_2);
      iVar1 = unaff_D7;
    }
    h_motor(0xc,param_2);
  }
  mkdoserr(param_2,iVar1);
  return;
}


// ==== h_mkdir @ 0101c3b0

void h_mkdir(undefined1 param_1,undefined1 param_2,int param_3,undefined4 param_4)

{
  bool bVar1;
  size_t __size;
  undefined *unaff_D5;
  undefined *unaff_D7;
  
  bVar1 = false;
  h_dph(param_2);
  __size = *(short *)(param_3 + 10) * 0x20;
  if (h_comsz < (int)__size) {
    do {
      malloc(__size);
      unaff_D5 = unaff_D7;
      if (unaff_D7 != (undefined *)0x0) {
        bVar1 = true;
        break;
      }
      __size = __size - h_comsz;
    } while (h_comsz < (int)__size);
  }
  if (unaff_D5 == (undefined *)0x0) {
    unaff_D5 = &h_combf;
  }
  h_iniven(param_3,param_2,__size,unaff_D5);
  if (bVar1) {
    mfree(unaff_D5);
  }
  if (-1 < (int)unaff_D7) {
    h_intcdr();
    h_mountf();
    if ((-1 < (int)unaff_D7) || (unaff_D7 == (undefined *)0xfffffff9)) {
      unaff_D7[0x33] = 1;
      h_create(param_1,param_2,param_4,0x7f,*(short *)(param_3 + 0xc) * 0x28);
      dosstt();
      if (-1 < (int)unaff_D7) {
        h_clrexb(param_1);
        h_close(param_1,(int)(short)unaff_D7);
        if (-1 < (int)unaff_D7) {
          dosstt();
        }
      }
      if (-1 < (int)unaff_D7) {
        h_wtalmap();
        h_zapall(param_2,param_1,1);
      }
    }
  }
  return;
}


// ==== h_iniven @ 0101c514

void h_iniven(ushort *param_1,undefined1 param_2,uint param_3,undefined4 param_4)

{
  ushort uVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  int iVar5;
  int unaff_D7;
  short sVar6;
  int iVar7;
  int iVar8;
  uint local_2a;
  uint local_26;
  uint local_22;
  uint local_1e;
  uint local_1a;
  uint local_16;
  
  iVar2 = (int)(short)param_1[5];
  iVar3 = (int)(short)param_1[6];
  uVar1 = param_1[7];
  local_16 = iVar2 << 5;
  local_1a = iVar3 << 5;
  local_1e = (int)(short)uVar1 << 5;
  local_22 = (uint)*(byte *)((int)param_1 + 7);
  iVar7 = 0;
  sVar6 = (short)unaff_D7;
  if (0 < iVar2) {
    do {
      if (param_3 < local_16) {
        uVar4 = param_3;
      }
      else {
        uVar4 = local_16;
      }
      h_clreex(param_1,iVar7,uVar4,param_4);
      iVar8 = (int)sVar6;
      iVar5 = (iVar8 * 0x20) / (int)(uint)*param_1;
      if ((iVar8 * 0x20) % (int)(uint)*param_1 != 0) {
        iVar5 = iVar5 + 1;
      }
      h_rwstrn(3,param_2,local_22,iVar5,param_4);
      if (unaff_D7 < 0) {
        return;
      }
      local_22 = iVar5 + local_22;
      local_16 = local_16 + iVar8 * -0x20;
      iVar7 = iVar8 + iVar7;
    } while (iVar7 < iVar2);
  }
  local_22 = (uint)((int)(short)param_1[5] << 5) / (uint)*param_1 +
             (uint)*(byte *)((int)param_1 + 7);
  iVar2 = 0;
  if (0 < iVar3) {
    do {
      if (param_3 < local_1a) {
        uVar4 = param_3;
      }
      else {
        uVar4 = local_1a;
      }
      h_clrdir(param_1,iVar2,uVar4,param_4);
      iVar5 = (int)sVar6;
      local_26 = (uint)*param_1;
      iVar7 = (iVar5 * 0x20) / (int)local_26;
      local_26 = (uint)*param_1;
      if ((iVar5 * 0x20) % (int)local_26 != 0) {
        iVar7 = iVar7 + 1;
      }
      h_rwstrn(3,param_2,local_22,iVar7,param_4);
      if (unaff_D7 < 0) {
        return;
      }
      local_22 = iVar7 + local_22;
      local_1a = local_1a + iVar5 * -0x20;
      iVar2 = iVar5 + iVar2;
    } while (iVar2 < iVar3);
  }
  iVar2 = (short)uVar1 + 0x4000;
  local_22 = (uint)((int)(short)param_1[6] << 5) / (uint)*param_1 +
             (uint)((int)(short)param_1[5] << 5) / (uint)*param_1 +
             (uint)*(byte *)((int)param_1 + 7);
  iVar3 = 0x4000;
  if (0x4000 < iVar2) {
    do {
      if (param_3 < local_1e) {
        uVar4 = param_3;
      }
      else {
        uVar4 = local_1e;
      }
      h_clrdir(param_1,iVar3,uVar4,param_4);
      iVar5 = (int)sVar6;
      local_2a = (uint)*param_1;
      iVar7 = (iVar5 * 0x20) / (int)local_2a;
      local_2a = (uint)*param_1;
      if ((iVar5 * 0x20) % (int)local_2a != 0) {
        iVar7 = iVar7 + 1;
      }
      h_rwstrn(3,param_2,local_22,iVar7,param_4);
      if (unaff_D7 < 0) {
        return;
      }
      local_22 = iVar7 + local_22;
      local_1e = local_1e + iVar5 * -0x20;
      iVar3 = iVar5 + iVar3;
    } while (iVar3 < iVar2);
  }
  return;
}


// ==== h_clreex @ 0101c7b0

void h_clreex(undefined4 param_1,short param_2,uint param_3,short *param_4)

{
  int iVar1;
  short sVar2;
  
  sVar2 = (short)(param_3 >> 5);
  fill(param_4,(int)sVar2 << 5,0);
  iVar1 = 0;
  if (0 < sVar2) {
    do {
      *param_4 = param_2;
      param_2 = param_2 + 1;
      param_4 = param_4 + 0x10;
      iVar1 = iVar1 + 1;
    } while (iVar1 < sVar2);
  }
  return;
}


// ==== h_clrdir @ 0101c800

void h_clrdir(undefined4 param_1,short param_2,uint param_3,int param_4)

{
  int iVar1;
  short sVar2;
  
  sVar2 = (short)(param_3 >> 5);
  fill(param_4,(int)sVar2 << 5,0);
  for (iVar1 = 0; iVar1 < sVar2; iVar1 = iVar1 + 1) {
    if (param_2 == 0x4000) {
      cpybuf(s__01046b84,param_4,0xb);
      redwat(param_4 + 0x10);
      *(undefined1 *)(param_4 + 0xb) = 0x10;
    }
    else {
      *(undefined1 *)(param_4 + 0xb) = 1;
    }
    *(short *)(param_4 + 0x18) = param_2;
    param_2 = param_2 + 1;
    param_4 = param_4 + 0x20;
  }
  return;
}


// ==== h_clrexb @ 0101c886

void h_clrexb(undefined1 param_1,short param_2,uint param_3)

{
  uint uVar1;
  bool bVar2;
  size_t __size;
  int iVar3;
  undefined *unaff_D7;
  undefined *unaff_A3;
  
  bVar2 = false;
  __size = param_3;
  if (h_comsz < (int)param_3) {
    do {
      malloc(__size);
      unaff_A3 = unaff_D7;
      if (unaff_D7 != (undefined *)0x0) {
        bVar2 = true;
        break;
      }
      __size = (int)__size >> 1;
    } while (h_comsz < (int)__size);
  }
  if (unaff_A3 == (undefined *)0x0) {
    unaff_A3 = &h_combf;
  }
  fill(unaff_A3,__size,0x20);
  iVar3 = 0;
  uVar1 = param_3;
  while (__size < uVar1) {
    h_write(param_1,(int)param_2,__size,unaff_A3);
    dosstt();
    if ((int)unaff_D7 < 0) break;
    iVar3 = __size + iVar3;
    uVar1 = param_3 - iVar3;
  }
  if (0 < (int)(param_3 - iVar3)) {
    h_write(param_1,(int)param_2,param_3 - iVar3,unaff_A3);
    dosstt();
  }
  if (bVar2) {
    mfree(unaff_A3);
  }
  return;
}


// ==== h_dph @ 0101c978

void h_dph(byte param_1)

{
  if (param_1 < 2) {
    (&DAT_01044442)[(uint)param_1 * 0x36] = param_1;
  }
  return;
}


// ==== h_selinf @ 0101c9ae

void h_selinf(int param_1)

{
  int unaff_D7;
  
  cmpbuf(param_1 + 8,&DAT_0101c9a4,3);
  if (unaff_D7 == 1) {
    cmpbuf(param_1 + 0x10,"D3856",5);
  }
  return;
}


// ==== h_dskcfg @ 0101ca08

void h_dskcfg(undefined1 param_1)

{
  undefined1 auStack_28 [36];
  
  h_inquiry(param_1,auStack_28);
  h_selinf(auStack_28);
  return;
}


// ==== h_intcdr @ 0101ca34

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void h_intcdr(void)

{
  h_cdrhbf = 0;
  _DAT_01044f66 = &h_lnkbuf;
  DAT_01044f6a = 0;
  _DAT_01044f6c = 0;
  _DAT_01044f6e = 0;
  _DAT_01044f70 = 0;
  _DAT_01044f72 = &h_pathbf;
  _DAT_01044f76 = 0;
  return;
}


// ==== h_supdph @ 0101ca78

void h_supdph(undefined4 *param_1)

{
  undefined4 unaff_D7;
  
  *param_1 = 0;
  param_1[1] = 0;
  param_1[2] = 0;
  param_1[3] = 0;
  param_1[4] = 0;
  param_1[5] = 0;
  param_1[6] = 0;
  h_dskcfg((int)*(char *)((int)param_1 + 0x32));
  param_1[7] = unaff_D7;
  param_1[8] = 0;
  h_supcdr();
  param_1[9] = unaff_D7;
  param_1[10] = 0;
  param_1[0xb] = 0;
  *(undefined1 *)(param_1 + 0xd) = 0;
  *(undefined1 *)((int)param_1 + 0x35) = 0;
  return;
}


// ==== h_supcdr @ 0101cad4

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void h_supcdr(void)

{
  _DAT_01044f66 = &h_lnkbuf;
  _DAT_01044f72 = &h_pathbf;
  return;
}


// ==== h_wtalmap @ 0101caf6

void h_wtalmap(int param_1)

{
  ushort *puVar1;
  int iVar2;
  
  if (*(int *)(param_1 + 0x18) != 0) {
    puVar1 = *(ushort **)(param_1 + 0x1c);
    iVar2 = *(int *)(puVar1 + 0xc) + *(int *)(puVar1 + 0xe) + *(int *)(puVar1 + 10);
    h_rwstrn(3,*(undefined1 *)(param_1 + 0x32),
             (uint)((int)(short)puVar1[6] << 5) / (uint)*puVar1 +
             (uint)((int)(short)puVar1[5] << 5) / (uint)*puVar1 + (uint)*(byte *)((int)puVar1 + 7) +
             (uint)((int)(short)puVar1[7] << 5) / (uint)*puVar1,
             (uint)(iVar2 % (int)(uint)*puVar1 != 0) + iVar2 / (int)(uint)*puVar1,
             *(int *)(param_1 + 0x18));
  }
  return;
}


// ==== h_mount @ 0101cbb4

void h_mount(undefined1 param_1,byte param_2)

{
  int iVar1;
  uint uVar2;
  uint unaff_D7;
  
  h_dph(param_2);
  if (unaff_D7 == 0) {
    uVar2 = 0xfffffff6;
  }
  else {
    *(undefined1 *)(unaff_D7 + 0x34) = 0;
    iVar1 = *(char *)(unaff_D7 + 0x33) + 1;
    uVar2 = (uint)param_2;
    if (0 < iVar1) {
      if (iVar1 == 1) {
        h_motor(0xb,param_2);
        uVar2 = unaff_D7;
        if ((int)unaff_D7 < 0) goto LAB_0101cc5c;
        h_mountf();
        if ((int)unaff_D7 < 0) {
          h_zapall((int)*(char *)(unaff_D7 + 0x32),param_1,1);
          h_motor(0xc,param_2);
          goto LAB_0101cc5c;
        }
      }
      *(char *)(unaff_D7 + 0x33) = (char)iVar1;
    }
  }
LAB_0101cc5c:
  mkdoserr(param_2,uVar2);
  return;
}


// ==== h_mountf @ 0101cc78

void h_mountf(undefined4 param_1,undefined1 param_2)

{
  int unaff_D7;
  char acStack_54 [80];
  
  h_supdph(param_1);
  h_almapse(param_1);
  if ((-1 < unaff_D7) && (h_pwpwd(param_1,acStack_54), -1 < unaff_D7)) {
    h_chdsub(param_1,param_2,acStack_54);
    if (unaff_D7 < 0) {
      strcpy(acStack_54,"/");
      h_chdsub(param_1,param_2,acStack_54);
    }
  }
  return;
}


// ==== h_demnt @ 0101ccfa

void h_demnt(undefined1 param_1,undefined1 param_2)

{
  int iVar1;
  int unaff_D7;
  
  h_dph(param_2);
  h_dmntck();
  iVar1 = unaff_D7;
  if (unaff_D7 < 0) {
    if ((unaff_D7 != -4) && (unaff_D7 != -1)) goto LAB_0101cdaa;
    iVar1 = 0;
  }
  if (((*(byte *)(unaff_D7 + 0x34) & 0x10) == 0) &&
     (*(char *)(unaff_D7 + 0x33) = (char)iVar1, iVar1 < 1)) {
    h_motor(0xb,param_2);
    h_wtalmap();
    if (-1 < unaff_D7) {
      h_zapall((int)*(char *)(unaff_D7 + 0x32),param_1,1);
      h_motor(0xc,param_2);
    }
  }
LAB_0101cdaa:
  mkdoserr(param_2);
  return;
}


// ==== h_dmntck @ 0101cdba

void h_dmntck(void)

{
  return;
}


// ==== h_zapfcb @ 0101cde8

void h_zapfcb(int param_1,int param_2)

{
  int iVar1;
  
  iVar1 = *(int *)(param_1 + 8);
  if (param_2 == 1) {
    h_flush(param_1);
  }
  *(undefined1 *)(iVar1 + 0xc) = 0;
  *(undefined1 *)(iVar1 + 0xd) = 0;
  zap_ptr(iVar1,mfree);
  *(undefined4 *)(param_1 + 8) = 0;
  *(undefined1 *)(param_1 + 0x1b) = 0;
  return;
}


// ==== h_zapfcq @ 0101ce3c

void h_zapfcq(int *param_1,undefined4 param_2)

{
  int *piVar1;
  int unaff_D7;
  
  piVar1 = (int *)*param_1;
  if ((param_1 != (int *)0x0) && (piVar1 != (int *)0x0)) {
    h_zapfcq(piVar1,param_2);
    h_zapfcb(piVar1,param_2);
    if (-1 < unaff_D7) {
      *param_1 = *piVar1;
    }
  }
  return;
}


// ==== h_zapflg @ 0101ce7e

void h_zapflg(int param_1)

{
  *(undefined1 *)(param_1 + 0x33) = 0;
  *(byte *)(param_1 + 0x34) = *(byte *)(param_1 + 0x34) | 0x10;
  return;
}


// ==== h_zapsgh @ 0101ce9a

void h_zapsgh(undefined4 *param_1)

{
  zap_ptr(*param_1,mfree);
  zap_ptr(param_1,mfree);
  return;
}


// ==== h_zapeeh @ 0101ceca

void h_zapeeh(undefined4 *param_1)

{
  zap_ptr(*param_1,mfree);
  zap_ptr(param_1,mfree);
  return;
}


// ==== h_zapdph @ 0101cefa

void h_zapdph(int param_1,undefined1 param_2,int param_3)

{
  if (param_3 == 1) {
    h_putdir(param_1,param_2);
  }
  zap_ptr(param_1 + 0x1c,0);
  h_zapsgh(param_1 + 8);
  h_zapsgh(param_1 + 0xc);
  h_zapsgh(param_1 + 0x20);
  h_zapeeh(param_1 + 0x10);
  h_zapeeh(param_1 + 0x14);
  zap_ptr(param_1 + 0x18,mfree);
  h_zapflg(param_1);
  return;
}


// ==== h_zapall @ 0101cf82

void h_zapall(undefined1 param_1)

{
  undefined4 *unaff_D7;
  
  h_dph(param_1);
  h_zapfcq();
  if (-1 < (int)unaff_D7) {
    *unaff_D7 = 0;
    unaff_D7[1] = 0;
    h_zapdph();
  }
  return;
}


// ==== h_pwd @ 0101cfd8

void h_pwd(undefined4 param_1,undefined1 param_2)

{
  int unaff_D7;
  
  h_dph(param_2);
  if (unaff_D7 == 0) {
    unaff_D7 = -10;
  }
  else {
    h_pwpwd();
  }
  mkdoserr(param_2,unaff_D7);
  return;
}


// ==== h_pwpwd @ 0101d020

void h_pwpwd(int param_1,char *param_2)

{
  int iVar1;
  int iVar2;
  int iVar3;
  char *pcVar4;
  int iVar5;
  int iVar6;
  
  iVar1 = *(int *)(param_1 + 0x24);
  iVar6 = (int)*(short *)(iVar1 + 0x12);
  if (iVar6 == 0) {
    cpydata(&DAT_0101d01e,param_2,2);
  }
  else {
    iVar5 = 0;
    if (0 < iVar6) {
      do {
        iVar2 = *(int *)(iVar1 + 0xe);
        *param_2 = '/';
        pcVar4 = (char *)(iVar2 + 2 + iVar5 * 10);
        for (iVar3 = 0; (param_2 = param_2 + 1, *pcVar4 != ' ' && (iVar3 < 8)); iVar3 = iVar3 + 1) {
          *param_2 = *pcVar4;
          pcVar4 = pcVar4 + 1;
        }
        iVar5 = iVar5 + 1;
      } while (iVar5 < iVar6);
    }
    *param_2 = '\0';
  }
  return;
}


// ==== h_pwanap @ 0101d094

void h_pwanap(char *param_1,undefined4 param_2)

{
  int unaff_D7;
  
  strlen(param_1);
  if (unaff_D7 != 0) {
    h_pwtypp(param_1);
    if (unaff_D7 == 0) {
      h_pwrelp(param_1,param_2);
    }
    else {
      h_pwabsp(param_1);
    }
  }
  return;
}


// ==== h_pwtypp @ 0101d0e0

bool h_pwtypp(char *param_1)

{
  return *param_1 == '/';
}


// ==== h_pwrelp @ 0101d102

/* WARNING: Removing unreachable block (ram,0x0101d17e) */

void h_pwrelp(char *param_1,undefined4 param_2)

{
  int iVar1;
  int unaff_D7;
  
  iVar1 = 0;
  do {
    strlen(param_1);
    if (unaff_D7 == 0) {
      iVar1 = 4;
    }
    else {
      h_pwnent(param_1,param_2);
      if ((unaff_D7 < 1) || (8 < unaff_D7)) {
LAB_0101d194:
        iVar1 = -10;
      }
      else {
        cmpbuf(param_2,&DAT_0101d0fc,1);
        if (unaff_D7 != 1) {
          cmpbuf(param_2,&DAT_0101d0fe,2);
          h_fnchk(param_2);
          if (unaff_D7 < 0) goto LAB_0101d194;
          iVar1 = 1;
        }
      }
    }
    if (iVar1 != 0) {
      return;
    }
  } while( true );
}


// ==== h_pwnent @ 0101d1a8

void h_pwnent(char *param_1,undefined4 param_2)

{
  int unaff_D7;
  char *pcVar1;
  int iVar2;
  undefined1 auStack_e [10];
  
  for (pcVar1 = param_1; (*pcVar1 != '\0' && (*pcVar1 != '/')); pcVar1 = pcVar1 + 1) {
  }
  strlen(param_1);
  iVar2 = (int)pcVar1 - (int)param_1;
  if ((iVar2 < 9) && (iVar2 != 0)) {
    cpydata(param_1,auStack_e,iVar2);
    auStack_e[iVar2] = 0;
    cpydata(param_1 + iVar2 + 1,param_1,unaff_D7 - iVar2);
    param_1[unaff_D7 - iVar2] = '\0';
    h_pwtypp(param_1);
    if (unaff_D7 != 1) {
      fill(param_2,0xb,0x20);
      cpydata(auStack_e,param_2,iVar2);
    }
  }
  return;
}


// ==== h_pwabsp @ 0101d24a

undefined4 h_pwabsp(char *param_1)

{
  undefined4 uVar1;
  int unaff_D7;
  
  strlen(param_1);
  cpydata(param_1 + 1,param_1);
  h_pwtypp(param_1);
  if (unaff_D7 == 1) {
    uVar1 = 0xfffffff6;
  }
  else {
    uVar1 = 3;
  }
  return uVar1;
}


// ==== h_pwfent @ 0101d288

undefined2 h_pwfent(int param_1)

{
  short sVar1;
  undefined2 uVar2;
  
  sVar1 = *(short *)(*(int *)(param_1 + 0x24) + 0x12);
  if (sVar1 == 0) {
    uVar2 = 0x4000;
  }
  else {
    uVar2 = *(undefined2 *)(*(int *)(*(int *)(param_1 + 0x24) + 0xe) + (short)(sVar1 + -1) * 10);
  }
  return uVar2;
}


// ==== h_pwrt @ 0101d2bc

void h_pwrt(int param_1)

{
  *(undefined2 *)(*(int *)(param_1 + 0x24) + 0x12) = 0;
  return;
}


// ==== h_pwup @ 0101d2d2

undefined4 h_pwup(int param_1)

{
  int iVar1;
  short sVar2;
  short *psVar3;
  
  iVar1 = *(int *)(param_1 + 0x24);
  psVar3 = (short *)(iVar1 + 0x12);
  sVar2 = 0;
  if (*psVar3 != 0) {
    sVar2 = *psVar3 + -1;
    *psVar3 = sVar2;
  }
  return CONCAT22((short)((uint)iVar1 >> 0x10),sVar2);
}


// ==== h_pwdwn @ 0101d2f6

undefined4 h_pwdwn(int param_1,undefined4 param_2,undefined2 param_3)

{
  undefined2 *puVar1;
  undefined4 uVar2;
  
  puVar1 = *(undefined2 **)(param_1 + 0x24);
  if (puVar1[9] == 8) {
    uVar2 = 0xffffffca;
  }
  else {
    cpydata(param_2,*(int *)(puVar1 + 7) + 2 + (short)puVar1[9] * 10,8);
    *(undefined2 *)(*(int *)(puVar1 + 7) + (short)puVar1[9] * 10) = param_3;
    *puVar1 = param_3;
    puVar1[9] = puVar1[9] + 1;
    uVar2 = 0;
  }
  return uVar2;
}


// ==== h_pwlench @ 0101d362

void h_pwlench(char *param_1)

{
  strlen(param_1);
  return;
}


// ==== h_pwdirn @ 0101d382

void h_pwdirn(char *param_1,undefined1 *param_2,undefined4 param_3)

{
  int iVar1;
  int unaff_D7;
  char *pcVar2;
  
  strlen(param_1);
  for (pcVar2 = param_1 + unaff_D7 + -1; (param_1 <= pcVar2 && (*pcVar2 != '/'));
      pcVar2 = pcVar2 + -1) {
  }
  iVar1 = (int)pcVar2 - (int)param_1;
  if (iVar1 < 0) {
    *param_2 = 0;
  }
  else {
    if (iVar1 == 0) {
      cpydata(&DAT_0101d01e,param_2,2);
      param_1 = param_1 + 1;
    }
    else {
      cpydata(param_1,param_2,iVar1);
      param_2[iVar1] = 0;
      unaff_D7 = unaff_D7 - iVar1;
      param_1 = param_1 + iVar1 + 1;
    }
    unaff_D7 = unaff_D7 + -1;
  }
  fill(param_3,0xb,0x20);
  cpydata(param_1,param_3,unaff_D7);
  return;
}


// ==== hdinit @ 0101d42c

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void hdinit(void)

{
  undefined2 uVar1;
  
  uVar1 = _DAT_00880000;
  cacr_off();
  _DAT_00880000 = 0x5aa5;
  cacr_on();
  HDDInitia();
  DAT_0f00d000 = 0;
  cacr_on();
  _DAT_00880000 = uVar1;
  return;
}


// ==== h_rwstrn @ 0101d47a

void h_rwstrn(char param_1,byte param_2,int param_3,int param_4,int param_5)

{
  int iVar1;
  int iVar2;
  int unaff_D7;
  byte local_c;
  undefined1 local_b;
  undefined1 local_a;
  undefined1 local_9;
  undefined1 local_8;
  undefined1 local_7;
  undefined1 local_6;
  
  gTimeOutC = 500;
  if (param_1 == '\x02') {
    local_b = 8;
  }
  else {
    if (param_1 != '\x03') {
      gTimeOutC = 500;
      return;
    }
    local_b = 10;
  }
  local_c = param_2;
  local_6 = 0;
  param_4 = (uint)*(ushort *)(&DAT_01046c30 + (uint)param_2 * 8) * param_4;
  do {
    if (param_4 < 1) {
      return;
    }
    if (param_4 < 0xfe01) {
      iVar1 = param_4;
    }
    else {
      iVar1 = 0xfe00;
    }
    iVar2 = iVar1 / (int)(uint)*(ushort *)(&DAT_01046c30 + (uint)param_2 * 8);
    local_a = (undefined1)((uint)param_3 >> 0x10);
    local_9 = (undefined1)((uint)param_3 >> 8);
    local_8 = (undefined1)param_3;
    local_7 = (undefined1)iVar2;
    HDReqMana(&local_c,iVar1,param_5);
    if (unaff_D7 < 0) {
      if (param_1 != '\x03') {
        return;
      }
      HDReassig(&local_c,param_3,iVar2,param_5);
      if (unaff_D7 < 0) {
        return;
      }
    }
    param_4 = param_4 - iVar1;
    param_5 = iVar1 + param_5;
    param_3 = iVar2 + param_3;
  } while( true );
}


// ==== HDReassig @ 0101d5ac

void HDReassig(byte *param_1,int param_2,int param_3,int param_4)

{
  uint uVar1;
  int iVar2;
  int unaff_D7;
  undefined4 local_14;
  int local_10;
  undefined1 auStack_c [8];
  
  uVar1 = (uint)*(ushort *)(&DAT_01046c30 + (uint)*param_1 * 8);
  param_1[5] = 1;
  local_14 = 4;
  MakeCDBDa(7,auStack_c,*param_1,0);
  iVar2 = 0;
  if (0 < param_3) {
    do {
      HDReqMana(param_1,uVar1,param_4);
      if (unaff_D7 < 0) {
        local_10 = param_2;
        HDReqMana(auStack_c,8,&local_14);
        if (unaff_D7 < 0) {
          return;
        }
        HDReqMana(param_1,uVar1,param_4);
        if (unaff_D7 < 0) {
          return;
        }
      }
      param_4 = uVar1 + param_4;
      param_2 = param_2 + 1;
      param_1[3] = (byte)((uint)param_2 >> 8);
      param_1[4] = (byte)param_2;
      iVar2 = iVar2 + 1;
    } while (iVar2 < param_3);
  }
  return;
}


// ==== h_motor @ 0101d67c

void h_motor(char param_1,undefined1 param_2)

{
  undefined1 auStack_c [8];
  
  if (param_1 == '\v') {
    MakeCDBDa(0,auStack_c,param_2,0);
    gTimeOutC = 500;
    HDReqMana(auStack_c,0,0);
  }
  return;
}


// ==== h_inquiry @ 0101d6c8

void h_inquiry(undefined4 param_1,undefined4 param_2)

{
  undefined1 auStack_c [8];
  
  MakeCDBDa(0x12,auStack_c,param_1,0);
  gTimeOutC = 500;
  HDReqMana(auStack_c,0x24,param_2);
  return;
}


// ==== h_format @ 0101d706

void h_format(undefined1 param_1)

{
  undefined1 auStack_c [8];
  
  SetupForm(&gHDDCmdCo,param_1);
  MakeCDBDa(4,auStack_c,param_1,0);
  gTimeOutC = 180000;
  HDReqMana(auStack_c,0,0);
  return;
}


// ==== MakeCDBDa @ 0101d752

void MakeCDBDa(undefined1 param_1,undefined1 *param_2,undefined1 param_3,int param_4)

{
  undefined1 *puVar1;
  
  puVar1 = param_2 + 1;
  *param_2 = param_3;
  param_2[2] = 0;
  param_2[3] = 0;
  param_2[4] = 0;
  param_2[5] = 0;
  param_2[6] = 0;
  switch(param_1) {
  case 0:
  case 4:
  case 7:
    *puVar1 = param_1;
    break;
  case 3:
    *puVar1 = param_1;
    param_2[5] = 0xd;
    break;
  case 0x12:
    *puVar1 = param_1;
    param_2[5] = 0x24;
    break;
  case 0x1b:
    *puVar1 = param_1;
    if (param_4 == 1) {
      param_2[5] = 1;
    }
  }
  return;
}


// ==== HDReqMana @ 0101d7ee

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void HDReqMana(undefined1 *param_1,undefined2 param_2,undefined4 param_3)

{
  uint unaff_D7;
  short local_6;
  
  spfledbli();
  DAT_01046ba1 = *param_1;
  cpybuf(param_1 + 1,&DAT_01046ba2,6);
  _DAT_01046ba8 = param_2;
  _DAT_01046baa = param_3;
  DAT_01046bae = &local_6;
  clrecb(0,0x40000020);
  devtrp(1,7);
  do {
    wait((void *)0x0);
  } while ((unaff_D7 & 0x40000020) == 0);
  if ((((((unaff_D7 & 0x40000000) != 0) && ((DAT_0f009000 & 0x20) != 0)) || (*DAT_01046bae != 0)) &&
      ((DAT_01046ba2 == '\b' || (DAT_01046ba2 == '\n')))) &&
     (RWErrorRe(&gHDDCmdCo,1), unaff_D7 != 0)) {
    clrecb(0,0x40000020);
    devtrp(1,7);
    do {
      wait((void *)0x0);
    } while ((unaff_D7 & 0x40000020) == 0);
    if ((((unaff_D7 & 0x40000000) != 0) && ((DAT_0f009000 & 0x20) != 0)) || (*DAT_01046bae != 0)) {
      RWErrorRe(&gHDDCmdCo,1);
    }
  }
  spflednob();
  return;
}


// ==== h_bkbyt @ 0101d93c

undefined1 h_bkbyt(int param_1)

{
  return *(undefined1 *)(param_1 + 8);
}


// ==== h_rsize @ 0101d964

void h_rsize(undefined4 param_1)

{
  h_bkbyt(param_1,1);
  return;
}


// ==== h_bbasset @ 0101d97a

void h_bbasset(int param_1)

{
  int *unaff_D7;
  int *piVar1;
  
  piVar1 = *(int **)(param_1 + 8);
  if (*(int **)(param_1 + 8) == (int *)0x0) {
    f_fileio((int)*(char *)(param_1 + 0x1b));
    *(int **)(param_1 + 8) = unaff_D7;
    piVar1 = unaff_D7;
  }
  if ((piVar1 != (int *)0x0) && (*piVar1 == 0)) {
    h_rsize(*(undefined4 *)(*(int *)(param_1 + 4) + 0x1c));
    malloc((size_t)unaff_D7);
    if (unaff_D7 != (int *)0x0) {
      *piVar1 = (int)unaff_D7;
      *(int **)((int)piVar1 + 0x12) = unaff_D7;
      piVar1[1] = (int)unaff_D7;
      *(undefined4 *)((int)piVar1 + 0xe) = 0;
      piVar1[2] = 0;
      *(undefined1 *)(piVar1 + 3) = 0;
    }
  }
  return;
}


// ==== f_clpfio @ 0101d9f2

uint f_clpfio(int *param_1,int param_2,uint param_3,uint param_4)

{
  if (param_2 < 1) {
    if ((param_4 < (uint)param_1[1]) || (*(int *)((int)param_1 + 0x12) != *param_1)) {
      param_3 = 0xfffffff4;
    }
    else {
      param_3 = 0;
    }
  }
  else if ((int)param_4 < (int)param_3) {
    param_3 = param_4;
  }
  return param_3;
}


// ==== h_charge @ 0101da2e

void h_charge(int param_1)

{
  undefined4 *puVar1;
  int unaff_D7;
  
  puVar1 = *(undefined4 **)(param_1 + 8);
  if ((puVar1 != (undefined4 *)0x0) && (h_rdbuf(param_1,puVar1[1],*puVar1), -1 < unaff_D7)) {
    *(byte *)(puVar1 + 3) = *(byte *)(puVar1 + 3) | 1;
    puVar1[2] = unaff_D7;
  }
  return;
}


// ==== h_grwfil @ 0101da70

void h_grwfil(int param_1,short param_2)

{
  int unaff_D7;
  
  h_setmap(param_1,(int)param_2);
  if ((0 < unaff_D7) &&
     (*(short *)(param_1 + 0xe) = param_2 + *(short *)(param_1 + 0xe),
     *(short *)(param_1 + 0x20) < 1)) {
    *(short *)(param_1 + 0x20) = (short)unaff_D7;
  }
  return;
}


// ==== h_skfcb @ 0101dab6

void h_skfcb(int param_1,uint param_2)

{
  undefined4 uVar1;
  uint uVar2;
  int unaff_D7;
  short sVar3;
  
  uVar1 = *(undefined4 *)(param_1 + 8);
  if (param_2 < *(uint *)(param_1 + 0x12)) {
    uVar2 = param_2;
  }
  else {
    uVar2 = *(uint *)(param_1 + 0x12);
  }
  h_bkord(*(undefined4 *)(*(int *)(param_1 + 4) + 0x1c),uVar2);
  sVar3 = (short)unaff_D7;
  h_eexnum(param_1,(int)*(short *)(param_1 + 0x20),
           (int)(sVar3 / 0xc) - (int)(*(short *)(param_1 + 0x10) / 0xc));
  f_skfio(uVar1,*(undefined4 *)(param_1 + 0x16),param_2);
  if (unaff_D7 == 1) {
    h_flush(param_1);
  }
  if (-1 < (int)(uint)(unaff_D7 == 1)) {
    *(uint *)(param_1 + 0x16) = uVar2;
    *(short *)(param_1 + 0x10) = sVar3;
    *(short *)(param_1 + 0x20) = sVar3;
  }
  return;
}


// ==== f_skfio @ 0101db5c

void f_skfio(int *param_1,int param_2,uint param_3)

{
  uint uVar1;
  
  uVar1 = param_3 + ((*(int *)((int)param_1 + 0x12) - *param_1) - param_2);
  if (param_1 != (int *)0x0) {
    if (((int)uVar1 < 0) || ((uint)param_1[1] <= uVar1)) {
      param_1[2] = 0;
    }
    else if ((*(byte *)(param_1 + 3) & 0x81) != 0) {
      if (uVar1 < (uint)param_1[2]) {
        uVar1 = param_1[2];
      }
      param_1[2] = uVar1;
    }
    *(uint *)((int)param_1 + 0x12) = *param_1 + param_3 % (uint)param_1[1];
    if ((param_1[2] + *param_1) - *(int *)((int)param_1 + 0x12) < 1) {
      *(byte *)(param_1 + 3) = *(byte *)(param_1 + 3) & 0xfe;
    }
  }
  return;
}


// ==== h_flush @ 0101dbee

void h_flush(int param_1)

{
  int *piVar1;
  int unaff_D7;
  
  piVar1 = *(int **)(param_1 + 8);
  if ((piVar1 != (int *)0x0) && (*(char *)(piVar1 + 3) < '\0')) {
    if (((*(byte *)(param_1 + 0xc) & 3) != 3) && (piVar1[2] != 0)) {
      fill(*(undefined4 *)((int)piVar1 + 0x12),(piVar1[1] + *piVar1) - *(int *)((int)piVar1 + 0x12),
           0);
    }
    h_wrbuf(param_1,piVar1[1],*piVar1);
    if (-1 < unaff_D7) {
      *(byte *)(piVar1 + 3) = *(byte *)(piVar1 + 3) & 0x7f;
      piVar1[2] = 0;
    }
  }
  return;
}


// ==== h_rdfio @ 0101dc7c

void h_rdfio(int param_1,uint param_2,undefined4 param_3)

{
  int *piVar1;
  int iVar2;
  uint unaff_D7;
  uint unaff_A4;
  
  h_bbasset(param_1);
  if (-1 < (int)unaff_D7) {
    piVar1 = *(int **)(param_1 + 8);
    iVar2 = (piVar1[2] + *piVar1) - *(int *)((int)piVar1 + 0x12);
    f_clpfio(piVar1,iVar2,iVar2,param_2);
    if (unaff_D7 != 0) {
      if ((int)unaff_D7 < 1) {
        h_charge(param_1);
        if ((0 < (int)unaff_D7) &&
           (unaff_A4 = (piVar1[2] + *piVar1) - *(int *)((int)piVar1 + 0x12), param_2 < unaff_A4)) {
          unaff_A4 = param_2;
        }
      }
      else {
        unaff_A4 = unaff_D7;
      }
      if (0 < (int)unaff_D7) {
        cpydata(*(undefined4 *)((int)piVar1 + 0x12),param_3,unaff_A4);
        h_skfcb(param_1,*(int *)(param_1 + 0x16) + unaff_A4);
      }
    }
  }
  return;
}


// ==== h_wrfio @ 0101dd24

void h_wrfio(int param_1,uint param_2,undefined4 param_3)

{
  int *piVar1;
  uint unaff_D7;
  uint uVar2;
  
  h_bbasset(param_1);
  if ((int)unaff_D7 < 0) {
    return;
  }
  piVar1 = *(int **)(param_1 + 8);
  f_clpfio(piVar1,piVar1[2],(piVar1[1] + *piVar1) - *(int *)((int)piVar1 + 0x12),param_2);
  if (unaff_D7 == 0) {
    return;
  }
  if ((int)unaff_D7 < 1) {
    h_ftlbk(param_1,(int)*(short *)(param_1 + 0x10));
    uVar2 = param_2;
    if ((short)unaff_D7 < 1) {
      h_grwfil(param_1,1);
    }
    else {
      if ((*(byte *)(param_1 + 0xc) & 1) != 0) {
        h_charge(param_1);
        if (0 < (int)unaff_D7) {
          uVar2 = (piVar1[1] + *piVar1) - *(int *)((int)piVar1 + 0x12);
          if (param_2 < uVar2) {
            uVar2 = param_2;
          }
          goto LAB_0101ddda;
        }
        if (unaff_D7 != 0xfffffff4) goto LAB_0101ddda;
      }
      unaff_D7 = 0;
    }
  }
  else {
    uVar2 = unaff_D7;
  }
LAB_0101ddda:
  if (-1 < (int)unaff_D7) {
    cpydata(param_3,*(undefined4 *)((int)piVar1 + 0x12),uVar2);
    if (uVar2 != 0) {
      *(byte *)(piVar1 + 3) = *(byte *)(piVar1 + 3) | 0x80;
      *(byte *)(param_1 + 0xc) = *(byte *)(param_1 + 0xc) | 0x80;
    }
    if (*(uint *)(param_1 + 0x12) <= uVar2 + *(int *)(param_1 + 0x16)) {
      *(uint *)(param_1 + 0x12) = uVar2 + *(int *)(param_1 + 0x16);
    }
    h_skfcb(param_1,*(int *)(param_1 + 0x16) + uVar2);
  }
  return;
}


// ==== h_contig @ 0101de48

void h_contig(int param_1,short param_2,short param_3)

{
  short sVar1;
  short sVar2;
  short sVar3;
  int unaff_D7;
  int iVar4;
  
  h_srhblk(param_1,(int)param_2);
  if ((-1 < (short)unaff_D7) &&
     (h_skeeh(*(undefined4 *)(param_1 + 4),(int)(short)unaff_D7), unaff_D7 != 0)) {
    iVar4 = (int)(param_2 % 0xc);
    sVar3 = *(short *)(unaff_D7 + 8 + iVar4 * 2);
    if ((0 < sVar3) && (sVar2 = 1, 1 < param_3)) {
      do {
        iVar4 = iVar4 + 1;
        if (0xb < iVar4) {
          iVar4 = 0;
          h_skeeh(*(undefined4 *)(param_1 + 4),(int)*(short *)(unaff_D7 + 6));
          if (unaff_D7 == 0) {
            return;
          }
        }
        sVar1 = *(short *)(unaff_D7 + 8 + iVar4 * 2);
        if (sVar1 < 1) {
          return;
        }
        if (sVar3 + 1 != (int)sVar1) {
          return;
        }
        sVar2 = sVar2 + 1;
        sVar3 = sVar1;
      } while (sVar2 < param_3);
      return;
    }
  }
  return;
}


// ==== h_bksl @ 0101df00

undefined1 h_bksl(int param_1)

{
  return *(undefined1 *)(param_1 + 8);
}


// ==== h_bknxt @ 0101df1e

undefined4 h_bknxt(int param_1,short param_2)

{
  undefined2 extraout_D0u;
  undefined4 uVar1;
  int unaff_D7;
  short sVar2;
  
  h_srhblk(param_1,(int)param_2);
  sVar2 = (short)unaff_D7;
  uVar1 = CONCAT22(extraout_D0u,sVar2);
  if ((-1 < sVar2) && (uVar1 = h_skeeh(*(undefined4 *)(param_1 + 4),(int)sVar2), unaff_D7 != 0)) {
    uVar1 = CONCAT22(param_2 / 0xc,*(undefined2 *)(unaff_D7 + 8 + (param_2 % 0xc) * 2));
  }
  return uVar1;
}


// ==== h_bkidx @ 0101df76

int h_bkidx(int param_1,short param_2)

{
  int iVar1;
  
  iVar1 = (uint)*(byte *)(*(int *)(param_1 + 0x1c) + 8) * (int)param_2;
  if (iVar1 < (int)(uint)*(ushort *)(*(int *)(param_1 + 0x1c) + 0x10)) {
    iVar1 = -10;
  }
  return iVar1;
}


// ==== h_rdbuf @ 0101dfae

void h_rdbuf(int param_1,uint param_2,int param_3)

{
  undefined4 uVar1;
  undefined1 uVar2;
  uint uVar3;
  short sVar4;
  uint unaff_D7;
  short sVar5;
  short sVar6;
  uint local_12;
  int local_8;
  
  local_8 = param_3;
  if ((param_2 != 0) &&
     (local_12 = *(int *)(param_1 + 0x12) - *(int *)(param_1 + 0x16), 0 < (int)local_12)) {
    uVar2 = *(undefined1 *)(*(int *)(param_1 + 4) + 0x32);
    uVar1 = *(undefined4 *)(*(int *)(param_1 + 4) + 0x1c);
    if (param_2 < local_12) {
      local_12 = param_2;
    }
    h_bkcnt(uVar1,local_12);
    sVar6 = *(short *)(param_1 + 0x10);
    uVar3 = unaff_D7 & 0xffff;
    while (sVar4 = (short)uVar3, 0 < sVar4) {
      h_bknxt(param_1,(int)sVar6);
      sVar5 = (short)unaff_D7;
      unaff_D7 = (uint)sVar5;
      h_bkidx(*(undefined4 *)(param_1 + 4),unaff_D7);
      h_contig(param_1,(int)sVar6,(int)sVar4);
      h_bksl(uVar1,(int)sVar5);
      h_rwstrn(2,uVar2,unaff_D7,unaff_D7,local_8);
      if ((int)unaff_D7 < 0) {
        return;
      }
      sVar6 = sVar5 + sVar6;
      h_bkbyt(uVar1,(int)sVar5);
      local_8 = unaff_D7 + local_8;
      uVar3 = (uint)(ushort)(sVar4 - sVar5);
    }
  }
  return;
}


// ==== h_wrbuf @ 0101e0a6

/* WARNING: Removing unreachable block (ram,0x0101e0fc) */

void h_wrbuf(int param_1,int param_2,int param_3)

{
  undefined4 uVar1;
  undefined1 uVar2;
  short sVar3;
  int unaff_D7;
  short sVar6;
  int iVar4;
  int iVar5;
  short sVar7;
  
  if (param_2 != 0) {
    uVar1 = *(undefined4 *)(*(int *)(param_1 + 4) + 0x1c);
    h_bkcnt(uVar1,param_2);
    h_ftlbk(param_1,(int)*(short *)(param_1 + 0x10));
    iVar4 = 0;
    uVar2 = *(undefined1 *)(*(int *)(param_1 + 4) + 0x32);
    sVar7 = *(short *)(param_1 + 0x10);
    iVar5 = unaff_D7;
    for (sVar3 = (short)unaff_D7; 0 < sVar3; sVar3 = sVar3 - sVar6) {
      h_bknxt(param_1,(int)sVar7);
      sVar6 = (short)iVar5;
      iVar4 = (int)sVar6;
      h_bkidx(*(undefined4 *)(param_1 + 4),iVar4);
      h_contig(param_1,(int)sVar7,(int)sVar3);
      h_bksl(uVar1,(int)sVar6);
      h_rwstrn(3,uVar2,iVar4,iVar4,param_3);
      iVar5 = iVar4;
      if (iVar4 < 0) break;
      sVar7 = sVar6 + sVar7;
      h_bkbyt(uVar1,(int)sVar6);
      param_3 = iVar4 + param_3;
    }
    if ((iVar4 == 0) && (h_bkbyt(uVar1,(int)(short)unaff_D7), 0 < iVar5)) {
      *(byte *)(param_1 + 0xc) = *(byte *)(param_1 + 0xc) | 0x80;
    }
  }
  return;
}


// ==== h_drhckn @ 0101e1d0

undefined4 h_drhckn(int param_1,ushort param_2)

{
  undefined4 uVar1;
  
  if (param_1 == 0) {
    uVar1 = 0xffffffcc;
  }
  else if (((short)(param_2 & 0xbfff) < 0) ||
          (*(short *)(*(int *)(param_1 + 0x1c) + 0xe) <= (short)(param_2 & 0xbfff))) {
    uVar1 = 0xfffffff7;
  }
  else {
    uVar1 = 0;
  }
  return uVar1;
}


// ==== h_drhsno @ 0101e202

void h_drhsno(void)

{
  return;
}


// ==== h_drhset @ 0101e280

void h_drhset(int param_1)

{
  int *piVar1;
  undefined4 *unaff_D7;
  
  if (param_1 != 0) {
    piVar1 = *(int **)(param_1 + 0x20);
    if (piVar1 == (int *)0x0) {
      malloc(0x12);
      if (unaff_D7 != (undefined4 *)0x0) {
        *(undefined4 **)(param_1 + 0x20) = unaff_D7;
        *unaff_D7 = 0;
        *(undefined2 *)((int)unaff_D7 + 10) = 0x40;
        *(undefined1 *)(unaff_D7 + 1) = 0;
        *(undefined4 *)((int)unaff_D7 + 6) = 0;
        *(undefined2 *)(unaff_D7 + 3) = 0;
        *(undefined2 *)((int)unaff_D7 + 0xe) = 0;
        *(undefined2 *)(unaff_D7 + 4) = 0;
        h_drhset(param_1);
      }
    }
    else if (*piVar1 == 0) {
      malloc(0x800);
      if (unaff_D7 == (undefined4 *)0x0) {
        zap_ptr(param_1 + 0x20,mfree);
      }
      else {
        *piVar1 = (int)unaff_D7;
      }
    }
  }
  return;
}


// ==== h_drhavl @ 0101e30e

void h_drhavl(void)

{
  return;
}


// ==== h_skddir @ 0101e36e

int h_skddir(int param_1,short param_2)

{
  int *piVar1;
  int unaff_D7;
  
  h_drhckn(param_1,(int)param_2);
  if ((-1 < unaff_D7) && (h_drhset(param_1), -1 < unaff_D7)) {
    h_skddsub(param_1,(int)param_2);
    if (-1 < unaff_D7) {
      piVar1 = *(int **)(param_1 + 0x20);
      *(short *)((int)piVar1 + 0xe) = param_2;
      *(short *)(piVar1 + 4) = *(short *)((int)piVar1 + 10) - (short)unaff_D7;
      return *piVar1 + unaff_D7 * 0x20;
    }
    h_zapsgh(param_1 + 0x20);
  }
  return 0;
}


// ==== h_skddsub @ 0101e3e4

void h_skddsub(int param_1,short param_2)

{
  int unaff_D7;
  int iVar1;
  
  iVar1 = (int)param_2;
  h_drhavl(param_1,iVar1);
  if (unaff_D7 < 0) {
    h_drhfls(param_1);
    if (-1 < unaff_D7) {
      h_drhsno(param_1,iVar1);
      if (-1 < unaff_D7) {
        *(int *)(*(int *)(param_1 + 0x20) + 6) = unaff_D7;
        h_drhchg(param_1);
        if (-1 < unaff_D7) {
          h_drhavl(param_1,iVar1);
        }
      }
    }
  }
  return;
}


// ==== h_drhchg @ 0101e44e

void h_drhchg(int param_1)

{
  int *piVar1;
  undefined2 uVar2;
  int unaff_D7;
  
  if (((param_1 != 0) && (piVar1 = *(int **)(param_1 + 0x20), piVar1 != (int *)0x0)) &&
     (h_rwstrn(2,(int)*(char *)(param_1 + 0x32),*(undefined4 *)((int)piVar1 + 6),
               0x800 / **(ushort **)(param_1 + 0x1c),*piVar1), -1 < unaff_D7)) {
    *(undefined1 *)(piVar1 + 1) = 1;
    *(undefined2 *)(piVar1 + 4) = *(undefined2 *)((int)piVar1 + 10);
    uVar2 = *(undefined2 *)(*piVar1 + 0x18);
    *(undefined2 *)(piVar1 + 3) = uVar2;
    *(undefined2 *)((int)piVar1 + 0xe) = uVar2;
  }
  return;
}


// ==== h_drhfls @ 0101e4c4

void h_drhfls(int param_1)

{
  int *piVar1;
  undefined2 uVar2;
  int unaff_D7;
  
  if ((((param_1 != 0) && (piVar1 = *(int **)(param_1 + 0x20), piVar1 != (int *)0x0)) &&
      (*(char *)(piVar1 + 1) < '\0')) &&
     (h_rwstrn(3,(int)*(char *)(param_1 + 0x32),*(undefined4 *)((int)piVar1 + 6),
               0x800 / **(ushort **)(param_1 + 0x1c),*piVar1), -1 < unaff_D7)) {
    *(byte *)(piVar1 + 1) = *(byte *)(piVar1 + 1) & 0x7f;
    *(undefined2 *)(piVar1 + 4) = *(undefined2 *)((int)piVar1 + 10);
    uVar2 = *(undefined2 *)(*piVar1 + 0x18);
    *(undefined2 *)(piVar1 + 3) = uVar2;
    *(undefined2 *)((int)piVar1 + 0xe) = uVar2;
  }
  return;
}


// ==== h_eehset @ 0101e548

void h_eehset(int param_1)

{
  int unaff_D7;
  int iVar1;
  
  iVar1 = *(int *)(param_1 + 0x10);
  if (iVar1 == 0) {
    malloc(0x800);
    if (unaff_D7 != 0) {
      malloc(0x12);
      iVar1 = unaff_D7;
      if (unaff_D7 == 0) {
        mfree();
      }
      else {
        *(int *)unaff_D7 = unaff_D7;
        *(undefined1 *)(unaff_D7 + 4) = 0;
      }
    }
    *(int *)(param_1 + 0x10) = iVar1;
  }
  if ((iVar1 != 0) && ((*(byte *)(iVar1 + 4) & 1) == 0)) {
    *(undefined2 *)(iVar1 + 0xc) = 0;
    *(undefined2 *)(iVar1 + 0xe) = 0;
    *(undefined2 *)(iVar1 + 10) = 0x40;
    *(undefined2 *)(iVar1 + 0x10) = 0;
    *(undefined4 *)(iVar1 + 6) = 0;
  }
  return;
}


// ==== h_eehswp @ 0101e5ce

undefined4 h_eehswp(int param_1)

{
  undefined4 uVar1;
  
  uVar1 = *(undefined4 *)(param_1 + 0x14);
  *(undefined4 *)(param_1 + 0x14) = *(undefined4 *)(param_1 + 0x10);
  *(undefined4 *)(param_1 + 0x10) = uVar1;
  h_eehset(param_1);
  return *(undefined4 *)(param_1 + 0x10);
}


// ==== h_eehavl @ 0101e5fc

void h_eehavl(void)

{
  return;
}


// ==== h_skeeh @ 0101e632

void h_skeeh(int param_1,short param_2)

{
  ushort *puVar1;
  ushort uVar2;
  short sVar3;
  short sVar4;
  int unaff_D7;
  int iVar5;
  int iVar6;
  
  puVar1 = *(ushort **)(param_1 + 0x1c);
  uVar2 = *puVar1;
  h_eehset(param_1);
  iVar6 = *(int *)(param_1 + 0x10);
  sVar3 = *(short *)(iVar6 + 10);
  sVar4 = *(short *)(iVar6 + 10);
  if ((param_2 < (short)puVar1[5]) && (-1 < unaff_D7)) {
    h_eehavl(iVar6,(int)param_2);
    iVar5 = unaff_D7;
    if (unaff_D7 < 0) {
      h_eehswp(param_1);
      iVar6 = unaff_D7;
      if (unaff_D7 == 0) {
        iVar5 = -0x34;
      }
      else {
        h_eehavl();
        if (unaff_D7 < 0) {
          h_exxfls(param_1);
          if (-1 < unaff_D7) {
            *(uint *)(unaff_D7 + 6) =
                 ((uint)((int)sVar4 << 5) / (uint)uVar2) * (int)(param_2 / sVar3);
            h_exxchg(param_1);
            if (-1 < unaff_D7) {
              iVar5 = (int)param_2 - (int)*(short *)(unaff_D7 + 0xc);
            }
          }
        }
      }
    }
    if (iVar5 < 0) {
      h_zapeeh(param_1 + 0x10);
    }
    else {
      *(short *)(iVar6 + 0xe) = param_2;
      *(short *)(iVar6 + 0x10) = *(short *)(iVar6 + 10) - (short)iVar5;
    }
  }
  return;
}


// ==== h_exxchg @ 0101e72c

void h_exxchg(int param_1)

{
  ushort *puVar1;
  undefined4 *puVar2;
  short sVar3;
  short sVar4;
  int unaff_D7;
  
  puVar1 = *(ushort **)(param_1 + 0x1c);
  puVar2 = *(undefined4 **)(param_1 + 0x10);
  sVar3 = (short)((uint)*puVar1 * *(int *)((int)puVar2 + 6) >> 5);
  if ((int)(short)puVar1[5] - (int)sVar3 < (int)*(short *)((int)puVar2 + 10)) {
    sVar4 = puVar1[5] - sVar3;
  }
  else {
    sVar4 = *(short *)((int)puVar2 + 10);
  }
  if (puVar2 != (undefined4 *)0x0) {
    h_rwstrn(2,(int)*(char *)(param_1 + 0x32),*(undefined4 *)((int)puVar2 + 6),
             (uint)((int)sVar4 << 5) / (uint)*puVar1,*puVar2);
    if (-1 < unaff_D7) {
      *(short *)(puVar2 + 3) = sVar3;
      *(short *)((int)puVar2 + 0xe) = sVar3;
      *(byte *)(puVar2 + 1) = *(byte *)(puVar2 + 1) | 1;
      *(short *)(puVar2 + 4) = sVar4;
    }
  }
  return;
}


// ==== h_exxfls @ 0101e7ca

void h_exxfls(int param_1)

{
  ushort *puVar1;
  undefined4 *puVar2;
  short sVar3;
  int unaff_D7;
  
  puVar1 = *(ushort **)(param_1 + 0x1c);
  puVar2 = *(undefined4 **)(param_1 + 0x10);
  sVar3 = (short)((uint)*puVar1 * *(int *)((int)puVar2 + 6) >> 5);
  if ((int)(short)puVar1[5] - (int)sVar3 < (int)*(short *)((int)puVar2 + 10)) {
    sVar3 = puVar1[5] - sVar3;
  }
  else {
    sVar3 = *(short *)((int)puVar2 + 10);
  }
  if ((puVar2 != (undefined4 *)0x0) && (*(char *)(puVar2 + 1) < '\0')) {
    h_rwstrn(3,(int)*(char *)(param_1 + 0x32),*(undefined4 *)((int)puVar2 + 6),
             (uint)((int)sVar3 << 5) / (uint)*puVar1,*puVar2);
    if (-1 < unaff_D7) {
      *(byte *)(puVar2 + 1) = *(byte *)(puVar2 + 1) & 0x7f;
      *(undefined2 *)(puVar2 + 4) = 0;
      *(undefined2 *)((int)puVar2 + 0xe) = *(undefined2 *)(puVar2 + 3);
    }
  }
  return;
}


// ==== h_exxon @ 0101e86c

void h_exxon(int param_1,short param_2,short param_3)

{
  short sVar1;
  int iVar2;
  short *psVar3;
  
  psVar3 = (short *)(param_1 + 8);
  sVar1 = 0;
  iVar2 = 0;
  do {
    if (param_3 <= sVar1) {
      return;
    }
    if (*psVar3 < 1) {
      *psVar3 = param_2;
      param_2 = param_2 + 1;
      sVar1 = sVar1 + 1;
    }
    psVar3 = psVar3 + 1;
    iVar2 = iVar2 + 1;
  } while (iVar2 < 0xc);
  return;
}


// ==== h_exxoff @ 0101e8ac

void h_exxoff(int param_1,int param_2)

{
  short sVar1;
  short *psVar2;
  
  psVar2 = (short *)(param_2 * 2 + 8 + param_1);
  while ((param_2 < 0xc && (sVar1 = *psVar2, sVar1 != 0))) {
    *psVar2 = 0;
    if ((int)psVar2[1] != sVar1 + 1) {
      return;
    }
    param_2 = param_2 + 1;
    psVar2 = psVar2 + 1;
  }
  return;
}


// ==== h_exxtst @ 0101e8e8

void h_exxtst(int param_1,short param_2)

{
  int iVar1;
  short *psVar2;
  
  iVar1 = 0;
  psVar2 = (short *)(param_1 + 8);
  do {
    if (param_2 == *psVar2) {
      return;
    }
    iVar1 = iVar1 + 1;
    psVar2 = psVar2 + 1;
  } while (iVar1 < 0xc);
  return;
}


// ==== h_nwxtnt @ 0101e920

void h_nwxtnt(int param_1)

{
  int iVar1;
  short *unaff_D7;
  short *psVar2;
  
  h_mapscn(*(undefined4 *)(param_1 + 0x28),0,(int)*(short *)(*(int *)(param_1 + 0x1c) + 10));
  if (-1 < (int)unaff_D7) {
    h_skeeh(param_1,(int)(short)unaff_D7);
    if (unaff_D7 != (short *)0x0) {
      iVar1 = 0;
      psVar2 = unaff_D7 + 4;
      do {
        *psVar2 = 0;
        iVar1 = iVar1 + 1;
        psVar2 = psVar2 + 1;
      } while (iVar1 < 0xc);
      *unaff_D7 = (short)unaff_D7;
      unaff_D7[1] = 0;
      unaff_D7[2] = 0;
      unaff_D7[3] = 0;
      *(byte *)(*(int *)(param_1 + 0x10) + 4) = *(byte *)(*(int *)(param_1 + 0x10) + 4) | 0x80;
    }
  }
  return;
}


// ==== h_rdexb @ 0101e9a8

void h_rdexb(undefined1 param_1,undefined1 param_2,undefined2 param_3,undefined2 param_4,
            undefined4 param_5,undefined4 param_6)

{
  h_rwexb(param_1,param_2,param_3,param_4,param_5,param_6,1);
  return;
}


// ==== h_wrexb @ 0101e9f4

void h_wrexb(undefined1 param_1,undefined1 param_2,undefined2 param_3,undefined2 param_4,
            undefined4 param_5,undefined4 param_6)

{
  h_rwexb(param_1,param_2,param_3,param_4,param_5,param_6,2);
  return;
}


// ==== H_OpenCmn @ 0101ea40

void H_OpenCmn(undefined1 param_1,undefined1 param_2)

{
  int unaff_D7;
  undefined1 auStack_14 [16];
  
  h_getvol(param_2,auStack_14);
  dosstt();
  if (-1 < unaff_D7) {
    h_open(param_1,param_2,auStack_14,0x7f);
  }
  return;
}


// ==== h_rwexb @ 0101ea9a

void h_rwexb(undefined1 param_1,undefined1 param_2,ushort param_3,ushort param_4,int param_5,
            int param_6,undefined2 param_7)

{
  uint uVar1;
  uint uVar2;
  uint unaff_D7;
  ushort *puVar3;
  uint uVar4;
  ushort local_1c;
  uint local_16;
  int local_e;
  
  local_e = param_6;
  h_dph(param_2);
  if (((param_4 < param_3) || (param_4 == 0)) || (param_3 == 0)) {
    uVar4 = 0xfffffff6;
  }
  else {
    H_OpenCmn(param_1,param_2);
    dosstt();
    if ((int)unaff_D7 < 0) {
      return;
    }
    uVar4 = 0;
    uVar1 = (uint)*(short *)(*(int *)(unaff_D7 + 0x24) + 8);
    if (uVar1 < ((uint)param_4 - (uint)param_3) + 1) {
      local_16 = uVar1;
    }
    else {
      local_16 = ((uint)param_4 - (uint)param_3) + 1;
    }
    puVar3 = *(ushort **)(*(int *)(unaff_D7 + 0x24) + 2);
    if (param_5 < 0x28) {
      local_1c = (ushort)param_5;
    }
    else {
      local_1c = 0x28;
    }
    uVar2 = 1;
    if (local_16 != 0) {
      do {
        if (uVar1 < uVar2) break;
        if (((*puVar3 & 0x4000) == 0) && (param_3 <= uVar2)) {
          h_rwcmnt(param_1,param_2,(int)(short)unaff_D7,(int)(short)*puVar3,(uint)local_1c,local_e,
                   param_7);
          if ((int)unaff_D7 < 0) break;
          local_e = (uint)local_1c + local_e;
          uVar4 = uVar4 + 1;
        }
        uVar2 = uVar2 + 1;
        puVar3 = puVar3 + 1;
      } while (uVar4 < local_16);
    }
    h_close(param_1,(int)(short)unaff_D7);
    if ((int)unaff_D7 < 0) {
      uVar4 = unaff_D7;
    }
  }
  mkdoserr(param_2,uVar4);
  return;
}


// ==== h_rwcmnt @ 0101ec18

void h_rwcmnt(undefined1 param_1,undefined1 param_2,short param_3,short param_4,int param_5,
             undefined4 param_6,short param_7)

{
  int unaff_D7;
  
  h_dph(param_2);
  h_chkent();
  if ((unaff_D7 != 0x4000) && (-1 < unaff_D7)) {
    h_seek(param_1,(int)param_3,0,param_4 * 0x28);
    dosstt();
    if (-1 < unaff_D7) {
      if (0x28 < param_5) {
        param_5 = 0x28;
      }
      if (param_7 == 2) {
        h_write(param_1,(int)param_3,param_5,param_6);
      }
      else {
        h_read(param_1,(int)param_3,param_5,param_6);
      }
      dosstt();
    }
  }
  return;
}


// ==== h_skdir @ 0101ecec

void h_skdir(undefined4 param_1,short param_2)

{
  int unaff_D7;
  
  h_chkent(param_1,(int)param_2);
  if (unaff_D7 < 1) {
    h_skfdir(param_1,(int)param_2);
  }
  else {
    h_skddir(param_1,(int)param_2);
  }
  return;
}


// ==== h_sghckn @ 0101ed34

undefined4 h_sghckn(int param_1,short param_2)

{
  undefined4 uVar1;
  
  if (param_1 == 0) {
    uVar1 = 0xffffffcc;
  }
  else if ((param_2 < 0) || (*(short *)(*(int *)(param_1 + 0x1c) + 0xc) <= param_2)) {
    uVar1 = 0xfffffff7;
  }
  else {
    uVar1 = 0;
  }
  return uVar1;
}


// ==== h_sghsno @ 0101ed64

void h_sghsno(void)

{
  return;
}


// ==== h_sghset @ 0101edcc

void h_sghset(int param_1)

{
  int *piVar1;
  undefined4 *unaff_D7;
  
  if (param_1 != 0) {
    piVar1 = *(int **)(param_1 + 8);
    if (piVar1 == (int *)0x0) {
      malloc(0x12);
      if (unaff_D7 != (undefined4 *)0x0) {
        *(undefined4 **)(param_1 + 8) = unaff_D7;
        *unaff_D7 = 0;
        *(undefined2 *)((int)unaff_D7 + 10) = 0x40;
        *(undefined1 *)(unaff_D7 + 1) = 0;
        *(undefined4 *)((int)unaff_D7 + 6) = 0;
        *(undefined2 *)(unaff_D7 + 3) = 0;
        *(undefined2 *)((int)unaff_D7 + 0xe) = 0;
        *(undefined2 *)(unaff_D7 + 4) = 0;
        h_sghset(param_1);
      }
    }
    else if (*piVar1 == 0) {
      malloc(0x800);
      if (unaff_D7 == (undefined4 *)0x0) {
        zap_ptr(param_1 + 8,mfree);
      }
      else {
        *piVar1 = (int)unaff_D7;
      }
    }
  }
  return;
}


// ==== h_sghswp @ 0101ee5a

undefined4 h_sghswp(int param_1)

{
  undefined4 uVar1;
  int unaff_D7;
  
  if (param_1 != 0) {
    uVar1 = *(undefined4 *)(param_1 + 8);
    *(undefined4 *)(param_1 + 8) = *(undefined4 *)(param_1 + 0xc);
    *(undefined4 *)(param_1 + 0xc) = uVar1;
    h_sghset(param_1);
    if (-1 < unaff_D7) {
      return *(undefined4 *)(param_1 + 8);
    }
  }
  return 0;
}


// ==== h_sghavl @ 0101ee94

void h_sghavl(void)

{
  return;
}


// ==== h_skfdir @ 0101eef4

int h_skfdir(int param_1,short param_2)

{
  int *piVar1;
  int unaff_D7;
  
  h_sghckn(param_1,(int)param_2);
  if ((-1 < unaff_D7) && (h_sghset(param_1), -1 < unaff_D7)) {
    h_skdfsub(param_1,(int)param_2);
    if (-1 < unaff_D7) {
      piVar1 = *(int **)(param_1 + 8);
      *(short *)((int)piVar1 + 0xe) = param_2;
      *(short *)(piVar1 + 4) = *(short *)((int)piVar1 + 10) - (short)unaff_D7;
      return *piVar1 + unaff_D7 * 0x20;
    }
    h_zapsgh(param_1 + 8);
  }
  return 0;
}


// ==== h_skdfsub @ 0101ef6a

void h_skdfsub(int param_1,short param_2)

{
  int unaff_D7;
  int iVar1;
  
  h_sghavl(param_1,(int)param_2);
  if ((unaff_D7 < 0) && (h_sghswp(param_1), unaff_D7 != 0)) {
    iVar1 = (int)param_2;
    h_sghavl(param_1,iVar1);
    if ((unaff_D7 < 0) &&
       ((h_sghfls(param_1), -1 < unaff_D7 && (h_sghsno(param_1,iVar1), -1 < unaff_D7)))) {
      *(int *)(*(int *)(param_1 + 8) + 6) = unaff_D7;
      h_sghchg(param_1);
      if (-1 < unaff_D7) {
        h_sghavl(param_1,iVar1);
      }
    }
  }
  return;
}


// ==== h_sghchg @ 0101effa

void h_sghchg(int param_1)

{
  int *piVar1;
  undefined2 uVar2;
  int unaff_D7;
  
  if (((param_1 != 0) && (piVar1 = *(int **)(param_1 + 8), piVar1 != (int *)0x0)) &&
     (h_rwstrn(2,(int)*(char *)(param_1 + 0x32),*(undefined4 *)((int)piVar1 + 6),
               0x800 / **(ushort **)(param_1 + 0x1c),*piVar1), -1 < unaff_D7)) {
    *(undefined1 *)(piVar1 + 1) = 1;
    *(undefined2 *)(piVar1 + 4) = *(undefined2 *)((int)piVar1 + 10);
    uVar2 = *(undefined2 *)(*piVar1 + 0x18);
    *(undefined2 *)(piVar1 + 3) = uVar2;
    *(undefined2 *)((int)piVar1 + 0xe) = uVar2;
  }
  return;
}


// ==== h_sghfls @ 0101f070

void h_sghfls(int param_1)

{
  int *piVar1;
  undefined2 uVar2;
  int unaff_D7;
  
  if ((((param_1 != 0) && (piVar1 = *(int **)(param_1 + 8), piVar1 != (int *)0x0)) &&
      (*(char *)(piVar1 + 1) < '\0')) &&
     (h_rwstrn(3,(int)*(char *)(param_1 + 0x32),*(undefined4 *)((int)piVar1 + 6),
               0x800 / **(ushort **)(param_1 + 0x1c),*piVar1), -1 < unaff_D7)) {
    *(byte *)(piVar1 + 1) = *(byte *)(piVar1 + 1) & 0x7f;
    *(undefined2 *)(piVar1 + 4) = *(undefined2 *)((int)piVar1 + 10);
    uVar2 = *(undefined2 *)(*piVar1 + 0x18);
    *(undefined2 *)(piVar1 + 3) = uVar2;
    *(undefined2 *)((int)piVar1 + 0xe) = uVar2;
  }
  return;
}


// ==== h_read @ 0101f0f4

void h_read(undefined4 param_1,short param_2,int param_3)

{
  int iVar1;
  undefined1 uVar2;
  int unaff_D7;
  
  uVar2 = 0;
  h_fcb((int)param_2);
  iVar1 = -10;
  if (unaff_D7 != 0) {
    if (*(char *)(unaff_D7 + 0x1b) == '\0') {
      iVar1 = -2;
    }
    else {
      uVar2 = *(undefined1 *)(*(int *)(unaff_D7 + 4) + 0x32);
      if ((*(byte *)(unaff_D7 + 0xc) & 1) != 0) {
        if (param_3 == 0) {
          iVar1 = 0;
        }
        else {
          h_rdsub();
          iVar1 = unaff_D7;
        }
      }
    }
  }
  mkdoserr(uVar2,iVar1);
  return;
}


// ==== h_rdsub @ 0101f168

void h_rdsub(int param_1,uint param_2,int param_3)

{
  uint unaff_D7;
  
  if (*(uint *)(param_1 + 0x12) < param_2) {
    param_2 = *(uint *)(param_1 + 0x12);
  }
  h_rdfio(param_1,param_2,param_3);
  if (-1 < (int)unaff_D7) {
    param_2 = param_2 - unaff_D7;
    if (0 < (int)param_2) {
      h_rsize(*(undefined4 *)(*(int *)(param_1 + 4) + 0x1c));
      h_rdbuf(param_1,unaff_D7 * (param_2 / unaff_D7),unaff_D7 + param_3);
      if (-1 < (int)unaff_D7) {
        h_skfcb(param_1,*(int *)(param_1 + 0x16) + unaff_D7);
        if (0 < (int)(param_2 - unaff_D7)) {
          h_rdfio(param_1,param_2 - unaff_D7,unaff_D7 + unaff_D7 + param_3);
        }
      }
    }
  }
  return;
}


// ==== h_write @ 0101f21c

void h_write(undefined4 param_1,short param_2,int param_3)

{
  int iVar1;
  undefined1 uVar2;
  int unaff_D7;
  
  uVar2 = 0;
  h_fcb((int)param_2);
  iVar1 = -10;
  if (((unaff_D7 != 0) && (iVar1 = -2, *(char *)(unaff_D7 + 0x1b) != '\0')) &&
     (uVar2 = *(undefined1 *)(*(int *)(unaff_D7 + 4) + 0x32), (*(byte *)(unaff_D7 + 0xc) & 2) != 0))
  {
    if (param_3 == 0) {
      iVar1 = 0;
    }
    else {
      h_wrsub();
      iVar1 = unaff_D7;
    }
  }
  mkdoserr(uVar2,iVar1);
  return;
}


// ==== h_wrsub @ 0101f28e

void h_wrsub(int param_1,int param_2,int param_3)

{
  uint uVar1;
  uint unaff_D7;
  
  h_wrfio(param_1,param_2,param_3);
  if (-1 < (int)unaff_D7) {
    uVar1 = param_2 - unaff_D7;
    if (0 < (int)uVar1) {
      h_rsize(*(undefined4 *)(*(int *)(param_1 + 4) + 0x1c));
      h_wrbuf(param_1,unaff_D7 * (uVar1 / unaff_D7),unaff_D7 + param_3);
      if (-1 < (int)unaff_D7) {
        if (*(uint *)(param_1 + 0x12) <= unaff_D7 + *(int *)(param_1 + 0x16)) {
          *(uint *)(param_1 + 0x12) = unaff_D7 + *(int *)(param_1 + 0x16);
        }
        h_skfcb(param_1,*(int *)(param_1 + 0x16) + unaff_D7);
        if (0 < (int)(uVar1 - unaff_D7)) {
          h_wrfio(param_1,uVar1 - unaff_D7,unaff_D7 + unaff_D7 + param_3);
        }
      }
    }
  }
  return;
}


// ==== h_seek @ 0101f34a

void h_seek(undefined4 param_1,short param_2)

{
  undefined1 uVar1;
  uint unaff_D7;
  uint uVar2;
  
  uVar1 = 0;
  h_fcb((int)param_2);
  uVar2 = 0xfffffff6;
  if (unaff_D7 != 0) {
    if (*(char *)(unaff_D7 + 0x1b) == '\0') {
      uVar2 = 0xfffffffe;
    }
    else {
      uVar1 = *(undefined1 *)(*(int *)(unaff_D7 + 4) + 0x32);
      if ((*(byte *)(unaff_D7 + 0xc) & 3) != 2) {
        h_bbasset();
        uVar2 = unaff_D7;
        if (-1 < (int)unaff_D7) {
          h_target();
          uVar2 = 0xfffffffa;
          if ((-1 < (int)unaff_D7) && (unaff_D7 < *(uint *)(unaff_D7 + 0x12))) {
            h_skfcb();
            uVar2 = unaff_D7;
            if (-1 < (int)unaff_D7) {
              uVar2 = (uint)param_2;
            }
          }
        }
      }
    }
  }
  mkdoserr(uVar1,uVar2);
  return;
}


// ==== h_target @ 0101f3f0

int h_target(int param_1,int param_2,int param_3)

{
  int iVar1;
  
  if (param_1 == 0) {
    return -10;
  }
  if (param_2 == 1) {
    iVar1 = *(int *)(param_1 + 0x16);
  }
  else {
    if (param_2 < 2) {
      if (param_2 == 0) {
        return param_3;
      }
      return -10;
    }
    if (param_2 != 2) {
      return -10;
    }
    iVar1 = *(int *)(param_1 + 0x12);
  }
  return param_3 + iVar1;
}


// ==== h_scanent @ 0101f434

void h_scanent(undefined4 param_1,undefined4 param_2,short param_3)

{
  int unaff_D7;
  
  if (param_3 == 0x7f) {
    h_vlscan(param_1);
  }
  else {
    h_lnseek(param_1,0);
    while (-1 < unaff_D7) {
      h_enscan(param_1,param_2,(int)(short)unaff_D7,param_3);
      if (unaff_D7 < 0) {
        return;
      }
      if (unaff_D7 == 0) {
        h_lnread(param_1);
        return;
      }
      h_lnseek(param_1,1);
    }
  }
  return;
}


// ==== h_vlscan @ 0101f4b4

undefined4 h_vlscan(undefined4 param_1)

{
  undefined4 uVar1;
  int unaff_D7;
  
  h_skdir(param_1,0);
  if (unaff_D7 == 0) {
    uVar1 = 0xfffffff7;
  }
  else {
    uVar1 = 0;
  }
  return uVar1;
}


// ==== h_enscan @ 0101f4d6

void h_enscan(undefined4 param_1,undefined4 param_2,short param_3,undefined4 param_4)

{
  int unaff_D7;
  
  h_chkent(param_1,(int)param_3);
  if (-1 < unaff_D7) {
    if (unaff_D7 < 1) {
      h_flscan(param_1,param_2,(int)param_3,param_4);
    }
    else {
      h_drscan(param_1,param_2,(int)param_3,param_4);
    }
  }
  return;
}


// ==== h_chkent @ 0101f538

void h_chkent(void)

{
  return;
}


// ==== h_drscan @ 0101f58e

undefined4 h_drscan(undefined4 param_1,undefined4 param_2,short param_3)

{
  undefined4 uVar1;
  int unaff_D7;
  
  h_skdir(param_1,(int)param_3);
  if ((unaff_D7 == 0) || ((*(byte *)(unaff_D7 + 0xb) & 1) != 0)) {
    uVar1 = 0xfffffff7;
  }
  else {
    cmpbuf(param_2);
    if (unaff_D7 == 1) {
      uVar1 = 0;
    }
    else {
      uVar1 = 1;
    }
  }
  return uVar1;
}


// ==== h_flscan @ 0101f5da

undefined4 h_flscan(undefined4 param_1,undefined4 param_2,short param_3,int param_4)

{
  undefined4 uVar1;
  int unaff_D7;
  
  h_skdir(param_1,(int)param_3);
  if ((unaff_D7 == 0) || ((*(byte *)(unaff_D7 + 0xb) & 1) != 0)) {
    uVar1 = 0xfffffff7;
  }
  else {
    if (((param_4 == 0x7e) || (-1 < *(char *)(unaff_D7 + 0xb))) && (cmpbuf(param_2), unaff_D7 == 1))
    {
      return 0;
    }
    uVar1 = 1;
  }
  return uVar1;
}


// ==== h_lnadd @ 0101f636

void h_lnadd(int param_1,short param_2,undefined1 param_3)

{
  short *psVar1;
  int iVar2;
  int unaff_D7;
  
  if ((((param_1 != 0) && (iVar2 = *(int *)(param_1 + 0x24), *(short *)(iVar2 + 8) < 0x480)) &&
      (h_lnscan(param_1,(int)param_2), unaff_D7 < 0)) &&
     (h_lnascn(param_1,(int)param_2), -1 < unaff_D7)) {
    psVar1 = (short *)(*(int *)(iVar2 + 2) + unaff_D7 * 2);
    cpydataba(psVar1,psVar1 + 1,(*(short *)(iVar2 + 8) - unaff_D7) * 2);
    *psVar1 = param_2;
    *(short *)(iVar2 + 8) = *(short *)(iVar2 + 8) + 1;
    *(byte *)(iVar2 + 6) = *(byte *)(iVar2 + 6) | 0x80;
    h_lnseek(param_1,0);
    h_cdrfls(param_1,param_3);
  }
  return;
}


// ==== h_lndel @ 0101f6e6

void h_lndel(int param_1,short param_2,undefined1 param_3)

{
  int iVar1;
  int iVar2;
  int unaff_D7;
  
  if (((param_1 != 0) && (iVar2 = *(int *)(param_1 + 0x24), *(short *)(iVar2 + 8) != 0)) &&
     (h_lnscan(param_1,(int)param_2), -1 < unaff_D7)) {
    iVar1 = *(int *)(iVar2 + 2) + unaff_D7 * 2;
    cpydata(iVar1 + 2,iVar1,(*(short *)(iVar2 + 8) - unaff_D7) * 2);
    *(short *)(iVar2 + 8) = *(short *)(iVar2 + 8) + -1;
    *(byte *)(iVar2 + 6) = *(byte *)(iVar2 + 6) | 0x80;
    h_lnseek(param_1,0);
    h_cdrfls(param_1,param_3);
  }
  return;
}


// ==== h_lnascn @ 0101f778

undefined2 h_lnascn(int param_1,short param_2)

{
  undefined2 uVar1;
  int unaff_D7;
  
  uVar1 = h_lnseek(param_1,0);
  while( true ) {
    if (unaff_D7 == -3) {
      return *(undefined2 *)(*(int *)(param_1 + 0x24) + 8);
    }
    if (unaff_D7 < 0) {
      return uVar1;
    }
    if (param_2 == unaff_D7) {
      return uVar1;
    }
    if (param_2 < unaff_D7) break;
    uVar1 = h_lnseek(param_1,1);
  }
  return *(undefined2 *)(*(int *)(param_1 + 0x24) + 10);
}


// ==== h_lnseek @ 0101f7e2

void h_lnseek(int param_1,int param_2)

{
  int iVar1;
  short sVar2;
  
  if (param_1 != 0) {
    iVar1 = *(int *)(param_1 + 0x24);
    if (param_2 == 0) {
      *(undefined2 *)(iVar1 + 10) = 0;
      *(undefined2 *)(iVar1 + 0xc) = *(undefined2 *)(iVar1 + 8);
      if (*(short *)(iVar1 + 8) == 0) {
        return;
      }
    }
    else {
      sVar2 = *(short *)(iVar1 + 10) + (short)param_2;
      if (sVar2 < 0) {
        return;
      }
      if (*(short *)(iVar1 + 8) <= sVar2) {
        return;
      }
      *(short *)(iVar1 + 10) = sVar2;
      *(short *)(iVar1 + 0xc) = *(short *)(iVar1 + 8) - sVar2;
    }
    h_lnread(param_1);
  }
  return;
}


// ==== h_lnread @ 0101f842

void h_lnread(void)

{
  return;
}


// ==== h_lnscan @ 0101f862

undefined2 h_lnscan(int param_1,short param_2)

{
  undefined2 uVar1;
  int unaff_D7;
  undefined4 uVar2;
  
  uVar2 = 0;
  while( true ) {
    uVar1 = h_lnseek(param_1,uVar2);
    if (unaff_D7 < 0) {
      return uVar1;
    }
    if (param_2 == unaff_D7) break;
    uVar2 = 1;
  }
  return *(undefined2 *)(*(int *)(param_1 + 0x24) + 10);
}


// ==== h_geoidx @ 0101f8a8

int h_geoidx(int param_1,int param_2,int param_3)

{
  return param_3 + param_2 * (uint)*(byte *)(param_1 + 3);
}


// ==== h_dcnfg @ 0101f8d6

void h_dcnfg(undefined4 param_1)

{
  uint uVar1;
  uint uVar2;
  int iVar3;
  ushort *unaff_D7;
  undefined4 unaff_A6;
  undefined1 auStack_2c [36];
  byte local_8;
  undefined1 uStack_7;
  ushort uStack_6;
  undefined1 local_4;
  undefined1 uStack_3;
  undefined2 uStack_2;
  
  local_4 = (undefined1)((uint)unaff_A6 >> 0x18);
  uStack_3 = (undefined1)((uint)unaff_A6 >> 0x10);
  uStack_2 = (undefined2)unaff_A6;
  h_inquiry(param_1,auStack_2c);
  if (-1 < (int)unaff_D7) {
    h_selinf(auStack_2c);
    iVar3 = (*(byte *)(unaff_D7 + 1) & 0x3f) << 0x16;
    local_8 = (byte)((uint)iVar3 >> 0x18) | (byte)(((*unaff_D7 & 3) << 0x1c) >> 0x18);
    uStack_7 = (undefined1)((uint)iVar3 >> 0x10);
    uVar2 = CONCAT31(CONCAT12(uStack_7,uStack_6),local_4) & 0xc00fffff;
    uVar1 = uVar2 | (unaff_D7[2] & 0x3ff) << 0x14;
    uStack_7 = (undefined1)(uVar1 >> 0x18);
    uStack_6 = (ushort)(uVar1 >> 8);
    local_4 = (undefined1)uVar2;
    uVar1 = CONCAT31(CONCAT21(uStack_6,local_4),uStack_3) & 0xf1ffffff;
    uStack_6 = (ushort)(uVar1 >> 0x10) |
               (ushort)(((*(byte *)((int)unaff_D7 + 3) & 7) << 0x19) >> 0x10);
    local_4 = (undefined1)(uVar1 >> 8);
    uStack_3 = (undefined1)uVar1;
    unaff_D7 = (ushort *)CONCAT22(CONCAT11(local_8,uStack_7),uStack_6);
  }
  mkdoserr(param_1,unaff_D7);
  return;
}


// ==== h_rdsct @ 0101f960

void h_rdsct(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  bool bVar1;
  int iVar2;
  int unaff_D7;
  
  h_dph(param_1);
  bVar1 = *(char *)(unaff_D7 + 0x33) < '\x01';
  h_geoidx(*(undefined4 *)(unaff_D7 + 0x1c),param_2,param_3,param_4);
  iVar2 = 0;
  if (bVar1) {
    h_motor(0xb,param_1);
    iVar2 = unaff_D7;
  }
  if (-1 < iVar2) {
    h_rwstrn(2,param_1);
    iVar2 = unaff_D7;
  }
  if (bVar1) {
    h_motor(0xc,param_1);
  }
  mkdoserr(param_1,iVar2);
  return;
}


// ==== h_wrsct @ 0101fa00

void h_wrsct(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5)

{
  char cVar1;
  int iVar2;
  int unaff_D7;
  
  h_dph(param_2);
  cVar1 = *(char *)(unaff_D7 + 0x33);
  h_geoidx(*(undefined4 *)(unaff_D7 + 0x1c),param_3,param_4,param_5);
  if (cVar1 < '\x01') {
    h_motor(0xb,param_2);
    iVar2 = unaff_D7;
  }
  else {
    h_zapall(param_2,param_1,0);
    iVar2 = 0;
  }
  if (-1 < iVar2) {
    h_rwstrn(3,param_2);
    h_motor(0xc,param_2);
    iVar2 = unaff_D7;
  }
  mkdoserr(param_2,iVar2);
  return;
}


// ==== h_almapse @ 0101faac

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void h_almapse(int param_1)

{
  ushort *puVar1;
  ushort uVar2;
  byte bVar3;
  uint uVar4;
  size_t __size;
  int unaff_D7;
  undefined4 local_8;
  
  puVar1 = *(ushort **)(param_1 + 0x1c);
  uVar2 = puVar1[8];
  bVar3 = *(byte *)(puVar1 + 4);
  _fcnt = 0;
  timset(0,2,&fcnt);
  if (*(int *)(param_1 + 0x18) == 0) {
    uVar4 = *(int *)(puVar1 + 0xc) + *(int *)(puVar1 + 0xe) + *(int *)(puVar1 + 10);
    __size = (uint)*puVar1 * (uVar4 / *puVar1 + (uint)(uVar4 % (uint)*puVar1 != 0));
    malloc(__size);
    *(int *)(param_1 + 0x18) = unaff_D7;
    if (unaff_D7 == 0) {
      return;
    }
    fill(*(undefined4 *)(param_1 + 0x18),__size,0);
    *(int *)(param_1 + 0x28) = *(int *)(puVar1 + 10) + *(int *)(param_1 + 0x18);
    *(int *)(param_1 + 0x2c) = *(int *)(puVar1 + 0xe) + *(int *)(param_1 + 0x28);
  }
  malloc((uint)*(byte *)(puVar1 + 4) * (uint)*puVar1);
  if (unaff_D7 != 0) {
    h_initmap(param_1);
    mfree();
    if (-1 < unaff_D7) {
      h_blkcnt(*(undefined4 *)(param_1 + 0x18),(uint)uVar2 / (uint)bVar3,
               (uint)puVar1[8] / (uint)*(byte *)(puVar1 + 4) + (int)(short)puVar1[9]);
      *(short *)(param_1 + 0x30) = (short)unaff_D7;
    }
    ggtim(0,&local_8);
    dumdisp(local_8);
  }
  return;
}


// ==== dumdisp @ 0101fc08

void dumdisp(void)

{
  return;
}


// ==== h_blkcnt @ 0101fc10

void h_blkcnt(undefined4 param_1,int param_2,int param_3)

{
  for (; param_2 < param_3; param_2 = param_2 + 1) {
  }
  return;
}


// ==== h_mapscn @ 0101fc58

void h_mapscn(int param_1,uint param_2,uint param_3)

{
  uint uVar1;
  byte *pbVar2;
  uint uVar3;
  uint uVar4;
  
  uVar4 = 0xfffffff4;
  if (param_3 <= param_2) {
    return;
  }
  uVar3 = param_2 & 7;
  uVar1 = 0x80 >> uVar3 & 0xff;
  pbVar2 = (byte *)((param_2 >> 3) + param_1);
  do {
    while ((param_3 <= param_2 || (7 < uVar3))) {
LAB_0101fcc6:
      if (-1 < (int)uVar4) {
        return;
      }
      if (param_3 <= param_2) {
        return;
      }
      uVar1 = 0x80;
      pbVar2 = pbVar2 + 1;
      uVar3 = 0;
    }
    dbgdsp(pbVar2,*pbVar2,uVar1,param_2);
    if (((byte)uVar1 & *pbVar2) == 0) {
      uVar4 = param_2;
      goto LAB_0101fcc6;
    }
    uVar1 = (uint)(byte)((byte)uVar1 >> 1);
    uVar3 = uVar3 + 1;
    param_2 = param_2 + 1;
  } while( true );
}


// ==== dbgdsp @ 0101fce6

void dbgdsp(void)

{
  return;
}


// ==== h_maonof @ 0101fcee

void h_maonof(uint param_1,int param_2,short param_3)

{
  if (param_3 == 0) {
    *(byte *)(param_2 + (param_1 >> 3)) =
         *(byte *)(param_2 + (param_1 >> 3)) & ~(byte)(0x80 >> (param_1 & 7));
  }
  else {
    *(byte *)(param_2 + (param_1 >> 3)) =
         *(byte *)(param_2 + (param_1 >> 3)) | (byte)(0x80 >> (param_1 & 7));
  }
  return;
}


// ==== h_mapcnt @ 0101fd3c

void h_mapcnt(int param_1,short param_2)

{
  int unaff_D7;
  
  h_fenmap(*(undefined4 *)(param_1 + 4),(int)*(short *)(param_1 + 0x1e),param_2);
  if ((-1 < unaff_D7) && (h_eenmst(param_1,param_2), param_2 == 0)) {
    h_resmap(param_1,0);
  }
  return;
}


// ==== h_fenmap @ 0101fd9c

void h_fenmap(int param_1,ushort param_2,undefined2 param_3)

{
  int iVar1;
  int unaff_D7;
  
  iVar1 = *(int *)(param_1 + 0x1c);
  h_chkent(param_1,(int)(short)param_2);
  if (unaff_D7 == 0x4000) {
    param_2 = *(short *)(iVar1 + 0xc) + (param_2 & 0xbfff);
  }
  else if (unaff_D7 != 0) {
    return;
  }
  h_maonof((int)(short)param_2,*(undefined4 *)(param_1 + 0x2c),param_3);
  return;
}


// ==== h_eenmst @ 0101fdfe

void h_eenmst(int param_1,undefined2 param_2)

{
  undefined4 uVar1;
  short sVar2;
  short sVar3;
  int unaff_D7;
  
  uVar1 = *(undefined4 *)(param_1 + 4);
  h_skdir(uVar1,(int)*(short *)(param_1 + 0x1e));
  if ((unaff_D7 != 0) && ((*(short *)(unaff_D7 + 0x1e) != 0 || (*(short *)(unaff_D7 + 0x1c) != 0))))
  {
    sVar2 = *(short *)(unaff_D7 + 0x1e);
    sVar3 = *(short *)(unaff_D7 + 0x1c);
    while (((h_skeeh(uVar1,(int)sVar3), unaff_D7 != 0 &&
            (h_eenmap(uVar1,(int)sVar3,param_2), -1 < unaff_D7)) && (sVar3 != sVar2))) {
      sVar3 = *(short *)(unaff_D7 + 6);
    }
  }
  return;
}


// ==== h_eenmap @ 0101fe88

void h_eenmap(int param_1,short param_2,undefined2 param_3)

{
  if ((-1 < param_2) && (param_2 < *(short *)(*(int *)(param_1 + 0x1c) + 10))) {
    h_maonof((int)param_2,*(undefined4 *)(param_1 + 0x28),param_3);
  }
  return;
}


// ==== h_mbset @ 0101fec6

void h_mbset(int param_1,ushort param_2,ushort param_3)

{
  byte *pbVar1;
  byte unaff_D7b;
  int iVar2;
  ushort uVar3;
  byte *pbVar4;
  
  pbVar1 = (byte *)(*(int *)(param_1 + 0x18) + (int)((short)param_2 >> 3));
  pbVar4 = pbVar1;
  if ((param_2 & 7) != 0) {
    iVar2 = 8 - (param_2 & 7);
    if ((short)param_3 < iVar2) {
      uVar3 = param_3;
    }
    else {
      uVar3 = (ushort)iVar2;
    }
    mkmask(iVar2,iVar2 - (short)uVar3);
    unaff_D7b = *pbVar1 | unaff_D7b;
    pbVar4 = pbVar1 + 1;
    *pbVar1 = unaff_D7b;
    param_3 = param_3 - uVar3;
  }
  for (iVar2 = (int)((short)param_3 >> 3); 0 < iVar2; iVar2 = iVar2 + -1) {
    *pbVar4 = 0xff;
    param_3 = param_3 - 8;
    pbVar4 = pbVar4 + 1;
  }
  if ((param_3 & 7) != 0) {
    if (7 < (short)param_3) {
      param_3 = 8;
    }
    mkmask(8,8 - (short)param_3);
    *pbVar4 = *pbVar4 | unaff_D7b;
  }
  return;
}


// ==== h_mbclr @ 0101ff62

void h_mbclr(int param_1,ushort param_2,ushort param_3)

{
  byte *pbVar1;
  byte unaff_D7b;
  int iVar2;
  ushort uVar3;
  byte *pbVar4;
  
  pbVar1 = (byte *)(*(int *)(param_1 + 0x18) + (int)((short)param_2 >> 3));
  pbVar4 = pbVar1;
  if ((param_2 & 7) != 0) {
    iVar2 = 8 - (param_2 & 7);
    if ((short)param_3 < iVar2) {
      uVar3 = param_3;
    }
    else {
      uVar3 = (ushort)iVar2;
    }
    mkmask(iVar2,iVar2 - (short)uVar3);
    unaff_D7b = *pbVar1 & ~unaff_D7b;
    pbVar4 = pbVar1 + 1;
    *pbVar1 = unaff_D7b;
    param_3 = param_3 - uVar3;
  }
  for (iVar2 = (int)((short)param_3 >> 3); 0 < iVar2; iVar2 = iVar2 + -1) {
    *pbVar4 = 0;
    param_3 = param_3 - 8;
    pbVar4 = pbVar4 + 1;
  }
  if ((param_3 & 7) != 0) {
    if (7 < (short)param_3) {
      param_3 = 8;
    }
    mkmask(8,8 - (short)param_3);
    *pbVar4 = *pbVar4 & ~unaff_D7b;
  }
  return;
}


// ==== h_mbcnt @ 01020000

void h_mbcnt(int param_1,ushort param_2,byte param_3)

{
  byte *pbVar1;
  byte *pbVar2;
  uint uVar3;
  byte unaff_D6b;
  uint unaff_D7;
  byte *pbVar4;
  int iVar5;
  uint uVar6;
  int iVar7;
  byte local_9;
  
  iVar5 = *(int *)(param_1 + 0x1c);
  uVar6 = 8 - ((uint)*(ushort *)(iVar5 + 0x10) / (uint)*(byte *)(iVar5 + 8) +
               (int)*(short *)(iVar5 + 0x12) & 7) & 7;
  pbVar1 = (byte *)(*(int *)(param_1 + 0x18) + (int)((short)param_2 >> 3));
  pbVar2 = (byte *)(*(int *)(iVar5 + 0x14) + -1 + *(int *)(param_1 + 0x18));
  if (pbVar2 < pbVar1) {
    return;
  }
  if ((param_3 & 1) == 0) {
    local_9 = 0;
  }
  else {
    local_9 = 0xff;
  }
  iVar5 = 8 - (param_2 & 7);
  if (pbVar2 == pbVar1) {
    mkmask(iVar5,uVar6);
    h_mbcntb(iVar5,uVar6,*pbVar1,local_9,unaff_D7 + (1 << uVar6));
    return;
  }
  pbVar4 = pbVar1;
  if ((param_2 & 7) != 0) {
    mkmask(iVar5,0);
    pbVar4 = pbVar1 + 1;
    unaff_D6b = *pbVar1;
    uVar3 = (uint)unaff_D6b;
    if ((unaff_D7 & local_9) != (unaff_D7 & uVar3)) {
      iVar7 = unaff_D7 + 1;
      uVar6 = 0;
      goto LAB_01020158;
    }
  }
  for (; (pbVar4 <= pbVar2 && (unaff_D6b = *pbVar4, unaff_D6b == local_9)); pbVar4 = pbVar4 + 1) {
  }
  if (pbVar4 < pbVar2) {
    uVar6 = 0;
  }
  else if (pbVar2 != pbVar4) {
    uVar6 = 8;
  }
  iVar7 = 0x100;
  uVar3 = (uint)unaff_D6b;
  iVar5 = 8;
LAB_01020158:
  h_mbcntb(iVar5,uVar6,uVar3,local_9,iVar7);
  return;
}


// ==== h_mbcntb @ 0102016c

void h_mbcntb(int param_1,int param_2,byte param_3,byte param_4,uint param_5)

{
  do {
    param_1 = param_1 + -1;
    if (param_1 < param_2) {
      return;
    }
    param_5 = param_5 >> 1;
  } while ((param_5 & param_4) == (param_5 & param_3));
  return;
}


// ==== h_setmap @ 010201be

void h_setmap(int param_1,short param_2)

{
  int iVar1;
  short sVar2;
  short sVar3;
  short sVar4;
  int unaff_D7;
  short local_6;
  
  iVar1 = *(int *)(param_1 + 4);
  sVar4 = *(short *)(*(int *)(iVar1 + 0x1c) + 0x12);
  sVar2 = *(short *)(iVar1 + 0x30);
  h_opnent(*(undefined4 *)(iVar1 + 0x28),(int)*(short *)(*(int *)(iVar1 + 0x1c) + 10));
  sVar3 = (short)unaff_D7;
  if ((param_2 <= (short)(sVar4 - sVar2)) && (param_2 <= sVar3)) {
    do {
      if (param_2 < 1) {
        return;
      }
      h_nxfrbk(iVar1,(int)param_2,&local_6);
      if (local_6 < param_2) {
        sVar4 = local_6;
      }
      else {
        sVar4 = param_2;
      }
      h_mbset(iVar1,(int)sVar3,(int)sVar4);
      param_2 = param_2 - sVar4;
      *(short *)(iVar1 + 0x30) = sVar4 + *(short *)(iVar1 + 0x30);
      h_grwent(param_1,(int)sVar3,(int)sVar4);
    } while (0 < unaff_D7);
  }
  return;
}


// ==== h_opnent @ 0102028e

uint h_opnent(int param_1,ushort param_2)

{
  int iVar1;
  uint uVar2;
  uint uVar3;
  
  uVar2 = (uint)param_2;
  uVar3 = 0;
  if (0 < (short)param_2) {
    do {
      iVar1 = 0x80 >> (uVar3 & 7);
      uVar2 = CONCAT31((int3)((uint)iVar1 >> 8),*(byte *)(param_1 + ((int)uVar3 >> 3)) & (byte)iVar1
                      );
      uVar3 = uVar3 + 1;
    } while ((int)uVar3 < (int)(short)param_2);
  }
  return uVar2;
}


// ==== h_nxfrbk @ 010202de

void h_nxfrbk(int param_1,undefined4 param_2,short *param_3)

{
  short sVar1;
  ushort uVar2;
  byte bVar3;
  ushort uVar4;
  short sVar5;
  short unaff_D7w;
  
  sVar1 = *(short *)(*(int *)(param_1 + 0x1c) + 0x12);
  uVar2 = *(ushort *)(*(int *)(param_1 + 0x1c) + 0x10);
  bVar3 = *(byte *)(*(int *)(param_1 + 0x1c) + 8);
  sVar5 = 0;
  for (uVar4 = *(ushort *)(*(int *)(param_1 + 0x1c) + 0x10) /
               (ushort)*(byte *)(*(int *)(param_1 + 0x1c) + 8);
      (int)(short)uVar4 < (int)((uint)uVar2 / (uint)bVar3 + (int)sVar1); uVar4 = unaff_D7w + uVar4)
  {
    h_mbcnt(param_1,(int)(short)uVar4,0);
    if (unaff_D7w < 1) {
      h_mbcnt(param_1,(int)(short)uVar4,1);
    }
    else if (sVar5 < unaff_D7w) {
      sVar5 = unaff_D7w;
    }
  }
  *param_3 = sVar5;
  return;
}


// ==== h_grwxsb @ 0102038e

void h_grwxsb(int param_1,short *param_2,int param_3)

{
  short sVar1;
  short *unaff_D7;
  int iVar2;
  
  if (((param_3 != 0) && (h_nwxtnt(param_1), -1 < (int)unaff_D7)) &&
     (h_skeeh(param_1), unaff_D7 != (short *)0x0)) {
    sVar1 = (short)unaff_D7;
    *unaff_D7 = sVar1;
    *(short *)(param_3 + 0x1e) = sVar1;
    h_eenmap(param_1,(int)sVar1,0xffffffff);
    if (param_2 == (short *)0x0) {
      *(short *)(param_3 + 0x1c) = *unaff_D7;
    }
    else {
      unaff_D7[1] = param_2[1] + 1;
      unaff_D7[2] = *param_2;
      *(byte *)(*(int *)(param_1 + 0x10) + 4) = *(byte *)(*(int *)(param_1 + 0x10) + 4) | 0x80;
      h_skeeh(param_1,(int)*param_2);
      if (unaff_D7 != (short *)0x0) {
        unaff_D7[3] = *unaff_D7;
        *(byte *)(*(int *)(param_1 + 0x10) + 4) = *(byte *)(*(int *)(param_1 + 0x10) + 4) | 0x80;
      }
    }
    h_chkent(param_1,(int)*(short *)(param_3 + 0x18));
    if ((int)unaff_D7 < 1) {
      iVar2 = *(int *)(param_1 + 8);
    }
    else {
      iVar2 = *(int *)(param_1 + 0x20);
    }
    *(byte *)(iVar2 + 4) = *(byte *)(iVar2 + 4) | 0x80;
  }
  return;
}


// ==== h_grwent @ 01020480

void h_grwent(int param_1,undefined4 param_2,short param_3)

{
  int iVar1;
  int iVar2;
  int unaff_D7;
  
  iVar1 = *(int *)(param_1 + 4);
  h_skdir(iVar1,(int)*(short *)(param_1 + 0x1e));
  if (unaff_D7 != 0) {
    iVar2 = 0;
    if (*(short *)(unaff_D7 + 0x1e) != 0) {
      h_skeeh(iVar1,(int)*(short *)(unaff_D7 + 0x1e));
      h_exxon();
      param_3 = param_3 - (short)unaff_D7;
      *(byte *)(*(int *)(iVar1 + 0x10) + 4) = *(byte *)(*(int *)(iVar1 + 0x10) + 4) | 0x80;
      iVar2 = unaff_D7;
    }
    if (0 < param_3) {
      h_grwxsb(iVar1,iVar2);
      h_grwxlp(iVar1);
    }
  }
  return;
}


// ==== h_grwxlp @ 0102054e

void h_grwxlp(int param_1,int param_2,undefined4 param_3,short param_4,short param_5)

{
  int unaff_D7;
  
  while( true ) {
    if (param_2 == 0) {
      return;
    }
    h_exxon(param_2,(int)param_4,(int)param_5);
    param_5 = param_5 - (short)unaff_D7;
    param_4 = (short)unaff_D7 + param_4;
    *(byte *)(*(int *)(param_1 + 0x10) + 4) = *(byte *)(*(int *)(param_1 + 0x10) + 4) | 0x80;
    if (param_5 < 1) break;
    h_grwxsb(param_1,param_2,param_3);
    param_2 = unaff_D7;
  }
  return;
}


// ==== h_srhblk @ 010205c8

void h_srhblk(int param_1,short param_2)

{
  short sVar1;
  int unaff_D7;
  
  sVar1 = *(short *)(param_1 + 0x20);
  h_skeeh(*(undefined4 *)(param_1 + 4),(int)sVar1);
  if (unaff_D7 != 0) {
    h_eexnum(param_1,(int)sVar1,(int)(param_2 / 0xc) - (int)*(short *)(unaff_D7 + 2));
  }
  return;
}


// ==== h_resmap @ 01020620

void h_resmap(int param_1,short param_2)

{
  undefined4 uVar1;
  short sVar2;
  int unaff_D7;
  
  uVar1 = *(undefined4 *)(param_1 + 4);
  h_skdir(uVar1,(int)*(short *)(param_1 + 0x1e));
  if ((unaff_D7 != 0) &&
     (((*(short *)(unaff_D7 + 0x1e) != 0 || (*(short *)(unaff_D7 + 0x1c) != 0)) &&
      (h_srhblk(param_1,(int)param_2), -1 < unaff_D7)))) {
    sVar2 = *(short *)(unaff_D7 + 0x1e);
    if ((short)unaff_D7 != sVar2) {
      while (h_skeeh(uVar1,(int)sVar2), unaff_D7 != 0) {
        sVar2 = *(short *)(unaff_D7 + 4);
        h_rsmpsb(param_1);
        if ((unaff_D7 < 0) || ((short)unaff_D7 == sVar2)) break;
      }
    }
    h_skeeh(uVar1,(int)sVar2);
    if (unaff_D7 != 0) {
      h_rsmpsb(param_1);
    }
  }
  return;
}


// ==== h_rsmpsb @ 010206ec

void h_rsmpsb(int param_1,short *param_2,int param_3)

{
  short sVar1;
  short sVar2;
  int iVar3;
  undefined2 *unaff_D7;
  int iVar4;
  
  iVar4 = *(int *)(param_1 + 4);
  for (iVar3 = param_3; (iVar3 < 0xc && (sVar1 = param_2[iVar3 + 4], sVar1 != 0));
      iVar3 = sVar2 + iVar3) {
    h_exxoff(param_2,iVar3);
    sVar2 = (short)unaff_D7;
    h_mbclr(iVar4,(int)sVar1,(int)sVar2);
    *(byte *)(*(int *)(iVar4 + 0x10) + 4) = *(byte *)(*(int *)(iVar4 + 0x10) + 4) | 0x80;
    *(short *)(iVar4 + 0x30) = *(short *)(iVar4 + 0x30) - sVar2;
  }
  if (param_3 == 0) {
    sVar2 = param_2[2];
    sVar1 = *param_2;
    param_2[1] = 0;
    param_2[2] = 0;
    param_2[3] = 0;
    *(byte *)(*(int *)(iVar4 + 0x10) + 4) = *(byte *)(*(int *)(iVar4 + 0x10) + 4) | 0x80;
    h_maonof((int)*param_2,*(undefined4 *)(iVar4 + 0x28),0);
    h_skdir(iVar4,(int)*(short *)(param_1 + 0x1e));
    if (unaff_D7 != (undefined2 *)0x0) {
      if (sVar2 == 0) {
        unaff_D7[0xf] = 0;
        unaff_D7[0xe] = 0;
        h_chkent(iVar4,(int)(short)unaff_D7[0xc]);
        if (unaff_D7 == (undefined2 *)0x4000) {
          iVar4 = *(int *)(iVar4 + 0x20);
        }
        else {
          iVar4 = *(int *)(iVar4 + 8);
        }
        *(byte *)(iVar4 + 4) = *(byte *)(iVar4 + 4) | 0x80;
        *(undefined2 *)(param_1 + 0x20) = 0;
      }
      else {
        h_skeeh(iVar4,(int)sVar2);
        if (unaff_D7 != (undefined2 *)0x0) {
          unaff_D7[0xf] = *unaff_D7;
          h_chkent(iVar4,(int)(short)unaff_D7[0xc]);
          if (unaff_D7 == (undefined2 *)0x4000) {
            iVar3 = *(int *)(iVar4 + 0x20);
          }
          else {
            iVar3 = *(int *)(iVar4 + 8);
          }
          *(byte *)(iVar3 + 4) = *(byte *)(iVar3 + 4) | 0x80;
          unaff_D7[3] = 0;
          *(byte *)(*(int *)(iVar4 + 0x10) + 4) = *(byte *)(*(int *)(iVar4 + 0x10) + 4) | 0x80;
          if (sVar1 == *(short *)(param_1 + 0x20)) {
            *(undefined2 *)(param_1 + 0x20) = *unaff_D7;
          }
        }
      }
    }
  }
  return;
}


// ==== h_kind @ 01020870

void h_kind(void)

{
  return;
}


// ==== h_remain @ 0102087a

void h_remain(undefined1 param_1)

{
  int iVar1;
  int unaff_D7;
  
  h_dph(param_1);
  iVar1 = -10;
  if (unaff_D7 != 0) {
    if (*(char *)(unaff_D7 + 0x33) < '\x01') {
      iVar1 = -4;
    }
    else {
      h_bkbyt(*(int *)(unaff_D7 + 0x1c),
              (int)*(short *)(*(int *)(unaff_D7 + 0x1c) + 0x12) - (int)*(short *)(unaff_D7 + 0x30));
      iVar1 = unaff_D7;
    }
  }
  mkdoserr(param_1,iVar1);
  return;
}


// ==== h_reman2 @ 010208d8

void h_reman2(undefined1 param_1)

{
  int iVar1;
  int iVar2;
  int unaff_D7;
  
  h_dph(param_1);
  iVar1 = *(int *)(unaff_D7 + 0x1c);
  iVar2 = -10;
  if (unaff_D7 != 0) {
    if (*(char *)(unaff_D7 + 0x33) < '\x01') {
      iVar2 = -4;
    }
    else {
      h_opnent(*(undefined4 *)(unaff_D7 + 0x28),(int)*(short *)(iVar1 + 10));
      iVar2 = (int)(short)unaff_D7;
      h_bkbyt(iVar1,iVar2);
    }
  }
  mkdoserr(param_1,iVar2);
  return;
}


// ==== h_info @ 01020944

void h_info(undefined1 param_1,undefined4 param_2)

{
  undefined4 uVar1;
  int unaff_D7;
  
  h_dph(param_1);
  if (unaff_D7 == 0) {
    uVar1 = 0xfffffff6;
  }
  else if (*(char *)(unaff_D7 + 0x33) < '\x01') {
    uVar1 = 0xfffffffc;
  }
  else {
    cpybuf(*(undefined4 *)(unaff_D7 + 0x1c),param_2,0x20);
    uVar1 = 0;
  }
  mkdoserr(param_1,uVar1);
  return;
}


// ==== h_dstat @ 010209a0

void h_dstat(undefined4 param_1,undefined1 param_2)

{
  int unaff_D7;
  
  h_dph(param_2);
  if (*(char *)(unaff_D7 + 0x33) < '\0') {
    *(undefined1 *)(unaff_D7 + 0x35) = 0;
  }
  mkdoserr(param_2,(int)*(char *)(unaff_D7 + 0x35));
  return;
}


// ==== HDCommand @ 010209e0

uint HDCommand(void)

{
  uint unaff_D7;
  
  clrecb(0,0x40000020);
  devtrp(1,7);
  do {
    wait((void *)0x0);
  } while ((unaff_D7 & 0x40000020) == 0);
  return unaff_D7 & 0x40000020;
}


// ==== HDDInitia @ 01020a22

void HDDInitia(void)

{
  int iVar1;
  int iVar2;
  uint unaff_D7;
  undefined1 *puVar3;
  
  devtrp(1,0);
  do {
    wait((void *)0x0);
  } while ((unaff_D7 & 0x20) == 0);
  iVar1 = 0;
  iVar2 = 1;
  do {
    WaitHDRea(&gHDDCmdCo,iVar1);
    if (unaff_D7 != 0) {
      puVar3 = &gHDDCtlDa + iVar1 * 8;
      CheckDriv(&gHDDCmdCo,puVar3,iVar1);
      if ((&DAT_01046c2f)[iVar1 * 8] != -1) {
        CheckSect(&gHDDCmdCo,puVar3,iVar1);
        RezeroUni(&gHDDCmdCo,puVar3,iVar1);
        if (*DAT_01046bae == 0) {
          *puVar3 = 1;
        }
      }
    }
    iVar2 = iVar2 + -1;
    iVar1 = iVar1 + 1;
  } while (iVar2 != 0);
  return;
}


// ==== WaitHDRea @ 01020acc

void WaitHDRea(int param_1,undefined1 param_2)

{
  int iVar1;
  char unaff_D7b;
  
  fill(param_1,0x1a,0);
  *(undefined1 *)(param_1 + 9) = param_2;
  *(char *)(param_1 + 0xb) = *(char *)(param_1 + 9) << 5;
  *(undefined2 **)(param_1 + 0x16) = &gHDDEvent;
  iVar1 = 4;
  while( true ) {
    *(undefined1 *)(param_1 + 10) = 0;
    HDCommand(param_1);
    if ((**(short **)(param_1 + 0x16) == 0) && (WD33C93Re(0xf), unaff_D7b == '\0')) break;
    wait((void *)0x0);
    iVar1 = iVar1 + -1;
    if (iVar1 == 0) {
      return;
    }
  }
  return;
}


// ==== CheckDriv @ 01020b52

char CheckDriv(int param_1,int param_2,undefined1 param_3)

{
  char cVar1;
  int unaff_D7;
  char *pcVar2;
  
  *(undefined1 *)(param_2 + 1) = 0xff;
  fill(&gHDDInqDa,0x30,0);
  *(undefined1 *)(param_1 + 9) = param_3;
  *(undefined1 *)(param_1 + 10) = 0x12;
  *(char *)(param_1 + 0xb) = *(char *)(param_1 + 9) << 5;
  *(undefined1 *)(param_1 + 0xc) = 0;
  *(undefined1 *)(param_1 + 0xd) = 0;
  *(undefined1 *)(param_1 + 0xe) = 0x24;
  *(undefined1 *)(param_1 + 0xf) = 0;
  *(undefined2 *)(param_1 + 0x10) = 0x24;
  *(undefined **)(param_1 + 0x12) = &gHDDInqDa;
  HDCommand(param_1);
  pcVar2 = &gHDDTypeC;
  while( true ) {
    if (*pcVar2 < '\x01') {
      return *pcVar2;
    }
    cVar1 = cmpbuf(pcVar2 + 2,&DAT_01046c04,(int)*pcVar2);
    if (unaff_D7 != 0) break;
    pcVar2 = pcVar2 + 0x12;
  }
  *(char *)(param_2 + 1) = pcVar2[1];
  return cVar1;
}


// ==== CheckSect @ 01020c02

void CheckSect(int param_1,int param_2,undefined1 param_3)

{
  *(undefined2 *)(param_2 + 2) = 0xffff;
  fill(&gHDDInqDa,0x30,0xff);
  *(undefined1 *)(param_1 + 9) = param_3;
  *(undefined1 *)(param_1 + 10) = 0x1a;
  *(char *)(param_1 + 0xb) = *(char *)(param_1 + 9) << 5;
  *(undefined1 *)(param_1 + 0xc) = 1;
  *(undefined1 *)(param_1 + 0xd) = 0;
  *(undefined1 *)(param_1 + 0xe) = 0x24;
  *(undefined1 *)(param_1 + 0xf) = 0;
  *(undefined2 *)(param_1 + 0x10) = 0x24;
  *(undefined **)(param_1 + 0x12) = &gHDDInqDa;
  HDCommand(param_1);
  *(ushort *)(param_2 + 2) = (ushort)DAT_01046c06 << 8;
  if (*(short *)(param_2 + 2) == 0x100) {
    *(undefined2 *)(param_2 + 4) = 0xff;
    *(undefined1 *)(param_2 + 6) = 8;
    *(undefined1 *)(param_2 + 7) = 0x10;
  }
  else if (*(short *)(param_2 + 2) == 0x200) {
    *(undefined2 *)(param_2 + 4) = 0x7f;
    *(undefined1 *)(param_2 + 6) = 9;
    *(undefined1 *)(param_2 + 7) = 8;
  }
  return;
}


// ==== RezeroUni @ 01020ccc

void RezeroUni(int param_1,int param_2,undefined1 param_3)

{
  switch(*(undefined1 *)(param_2 + 1)) {
  case 0x13:
  case 0x15:
  case 0x17:
  case 0x18:
  case 0x19:
  case 0x21:
  case 0x23:
  case 0x25:
  case 0x26:
    fill(param_1,0x1a,0);
    *(undefined1 *)(param_1 + 9) = param_3;
    *(undefined1 *)(param_1 + 10) = 0;
    *(char *)(param_1 + 0xb) = *(char *)(param_1 + 9) << 5;
    *(undefined2 **)(param_1 + 0x16) = &gHDDEvent;
    HDCommand(param_1);
    *(undefined1 *)(param_1 + 10) = 1;
    HDCommand(param_1);
  }
  return;
}


// ==== RWErrorRe @ 01020d68

void RWErrorRe(int param_1,int param_2)

{
  int iVar1;
  byte unaff_D7b;
  
  if (*(byte *)(param_1 + 9) < 2) {
    if (param_2 == 1) {
      clrecb(0,0x20);
      devtrp(1,0);
      do {
        wait((void *)0x0);
      } while ((unaff_D7b & 0x20) == 0);
    }
    cpybuf(param_1,&gHDDCmdBa,0x1a);
    fill(param_1 + 10,6,0);
    if (*(char *)(param_1 + 9) == '\x01') {
      *(char *)(param_1 + 0xb) = *(char *)(param_1 + 9) << 5;
    }
    iVar1 = 10;
    do {
      HDCommand(param_1);
      if ((**(short **)(param_1 + 0x16) == 0) && (WD33C93Re(0xf), unaff_D7b == 0)) {
        (&gHDDCtlDa)[(uint)*(byte *)(param_1 + 9) * 8] = 1;
        cpybuf(&gHDDCmdBa,param_1,0x1a);
        return;
      }
      iVar1 = iVar1 + -1;
    } while (iVar1 != 0);
    (&gHDDCtlDa)[(uint)*(byte *)(param_1 + 9) * 8] = 0;
    cpybuf(&gHDDCmdBa,param_1,0x1a);
  }
  return;
}


// ==== SetCmdPar @ 01020e78

void SetCmdPar(int param_1,undefined1 param_2)

{
  fill(&gHDDCmdPa,0x28,0);
  if (param_1 == 3) {
    DAT_01046bd0 = 3;
    DAT_01046bd1 = 0x16;
    DAT_01046bd3 = 1;
    DAT_01046bd5 = 1;
    DAT_01046bd9 = 0x18;
    DAT_01046bdb = 0x4d;
    return;
  }
  if (3 < param_1) {
    if (param_1 == 4) {
      DAT_01046bd0 = 4;
      DAT_01046bd1 = 0x12;
      DAT_01046bd3 = 5;
      DAT_01046bd4 = 0x30;
      DAT_01046bd5 = 4;
      return;
    }
    return;
  }
  if (param_1 != 1) {
    return;
  }
  DAT_01046bcf = 8;
  DAT_01046bd6 = 2;
  DAT_01046bd8 = 1;
  DAT_01046bd9 = 6;
  DAT_01046bda = 0;
  DAT_01046bdb = 0x10;
  switch(param_2) {
  case 0x15:
    DAT_01046bdc = 0xb;
    break;
  case 0x17:
    DAT_01046bdc = 8;
    break;
  case 0x18:
    DAT_01046bd9 = 10;
    DAT_01046bdc = 0x41;
    DAT_01046be0 = 0x10;
    break;
  case 0x19:
    DAT_01046bd9 = 10;
    DAT_01046bdc = 0xb;
    DAT_01046be0 = 0x10;
    break;
  case 0x25:
    gHDDCmdPa = 0x93;
    DAT_01046bd1 = 0x87;
    DAT_01046bd2 = 0xa2;
    DAT_01046bd3 = 0x5c;
    DAT_01046bda = 200;
    DAT_01046bdb = 0x20;
    DAT_01046bdc = 0x79;
    DAT_01046be0 = 0x20;
    goto LAB_01020ffc;
  case 0x26:
    gHDDCmdPa = 0x9f;
    DAT_01046bd0 = 1;
    DAT_01046bd1 = 0x11;
    DAT_01046bd2 = 0x77;
    DAT_01046bd3 = 0x2b;
    DAT_01046bda = 0xc0;
    DAT_01046bdb = 0xb;
    DAT_01046bdc = 0xf0;
    DAT_01046be0 = 0xf;
LAB_01020ffc:
    DAT_01046bd9 = 10;
    DAT_01046bd8 = 0x81;
    DAT_01046bce = 0x10;
    DAT_01046be2 = 0xff;
    DAT_01046be3 = 0xff;
  }
  return;
}


// ==== SetupForm @ 01021060

void SetupForm(int param_1,byte param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined1 uVar3;
  
  *(byte *)(param_1 + 9) = param_2;
  *(undefined1 *)(param_1 + 10) = 0x15;
  *(undefined1 *)(param_1 + 0xb) = 0x11;
  *(undefined1 *)(param_1 + 0xc) = 0;
  *(undefined1 *)(param_1 + 0xd) = 0;
  *(undefined1 *)(param_1 + 0xf) = 0;
  *(undefined1 **)(param_1 + 0x12) = &gHDDCmdPa;
  *(undefined2 **)(param_1 + 0x16) = &gHDDEvent;
  uVar3 = (&DAT_01046c2f)[(uint)param_2 * 8];
  switch(uVar3) {
  case 0x13:
    *(undefined1 *)(param_1 + 0xe) = 0x14;
    *(undefined2 *)(param_1 + 0x10) = 0x14;
    SetCmdPar(1,0x13);
    HDCommand(param_1);
    *(undefined1 *)(param_1 + 0xe) = 0x1c;
    *(undefined2 *)(param_1 + 0x10) = 0x1c;
    uVar2 = 0x13;
    uVar1 = 3;
    break;
  default:
    goto switchD_010210be_caseD_14;
  case 0x15:
    *(undefined1 *)(param_1 + 0xe) = 0x14;
    *(undefined2 *)(param_1 + 0x10) = 0x14;
    SetCmdPar(1,0x15);
    HDCommand(param_1);
    *(undefined1 *)(param_1 + 0xe) = 0x18;
    *(undefined2 *)(param_1 + 0x10) = 0x18;
    uVar2 = 0x15;
    uVar1 = 4;
    break;
  case 0x17:
    *(undefined1 *)(param_1 + 0xe) = 0x14;
    *(undefined2 *)(param_1 + 0x10) = 0x14;
    uVar3 = 0x17;
    goto LAB_0102118c;
  case 0x18:
  case 0x19:
  case 0x25:
  case 0x26:
    *(undefined1 *)(param_1 + 0xe) = 0x18;
    *(undefined2 *)(param_1 + 0x10) = 0x18;
LAB_0102118c:
    SetCmdPar(1,uVar3);
    HDCommand(param_1);
    return;
  case 0x21:
  case 0x23:
    *(undefined1 *)(param_1 + 0xe) = 0x14;
    *(undefined2 *)(param_1 + 0x10) = 0x14;
    SetCmdPar(1,uVar3);
    HDCommand(param_1);
    *(undefined1 *)(param_1 + 10) = 3;
    *(undefined1 *)(param_1 + 0xb) = 0;
    *(undefined1 *)(param_1 + 0xe) = 0;
    *(undefined2 *)(param_1 + 0x10) = 0;
    *(undefined4 *)(param_1 + 0x12) = 0;
    HDCommand(param_1);
    goto switchD_010210be_caseD_14;
  }
  SetCmdPar(uVar1,uVar2);
  HDCommand(param_1);
switchD_010210be_caseD_14:
  return;
}


// ==== TimeUpInt @ 010211ec

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void TimeUpInt(void)

{
  if ((DAT_01046ba2 != '\x04') && ((gHDDReqFl != 0 || (ram0x01046d04 != 0)))) {
    ram0x01046d04 = 0;
    gHDDReqFl = 0;
    *DAT_01046bae = 4;
    post(9,0x20);
  }
  return;
}


// ==== hdktrp @ 01021238

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void hdktrp(int param_1)

{
  int unaff_D7;
  
  ram0x01046d04 = 0;
  gHDDReqFl = 0;
  if (param_1 == 0) {
    WD33C93Re(0,0x87);
    WD33C93Re(0x18,0);
  }
  else {
    if ((DAT_0f009000 & 0x20) == 0) {
      if ((param_1 == 7) && (CheckTran(&gHDDCmdCo), unaff_D7 != 0)) {
        WD33C93Re(1,0x81);
        WD33C93Re(0x11,0);
        WD33C93Re(0x15,DAT_01046ba1);
        WD33C93Re(0xf,0);
        WD33C93Re(0x16,0x40);
        WD33C93Re(2,0xff);
        CDBWrite(&gHDDCmdCo);
        SetDMACon(&gHDDCmdCo);
        *DAT_01046bae = 0;
        gHDDReqFl = 1;
        WD33C93Re(0x18,9);
        timer(TimeUpInt,400);
        return;
      }
      *DAT_01046bae = 1;
    }
    else {
      *DAT_01046bae = 2;
    }
    post(9,0x20);
  }
  return;
}


// ==== WD33C93Re @ 0102134c

void WD33C93Re(undefined1 param_1)

{
  DAT_0f009000 = param_1;
  SCSIWait();
  SCSIWait();
  return;
}


// ==== WD33C93Re @ 01021380

void WD33C93Re(undefined1 param_1,undefined1 param_2)

{
  DAT_0f009000 = param_1;
  SCSIWait();
  DAT_0f009001 = param_2;
  SCSIWait();
  return;
}


// ==== CheckTran @ 010213b4

uint CheckTran(int param_1)

{
  int iVar1;
  uint uVar2;
  
  if ((((*(char *)(param_1 + 10) == '\b') ||
       (uVar2 = (uint)*(byte *)(param_1 + 10), *(byte *)(param_1 + 10) == 10)) &&
      (uVar2 = (uint)*(byte *)(param_1 + 0xe), *(byte *)(param_1 + 0xe) != 0)) &&
     (uVar2 = (uint)*(ushort *)(param_1 + 0x10), *(ushort *)(param_1 + 0x10) != 0)) {
    iVar1 = (uint)*(byte *)(param_1 + 9) * 8;
    uVar2 = (uint)*(ushort *)(param_1 + 0x10);
    if ((uint)*(byte *)(param_1 + 0xe) << ((&DAT_01046c34)[iVar1] & 0x3f) != uVar2) {
      uVar2 = (uint)*(byte *)(param_1 + 0xe) << ((&DAT_01046c34)[iVar1] & 0x3f);
      *(short *)(param_1 + 0x10) = (short)uVar2;
    }
  }
  return uVar2;
}


// ==== CDBWrite @ 01021432

void CDBWrite(int param_1)

{
  int iVar1;
  undefined1 *puVar2;
  
  WD33C93Re(3,*(undefined1 *)(param_1 + 10));
  iVar1 = 5;
  puVar2 = (undefined1 *)(param_1 + 0xb);
  do {
    DAT_0f009001 = *puVar2;
    SCSIWait();
    iVar1 = iVar1 + -1;
    puVar2 = puVar2 + 1;
  } while (iVar1 != 0);
  iVar1 = 4;
  do {
    WD33C93Re(iVar1 + 8,0);
    iVar1 = iVar1 + -1;
  } while (iVar1 != 0);
  if (*(char *)(param_1 + 10) == '7') {
    WD33C93Re(10,(int)(*(ushort *)(param_1 + 0x10) - 4) >> 8 & 0xff);
    WD33C93Re(0xb,(*(ushort *)(param_1 + 0x10) & 0xff) - 4);
  }
  return;
}


// ==== SetDMACon @ 010214da

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void SetDMACon(int param_1)

{
  _mskon();
  switch(*(undefined1 *)(param_1 + 10)) {
  case 3:
  case 8:
  case 0x12:
  case 0x1a:
  case 0x20:
  case 0x23:
  case 0x37:
    SetTransf(param_1);
    _DAT_0f008008 = 0x234;
    dmahset(2,*(undefined4 *)(param_1 + 0x12),*(undefined2 *)(param_1 + 0x10));
    DAT_0f00800b = 4;
    break;
  case 4:
  case 7:
  case 10:
  case 0x15:
  case 0x24:
    SetTransf(param_1);
    _DAT_0f008008 = 0x234;
    dmahset(2,*(undefined4 *)(param_1 + 0x12),*(undefined2 *)(param_1 + 0x10));
    DAT_0f00800b = 8;
    break;
  default:
    goto switchD_01021502_caseD_5;
  }
  dmsk_rst(4);
  _DAT_0f008008 = 0x230;
  ram0x01046d04 = 1;
switchD_01021502_caseD_5:
  _mskoff();
  return;
}


// ==== SetTransf @ 01021604

void SetTransf(int param_1)

{
  WD33C93Re(0x12,0);
  WD33C93Re(0x13,*(ushort *)(param_1 + 0x10) >> 8);
  WD33C93Re(0x14,*(ushort *)(param_1 + 0x10) & 0xff);
  return;
}


// ==== hdkirq @ 01021652

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void hdkirq(void)

{
  bool bVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  uint unaff_D7;
  char cVar5;
  int iVar6;
  
  bVar1 = false;
  iVar6 = 0;
  do {
    WD33C93Re(0x17);
    cVar5 = (char)unaff_D7;
    uVar4 = unaff_D7 & 0xff;
    if (uVar4 == 0x1f) {
LAB_01021792:
      WD33C93Re(0x18,0xa0);
      iVar2 = 100;
      do {
        if ((DAT_0f009000 & 1) != 0) goto LAB_010217ac;
        iVar2 = iVar2 + -1;
      } while (iVar2 != 0);
LAB_01021870:
      bVar1 = true;
    }
    else {
      if (uVar4 < 0x20) {
        if (uVar4 < 0x1a) {
          if (uVar4 < 0x18) {
            if (uVar4 != 0) {
              if (uVar4 == 0x16) {
LAB_010217ac:
                WD33C93Re(0x19);
                return;
              }
              goto LAB_01021872;
            }
            WD33C93Re(0x18);
            if (cVar5 == '\0') {
              *DAT_01046bae = 0;
              post(9,0x20);
              gHDDReqFl = 0;
              return;
            }
          }
          else {
            WD33C93Re(0x18,0xa0);
            iVar2 = 100;
            do {
              if ((DAT_0f009000 & 1) != 0) {
                if (cVar5 == '\x19') {
LAB_0102181c:
                  WD33C93Re(0x19);
                }
                else {
LAB_01021828:
                  WD33C93Re(0x19,0);
                }
LAB_01021834:
                *DAT_01046bae = 8;
                return;
              }
              iVar2 = iVar2 + -1;
            } while (iVar2 != 0);
          }
        }
        else {
          uVar3 = 0x1b;
LAB_010216d0:
          if (uVar3 != uVar4) goto LAB_01021872;
          WD33C93Re(0x18,0xa0);
          iVar2 = 100;
          do {
            if ((DAT_0f009000 & 1) != 0) {
              WD33C93Re(0x19);
              if ((unaff_D7 & 3) == 0) {
                return;
              }
              goto LAB_01021834;
            }
            iVar2 = iVar2 + -1;
          } while (iVar2 != 0);
        }
        goto LAB_01021870;
      }
      if (uVar4 < 0x4a) {
        if (0x47 < uVar4) {
          WD33C93Re(0x18,0xa0);
          iVar2 = 100;
          do {
            if ((DAT_0f009000 & 1) != 0) {
              if (cVar5 == 'I') goto LAB_0102181c;
              goto LAB_01021828;
            }
            iVar2 = iVar2 + -1;
          } while (iVar2 != 0);
          goto LAB_01021870;
        }
        if (uVar4 == 0x20) {
          WD33C93Re(0x18,3);
          return;
        }
      }
      else {
        if (uVar4 == 0x4f) goto LAB_01021792;
        if (uVar4 < 0x50) {
          uVar3 = 0x4b;
          goto LAB_010216d0;
        }
        if (uVar4 == 0x85) {
          _mskon();
          if ((ram0x01046d04 != 0) || (gHDDReqFl != 1)) {
            if ((gHDDReqFl != 1) || (dmaaget(2), unaff_D7 != 0xffff)) {
              gHDDReqFl = 0;
              _mskoff();
              return;
            }
            ram0x01046d04 = 0;
          }
          gHDDReqFl = 0;
          _mskoff();
          can_time(TimeUpInt);
          post(9,0x20);
          return;
        }
      }
    }
LAB_01021872:
    if ((bVar1) || (iVar6 = iVar6 + 1, 99 < iVar6)) {
      *DAT_01046bae = 4;
      return;
    }
  } while( true );
}


// ==== hdkdma @ 01021894

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void hdkdma(void)

{
  _mskon();
  if ((gHDDReqFl == 0) && (ram0x01046d04 == 1)) {
    ram0x01046d04 = 0;
    _mskoff();
    can_time(TimeUpInt);
    post(9,0x20);
  }
  else {
    ram0x01046d04 = 0;
    _mskoff();
  }
  return;
}


// ==== ini_icu @ 010218e8

void ini_icu(void)

{
  icuInit(0xf004000,&imgICU0,0x50);
  icuInit(&DAT_0f003000,&imgICU1,0x58);
  return;
}


// ==== icuInit @ 01021920

void icuInit(undefined1 *param_1,int param_2,undefined1 param_3)

{
  *(undefined1 *)(param_2 + 3) = 0x13;
  *param_1 = 0x13;
  intwait();
  *(undefined1 *)(param_2 + 7) = param_3;
  param_1[1] = param_3;
  intwait();
  *(undefined1 *)(param_2 + 9) = 0xf;
  param_1[1] = 0xf;
  intwait();
  *(undefined1 *)(param_2 + 4) = 0;
  *param_1 = 0;
  intwait();
  *(undefined1 *)(param_2 + 5) = 0xb;
  *param_1 = 0xb;
  intwait();
  *(undefined1 *)(param_2 + 10) = 0xff;
  param_1[1] = 0xff;
  intwait();
  return;
}


// ==== demskicu @ 0102198c

void demskicu(int param_1,int param_2,byte param_3)

{
  byte bVar1;
  
  bVar1 = *(byte *)(param_2 + 10) & ~param_3;
  *(byte *)(param_2 + 10) = bVar1;
  *(byte *)(param_1 + 1) = bVar1;
  return;
}


// ==== enmskicu @ 010219b2

void enmskicu(int param_1,int param_2,byte param_3)

{
  param_3 = param_3 | *(byte *)(param_2 + 10);
  *(byte *)(param_2 + 10) = param_3;
  *(byte *)(param_1 + 1) = param_3;
  return;
}


// ==== icudrv @ 010219d4

void icudrv(int param_1,int param_2)

{
  undefined *puVar1;
  undefined1 *puVar2;
  
  if (param_2 >> 8 == 0) {
    puVar2 = (undefined1 *)0xf004000;
    puVar1 = &imgICU0;
  }
  else {
    puVar2 = &DAT_0f003000;
    puVar1 = &imgICU1;
  }
  if (param_1 == 1) {
    enmskicu(puVar2,puVar1,(int)(char)param_2);
  }
  else if ((param_1 < 2) && (param_1 == 0)) {
    ini_icu();
  }
  else {
    demskicu(puVar2,puVar1,(int)(char)param_2);
  }
  return;
}


// ==== init_wait @ 01021a50

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void init_wait(void)

{
  int iVar1;
  
  _ack_task = 0;
  _ret_task = 0;
  retry = 0;
  rty_wait = 3;
  iVar1 = 0;
  do {
    (&tbl_wait)[iVar1] = 0;
    iVar1 = iVar1 + 1;
  } while (iVar1 < 0x40);
  setcrcs(&DAT_01046e33,0,0,0);
  return;
}


// ==== idc_req @ 01021a98

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void idc_req(int param_1,undefined4 param_2)

{
  int unaff_D7;
  int iVar1;
  int local_8;
  
  if ((f_reset == -1) && (day_tim(&DAT_01046fd6), unaff_D7 == 0)) {
    alarm(0x90);
    wtmsg();
    can_alrm();
    f_reset = 0;
  }
  if (*(char *)(param_1 + 1) == '\0') {
    iVar1 = 0x103;
  }
  else {
    iVar1 = *(char *)(param_1 + 1) + 3;
  }
  cpydata(param_1,&rtybuf,iVar1);
  rtycount = param_2;
  local_8 = 0xb4;
  do {
    fdcwait();
    local_8 = local_8 + -1;
  } while (local_8 != 0);
  set_wait(f_pno,param_2);
  devtrp(0xd,(port_no + 0xc0) * 0x100 | 0x10006,param_1,&local_8);
  _dvret = unaff_D7;
  if (unaff_D7 == 0) {
    can_wait(f_pno);
  }
  return;
}


// ==== sdu_wait @ 01021b86

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

uint sdu_wait(int param_1)

{
  byte bVar1;
  byte *pbVar2;
  uint uVar3;
  undefined *puVar4;
  int iVar5;
  int unaff_D7;
  
  do {
    while( true ) {
      wtmsg();
      uVar3 = can_wait();
      if (unaff_D7 != 0) break;
      remsg(param_1);
      if (*(byte *)(param_1 + 2) < 0x80) {
        if (*(int *)(param_1 + 0x32) != 0) {
          latopa(*(undefined1 *)(param_1 + 2),*(undefined4 *)(param_1 + 0x32));
          *(undefined4 *)(param_1 + 0x32) = 0;
        }
        latopa(*(undefined1 *)(param_1 + 2),*(undefined4 *)(param_1 + 0x36));
        *(undefined4 *)(param_1 + 0x36) = 0;
      }
      if (port_no + 0xc0 != (uint)*(byte *)(param_1 + 2)) {
        return port_no + 0xc0;
      }
      iVar5 = 0xc0;
      pbVar2 = (byte *)(param_1 + 0xc);
      bVar1 = *(byte *)(param_1 + 8);
      uVar3 = (uint)bVar1;
      if (bVar1 == 4) {
        _rec_stat = 4;
      }
      else {
        if (bVar1 < 5) {
          if (bVar1 == 2) {
            _rec_stat = 2;
            uVar3 = (uint)*(byte *)(param_1 + 10);
            if ('\x1f' < (char)*(byte *)(param_1 + 10)) {
              chkcrc(param_1 + 9);
              if ((*pbVar2 & 0x40) != 0) {
                *(undefined1 *)(param_1 + 0xd) = 0xff;
                *(undefined1 *)(param_1 + 0xe) = 0xbc;
              }
              uVar3 = *pbVar2 & 0xffffff0f;
              *pbVar2 = (byte)uVar3;
            }
            goto LAB_01021cd2;
          }
        }
        else if (bVar1 == 5) {
          _rec_stat = 5;
        }
        else if (bVar1 == 0xff) {
          _rec_stat = *(byte *)(param_1 + 9) | 0xff00;
          uVar3 = *(byte *)(param_1 + 9) & 0xffffff78;
        }
        iVar5 = -1;
      }
LAB_01021cd2:
      if ((iVar5 == 0xc0) || (9 < retry)) {
        if (_ack_task != 0) {
          _ack_task = 0;
        }
        if (_ret_task != 0) {
          _ret_task = 0;
        }
        if (9 < retry) {
          f_reset = 0xffffffff;
        }
        retry = 0;
        return uVar3;
      }
LAB_01021d70:
      retry = retry + 1;
      r_wait = -1;
      set_wait(0,rty_wait);
    }
    if (((f_mode == 1) || (f_mode == 3)) || (f_mode == 5)) {
      if (r_wait != -1) {
        if (10 < retry) {
          retry = 0;
          _ack_task = 0;
          _ret_task = 0;
          return uVar3;
        }
        goto LAB_01021d70;
      }
      r_wait = 0;
      if (f_mode == 5) {
        puVar4 = &rtysns;
      }
      else {
        puVar4 = &rtybuf;
      }
      uVar3 = idc_req(puVar4,rtycount);
      if (unaff_D7 != 0) {
        retry = 0;
        _ack_task = 0;
        _ret_task = 0;
        return uVar3;
      }
    }
    if (f_mode == 4) {
      f_tcb = (uint)(byte)(&tbl_tno)[f_pno];
      return (uint)(byte)(&tbl_tno)[f_pno];
    }
  } while( true );
}


// ==== set_wait @ 01021e14

void set_wait(undefined4 param_1,int param_2)

{
  alarm(param_2 * 3);
  return;
}


// ==== can_wait @ 01021e2a

void can_wait(void)

{
  can_alrm();
  return;
}


// ==== ap_proc @ 01021e38

void ap_proc(void)

{
  if ((f_mode == 3) && (*(short *)(&tbl_stim + f_pno * 2) != 0)) {
    set_wait(f_pno,*(short *)(&tbl_stim + f_pno * 2));
  }
  return;
}


// ==== sp_proc @ 01021e72

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void sp_proc(int param_1)

{
  int iVar1;
  
  iVar1 = f_tcb * 0x34;
  if (f_mode != 4) {
    return;
  }
  sbuff = 2;
  DAT_01087959 = '\x03';
  switch(f_pno) {
  case 0xd:
  case 0x11:
  case 0x16:
  case 0x1a:
  case 0x39:
    if (param_1 == 0) {
      DAT_0108795c = 1;
    }
    else {
      DAT_0108795c = 3;
    }
    break;
  default:
    DAT_0108795c = 0;
  }
  _DAT_0108795a = *(undefined2 *)(&DAT_01046f4a + f_pno * 2);
  if (f_pno != 0xb) {
    if (f_pno < 0xc) {
      if (f_pno != 9) goto LAB_01021faa;
    }
    else if (f_pno != 0xf) {
      if (f_pno == 0x3c) {
        cpydata(*(undefined4 *)(&DAT_01078660 + iVar1),&DAT_0108795d,
                *(undefined4 *)(&DAT_01078656 + iVar1));
        DAT_01087959 = (char)*(undefined4 *)(&DAT_01078656 + iVar1) + DAT_01087959;
      }
      goto LAB_01021faa;
    }
  }
  DAT_0108795d = (&DAT_01078638)[iVar1];
  DAT_01087959 = '\x04';
LAB_01021faa:
  calcrc(&DAT_01087959);
  calcs(&DAT_01087959);
  idc_req(&sbuff,0xa0);
  return;
}


// ==== rp_stat @ 01021fe4

void rp_stat(int param_1)

{
  uint uVar1;
  uint *puVar2;
  short *psVar3;
  int iVar4;
  
  if (f_mode == 5) {
    iVar4 = f_tcb * 0x34;
    puVar2 = *(uint **)(&DAT_01078664 + iVar4);
    psVar3 = *(short **)(&DAT_01078664 + iVar4);
    cpydata(param_1 + 0xd,puVar2,4);
    if (((f_pno == 0x1b) && (-1 < (int)*puVar2)) && (*(uint *)(&DAT_01078656 + iVar4) <= *puVar2)) {
      *puVar2 = *(uint *)(&DAT_01078656 + iVar4);
    }
    if ((-1 < (int)*puVar2) && ((f_pno == 0x17 || (f_pno == 0x19)))) {
      uVar1 = *puVar2;
      (&file_tp)[*puVar2] = 0;
      (&file_cp)[uVar1] = 0;
      uVar1 = *puVar2;
      (&wflash)[*puVar2] = 0;
      (&wmark)[uVar1] = 0;
      *(undefined4 *)(&wdatabuf + *puVar2 * 4) = rwbuf;
      (&used_fcb)[*puVar2] = 0xffffffff;
      (&used_drv)[*puVar2] = (&DAT_01078638)[iVar4];
      (&fileport)[*puVar2] = port_no;
    }
    if (((((int)*puVar2 < 0) && (*psVar3 != -0x44)) &&
        ((*psVar3 != -0x43 && ((f_pno == 0x1b || (f_pno == 0x24)))))) &&
       ((f_pno != 0x24 || (*psVar3 != -10)))) {
      (&used_fcb)[*(short *)(&DAT_0107865a + iVar4)] = 0;
    }
  }
  return;
}


// ==== rp_stpr @ 01022126

void rp_stpr(int param_1)

{
  int iVar1;
  int *piVar2;
  short *psVar3;
  int iVar4;
  int iVar5;
  uint uVar6;
  
  if (f_mode == 5) {
    iVar5 = f_tcb * 0x34;
    iVar1 = *(int *)(&DAT_01078660 + iVar5);
    uVar6 = (uint)*(byte *)(param_1 + 9);
    if (uVar6 == 0) {
      uVar6 = 0x100;
    }
    iVar4 = uVar6 - 7;
    piVar2 = *(int **)(&DAT_01078664 + iVar5);
    psVar3 = *(short **)(&DAT_01078664 + iVar5);
    if ((f_type == 1) || (f_type == 0)) {
      if (f_pno != 0x1a) {
        f_wp = 0;
      }
      ttl_len = 0;
    }
    cpydata(param_1 + 0xd,piVar2,4);
    if ((*piVar2 < 0) && (*psVar3 != -0xc)) {
      if ((*psVar3 != -0x44) && (*psVar3 != -0x43)) {
        if ((f_pno == 0x11) && ((byte)(&DAT_01078638)[iVar5] < 2)) {
          mfree(dirbuf);
          *(undefined4 *)(&DAT_01078660 + iVar5) = dirsave;
        }
        if (f_pno == 0x1a) {
          (&used_fcb)[*(short *)(&DAT_0107865a + iVar5)] = 0;
        }
      }
    }
    else {
      switch(f_pno) {
      case 0x11:
        cpydata(param_1 + 0x11,f_wp + iVar1,iVar4);
        f_wp = iVar4 + f_wp;
        if (((f_type == 2) || (f_type == 0)) && ((byte)(&DAT_01078638)[iVar5] < 2)) {
          convdir(dirbuf,dirsave,**(undefined4 **)(&DAT_01078664 + iVar5));
          mfree(dirbuf);
          *(undefined4 *)(&DAT_01078660 + iVar5) = dirsave;
        }
        break;
      case 0x1a:
        if ((f_type == 0) && (*psVar3 == -0xc)) {
          if (f_wp != 0) {
            *piVar2 = f_wp;
          }
        }
        else {
          rp_read(param_1 + 10,&DAT_01078636 + iVar5,iVar4);
        }
        break;
      case 0x36:
      case 0x37:
        ttl_len = f_bc + ttl_len + -7;
        if ((f_type == 2) || (f_type == 0)) {
          *piVar2 = ttl_len;
        }
      }
      if ((f_pno != 0x11) && (f_pno != 0x1a)) {
        cpydata(param_1 + 0x11,f_wp + iVar1,iVar4);
        f_wp = iVar4 + f_wp;
      }
    }
  }
  return;
}


// ==== rp_para @ 010223a6

void rp_para(int param_1)

{
  int iVar1;
  int iVar2;
  uint *puVar3;
  undefined4 uVar4;
  uint local_a;
  short local_6;
  
  if (f_mode == 5) {
    iVar1 = f_tcb * 0x34;
    uVar4 = *(undefined4 *)(&DAT_01078660 + iVar1);
    iVar2 = *(byte *)(param_1 + 9) - 3;
    if (f_pno == 0x3d) {
      if (*(char *)(param_1 + 0xd) == -1) {
        return;
      }
      cpydata((char *)(param_1 + 0xd),&local_6,2);
      if (local_6 == 0x200) {
        iVar2 = 2;
      }
      else {
        iVar2 = 0;
      }
      local_a = (uint)((byte)(&DAT_01078638)[iVar1] < 2) |
                (int)*(char *)(param_1 + 0x12) << 1 |
                iVar2 << 2 |
                (int)*(char *)(param_1 + 0xf) << 4 |
                (int)*(char *)(param_1 + 0x10) << 10 | (int)*(char *)(param_1 + 0x11) << 0x14;
      iVar2 = 4;
      uVar4 = *(undefined4 *)(&DAT_01078664 + iVar1);
      puVar3 = &local_a;
    }
    else {
      puVar3 = (uint *)(param_1 + 0xd);
    }
    cpydata(puVar3,uVar4,iVar2);
  }
  return;
}


// ==== ck_idc @ 0102249e

void ck_idc(void)

{
  if (*(short *)((uint)port_no * 0x400 + 0xfff93a0) < 0) {
    devtrp(0xc,(port_no + 0xc0) * 0x100 | 0x80010006);
    devtrp(0xc,(port_no + 0xc0) * 0x100 | 0x80020006);
    devtrp(0xc,(port_no + 0xc0) * 0x100 | 0x80030006);
    idc_req(&DAT_01046fdc,0x10);
  }
  return;
}


// ==== id_proc @ 01022546

void id_proc(int param_1)

{
  int iVar1;
  
  if ((f_mode == 1) && (*(char *)(param_1 + 9) == '\x04')) {
    iVar1 = 0;
    do {
      if ((&DAT_01046fe2)[iVar1] != *(char *)(param_1 + 10 + iVar1)) {
        return;
      }
      iVar1 = iVar1 + 1;
    } while (iVar1 < 4);
  }
  return;
}


// ==== convdir @ 0102258e

void convdir(int param_1,int param_2,int param_3)

{
  int iVar1;
  
  iVar1 = 0;
  if (0 < param_3) {
    do {
      ms_dircnv(param_1,param_2);
      param_1 = param_1 + 0x20;
      param_2 = param_2 + 0x20;
      iVar1 = iVar1 + 1;
    } while (iVar1 < param_3);
  }
  return;
}


// ==== ms_dircnv @ 010225cc

void ms_dircnv(int param_1,int param_2)

{
  ushort uVar1;
  byte bVar2;
  short unaff_D7w;
  
  revword(*(undefined2 *)(param_1 + 0x16));
  revword(*(undefined2 *)(param_1 + 0x18));
  uVar1 = *(ushort *)(param_1 + 0x18);
  cpybuf(param_1,param_2,0xb);
  *(byte *)(param_2 + 0x10) = (byte)(unaff_D7w >> 0xb) & 0x1f;
  bVar2 = (byte)(unaff_D7w >> 5);
  *(byte *)(param_2 + 0x11) = bVar2 & 0x3f;
  *(byte *)(param_2 + 0x12) = (byte)unaff_D7w & 0x1f;
  *(char *)(param_2 + 0xc) = (char)((((uVar1 & 0xfe) >> 1) + 0x50) % 100);
  *(byte *)(param_2 + 0xd) = bVar2 & 0xf;
  *(byte *)(param_2 + 0xe) = (byte)unaff_D7w & 0x1f;
  *(undefined1 *)(param_2 + 0xf) = 0;
  revword(*(undefined2 *)(param_1 + 0x1a));
  *(short *)(param_2 + 0x14) = unaff_D7w;
  *(uint *)(param_2 + 0x16) =
       *(uint *)(param_1 + 0x1c) >> 0x18 |
       (*(uint *)(param_1 + 0x1c) & 0xff0000) >> 8 |
       (*(uint *)(param_1 + 0x1c) & 0xff00) << 8 | *(int *)(param_1 + 0x1c) << 0x18;
  return;
}


// ==== set_l_to_ @ 010226e0

void set_l_to_(undefined2 *param_1,undefined2 param_2)

{
  *param_1 = param_2;
  return;
}


// ==== get_w_to_ @ 010226f2

undefined2 get_w_to_(undefined2 *param_1)

{
  return *param_1;
}


// ==== fnetcpybu @ 01022704

void fnetcpybu(undefined2 *param_1,undefined2 *param_2,int param_3)

{
  undefined2 uVar1;
  int iVar2;
  undefined2 *puVar3;
  undefined2 *puVar4;
  undefined1 local_6;
  undefined1 uStack_5;
  
  if (((uint)param_2 & 1) == 0) {
    for (iVar2 = param_3 + 1 >> 1; iVar2 != 0; iVar2 = iVar2 + -1) {
      *param_2 = *param_1;
      param_1 = param_1 + 1;
      param_2 = param_2 + 1;
    }
  }
  else {
    while (iVar2 = param_3, puVar3 = param_2, iVar2 != 0) {
      puVar4 = param_1 + 1;
      uVar1 = *param_1;
      local_6 = (undefined1)((ushort)uVar1 >> 8);
      *(undefined1 *)puVar3 = local_6;
      param_1 = puVar4;
      param_2 = (undefined2 *)((int)puVar3 + 1);
      param_3 = 0;
      if (iVar2 != 1) {
        uStack_5 = (undefined1)uVar1;
        *(undefined1 *)((int)puVar3 + 1) = uStack_5;
        param_2 = puVar3 + 1;
        param_3 = iVar2 + -2;
      }
    }
  }
  return;
}


// ==== tnetcpybu @ 0102274c

short * tnetcpybu(byte *param_1,short *param_2,uint param_3)

{
  int iVar1;
  short *psVar2;
  uint uVar3;
  short local_6;
  
  if (((uint)param_1 & 1) == 0) {
    psVar2 = param_2;
    for (iVar1 = (int)(param_3 + 1) >> 1; iVar1 != 0; iVar1 = iVar1 + -1) {
      *psVar2 = *(short *)param_1;
      param_1 = param_1 + 2;
      psVar2 = psVar2 + 1;
    }
  }
  else {
    uVar3 = param_3;
    if ((int)param_3 < 0) {
      uVar3 = param_3 + 1;
    }
    psVar2 = param_2;
    for (iVar1 = (int)uVar3 >> 1; iVar1 != 0; iVar1 = iVar1 + -1) {
      *psVar2 = *(short *)param_1;
      param_1 = param_1 + 2;
      psVar2 = psVar2 + 1;
    }
    uVar3 = param_3;
    if ((int)param_3 < 0) {
      uVar3 = param_3 + 1;
    }
    param_2 = (short *)-((uVar3 & 0xfffffffe) - param_3);
    if (param_2 != (short *)0x0) {
      local_6 = (ushort)*param_1 << 8;
      *psVar2 = local_6;
    }
  }
  return param_2;
}


// ==== if508moun @ 010227b2

void if508moun(void)

{
  int unaff_D7;
  
  get_w_to_(0xff02002);
  set_l_to_(0xff02002,0x5555);
  get_w_to_(0xff02002);
  if (unaff_D7 == 0x5555) {
    set_l_to_(0xff02002);
  }
  return;
}


// ==== if508rdy @ 0102280a

void if508rdy(void)

{
  if (((byte)netdcb & 0x10) != 0) {
    get_w_to_(0xff02000);
  }
  return;
}


// ==== int508_tu @ 01022834

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void int508_tu(void)

{
  int unaff_D7;
  
  if (cmds_get != cmds_set) {
    get_w_to_(0xff02010);
    if (unaff_D7 == 0) {
      set_l_to_(0xff02010,*(undefined4 *)(&cmdsave + cmds_get * 4));
      cmds_get = cmds_get + 1 & 0xf;
      if (cmds_get == cmds_set) {
        _DAT_0ff03ffc = 0;
        return;
      }
    }
    _DAT_0ff03ffc = 0;
    timer(int508_tu,5);
  }
  return;
}


// ==== int508 @ 010228b4

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void int508(uint param_1)

{
  int unaff_D7;
  
  if508rdy();
  if (unaff_D7 == 1) {
    get_w_to_(0xff02010);
    *(uint *)(&cmdsave + cmds_set * 4) = param_1 | 0x8000;
    cmds_set = cmds_set + 1 & 0xf;
    timer(int508_tu,5);
  }
  else {
    set_l_to_(0xff02010,param_1 | 0x8000);
    _DAT_0ff03ffc = 0;
  }
  return;
}


// ==== netsyspos @ 01022932

void netsyspos(undefined4 param_1,int param_2)

{
  **(undefined4 **)(param_2 + 0xc) = param_1;
  post(*(undefined1 *)(param_2 + 2),0x8000000);
  *(undefined1 *)(param_2 + 2) = 0;
  return;
}


// ==== tup_nt1tx @ 01022966

void tup_nt1tx(void)

{
  DAT_01047040 = DAT_01047040 + 1;
  DAT_01046fec._0_1_ = DAT_01046fec._0_1_ | 0x10;
  dioreq(DAT_0104717c);
  return;
}


// ==== tup_nt1rx @ 01022988

void tup_nt1rx(void)

{
  DAT_0104709c = DAT_0104709c + 1;
  DAT_01047048._0_1_ = DAT_01047048._0_1_ | 0x20;
  dioreq(DAT_01047190);
  return;
}


// ==== tup_nt2tx @ 010229aa

void tup_nt2tx(void)

{
  DAT_01047040 = DAT_01047040 + 1;
  DAT_01046fec._0_1_ = DAT_01046fec._0_1_ | 1;
  dioreq(DAT_0104717c);
  return;
}


// ==== tup_nt2rx @ 010229cc

void tup_nt2rx(void)

{
  DAT_0104709c = DAT_0104709c + 1;
  DAT_01047048._0_1_ = DAT_01047048._0_1_ | 2;
  dioreq(DAT_01047190);
  return;
}


// ==== nettxirq @ 010229ee

void nettxirq(void)

{
  DAT_0104703c = DAT_0104703c + 1;
  DAT_01046fec = DAT_01046fec | 1;
  can_time(net_tup);
  DAT_01046fec = DAT_01046fec & 0xeeffffff;
  dioreq(DAT_0104717c);
  return;
}


// ==== netrxirq @ 01022a2a

void netrxirq(void)

{
  DAT_01047098 = DAT_01047098 + 1;
  DAT_01047048 = DAT_01047048 | 2;
  can_time(PTR_tup_nt2tx_010471b0);
  DAT_01047048 = DAT_01047048 & 0xddffffff;
  dioreq(DAT_01047190);
  return;
}


// ==== ntdmail @ 01022a66

void ntdmail(int param_1,int param_2)

{
  int unaff_D5;
  int unaff_D7;
  int iVar1;
  int *piVar2;
  undefined4 uStack_2c;
  int local_28;
  int local_24;
  int local_20;
  
  if (*(int *)(param_2 + 8) == 0x20) {
    local_20 = 0xff02000;
    local_24 = 0x1022a90;
    get_w_to_();
    **(int **)(param_2 + 0x10) = unaff_D7;
    local_24 = 0xff02004;
    local_28 = 0x1022aa0;
    get_w_to_();
    **(int **)(param_2 + 0x14) = unaff_D7;
    local_28 = param_2;
    piVar2 = &uStack_2c;
    uStack_2c = 1;
  }
  else if ((*(int *)(param_2 + 8) == 1) || (*(int *)(param_2 + 8) == 0x40)) {
    local_20 = param_2;
    piVar2 = &local_24;
    local_24 = -1;
  }
  else {
    local_20 = 0xff02000;
    local_24 = 0x1022ade;
    get_w_to_();
    if (-1 < (short)unaff_D7) {
      iVar1 = 0;
      do {
        local_20 = (&netsettbl)[iVar1 * 3];
        local_24 = 0x1022b08;
        get_w_to_();
        if (unaff_D7 == 0) {
          local_20 = 0x24;
          local_24 = param_1 + 8 + iVar1 * 0x24;
          local_28 = param_2;
          uStack_2c = 0x1022b24;
          cpybuf();
          uStack_2c = 0x30;
          tnetcpybu(*(undefined4 *)(param_2 + 0x10),(&DAT_010226b4)[iVar1 * 3]);
          if (*(int *)(param_2 + 0x14) != 0) {
            local_20 = *(undefined4 *)(param_2 + 0x14);
            local_24 = (&DAT_010226b8)[iVar1 * 3];
            local_28 = *(int *)(param_2 + 0x18);
            uStack_2c = 0x1022b5a;
            tnetcpybu();
            unaff_D5 = 0;
          }
          if (*(int *)(param_2 + 0x1c) != 0) {
            local_20 = *(undefined4 *)(param_2 + 0x1c);
            local_28 = *(int *)(param_2 + 0x20);
            uStack_2c = 0x1022b76;
            local_24 = unaff_D5;
            tnetcpybu();
          }
          local_20 = 0x1022b80;
          _mskon();
          local_20 = *(int *)(param_2 + 0x1c) + 0x40 + *(int *)(param_2 + 0x14);
          local_24 = (&netsettbl)[iVar1 * 3];
          local_28 = 0x1022ba4;
          set_l_to_();
          local_28 = 10;
          uStack_2c = 0x1022bae;
          int508();
          uStack_2c = 0x1022bb4;
          _mskoff();
          break;
        }
        iVar1 = iVar1 + 1;
      } while (iVar1 < 2);
      if (iVar1 < 2) {
        return;
      }
    }
    local_20 = param_2;
    piVar2 = &local_24;
    local_24 = -9;
  }
  *(undefined4 *)((int)piVar2 + -4) = 0x1022bd6;
  netsyspos();
  return;
}


// ==== nettxresp @ 01022be6

void nettxresp(void)

{
  int unaff_D7;
  
  get_w_to_(netsettbl);
  if ((unaff_D7 == 0) && (DAT_01046ff2 != '\0')) {
    netsyspos(1,&DAT_01046ff0);
  }
  get_w_to_(DAT_010226bc);
  if ((unaff_D7 == 0) && (DAT_01047016 != '\0')) {
    netsyspos(1,&DAT_01047014);
  }
  return;
}


// ==== nettxdrv @ 01022c44

void nettxdrv(void)

{
  uint uVar1;
  int unaff_D7;
  undefined4 **ppuVar2;
  undefined4 **ppuVar3;
  undefined4 *local_3c;
  undefined4 *local_38;
  undefined4 auStack_28 [9];
  
  local_38 = (undefined4 *)0x1022c58;
  _mskon();
  uVar1 = DAT_01046fec;
  DAT_01046fec = 0;
  local_38 = (undefined4 *)0x1022c6a;
  _mskoff();
  if ((uVar1 & 0x11000001) != 0) {
    local_38 = (undefined4 *)0x1022c7a;
    netrxresp();
    if ((uVar1 & 1) != 0) {
      local_38 = (undefined4 *)0x1022c86;
      nettxresp();
      uVar1 = 0;
    }
    if ((uVar1 & 0x10000000) != 0) {
      local_38 = (undefined4 *)&DAT_01046ff0;
      local_3c = (undefined4 *)0xfffffff8;
      netsyspos();
    }
    if ((uVar1 & 0x1000000) != 0) {
      local_38 = (undefined4 *)&DAT_01047014;
      local_3c = (undefined4 *)0xfffffff8;
      netsyspos();
    }
  }
  ppuVar2 = (undefined4 **)(auStack_28 + -3);
  if ((DAT_01046ff2 == '\0') || (DAT_01047016 == '\0')) {
    local_38 = auStack_28;
    local_3c = DAT_0104717c;
    dremsg();
    if (unaff_D7 != 0) {
      ppuVar3 = &local_38;
      local_38 = DAT_0104717c;
      goto LAB_01022d0c;
    }
    if ((netdcb & 0x10) == 0) {
      local_38 = auStack_28;
      local_3c = (undefined4 *)0xfffffff6;
      netsyspos();
      ppuVar2 = &local_3c;
    }
    else {
      local_38 = auStack_28;
      local_3c = &netdcb;
      ntdmail();
      ppuVar2 = (undefined4 **)(auStack_28 + -3);
    }
  }
  ppuVar3 = (undefined4 **)((int)ppuVar2 + -4);
  *(undefined4 **)((int)ppuVar2 + -4) = DAT_0104717c;
LAB_01022d0c:
  *(undefined4 *)((int)ppuVar3 + -4) = 0x1022d12;
  iodone();
  return;
}


// ==== netrxresp @ 01022d1c

void netrxresp(void)

{
  bool bVar1;
  int unaff_D7;
  undefined1 uVar2;
  
  bVar1 = false;
  get_w_to_(netgettbl);
  if (unaff_D7 != 0) {
    if ((DAT_01047044 & 0x100) != 0) {
      fnetcpybu(DAT_010226cc,&cmembuf);
      if (((cmembuf == 1) && (0x1f < DAT_01089328)) && (DAT_01089328 < 0x34)) {
        uVar2 = 2;
      }
      else {
        uVar2 = DAT_0104704e;
      }
      i_semsg(DAT_01047190,uVar2,&cmembuf);
    }
    _mskon();
    set_l_to_(netgettbl,0);
    bVar1 = true;
  }
  get_w_to_(DAT_010226d4);
  if (unaff_D7 != 0) {
    if ((DAT_01047044 & 0x100) != 0) {
      fnetcpybu(DAT_010226d8,&cmembuf);
      i_semsg(DAT_01047190,DAT_0104704e,&cmembuf);
    }
    _mskon();
    set_l_to_(DAT_010226d4,0);
    bVar1 = true;
  }
  if (bVar1) {
    int508(0x14);
    _mskoff();
  }
  return;
}


// ==== netrxdrv @ 01022e6a

void netrxdrv(void)

{
  uint uVar1;
  undefined4 uVar2;
  int unaff_D7;
  undefined1 auStack_28 [2];
  undefined1 local_26;
  int local_20;
  undefined4 *local_1c;
  
  _mskon();
  uVar1 = DAT_01047048;
  DAT_01047048 = 0;
  _mskoff();
  if (((uVar1 & 0x22000002) != 0) && (nettxresp(), (uVar1 & 2) != 0)) {
    netrxresp();
  }
  dremsg(DAT_01047190,auStack_28);
  if (unaff_D7 == 0) {
    if ((DAT_01047044 & 0x10) == 0) {
      uVar2 = 0xfffffff6;
    }
    else if (local_20 == 0x40) {
      cpybuf(auStack_28,&DAT_0104704c,0x24);
      DAT_01047044 = DAT_01047044 | 0x100;
      _mskon();
      set_l_to_(0xff02008,DAT_01047174);
      set_l_to_(0xff0200c,DAT_01047188);
      int508(2);
      _mskoff();
      uVar2 = 1;
    }
    else {
      if (local_20 == 0x41) {
        fill(&DAT_0104704c,0x24,0);
        DAT_01047044 = DAT_01047044 & 0xfffffeff;
        *local_1c = 1;
        post(local_26,0x8000000);
        goto LAB_01022fa8;
      }
      uVar2 = 0xffffffff;
    }
    *local_1c = uVar2;
    post(local_26,0x8000000);
  }
LAB_01022fa8:
  iodone(DAT_01047190);
  return;
}


// ==== cmlog @ 01022fb8

void cmlog(short param_1)

{
  int iVar1;
  
  if (param_1 == (&DAT_010471c0)[clogno * 2]) {
    *(short *)(&cmemlog + clogno * 4) = *(short *)(&cmemlog + clogno * 4) + 1;
  }
  else {
    clogno = clogno + 1;
    iVar1 = (int)clogno;
    (&DAT_010471c0)[iVar1 * 2] = param_1;
    *(undefined2 *)(&cmemlog + iVar1 * 4) = 1;
  }
  return;
}


// ==== neti_tup @ 01022ffa

void neti_tup(void)

{
  short unaff_D7w;
  undefined4 *puVar1;
  undefined4 uStack_1c;
  int local_18;
  undefined4 local_14;
  
  if (netdcb == 0) {
    local_14 = 0xff02010;
    local_18 = 0x1023020;
    get_w_to_();
    local_18 = (int)unaff_D7w;
    uStack_1c = 0x102302c;
    cmlog();
    if (unaff_D7w == -1) {
      netdcb = 1;
      DAT_01047044 = 1;
      local_14 = 0;
      local_18 = 0xff02010;
      uStack_1c = 0x1023056;
      set_l_to_();
      puVar1 = &uStack_1c;
      uStack_1c = 3;
    }
    else {
      puVar1 = &local_14;
      local_14 = 5;
    }
  }
  else if (netdcb == 1) {
    local_14 = 0xff02010;
    local_18 = 0x1023068;
    get_w_to_();
    local_18 = (int)unaff_D7w;
    uStack_1c = 0x1023074;
    cmlog();
    if (unaff_D7w == 0) {
      netdcb = netdcb | 0x10;
      DAT_01047044 = DAT_01047044 | 0x10;
      local_14 = DAT_0104717c;
      local_18 = 0x102309e;
      iodone();
      local_18 = DAT_01047190;
      uStack_1c = 0x10230a4;
      iodone();
      return;
    }
    puVar1 = &local_14;
    local_14 = 3000;
  }
  else {
    puVar1 = &local_14;
    local_14 = 300;
  }
  *(code **)((int)puVar1 + -4) = neti_tup;
  *(undefined4 *)((int)puVar1 + -8) = 0x10230b6;
  timer();
  return;
}


// ==== net_init @ 010230c0

void net_init(int param_1)

{
  short unaff_D7w;
  undefined **ppuVar1;
  undefined4 uStack_18;
  int local_14;
  undefined *local_10;
  
  local_10 = (&PTR_nettxirq_01047178)[param_1 * 5];
  local_14 = (&DAT_01047174)[param_1 * 5];
  uStack_18 = 0x10230ea;
  irqvct();
  if (param_1 == 0) {
    netdcb = 0;
    DAT_01047044 = 0;
    local_10 = (undefined *)0xff02010;
    local_14 = 0x1023108;
    get_w_to_();
    local_14 = (int)unaff_D7w;
    uStack_18 = 0x1023114;
    cmlog();
    if (unaff_D7w == -1) {
      netdcb = 1;
      DAT_01047044 = 1;
      local_10 = (undefined *)0x0;
      local_14 = 0xff02010;
      uStack_18 = 0x102313e;
      set_l_to_();
      ppuVar1 = (undefined **)&uStack_18;
      uStack_18 = 3;
    }
    else {
      ppuVar1 = &local_10;
      local_10 = (undefined *)0x5;
    }
    *(code **)((int)ppuVar1 + -4) = neti_tup;
    *(undefined4 *)((int)ppuVar1 + -8) = 0x102314e;
    timer();
  }
  return;
}


// ==== netinit0 @ 01023158

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void netinit0(void)

{
  DAT_010471c0 = 0xffff;
  _cmemlog = 0xffff;
  clogno = 0;
  net_init(0);
  return;
}


// ==== netinit1 @ 0102317e

void netinit1(void)

{
  net_init(1);
  return;
}


// ==== netsioini @ 01023190

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void netsioini(void)

{
  uint unaff_D7;
  
  siodcb = 0;
  if ((((byte)netdcb & 0x10) == 0) || (get_w_to_(0xff039c4), (unaff_D7 & 0x1000) == 0)) {
    timer(netsioini,10);
    return;
  }
  irqvct(DAT_0104719c,PTR_netsioirq_010471a0);
  DAT_010470b0 = 8;
  DAT_010470b4 = 10;
  DAT_010470b8 = 2;
  DAT_010470bc = 0x2580;
  DAT_010470a8 = 0;
  _DAT_010470c0 = 0x5000;
  set_l_to_(0xff039cc,8);
  set_l_to_(0xff039d0,DAT_010470b4);
  set_l_to_(0xff039d4,DAT_010470b8);
  set_l_to_(0xff039c8,DAT_010470bc);
  set_l_to_(0xff039d8,DAT_0104719c);
  set_l_to_(0xff039c0,0x51f0);
  int508(0);
  DAT_0104711c = DAT_0104711c + 1;
  siodcb = 1;
  iodone(DAT_010471a4);
  return;
}


// ==== netsioirq @ 0102329c

void netsioirq(void)

{
  uint uVar1;
  int unaff_D7;
  
  DAT_01047120 = DAT_01047120 + 1;
  get_w_to_(0xff039dc);
  uVar1 = (uint)(unaff_D7 == 0);
  get_w_to_(0xff039e0);
  if (unaff_D7 != 0) {
    uVar1 = uVar1 | 0x10;
  }
  DAT_010470a4 = uVar1;
  dioreq(DAT_010471a4);
  return;
}


// ==== nsiosendr @ 010232ee

void nsiosendr(void)

{
  int iVar1;
  int unaff_D7;
  
  if (DAT_010470c6 != '\0') {
    get_w_to_(0xff039dc);
    if (unaff_D7 == 0) {
      if (DAT_010470d8 == 0) {
        nsioaplpo(&DAT_010470c4,DAT_010470c8);
      }
      else {
        if (DAT_010470d8 < 0x101) {
          iVar1 = DAT_010470d8;
        }
        else {
          iVar1 = 0xff;
        }
        tnetcpybu(DAT_010470dc,0xff03a00,iVar1);
        _mskon();
        set_l_to_(0xff039dc,iVar1);
        DAT_010470dc = iVar1 + DAT_010470dc;
        DAT_010470d8 = DAT_010470d8 - iVar1;
        set_l_to_(0xff039c0,4);
        int508(0);
        _mskoff();
      }
    }
  }
  return;
}


// ==== nsioreciv @ 010233b0

void nsioreciv(void)

{
  int iVar1;
  int unaff_D7;
  
  if (siodcb == 1) {
    get_w_to_(0xff039e0);
    if ((unaff_D7 != 0) && (DAT_010470f2 != '\0')) {
      if (DAT_010470a8 == 0) {
        iVar1 = 0xff03b00;
        DAT_010470a8 = unaff_D7;
      }
      else {
        iVar1 = DAT_010470ac;
      }
      if (DAT_01047104 < DAT_010470a8) {
        fnetcpybu(iVar1,DAT_01047108,DAT_01047104);
        nsioaplpo(&DAT_010470f0,DAT_01047104);
        DAT_010470a8 = DAT_010470a8 - DAT_01047104;
        DAT_010470ac = DAT_01047104 + DAT_010470ac;
      }
      else {
        fnetcpybu(iVar1,DAT_01047108,DAT_010470a8);
        nsioaplpo(&DAT_010470f0,DAT_010470a8);
        _mskon();
        set_l_to_(0xff039e0,0);
        set_l_to_(0xff039c0,0x1000);
        DAT_010470a8 = 0;
        int508(0);
        _mskoff();
      }
    }
  }
  return;
}


// ==== nsio_mode @ 0102349a

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void nsio_mode(int param_1)

{
  uint *puVar1;
  byte bVar2;
  
  puVar1 = (uint *)(param_1 + 0x14);
  bVar2 = (*puVar1 & 4) != 0;
  if ((bool)bVar2) {
    _DAT_010470c0 = _DAT_010470c0 | 1;
  }
  if ((*puVar1 & 8) != 0) {
    _DAT_010470c0 = _DAT_010470c0 & 0xfffffffe;
    bVar2 = bVar2 | 2;
  }
  if ((*puVar1 & 0x100) != 0) {
    DAT_010470b0 = *(undefined4 *)(param_1 + 0x18);
    set_l_to_(0xff039cc,DAT_010470b0);
    bVar2 = bVar2 | 0x20;
  }
  if ((*puVar1 & 0x200) != 0) {
    DAT_010470b4 = *(undefined4 *)(param_1 + 0x1c);
    set_l_to_(0xff039d0,DAT_010470b4);
    bVar2 = bVar2 | 0x40;
  }
  if ((*puVar1 & 0x400) != 0) {
    DAT_010470b8 = *(undefined4 *)(param_1 + 0x20);
    set_l_to_(0xff039d4,DAT_010470b8);
    bVar2 = bVar2 | 0x80;
  }
  if ((*puVar1 & 0x800) != 0) {
    DAT_010470bc = *(undefined4 *)(param_1 + 0x24);
    set_l_to_(0xff039c8,DAT_010470bc);
    bVar2 = bVar2 | 0x10;
  }
  if (bVar2 != 0) {
    _mskon();
    set_l_to_(0xff039c0,bVar2);
    int508(0);
    _mskoff();
  }
  nsioaplpo(param_1,1);
  return;
}


// ==== nsio_sens @ 010235ac

void nsio_sens(int param_1)

{
  uint *puVar1;
  undefined4 unaff_D7;
  
  puVar1 = (uint *)(param_1 + 0x14);
  if ((*puVar1 & 1) != 0) {
    latopa(*(undefined1 *)(param_1 + 2),*(undefined4 *)(param_1 + 0x18));
    *(undefined4 *)(param_1 + 0x18) = unaff_D7;
    get_w_to_(0xff039c4);
    **(undefined4 **)(param_1 + 0x18) = unaff_D7;
  }
  if ((*puVar1 & 0x1000) != 0) {
    latopa(*(undefined1 *)(param_1 + 2),*(undefined4 *)(param_1 + 0x1c));
    *(undefined4 *)(param_1 + 0x1c) = unaff_D7;
    **(undefined4 **)(param_1 + 0x1c) = DAT_010470b0;
  }
  if ((*puVar1 & 0x2000) != 0) {
    latopa(*(undefined1 *)(param_1 + 2),*(undefined4 *)(param_1 + 0x20));
    *(undefined4 *)(param_1 + 0x20) = unaff_D7;
    **(undefined4 **)(param_1 + 0x20) = DAT_010470b4;
  }
  if ((*puVar1 & 0x4000) != 0) {
    latopa(*(undefined1 *)(param_1 + 2),*(undefined4 *)(param_1 + 0x24));
    *(undefined4 *)(param_1 + 0x24) = unaff_D7;
    **(undefined4 **)(param_1 + 0x24) = DAT_010470b8;
  }
  if ((short)*puVar1 < 0) {
    latopa(*(undefined1 *)(param_1 + 2),*(undefined4 *)(param_1 + 0x28));
    *(undefined4 *)(param_1 + 0x28) = unaff_D7;
    **(undefined4 **)(param_1 + 0x28) = DAT_010470bc;
  }
  nsioaplpo(param_1,1);
  return;
}


// ==== nsioaplpo @ 010236be

void nsioaplpo(int param_1,undefined4 param_2)

{
  **(undefined4 **)(param_1 + 0xc) = param_2;
  post(*(undefined1 *)(param_1 + 2),*(undefined4 *)(param_1 + 0x10));
  *(undefined1 *)(param_1 + 2) = 0;
  return;
}


// ==== netsiodrv @ 010236f0

void netsiodrv(void)

{
  uint uVar1;
  int unaff_D7;
  undefined4 uVar2;
  undefined1 auStack_30 [2];
  undefined1 local_2e;
  int local_28;
  undefined4 in_stack_ffffffdc;
  undefined4 in_stack_ffffffe8;
  
  _mskon();
  uVar1 = DAT_010470a4;
  DAT_010470a4 = 0;
  _mskoff();
  if ((uVar1 & 0x11) != 0) {
    if ((uVar1 & 1) != 0) {
      nsiosendr();
    }
    if ((uVar1 & 0x10) != 0) {
      nsioreciv();
    }
  }
  dremsg(DAT_010471a4,auStack_30);
  if (unaff_D7 != 0) goto LAB_01023848;
  latopa(local_2e,in_stack_ffffffdc);
  if (local_28 == 1) {
    if (DAT_010470c6 == '\0') {
      latopa(local_2e,in_stack_ffffffe8);
      cpybuf(auStack_30,&DAT_010470c4,0x2c);
      DAT_010470c8 = DAT_010470d8;
      nsiosendr();
      goto LAB_01023848;
    }
    uVar2 = 0xfffffffd;
  }
  else if (local_28 == 2) {
    if (DAT_010470f2 == '\0') {
      latopa(local_2e,in_stack_ffffffe8);
      cpybuf(auStack_30,&DAT_010470f0,0x2c);
      nsioreciv();
      goto LAB_01023848;
    }
    uVar2 = 0xfffffffd;
  }
  else {
    if (local_28 == 3) {
      nsio_mode(auStack_30);
      goto LAB_01023848;
    }
    if (local_28 == 4) {
      nsio_sens(auStack_30);
      goto LAB_01023848;
    }
    uVar2 = 0xfffffffe;
  }
  nsioaplpo(auStack_30,uVar2);
LAB_01023848:
  iodone(DAT_010471a4);
  return;
}


// ==== net_creat @ 01023858

void net_creat(void)

{
  int iVar1;
  int unaff_D7;
  
  if508moun();
  if (unaff_D7 != 0) {
    crtask(&nettib,0);
    crtask(&netmantib,0);
    fill(&netdcb,0xb8,0);
    iVar1 = 0;
    do {
      crdcb((&netinitd)[iVar1 * 5],(&PTR_nettxdrv_01047180)[iVar1 * 5],(&DAT_0104717c)[iVar1 * 5]);
      if (unaff_D7 != 0) {
        (&netdcb)[iVar1 * 0x17] = 0xfffffff0;
      }
      iVar1 = iVar1 + 1;
    } while (iVar1 < 2);
    fill(&siodcb,0x88,0);
    crdcb(netsioini,PTR_netsiodrv_010471a8,DAT_010471a4);
    if (unaff_D7 != 0) {
      siodcb = 0xfffffff0;
    }
  }
  return;
}


// ==== ifdebug @ 01023920

void ifdebug(void)

{
  _settcb(&tcbm,0x40);
  _setecb(&ecbm);
  _setrcb(&rcbm,0x50);
  _setpcb(&syspcb,&cpcb,0x40);
  _setdcb(&dcbtbl,0x20);
  _setetcb(&etcb);
  _setlcb(&lcb);
  _setedcb(&edcb);
  _setdque(&dcbque);
  _setmemb(memcbctl);
  return;
}


// ==== _getmend @ 010239bc

int _getmend(void)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  piVar3 = memcbctl + *memcbctl * 2;
  iVar1 = memcbctl[1];
  iVar2 = 0;
  if (iVar1 != 0) {
    iVar2 = *memcbctl;
    do {
      iVar2 = iVar2 + -1;
      if (iVar2 == 0) {
        return iVar1;
      }
      piVar3 = piVar3 + -2;
      iVar1 = CONCAT22((short)((uint)iVar1 >> 0x10),*(short *)piVar3);
    } while (*(short *)piVar3 != 0);
    iVar2 = pnotoph(iVar2);
  }
  return iVar2;
}


// ==== _initmmu @ 01023a08

void _initmmu(void)

{
  short unaff_D7w;
  
  memend = memcbctl + -4;
  fill(&syspcb,0x80,0);
  syspcb = 0x203;
  mmu_pcbma(&syspcb);
  if (unaff_D7w != 0) {
    mmusetup(0);
    set_cacr(setcacr);
  }
  return;
}


// ==== mcbinit @ 01023a62

void mcbinit(int param_1,int param_2)

{
  uint uVar1;
  uint uVar2;
  int iVar3;
  uint *puVar4;
  
  smmemcbct = &smmcbctl;
  smmcbctl = 0x400;
  DAT_01075fd0 = 0x400;
  fill(&srmmcb,0x2000,0);
  uVar2 = (param_2 - param_1) + 1U >> 10;
  uVar1 = uVar2 << 3;
  iVar3 = (int)uVar1 >> 10;
  if ((uVar1 & 0x3ff) != 0) {
    iVar3 = iVar3 + 1;
  }
  puVar4 = (uint *)((uVar2 - iVar3) * 0x400 + param_1);
  fill(puVar4,uVar1,0);
  *puVar4 = uVar2;
  puVar4[1] = (uVar2 - iVar3) - 1;
  mcbset(puVar4 + (uVar2 - iVar3) * 2,iVar3,0x5000,0,0);
  mcbset(puVar4 + 2,0x3f,0x2000,0,0);
  mcbset(puVar4 + 0x80,0x1e7,0x8000,0,0);
  set_vbr(param_1);
  memcbctl = puVar4;
  return;
}


// ==== mcbset @ 01023b66

void mcbset(undefined2 *param_1,int param_2,undefined2 param_3,undefined1 param_4,undefined4 param_5
           )

{
  for (; param_2 != 0; param_2 = param_2 + -1) {
    *param_1 = param_3;
    *(undefined1 *)(param_1 + 1) = param_4;
    *(undefined1 *)((int)param_1 + 3) = 0;
    *(undefined4 *)(param_1 + 2) = param_5;
    param_1 = param_1 + 4;
  }
  return;
}


// ==== intinit @ 01023ba0

void intinit(void)

{
  icuInit(0xf004000,&imgICU0,0x50);
  icuInit(&DAT_0f003000,&imgICU1,0x58);
  return;
}


// ==== iordbuf @ 01023bd8

void iordbuf(undefined1 *param_1,undefined4 param_2,int param_3)

{
  undefined1 *unaff_D7;
  
  _ltopa(etcb,param_2);
  for (; param_3 != 0; param_3 = param_3 + -1) {
    *unaff_D7 = *param_1;
    unaff_D7 = unaff_D7 + 1;
    param_1 = param_1 + 1;
  }
  return;
}


// ==== iowtbuf @ 01023c10

void iowtbuf(undefined4 param_1,undefined1 *param_2,int param_3)

{
  undefined1 *unaff_D7;
  
  _ltopa(etcb,param_1);
  for (; param_3 != 0; param_3 = param_3 + -1) {
    *unaff_D7 = *param_2;
    unaff_D7 = unaff_D7 + 1;
    param_2 = param_2 + 1;
  }
  return;
}


// ==== kcmdsend @ 01023c48

void kcmdsend(int param_1)

{
  char cVar1;
  
  cVar1 = *(char *)(param_1 + 0xc);
  DAT_010473c0 = 0;
  if (cVar1 == '\x03') {
    kcmdmode(param_1);
  }
  else if (cVar1 == '\x04') {
    kcmddial(param_1);
  }
  else if (cVar1 == '\x05') {
    kcmdbuzz(param_1);
  }
  else if (cVar1 == '\x06') {
    kcmdled(param_1);
  }
  else if (cVar1 == '\a') {
    kcmdspk(param_1);
  }
  else if (cVar1 == '\b') {
    kcmdrgrw(param_1);
  }
  else if (cVar1 == '\x16') {
    kcmdagled(param_1);
  }
  else if (cVar1 == '\x18') {
    kcmdbkled(param_1);
  }
  else if (cVar1 == '\x17') {
    kcmdlcd(param_1);
  }
  else if (cVar1 == '\x19') {
    kcmdcgset(param_1);
  }
  else {
    kcmdkrep(param_1);
  }
  return;
}


// ==== kcmdmode @ 01023d10

void kcmdmode(int *param_1)

{
  cpybuf(*param_1 * 2 + 0x10473ca,&DAT_010473c8,2);
  ksendcmd(&DAT_010473c4,6);
  return;
}


// ==== kcmddial @ 01023d48

void kcmddial(uint *param_1)

{
  uint uVar1;
  byte bVar3;
  int iVar2;
  char cVar4;
  short sVar5;
  uint uVar6;
  int unaff_D7;
  
  uVar1 = *param_1;
  bVar3 = (byte)(uVar1 >> 8);
  cVar4 = (char)uVar1;
  uVar6 = uVar1 & 0xff;
  iVar2 = (int)uVar1 >> 0x10;
  if ((bVar3 == 0) || (bVar3 == 1)) {
    if (bVar3 == 0) {
      if (iVar2 < 0) {
        iVar2 = -iVar2;
      }
      sqrroot(iVar2 * 0x960);
      (&DAT_010473e7)[uVar6 * 3] = (char)(unaff_D7 / 10);
      if (cVar4 == '\0') {
        cVar4 = -0x33;
      }
      else if (cVar4 == '\x01') {
        cVar4 = -0x34;
      }
      else if (cVar4 == '\x02') {
        cVar4 = -0x31;
      }
      else {
        if (cVar4 != '\x03') goto LAB_01023e50;
        cVar4 = -0x32;
      }
      sVar5 = 6;
      (&DAT_010473e8)[uVar6 * 3] = ~(cVar4 + (&DAT_010473e7)[uVar6 * 3]) + 1;
    }
    else {
      if ((cVar4 != '\x04') && (cVar4 != '\x05')) goto LAB_01023e50;
      sVar5 = 5;
    }
    cpybuf(&DAT_010473e6 + uVar6 * 3,(uint)bVar3 * 6 + 0x10473dd,sVar5 + -3);
    ksendcmd((uint)bVar3 * 6 + 0x10473da,(int)sVar5);
  }
  else {
LAB_01023e50:
    *(undefined4 *)param_1[2] = 0xfffffffe;
  }
  return;
}


// ==== kcmdbuzz @ 01023e62

void kcmdbuzz(int *param_1)

{
  cpybuf(*param_1 * 2 + 0x10473fe,&DAT_010473fc,2);
  ksendcmd(&DAT_010473f8,6);
  return;
}


// ==== kcmdled @ 01023e9a

void kcmdled(uint *param_1)

{
  uint uVar1;
  byte bVar2;
  
  uVar1 = *param_1;
  bVar2 = (byte)uVar1 & 0xf;
  if ((uVar1 & 0x10) == 0) {
    if ((uVar1 & 0x10) != 0) {
      *(undefined4 *)param_1[2] = 0xfffffffe;
      return;
    }
    DAT_01047411 = bVar2;
  }
  else {
    DAT_01047411 = 0x80;
    if (bVar2 < 0xb) {
      DAT_01047411 = bVar2 + 0x80;
    }
  }
  DAT_01047412 = ~(DAT_01047411 + 0x4c) + 1;
  ksendcmd(&DAT_0104740e,5);
  return;
}


// ==== kcmdspk @ 01023f12

void kcmdspk(undefined4 *param_1)

{
  DAT_01047417 = (undefined1)*param_1;
  DAT_01047418 = ~((char)*param_1 + 0xa0U) + 1;
  ksendcmd(&DAT_01047413,6);
  return;
}


// ==== kcmdrgrw @ 01023f46

void kcmdrgrw(undefined4 *param_1)

{
  char cVar1;
  undefined *puVar2;
  undefined4 uVar3;
  
  cVar1 = (char)((uint)*param_1 >> 8);
  if ((char)((uint)*param_1 >> 0x10) == 'w') {
    DAT_01047422 = (char)*param_1;
    DAT_01047423 = ~(DAT_01047422 + cVar1 + 'W') + 1;
    uVar3 = 6;
    puVar2 = &DAT_0104741e;
    DAT_01047421 = cVar1;
  }
  else {
    DAT_0104741d = ~(cVar1 + 0x52U) + 1;
    Frgread = 0;
    uVar3 = 5;
    puVar2 = &DAT_01047419;
    DAT_0104741c = cVar1;
  }
  ksendcmd(puVar2,uVar3);
  return;
}


// ==== kcmdkrep @ 01023fba

void kcmdkrep(uint *param_1)

{
  uint uVar1;
  uint uVar2;
  int iVar3;
  ushort uVar4;
  byte bVar5;
  char acStack_90 [4];
  char acStack_8c [136];
  
  bVar5 = 0;
  uVar1 = *param_1;
  uVar2 = *param_1;
  cpybuf(&DAT_01047424,acStack_90,4);
  iVar3 = (uVar2 & 0xff) << 1;
  acStack_90[1] = (char)iVar3 + '\x02';
  acStack_90[3] = (char)(uVar1 >> 0x10);
  cpybuf(param_1[1],acStack_8c,iVar3);
  uVar4 = (short)iVar3 + 3;
  if (1 < uVar4) {
    do {
      bVar5 = acStack_90[(short)uVar4] + bVar5;
      uVar4 = uVar4 - 1;
    } while (1 < (short)uVar4);
  }
  iVar3 = (uVar2 & 0xff) * 2;
  acStack_8c[iVar3] = ~bVar5 + 1;
  ksendcmd(acStack_90,iVar3 + 5);
  return;
}


// ==== kcmdagled @ 0102405c

void kcmdagled(undefined4 *param_1)

{
  DAT_0104742a = (byte)*param_1;
  DAT_0104742b = ~DAT_0104742a + 1;
  ksendcmd(&DAT_01047428,4);
  return;
}


// ==== kcmdbkled @ 0102408a

void kcmdbkled(int *param_1)

{
  int iVar1;
  char *pcVar2;
  short sVar3;
  byte bVar4;
  
  bVar4 = 0;
  DAT_0104742d = (undefined1)*param_1;
  sVar3 = 2;
  iVar1 = *param_1;
  pcVar2 = (char *)param_1[1];
  while (iVar1 != 0) {
    bVar4 = *pcVar2 + bVar4;
    (&DAT_0104742c)[sVar3] = *pcVar2;
    *param_1 = *param_1 + -1;
    sVar3 = sVar3 + 1;
    pcVar2 = pcVar2 + 1;
    iVar1 = *param_1;
  }
  (&DAT_0104742c)[sVar3] = ~bVar4 + 1;
  ksendcmd(&DAT_0104742c,sVar3 + 1);
  return;
}


// ==== kcmdlcd @ 010240e6

void kcmdlcd(undefined4 *param_1)

{
  ushort uVar1;
  ushort uVar2;
  byte bVar3;
  char local_90 [4];
  char acStack_8c [136];
  
  bVar3 = 0;
  local_90[2] = (char)((uint)*param_1 >> 8);
  local_90[3] = (char)*param_1;
  uVar2 = (ushort)*param_1 & 0xff;
  local_90[0] = -0x7c;
  local_90[1] = local_90[3] + '\x02';
  if ((char)((uint)*param_1 >> 0x10) != '\0') {
    local_90[2] = local_90[2] | 0x80;
  }
  cpybuf(param_1[1],acStack_8c,uVar2);
  uVar1 = uVar2 + 3;
  if (1 < uVar1) {
    do {
      bVar3 = local_90[(short)uVar1] + bVar3;
      uVar1 = uVar1 - 1;
    } while (1 < (short)uVar1);
  }
  acStack_8c[(short)uVar2] = ~bVar3 + 1;
  ksendcmd(local_90,(short)uVar2 + 5);
  return;
}


// ==== kcmdcgset @ 01024180

void kcmdcgset(undefined4 *param_1)

{
  short sVar1;
  byte bVar2;
  
  bVar2 = 0;
  DAT_01047531 = (char)((uint)*param_1 >> 0x10) != '\0';
  DAT_01047532 = (undefined1)*param_1;
  cpybuf(param_1[1],&DAT_01047533,7);
  sVar1 = 10;
  do {
    bVar2 = (&DAT_0104752f)[sVar1] + bVar2;
    sVar1 = sVar1 + -1;
  } while (1 < sVar1);
  DAT_0104753a = ~bVar2 + 1;
  ksendcmd(&DAT_0104752f,0xc);
  return;
}


// ==== ksendcmd @ 01024202

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void ksendcmd(undefined4 param_1,short param_2)

{
  uint uVar1;
  
  uVar1 = (int)_DAT_0d01ca40 + (int)param_2;
  if (uVar1 < 0x9e) {
    DAT_010473c0 = 0;
    cpybuf(param_1,_DAT_0d01ca40 + 0xd01ca42,(int)param_2);
    _DAT_0d01ca40 = param_2 + _DAT_0d01ca40;
  }
  else {
    DAT_010473c0 = 1;
    ksenddumy((int)_DAT_0d01ca40,(int)param_2,uVar1);
  }
  return;
}


// ==== ksenddumy @ 01024272

void ksenddumy(void)

{
  return;
}


// ==== kirqrx @ 0102427c

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void kirqrx(void)

{
  if (Kbytecnt == 0) {
    if (_DAT_0d01cae0 < 0x11) {
      cpybuf(0xd01cae2,&Kbytebuf,(int)_DAT_0d01cae0);
      Kbytecnt = _DAT_0d01cae0;
    }
    else {
      cpybuf(0xd01cae2,&Kbytebuf,0x10);
      Kbytecnt = 0x10;
    }
  }
  _DAT_0d01cae0 = 0;
  _mskon();
  _DAT_01047592 = _DAT_01047592 | 0x8000;
  _mskoff();
  dioreq(0x81);
  return;
}


// ==== kirqtx @ 01024306

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void kirqtx(void)

{
  _mskon();
  _DAT_01047592 = _DAT_01047592 | 0x4000;
  _mskoff();
  dioreq(0x81);
  return;
}


// ==== ksrset @ 0102432c

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void ksrset(void)

{
  _DAT_0d01ca02 = 2;
  _DAT_0d01ca00 = 1;
  return;
}


// ==== knop @ 01024346

void knop(void)

{
  return;
}


// ==== ksinit @ 0102434e

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void ksinit(void)

{
  irqvct(0xa0,kirqrx);
  irqvct(0xa1,ksrset);
  irqvct(0xa2,kirqtx);
  irqvct(0xa3,knop);
  itrpvct(3,dialstat);
  fill(&Kcdbuf,0x24,0);
  fill(&Kbytebuf,0x10,0);
  Kbusyflg = 0;
  Kinitflg = 0;
  Kreqflg = 0;
  Kbytecnt = 0;
  _Kdevreg = 0;
  FUN_01024412(0x873);
  _mskon();
  kbd_start = kbd_start | 0x80;
  _mskoff();
  dioreq(0x81);
  return;
}


// ==== FUN_01024412 @ 01024412

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_01024412(undefined2 param_1)

{
  short sVar1;
  
  sVar1 = -0x4184;
  while ((_DAT_0d01ca20 & 1) == 0) {
    sVar1 = sVar1 + -1;
  }
  if (sVar1 != 0) {
    _DAT_0d01ca02 = 1;
    _DAT_0d01ca04 = param_1;
    _DAT_0d01ca0a = 0xa2a0;
    _DAT_0d01ca0c = 0xa3a1;
    _DAT_0d01ca00 = 6;
    sVar1 = 0x477;
    while ((_DAT_0d01ca20 & 1) != 0) {
      sVar1 = sVar1 + -1;
    }
    if (sVar1 != 0) {
      do {
      } while ((_DAT_0d01ca20 & 1) == 0);
    }
  }
  return;
}


// ==== kbddev @ 010244b2

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void kbddev(void)

{
  uint uVar1;
  
  _mskon();
  uVar1 = _kbd_start;
  _kbd_start = 0;
  _mskoff();
  if ((int)uVar1 < 0) {
    kinitdev();
  }
  if ((short)uVar1 < 0) {
    _Kdevreg = uVar1 & 1 | _Kdevreg;
    krecvdev();
  }
  if ((uVar1 & 0x4000) != 0) {
    _Kdevreg = uVar1 & 2 | _Kdevreg;
  }
  if (((uVar1 & 0x40000000) != 0) && (Kbusyflg == '\x01')) {
    *DAT_01047584 = 0xfffffffd;
    Kbusyflg = '\0';
    post(DAT_01047576,1);
  }
  if (Kreqflg == '\x01') {
    kreqfunk(&Kreqpint);
    if (Kreqflg == '\0') {
      post(DAT_01047596,1);
    }
  }
  kdmsgdev();
  return;
}


// ==== kdmsgdev @ 0102457c

/* WARNING: Removing unreachable block (ram,0x01024696) */

void kdmsgdev(void)

{
  int unaff_D7;
  undefined1 auStack_1a [2];
  undefined1 local_18;
  undefined1 auStack_12 [4];
  undefined4 in_stack_fffffff2;
  undefined4 in_stack_fffffff6;
  byte local_6;
  
  dremsg(0x81,auStack_1a);
  if (unaff_D7 != 0) {
    return;
  }
  s_ltopa(local_18,in_stack_fffffff6);
  s_ltopa(local_18,in_stack_fffffff2);
  if (local_6 < 3) {
    kreqfunk(auStack_1a);
    if (Kreqflg != '\0') goto LAB_010246bc;
  }
  else {
    if ((local_6 == 0x14) || (local_6 == 0x15)) {
      kreqvolfu(auStack_1a);
      post(local_18,1);
      goto LAB_010246bc;
    }
    if (((local_6 < 3) || (9 < local_6)) && ((local_6 < 0x16 || (0x19 < local_6)))) {
      uRam00000000 = 0xfffffffe;
    }
    else {
      if ((Kbusyflg != '\x01') && (Kinitflg != '\x01')) {
        kcmdsend(auStack_12);
        cpybuf(auStack_1a,&Kmsgdev,0x16);
        Kbusyflg = '\x01';
        timer(ktimout,0x14);
        goto LAB_010246bc;
      }
      uRam00000000 = 0;
    }
  }
  post(local_18,1);
LAB_010246bc:
  iodone(0x81);
  return;
}


// ==== ktimout @ 010246d0

void ktimout(void)

{
  if (Kinitflg == '\x01') {
    kinitdev();
  }
  else {
    _mskon();
    kbd_start = kbd_start | 0x40;
    _mskoff();
    dioreq(0x81);
  }
  return;
}


// ==== kinitdev @ 01024708

void kinitdev(void)

{
  undefined1 auStack_16 [4];
  undefined4 local_12 [2];
  undefined1 *local_a;
  undefined1 local_6;
  
  local_a = auStack_16;
  local_12[0] = 1;
  local_6 = 3;
  kcmdsend(local_12);
  Kinitflg = 1;
  timer(ktimout,10);
  return;
}


// ==== krecvdev @ 01024746

void krecvdev(void)

{
  bool bVar1;
  bool bVar2;
  short sVar3;
  ushort uVar4;
  short sVar5;
  uint uVar6;
  
  sVar3 = DAT_0104755e;
  sVar5 = 0;
  uVar4 = 0;
  bVar2 = false;
  uVar6 = 0;
  bVar1 = false;
  if (0 < Kbytecnt) {
    do {
      if ((sVar3 + -1 == (int)DAT_0104755c) && ((sVar3 != 0 || (DAT_0104755c == 0xf)))) break;
      if ((bVar1) ||
         ((((byte)(&Kbytebuf)[sVar5] < 0x80 || (0x85 < (byte)(&Kbytebuf)[sVar5])) &&
          ((&Kbytebuf)[sVar5] != -0x73)))) {
        if (Frgread == '\x01') {
          uVar4 = (ushort)(byte)(&Kbytebuf)[sVar5];
          Frgread = '\0';
          bVar2 = true;
        }
        else {
          (&Kcdbuf)[DAT_0104755c] = (ushort)(byte)(&Kbytebuf)[sVar5] | (ushort)uVar6;
          uVar6 = 0;
          if (DAT_0104755c == 0xf) {
            DAT_0104755c = 0;
          }
          else {
            DAT_0104755c = DAT_0104755c + 1;
          }
        }
        bVar1 = false;
      }
      else {
        if ((&Kbytebuf)[sVar5] == -0x7d) {
          can_time(ktimout);
          uVar4 = 1;
        }
        else {
          if ((&Kbytebuf)[sVar5] != -0x7c) {
            if ((&Kbytebuf)[sVar5] == -0x7e) {
              can_time(ktimout);
              Frgread = '\x01';
              bVar1 = true;
            }
            else if ((&Kbytebuf)[sVar5] != -0x7b) {
              if (((&Kbytebuf)[sVar5] == -0x80) || ((&Kbytebuf)[sVar5] == -0x7f)) {
                uVar6 = 0x100 << (-((&Kbytebuf)[sVar5] == -0x7f) & 1U) & 0xffff;
                bVar1 = true;
              }
              else if ((&Kbytebuf)[sVar5] == -0x73) {
                uVar6 = 0x300;
                bVar1 = true;
              }
            }
            goto LAB_010248e2;
          }
          can_time(ktimout);
          uVar4 = 0xffff;
        }
        bVar2 = true;
      }
LAB_010248e2:
      sVar5 = sVar5 + 1;
    } while (sVar5 < Kbytecnt);
  }
  _mskon();
  Kbytecnt = 0;
  _mskoff();
  if ((bVar2) && ((Kbusyflg == '\x01' || (Kinitflg == '\x01')))) {
    if (Kinitflg == '\x01') {
      if (uVar4 == 0xffff) {
        kinitdev();
      }
      else {
        Kinitflg = '\0';
        iodone(0x81);
      }
    }
    else {
      Kbusyflg = '\0';
      *DAT_01047584 = (int)(short)uVar4;
      post(DAT_01047576,1);
    }
  }
  return;
}


// ==== dialstat @ 01024974

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined2 dialstat(void)

{
  return *(undefined2 *)(&DAT_0d01ca02 + _DAT_0d01cbe0);
}


// ==== kreqfunk @ 010249a4

void kreqfunk(int param_1)

{
  if (*(char *)(param_1 + 0x14) == '\0') {
    kreqstat(param_1 + 8);
  }
  else {
    if (*(char *)(param_1 + 0x14) == '\x01') {
      kreqhead(param_1);
      return;
    }
    kreqtail(param_1 + 8);
  }
  Kreqflg = 0;
  return;
}


// ==== kreqvolfu @ 010249e2

void kreqvolfu(int param_1)

{
  char cVar1;
  undefined4 *puVar2;
  undefined4 unaff_D7;
  
  puVar2 = (undefined4 *)(param_1 + 8);
  cVar1 = *(char *)(param_1 + 0x14);
  if (cVar1 == '\x14') {
    kreqvol(puVar2);
  }
  if (cVar1 == '\x15') {
    s_ltopa(*(undefined1 *)(param_1 + 2),*puVar2);
    *puVar2 = unaff_D7;
    kreqvolbl(puVar2);
  }
  return;
}


// ==== kreqvol @ 01024a32

void kreqvol(int *param_1)

{
  int iVar1;
  ushort uVar2;
  
  iVar1 = (*param_1 + *param_1 * 2) * 2;
  if ((&DAT_0d01c9d0)[iVar1] == '\0') {
    uVar2 = *(ushort *)(iVar1 + 0xd01c9d2);
  }
  else {
    uVar2 = *(ushort *)(&DAT_0d01c9d4 + iVar1);
  }
  *(uint *)param_1[2] = (uint)uVar2;
  return;
}


// ==== kreqvolbl @ 01024a6a

char kreqvolbl(undefined4 *param_1)

{
  char cVar1;
  short sVar2;
  char *pcVar3;
  undefined2 *puVar4;
  
  puVar4 = (undefined2 *)*param_1;
  pcVar3 = &DAT_0d01c9d0;
  sVar2 = 0;
  do {
    cVar1 = *pcVar3;
    if (cVar1 == '\0') {
      *puVar4 = *(undefined2 *)(pcVar3 + 2);
    }
    else {
      *puVar4 = *(undefined2 *)(pcVar3 + 4);
    }
    sVar2 = sVar2 + 1;
    pcVar3 = pcVar3 + 6;
    puVar4 = puVar4 + 1;
  } while (sVar2 < 6);
  *(undefined4 *)param_1[2] = 1;
  return cVar1;
}


// ==== kreqstat @ 01024aa2

void kreqstat(int param_1)

{
  int *piVar1;
  int iVar2;
  
  if (DAT_0104755c < DAT_0104755e) {
    piVar1 = *(int **)(param_1 + 8);
    iVar2 = DAT_0104755c + 0x10;
  }
  else {
    piVar1 = *(int **)(param_1 + 8);
    iVar2 = (int)DAT_0104755c;
  }
  *piVar1 = iVar2 - DAT_0104755e;
  return;
}


// ==== kreqhead @ 01024ae4

void kreqhead(int param_1)

{
  short sVar1;
  int iVar2;
  undefined2 *puVar3;
  int *piVar4;
  
  iVar2 = *(int *)(param_1 + 8);
  sVar1 = DAT_0104755e;
  puVar3 = *(undefined2 **)(param_1 + 0xc);
  while ((iVar2 != 0 && (DAT_0104755c != sVar1))) {
    *puVar3 = (&Kcdbuf)[sVar1];
    iVar2 = iVar2 + -1;
    if (sVar1 == 0xf) {
      sVar1 = 0;
      puVar3 = puVar3 + 1;
    }
    else {
      sVar1 = sVar1 + 1;
      puVar3 = puVar3 + 1;
    }
  }
  if (iVar2 == 0) {
    if (DAT_0104755c < sVar1) {
      piVar4 = *(int **)(param_1 + 0x10);
      iVar2 = DAT_0104755c + 0x10;
    }
    else {
      piVar4 = *(int **)(param_1 + 0x10);
      iVar2 = (int)DAT_0104755c;
    }
    DAT_0104755e = sVar1;
    *piVar4 = iVar2 - sVar1;
    Kreqflg = 0;
  }
  else {
    *(int *)(param_1 + 8) = iVar2;
    Kreqflg = 1;
    cpybuf(param_1,&Kreqpint,0x16);
  }
  return;
}


// ==== kreqtail @ 01024b86

void kreqtail(int *param_1)

{
  int iVar1;
  short sVar2;
  undefined2 auStack_24 [16];
  
  iVar1 = *param_1;
  auStack_24[iVar1] = 0;
  sVar2 = DAT_0104755c;
  while ((iVar1 != 0 && (sVar2 != DAT_0104755e))) {
    if (sVar2 == 0) {
      sVar2 = 0xf;
    }
    else {
      sVar2 = sVar2 + -1;
    }
    iVar1 = iVar1 + -1;
    auStack_24[iVar1] = (&Kcdbuf)[sVar2];
  }
  if (iVar1 != *param_1) {
    cpybuf(auStack_24 + iVar1,param_1[1],(*param_1 - iVar1) * 2);
  }
  DAT_0104755e = DAT_0104755c;
  *(int *)param_1[2] = *param_1 - iVar1;
  return;
}


// ==== keytask @ 01024c00

/* WARNING: Heritage AFTER dead removal. Example location: r0x00000000 : 0x01024eca */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */
/* WARNING: Restarted to delay deadcode elimination for space: ram */

void keytask(void)

{
  int unaff_D7;
  undefined1 auStack_28 [2];
  undefined1 local_26;
  undefined4 local_1e;
  undefined4 local_1a;
  undefined4 local_16;
  
  DAT_010475ac = 0;
  do {
    wtmsg();
    while (remsg(auStack_28), unaff_D7 == 0) {
      s_ltopa(local_26,local_1e);
      if (uRam00000000._0_1_ == 0x26) {
        s_ltopa(local_26,local_1a);
        osfbuzon(uRam00000000);
LAB_01024e70:
        s_ltopa(local_26,local_16);
        uRam00000000 = uRam00000000 & 0xffff;
      }
      else if (uRam00000000._0_1_ < 0x27) {
        if (uRam00000000._0_1_ == 0x22) {
          s_ltopa(local_26,local_1a);
          osfstvol(uRam00000000);
          goto LAB_01024e70;
        }
        if (uRam00000000._0_1_ < 0x23) {
          if (uRam00000000._0_1_ == 0x20) {
            s_ltopa(local_26,local_1a);
            _DAT_010475ae = uRam00000000;
          }
          else if (uRam00000000._0_1_ == 0x21) {
            s_ltopa(local_26,local_1a);
            stwhlmod((int)(short)uRam00000000,(int)(short)uRam00000004);
            s_ltopa(local_26,local_16);
            uRam00000000 = uRam00000000 & 0xffff;
          }
        }
        else if (uRam00000000._0_1_ == 0x24) {
          s_ltopa(local_26,local_1a);
          osfstkbd(uRam00000000,uRam00000004,uRam00000008);
          s_ltopa(local_26,local_16);
          uRam00000000 = uRam00000000 & 0xffff;
        }
        else if (uRam00000000._0_1_ < 0x25) {
          if (uRam00000000._0_1_ == 0x23) {
            s_ltopa(local_26,local_1a);
            osfkrgrw(uRam00000000,uRam00000004,uRam00000008);
            s_ltopa(local_26,local_16);
            uRam00000000 = 0;
          }
        }
        else if (uRam00000000._0_1_ == 0x25) {
          s_ltopa(local_26,local_1a);
          osfstled(uRam00000000);
          goto LAB_01024e70;
        }
      }
      else if (uRam00000000._0_1_ == 0x32) {
        s_ltopa(local_26,local_1a);
        s_ltopa(local_26,uRam00000008);
        osfkcgset(uRam00000000,uRam00000004);
LAB_01025010:
        s_ltopa(local_26,local_16);
        uRam00000000 = uRam00000000 & 0xffff;
      }
      else if (uRam00000000._0_1_ < 0x33) {
        if (uRam00000000._0_1_ == 0x30) {
          s_ltopa(local_26,local_1a);
          osfkled(uRam00000000,uRam00000004,uRam00000008,uRam0000000c);
LAB_01024f44:
          s_ltopa(local_26,local_16);
          uRam00000000 = uRam00000000 & 0xffff;
        }
        else if (uRam00000000._0_1_ < 0x31) {
          if (uRam00000000._0_1_ == 0x27) {
            s_ltopa(local_26,local_1a);
            s_ltopa(local_26,uRam00000004);
            osfkarep(uRam00000000);
            goto LAB_01025010;
          }
        }
        else if (uRam00000000._0_1_ == 0x31) {
          s_ltopa(local_26,local_1a);
          s_ltopa(local_26,uRam0000000c);
          osfklcd(uRam00000000,uRam00000004,uRam00000008);
          s_ltopa(local_26,local_16);
          uRam00000000 = uRam00000000 & 0xffff;
        }
      }
      else if (uRam00000000._0_1_ == 0xfa) {
        DAT_010475ac = 0;
      }
      else if (uRam00000000._0_1_ < 0xfb) {
        if (uRam00000000._0_1_ == 0x33) {
          s_ltopa(local_26,local_1a);
          s_ltopa(local_26,uRam00000004);
          osfkbkled(uRam00000000);
          goto LAB_01024f44;
        }
      }
      else if (uRam00000000._0_1_ == 0xfb) {
        DAT_010475ac = 1;
      }
      post(local_26,1);
    }
  } while( true );
}


// ==== stwhlmod @ 0102505e

void stwhlmod(short param_1,short param_2)

{
  undefined1 auStack_16 [4];
  uint local_12 [2];
  undefined1 *local_a;
  undefined1 local_6;
  
  local_6 = 4;
  local_a = auStack_16;
  if (param_1 == 0) {
    if (param_2 < 0) {
      local_12[0] = 0;
    }
    else {
      local_12[0] = 1;
    }
  }
  else if (param_1 == 1) {
    local_12[0] = 0x104;
  }
  else if (param_1 == 2) {
    if (param_2 < 0) {
      local_12[0] = 2;
    }
    else {
      local_12[0] = 3;
    }
  }
  else {
    local_12[0] = 0x105;
  }
  local_12[0] = local_12[0] | (int)param_2 << 0x10;
  kcdsmsg(local_12);
  return;
}


// ==== osfstvol @ 010250d2

void osfstvol(byte param_1)

{
  undefined1 auStack_16 [4];
  uint local_12 [2];
  undefined1 *local_a;
  undefined1 local_6;
  
  local_6 = 7;
  local_a = auStack_16;
  local_12[0] = (uint)param_1;
  kcdsmsg(local_12);
  return;
}


// ==== osfkrgrw @ 01025100

void osfkrgrw(int param_1,int param_2,byte param_3)

{
  undefined1 auStack_16 [4];
  uint local_12 [2];
  undefined1 *local_a;
  undefined1 local_6;
  
  local_6 = 8;
  local_a = auStack_16;
  if (param_1 == 0x77) {
    local_12[0] = param_3 | 0x770000 | param_2 << 8;
  }
  else {
    local_12[0] = param_2 << 8 | 0x720000;
  }
  kcdsmsg(local_12);
  return;
}


// ==== osfstkbd @ 01025152

void osfstkbd(ushort param_1,ushort param_2,ushort param_3)

{
  undefined1 auStack_16 [4];
  uint local_12 [2];
  undefined1 *local_a;
  undefined1 local_6;
  
  local_6 = 3;
  local_a = auStack_16;
  local_12[0] = (uint)(ushort)(param_1 & 1 | (param_2 & 1) << 1 | (param_3 & 1) << 2);
  kcdsmsg(local_12);
  return;
}


// ==== osfstled @ 010251a2

void osfstled(uint param_1)

{
  undefined1 auStack_16 [4];
  uint local_12 [2];
  undefined1 *local_a;
  undefined1 local_6;
  
  local_6 = 6;
  local_a = auStack_16;
  local_12[0] = param_1 & 0xff;
  kcdsmsg(local_12);
  return;
}


// ==== osfbuzon @ 010251d2

void osfbuzon(undefined4 param_1)

{
  undefined1 auStack_16 [4];
  undefined4 local_12 [2];
  undefined1 *local_a;
  undefined1 local_6;
  
  local_6 = 5;
  local_a = auStack_16;
  local_12[0] = param_1;
  kcdsmsg(local_12);
  return;
}


// ==== osfkarep @ 010251fa

void osfkarep(int param_1,undefined4 param_2,uint param_3)

{
  undefined1 auStack_16 [4];
  uint local_12;
  undefined4 local_e;
  undefined1 *local_a;
  undefined1 local_6;
  
  if (((int)param_3 < 0x41) && (0 < (int)param_3)) {
    local_6 = 9;
    local_a = auStack_16;
    local_e = param_2;
    local_12 = param_3 | param_1 << 0x10;
    kcdsmsg(&local_12);
  }
  return;
}


// ==== osfkled @ 01025242

void osfkled(uint param_1,int param_2,int param_3,int param_4)

{
  undefined1 auStack_16 [4];
  uint local_12 [2];
  undefined1 *local_a;
  undefined1 local_6;
  
  if ((int)param_1 < 0x1a) {
    local_6 = 0x16;
    local_a = auStack_16;
    local_12[1] = 0;
    if (param_4 == 0) {
      local_12[0] = 0;
    }
    else {
      local_12[0] = 0x80;
    }
    if (param_2 != 0) {
      local_12[0] = local_12[0] | 0x40;
    }
    if (param_3 != 0) {
      local_12[0] = local_12[0] | 0x20;
    }
    local_12[0] = param_1 | local_12[0];
    kcdsmsg(local_12);
  }
  return;
}


// ==== osfkbkled @ 010252a0

void osfkbkled(undefined4 param_1,undefined4 param_2)

{
  undefined1 auStack_16 [4];
  undefined4 local_12;
  undefined4 local_e;
  undefined1 *local_a;
  undefined1 local_6;
  
  local_6 = 0x18;
  local_a = auStack_16;
  local_e = param_2;
  local_12 = param_1;
  kcdsmsg(&local_12);
  return;
}


// ==== osfklcd @ 010252ce

void osfklcd(int param_1,int param_2,uint param_3,undefined4 param_4)

{
  undefined1 auStack_16 [4];
  uint local_12;
  undefined4 local_e;
  undefined1 *local_a;
  undefined1 local_6;
  
  if ((int)param_3 < 0x51) {
    local_6 = 0x17;
    local_a = auStack_16;
    local_e = param_4;
    local_12 = param_3 | param_2 << 8 | param_1 << 0x10;
    kcdsmsg(&local_12);
  }
  return;
}


// ==== osfkcgset @ 0102531a

void osfkcgset(int param_1,uint param_2,undefined4 param_3)

{
  undefined1 auStack_16 [4];
  uint local_12;
  undefined4 local_e;
  undefined1 *local_a;
  undefined1 local_6;
  
  local_6 = 0x19;
  local_a = auStack_16;
  local_e = param_3;
  local_12 = param_2 | param_1 << 0x10;
  kcdsmsg(&local_12);
  return;
}


// ==== kcdsmsg @ 01025352

void kcdsmsg(uint *param_1)

{
  uint unaff_D7;
  undefined1 auStack_12 [14];
  
  cpybuf(param_1,auStack_12,0xe);
  dsemsg(0xe,0x81,param_1);
  do {
    wait((void *)0x0);
  } while ((unaff_D7 & 1) == 0);
  if (((*(char *)(param_1 + 3) != '\b') || ((*param_1 >> 0x10 & 0xff) != 0x72)) &&
     (*(int *)param_1[2] == 0)) {
    do {
      wait((void *)0x0);
    } while ((unaff_D7 & 0x40000000) == 0);
    dsemsg(0xe,0x81,auStack_12);
    do {
      wait((void *)0x0);
    } while ((unaff_D7 & 1) == 0);
  }
  return;
}


// ==== schpcb @ 01025408

uint schpcb(uint param_1,ushort param_2)

{
  int iVar1;
  uint uVar2;
  
  uVar2 = (int)param_1 >> 0x19 & 7;
  if (param_2 == 1) {
    if ((param_1 & 0xf0000000) == 0xa0000000) {
      uVar2 = uVar2 + 8;
    }
    iVar1 = 0;
  }
  else {
    if (param_2 != 2) {
      return (uint)param_2;
    }
    if ((param_1 & 0xf0000000) == 0xb0000000) {
      uVar2 = uVar2 + 8;
    }
    iVar1 = 1;
  }
  return (&shpcb)[uVar2 * 2 + iVar1];
}


// ==== _ltoph @ 01025476

void _ltoph(int param_1,uint param_2)

{
  if (((*(uint *)(param_1 + 0x2c) <= param_2) &&
      (param_2 < (uint)(*(int *)(param_1 + 0x2c) + *(int *)(param_1 + 0x30) * 4))) ||
     ((*(uint *)(param_1 + 0x34) <= param_2 &&
      (param_2 < (uint)(*(int *)(param_1 + 0x34) + *(int *)(param_1 + 0x38) * 4))))) {
    mmuwalk(param_1,param_2);
  }
  return;
}


// ==== _ltopa @ 010254c6

void _ltopa(ushort *param_1,uint param_2)

{
  int unaff_D7;
  
  if (*(char *)((int)param_1 + 0x49) != '\0') {
    mmuwalk(&syspcb + (uint)*(byte *)((int)param_1 + 0x49) * 0x40,param_2);
    if (unaff_D7 != -1) {
      return;
    }
    if ((((param_2 & 0xf0000000) == 0xb0000000) || ((param_2 & 0xf0000000) == 0xd0000000)) &&
       ((param_1[0x24] & 0x2000) != 0)) {
      schpcb(param_2,2);
      _ltoph();
    }
    if ((((param_2 & 0xf0000000) == 0xa0000000) || ((param_2 & 0xf0000000) == 0xc0000000)) &&
       ((param_1[0x24] & 0x4000) != 0)) {
      schpcb(param_2,1);
      _ltoph();
    }
  }
  if ((*param_1 & 0x100) == 0) {
    trapv();
  }
  return;
}


// ==== _latopa @ 010255b0

void _latopa(int param_1)

{
  int unaff_D7;
  
  gettcb(*(undefined4 *)(param_1 + 4));
  if (unaff_D7 != -3) {
    _ltopa();
  }
  return;
}


// ==== _sltopa @ 010255e2

void _sltopa(int param_1,uint param_2)

{
  int unaff_D7;
  
  if ((*(char *)(param_1 + 0x49) != '\0') &&
     (mmuwalk(&syspcb + (uint)*(byte *)(param_1 + 0x49) * 0x40,param_2), unaff_D7 == -1)) {
    if ((((param_2 & 0xf0000000) == 0xb0000000) || ((param_2 & 0xf0000000) == 0xd0000000)) &&
       ((*(byte *)(param_1 + 0x48) & 0x20) != 0)) {
      schpcb(param_2,2);
      _ltoph();
    }
    if ((((param_2 & 0xf0000000) == 0xa0000000) || ((param_2 & 0xf0000000) == 0xc0000000)) &&
       ((*(byte *)(param_1 + 0x48) & 0x40) != 0)) {
      schpcb(param_2,1);
      _ltoph();
    }
  }
  return;
}


// ==== s_ltopa @ 010256c6

void s_ltopa(undefined4 param_1)

{
  int unaff_D7;
  
  gettcb(param_1);
  if (unaff_D7 != -3) {
    _sltopa();
  }
  return;
}


// ==== _ctltop @ 010256ee

void _ctltop(int param_1)

{
  _ltopa(*(undefined4 *)(etcb + 0x3c),*(undefined4 *)(param_1 + 4));
  return;
}


// ==== getdipsw @ 01025710

undefined1 getdipsw(void)

{
  return DAT_0f00b002;
}


// ==== set7seg @ 01025724

void set7seg(undefined1 param_1)

{
  DAT_0f00b003 = param_1;
  getdipsw();
  return;
}


// ==== FUN_01025744 @ 01025744

void FUN_01025744(void)

{
  return;
}


// ==== FUN_01025876 @ 01025876

/* WARNING: Removing unreachable block (ram,0x01025aa6) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined1 FUN_01025876(undefined4 param_1,undefined4 param_2,int param_3,int param_4,int param_5)

{
  undefined2 *puVar1;
  undefined1 uVar2;
  uint uVar3;
  int iVar4;
  uint unaff_D7;
  ushort uVar5;
  char *pcVar6;
  
  _ltoph(&syspcb + param_3 * 0x40,*(undefined4 *)(param_4 + 0x14));
  ewsl_read();
  if (*(uint *)(param_4 + 4) == unaff_D7) {
    if (_DAT_0107da80 == 0) {
      uVar5 = 0;
    }
    else {
      uVar5 = *(ushort *)(unaff_D7 + 0xc);
    }
    if ((uVar5 & 8) == 0) {
      _ltoph(&syspcb + param_3 * 0x40,*(undefined4 *)(param_4 + 0x18));
      ewsl_read();
      if (*(uint *)(param_4 + 8) != unaff_D7) {
        pcVar6 = "load_ewsl_1: Drive #%d %s: ewsl_read(DATA) error.\n";
        goto LAB_01025ab4;
      }
    }
    ewsl_read(param_5,*(undefined2 *)(param_4 + 2));
    if (*(ushort *)(param_4 + 2) == unaff_D7) {
      if ((uVar5 & 1) != 0) {
        uVar3 = (uint)(*(ushort *)(param_4 + 2) >> 4);
        sym_alloc(&syspcb + param_3 * 0x40,(uVar3 + 1) * 0xc);
        if (unaff_D7 == 0) {
          pcVar6 = "load_ewsl_1: Drive #%d %s: sym_alloc() error.\n";
          goto LAB_01025ab4;
        }
        pcVar6 = *(char **)(&DAT_010557a4 + param_3 * 0x80);
        strcpy(pcVar6,"/DBGSYM/");
        *(uint *)(pcVar6 + 8) = uVar3;
        iVar4 = 0;
        if (uVar3 != 0) {
          do {
            cpybuf(param_5 + 6 + iVar4 * 0x10,pcVar6 + iVar4 * 0xc + 0xc,8);
            *(undefined4 *)(pcVar6 + iVar4 * 0xc + 0x14) = *(undefined4 *)(param_5 + iVar4 * 0x10);
            iVar4 = iVar4 + 1;
          } while (iVar4 < (int)uVar3);
        }
      }
      ewsl_chec();
      if (unaff_D7 == 0) {
        if (iRam00000004 == 0) {
          return 0;
        }
        if ((uVar5 & 2) != 0) {
          _mskon();
          puVar1 = &syspcb + param_3 * 0x40;
          mmu_txpro(puVar1,0);
          mmusetup(param_3);
          _setbk(iRam00000004,puVar1);
          mmu_txpro(puVar1,1);
          _mskoff();
        }
        crtask(0,param_3);
        return uRam00000003;
      }
      pcVar6 = "load_ewsl_1: Drive #%d %s: CRC-16 error.\n";
    }
    else {
      pcVar6 = "load_ewsl_1: Drive #%d %s: ewsl_read(SYMBOL) error.\n";
    }
  }
  else {
    pcVar6 = "load_ewsl_1: Drive #%d %s: ewsl_read(TEXT) error.\n";
  }
LAB_01025ab4:
  uVar2 = FUN_01025744(pcVar6,param_1,param_2);
  return uVar2;
}


// ==== load_ewsl @ 01025bdc

/* WARNING: Removing unreachable block (ram,0x01025c64) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void load_ewsl(undefined4 param_1,char *param_2,int param_3)

{
  FILE *__stream;
  uint unaff_D7;
  undefined1 *puVar1;
  undefined1 *puVar2;
  undefined1 auStackY_d4 [128];
  undefined1 auStack_20 [2];
  ushort local_1e;
  
  bitneg();
  __stream = (FILE *)(unaff_D7 & 0xe0);
  _DAT_0107da80 = __stream;
  FUN_01025744("load_ewsl: Drive #%d %s: load start.\n");
  fdrive(param_1);
  fopen(param_2,"r");
  if (__stream == (FILE *)0x0) {
    FUN_01025744();
    return;
  }
  ewsl_open();
  bve_crpcb();
  if (__stream == (FILE *)0x0) {
    FUN_01025744();
    puVar2 = auStackY_d4 + 0x90;
  }
  else {
    sprintf((char *)(param_3 * 0x80 + 0x10557b0),"%-16.16s",param_2);
    chkadr(&syspcb + param_3 * 0x40,auStack_20);
    if (__stream == (FILE *)0x0) {
      FUN_01025744();
      puVar1 = auStackY_d4 + 0x90;
    }
    else {
      malloc((uint)local_1e);
      if (__stream == (FILE *)0x0) {
        FUN_01025744();
        return;
      }
      FUN_01025876(param_1,param_2);
      if (__stream != (FILE *)0x0) {
        mfree();
        ewsl_clos();
        fclose(__stream);
        return;
      }
      mfree();
      puVar1 = auStackY_d4 + 0x98;
    }
    *(int *)(puVar1 + -4) = param_3;
    *(undefined4 *)(puVar1 + -8) = 0x1025d38;
    delpcb();
    puVar2 = puVar1 + -4;
  }
  *(undefined4 *)(puVar2 + -4) = 0x1025d3e;
  ewsl_clos();
  *(FILE **)(puVar2 + -4) = __stream;
  *(undefined4 *)(puVar2 + -8) = 0x1025d46;
  fclose(*(FILE **)(puVar2 + -4));
  return;
}


// ==== asgetdrv @ 01025d7c

undefined8 asgetdrv(void)

{
  byte bVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  byte unaff_D7b;
  
  sbpeek(0xf00a7f9);
  bVar1 = unaff_D7b & 7;
  uVar3 = 2;
  if (bVar1 == 2) {
    uVar2 = 1;
  }
  else {
    if (bVar1 < 3) {
      uVar3 = 1;
    }
    else {
      uVar3 = 4;
      if (bVar1 == 4) {
        uVar2 = 6;
        goto LAB_01025db2;
      }
    }
    uVar2 = 0;
  }
LAB_01025db2:
  return CONCAT44(uVar2,uVar3);
}


// ==== lodtsk @ 01025ddc

/* WARNING: Removing unreachable block (ram,0x01025f34) */

void lodtsk(void)

{
  int unaff_D7;
  undefined1 auStack_36 [18];
  undefined1 auStack_24 [2];
  undefined1 local_22;
  undefined1 local_1c;
  undefined1 local_1a;
  undefined1 local_19;
  undefined1 auStack_18 [16];
  undefined4 local_8;
  
  do {
    asgetdrv();
    fs_mount();
  } while (unaff_D7 < 0);
  if508moun();
  if (unaff_D7 == 1) {
    fs_open();
    fs_clos();
    if508rdy();
    wait((void *)0x0);
  }
  load_ewsl();
  if (unaff_D7 == 0) {
    fs_open();
    set_pno = 1;
    ebload(0,1,1);
    set_pno = set_pno + 1;
  }
  else {
    set_pno = 2;
  }
  fs_demnt();
  do {
    do {
      wtmsg();
      remsg(auStack_24);
    } while (unaff_D7 != 0);
    latopa(local_22,local_8);
    load_ewsl(local_19,auStack_18,set_pno);
    uRam00000000 = 0;
    fs_open(local_19,auStack_18,0,auStack_36);
    ebload(0,set_pno,local_1a,local_19,local_1c,auStack_18);
    uRam00000000 = 0;
    set_pno = set_pno + 1;
    post(local_22,0x4000000);
  } while( true );
}


// ==== ebload @ 01025fc4

/* WARNING: Removing unreachable block (ram,0x010260ce) */
/* WARNING: Removing unreachable block (ram,0x01026126) */
/* WARNING: Removing unreachable block (ram,0x01026148) */
/* WARNING: Removing unreachable block (ram,0x0102614e) */
/* WARNING: Removing unreachable block (ram,0x0102617a) */
/* WARNING: Restarted to delay deadcode elimination for space: stack */

void ebload(short param_1,int param_2,undefined4 param_3,undefined4 param_4,uint param_5,
           char *param_6)

{
  int iVar1;
  bool bVar2;
  int unaff_D7;
  undefined2 *unaff_A4;
  undefined1 auStack_36 [4];
  undefined1 auStack_2e [4];
  int local_2a;
  undefined1 auStack_20 [4];
  int local_1c;
  int local_18;
  
  bVar2 = false;
  fs_read(param_4,(int)param_1,0x1c,auStack_20,auStack_36);
  dosstt();
  if (unaff_D7 == 0x1c) {
    bve_crpcb(param_2,auStack_20);
    iVar1 = param_2 * 0x80;
    unaff_A4 = &syspcb + param_2 * 0x40;
    sprintf((char *)(iVar1 + 0x10557b0),"%-16.16s",param_6);
    chkadr(unaff_A4,auStack_20);
    _ltoph(unaff_A4,*(undefined4 *)(&DAT_0105578c + iVar1));
    fs_read(param_4,(int)param_1,local_1c);
    dosstt();
    if (local_1c == 0x1c) {
      cpybuf();
      bitneg(DAT_0f00b002);
      param_5 = 0;
      _ltoph(unaff_A4,*(undefined4 *)(&DAT_01055794 + iVar1));
      fs_read(param_4,(int)param_1,local_18,0,auStack_36);
      dosstt(0);
      if (local_18 == 0) {
        bVar2 = true;
      }
    }
  }
  fs_clos(param_4,(int)param_1,auStack_36);
  if ((bVar2) && (local_2a != 0)) {
    if ((param_5 & 2) != 0) {
      _mskon();
      mmu_txpro(unaff_A4,0);
      mmusetup((int)(short)unaff_A4[1]);
      _setbk(local_2a,unaff_A4);
      mmu_txpro(unaff_A4,1);
      _mskoff();
    }
    crtask(auStack_2e,(int)(short)unaff_A4[1]);
  }
  return;
}


// ==== bve_crpcb @ 0102622a

void bve_crpcb(undefined4 param_1,int param_2)

{
  DAT_010475ca = 0x40;
  DAT_010475cb = 0x20;
  DAT_010475cc = *(uint *)(param_2 + 0x14) & 0xfe000000;
  DAT_010475d0 = *(int *)(param_2 + 4) + 0x3ffU & 0xfffffc00;
  DAT_010475d4 = *(uint *)(param_2 + 0x18) & 0xfe000000;
  DAT_010475d8 = *(int *)(param_2 + 0xc) + *(int *)(param_2 + 8) + 0x3ffU & 0xfffffc00;
  crpcb(param_1,&DAT_010475ca);
  return;
}


// ==== chkadr @ 010262a2

uint chkadr(int param_1,int param_2)

{
  uint uVar1;
  
  if ((((*(int *)(param_2 + 4) == 0) ||
       ((uVar1 = *(uint *)(param_2 + 0x14), *(uint *)(param_1 + 0x2c) <= uVar1 &&
        (uVar1 = *(int *)(param_1 + 0x30) + *(int *)(param_1 + 0x2c),
        (uint)(*(int *)(param_2 + 4) + *(int *)(param_2 + 0x14)) <= uVar1)))) &&
      (uVar1 = 0, *(int *)(param_2 + 8) != 0)) &&
     (uVar1 = *(uint *)(param_2 + 0x18), *(uint *)(param_1 + 0x34) <= uVar1)) {
    uVar1 = *(int *)(param_1 + 0x38) + *(int *)(param_1 + 0x34);
  }
  return uVar1;
}


// ==== symlod @ 01026316

void symlod(undefined4 param_1,short param_2,ushort param_3,undefined4 param_4,int param_5)

{
  int iVar1;
  uint uVar2;
  uint uVar3;
  int unaff_D7;
  undefined4 *unaff_A4;
  undefined1 auStack_20c [4];
  undefined4 local_204 [128];
  
  uVar2 = (uint)(param_3 >> 4);
  sym_alloc(param_5,uVar2 << 4);
  if (unaff_D7 == 1) {
    iVar1 = *(int *)(param_5 + 0x44);
    fill(iVar1,*(int *)(param_5 + 0x48) << 10,0);
    cpybuf("/DBGSYM/",iVar1,8);
    *(uint *)(iVar1 + 8) = uVar2;
    uVar3 = 0;
    if (uVar2 != 0) {
      do {
        if (uVar3 == 0) {
          if ((int)uVar2 < 0x21) {
            uVar3 = uVar2;
          }
          else {
            uVar3 = 0x20;
          }
          fs_read(param_1,(int)param_2,uVar3 * 0x10,local_204,auStack_20c);
          dosstt();
          if (uVar3 * 0x10 != 1) {
            return;
          }
          unaff_A4 = local_204;
        }
        cpybuf((int)unaff_A4 + 6,iVar1 + 0xc,8);
        *(undefined4 *)(iVar1 + 0x14) = *unaff_A4;
        uVar2 = uVar2 - 1;
        uVar3 = uVar3 - 1;
        unaff_A4 = unaff_A4 + 4;
        iVar1 = iVar1 + 0xc;
      } while (uVar2 != 0);
    }
  }
  return;
}


// ==== siotrp @ 01026400

void siotrp(int param_1)

{
  if (param_1 == 0x20) {
    siorst();
    post(0xe,0x800);
  }
  else if (param_1 == 0x24) {
    DAT_0f001001 = 0x27;
    rtcwait();
    sioirqtx();
  }
  return;
}


// ==== siorst @ 01026446

void siorst(void)

{
  sioinit();
  return;
}


// ==== sioinit @ 01026454

void sioinit(void)

{
  fill(&siowork,0x688,0);
  _mskon();
  ini_pit1(DAT_01047604);
  DAT_0f000001 = 1;
  rtcwait();
  DAT_0f001001 = DAT_010475f9;
  rtcwait();
  DAT_0f001001 = DAT_010475fb;
  rtcwait();
  DAT_0f001001 = DAT_010475fd;
  rtcwait();
  DAT_0f001001 = DAT_010475ff;
  rtcwait();
  DAT_0f001001 = (undefined1)DAT_01047600;
  rtcwait();
  DAT_0f001001 = DAT_01047603;
  rtcwait();
  _mskoff();
  return;
}


// ==== siogen @ 010264f4

void siogen(void)

{
  irqvct(0x5e,sioirqbrk);
  irqvct(0x5d,sioirqrxt);
  irqvct(0x5f,sioirqrxt);
  crtask(&DAT_0104761c,0);
  devtrp(0,2,0x1e0);
  return;
}


// ==== sioirqrxt @ 0102654e

void sioirqrxt(void)

{
  byte bVar1;
  char cVar2;
  
  while( true ) {
    do {
      bVar1 = DAT_0f001001;
      rtcwait();
      cVar2 = DAT_0f001000;
      if ((bVar1 & 0x38) != 0) {
        if ((bVar1 & 2) == 0) {
          cVar2 = '\0';
        }
        else {
          rtcwait();
        }
        sioirqerr(bVar1,(int)cVar2);
        return;
      }
      if ((bVar1 & 2) != 0) {
        rtcwait();
        sioirqrx(bVar1,(int)cVar2);
      }
    } while ((bVar1 & 1) == 0);
    if (DAT_01087a6e == 0) break;
    sioirqtx();
  }
  DAT_0f001001 = 0x26;
  rtcwait();
  return;
}


// ==== sioirqerr @ 010265de

void sioirqerr(byte param_1,undefined1 param_2)

{
  uint uVar1;
  
  if ((int)siowork < 0) {
    uVar1 = (uint)DAT_01087a64;
    if ((uint)DAT_01087a65 != (uVar1 + 1 & 1)) {
      (&DAT_01087a76)[*(int *)(&DAT_01087a66 + uVar1 * 4) + uVar1 * 0x226] = param_2;
      siowork = siowork & 0xffe0ffff;
      *(uint *)(&DAT_01087a66 + uVar1 * 4) = (uint)param_1 << 0x10 | 0x80000000;
      DAT_01087a64 = DAT_01087a64 + 1 & 1;
      post(0xe,0x800);
    }
  }
  DAT_0f001001 = 0x37;
  rtcwait();
  return;
}


// ==== sioirqrx @ 01026684

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void sioirqrx(byte param_1,char param_2)

{
  byte bVar1;
  uint uVar2;
  
  bVar1 = DAT_01087a64;
  if (-1 < (int)siowork) {
    return;
  }
  uVar2 = (uint)DAT_01087a64;
  if ((uint)DAT_01087a65 == (uVar2 + 1 & 1)) {
    return;
  }
  if (*(int *)(&DAT_01087a66 + uVar2 * 4) < 0x226) {
    (&DAT_01087a76)[*(int *)(&DAT_01087a66 + uVar2 * 4) + uVar2 * 0x226] = param_2;
    *(int *)(&DAT_01087a66 + uVar2 * 4) = *(int *)(&DAT_01087a66 + uVar2 * 4) + 1;
    if (_Siodebug == 0) {
      if ((((siowork & 0x100000) == 0) && ((siowork & 0x40000) == 0)) && ((siowork & 0x80000) == 0))
      {
        if ((siowork & 0x20000) == 0) {
          if ((siowork & 0x10000) == 0) {
            if (param_2 == '\x16') {
              siowork = siowork | 0x10000;
              return;
            }
          }
          else {
            if (param_2 == '\x16') goto LAB_01026774;
            if (param_2 == '\x02') {
              siowork = siowork | 0x20000;
              return;
            }
            if (param_2 == '\x06') {
              siowork = siowork | 0x40000;
              return;
            }
            if (param_2 == '\x15') {
              siowork = siowork | 0x80000;
              return;
            }
          }
        }
        else {
          if (param_2 == '\x16') {
LAB_01026774:
            siowork = siowork & 0xffe1ffff | 0x10000;
            (&DAT_01087a76)[uVar2 * 0x226] = param_2;
            *(undefined4 *)(&DAT_01087a66 + uVar2 * 4) = 1;
            return;
          }
          if (param_2 == '\x03') {
            siowork = siowork | 0x100000;
            return;
          }
          if ('\x1f' < param_2) {
            return;
          }
        }
      }
      else if (param_2 == '\x16') {
        siowork = siowork & 0xffe0ffff;
        goto LAB_01026818;
      }
      siowork = siowork & 0xffe0ffff;
      *(undefined4 *)(&DAT_01087a66 + uVar2 * 4) = 0;
      return;
    }
    if (param_2 != '\r') {
      return;
    }
  }
  else {
    siowork = siowork & 0xffe0ffff;
    *(uint *)(&DAT_01087a66 + uVar2 * 4) = (uint)param_1 << 0x10 | 0x80000080;
  }
LAB_01026818:
  DAT_01087a64 = bVar1 + 1 & 1;
  post(0xe,0x800);
  return;
}


// ==== sioirqtx @ 01026830

void sioirqtx(void)

{
  if (DAT_01087a72 < DAT_01087a6e) {
    DAT_0f001000 = (&DAT_01087ec2)[DAT_01087a72];
    DAT_01087a72 = DAT_01087a72 + 1;
    rtcwait();
  }
  else {
    DAT_0f001001 = 0x26;
    rtcwait();
    DAT_01087a6e = 0;
    post(0xe,0x800);
  }
  return;
}


// ==== sioirqbrk @ 01026890

void sioirqbrk(void)

{
  byte bVar1;
  
  bVar1 = DAT_0f001001;
  rtcwait();
  if ((bVar1 & 0x40) != 0) {
    DAT_0f001001 = 0x37;
    rtcwait();
  }
  return;
}


// ==== _mclear @ 010268c4

void _mclear(void)

{
  undefined4 *puVar2;
  undefined4 *puVar1;
  
  puVar1 = &_ramtop;
  do {
    puVar2 = puVar1 + 1;
    *puVar1 = 0;
    puVar1 = puVar2;
  } while (puVar2 < &_ramend);
  fill(&_ivvct,0x400,0);
  return;
}


// ==== mem_frech @ 010268f4

void mem_frech(int *param_1,uint param_2,short param_3)

{
  short sVar1;
  
  sVar1 = 0;
  for (; (((uint)(int)sVar1 < param_2 && (param_3 != 0)) && (*param_1 == -0xc0));
      param_1 = param_1 + 1) {
    param_3 = param_3 + -1;
    sVar1 = sVar1 + 1;
  }
  return;
}


// ==== mmu_c_cop @ 01026930

void mmu_c_cop(int *param_1,uint *param_2)

{
  short sVar1;
  uint uVar2;
  short sVar3;
  uint *puVar4;
  
  sVar1 = 0;
  uVar2 = 0;
  sVar3 = 0;
  do {
    if (*param_1 != -0xc0) {
      uVar2 = (&DAT_01047630)[sVar1] | uVar2;
    }
    sVar1 = sVar1 + 1;
    puVar4 = param_2;
    if (0x1f < sVar1) {
      puVar4 = param_2 + 1;
      *param_2 = uVar2;
      uVar2 = 0;
      sVar1 = 0;
    }
    sVar3 = sVar3 + 1;
    param_1 = param_1 + 1;
    param_2 = puVar4;
  } while (sVar3 < 0x100);
  return;
}


// ==== mmu_c_d_c @ 01026980

void mmu_c_d_c(undefined4 *param_1)

{
  short sVar1;
  
  sVar1 = 0;
  do {
    *param_1 = 0;
    sVar1 = sVar1 + 1;
    param_1 = param_1 + 1;
  } while (sVar1 < 8);
  return;
}


// ==== mmu_openc @ 01026998

uint mmu_openc(int param_1,uint *param_2)

{
  short sVar2;
  uint uVar1;
  short sVar3;
  short sVar4;
  undefined1 *puVar5;
  
  sVar2 = (short)(param_1 + 8U >> 3);
  puVar5 = &mmu_opnbu;
  sVar4 = 0;
  do {
    if (*param_2 == 0xfffffff4) {
      uVar1 = *param_2;
      if (uVar1 == 0xfffffff4) {
        uVar1 = mmu_c_d_c(puVar5);
      }
    }
    else {
      uVar1 = mmu_c_cop(*param_2 & 0xfffffff0,puVar5);
    }
    puVar5 = puVar5 + 0x20;
    sVar4 = sVar4 + 1;
    param_2 = param_2 + 1;
  } while (sVar4 < 0x40);
  puVar5 = &mmu_opnbu;
  sVar4 = 0;
  do {
    sVar3 = 0;
    if (0 < sVar2) {
      do {
        uVar1 = (uint)(byte)puVar5[sVar3];
        if (puVar5[sVar3] != 0) break;
        sVar3 = sVar3 + 1;
      } while (sVar3 < sVar2);
    }
    if (sVar2 == sVar3) {
      return uVar1;
    }
    sVar4 = sVar4 + 1;
    puVar5 = puVar5 + 1;
    if (0x7ff < sVar4) {
      return uVar1;
    }
  } while( true );
}


// ==== memalloc @ 01026a32

void memalloc(int param_1,ushort *param_2,int param_3,undefined4 param_4,int param_5,short param_6)

{
  uint *puVar1;
  uint *puVar2;
  ushort uVar3;
  short sVar4;
  uint uVar5;
  uint uVar6;
  short sVar7;
  uint unaff_D7;
  ushort uVar8;
  int *piVar9;
  int iVar10;
  short local_16;
  ushort local_14;
  int local_a;
  
  local_16 = (short)(param_5 + 0x3ffU >> 10);
  if ((*param_2 & 0x100) == 0) {
    if ((*(int *)(param_3 + 0xc) != 0) &&
       ((puVar1 = (uint *)(*(int *)(param_3 + 0xc) + (param_6 * 0x2000000 + 0xe0000000U >> 0x19) * 4
                          ), *puVar1 != 0xfffffff4 || (mmuib_pcb(param_3,puVar1,0), unaff_D7 != 0)))
       ) {
      uVar6 = *puVar1;
      mmu_openc((int)local_16,uVar6 & 0xfffffff0);
      uVar8 = (ushort)unaff_D7;
      if (uVar8 != 0xffff) {
        local_14 = uVar8;
        if ((short)uVar8 < 0) {
          local_14 = uVar8 + 0xff;
        }
        sVar4 = (short)local_14 >> 8;
        sVar7 = (short)uVar8 % 0x100;
        puVar2 = (uint *)((uVar6 & 0xfffffff0) + sVar4 * 4);
        iVar10 = (short)uVar8 * 0x400 + param_6 * 0x2000000 + -0x20000000;
        local_a = 0;
        while ((sVar4 < 0x80 &&
               ((*puVar2 != 0xfffffff4 || (mmuic_pcb(param_3,puVar2,0), unaff_D7 != 0))))) {
          piVar9 = (int *)((*puVar2 & 0xfffffff0) + sVar7 * 4);
          for (; sVar7 < 0x100; sVar7 = sVar7 + 1) {
            if (*piVar9 == -0xc0) {
              mem_frech(piVar9,(int)local_16,0x100 - sVar7);
              uVar6 = unaff_D7 & 0xffff;
              if ((short)uVar8 < local_16) {
                iVar10 = (0x100 - sVar7) * 0x400 + iVar10;
                break;
              }
              if (param_1 == 0) {
                pageget((int)(short)uVar8);
              }
              else {
                smpageget((int)(short)uVar8);
              }
              if (unaff_D7 == 0) {
                return;
              }
              if (local_a == 0) {
                local_a = iVar10;
              }
              uVar5 = unaff_D7;
              uVar3 = uVar8;
              if (param_1 == 0) {
                pagemake();
              }
              else {
                smpagemak();
              }
              while (uVar3 != 0) {
                mmuc_set(piVar9,uVar5,0,0);
                uVar3 = (short)uVar6 - 1;
                uVar6 = (uint)uVar3;
                piVar9 = piVar9 + 1;
                uVar5 = uVar5 + 0x400;
              }
              local_16 = local_16 - uVar8;
              if (local_16 == 0) {
                if (param_6 != 0) {
                  setallocm(puVar1,(int)param_6,param_3);
                }
                iVar10 = mlogno;
                (&mem_log)[mlogno * 4] = 1;
                (&DAT_01086710)[iVar10 * 4] = local_a;
                (&DAT_01086714)[iVar10 * 4] = param_5;
                (&DAT_01086718)[iVar10 * 4] = (uint)*(byte *)((int)param_2 + 3);
                mlogno = mlogno + 1 & 0xff;
                return;
              }
              sVar7 = uVar8 + sVar7;
              piVar9 = piVar9 + (short)uVar8;
              iVar10 = (short)uVar8 * 0x400 + iVar10;
            }
            else {
              sVar7 = sVar7 + 7;
              piVar9 = piVar9 + 7;
              iVar10 = iVar10 + 0x2000;
            }
            piVar9 = piVar9 + 1;
          }
          sVar7 = 0;
          sVar4 = sVar4 + 1;
          puVar2 = puVar2 + 1;
        }
      }
    }
  }
  else {
    pageget((int)local_16);
    if (unaff_D7 != 0) {
      pagemake();
    }
  }
  return;
}


// ==== mmuerfree @ 01026d46

void mmuerfree(void)

{
  return;
}


// ==== memfree @ 01026d4e

void memfree(int param_1,ushort *param_2,int param_3,short param_4,uint param_5)

{
  uint *puVar1;
  int iVar2;
  ushort uVar3;
  short sVar4;
  short unaff_D7w;
  uint *puVar5;
  uint *puVar6;
  
  if ((*param_2 & 0x100) == 0) {
    if ((param_5 & 0xf0000000) == 0xe0000000) {
      if (*(int *)(param_3 + 0xc) == 0) {
        return;
      }
      puVar6 = (uint *)(*(int *)(param_3 + 0xc) + (param_5 >> 0x19) * 4);
      if (*puVar6 == 0xfffffff4) {
        return;
      }
      uVar3 = ((ushort)(param_5 >> 0x10) & 0x1fc) >> 2;
      puVar6 = (uint *)((*puVar6 & 0xfffffff0) + (short)uVar3 * 4);
      if (*puVar6 == 0xfffffff4) {
        return;
      }
      sVar4 = (short)((param_5 & 0x3fc00) >> 10);
      puVar1 = (uint *)((*puVar6 & 0xfffffff0) + sVar4 * 4);
      if (*puVar1 == 0xffffff40) {
        return;
      }
      if (param_1 == 0) {
        seqpagefr(*puVar1 & 0xffffff00);
      }
      else {
        smseqpage(*puVar1 & 0xffffff00);
      }
      puVar5 = puVar1 + 1;
      *puVar1 = 0xffffff40;
      sVar4 = sVar4 + 1;
      if (0 < unaff_D7w) {
        for (; (unaff_D7w != 0 && ((short)uVar3 < 0x80)); uVar3 = uVar3 - 1) {
          for (; (unaff_D7w != 0 && (sVar4 < 0x100)); sVar4 = sVar4 + 1) {
            *puVar5 = 0xffffff40;
            unaff_D7w = unaff_D7w + -1;
            puVar5 = puVar5 + 1;
          }
          puVar6 = puVar6 + 1;
          puVar5 = (uint *)(*puVar6 & 0xfffffff0);
          sVar4 = 0;
        }
      }
      iVar2 = mlogno;
      (&mem_log)[mlogno * 4] = 2;
      (&DAT_01086710)[iVar2 * 4] = param_5;
      (&DAT_01086714)[iVar2 * 4] = 0;
      (&DAT_01086718)[iVar2 * 4] = (uint)*(byte *)((int)param_2 + 3);
      mlogno = mlogno + 1 & 0xff;
      return;
    }
  }
  else if (param_1 == 0) {
    if ((0x1089b50 < param_5) && (param_5 < 0x1400000)) {
      seqpagefr(param_5 & 0xffffff00);
      return;
    }
    if ((0x7fffff < param_5) && (param_5 < 0x900000)) {
      smseqpage(param_5 & 0xffffff00);
      return;
    }
  }
  mmuerfree((int)param_4,param_1,param_5);
  return;
}


// ==== alloctsk @ 01026ee4

void alloctsk(void)

{
  int iVar1;
  undefined4 uVar2;
  int unaff_D7;
  undefined4 *puVar3;
  undefined1 auStack_18 [2];
  undefined1 local_16;
  undefined4 local_10;
  undefined4 *local_8;
  
  mlogno = 0;
  do {
    iVar1 = mlogno;
    (&mem_log)[mlogno * 4] = 0xffffffff;
    (&DAT_01086710)[iVar1 * 4] = 0xffffffff;
    (&DAT_01086714)[iVar1 * 4] = 0xffffffff;
    (&DAT_01086718)[iVar1 * 4] = 0xffffffff;
    mlogno = mlogno + 1;
  } while (mlogno < 0x100);
  mlogno = 0;
  mem_max = 0x40000000;
  do {
    do {
      wtmsg();
      remsg(auStack_18);
    } while (unaff_D7 != 0);
    gettcb(local_16);
    getpcb(local_16);
    switch(local_10) {
    case 0:
      memalloc(0);
      break;
    case 1:
      uVar2 = 0;
      goto LAB_0102704c;
    case 2:
      memalloc(1);
      break;
    case 3:
      uVar2 = 1;
      goto LAB_0102704c;
    case 4:
      memalloc(0);
      break;
    case 5:
      uVar2 = 0;
LAB_0102704c:
      memfree(uVar2);
      break;
    default:
      uVar2 = 0xffffffff;
      goto LAB_0102705c;
    }
    uVar2 = 0;
LAB_0102705c:
    if ((uRam00000000 & 0x100) == 0) {
      s_ltopa(local_16,local_8);
      puVar3 = (undefined4 *)0x0;
    }
    else {
      puVar3 = local_8;
    }
    if (puVar3 != (undefined4 *)0xffffffff) {
      if (*(int *)(memcbctl + 4) < mem_max) {
        mem_max = *(int *)(memcbctl + 4);
      }
      *puVar3 = uVar2;
      post(local_16,0x200);
    }
  } while( true );
}


// ==== ch_adr @ 010270c8

void ch_adr(void)

{
  return;
}


// ==== dmareq @ 010270f4

undefined4 dmareq(void)

{
  byte bVar1;
  undefined4 uVar2;
  int iVar3;
  byte bVar4;
  
  bVar1 = DAT_0f00800a;
  intwait();
  iVar3 = 0;
  bVar4 = 1;
  do {
    uVar2 = 0;
    if ((bVar4 & bVar1) != 0) {
      uVar2 = (*(code *)(&PTR_mtomreq_010476c8)[iVar3])(2);
    }
    iVar3 = iVar3 + 1;
    bVar4 = bVar4 << 1;
  } while (iVar3 < 4);
  return uVar2;
}


// ==== dmadint @ 01027142

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void dmadint(undefined4 param_1)

{
  irqvct(0x40,dmareq);
  fill(&dmemwk,0x18,0);
  DAT_010476b2 = (undefined1)param_1;
  _DAT_0f008008 = 0x230;
  iodone(param_1);
  return;
}


// ==== mtomreq @ 0102718e

void mtomreq(void)

{
  dmsk_set(1);
  dmsk_set(2);
  return;
}


// ==== memmov @ 010271ae

/* WARNING: Removing unreachable block (ram,0x0102720a) */

void memmov(undefined4 param_1)

{
  undefined2 *unaff_D7;
  undefined1 auStack_20 [2];
  undefined1 local_1e;
  undefined4 local_c;
  undefined4 local_8;
  
  dremsg(param_1,auStack_20);
  if (unaff_D7 == (undefined2 *)0x0) {
    dmemwk = 2;
    latopa(local_1e,local_c);
    DAT_010476c2 = local_8;
    DAT_010476be = unaff_D7;
    movchk(&dmemwk,auStack_20);
    *DAT_010476be = 0;
  }
  if (dmemwk == 1) {
    dmemwk = 0;
    post(DAT_010476b3,DAT_010476c2);
  }
  iodone(DAT_010476b2);
  return;
}


// ==== movchk @ 0102727c

void movchk(int param_1,int param_2)

{
  int iVar1;
  int iVar2;
  int unaff_D7;
  ushort *puVar3;
  
  *(undefined1 *)(param_1 + 3) = *(undefined1 *)(param_2 + 2);
  latopa(*(undefined1 *)(param_2 + 2),*(undefined4 *)(param_2 + 8));
  *(int *)(param_1 + 8) = unaff_D7;
  *(undefined2 *)(param_1 + 0xc) = *(undefined2 *)(param_2 + 0x12);
  getpar(*(undefined1 *)(param_2 + 2));
  iVar1 = unaff_D7 * 0x80;
  puVar3 = &syspcb + unaff_D7 * 0x40;
  ch_adr(puVar3,*(undefined4 *)(param_2 + 8));
  if ((iVar1 == 0) ||
     (ch_adr(puVar3,*(int *)(param_2 + 8) + (uint)*(ushort *)(param_2 + 0x12)), iVar1 == 0)) {
    if (((&DAT_01058000)[(uint)*(byte *)(param_2 + 2) * 0x4e] & 0x20) == 0) {
      return;
    }
    iVar2 = 0;
    puVar3 = &syspcb;
    do {
      if ((*puVar3 & 2) != 0) break;
      iVar2 = iVar2 + 1;
      puVar3 = puVar3 + 0x40;
    } while (iVar2 < 0x40);
    if ((*puVar3 & 2) == 0) {
      return;
    }
    _ltoph(puVar3,*(undefined4 *)(param_2 + 8));
    *(int *)(param_1 + 8) = iVar1;
    ch_adr(puVar3,*(undefined4 *)(param_2 + 8));
    if (iVar1 == 0) {
      return;
    }
    ch_adr(puVar3,*(int *)(param_2 + 8) + (uint)*(ushort *)(param_2 + 0x12));
    if (iVar1 == 0) {
      return;
    }
  }
  setpadr(puVar3,param_2,param_1);
  return;
}


// ==== setpadr @ 010273a2

void setpadr(undefined4 param_1,int param_2,int param_3)

{
  undefined2 *puVar1;
  int unaff_D7;
  
  puVar1 = &syspcb + *(short *)(param_2 + 0xc) * 0x40;
  _ltoph(puVar1,*(undefined4 *)(param_2 + 0xe));
  *(int *)(param_3 + 4) = unaff_D7;
  ch_adr(puVar1,*(undefined4 *)(param_2 + 0xe));
  if (unaff_D7 != 0) {
    ch_adr(puVar1,*(int *)(param_2 + 0xe) + (uint)*(ushort *)(param_2 + 0x12));
  }
  return;
}


// ==== hdcreq @ 01027410

void hdcreq(void)

{
  dmsk_set(4);
  hdkdma();
  return;
}


// ==== dmyreq @ 01027428

void dmyreq(void)

{
  return;
}


// ==== mmuic_ini @ 01027430

void mmuic_ini(undefined4 *param_1)

{
  short sVar1;
  
  sVar1 = 0x100;
  do {
    *param_1 = 0xffffff40;
    sVar1 = sVar1 + -1;
    param_1 = param_1 + 1;
  } while (sVar1 != 0);
  return;
}


// ==== mmuiab_in @ 0102744a

void mmuiab_in(undefined4 *param_1)

{
  short sVar1;
  
  sVar1 = 0x80;
  do {
    *param_1 = 0xfffffff4;
    sVar1 = sVar1 + -1;
    param_1 = param_1 + 1;
  } while (sVar1 != 0);
  return;
}


// ==== mmuab_lin @ 01027462

void mmuab_lin(uint *param_1,uint param_2,short param_3)

{
  uint uVar1;
  
  if (param_3 == 0) {
    uVar1 = 2;
  }
  else {
    uVar1 = 6;
  }
  *param_1 = param_2 & 0xfffffff0 | uVar1;
  return;
}


// ==== mmubc_lin @ 01027484

void mmubc_lin(uint *param_1,uint param_2)

{
  *param_1 = param_2 & 0xfffffff0 | 2;
  return;
}


// ==== mmuc_set @ 0102749c

void mmuc_set(uint *param_1,uint param_2,undefined4 param_3,short param_4)

{
  uint uVar1;
  
  uVar1 = param_2 & 0xffffff00 | 1;
  if (param_4 != 0) {
    uVar1 = param_2 & 0xffffff00 | 0x41;
  }
  *param_1 = uVar1;
  return;
}


// ==== mmuc_szse @ 010274c2

void mmuc_szse(int param_1,int param_2,uint param_3,short param_4,short param_5)

{
  int iVar1;
  
  iVar1 = (uint)((param_3 & 0x3ff) != 0) + (param_3 >> 10);
  if (iVar1 != 0) {
    do {
      mmuc_set(param_1,param_2,(int)param_4,(int)param_5);
      param_1 = param_1 + 4;
      iVar1 = iVar1 + -1;
      param_2 = param_2 + 0x400;
    } while (iVar1 != 0);
  }
  return;
}


// ==== mmudscpag @ 01027526

void mmudscpag(int param_1)

{
  int unaff_D7;
  
  if (*(short *)(param_1 + 4) < 8) {
    s4pageget();
    *(int *)(param_1 + 8) = unaff_D7;
    if (unaff_D7 != 0) {
      *(undefined4 *)(param_1 + 0xc + *(short *)(param_1 + 4) * 4) = *(undefined4 *)(param_1 + 8);
      *(short *)(param_1 + 4) = *(short *)(param_1 + 4) + 1;
      *(undefined2 *)(param_1 + 6) = 0x1000;
    }
  }
  return;
}


// ==== mmuia_pcb @ 0102756a

void mmuia_pcb(int param_1)

{
  int unaff_D7;
  
  *(undefined2 *)(param_1 + 4) = 0;
  *(undefined2 *)(param_1 + 6) = 0;
  *(undefined4 *)(param_1 + 8) = 0;
  fill(param_1 + 0xc,0x20,0);
  mmudscpag(param_1);
  if (unaff_D7 != 0) {
    mmuiab_in(*(undefined4 *)(param_1 + 8));
    *(short *)(param_1 + 6) = *(short *)(param_1 + 6) + -0x200;
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 0x200;
  }
  return;
}


// ==== mmuib_pcb @ 010275d2

void mmuib_pcb(int param_1,undefined4 param_2,short param_3)

{
  int unaff_D7;
  
  if ((0x1ff < *(short *)(param_1 + 6)) || (mmudscpag(param_1), unaff_D7 != 0)) {
    mmuiab_in(*(undefined4 *)(param_1 + 8));
    mmuab_lin(param_2,*(undefined4 *)(param_1 + 8),(int)param_3);
    *(short *)(param_1 + 6) = *(short *)(param_1 + 6) + -0x200;
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 0x200;
  }
  return;
}


// ==== mmuic_pcb @ 01027640

void mmuic_pcb(int param_1,undefined4 param_2,short param_3)

{
  int unaff_D7;
  
  if ((0x3ff < *(short *)(param_1 + 6)) || (mmudscpag(param_1), unaff_D7 != 0)) {
    mmuic_ini(*(undefined4 *)(param_1 + 8));
    mmubc_lin(param_2,*(undefined4 *)(param_1 + 8),(int)param_3);
    *(short *)(param_1 + 6) = *(short *)(param_1 + 6) + -0x400;
    *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 0x400;
  }
  return;
}


// ==== mmu_frecs @ 010276ae

void mmu_frecs(uint *param_1)

{
  uint uVar1;
  short sVar2;
  uint *puVar3;
  
  puVar3 = (uint *)(*param_1 & 0xfffffff0);
  sVar2 = 0x100;
  do {
    if (*puVar3 != 0xffffff40) {
      uVar1 = *puVar3 & 0xffffff00;
      if ((*puVar3 & 0xf000000) == 0) {
        smpagefre(uVar1);
      }
      else {
        pagefree(uVar1);
      }
    }
    sVar2 = sVar2 + -1;
    puVar3 = puVar3 + 1;
  } while (sVar2 != 0);
  return;
}


// ==== mmu_frebs @ 01027708

void mmu_frebs(uint *param_1)

{
  int *piVar1;
  short sVar2;
  
  piVar1 = (int *)(*param_1 & 0xfffffff0);
  sVar2 = 0x80;
  do {
    if (*piVar1 != -0xc) {
      mmu_frecs(piVar1);
    }
    sVar2 = sVar2 + -1;
    piVar1 = piVar1 + 1;
  } while (sVar2 != 0);
  return;
}


// ==== mmu_frese @ 01027746

void mmu_frese(undefined4 param_1,int *param_2)

{
  short sVar1;
  
  if (param_2 != (int *)0x0) {
    sVar1 = 0x80;
    do {
      if (*param_2 != -0xc) {
        mmu_frebs(param_2);
      }
      sVar1 = sVar1 + -1;
      param_2 = param_2 + 1;
    } while (sVar1 != 0);
  }
  return;
}


// ==== mmu_segcs @ 0102777e

void mmu_segcs(short param_1,undefined4 param_2,uint *param_3,undefined4 param_4,undefined4 param_5,
              uint param_6,short param_7)

{
  int unaff_D7;
  
  mmuic_pcb(param_2,param_3,(int)param_1);
  if (unaff_D7 != 0) {
    mmuc_szse((*param_3 & 0xfffffff0) + ((param_6 & 0x3fc00) >> 10) * 4,param_5,param_4,(int)param_1
              ,(int)param_7);
  }
  return;
}


// ==== mmu_segbs @ 010277ea

void mmu_segbs(short param_1,undefined4 param_2,uint *param_3,uint param_4,int param_5,uint param_6,
              short param_7)

{
  uint uVar1;
  int unaff_D7;
  int iVar2;
  
  mmuib_pcb(param_2,param_3,(int)param_1);
  if (unaff_D7 != 0) {
    iVar2 = (*param_3 & 0xfffffff0) + ((param_6 & 0x1fc0000) >> 0x12) * 4;
    for (; param_4 != 0; param_4 = param_4 - uVar1) {
      if ((param_6 & 0x3ffff) == 0) {
        if (param_4 < 0x40001) goto LAB_0102786c;
        uVar1 = 0x40000;
      }
      else {
        uVar1 = 0x40000 - (param_6 & 0x3ffff);
        if (uVar1 < param_4) {
        }
        else {
LAB_0102786c:
          uVar1 = param_4;
        }
      }
      mmu_segcs((int)param_1,param_2,iVar2,uVar1,param_5,param_6,(int)param_7);
      if (unaff_D7 == 0) {
        return;
      }
      param_5 = uVar1 + param_5;
      param_6 = uVar1 + param_6;
      iVar2 = iVar2 + 4;
    }
  }
  return;
}


// ==== mmu_segse @ 010278b0

/* WARNING: Removing unreachable block (ram,0x010278e2) */
/* WARNING: Removing unreachable block (ram,0x010278f6) */

void mmu_segse(short param_1,undefined4 param_2,int param_3,uint param_4,int param_5)

{
  uint uVar1;
  uint uVar2;
  int unaff_D7;
  int iVar3;
  undefined2 local_6;
  
  uVar2 = param_5 + 0x3ffU & 0xfffffc00;
  uVar1 = param_5 + 0x3ffU >> 10;
  if ((param_4 == 0xa0000000) || (param_4 == 0xb0000000)) {
    local_6 = 1;
    smpageget(uVar1);
    if (unaff_D7 == 0) {
      return;
    }
    smpagemak();
  }
  else {
    local_6 = 0;
    pageget(uVar1);
    if (unaff_D7 == 0) {
      return;
    }
    pagemake();
  }
  if ((short)unaff_D7 != 0) {
    param_3 = param_3 + (param_4 >> 0x19) * 4;
    iVar3 = unaff_D7;
    for (; uVar2 != 0; uVar2 = uVar2 - uVar1) {
      if ((param_4 & 0x1ffffff) == 0) {
        if (uVar2 < 0x2000001) goto LAB_010279d6;
        uVar1 = 0x2000000;
      }
      else {
        uVar1 = 0x2000000 - (param_4 & 0x1ffffff);
        if (uVar1 < uVar2) {
        }
        else {
LAB_010279d6:
          uVar1 = uVar2;
        }
      }
      mmu_segbs((int)param_1,param_2,param_3,uVar1,iVar3,param_4,local_6);
      if (unaff_D7 == 0) {
        return;
      }
      iVar3 = uVar1 + iVar3;
      param_4 = uVar1 + param_4;
      param_3 = param_3 + 4;
    }
  }
  return;
}


// ==== mmushdche @ 01027a1a

uint mmushdche(int param_1)

{
  uint uVar1;
  
  if (*(int *)(param_1 + 0x30) != 0) {
    uVar1 = *(uint *)(param_1 + 0x2c) & 0xf0000000;
    if (uVar1 == 0xa0000000) {
      uVar1 = (*(uint *)(param_1 + 0x2c) >> 0x19 & 7) + 8;
    }
    else {
      if (uVar1 != 0xc0000000) goto LAB_01027a74;
      uVar1 = *(uint *)(param_1 + 0x2c) >> 0x19 & 7;
    }
    (&shpcb)[uVar1 * 2] = param_1;
  }
LAB_01027a74:
  uVar1 = 0;
  if (*(int *)(param_1 + 0x38) != 0) {
    uVar1 = *(uint *)(param_1 + 0x34) & 0xf0000000;
    if (uVar1 == 0xb0000000) {
      uVar1 = (*(uint *)(param_1 + 0x34) >> 0x19 & 7) + 8;
    }
    else {
      if (uVar1 != 0xd0000000) {
        return uVar1;
      }
      uVar1 = *(uint *)(param_1 + 0x34) >> 0x19 & 7;
    }
    (&DAT_01057768)[uVar1 * 2] = param_1;
  }
  return uVar1;
}


// ==== mmu_pcbma @ 01027aca

void mmu_pcbma(ushort *param_1)

{
  int iVar1;
  int unaff_D7;
  
  mmuia_pcb(param_1);
  if (unaff_D7 != 0) {
    iVar1 = *(int *)(param_1 + 6);
    if (*(int *)(param_1 + 0x18) != 0) {
      if (((*(uint *)(param_1 + 0x16) & 0xf0000000) == 0xa0000000) ||
         ((*(uint *)(param_1 + 0x16) & 0xf0000000) == 0xc0000000)) {
        *param_1 = *param_1 | 0x1000;
      }
      mmu_segse(1,param_1,iVar1,*(undefined4 *)(param_1 + 0x16),*(undefined4 *)(param_1 + 0x18));
      if (unaff_D7 == 0) {
        return;
      }
    }
    if (*(int *)(param_1 + 0x1c) != 0) {
      if (((*(uint *)(param_1 + 0x1a) & 0xf0000000) == 0xb0000000) ||
         ((*(uint *)(param_1 + 0x1a) & 0xf0000000) == 0xd0000000)) {
        *param_1 = *param_1 | 0x1000;
      }
      mmu_segse(0,param_1,iVar1,*(undefined4 *)(param_1 + 0x1a),*(undefined4 *)(param_1 + 0x1c));
      if (unaff_D7 == 0) {
        return;
      }
    }
    if (atbl_save != (undefined4 *)0x0) {
      *(undefined4 *)(iVar1 + 0x1c0 + atbl_offs * 4) = *atbl_save;
    }
    if ((*param_1 & 0x1000) != 0) {
      mmushdche(param_1);
    }
  }
  return;
}


// ==== mmu_pcbfr @ 01027bc4

void mmu_pcbfr(int param_1)

{
  uint uVar1;
  int iVar2;
  
  mmu_frese(param_1,*(undefined4 *)(param_1 + 0xc));
  if (*(int *)(param_1 + 0x48) != 0) {
    iVar2 = *(int *)(param_1 + 0x44);
    for (uVar1 = 0; uVar1 < *(uint *)(param_1 + 0x48); uVar1 = uVar1 + 1) {
      pagefree(iVar2);
      iVar2 = iVar2 + 4;
    }
  }
  iVar2 = 0;
  do {
    if (*(int *)(param_1 + 0xc + iVar2 * 4) == 0) break;
    pagefree(*(undefined4 *)(param_1 + 0xc + iVar2 * 4));
    iVar2 = iVar2 + 1;
  } while (iVar2 < 8);
  iVar2 = 0;
  do {
    if (param_1 == (&shpcb)[iVar2 * 2]) {
      (&shpcb)[iVar2 * 2] = 0;
    }
    if (param_1 == (&DAT_01057768)[iVar2 * 2]) {
      (&DAT_01057768)[iVar2 * 2] = 0;
    }
    iVar2 = iVar2 + 1;
  } while (iVar2 < 0x10);
  return;
}


// ==== mmu_txpro @ 01027c54

undefined4 mmu_txpro(int param_1,short param_2)

{
  uint *puVar1;
  uint uVar2;
  undefined4 uVar3;
  uint *puVar4;
  
  uVar3 = 0;
  if (*(int *)(param_1 + 0x30) != 0) {
    puVar4 = (uint *)(*(int *)(param_1 + 0xc) + (*(uint *)(param_1 + 0x2c) >> 0x19) * 4);
    puVar1 = (uint *)(*(int *)(param_1 + 0xc) +
                     (*(int *)(param_1 + 0x30) + *(uint *)(param_1 + 0x2c) >> 0x19) * 4);
    if (param_2 == 0) {
      for (; puVar1 != puVar4; puVar4 = puVar4 + 1) {
        *puVar4 = *puVar4 & 0xfffffffb;
      }
      uVar2 = *puVar4 & 0xfffffffb;
    }
    else {
      for (; puVar1 != puVar4; puVar4 = puVar4 + 1) {
        *puVar4 = *puVar4 | 4;
      }
      uVar2 = *puVar4 | 4;
    }
    *puVar4 = uVar2;
    uVar3 = set_crp(0x80000002,*(uint *)(param_1 + 0xc) & 0xfffffff0);
  }
  return uVar3;
}


// ==== mmu_shdse @ 01027cda

int mmu_shdse(short param_1,short param_2)

{
  int *piVar1;
  int *piVar2;
  undefined2 *puVar3;
  int iVar4;
  int iVar5;
  int iVar6;
  
  iVar4 = param_1 * 0x80;
  iVar5 = iVar4;
  if (param_2 != 2) {
    if (param_2 < 3) {
      if (param_2 != 1) {
        return iVar4;
      }
    }
    else if (param_2 != 3) {
      return iVar4;
    }
    iVar6 = 0;
    do {
      puVar3 = (undefined2 *)(&shpcb)[iVar6 * 2];
      if (((puVar3 != (undefined2 *)0x0) && (iVar5 = *(int *)(puVar3 + 0x18), iVar5 != 0)) &&
         (puVar3 != &syspcb + param_1 * 0x40)) {
        piVar1 = (int *)(*(int *)(puVar3 + 6) + (*(uint *)(puVar3 + 0x16) >> 0x19) * 4);
        piVar2 = (int *)(*(int *)(&DAT_0105576c + iVar4) + (*(uint *)(puVar3 + 0x16) >> 0x19) * 4);
        iVar5 = *piVar2;
        if (iVar5 == -0xc) {
          iVar5 = *piVar1;
          while (iVar5 != -0xc) {
            *piVar2 = *piVar1;
            iVar5 = piVar1[1];
            piVar1 = piVar1 + 1;
            piVar2 = piVar2 + 1;
          }
        }
      }
      iVar6 = iVar6 + 1;
    } while (iVar6 < 0x10);
    if (param_2 == 1) {
      return iVar5;
    }
  }
  iVar6 = 0;
  do {
    puVar3 = (undefined2 *)(&DAT_01057768)[iVar6 * 2];
    if (((puVar3 != (undefined2 *)0x0) && (iVar5 = *(int *)(puVar3 + 0x1c), iVar5 != 0)) &&
       (puVar3 != &syspcb + param_1 * 0x40)) {
      piVar1 = (int *)(*(int *)(puVar3 + 6) + (*(uint *)(puVar3 + 0x1a) >> 0x19) * 4);
      piVar2 = (int *)(*(int *)(&DAT_0105576c + iVar4) + (*(uint *)(puVar3 + 0x1a) >> 0x19) * 4);
      iVar5 = *piVar2;
      if (iVar5 == -0xc) {
        iVar5 = *piVar1;
        while (iVar5 != -0xc) {
          *piVar2 = *piVar1;
          iVar5 = piVar1[1];
          piVar1 = piVar1 + 1;
          piVar2 = piVar2 + 1;
        }
      }
    }
    iVar6 = iVar6 + 1;
  } while (iVar6 < 0x10);
  return iVar5;
}


// ==== setallocm @ 01027de6

uint setallocm(undefined4 *param_1,ushort param_2,ushort *param_3)

{
  uint uVar1;
  short sVar2;
  ushort *puVar3;
  
  uVar1 = (uint)param_2;
  puVar3 = &DAT_010557e0;
  if (atbl_save == (undefined4 *)0x0) {
    atbl_save = param_1;
    atbl_offs = param_2;
  }
  sVar2 = 0x3f;
  do {
    if (puVar3 != param_3) {
      uVar1 = (uint)*puVar3;
      if (((*puVar3 != 0) && (uVar1 = (uint)puVar3[1], puVar3[1] != 0)) &&
         (uVar1 = *(uint *)(puVar3 + 6), uVar1 != 0)) {
        *(undefined4 *)(uVar1 + 0x1c0 + (short)param_2 * 4) = *param_1;
      }
    }
    sVar2 = sVar2 + -1;
    puVar3 = puVar3 + 0x40;
  } while (sVar2 != 0);
  return uVar1;
}


// ==== mmu_shdrr @ 01027e44

void mmu_shdrr(void)

{
  return;
}


// ==== mmuwalk @ 01027e4c

void mmuwalk(void)

{
  return;
}


// ==== mvshort @ 01027ee0

void mvshort(ushort param_1,ushort *param_2)

{
  *param_2 = param_1 >> 8 | param_1 << 8;
  return;
}


// ==== cpyword @ 01027f0a

void cpyword(int param_1,int param_2,ushort param_3)

{
  ushort uVar1;
  
  uVar1 = 0;
  if (param_3 != 0) {
    do {
      mvshort(*(undefined2 *)(param_1 + (uint)uVar1 * 2),param_2 + (uint)uVar1 * 2);
      uVar1 = uVar1 + 1;
    } while (uVar1 < param_3);
  }
  return;
}


// ==== namset @ 01027f4c

void namset(char *param_1,int param_2)

{
  bool bVar1;
  byte bVar2;
  byte bVar3;
  byte bVar4;
  byte bVar5;
  byte unaff_D7b;
  byte local_7;
  
  strlen(param_1);
  if (unaff_D7b < 0xb) {
    local_7 = 0;
    bVar5 = 0;
    bVar1 = false;
    bVar3 = 0;
    if (unaff_D7b != 0) {
      do {
        if ((param_1[bVar3] == '.') &&
           (((bVar5 = bVar5 + 1, local_7 = bVar3, bVar3 == 0 || (6 < bVar3)) || (1 < bVar5)))) {
          bVar1 = true;
        }
        bVar3 = bVar3 + 1;
      } while (bVar3 < unaff_D7b);
    }
    if (((!bVar1) && ((bVar5 != 0 || (unaff_D7b < 7)))) &&
       ((bVar5 != 1 || ((int)((unaff_D7b - 1) - (uint)local_7) < 4)))) {
      fill(param_2,9,0x20);
      *(undefined1 *)(param_2 + 9) = 0;
      if (bVar5 == 0) {
        bVar3 = unaff_D7b;
      }
      else {
        bVar3 = local_7;
      }
      bVar4 = 0;
      bVar2 = 0;
      if (bVar3 != 0) {
        do {
          *(char *)(param_2 + (uint)bVar2) = param_1[bVar4];
          bVar4 = bVar4 + 1;
          bVar2 = bVar2 + 1;
        } while (bVar4 < bVar3);
      }
      if (bVar5 == 1) {
        bVar5 = 6;
        while (local_7 = local_7 + 1, local_7 < unaff_D7b) {
          *(char *)(param_2 + (uint)bVar5) = param_1[local_7];
          bVar5 = bVar5 + 1;
        }
      }
    }
  }
  return;
}


// ==== namset8 @ 0102805c

void namset8(char *param_1,int param_2)

{
  bool bVar1;
  byte bVar2;
  byte bVar3;
  byte bVar4;
  byte bVar5;
  byte unaff_D7b;
  byte local_7;
  
  strlen(param_1);
  if (unaff_D7b < 0xd) {
    local_7 = 0;
    bVar5 = 0;
    bVar1 = false;
    bVar3 = 0;
    if (unaff_D7b != 0) {
      do {
        if ((param_1[bVar3] == '.') &&
           (((bVar5 = bVar5 + 1, local_7 = bVar3, bVar3 == 0 || (8 < bVar3)) || (1 < bVar5)))) {
          bVar1 = true;
        }
        bVar3 = bVar3 + 1;
      } while (bVar3 < unaff_D7b);
    }
    if (((!bVar1) && ((bVar5 != 0 || (unaff_D7b < 10)))) &&
       ((bVar5 != 1 || ((int)((unaff_D7b - 1) - (uint)local_7) < 4)))) {
      fill(param_2,0xb,0x20);
      *(undefined1 *)(param_2 + 0xb) = 0;
      if (bVar5 == 0) {
        bVar3 = unaff_D7b;
      }
      else {
        bVar3 = local_7;
      }
      bVar4 = 0;
      bVar2 = 0;
      if (bVar3 != 0) {
        do {
          *(char *)(param_2 + (uint)bVar2) = param_1[bVar4];
          bVar4 = bVar4 + 1;
          bVar2 = bVar2 + 1;
        } while (bVar4 < bVar3);
      }
      if (bVar5 == 1) {
        bVar5 = 8;
        while (local_7 = local_7 + 1, local_7 < unaff_D7b) {
          *(char *)(param_2 + (uint)bVar5) = param_1[local_7];
          bVar5 = bVar5 + 1;
        }
      }
    }
  }
  return;
}


// ==== netrqrwai @ 0102816c

void netrqrwai(uint *param_1,int param_2)

{
  uint uVar1;
  uint unaff_D7;
  undefined4 local_8;
  
  local_8 = 0;
  *(undefined4 **)(param_2 + 4) = &local_8;
  *param_1 = *param_1 & 0xb7ffffff;
  dsemsg(0x1c,0x88,param_2);
  do {
    wait((void *)0x0);
    uVar1 = *param_1 | unaff_D7;
    *param_1 = uVar1;
    unaff_D7 = 0;
  } while ((uVar1 & 0x48000000) == 0);
  *param_1 = *param_1 & 0xb7ffffff;
  return;
}


// ==== netrqtwai @ 010281d4

void netrqtwai(uint *param_1,int param_2)

{
  uint uVar1;
  uint unaff_D7;
  undefined4 local_8;
  
  local_8 = 0;
  *(undefined4 **)(param_2 + 4) = &local_8;
  *param_1 = *param_1 & 0xb7ffffff;
  dsemsg(0x1c,0x87,param_2);
  do {
    wait((void *)0x0);
    uVar1 = *param_1 | unaff_D7;
    *param_1 = uVar1;
    unaff_D7 = 0;
  } while ((uVar1 & 0x48000000) == 0);
  *param_1 = *param_1 & 0xb7ffffff;
  return;
}


// ==== netdrvope @ 0102823c

void netdrvope(uint *param_1)

{
  uint unaff_D7;
  undefined4 local_24;
  undefined4 local_20;
  undefined4 *local_1c;
  
  local_20 = 0x40;
  local_24 = 0;
  local_1c = &local_24;
  *param_1 = *param_1 & 0xb7ffffff;
  dsemsg(0x1c,0x88,&local_20);
  do {
    wait((void *)0x0);
    unaff_D7 = *param_1 | unaff_D7;
    *param_1 = unaff_D7;
  } while ((unaff_D7 & 0x8000000) == 0);
  *param_1 = *param_1 & 0xf7ffffff;
  return;
}


// ==== netclose @ 010282a6

void netclose(undefined4 param_1)

{
  undefined4 local_20 [7];
  
  local_20[0] = 0x41;
  netrqrwai(param_1,local_20);
  return;
}


// ==== netsens @ 010282c2

void netsens(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  undefined4 local_20 [2];
  undefined4 local_18;
  undefined4 local_14;
  
  local_20[0] = 0x20;
  local_18 = param_1;
  local_14 = param_2;
  netrqtwai(param_3,local_20);
  return;
}


// ==== netsend @ 010282ea

void netsend(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6)

{
  undefined4 local_20 [2];
  undefined4 local_18;
  undefined4 local_14;
  undefined4 local_10;
  undefined4 local_c;
  undefined4 local_8;
  
  local_20[0] = 0x10;
  local_18 = param_1;
  local_10 = param_3;
  local_14 = param_2;
  local_8 = param_5;
  local_c = param_4;
  netrqtwai(param_6,local_20);
  return;
}


// ==== netreqsen @ 01028324

void netreqsen(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
              undefined4 param_5)

{
  *(undefined4 *)(param_1 + 0x24) = param_2;
  *(undefined4 *)(param_1 + 0x28) = param_3;
  *(undefined4 *)(param_1 + 0x30) = param_4;
  *(undefined4 *)(param_1 + 0x34) = param_5;
  if (DAT_01049d5a == '\0') {
    cpybuf(param_1 + 0x66,&netexcml,0x20);
    waitfio = param_1;
    netsndaft(param_1);
  }
  else {
    net_putfi(param_1);
  }
  return;
}


// ==== netwaitfi @ 01028382

void netwaitfi(void)

{
  undefined4 *puVar1;
  
  puVar1 = netfioqto;
  while ((DAT_01049d5a == '\0' && (puVar1 != (undefined4 *)0x0))) {
    netfioqto = (undefined4 *)*puVar1;
    *puVar1 = 0;
    cpybuf((int)puVar1 + 0x66,&netexcml,0x20);
    waitfio = puVar1;
    netsndaft(puVar1);
    puVar1 = netfioqto;
  }
  netfioqto = puVar1;
  return;
}


// ==== hostcmpbu @ 010283d8

char hostcmpbu(char *param_1,char *param_2)

{
  char cVar1;
  
  for (; ((*param_1 != '\0' && (*param_2 != '\0')) && (*param_2 == *param_1)); param_2 = param_2 + 1
      ) {
    param_1 = param_1 + 1;
  }
  cVar1 = *param_1;
  if (cVar1 == '\0') {
    cVar1 = *param_2;
  }
  return cVar1;
}


// ==== str_sz @ 0102840c

int str_sz(char *param_1)

{
  int iVar1;
  
  iVar1 = 0;
  for (; *param_1 != '\0'; param_1 = param_1 + 1) {
    iVar1 = iVar1 + 1;
  }
  return iVar1;
}


// ==== bytservop @ 01028426

void bytservop(uint *param_1)

{
  uint unaff_D7;
  
  malloc(0x400);
  if (unaff_D7 != 0) {
    *param_1 = *param_1 | 2;
    fill();
    *(undefined4 *)(unaff_D7 + 4) = 0x3f4;
    *(uint *)(unaff_D7 + 8) = unaff_D7 + 0xc;
    param_1[1] = unaff_D7;
  }
  return;
}


// ==== bytservad @ 0102847a

void * bytservad(uint *param_1)

{
  void *pvVar1;
  uint unaff_D7;
  uint *puVar2;
  
  pvVar1 = malloc(0x400);
  if (unaff_D7 != 0) {
    *param_1 = *param_1 | 2;
    fill();
    *(undefined4 *)(unaff_D7 + 4) = 0x3f4;
    *(uint *)(unaff_D7 + 8) = unaff_D7 + 0xc;
    if (param_1[1] == 0) {
      param_1[1] = unaff_D7;
      pvVar1 = (void *)0x0;
    }
    else {
      for (puVar2 = (uint *)param_1[1]; *puVar2 != 0; puVar2 = (uint *)*puVar2) {
      }
      *puVar2 = unaff_D7;
      pvVar1 = (void *)0x0;
    }
  }
  return pvVar1;
}


// ==== bytfree @ 010284e4

undefined1 bytfree(char *param_1)

{
  for (; *param_1 != '\0'; param_1 = param_1 + 1) {
    *param_1 = '\0';
  }
  return 0;
}


// ==== bytset @ 010284f8

void bytset(int param_1,int param_2,undefined1 *param_3)

{
  uint uVar1;
  undefined1 *puVar2;
  
  puVar2 = *(undefined1 **)(param_1 + 8);
  uVar1 = param_2 + 4U & 0xfffffffc;
  if (param_3 != (undefined1 *)0x0) {
    for (; param_2 != 0; param_2 = param_2 + -1) {
      *puVar2 = *param_3;
      puVar2 = puVar2 + 1;
      param_3 = param_3 + 1;
    }
  }
  *puVar2 = 0;
  *(uint *)(param_1 + 8) = uVar1 + *(int *)(param_1 + 8);
  *(uint *)(param_1 + 4) = *(int *)(param_1 + 4) - uVar1;
  return;
}


// ==== fiobytser @ 01028542

uint fiobytser(int param_1,int param_2,undefined1 *param_3)

{
  uint uVar1;
  uint uVar2;
  uint uVar3;
  undefined4 unaff_D7;
  uint *puVar4;
  uint *puVar5;
  int iVar6;
  int *piVar7;
  int local_20 [2];
  
  piVar7 = local_20 + 3;
  if (*(int *)(param_1 + 0x18) == 0) {
    local_20[1] = 0x1028566;
    malloc(0x400);
    *(undefined4 *)(param_1 + 0x18) = unaff_D7;
    if (*(int *)(param_1 + 0x18) == 0) {
      return 0;
    }
    iVar6 = *(int *)(param_1 + 0x18);
    local_20[1] = 4;
    local_20[0] = iVar6;
    fill();
    piVar7 = local_20;
    *(undefined4 *)(iVar6 + 4) = 0x3f4;
    *(int *)(iVar6 + 8) = iVar6 + 0xc;
  }
  else {
    iVar6 = *(int *)(param_1 + 0x18);
    if (*(int *)(iVar6 + 4) <= param_2 + 4) {
      uVar3 = param_2 + 3U >> 2;
      puVar5 = (uint *)(iVar6 + 8);
      uVar1 = *(uint *)(iVar6 + 4);
      uVar2 = uVar1 >> 2;
      do {
        if (uVar2 == 0) {
          return uVar1;
        }
        uVar1 = *puVar5;
        puVar4 = puVar5;
        if (uVar1 == 0) {
          for (; ((*puVar4 == 0 && (uVar2 != 0)) && (uVar3 != 0)); uVar3 = uVar3 - 1) {
            uVar2 = uVar2 - 1;
            puVar4 = puVar4 + 1;
          }
          if (uVar3 == 0) {
            uVar1 = param_2 + 3U & 0xfffffffc;
            *(uint *)(iVar6 + 8) = uVar1 + *(int *)(iVar6 + 8);
            *(uint *)(iVar6 + 4) = *(int *)(iVar6 + 4) - uVar1;
            if (param_3 != (undefined1 *)0x0) {
              for (; param_2 != 0; param_2 = param_2 + -1) {
                *(undefined1 *)puVar5 = *param_3;
                puVar5 = (uint *)((int)puVar5 + 1);
                param_3 = param_3 + 1;
              }
            }
            *(undefined1 *)puVar5 = 0;
            return uVar1;
          }
          uVar1 = param_2 + 3;
          uVar3 = uVar1 >> 2;
        }
        uVar2 = uVar2 - 1;
        puVar5 = puVar4 + 1;
      } while( true );
    }
  }
  piVar7[-1] = (int)param_3;
  piVar7[-2] = param_2;
  piVar7[-3] = iVar6;
  piVar7[-4] = 0x10285b4;
  uVar1 = bytset();
  return uVar1;
}


// ==== netfioget @ 01028634

void * netfioget(void)

{
  int *piVar1;
  void *pvVar2;
  uint uVar3;
  int unaff_D7;
  int iVar4;
  
  if (netfio == 0) {
    pvVar2 = malloc(0xc00);
    if (unaff_D7 == 0) {
      return pvVar2;
    }
    fill();
    netfio = unaff_D7;
  }
  uVar3 = 0;
  iVar4 = netfio;
  do {
    piVar1 = (int *)(iVar4 + 4);
    if ((void *)*piVar1 == (void *)0x0) {
      fill(iVar4,0x86,0);
      *(uint *)(iVar4 + 0xc) = uVar3 + 1;
      *(undefined4 *)(iVar4 + 4) = 1;
      *(undefined4 *)(iVar4 + 0x42) = 0;
      fiobytser(iVar4,0x30,0);
      *(int *)(iVar4 + 0x20) = unaff_D7;
      pvVar2 = (void *)fiobytser(iVar4,0x80,0);
      *(int *)(iVar4 + 0x1c) = unaff_D7;
      return pvVar2;
    }
    uVar3 = uVar3 + 1;
    iVar4 = iVar4 + 0x86;
  } while (uVar3 < 0x16);
  return (void *)*piVar1;
}


// ==== netfiofre @ 010286da

undefined4 netfiofre(int param_1)

{
  undefined4 uVar1;
  
  if (*(int *)(param_1 + 4) == 0) {
    uVar1 = 0;
  }
  else {
    *(undefined4 *)(param_1 + 0x38) = 0;
    uVar1 = 0;
    if (*(int *)(param_1 + 0x18) != 0) {
      uVar1 = mfree(*(undefined4 *)(param_1 + 0x18));
    }
    *(undefined4 *)(param_1 + 0x42) = 0;
    *(undefined4 *)(param_1 + 4) = 0;
  }
  return uVar1;
}


// ==== net_fiosc @ 01028714

void * net_fiosc(int param_1)

{
  void *pvVar1;
  int unaff_D7;
  int iVar2;
  
  if (netfio == 0) {
    pvVar1 = malloc(0xc00);
    if (unaff_D7 != 0) {
      pvVar1 = (void *)fill();
      netfio = unaff_D7;
    }
  }
  else {
    iVar2 = netfio + param_1 * 0x86 + -0x86;
    pvVar1 = (void *)0x0;
    if (*(int *)(iVar2 + 4) != 0) {
      pvVar1 = *(void **)(iVar2 + 0xc);
    }
  }
  return pvVar1;
}


// ==== net_skfio @ 01028780

void net_skfio(int param_1)

{
  uint uVar1;
  int iVar2;
  
  if (((waitfio == 0) || (param_1 != *(int *)(waitfio + 0x10))) && (netfio != 0)) {
    uVar1 = 0;
    iVar2 = netfio;
    do {
      if (((*(int *)(iVar2 + 4) != 0) && ((*(uint *)(iVar2 + 4) & 8) == 0)) &&
         (param_1 == *(int *)(iVar2 + 0x10))) {
        return;
      }
      uVar1 = uVar1 + 1;
      iVar2 = iVar2 + 0x86;
    } while (uVar1 < 0x16);
  }
  return;
}


// ==== hostfiosc @ 010287dc

void hostfiosc(int param_1)

{
  uint uVar1;
  int iVar2;
  
  if (netfio != 0) {
    uVar1 = 0;
    iVar2 = netfio;
    do {
      if (((*(int *)(iVar2 + 4) != 0) && ((*(uint *)(iVar2 + 4) & 8) != 0)) &&
         (param_1 == *(int *)(iVar2 + 0x10))) {
        return;
      }
      uVar1 = uVar1 + 1;
      iVar2 = iVar2 + 0x86;
    } while (uVar1 < 0x16);
  }
  return;
}


// ==== net_answa @ 01028822

void net_answa(uint param_1)

{
  uint uVar1;
  int iVar2;
  
  if (netfio != 0) {
    uVar1 = 0;
    iVar2 = netfio;
    do {
      if ((*(int *)(iVar2 + 4) != 0) && ((param_1 & *(uint *)(iVar2 + 4)) != 0)) {
        return;
      }
      uVar1 = uVar1 + 1;
      iVar2 = iVar2 + 0x86;
    } while (uVar1 < 0x16);
  }
  return;
}


// ==== net_htfio @ 0102885e

void net_htfio(char *param_1,short param_2)

{
  int unaff_D7;
  char *pcVar1;
  int iVar2;
  uint uVar3;
  char acStack_26 [34];
  
  iVar2 = 0;
  pcVar1 = param_1;
  do {
    if (*pcVar1 == ':') break;
    acStack_26[iVar2] = *pcVar1;
    iVar2 = iVar2 + 1;
    pcVar1 = pcVar1 + 1;
  } while (iVar2 < 0x20);
  acStack_26[iVar2 + 1] = '\0';
  if (netfio == 0) {
    malloc(0xc00);
    if (unaff_D7 != 0) {
      fill();
      netfio = unaff_D7;
    }
  }
  else {
    uVar3 = 0;
    iVar2 = netfio;
    do {
      if ((((*(uint *)(iVar2 + 4) & 8) != 0) &&
          (hostcmpbu(*(undefined4 *)(iVar2 + 0x38),param_1), unaff_D7 == 1)) &&
         (*(int *)(iVar2 + 0x4e) == (int)param_2)) {
        return;
      }
      uVar3 = uVar3 + 1;
      iVar2 = iVar2 + 0x86;
    } while (uVar3 < 0x16);
  }
  return;
}


// ==== net_othht @ 01028906

void net_othht(char *param_1,short param_2)

{
  int unaff_D7;
  char *pcVar1;
  int iVar2;
  uint uVar3;
  char acStack_26 [34];
  
  iVar2 = 0;
  pcVar1 = param_1;
  do {
    if (*pcVar1 == ':') break;
    acStack_26[iVar2] = *pcVar1;
    iVar2 = iVar2 + 1;
    pcVar1 = pcVar1 + 1;
  } while (iVar2 < 0x20);
  acStack_26[iVar2 + 1] = '\0';
  if (netfio != 0) {
    uVar3 = 0;
    iVar2 = netfio;
    do {
      if ((((*(uint *)(iVar2 + 4) & 8) != 0) &&
          (hostcmpbu(*(undefined4 *)(iVar2 + 0x38),param_1), unaff_D7 == 1)) &&
         (*(int *)(iVar2 + 0x4e) != (int)param_2)) {
        return;
      }
      uVar3 = uVar3 + 1;
      iVar2 = iVar2 + 0x86;
    } while (uVar3 < 0x16);
  }
  return;
}


// ==== fiomvhost @ 01028986

void fiomvhost(undefined4 param_1,int param_2)

{
  int unaff_D7;
  
  net_htfio(param_1,*(undefined1 *)(param_2 + 0x68));
  if (unaff_D7 != 0) {
    *(undefined4 *)(param_2 + 0x10) = *(undefined4 *)(unaff_D7 + 0x10);
    *(undefined4 *)(param_2 + 0x38) = *(undefined4 *)(unaff_D7 + 0x38);
    cpybuf(unaff_D7 + 0x56,param_2 + 0x56,0x10);
    *(int *)(unaff_D7 + 0x52) = *(int *)(unaff_D7 + 0x52) + 1;
  }
  return;
}


// ==== net_putfi @ 010289e0

void net_putfi(int *param_1)

{
  int *piVar1;
  
  *param_1 = 0;
  if (netfioqto == (int *)0x0) {
    netfioqto = param_1;
  }
  else {
    for (piVar1 = netfioqto; *piVar1 != 0; piVar1 = (int *)*piVar1) {
    }
    *piVar1 = (int)param_1;
  }
  return;
}


// ==== net_bufge @ 01028a0e

void net_bufge(void)

{
  bytservop(&netctl);
  return;
}


// ==== netdtsk @ 01028a24

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void netdtsk(void)

{
  uint unaff_D7;
  
  _pcode = 0;
  fill(&netctl,0x10,0);
  net_bufge();
  netdrvope(&pcode);
  _netctl = 1;
  netfioqto = 0;
  do {
    wtmsg();
    _pcode = unaff_D7 | _pcode;
    remsg(&netdwlml);
    if (unaff_D7 == 0) {
      if (DAT_01049712 == -0x78) {
        switch(DAT_01049718) {
        case 1:
          netdwlmai(&netdwlml);
          break;
        case 2:
          if ((_netctl & 0x10) == 0) {
            netrespma(&netdwlml);
          }
          else {
            nettestre(&netdwlml);
          }
          break;
        case 4:
          if ((DAT_0104971c == 2) || (DAT_0104971c == 1)) {
            net_utime(&netdwlml);
          }
        }
      }
      else if (DAT_01049712 != -0x79) {
        latopa(DAT_01049712,DAT_0104971c);
        DAT_0104971c = unaff_D7;
        switch(DAT_01049718) {
        case 1:
          net_mount(&netdwlml,&DAT_01049718);
          break;
        case 2:
          net_dismo(&netdwlml,&DAT_01049718);
          break;
        case 3:
          net_open(&netdwlml,&DAT_01049718);
          break;
        case 4:
          net_read(&netdwlml,&DAT_01049718);
          break;
        case 5:
          net_write(&netdwlml,&DAT_01049718);
          break;
        case 6:
          net_close(&netdwlml,&DAT_01049718);
          break;
        case 7:
          net_seek(&netdwlml,&DAT_01049718);
          break;
        case 8:
          net_utreq(&netdwlml,&DAT_01049718);
          break;
        case 9:
          _netctl = 0x10;
          latopa(DAT_01049712,DAT_01049724);
          DAT_01049724 = unaff_D7;
          latopa(DAT_01049712,DAT_0104972c);
          DAT_0104972c = unaff_D7;
          net_stest(&netdwlml,&DAT_01049718);
          break;
        case 10:
          _netctl = 0x10;
          latopa(DAT_01049712,DAT_0104972c);
          DAT_0104972c = unaff_D7;
          net_rtest(&netdwlml,&DAT_01049718);
        }
      }
    }
    netwaitfi();
    _pcode = 0;
  } while( true );
}


// ==== netmantas @ 01028c8c

void netmantas(void)

{
  int unaff_D7;
  
  nmdlogc = 0;
  do {
    while( true ) {
      do {
        wtmsg();
        remsg(&rmb);
      } while (unaff_D7 != 0);
      if (DAT_0104a3e6 != -0x78) break;
      cpybuf(&rmb,&dtmbox,0x648);
      nmrxmcmd(&DAT_01049da4,&atmbox);
    }
    cpybuf(&rmb,&atmbox,0x1c);
    nmrxmatr(DAT_01049d82,&DAT_01049d88);
  } while( true );
}


// ==== nmrxmcmd @ 01028d26

void nmrxmcmd(int param_1,int param_2)

{
  undefined4 *puVar1;
  int iVar2;
  
  puVar1 = (undefined4 *)(param_1 + 4);
  iVar2 = (int)(short)nmdlogc;
  cpybuf(param_2 + 8,&nmdlogb + iVar2 * 0x14,0x14);
  *(undefined4 *)(&DAT_0104aa30 + iVar2 * 0x14) = *(undefined4 *)(param_1 + 0x20);
  nmdlogc = nmdlogc + 1 & 0x1f;
  switch(*puVar1) {
  case 0x20:
    nmrr_sope(param_2,puVar1,param_1 + 0x40);
    break;
  case 0x21:
    nmrr_sclo(param_2,puVar1,param_1 + 0x40);
    break;
  case 0x24:
    nmrr_fope(param_2,puVar1,param_1 + 0x40);
    break;
  case 0x25:
    nmrr_fclo(param_2,puVar1,param_1 + 0x40);
    break;
  case 0x26:
    nmrr_frea(param_2,puVar1,param_1 + 0x40);
    break;
  case 0x27:
    nmrr_fwri(param_2,puVar1,param_1 + 0x40);
    break;
  case 0x28:
    nmrr_fcop(param_2,puVar1,param_1 + 0x40);
    break;
  case 0x29:
    nmrr_getd(param_2,puVar1,param_1 + 0x40);
    break;
  case 0x2a:
    nmrr_rm(param_2,puVar1,param_1 + 0x40);
    break;
  case 0x2b:
    nmrr_ren(param_2,puVar1,param_1 + 0x40);
    break;
  case 0x2c:
    nmrr_mkdi(param_2,puVar1,param_1 + 0x40);
    break;
  case 0x2d:
    nmrr_rmdi(param_2,puVar1,param_1 + 0x40);
    break;
  case 0x2e:
    nmrr_cd(param_2,puVar1,param_1 + 0x40);
    break;
  case 0x2f:
    nmrr_pwd(param_2,puVar1,param_1 + 0x40);
    break;
  case 0x30:
    nmrr_fnid(param_2,puVar1,param_1 + 0x40);
    break;
  case 0x31:
    nmrr_cope(param_2,puVar1,param_1 + 0x40);
    break;
  case 0x32:
    nmrr_cclo(param_2,puVar1,param_1 + 0x40);
    break;
  case 0x33:
    nmrr_crea(param_2,puVar1,param_1 + 0x40);
  }
  return;
}


// ==== nmrxmatr @ 01028ef4

void nmrxmatr(undefined4 param_1,undefined4 *param_2)

{
  undefined4 unaff_D7;
  int iVar1;
  
  latopa(param_1,param_2[1]);
  param_2[1] = unaff_D7;
  iVar1 = (int)(short)nmdlogc;
  cpybuf(param_2,&nmdlogb + iVar1 * 0x14,0x14);
  *(undefined4 *)(&DAT_0104aa30 + iVar1 * 0x14) = *(undefined4 *)param_2[1];
  nmdlogc = nmdlogc + 1 & 0x1f;
  switch(*param_2) {
  case 0x20:
    nmrc_cope(param_1,param_2 + 2);
    break;
  case 0x21:
    nmrc_cclo(param_1,param_2 + 2);
    break;
  case 0x22:
    nmrc_crea(param_1,param_2 + 2);
    break;
  case 0x23:
    nmrc_sope(param_1,param_2 + 2);
    break;
  case 0x24:
    nmrc_sclo(param_1,param_2 + 2);
    break;
  case 0x25:
    nmrc_fope(param_1,param_2 + 2);
    break;
  case 0x26:
    nmrc_fclo(param_1,param_2 + 2);
    break;
  case 0x27:
    nmrc_frea(param_1,param_2 + 2);
    break;
  case 0x28:
    nmrc_fwri(param_1,param_2 + 2);
    break;
  case 0x29:
    nmrc_getd(param_1,param_2 + 2);
    break;
  case 0x2a:
    nmrc_rm(param_1,param_2 + 2);
    break;
  case 0x2b:
    nmrc_ren(param_1,param_2 + 2);
    break;
  case 0x2c:
    nmrc_mkdi(param_1,param_2 + 2);
    break;
  case 0x2d:
    nmrc_rmdi(param_1,param_2 + 2);
    break;
  case 0x2e:
    nmrc_cd(param_1,param_2 + 2);
    break;
  case 0x2f:
    nmrc_pwd(param_1,param_2 + 2);
    break;
  case 0x30:
    nmrc_fnid(param_1,param_2 + 2);
    break;
  case 0x31:
    nmrc_fcop(param_1,param_2 + 2);
  }
  return;
}


// ==== nmrc_cope @ 010290a2

void nmrc_cope(undefined4 param_1,undefined4 *param_2)

{
  latopa(param_1,*param_2);
  nmtxmdrv(0x31,0);
  return;
}


// ==== nmrc_cclo @ 010290d8

void nmrc_cclo(undefined4 param_1,undefined4 *param_2)

{
  nmtxmdrv(0x32,*param_2,0,0,0,0,0);
  return;
}


// ==== nmrc_crea @ 010290fa

void nmrc_crea(undefined4 param_1,undefined4 *param_2)

{
  undefined4 unaff_D7;
  
  latopa(param_1,param_2[2]);
  param_2[2] = unaff_D7;
  nmtxmdrv(0x33,*param_2,0,0,param_2[1],0,0);
  return;
}


// ==== nmrc_sope @ 01029136

void nmrc_sope(undefined4 param_1,int param_2)

{
  latopa(param_1,*(undefined4 *)(param_2 + 4),0,0,0,0);
  nmtxmdrv(0x20,0);
  return;
}


// ==== nmrc_sclo @ 01029168

void nmrc_sclo(undefined4 param_1,undefined4 *param_2)

{
  nmtxmdrv(0x21,*param_2,0,0,0,0,0);
  return;
}


// ==== nmrc_fope @ 0102918a

void nmrc_fope(undefined4 param_1,undefined4 *param_2)

{
  char *unaff_D7;
  
  latopa(param_1,param_2[1]);
  strlen(unaff_D7);
  strlen(unaff_D7);
  nmtxmdrv(0x24,*param_2,0,(int)*(char *)(param_2 + 2));
  return;
}


// ==== nmrc_fclo @ 010291dc

void nmrc_fclo(undefined4 param_1,undefined4 *param_2)

{
  nmtxmdrv(0x25,*param_2,0,0,0,0,0);
  return;
}


// ==== nmrc_frea @ 010291fe

void nmrc_frea(undefined4 param_1,undefined4 *param_2)

{
  undefined4 unaff_D7;
  
  latopa(param_1,param_2[2]);
  param_2[2] = unaff_D7;
  nmtxmdrv(0x26,*param_2,0,0,param_2[1],0,0);
  return;
}


// ==== nmrc_fwri @ 0102923a

void nmrc_fwri(undefined4 param_1,undefined4 *param_2)

{
  latopa(param_1,param_2[2],param_2[1]);
  nmtxmdrv(0x27,*param_2,0,0,param_2[1]);
  return;
}


// ==== nmrc_getd @ 01029276

void nmrc_getd(undefined4 param_1,undefined4 *param_2)

{
  undefined4 unaff_D7;
  
  latopa(param_1,param_2[2]);
  param_2[2] = unaff_D7;
  nmtxmdrv(0x29,*param_2,0,param_2[1],0,0,0);
  return;
}


// ==== nmrc_rm @ 010292b2

void nmrc_rm(undefined4 param_1,undefined4 *param_2)

{
  char *unaff_D7;
  
  latopa(param_1,param_2[1]);
  strlen(unaff_D7);
  strlen(unaff_D7);
  nmtxmdrv(0x2a,*param_2,0,0);
  return;
}


// ==== nmrc_ren @ 010292fe

void nmrc_ren(undefined4 param_1,undefined4 *param_2)

{
  char *unaff_D7;
  undefined1 auStack_8a [134];
  
  fill(auStack_8a,0x86,0);
  latopa(param_1,param_2[1]);
  remove_bl();
  strlen(unaff_D7);
  cpybuf();
  latopa(param_1,param_2[2]);
  remove_bl();
  strlen(unaff_D7);
  cpybuf();
  nmtxmdrv(0x2b,*param_2,0,0,unaff_D7 + 1,auStack_8a,unaff_D7 + 1 + (int)(unaff_D7 + 1));
  return;
}


// ==== nmrc_mkdi @ 010293aa

void nmrc_mkdi(undefined4 param_1,undefined4 *param_2)

{
  char *unaff_D7;
  
  latopa(param_1,param_2[1]);
  strlen(unaff_D7);
  strlen(unaff_D7);
  nmtxmdrv(0x2c,*param_2,0,0);
  return;
}


// ==== nmrc_rmdi @ 010293f6

void nmrc_rmdi(undefined4 param_1,undefined4 *param_2)

{
  char *unaff_D7;
  
  latopa(param_1,param_2[1]);
  remove_bl();
  strlen(unaff_D7);
  strlen(unaff_D7);
  nmtxmdrv(0x2d,*param_2,0,0);
  return;
}


// ==== nmrc_cd @ 0102944a

void nmrc_cd(undefined4 param_1,undefined4 *param_2)

{
  char *unaff_D7;
  
  latopa(param_1,param_2[1]);
  strlen(unaff_D7);
  strlen(unaff_D7);
  nmtxmdrv(0x2e,*param_2,0,0);
  return;
}


// ==== nmrc_pwd @ 01029496

void nmrc_pwd(undefined4 param_1,undefined4 *param_2)

{
  undefined4 unaff_D7;
  
  latopa(param_1,param_2[1]);
  param_2[1] = unaff_D7;
  nmtxmdrv(0x2f,*param_2,0,0,0,0,0);
  return;
}


// ==== nmrc_fnid @ 010294d0

void nmrc_fnid(undefined4 param_1,undefined4 *param_2)

{
  latopa(param_1,param_2[1],0,0,0,0);
  nmtxmdrv(0x30,*param_2);
  return;
}


// ==== nmrc_fcop @ 01029508

void nmrc_fcop(undefined4 param_1,undefined4 *param_2)

{
  char *unaff_D7;
  undefined1 auStack_8a [134];
  
  fill(auStack_8a,0x86,0);
  latopa(param_1,param_2[1]);
  strlen(unaff_D7);
  cpybuf();
  latopa(param_1,param_2[2]);
  strlen(unaff_D7);
  cpybuf();
  nmtxmdrv(0x28,*param_2,0,0,unaff_D7 + 1,auStack_8a,unaff_D7 + 1 + (int)(unaff_D7 + 1));
  return;
}


// ==== nmrr_cope @ 010295a4

void nmrr_cope(int param_1,int param_2)

{
  **(undefined4 **)(param_1 + 0xc) = *(undefined4 *)(param_2 + 0x1c);
  post(*(undefined1 *)(param_1 + 2),0x400);
  return;
}


// ==== nmrr_cclo @ 010295d4

void nmrr_cclo(int param_1,int param_2)

{
  **(undefined4 **)(param_1 + 0xc) = *(undefined4 *)(param_2 + 0x1c);
  post(*(undefined1 *)(param_1 + 2),0x400);
  return;
}


// ==== nmrr_crea @ 01029604

void nmrr_crea(int param_1,int param_2,undefined4 param_3)

{
  **(undefined4 **)(param_1 + 0xc) = *(undefined4 *)(param_2 + 0x1c);
  if (0 < *(int *)(param_2 + 0x1c)) {
    cpybuf(param_3,*(undefined4 *)(param_1 + 0x18),*(undefined4 *)(param_2 + 0x1c));
  }
  post(*(undefined1 *)(param_1 + 2),0x400);
  return;
}


// ==== nmrr_sope @ 0102965a

void nmrr_sope(int param_1,int param_2)

{
  **(undefined4 **)(param_1 + 0xc) = *(undefined4 *)(param_2 + 0x1c);
  post(*(undefined1 *)(param_1 + 2),0x400);
  return;
}


// ==== nmrr_sclo @ 0102968a

void nmrr_sclo(int param_1,int param_2)

{
  **(undefined4 **)(param_1 + 0xc) = *(undefined4 *)(param_2 + 0x1c);
  post(*(undefined1 *)(param_1 + 2),0x400);
  return;
}


// ==== nmrr_fope @ 010296ba

void nmrr_fope(int param_1,int param_2)

{
  **(undefined4 **)(param_1 + 0xc) = *(undefined4 *)(param_2 + 0x1c);
  post(*(undefined1 *)(param_1 + 2),0x400);
  return;
}


// ==== nmrr_fclo @ 010296ea

void nmrr_fclo(int param_1,int param_2)

{
  **(undefined4 **)(param_1 + 0xc) = *(undefined4 *)(param_2 + 0x1c);
  post(*(undefined1 *)(param_1 + 2),0x400);
  return;
}


// ==== nmrr_frea @ 0102971a

void nmrr_frea(int param_1,int param_2,undefined4 param_3)

{
  **(undefined4 **)(param_1 + 0xc) = *(undefined4 *)(param_2 + 0x1c);
  if (0 < *(int *)(param_2 + 0x1c)) {
    cpybuf(param_3,*(undefined4 *)(param_1 + 0x18),*(undefined4 *)(param_2 + 0x1c));
  }
  post(*(undefined1 *)(param_1 + 2),0x400);
  return;
}


// ==== nmrr_fwri @ 01029770

void nmrr_fwri(int param_1,int param_2)

{
  **(undefined4 **)(param_1 + 0xc) = *(undefined4 *)(param_2 + 0x1c);
  post(*(undefined1 *)(param_1 + 2),0x400);
  return;
}


// ==== nmrr_getd @ 010297a0

void nmrr_getd(int param_1,int param_2,int param_3)

{
  int iVar1;
  int iVar2;
  byte local_14 [16];
  
  **(undefined4 **)(param_1 + 0xc) = *(undefined4 *)(param_2 + 0x1c);
  if (0 < *(int *)(param_2 + 0x1c)) {
    redwat(local_14);
    if (local_14[0] < 0x50) {
      iVar1 = 0x14;
    }
    else {
      iVar1 = -0x50;
    }
    iVar2 = 0;
    if (0 < *(int *)(param_2 + 0x1c)) {
      do {
        if ((*(uint *)(param_3 + 0xc) & 0xfe000000) == 0) {
          *(uint *)(param_3 + 0xc) =
               (iVar1 + (uint)local_14[0]) * 0x2000000 | *(uint *)(param_3 + 0xc);
        }
        cpybuf(param_3,*(undefined4 *)(param_1 + 0x18),0x20);
        param_3 = param_3 + 0x20;
        *(int *)(param_1 + 0x18) = *(int *)(param_1 + 0x18) + 0x20;
        iVar2 = iVar2 + 1;
      } while (iVar2 < *(int *)(param_2 + 0x1c));
    }
  }
  post(*(undefined1 *)(param_1 + 2),0x400);
  return;
}


// ==== nmrr_rm @ 01029870

void nmrr_rm(int param_1,int param_2)

{
  **(undefined4 **)(param_1 + 0xc) = *(undefined4 *)(param_2 + 0x1c);
  post(*(undefined1 *)(param_1 + 2),0x400);
  return;
}


// ==== nmrr_ren @ 010298a0

void nmrr_ren(int param_1,int param_2)

{
  **(undefined4 **)(param_1 + 0xc) = *(undefined4 *)(param_2 + 0x1c);
  post(*(undefined1 *)(param_1 + 2),0x400);
  return;
}


// ==== nmrr_mkdi @ 010298d0

void nmrr_mkdi(int param_1,int param_2)

{
  **(undefined4 **)(param_1 + 0xc) = *(undefined4 *)(param_2 + 0x1c);
  post(*(undefined1 *)(param_1 + 2),0x400);
  return;
}


// ==== nmrr_rmdi @ 01029900

void nmrr_rmdi(int param_1,int param_2)

{
  **(undefined4 **)(param_1 + 0xc) = *(undefined4 *)(param_2 + 0x1c);
  post(*(undefined1 *)(param_1 + 2),0x400);
  return;
}


// ==== nmrr_cd @ 01029930

void nmrr_cd(int param_1,int param_2)

{
  **(undefined4 **)(param_1 + 0xc) = *(undefined4 *)(param_2 + 0x1c);
  post(*(undefined1 *)(param_1 + 2),0x400);
  return;
}


// ==== nmrr_pwd @ 01029960

void nmrr_pwd(int param_1,int param_2,undefined4 param_3)

{
  **(undefined4 **)(param_1 + 0xc) = *(undefined4 *)(param_2 + 0x1c);
  if (0 < *(int *)(param_2 + 0x1c)) {
    cpybuf(param_3,*(undefined4 *)(param_1 + 0x14),*(undefined4 *)(param_2 + 0x1c));
  }
  post(*(undefined1 *)(param_1 + 2),0x400);
  return;
}


// ==== nmrr_fnid @ 010299b6

void nmrr_fnid(int param_1,int param_2)

{
  **(undefined4 **)(param_1 + 0xc) = *(undefined4 *)(param_2 + 0x1c);
  post(*(undefined1 *)(param_1 + 2),0x400);
  return;
}


// ==== nmrr_fcop @ 010299e6

void nmrr_fcop(int param_1,int param_2)

{
  **(undefined4 **)(param_1 + 0xc) = *(undefined4 *)(param_2 + 0x1c);
  post(*(undefined1 *)(param_1 + 2),0x400);
  return;
}


// ==== nmtxmdrv @ 01029a16

void nmtxmdrv(undefined4 param_1,undefined4 param_2,char *param_3,undefined4 param_4,
             undefined4 param_5,undefined4 param_6,undefined4 param_7)

{
  uint uVar1;
  uint unaff_D7;
  undefined4 uVar2;
  undefined4 local_54;
  undefined4 local_50;
  undefined4 *local_4c;
  undefined4 *local_48;
  undefined4 local_44;
  undefined4 local_40;
  undefined4 local_3c;
  undefined4 local_38;
  undefined4 local_34;
  undefined4 local_30;
  undefined4 local_2c;
  undefined1 auStack_28 [12];
  undefined4 local_1c;
  undefined4 local_18;
  undefined4 local_14;
  
  fill(&local_34,0x30,0);
  local_34 = 1;
  local_14 = 0;
  local_30 = param_1;
  local_2c = param_2;
  if (param_3 != (char *)0x0) {
    strlen(param_3);
    if ((int)unaff_D7 < 0xb) {
      uVar2 = 0;
    }
    else {
      uVar2 = 0xb;
    }
    cpybuf(param_3,auStack_28,uVar2);
  }
  local_1c = param_4;
  local_18 = param_5;
  local_50 = 0x10;
  local_54 = 0;
  local_4c = &local_54;
  local_40 = param_6;
  local_44 = param_7;
  local_38 = 0;
  local_3c = 0;
  local_48 = &local_34;
  dsemsg(0x1c,0x87,&local_50);
  do {
    wait((void *)0x0);
    uVar1 = unaff_D7 & 0x48000000;
    unaff_D7 = 0;
  } while (uVar1 == 0);
  return;
}


// ==== remove_bl @ 01029ae4

undefined1 remove_bl(char *param_1)

{
  char cVar1;
  char *pcVar2;
  
  while (*param_1 != '\0') {
    if (*param_1 == ' ') {
      cVar1 = *param_1;
      pcVar2 = param_1;
      while (cVar1 != '\0') {
        *pcVar2 = pcVar2[1];
        pcVar2 = pcVar2 + 1;
        cVar1 = *pcVar2;
      }
    }
    else {
      param_1 = param_1 + 1;
    }
  }
  return 0;
}


// ==== nd_dcbsch @ 01029b14

void * nd_dcbsch(int param_1)

{
  void *pvVar1;
  int unaff_D7;
  int *piVar2;
  
  if (dwldcb == 0) {
    pvVar1 = malloc(0x400);
    if (unaff_D7 != 0) {
      pvVar1 = (void *)fill();
      dwldcb = unaff_D7;
    }
  }
  else {
    piVar2 = (int *)(dwldcb + param_1 * 0x2a + -0x2a);
    pvVar1 = (void *)0x0;
    if (*piVar2 != 0) {
      pvVar1 = (void *)piVar2[1];
    }
  }
  return pvVar1;
}


// ==== nd_dcbget @ 01029b78

void * nd_dcbget(void)

{
  void *pvVar1;
  uint uVar2;
  int *unaff_D7;
  int *piVar3;
  
  if (dwldcb == (int *)0x0) {
    pvVar1 = malloc(0x400);
    if (unaff_D7 == (int *)0x0) {
      return pvVar1;
    }
    fill();
    dwldcb = unaff_D7;
  }
  uVar2 = 0;
  piVar3 = dwldcb;
  do {
    pvVar1 = (void *)*piVar3;
    if (pvVar1 == (void *)0x0) {
      fill(piVar3,0x2a,0);
      piVar3[1] = uVar2 + 1;
      *piVar3 = 1;
      malloc(0xc00);
      piVar3[4] = (int)unaff_D7;
      if ((void *)piVar3[4] == (void *)0x0) {
        *piVar3 = 0;
        return (void *)0x0;
      }
      return (void *)piVar3[4];
    }
    uVar2 = uVar2 + 1;
    piVar3 = (int *)((int)piVar3 + 0x2a);
  } while (uVar2 < 0x18);
  return pvVar1;
}


// ==== nd_ngresp @ 01029c0c

void nd_ngresp(int param_1,int param_2)

{
  *(undefined4 *)(param_2 + 0x1c) = 0xffffffff;
  netsend(param_1 + 8,0,0,0,0,&pcode);
  return;
}


// ==== dl_mount @ 01029c3a

void dl_mount(int param_1,int param_2)

{
  undefined4 uVar1;
  int unaff_D7;
  
  if (*(int *)(param_2 + 4) == 0) {
    asgetdrv();
    *(int *)(param_2 + 4) = unaff_D7;
  }
  uVar1 = *(undefined4 *)(param_2 + 4);
  fs_mount(uVar1,&pcode);
  if (unaff_D7 < 0) {
    *(undefined4 *)(param_2 + 0x1c) = 0xffffffff;
  }
  else {
    *(undefined4 *)(param_2 + 0x1c) = 1;
    mnt_drvno = uVar1;
  }
  netsend(param_1 + 8,0,0,0,0,&pcode);
  return;
}


// ==== dl_dismou @ 01029cb0

void dl_dismou(int param_1,int param_2)

{
  int unaff_D7;
  
  if (*(int *)(param_2 + 4) == 0) {
    asgetdrv();
    *(int *)(param_2 + 4) = unaff_D7;
  }
  if (*(int *)(param_2 + 4) != 6) {
    fs_demnt(*(int *)(param_2 + 4),&pcode);
    if (unaff_D7 < 0) {
      *(undefined4 *)(param_2 + 0x1c) = 0xffffffff;
      goto LAB_01029d08;
    }
  }
  *(undefined4 *)(param_2 + 0x1c) = 1;
  mnt_drvno = 0xffffffff;
LAB_01029d08:
  netsend(param_1 + 8,0,0,0,0,&pcode);
  return;
}


// ==== dl_open @ 01029d2e

void dl_open(int param_1,int param_2)

{
  char cVar1;
  int iVar2;
  uint *unaff_D7;
  
  nd_dcbget();
  if ((unaff_D7 == (uint *)0x0) || (mnt_drvno == 0xffffffff)) {
    nd_ngresp(param_1,param_2);
  }
  else {
    unaff_D7[3] = mnt_drvno;
    fill(unaff_D7 + 7,0xb,0x20);
    iVar2 = 0;
    do {
      if (*(char *)(param_2 + 8 + iVar2) == '.') break;
      if ((*(byte *)(param_2 + 8 + iVar2) < 0x61) || (0x7a < *(byte *)(param_2 + 8 + iVar2))) {
        cVar1 = *(char *)(param_2 + 8 + iVar2);
      }
      else {
        cVar1 = *(char *)(param_2 + 8 + iVar2) + -0x20;
      }
      *(char *)((int)unaff_D7 + iVar2 + 0x1c) = cVar1;
      iVar2 = iVar2 + 1;
    } while (iVar2 < 8);
    if (*(char *)(param_2 + 8 + iVar2) == '.') {
      iVar2 = iVar2 + 1;
    }
    if (*(char *)(param_2 + 8 + iVar2) != '\0') {
      if ((*(byte *)(param_2 + 8 + iVar2) < 0x61) || (0x7a < *(byte *)(param_2 + 8 + iVar2))) {
        cVar1 = *(char *)(param_2 + 8 + iVar2);
      }
      else {
        cVar1 = *(char *)(param_2 + 8 + iVar2) + -0x20;
      }
      *(char *)(unaff_D7 + 9) = cVar1;
    }
    if (*(char *)(param_2 + 9 + iVar2) != '\0') {
      if ((*(byte *)(param_2 + 9 + iVar2) < 0x61) || (0x7a < *(byte *)(param_2 + 9 + iVar2))) {
        cVar1 = *(char *)(param_2 + 9 + iVar2);
      }
      else {
        cVar1 = *(char *)(param_2 + 9 + iVar2) + -0x20;
      }
      *(char *)((int)unaff_D7 + 0x25) = cVar1;
    }
    if (*(char *)(param_2 + 10 + iVar2) != '\0') {
      if ((*(byte *)(param_2 + 10 + iVar2) < 0x61) || (0x7a < *(byte *)(param_2 + 10 + iVar2))) {
        cVar1 = *(char *)(param_2 + 10 + iVar2);
      }
      else {
        cVar1 = *(char *)(param_2 + 10 + iVar2) + -0x20;
      }
      *(char *)((int)unaff_D7 + 0x26) = cVar1;
    }
    if (*(int *)(param_2 + 0x14) == 2) {
      *unaff_D7 = *unaff_D7 | 0x2000;
      *(undefined1 *)(unaff_D7 + 10) = 1;
    }
    else {
      *unaff_D7 = *unaff_D7 | 0x1000;
      *(undefined1 *)(unaff_D7 + 10) = 0;
    }
    fs_open(unaff_D7[3],unaff_D7 + 7,*(undefined1 *)(unaff_D7 + 10),&pcode);
    if ((int)unaff_D7 < 0) {
      *(undefined4 *)(param_2 + 0x1c) = 0xffffffff;
      *unaff_D7 = 0;
    }
    else {
      unaff_D7[2] = (uint)unaff_D7;
      *(uint *)(param_2 + 0x1c) = unaff_D7[1];
      *(uint *)(param_2 + 4) = unaff_D7[1];
      *unaff_D7 = *unaff_D7 | 0x100;
    }
    netsend(param_1 + 8,0,0,0,0,&pcode);
  }
  return;
}


// ==== dl_close @ 01029ee6

void dl_close(int param_1,int param_2)

{
  uint *unaff_D7;
  
  nd_dcbsch(*(undefined4 *)(param_2 + 4));
  if ((unaff_D7 == (uint *)0x0) || ((*unaff_D7 & 0x100) == 0)) {
    nd_ngresp(param_1,param_2);
  }
  else {
    fs_clos(unaff_D7[3],unaff_D7[2],&pcode);
    mfree(unaff_D7[4]);
    *unaff_D7 = 0;
    *(undefined4 *)(param_2 + 0x1c) = 1;
    netsend(param_1 + 8,0,0,0,0,&pcode);
  }
  return;
}


// ==== dl_blkrea @ 01029f68

uint dl_blkrea(uint *param_1,undefined4 param_2)

{
  uint uVar1;
  uint unaff_D7;
  
  uVar1 = *param_1 & 0x81000000;
  if (uVar1 == 0) {
    fs_read(param_1[3],param_1[2],param_2,param_1[4],&pcode);
    if ((int)unaff_D7 < 0) {
      uVar1 = *param_1 | 0x1000000;
      *param_1 = uVar1;
    }
    else {
      uVar1 = dosstt();
      param_1[5] = param_1[4];
      param_1[6] = unaff_D7;
    }
  }
  return uVar1;
}


// ==== dl_min @ 01029fda

void dl_min(void)

{
  return;
}


// ==== dl_read @ 0102a004

void dl_read(int param_1,int param_2)

{
  undefined4 uVar1;
  uint *unaff_D7;
  
  nd_dcbsch(*(undefined4 *)(param_2 + 4));
  if (((unaff_D7 != (uint *)0x0) && (*(char *)(unaff_D7 + 10) != '\x01')) &&
     ((*unaff_D7 & 0x100) != 0)) {
    uVar1 = *(undefined4 *)(param_2 + 0x18);
    dl_blkrea();
    if (0 < (int)unaff_D7) {
      dl_min(uVar1);
      *(uint **)(param_2 + 0x1c) = unaff_D7;
      netsend(param_1 + 8);
      unaff_D7[5] = (int)unaff_D7 + unaff_D7[5];
      unaff_D7[6] = unaff_D7[6] - (int)unaff_D7;
      return;
    }
  }
  nd_ngresp(param_1,param_2);
  return;
}


// ==== dl_write @ 0102a0a4

void dl_write(int param_1,int param_2)

{
  uint *unaff_D7;
  
  nd_dcbsch(*(undefined4 *)(param_2 + 4));
  if ((((unaff_D7 != (uint *)0x0) && (*(char *)(unaff_D7 + 10) != '\0')) &&
      ((*unaff_D7 & 0x100) != 0)) && ((*unaff_D7 & 0x1000000) == 0)) {
    fs_write(unaff_D7[3],unaff_D7[2],*(undefined4 *)(param_2 + 0x18),param_1 + 0x48,&pcode);
    if (-1 < (int)unaff_D7) {
      dosstt();
      *(uint **)(param_2 + 0x1c) = unaff_D7;
      netsend(param_1 + 8,0,0,0,0,&pcode);
      return;
    }
    *unaff_D7 = *unaff_D7 | 0x1000000;
  }
  nd_ngresp(param_1,param_2);
  return;
}


// ==== dl_seek @ 0102a152

/* WARNING: Restarted to delay deadcode elimination for space: stack */

void dl_seek(int param_1,int param_2)

{
  undefined4 uVar1;
  uint *unaff_D7;
  
  nd_dcbsch(*(undefined4 *)(param_2 + 4));
  if ((((unaff_D7 != (uint *)0x0) && (*(char *)(unaff_D7 + 10) != '\x01')) &&
      ((*unaff_D7 & 0x100) != 0)) && ((*unaff_D7 & 0x1000000) == 0)) {
    if (*(int *)(param_2 + 0x14) == 10) {
      uVar1 = 0;
    }
    else if (*(int *)(param_2 + 0x14) == 0xb) {
      uVar1 = 1;
    }
    else {
      if (*(int *)(param_2 + 0x14) != 0xc) goto LAB_0102a1f0;
      uVar1 = 2;
    }
    fs_seek(unaff_D7[3],unaff_D7[2],uVar1,*(undefined4 *)(param_2 + 0x18),&pcode);
    if (-1 < (int)unaff_D7) {
      *(undefined4 *)(param_2 + 0x1c) = *(undefined4 *)(param_2 + 0x18);
      unaff_D7[6] = 0;
      netsend(param_1 + 8,0,0,0,0,&pcode);
      return;
    }
    *unaff_D7 = *unaff_D7 | 0x1000000;
  }
LAB_0102a1f0:
  nd_ngresp(param_1,param_2);
  return;
}


// ==== dl_getdir @ 0102a228

void dl_getdir(int param_1,int param_2)

{
  int in_D1;
  int iVar1;
  int unaff_D7;
  
  if (*(int *)(param_2 + 0x14) == 0x14) {
    in_D1 = 1;
    mnt_dirno = 1;
  }
  else if (*(int *)(param_2 + 0x14) == 0x15) {
    in_D1 = mnt_dirno;
  }
  iVar1 = *(int *)(param_2 + 0x18) + in_D1;
  if (0x600 < *(int *)(param_2 + 0x18) * 0x20) {
    iVar1 = in_D1 + 0xc000;
  }
  fs_dire(mnt_drvno,in_D1,iVar1,param_1 + 0x48,&pcode);
  if (unaff_D7 < 0) {
    nd_ngresp(param_1,param_2);
  }
  else {
    dosstt();
    *(int *)(param_2 + 0x1c) = unaff_D7;
    mnt_dirno = unaff_D7 + mnt_dirno;
    netsend(param_1 + 8,unaff_D7 << 5,param_1 + 0x48,0,0,&pcode);
  }
  return;
}


// ==== dl_chdir @ 0102a2ea

void dl_chdir(int param_1,int param_2)

{
  int unaff_D7;
  
  fs_chdir(mnt_drvno,param_1 + 0x48,&pcode);
  if (unaff_D7 < 0) {
    nd_ngresp(param_1,param_2);
  }
  else {
    *(undefined4 *)(param_2 + 0x1c) = 1;
    netsend(param_1 + 8,0,0,0,0,&pcode);
  }
  return;
}


// ==== netdwlmai @ 0102a356

void netdwlmai(int param_1)

{
  undefined4 *puVar1;
  
  puVar1 = (undefined4 *)(param_1 + 0xc);
  switch(*puVar1) {
  case 0:
    dl_mount(param_1,puVar1);
    break;
  case 1:
    dl_dismou(param_1,puVar1);
    break;
  case 2:
    dl_open(param_1,puVar1);
    break;
  case 3:
    dl_read(param_1,puVar1);
    break;
  case 4:
    dl_write(param_1,puVar1);
    break;
  case 5:
    dl_seek(param_1,puVar1);
    break;
  case 6:
    dl_close(param_1,puVar1);
    break;
  case 7:
    dl_getdir(param_1,puVar1);
    break;
  case 8:
    dl_chdir(param_1,puVar1);
  }
  return;
}


// ==== makemlhea @ 0102a4ea

void makemlhea(undefined4 param_1,int param_2)

{
  undefined4 *puVar1;
  
  puVar1 = *(undefined4 **)(param_2 + 0x20);
  fill(puVar1,0x30,0);
  *puVar1 = 2;
  puVar1[1] = param_1;
  switch(param_1) {
  case 0x22:
    puVar1[5] = 2;
    puVar1[6] = 1;
    puVar1[7] = 0;
    break;
  case 0x26:
    puVar1[5] = *(undefined4 *)(param_2 + 0x10);
    cpybuf(param_2 + 0x56,puVar1 + 6,0x10);
    puVar1[10] = 0x10;
    break;
  case 0x27:
  case 0x29:
    puVar1[5] = *(undefined4 *)(param_2 + 0x10);
    break;
  case 0x2a:
    puVar1[5] = *(undefined4 *)(param_2 + 0x10);
    puVar1[6] = 0x40;
    break;
  case 0x2b:
    puVar1[5] = *(undefined4 *)(param_2 + 0x10);
    puVar1[6] = 0x40;
    puVar1[7] = 0x4b;
  }
  return;
}


// ==== makeuthea @ 0102a5a4

void makeuthea(undefined4 param_1)

{
  fill(&utmlhead,0x30,0);
  utmlhead = 4;
  DAT_0104ad3c = param_1;
  return;
}


// ==== bufsize @ 0102a5cc

int bufsize(char *param_1)

{
  int iVar1;
  
  iVar1 = 0;
  for (; *param_1 != '\0'; param_1 = param_1 + 1) {
    iVar1 = iVar1 + 1;
  }
  return iVar1;
}


// ==== net_aplpo @ 0102a5e6

undefined1 net_aplpo(int param_1,int param_2)

{
  undefined1 uVar1;
  undefined4 unaff_D7;
  
  uVar1 = 0;
  if (*(char *)(param_1 + 2) != '\0') {
    if (param_2 < 0) {
      netanserr(param_2,*(undefined1 *)(param_1 + 2));
    }
    mkdoserr(0x10,param_2);
    **(undefined4 **)(param_1 + 0xc) = unaff_D7;
    uVar1 = post(*(undefined1 *)(param_1 + 2),0x8000000);
    *(undefined1 *)(param_1 + 2) = 0;
    DAT_01049d5a = 0;
    waitfio = 0;
  }
  return uVar1;
}


// ==== netanserr @ 0102a656

void netanserr(void)

{
  return;
}


// ==== net_utime @ 0102a65e

void net_utime(int param_1)

{
  undefined4 *puVar1;
  
  puVar1 = DAT_0104ad94;
  if (DAT_0104ad8a != '\0') {
    *DAT_0104ad94 = *(undefined4 *)(param_1 + 0x18);
    puVar1[1] = *(undefined4 *)(param_1 + 0x1c);
    post(DAT_0104ad8a,0x8000000);
    DAT_0104ad8a = '\0';
  }
  return;
}


// ==== net_utreq @ 0102a69c

void net_utreq(int param_1)

{
  int unaff_D7;
  
  if (DAT_0104ad8a == '\0') {
    cpybuf(param_1,&wt_utmail,0x20);
    makeuthea(2);
    netsend(&utmlhead,0,0,0,0,&pcode);
    if (unaff_D7 == 1) {
      return;
    }
  }
  *(undefined4 *)(param_1 + 0xc) = 0;
  *(undefined4 *)(param_1 + 0x10) = 0;
  post(*(undefined1 *)(param_1 + 2),0x8000000);
  return;
}


// ==== net_stest @ 0102a716

void net_stest(undefined4 param_1,int param_2)

{
  int unaff_D7;
  undefined4 uVar1;
  
  netsend(*(undefined4 *)(param_2 + 0xc),*(undefined4 *)(param_2 + 0x10),
          *(undefined4 *)(param_2 + 0x14),0,0,&pcode);
  if (unaff_D7 == 1) {
    uVar1 = 1;
  }
  else {
    uVar1 = 0xfffffff8;
  }
  net_aplpo(param_1,uVar1);
  return;
}


// ==== net_rtest @ 0102a766

void net_rtest(int param_1,int param_2)

{
  DAT_01049708 = *(undefined4 *)(param_2 + 0x14);
  DAT_0104970c = (uint)*(byte *)(param_1 + 2);
  net_aplpo(param_1,1);
  return;
}


// ==== nettestre @ 0102a798

void nettestre(short *param_1)

{
  if (DAT_0104970c != 0) {
    semsg((int)*param_1,DAT_0104970c,param_1 + 4);
  }
  return;
}


// ==== net_mount @ 0102a7c2

void net_mount(int param_1,int param_2)

{
  int unaff_D7;
  char *pcVar1;
  int iVar2;
  undefined4 uVar3;
  undefined1 auStack_26 [34];
  
  latopa(*(undefined1 *)(param_1 + 2),*(undefined4 *)(param_2 + 8));
  *(int *)(param_2 + 8) = unaff_D7;
  pcVar1 = *(char **)(param_2 + 8);
  for (iVar2 = 0; ((*pcVar1 != ':' && (*pcVar1 != '\0')) && (iVar2 < 0x20)); iVar2 = iVar2 + 1) {
    pcVar1 = pcVar1 + 1;
  }
  cpybuf(*(undefined4 *)(param_2 + 8),auStack_26,iVar2);
  auStack_26[iVar2] = 0;
  net_htfio(auStack_26,*(undefined1 *)(param_1 + 2));
  if (unaff_D7 == 0) {
    netfioget();
    uVar3 = 0xfffffff5;
  }
  else {
    if (*(int *)(unaff_D7 + 0x10) == 0) {
      fiobytser();
      *(int *)(unaff_D7 + 0x38) = unaff_D7;
      *(uint *)(unaff_D7 + 4) = *(uint *)(unaff_D7 + 4) | 0x28;
      cpybuf(param_1,unaff_D7 + 0x66,0x20);
      makemlhea(0x22);
      *(undefined4 *)(unaff_D7 + 0x2c) = 1;
      netreqsen();
      return;
    }
    uVar3 = 1;
  }
  net_aplpo(param_1,uVar3);
  return;
}


// ==== net_dismo @ 0102a8c4

void net_dismo(int param_1,int param_2)

{
  int unaff_D7;
  char *pcVar1;
  int iVar2;
  undefined1 auStack_24 [32];
  
  latopa(*(undefined1 *)(param_1 + 2),*(undefined4 *)(param_2 + 8));
  *(int *)(param_2 + 8) = unaff_D7;
  pcVar1 = *(char **)(param_2 + 8);
  for (iVar2 = 0; ((*pcVar1 != ':' && (*pcVar1 != '\0')) && (iVar2 < 0x20)); iVar2 = iVar2 + 1) {
    pcVar1 = pcVar1 + 1;
  }
  cpybuf(*(undefined4 *)(param_2 + 8),auStack_24,iVar2);
  auStack_24[iVar2] = 0;
  net_htfio(auStack_24,*(undefined1 *)(param_1 + 2));
  if (unaff_D7 == 0) {
    net_aplpo(param_1,0xfffffffc);
  }
  else {
    *(undefined4 *)(unaff_D7 + 0x4a) = 1;
    cpybuf(param_1,unaff_D7 + 0x66,0x20);
    nsnddisc();
  }
  return;
}


// ==== net_open @ 0102a972

void net_open(undefined4 param_1,int param_2)

{
  byte bVar1;
  int unaff_D7;
  char *pcVar2;
  int iVar3;
  undefined1 *puVar4;
  undefined1 auStack_24 [32];
  
  netfioget();
  if (unaff_D7 == 0) {
    puVar4 = auStack_24 + -0x18;
  }
  else {
    latopa();
    *(int *)(param_2 + 8) = unaff_D7;
    pcVar2 = *(char **)(param_2 + 8);
    for (iVar3 = 0; (*pcVar2 != ':' && (iVar3 < 0x20)); iVar3 = iVar3 + 1) {
      pcVar2 = pcVar2 + 1;
    }
    if (*pcVar2 == ':') {
      bufsize();
      fiobytser();
      *(int *)(unaff_D7 + 0x3c) = unaff_D7;
      cpybuf(*(undefined4 *)(param_2 + 8),auStack_24,iVar3);
      auStack_24[iVar3] = 0;
      cpybuf(param_1,unaff_D7 + 0x66,0x20);
      fiomvhost();
      if (unaff_D7 == 0) {
        netfiofre();
        puVar4 = auStack_24 + -0x1c;
      }
      else {
        *(char *)(unaff_D7 + 0x40) = (char)*(undefined4 *)(param_2 + 0xc);
        bVar1 = *(byte *)(unaff_D7 + 0x40);
        if (bVar1 == 1) {
          *(uint *)(unaff_D7 + 4) = *(uint *)(unaff_D7 + 4) | 0x200;
LAB_0102aaba:
          *(uint *)(unaff_D7 + 4) = *(uint *)(unaff_D7 + 4) | 0x20;
          nsndopen();
          return;
        }
        if (bVar1 < 2) {
          if (bVar1 == 0) {
            *(uint *)(unaff_D7 + 4) = *(uint *)(unaff_D7 + 4) | 0x100;
            goto LAB_0102aaba;
          }
        }
        else if (bVar1 == 2) {
          *(uint *)(unaff_D7 + 4) = *(uint *)(unaff_D7 + 4) | 0x400;
          goto LAB_0102aaba;
        }
        netfiofre();
        puVar4 = auStack_24 + -0x1c;
      }
    }
    else {
      netfiofre();
      puVar4 = auStack_24 + -0x1c;
    }
  }
  *(undefined4 *)(puVar4 + -4) = param_1;
  *(undefined4 *)(puVar4 + -8) = 0x102aab8;
  net_aplpo();
  return;
}


// ==== net_readr @ 0102aad8

void net_readr(int param_1)

{
  undefined4 unaff_D7;
  
  makemlhea(0x27,param_1);
  sprintf(*(char **)(param_1 + 0x1c),PTR_s_READ__d__d_0104acbc,*(undefined4 *)(param_1 + 0x14),
          *(undefined4 *)(param_1 + 0x4a));
  bufsize(*(undefined4 *)(param_1 + 0x1c));
  *(undefined4 *)(*(int *)(param_1 + 0x20) + 0x18) = unaff_D7;
  *(undefined4 *)(param_1 + 0x2c) = 3;
  netreqsen(param_1);
  return;
}


// ==== netrbufse @ 0102ab38

void netrbufse(undefined4 param_1,int param_2,int param_3,int param_4,int param_5,undefined4 param_6
              ,int param_7)

{
  undefined4 uVar1;
  
  if ((param_5 == -1) && (param_4 == 3)) {
    *(uint *)(param_3 + 4) = *(uint *)(param_3 + 4) | 0x10000000;
    uVar1 = 0xfffffffb;
  }
  else {
    if (param_5 != 0) {
      *(int *)(param_3 + 0x52) = param_5;
      *(int *)(param_3 + 0x4a) = param_5;
      if (*(int *)(param_2 + 8) != param_7) {
        cpybuf(param_6,*(undefined4 *)(param_3 + 0x46),*(int *)(param_2 + 8) - param_7);
        *(int *)(param_3 + 0x46) = *(int *)(param_3 + 0x46) + (*(int *)(param_2 + 8) - param_7);
        *(int *)(param_3 + 0x4a) = *(int *)(param_3 + 0x4a) - (*(int *)(param_2 + 8) - param_7);
        if (*(int *)(param_3 + 0x52) == 0) {
          uVar1 = *(undefined4 *)(param_3 + 0x52);
          goto LAB_0102abdc;
        }
        *(int *)(param_3 + 0x4a) = *(int *)(param_3 + 0x4a) - (*(int *)(param_2 + 8) - param_7);
      }
      *(uint *)(param_3 + 4) = *(uint *)(param_3 + 4) | 0x4000;
      return;
    }
    *(uint *)(param_3 + 4) = *(uint *)(param_3 + 4) | 0x80000000;
    uVar1 = 0;
  }
LAB_0102abdc:
  net_aplpo(param_1,uVar1);
  *(undefined1 *)(param_3 + 0x68) = 0;
  return;
}


// ==== netrbufmd @ 0102ac10

void netrbufmd(int param_1,int param_2,undefined4 param_3)

{
  uint uVar1;
  
  if (param_2 != 0) {
    *(int *)(param_1 + 0x4a) = *(int *)(param_1 + 0x4a) - param_2;
    cpybuf(param_3,*(undefined4 *)(param_1 + 0x46),param_2);
    *(int *)(param_1 + 0x46) = param_2 + *(int *)(param_1 + 0x46);
    if (*(int *)(param_1 + 0x4a) == 0) {
      net_aplpo(param_1 + 0x66,*(undefined4 *)(param_1 + 0x52));
      *(undefined1 *)(param_1 + 0x68) = 0;
      uVar1 = *(uint *)(param_1 + 4) & 0xffffafff;
    }
    else {
      uVar1 = *(uint *)(param_1 + 4) | 0x4000;
    }
    *(uint *)(param_1 + 4) = uVar1;
  }
  return;
}


// ==== net_read @ 0102ac82

void net_read(int param_1,int param_2)

{
  int unaff_D7;
  undefined4 uVar1;
  
  net_fiosc(*(undefined4 *)(param_2 + 8));
  if (unaff_D7 == 0) {
    uVar1 = 0xfffffff6;
  }
  else if ((*(uint *)(unaff_D7 + 4) & 0x10000000) == 0) {
    if (((*(uint *)(unaff_D7 + 4) & 0x10) == 0) ||
       (((*(uint *)(unaff_D7 + 4) & 0x100) == 0 && ((*(uint *)(unaff_D7 + 4) & 0x400) == 0)))) {
      uVar1 = 0xfffffffe;
    }
    else {
      latopa(*(undefined1 *)(param_1 + 2),*(undefined4 *)(param_2 + 0x10));
      *(int *)(param_2 + 0x10) = unaff_D7;
      *(undefined4 *)(unaff_D7 + 0x46) = *(undefined4 *)(param_2 + 0x10);
      cpybuf(param_1,unaff_D7 + 0x66,0x20);
      *(undefined4 *)(unaff_D7 + 0x52) = 0;
      *(undefined4 *)(unaff_D7 + 0x4a) = *(undefined4 *)(param_2 + 0xc);
      if (-1 < *(int *)(unaff_D7 + 4)) {
        net_readr();
        return;
      }
      uVar1 = 0;
    }
  }
  else {
    uVar1 = 0xfffffffb;
  }
  net_aplpo(param_1,uVar1);
  return;
}


// ==== netwbufse @ 0102ad42

void netwbufse(undefined4 param_1,undefined4 param_2,int param_3,undefined4 param_4,int param_5)

{
  if (param_5 == -1) {
    *(uint *)(param_3 + 4) = *(uint *)(param_3 + 4) | 0x10000000;
    net_aplpo(param_1,0xfffffffb);
    if ((*(uint *)(param_3 + 4) & 0x40) != 0) {
      nsndclose(param_3);
    }
  }
  else {
    net_aplpo(param_1,param_5);
    *(undefined1 *)(param_3 + 0x68) = 0;
    *(uint *)(param_3 + 4) = *(uint *)(param_3 + 4) & 0xff7f5fff;
  }
  return;
}


// ==== net_write @ 0102adac

void net_write(int param_1,undefined4 param_2)

{
  int iVar1;
  uint unaff_D7;
  
  *(undefined4 *)(param_1 + 0x2c) = 4;
  makemlhea(0x27,param_1);
  sprintf(*(char **)(param_1 + 0x1c),PTR_s_WRITE__d__d_0104acc0,*(undefined4 *)(param_1 + 0x14),
          param_2);
  bufsize(*(undefined4 *)(param_1 + 0x1c));
  if ((unaff_D7 & 1) == 0) {
    *(undefined1 *)(*(int *)(param_1 + 0x1c) + -1 + unaff_D7) = 10;
  }
  else {
    *(undefined1 *)(*(int *)(param_1 + 0x1c) + unaff_D7) = 10;
    unaff_D7 = unaff_D7 + 1;
  }
  iVar1 = 0x1ea - unaff_D7;
  if (*(int *)(param_1 + 0x4a) < iVar1) {
    iVar1 = *(int *)(param_1 + 0x4a);
  }
  *(uint *)(*(int *)(param_1 + 0x20) + 0x18) = iVar1 + unaff_D7;
  netreqsen(param_1,unaff_D7,*(undefined4 *)(param_1 + 0x1c),iVar1,*(undefined4 *)(param_1 + 0x46));
  return;
}


// ==== netwbufmd @ 0102ae46

void netwbufmd(int param_1)

{
  undefined4 uVar1;
  
  if (*(int *)(param_1 + 0x4a) == 0) {
    *(uint *)(param_1 + 4) = *(uint *)(param_1 + 4) & 0xffff7fff;
  }
  else {
    makemlhea(0x27,param_1);
    if (*(int *)(param_1 + 0x4a) < 0x1ea) {
      uVar1 = *(undefined4 *)(param_1 + 0x4a);
    }
    else {
      uVar1 = 0x1ea;
    }
    *(undefined4 *)(*(int *)(param_1 + 0x20) + 0x18) = uVar1;
    *(undefined4 *)(param_1 + 0x2c) = 5;
    *(undefined4 *)(param_1 + 0x24) = uVar1;
    *(undefined4 *)(param_1 + 0x28) = *(undefined4 *)(param_1 + 0x46);
    *(undefined4 *)(param_1 + 0x30) = 0;
    *(undefined4 *)(param_1 + 0x34) = 0;
    netsndaft(param_1);
  }
  return;
}


// ==== net_write @ 0102aeba

void net_write(int param_1,int param_2)

{
  int unaff_D7;
  undefined4 uVar1;
  
  net_fiosc(*(undefined4 *)(param_2 + 8));
  if (unaff_D7 == 0) {
    uVar1 = 0xfffffff6;
  }
  else if ((*(uint *)(unaff_D7 + 4) & 0x10000000) == 0) {
    if (((*(uint *)(unaff_D7 + 4) & 0x10) != 0) &&
       (((*(uint *)(unaff_D7 + 4) & 0x200) != 0 || ((*(uint *)(unaff_D7 + 4) & 0x400) != 0)))) {
      latopa(*(undefined1 *)(param_1 + 2),*(undefined4 *)(param_2 + 0x10));
      *(int *)(param_2 + 0x10) = unaff_D7;
      *(undefined4 *)(unaff_D7 + 0x42) = *(undefined4 *)(param_2 + 0x10);
      *(undefined4 *)(unaff_D7 + 0x46) = *(undefined4 *)(param_2 + 0x10);
      cpybuf(param_1,unaff_D7 + 0x66,0x20);
      *(undefined4 *)(unaff_D7 + 0x52) = *(undefined4 *)(param_2 + 0xc);
      *(undefined4 *)(unaff_D7 + 0x4a) = *(undefined4 *)(param_2 + 0xc);
      net_write();
      return;
    }
    uVar1 = 0xfffffffe;
  }
  else {
    uVar1 = 0xfffffffb;
  }
  net_aplpo(param_1,uVar1);
  return;
}


// ==== net_close @ 0102af76

void net_close(undefined4 param_1,int param_2)

{
  int unaff_D7;
  undefined4 uVar1;
  
  net_fiosc(*(undefined4 *)(param_2 + 8));
  if (unaff_D7 == 0) {
    uVar1 = 0xfffffff6;
  }
  else {
    if ((*(uint *)(unaff_D7 + 4) & 0x10) != 0) {
      cpybuf(param_1,unaff_D7 + 0x66,0x20);
      nsndclose();
      return;
    }
    uVar1 = 0xfffffffe;
  }
  net_aplpo(param_1,uVar1);
  return;
}


// ==== net_seek @ 0102afd8

void net_seek(undefined4 param_1,int param_2)

{
  int unaff_D7;
  undefined4 uVar1;
  
  net_fiosc(*(undefined4 *)(param_2 + 8));
  if (unaff_D7 == 0) {
    uVar1 = 0xfffffff6;
  }
  else if ((*(uint *)(unaff_D7 + 4) & 0x10000000) == 0) {
    if ((*(uint *)(unaff_D7 + 4) & 0x100) != 0) {
      nsndseek();
      return;
    }
    uVar1 = 0xfffffffe;
  }
  else {
    uVar1 = 0xfffffffb;
  }
  net_aplpo(param_1,uVar1);
  return;
}


// ==== netsndaft @ 0102b044

void netsndaft(int param_1)

{
  int iVar1;
  int iVar2;
  int unaff_D7;
  int *piVar3;
  int *piVar4;
  int local_10;
  undefined4 local_c;
  
  local_c = &pcode;
  local_10 = *(int *)(param_1 + 0x34);
  netsend(*(undefined4 *)(param_1 + 0x20),*(undefined4 *)(param_1 + 0x24),
          *(undefined4 *)(param_1 + 0x28),*(undefined4 *)(param_1 + 0x30));
  piVar3 = (int *)((int)register0x0000003c + -8);
  switch(*(undefined4 *)(param_1 + 0x2c)) {
  case 1:
    if (unaff_D7 == 1) {
      *(uint *)(param_1 + 4) = *(uint *)(param_1 + 4) | 0x40000;
      return;
    }
    local_c = (undefined *)param_1;
    local_10 = 0x102b0ac;
    netfiofre();
    piVar4 = &local_10;
    local_10 = -8;
    break;
  case 2:
    if (unaff_D7 == 1) {
      return;
    }
    *(uint *)(param_1 + 4) = *(uint *)(param_1 + 4) & 0xffffffdf;
    goto LAB_0102b1b0;
  case 3:
    if (unaff_D7 == 1) {
      *(uint *)(param_1 + 4) = *(uint *)(param_1 + 4) | 0x801000;
      return;
    }
    *(uint *)(param_1 + 4) = *(uint *)(param_1 + 4) & 0xffffefff;
    *(uint *)(param_1 + 4) = *(uint *)(param_1 + 4) | 0x10000000;
    piVar4 = &local_c;
    local_c = (undefined *)0xfffffffb;
    break;
  case 4:
    if (unaff_D7 == 1) {
      if (*(int *)(param_1 + 0x30) == 0) goto LAB_0102b18c;
      *(int *)(param_1 + 0x4a) = *(int *)(param_1 + 0x4a) - *(int *)(param_1 + 0x30);
      iVar1 = *(int *)(param_1 + 0x46);
      iVar2 = *(int *)(param_1 + 0x30);
LAB_0102b186:
      *(int *)(param_1 + 0x46) = iVar2 + iVar1;
LAB_0102b18c:
      *(uint *)(param_1 + 4) = *(uint *)(param_1 + 4) | 0x80a000;
      return;
    }
    *(uint *)(param_1 + 4) = *(uint *)(param_1 + 4) & 0xffffdfff;
    *(uint *)(param_1 + 4) = *(uint *)(param_1 + 4) | 0x10000000;
    piVar4 = &local_c;
    local_c = (undefined *)0xfffffffb;
    break;
  case 5:
    if (unaff_D7 == 1) {
      *(int *)(param_1 + 0x4a) = *(int *)(param_1 + 0x4a) - *(int *)(param_1 + 0x24);
      iVar1 = *(int *)(param_1 + 0x46);
      iVar2 = *(int *)(param_1 + 0x24);
      goto LAB_0102b186;
    }
    *(uint *)(param_1 + 4) = *(uint *)(param_1 + 4) | 0x10000000;
    piVar4 = &local_c;
    local_c = (undefined *)0xfffffffb;
    break;
  case 6:
    if (unaff_D7 == 1) {
      return;
    }
LAB_0102b1b0:
    *(uint *)(param_1 + 4) = *(uint *)(param_1 + 4) | 0x10000000;
    local_c = (undefined *)0xfffffffd;
    local_10 = param_1 + 0x66;
    net_aplpo();
    piVar3 = &local_10;
LAB_0102b1ca:
    *(int *)((int)piVar3 + -4) = param_1;
    *(undefined4 *)((int)piVar3 + -8) = 0x102b1d2;
    netfiofre();
    return;
  case 7:
    if (unaff_D7 == 1) {
      return;
    }
    *(uint *)(param_1 + 4) = *(uint *)(param_1 + 4) | 0x10000000;
    piVar4 = &local_c;
    local_c = (undefined *)0xfffffffd;
    break;
  default:
    goto switchD_0102b086_caseD_8;
  case 10:
    if (unaff_D7 == 1) {
      *(undefined4 *)(param_1 + 8) = 1;
      return;
    }
    goto LAB_0102b1ca;
  }
  *(int *)((int)piVar4 + -4) = param_1 + 0x66;
  *(undefined4 *)((int)piVar4 + -8) = 0x102b1f4;
  net_aplpo();
switchD_0102b086_caseD_8:
  return;
}


// ==== setarg @ 0102b1fc

void setarg(byte *param_1)

{
  byte bVar1;
  int iVar2;
  byte *pbVar3;
  undefined4 *puVar4;
  undefined4 *puVar5;
  
  iVar2 = 0;
  puVar4 = &argtbl;
  while( true ) {
    bVar1 = *param_1;
    pbVar3 = param_1;
    while ((bVar1 != 0 && (((bVar1 < 0x21 || (bVar1 == 0x2c)) || (0x7e < bVar1))))) {
      pbVar3 = pbVar3 + 1;
      bVar1 = *pbVar3;
    }
    param_1 = pbVar3;
    puVar5 = puVar4;
    if (bVar1 == 0) goto LAB_0102b294;
    iVar2 = iVar2 + 1;
    puVar5 = puVar4 + 1;
    *puVar4 = pbVar3;
    for (; ((0x20 < *pbVar3 && (*pbVar3 < 0x7f)) && (*pbVar3 != 0x2c)); pbVar3 = pbVar3 + 1) {
      if (iVar2 == 1) {
        if ((*pbVar3 < 0x61) || (0x7a < *pbVar3)) {
          bVar1 = *pbVar3;
        }
        else {
          bVar1 = *pbVar3 - 0x20;
        }
        *pbVar3 = bVar1;
      }
    }
    param_1 = pbVar3;
    if (*pbVar3 == 0) goto LAB_0102b294;
    if (*pbVar3 == 10) break;
    param_1 = pbVar3 + 1;
    *pbVar3 = 0;
    puVar4 = puVar5;
    if (0x12 < iVar2) {
LAB_0102b294:
      while (iVar2 < 0x13) {
        *puVar5 = param_1;
        iVar2 = iVar2 + 1;
        puVar5 = puVar5 + 1;
      }
      return;
    }
  }
  param_1 = pbVar3 + 1;
  *pbVar3 = 0;
  goto LAB_0102b294;
}


// ==== cmpcmd @ 0102b2aa

char cmpcmd(char *param_1,char *param_2)

{
  for (; (*param_1 != '\0' && (*param_2 == *param_1)); param_2 = param_2 + 1) {
    param_1 = param_1 + 1;
  }
  return *param_1;
}


// ==== cmpchk @ 0102b2d6

void cmpchk(undefined4 param_1)

{
  int iVar1;
  int unaff_D7;
  
  iVar1 = 0;
  do {
    cmpcmd((&rtncmdmod)[iVar1],param_1);
    if (unaff_D7 == 1) {
      return;
    }
    iVar1 = iVar1 + 1;
  } while (iVar1 < 0xb);
  return;
}


// ==== strszchk @ 0102b316

void strszchk(char *param_1)

{
  int iVar1;
  
  iVar1 = 0;
  do {
    if (*param_1 == '\n') {
      return;
    }
    iVar1 = iVar1 + 1;
    param_1 = param_1 + 1;
  } while (iVar1 < 0x80);
  return;
}


// ==== nsnddisc @ 0102b33a

void nsnddisc(int param_1)

{
  makemlhea(0x27,param_1);
  *(undefined4 *)(*(int *)(param_1 + 0x20) + 0x18) = 0xb;
  *(undefined4 *)(param_1 + 0x2c) = 10;
  netreqsen(param_1,0xb,PTR_s_DISCONNECT_0104ace0,0,0);
  return;
}


// ==== nsndopen @ 0102b37e

void nsndopen(int param_1)

{
  undefined4 unaff_D7;
  
  makemlhea(0x27,param_1);
  sprintf(*(char **)(param_1 + 0x1c),sndcmdmod,(&openmodet)[*(byte *)(param_1 + 0x40)],
          *(undefined4 *)(param_1 + 0x3c));
  bufsize(*(undefined4 *)(param_1 + 0x1c));
  *(undefined4 *)(*(int *)(param_1 + 0x20) + 0x18) = unaff_D7;
  *(undefined4 *)(param_1 + 0x2c) = 2;
  netreqsen(param_1);
  return;
}


// ==== nsndclose @ 0102b3ec

void nsndclose(int param_1)

{
  undefined4 unaff_D7;
  
  makemlhea(0x27,param_1);
  sprintf(*(char **)(param_1 + 0x1c),PTR_s_CLOSE__d_0104acc8,*(undefined4 *)(param_1 + 0x14));
  bufsize(*(undefined4 *)(param_1 + 0x1c));
  *(undefined4 *)(*(int *)(param_1 + 0x20) + 0x18) = unaff_D7;
  *(undefined4 *)(param_1 + 0x2c) = 6;
  netreqsen(param_1);
  return;
}


// ==== nsndseek @ 0102b448

void nsndseek(int param_1,int param_2,undefined4 param_3)

{
  undefined4 unaff_D7;
  
  makemlhea(0x27,param_1);
  sprintf(*(char **)(param_1 + 0x1c),PTR_s_LSEEK__d__d__d_0104acc4,*(undefined4 *)(param_1 + 0x14),
          param_3,*(undefined4 *)(&seekmodet + param_2 * 4));
  bufsize(*(undefined4 *)(param_1 + 0x1c));
  *(undefined4 *)(*(int *)(param_1 + 0x20) + 0x18) = unaff_D7;
  *(undefined4 *)(param_1 + 0x2c) = 7;
  netreqsen(param_1);
  return;
}


// ==== netrespch @ 0102b4ba

void netrespch(int param_1,undefined4 param_2,int param_3)

{
  uint uVar1;
  uint uVar2;
  int unaff_D7;
  undefined4 uVar3;
  
  strszchk(param_1 + 0x48);
  setarg(param_1 + 0x48);
  cmpchk(argtbl);
  switch(unaff_D7) {
  case 0:
    if (unaff_D7 == 3) {
      atoi(DAT_0104adac);
      *(undefined4 *)(param_3 + 0x14) = 3;
      *(uint *)(param_3 + 4) = *(uint *)(param_3 + 4) & 0xffffffdf;
      *(uint *)(param_3 + 4) = *(uint *)(param_3 + 4) | 0x10;
      if (*(char *)(param_3 + 0x40) == '\0') {
        *(undefined4 *)(param_3 + 0x46) = *(undefined4 *)(param_3 + 0x42);
        *(undefined4 *)(param_3 + 0x4a) = 0;
      }
      uVar3 = *(undefined4 *)(param_3 + 0xc);
      goto LAB_0102b6c6;
    }
LAB_0102b71e:
    uVar1 = *(uint *)(param_3 + 4);
    uVar2 = 0xffffffdf;
    goto LAB_0102b724;
  case 1:
    if ((*(uint *)(param_3 + 4) & 0x1000) != 0) {
      atoi(DAT_0104adac);
      netrbufse(param_3 + 0x66,param_2,param_3);
    }
    break;
  case 2:
    if ((*(uint *)(param_3 + 4) & 0x2000) != 0) {
      atoi(DAT_0104adac);
      netwbufse(param_3 + 0x66,param_2,param_3);
    }
    break;
  case 3:
    atoi(DAT_0104adac);
    if (unaff_D7 != -1) {
      *(undefined4 *)(param_3 + 0x4a) = 0;
      *(undefined4 *)(param_3 + 0x52) = 0;
      uVar3 = *(undefined4 *)(param_3 + 0xc);
      goto LAB_0102b6c6;
    }
    *(uint *)(param_3 + 4) = *(uint *)(param_3 + 4) | 0x10000000;
    uVar3 = 0xfffffffb;
    goto LAB_0102b73a;
  case 4:
    atoi(DAT_0104adac);
    if (unaff_D7 == 0) {
      *(undefined4 *)(param_3 + 0x4a) = *(undefined4 *)(param_3 + 0xc);
    }
    else {
      *(undefined4 *)(param_3 + 0x4a) = 0xfffffffb;
      *(uint *)(param_3 + 4) = *(uint *)(param_3 + 4) & 0xffffffdf;
      *(uint *)(param_3 + 4) = *(uint *)(param_3 + 4) | 0x10000000;
    }
    net_aplpo(param_3 + 0x66,*(undefined4 *)(param_3 + 0x4a));
    netfiofre(param_3);
    break;
  case 7:
    *(uint *)(param_3 + 4) = *(uint *)(param_3 + 4) & 0xffffffdf;
    uVar3 = 1;
LAB_0102b6c6:
    net_aplpo(param_3 + 0x66,uVar3);
    break;
  case 9:
    atoi(DAT_0104adac);
    if (unaff_D7 != 0) goto LAB_0102b71e;
    *(uint *)(param_3 + 0x4e) = (uint)*(byte *)(param_3 + 0x68);
    *(uint *)(param_3 + 4) = *(uint *)(param_3 + 4) | 2;
    net_othht(*(undefined4 *)(param_3 + 0x38),*(undefined4 *)(param_3 + 0x4e));
    makemlhea(0x27,param_3);
    *(undefined4 *)(*(int *)(param_3 + 0x20) + 0x18) = 6;
    netsend(*(undefined4 *)(param_3 + 0x20),6,PTR_s_RESET_0104acd4,0,0,&pcode);
    *(undefined4 *)(param_3 + 0x4e) = 0;
    uVar1 = *(uint *)(param_3 + 4);
    uVar2 = 0xfffffffd;
LAB_0102b724:
    *(uint *)(param_3 + 4) = uVar2 & uVar1;
    *(uint *)(param_3 + 4) = *(uint *)(param_3 + 4) | 0x10000000;
    uVar3 = 0xffffffff;
LAB_0102b73a:
    net_aplpo(param_3 + 0x66,uVar3);
    nsnddisc(param_3);
  }
  return;
}


// ==== netrespmd @ 0102b756

undefined4 netrespmd(int param_1,int param_2,int param_3)

{
  undefined4 uVar1;
  
  if ((*(uint *)(param_3 + 4) & 0x1000) == 0) {
    uVar1 = *(undefined4 *)(param_3 + 4);
  }
  else {
    uVar1 = netrbufmd(param_3,*(undefined4 *)(param_2 + 8),param_1 + 0x48);
  }
  return uVar1;
}


// ==== netrespma @ 0102b78a

uint netrespma(int param_1)

{
  int *piVar1;
  uint uVar2;
  undefined4 uVar3;
  int unaff_D7;
  int iVar4;
  byte *pbVar5;
  undefined4 *puVar6;
  undefined4 local_24;
  
  piVar1 = (int *)(param_1 + 0xc);
  uVar2 = *piVar1 - 0x20;
  switch(uVar2) {
  default:
    goto switchD_0102b7ac_caseD_0;
  case 2:
    local_24 = (int *)0x102b7d4;
    uVar2 = net_answa();
    if (unaff_D7 == 0) {
      return uVar2;
    }
    *(uint *)(unaff_D7 + 4) = *(uint *)(unaff_D7 + 4) & 0xfffbffff;
    *(undefined4 *)(unaff_D7 + 0x10) = *(undefined4 *)(param_1 + 0x18);
    if (*(int *)(unaff_D7 + 0x10) < 0) {
      *(uint *)(unaff_D7 + 4) = *(uint *)(unaff_D7 + 4) & 0xfdffffff;
      *(uint *)(unaff_D7 + 4) = *(uint *)(unaff_D7 + 4) | 0x10000000;
      local_24 = (int *)(unaff_D7 + 0x66);
      net_aplpo();
      puVar6 = &local_24;
    }
    else if (sv_entry == 0) {
      *(uint *)(unaff_D7 + 4) = *(uint *)(unaff_D7 + 4) | 0x4000000;
      local_24 = (int *)0x2b;
      makemlhea();
      uVar2 = netsend(*(undefined4 *)(unaff_D7 + 0x20),0xf,serv_body,0,0,&pcode);
      if (unaff_D7 == 1) {
        return uVar2;
      }
      *(uint *)(unaff_D7 + 4) = *(uint *)(unaff_D7 + 4) & 0xfbffffff;
      *(uint *)(unaff_D7 + 4) = *(uint *)(unaff_D7 + 4) | 0x10000000;
      local_24 = (int *)(unaff_D7 + 0x66);
      net_aplpo();
      puVar6 = &local_24;
    }
    else {
      *(uint *)(unaff_D7 + 4) = *(uint *)(unaff_D7 + 4) | 0x2000000;
      local_24 = (int *)0x2a;
      makemlhea();
      uVar2 = netsend(*(undefined4 *)(unaff_D7 + 0x20),0x20,*(undefined4 *)(unaff_D7 + 0x38),0,0,
                      &pcode);
      if (unaff_D7 == 1) {
        return uVar2;
      }
      *(uint *)(unaff_D7 + 4) = *(uint *)(unaff_D7 + 4) & 0xfdffffff;
      *(uint *)(unaff_D7 + 4) = *(uint *)(unaff_D7 + 4) | 0x10000000;
      local_24 = (int *)(unaff_D7 + 0x66);
      net_aplpo();
      puVar6 = &local_24;
    }
    break;
  case 6:
    local_24 = (int *)0x102b934;
    uVar2 = hostfiosc();
    if (unaff_D7 == 0) {
      return uVar2;
    }
    *(uint *)(unaff_D7 + 4) = *(uint *)(unaff_D7 + 4) & 0xffbfffff;
    if (*(int *)(param_1 + 0x18) == 0) {
      return 0;
    }
    *(uint *)(unaff_D7 + 4) = *(uint *)(unaff_D7 + 4) | 0x10000000;
    *(undefined4 *)(unaff_D7 + 8) = 0;
    local_24 = (int *)0x29;
    makemlhea();
    uVar2 = netsend(*(undefined4 *)(unaff_D7 + 0x20),0,0,0,0,&pcode);
    if (unaff_D7 == 1) {
      uVar3 = 0xfffffff8;
      goto LAB_0102be28;
    }
    local_24 = (int *)(unaff_D7 + 0x66);
    net_aplpo();
    puVar6 = &local_24;
    break;
  case 7:
    local_24 = (int *)0x102b9c2;
    uVar2 = net_skfio();
    if (unaff_D7 == 0) {
      return uVar2;
    }
    if ((short)*(undefined4 *)(unaff_D7 + 4) < 0) {
      local_24 = (int *)0x102b9e0;
      uVar2 = netwbufmd();
      return uVar2;
    }
    if ((*(uint *)(unaff_D7 + 4) & 0x800000) != 0) {
      *(uint *)(unaff_D7 + 4) = *(uint *)(unaff_D7 + 4) & 0xff7fffff;
    }
    if (*(uint *)(unaff_D7 + 8) != 1) {
      return *(uint *)(unaff_D7 + 8);
    }
    *(undefined4 *)(unaff_D7 + 8) = 0;
    local_24 = (int *)0x29;
    makemlhea();
    uVar2 = netsend(*(undefined4 *)(unaff_D7 + 0x20),0,0,0,0,&pcode);
    puVar6 = (undefined4 *)((int)register0x0000003c + -0x1c);
    if (unaff_D7 == 1) {
      return uVar2;
    }
    break;
  case 8:
    if (*(int *)(param_1 + 0x1c) == 0) {
      return 0;
    }
    local_24 = (int *)0x102ba62;
    uVar2 = net_skfio();
    if (unaff_D7 == 0) {
      return uVar2;
    }
    local_24 = piVar1;
    if ((*(uint *)(unaff_D7 + 4) & 0x4000) == 0) {
      uVar2 = netrespch(param_1);
      return uVar2;
    }
    uVar2 = netrespmd(param_1);
    return uVar2;
  case 9:
    local_24 = (int *)0x102baa6;
    uVar2 = net_skfio();
    if (unaff_D7 == 0) {
      return uVar2;
    }
    if (*(int *)(unaff_D7 + 8) == 0) {
      local_24 = (int *)(unaff_D7 + 0x66);
      uVar2 = net_aplpo();
      *(undefined4 *)(unaff_D7 + 0x52) = 0;
      *(undefined4 *)(unaff_D7 + 0x10) = 0;
      return uVar2;
    }
    if (*(int *)(unaff_D7 + 8) == 1) {
      *(undefined4 *)(unaff_D7 + 8) = 0;
      local_24 = (int *)0x102baf2;
      uVar2 = netfiofre();
      return uVar2;
    }
    *(uint *)(unaff_D7 + 4) = *(uint *)(unaff_D7 + 4) | 0x10000000;
    local_24 = (int *)(unaff_D7 + 0x66);
    uVar2 = net_aplpo();
    return uVar2;
  case 10:
    local_24 = (int *)0x102bb22;
    hostfiosc();
    if ((*(uint *)(unaff_D7 + 4) & 0x2000000) == 0) {
      return *(uint *)(unaff_D7 + 4);
    }
    *(short *)(unaff_D7 + 0x56) = (short)*(undefined4 *)(param_1 + 0x2c);
    *(undefined2 *)(unaff_D7 + 0x58) = DAT_0104ad72;
    pbVar5 = (byte *)(*(int *)(param_1 + 0x34) + 8 + param_1);
    local_24 = (int *)(unaff_D7 + 0x5a);
    cpybuf(((uint)pbVar5[3] | (uint)pbVar5[2] << 8 | (uint)pbVar5[1] << 0x10 | (uint)*pbVar5 << 0x18
           ) + 8 + param_1);
    makemlhea(0x26,unaff_D7);
    *(uint *)(unaff_D7 + 4) = *(uint *)(unaff_D7 + 4) | 0x400000;
    uVar2 = netsend(*(undefined4 *)(unaff_D7 + 0x20),0,0,0,0,&pcode);
    if (unaff_D7 == 1) {
      return uVar2;
    }
    local_24 = (int *)(unaff_D7 + 0x66);
    net_aplpo();
    *(uint *)(unaff_D7 + 4) = *(uint *)(unaff_D7 + 4) & 0xffbfffff;
    *(uint *)(unaff_D7 + 4) = *(uint *)(unaff_D7 + 4) | 0x10000000;
    *(undefined4 *)(unaff_D7 + 8) = 0;
    makemlhea(0x29,unaff_D7);
    uVar2 = netsend(*(undefined4 *)(unaff_D7 + 0x20),0,0,0,0,&pcode);
    if (unaff_D7 == 1) goto LAB_0102be26;
    local_24 = (int *)(unaff_D7 + 0x66);
    net_aplpo();
    puVar6 = &local_24;
    break;
  case 0xb:
    local_24 = (int *)0x102bc6c;
    hostfiosc();
    local_24 = (int *)0x10;
    cpybuf(param_1 + 0x28,&sv_entry);
    iVar4 = sv_entry + 8 + param_1;
    bufsize(iVar4,iVar4);
    fiobytser(unaff_D7);
    pbVar5 = (byte *)(DAT_0104ad6c + 8 + param_1);
    iVar4 = ((uint)pbVar5[3] |
            (uint)pbVar5[2] << 8 | (uint)pbVar5[1] << 0x10 | (uint)*pbVar5 << 0x18) + 8 + param_1;
    sv_entry = unaff_D7;
    bufsize(iVar4,iVar4);
    fiobytser(unaff_D7);
    local_24 = (int *)0x4;
    fiobytser(unaff_D7);
    param_1 = DAT_0104ad74 + 8 + param_1;
    DAT_0104ad6c = unaff_D7;
    bufsize(param_1,param_1);
    fiobytser(unaff_D7);
    DAT_0104ad74 = unaff_D7;
    if (unaff_D7 != 0) {
      *(uint *)(unaff_D7 + 4) = *(uint *)(unaff_D7 + 4) & 0xfbffffff;
      *(uint *)(unaff_D7 + 4) = *(uint *)(unaff_D7 + 4) | 0x2000000;
      local_24 = (int *)0x2a;
      makemlhea();
      uVar2 = netsend(*(undefined4 *)(unaff_D7 + 0x20),0x20,*(undefined4 *)(unaff_D7 + 0x38),0,0,
                      &pcode);
      if (unaff_D7 == 1) {
        return uVar2;
      }
    }
    local_24 = (int *)(unaff_D7 + 0x66);
    net_aplpo();
    *(uint *)(unaff_D7 + 4) = *(uint *)(unaff_D7 + 4) & 0xfdffffff;
    *(uint *)(unaff_D7 + 4) = *(uint *)(unaff_D7 + 4) | 0x10000000;
    *(undefined4 *)(unaff_D7 + 8) = 0;
    makemlhea(0x29,unaff_D7);
    uVar2 = netsend(*(undefined4 *)(unaff_D7 + 0x20),0,0,0,0,&pcode);
    if (unaff_D7 != 1) {
      local_24 = (int *)(unaff_D7 + 0x66);
      net_aplpo();
      uVar2 = netfiofre(unaff_D7);
    }
LAB_0102be26:
    uVar3 = 0xfffffff4;
LAB_0102be28:
    *(undefined4 *)(unaff_D7 + 0x4a) = uVar3;
    goto switchD_0102b7ac_caseD_0;
  }
  *(int *)((int)puVar6 + -4) = unaff_D7;
  *(undefined4 *)((int)puVar6 + -8) = 0x102bc5e;
  uVar2 = netfiofre();
switchD_0102b7ac_caseD_0:
  return uVar2;
}


// ==== os_vrsex @ 0102be3c

void os_vrsex(int param_1,char *param_2)

{
  int iVar1;
  int iVar2;
  char *pcVar3;
  
  iVar1 = 0;
  iVar2 = 0;
  pcVar3 = (char *)0x0;
  if (param_1 == 0) {
    pcVar3 = sysver;
    iVar2 = 6;
  }
  else if (param_1 == 1) {
    pcVar3 = Oversion;
    iVar2 = 0xb;
  }
  for (; iVar1 < iVar2; iVar1 = iVar1 + 1) {
    if (*pcVar3 == ' ') break;
    *param_2 = *pcVar3;
    pcVar3 = pcVar3 + 1;
    param_2 = param_2 + 1;
  }
  *param_2 = '\0';
  return;
}


// ==== phtopno @ 0102be88

undefined4 phtopno(void)

{
  return 10;
}


// ==== smphtopno @ 0102be9e

undefined4 smphtopno(void)

{
  return 10;
}


// ==== pnotoph @ 0102beb4

undefined4 pnotoph(void)

{
  return 10;
}


// ==== smpnotoph @ 0102beca

undefined4 smpnotoph(void)

{
  return 10;
}


// ==== pageget @ 0102bee0

void pageget(int param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  
  if (param_1 <= memcbctl[1]) {
    piVar4 = memcbctl;
    for (iVar2 = 1; piVar4 = piVar4 + 2, iVar2 < *memcbctl; iVar2 = iVar2 + 1) {
      if (*(short *)piVar4 == 0) {
        iVar1 = 0;
        piVar3 = piVar4;
        if (0 < param_1) {
          do {
            if (*(short *)piVar3 != 0) break;
            iVar1 = iVar1 + 1;
            piVar3 = piVar3 + 2;
          } while (iVar1 < param_1);
        }
        if (param_1 == iVar1) {
          iVar1 = 0;
          if (0 < param_1) {
            do {
              *(undefined2 *)piVar4 = 1;
              iVar1 = iVar1 + 1;
              piVar4 = piVar4 + 2;
            } while (iVar1 < param_1);
          }
          memcbctl[1] = memcbctl[1] - param_1;
          pnotoph(iVar2);
          return;
        }
        iVar2 = iVar1 + iVar2;
        piVar4 = piVar4 + iVar1 * 2;
      }
    }
  }
  return;
}


// ==== smpageget @ 0102bf6e

void smpageget(int param_1)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  int *piVar4;
  
  if (param_1 <= smmemcbct[1]) {
    piVar4 = smmemcbct;
    for (iVar2 = 0; piVar4 = piVar4 + 2, iVar2 < *smmemcbct; iVar2 = iVar2 + 1) {
      if (*(short *)piVar4 == 0) {
        iVar1 = 0;
        piVar3 = piVar4;
        if (0 < param_1) {
          do {
            if (*(short *)piVar3 != 0) break;
            iVar1 = iVar1 + 1;
            piVar3 = piVar3 + 2;
          } while (iVar1 < param_1);
        }
        if (param_1 == iVar1) {
          iVar1 = 0;
          if (0 < param_1) {
            do {
              *(undefined2 *)piVar4 = 1;
              iVar1 = iVar1 + 1;
              piVar4 = piVar4 + 2;
            } while (iVar1 < param_1);
          }
          smmemcbct[1] = smmemcbct[1] - param_1;
          smpnotoph(iVar2);
          return;
        }
        iVar2 = iVar1 + iVar2;
        piVar4 = piVar4 + iVar1 * 2;
      }
    }
  }
  return;
}


// ==== spageget @ 0102bffc

int spageget(void)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  piVar3 = memcbctl + *memcbctl * 2;
  iVar1 = memcbctl[1];
  iVar2 = 0;
  if (iVar1 != 0) {
    iVar2 = *memcbctl;
    do {
      iVar2 = iVar2 + -1;
      if (iVar2 == 0) {
        return iVar1;
      }
      piVar3 = piVar3 + -2;
      iVar1 = CONCAT22((short)((uint)iVar1 >> 0x10),*(short *)piVar3);
    } while (*(short *)piVar3 != 0);
    *(undefined2 *)piVar3 = 1;
    memcbctl[1] = memcbctl[1] + -1;
    iVar2 = pnotoph(iVar2);
  }
  return iVar2;
}


// ==== s4pageget @ 0102c050

int s4pageget(void)

{
  short sVar1;
  int *piVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  int *piVar6;
  
  iVar3 = memcbctl[1];
  iVar4 = 0;
  if (iVar3 != 0) {
    iVar4 = *memcbctl;
    piVar6 = memcbctl + *memcbctl * 2;
    do {
      do {
        piVar2 = piVar6;
        iVar4 = iVar4 + -1;
        if (iVar4 == 0) {
          return iVar3;
        }
        piVar6 = piVar2 + -2;
        sVar1 = *(short *)piVar6;
        iVar3 = CONCAT22((short)((uint)iVar3 >> 0x10),sVar1);
      } while (sVar1 != 0);
      iVar5 = 3;
      for (piVar6 = piVar2 + -4;
          ((iVar4 != 0 && (iVar5 != 0)) &&
          (iVar3 = CONCAT22((short)((uint)iVar3 >> 0x10),*(short *)piVar6), *(short *)piVar6 == 0));
          piVar6 = piVar6 + -2) {
        iVar5 = iVar5 + -1;
        iVar4 = iVar4 + -1;
      }
    } while ((iVar5 != 0) ||
            (iVar3 = CONCAT22((short)((uint)iVar3 >> 0x10),*(short *)piVar6), *(short *)piVar6 != 0)
            );
    *(undefined2 *)piVar6 = 1;
    *(undefined2 *)(piVar6 + 2) = 1;
    *(undefined2 *)(piVar6 + 4) = 1;
    *(undefined2 *)(piVar6 + 6) = 1;
    memcbctl[1] = memcbctl[1] + -4;
    iVar4 = pnotoph(iVar4);
  }
  return iVar4;
}


// ==== pagefree @ 0102c0dc

undefined2 pagefree(undefined4 param_1)

{
  undefined2 uVar1;
  int unaff_D7;
  short *psVar2;
  
  phtopno(param_1);
  psVar2 = (short *)(memcbctl + unaff_D7 * 8);
  if (*psVar2 == 0) {
    uVar1 = 0;
  }
  else {
    uVar1 = fill(psVar2,8,0);
    *(int *)(memcbctl + 4) = *(int *)(memcbctl + 4) + 1;
  }
  return uVar1;
}


// ==== ng_free @ 0102c11c

void ng_free(void)

{
  return;
}


// ==== seqpagefr @ 0102c124

void seqpagefr(undefined4 param_1)

{
  int iVar1;
  int iVar2;
  int unaff_D7;
  short *psVar3;
  
  phtopno(param_1);
  psVar3 = (short *)(memcbctl + unaff_D7 * 8);
  if ((*psVar3 == 0) || ((uint)*(byte *)((int)psVar3 + 0xb) == *(byte *)((int)psVar3 + 3) + 1)) {
LAB_0102c18e:
    ng_free(psVar3);
  }
  else {
    iVar1 = *(byte *)((int)psVar3 + 3) - 1;
    fill(psVar3,8,0);
    *(int *)(memcbctl + 4) = *(int *)(memcbctl + 4) + 1;
    iVar2 = 0;
    if (0 < iVar1) {
      do {
        psVar3 = psVar3 + 4;
        if (*psVar3 == 0) goto LAB_0102c18e;
        fill(psVar3,8,0);
        *(int *)(memcbctl + 4) = *(int *)(memcbctl + 4) + 1;
        iVar2 = iVar2 + 1;
      } while (iVar2 < iVar1);
    }
  }
  return;
}


// ==== seqchkpag @ 0102c1ca

short seqchkpag(undefined4 param_1)

{
  byte bVar1;
  short sVar2;
  int iVar3;
  int unaff_D7;
  short *psVar4;
  
  phtopno(param_1);
  psVar4 = (short *)(memcbctl + unaff_D7 * 8);
  sVar2 = 0;
  if (*psVar4 != 0) {
    bVar1 = *(byte *)((int)psVar4 + 3);
    sVar2 = CONCAT11((char)((ushort)*psVar4 >> 8),bVar1);
    iVar3 = 0;
    if (bVar1 != 0) {
      do {
        psVar4 = psVar4 + 4;
        sVar2 = *psVar4;
        if (sVar2 == 0) {
          return 0;
        }
        iVar3 = iVar3 + 1;
      } while (iVar3 < (int)(uint)bVar1);
    }
  }
  return sVar2;
}


// ==== pageszfre @ 0102c20c

undefined2 pageszfre(undefined4 param_1,int param_2)

{
  undefined2 uVar1;
  int iVar2;
  int unaff_D7;
  short *psVar3;
  
  uVar1 = phtopno(param_1);
  psVar3 = (short *)(memcbctl + unaff_D7 * 8);
  iVar2 = 0;
  if (0 < param_2) {
    do {
      if (*psVar3 == 0) {
        return 0;
      }
      uVar1 = fill(psVar3,8,0);
      *(int *)(memcbctl + 4) = *(int *)(memcbctl + 4) + 1;
      iVar2 = iVar2 + 1;
      psVar3 = psVar3 + 4;
    } while (iVar2 < param_2);
  }
  return uVar1;
}


// ==== smpagefre @ 0102c26c

undefined2 smpagefre(undefined4 param_1)

{
  undefined2 uVar1;
  int unaff_D7;
  short *psVar2;
  
  smphtopno(param_1);
  psVar2 = (short *)(smmemcbct + unaff_D7 * 8 + 8);
  if (*psVar2 == 0) {
    uVar1 = 0;
  }
  else {
    uVar1 = fill(psVar2,8,0);
    *(int *)(smmemcbct + 4) = *(int *)(smmemcbct + 4) + 1;
  }
  return uVar1;
}


// ==== smseqpage @ 0102c2ae

void smseqpage(undefined4 param_1)

{
  int iVar1;
  int iVar2;
  int unaff_D7;
  short *psVar3;
  
  smphtopno(param_1);
  psVar3 = (short *)(smmemcbct + unaff_D7 * 8);
  if ((*psVar3 == 0) || ((uint)*(byte *)((int)psVar3 + 0xb) == *(byte *)((int)psVar3 + 3) + 1)) {
LAB_0102c318:
    ng_free(psVar3);
  }
  else {
    iVar1 = *(byte *)((int)psVar3 + 3) - 1;
    fill(psVar3,8,0);
    *(int *)(smmemcbct + 4) = *(int *)(smmemcbct + 4) + 1;
    iVar2 = 0;
    if (0 < iVar1) {
      do {
        psVar3 = psVar3 + 4;
        if (*psVar3 == 0) goto LAB_0102c318;
        fill(psVar3,8,0);
        *(int *)(smmemcbct + 4) = *(int *)(smmemcbct + 4) + 1;
        iVar2 = iVar2 + 1;
      } while (iVar2 < iVar1);
    }
  }
  return;
}


// ==== smseqchkp @ 0102c354

short smseqchkp(undefined4 param_1)

{
  byte bVar1;
  short sVar2;
  int iVar3;
  int unaff_D7;
  short *psVar4;
  
  smphtopno(param_1);
  psVar4 = (short *)(smmemcbct + unaff_D7 * 8);
  sVar2 = 0;
  if (*psVar4 != 0) {
    bVar1 = *(byte *)((int)psVar4 + 3);
    sVar2 = CONCAT11((char)((ushort)*psVar4 >> 8),bVar1);
    iVar3 = 0;
    if (bVar1 != 0) {
      do {
        psVar4 = psVar4 + 4;
        sVar2 = *psVar4;
        if (sVar2 == 0) {
          return 0;
        }
        iVar3 = iVar3 + 1;
      } while (iVar3 < (int)(uint)bVar1);
    }
  }
  return sVar2;
}


// ==== smpageszf @ 0102c396

undefined2 smpageszf(undefined4 param_1,int param_2)

{
  undefined2 uVar1;
  int iVar2;
  int unaff_D7;
  short *psVar3;
  
  uVar1 = smphtopno(param_1);
  psVar3 = (short *)(smmemcbct + unaff_D7 * 8);
  iVar2 = 0;
  if (0 < param_2) {
    do {
      psVar3 = psVar3 + 4;
      if (*psVar3 == 0) {
        return 0;
      }
      uVar1 = fill(psVar3,8,0);
      *(int *)(smmemcbct + 4) = *(int *)(smmemcbct + 4) + 1;
      iVar2 = iVar2 + 1;
    } while (iVar2 < param_2);
  }
  return uVar1;
}


// ==== pagemake @ 0102c3f8

void pagemake(undefined4 param_1,short param_2,undefined1 param_3,int param_4,ushort param_5)

{
  ushort uVar1;
  int unaff_D7;
  short *psVar2;
  
  phtopno(param_1);
  psVar2 = (short *)(memcbctl + unaff_D7 * 8);
  uVar1 = 0;
  if (param_5 != 0) {
    do {
      if (*psVar2 != 1) {
        return;
      }
      *psVar2 = param_2;
      *(undefined1 *)(psVar2 + 1) = param_3;
      if (uVar1 == 0) {
        *(char *)((int)psVar2 + 3) = (char)param_5;
      }
      else {
        *(char *)((int)psVar2 + 3) = (char)uVar1 + '\x01';
      }
      *(int *)(psVar2 + 2) = param_4;
      uVar1 = uVar1 + 1;
      psVar2 = psVar2 + 4;
      param_4 = param_4 + 0x400;
    } while (uVar1 < param_5);
  }
  return;
}


// ==== smpagemak @ 0102c46e

void smpagemak(undefined4 param_1,short param_2,undefined1 param_3,int param_4,ushort param_5)

{
  ushort uVar1;
  int unaff_D7;
  short *psVar2;
  short *psVar3;
  
  smphtopno(param_1);
  uVar1 = 0;
  if (param_5 != 0) {
    psVar3 = (short *)(smmemcbct + unaff_D7 * 8);
    do {
      psVar2 = psVar3 + 4;
      if (*psVar2 != 1) {
        return;
      }
      *psVar2 = param_2;
      *(undefined1 *)(psVar3 + 5) = param_3;
      if (uVar1 == 0) {
        *(char *)((int)psVar3 + 0xb) = (char)param_5;
      }
      else {
        *(char *)((int)psVar3 + 0xb) = (char)uVar1 + '\x01';
      }
      *(int *)(psVar3 + 6) = param_4;
      uVar1 = uVar1 + 1;
      param_4 = param_4 + 0x400;
      psVar3 = psVar2;
    } while (uVar1 < param_5);
  }
  return;
}


// ==== spagemake @ 0102c4e6

void spagemake(undefined4 param_1,short param_2,undefined1 param_3,undefined4 param_4)

{
  int unaff_D7;
  short *psVar1;
  
  phtopno(param_1);
  psVar1 = (short *)(memcbctl + unaff_D7 * 8);
  if (*psVar1 == 1) {
    *psVar1 = param_2;
    *(undefined1 *)(psVar1 + 1) = param_3;
    *(undefined1 *)((int)psVar1 + 3) = 0;
    *(undefined4 *)(psVar1 + 2) = param_4;
  }
  return;
}


// ==== _crpcb @ 0102c534

uint _crpcb(int param_1)

{
  int iVar1;
  byte *pbVar2;
  byte bVar3;
  int iVar4;
  undefined2 uVar5;
  ushort uVar7;
  uint uVar6;
  int unaff_D7;
  ushort *puVar8;
  
  iVar1 = *(int *)(param_1 + 4);
  iVar4 = iVar1 * 0x80;
  puVar8 = &syspcb + iVar1 * 0x40;
  uVar5 = (undefined2)((uint)iVar4 >> 0x10);
  uVar6 = CONCAT22(uVar5,*puVar8);
  if ((*puVar8 == 0) &&
     (uVar6 = CONCAT22(uVar5,*(short *)(&DAT_01055762 + iVar4)),
     *(short *)(&DAT_01055762 + iVar4) == 0)) {
    pbVar2 = *(byte **)(param_1 + 8);
    fill(puVar8,0x80,0);
    uVar6 = *(uint *)(pbVar2 + 2);
    if (0x7fffff < uVar6) {
      bVar3 = pbVar2[1] | *pbVar2;
      *puVar8 = 0;
      if ((char)bVar3 < '\0') {
        uVar7 = *puVar8 | 0x200;
      }
      else {
        uVar7 = *puVar8 | 0x100;
      }
      *puVar8 = uVar7;
      if ((bVar3 & 0x40) != 0) {
        *puVar8 = *puVar8 | 1;
      }
      if ((bVar3 & 0x20) != 0) {
        *puVar8 = *puVar8 | 2;
      }
      *(short *)(&DAT_01055762 + iVar4) = (short)iVar1;
      *(undefined4 *)(&DAT_0105578c + iVar4) = *(undefined4 *)(pbVar2 + 2);
      *(undefined4 *)(&DAT_01055790 + iVar4) = *(undefined4 *)(pbVar2 + 6);
      *(undefined4 *)(&DAT_01055794 + iVar4) = *(undefined4 *)(pbVar2 + 10);
      *(undefined4 *)(&DAT_01055798 + iVar4) = *(undefined4 *)(pbVar2 + 0xe);
      if (((*(int *)(&DAT_01055790 + iVar4) != 0) ||
          (uVar6 = 0, *(int *)(&DAT_01055798 + iVar4) != 0)) &&
         (uVar6 = mmu_pcbma(puVar8), unaff_D7 == 0)) {
        mmu_pcbfr(puVar8);
        uVar6 = fill(puVar8,0x80,0);
      }
    }
  }
  return uVar6;
}


// ==== _delpcb @ 0102c626

undefined4 _delpcb(int param_1)

{
  int iVar1;
  undefined2 uVar2;
  undefined4 uVar3;
  short *psVar4;
  
  iVar1 = *(int *)(param_1 + 4) * 0x80;
  psVar4 = &syspcb + *(int *)(param_1 + 4) * 0x40;
  uVar2 = (undefined2)((uint)iVar1 >> 0x10);
  uVar3 = CONCAT22(uVar2,*psVar4);
  if ((*psVar4 != 0) &&
     (uVar3 = CONCAT22(uVar2,*(short *)(&DAT_01055762 + iVar1)),
     *(short *)(&DAT_01055762 + iVar1) != 0)) {
    mmu_pcbfr(psVar4);
    uVar3 = fill(psVar4,0x80,0);
  }
  return uVar3;
}


// ==== _mapset @ 0102c668

uint _mapset(int param_1)

{
  byte bVar1;
  uint uVar2;
  int unaff_D7;
  char cVar3;
  
  if (*(int *)(param_1 + 4) == 0) {
    uVar2 = (uint)*(byte *)(etcb + 3);
  }
  else {
    uVar2 = *(uint *)(param_1 + 4);
  }
  uVar2 = gettcb(uVar2);
  if ((unaff_D7 != -3) && (uVar2 = *(uint *)(param_1 + 8) & 0xffffff9f, uVar2 == 0)) {
    bVar1 = *(byte *)(unaff_D7 + 0x48) | (byte)*(undefined4 *)(param_1 + 8);
    uVar2 = CONCAT31((int3)((uint)*(undefined4 *)(param_1 + 8) >> 8),bVar1);
    *(byte *)(unaff_D7 + 0x48) = bVar1;
    if (unaff_D7 == etcb) {
      cVar3 = (*(byte *)(unaff_D7 + 0x48) & 0x40) != 0;
      if ((*(byte *)(unaff_D7 + 0x48) & 0x20) != 0) {
        cVar3 = cVar3 + '\x02';
      }
      uVar2 = mmu_shdse(*(undefined1 *)(unaff_D7 + 0x49),cVar3);
    }
  }
  return uVar2;
}


// ==== _mapclr @ 0102c6fc

uint _mapclr(int param_1)

{
  byte bVar1;
  uint uVar2;
  int unaff_D7;
  char cVar3;
  
  if (*(int *)(param_1 + 4) == 0) {
    uVar2 = (uint)*(byte *)(etcb + 3);
  }
  else {
    uVar2 = *(uint *)(param_1 + 4);
  }
  uVar2 = gettcb(uVar2);
  if ((unaff_D7 != -3) && (uVar2 = *(uint *)(param_1 + 8) & 0xffffff9f, uVar2 == 0)) {
    bVar1 = *(byte *)(unaff_D7 + 0x48) & ~(byte)*(undefined4 *)(param_1 + 8);
    uVar2 = CONCAT31((int3)((uint)*(undefined4 *)(param_1 + 8) >> 8),bVar1);
    *(byte *)(unaff_D7 + 0x48) = bVar1;
    if (unaff_D7 == etcb) {
      cVar3 = (*(uint *)(param_1 + 8) & 0x40) != 0;
      if ((*(uint *)(param_1 + 8) & 0x20) != 0) {
        cVar3 = cVar3 + '\x02';
      }
      uVar2 = mmu_shdrr(*(undefined1 *)(unaff_D7 + 0x49),cVar3);
    }
  }
  return uVar2;
}


// ==== _getpar @ 0102c792

undefined1 _getpar(int param_1)

{
  undefined1 uVar1;
  int unaff_D7;
  
  uVar1 = gettcb(*(undefined4 *)(param_1 + 4));
  if (unaff_D7 != -3) {
    uVar1 = *(undefined1 *)(unaff_D7 + 0x49);
  }
  return uVar1;
}


// ==== getpcb @ 0102c7bc

short getpcb(short param_1)

{
  short sVar1;
  int unaff_D7;
  
  sVar1 = gettcb((int)param_1);
  if (unaff_D7 != -3) {
    sVar1 = (&syspcb)[(uint)*(byte *)(unaff_D7 + 0x49) * 0x40];
    if (sVar1 == 0) {
      sVar1 = *(short *)(&DAT_01055762 + (uint)*(byte *)(unaff_D7 + 0x49) * 0x80);
    }
  }
  return sVar1;
}


// ==== mmusetup @ 0102c7fa

void mmusetup(byte param_1)

{
  int iVar1;
  ushort uVar2;
  undefined2 *puVar3;
  
  iVar1 = (uint)param_1 * 0x80;
  puVar3 = &syspcb + (uint)param_1 * 0x40;
  uVar2 = (ushort)((*(byte *)(etcb + 0x48) & 0x40) != 0);
  if ((*(byte *)(etcb + 0x48) & 0x20) != 0) {
    uVar2 = uVar2 + 2;
  }
  if ((puVar3 != cpcb) || (uVar2 != mmuswflag)) {
    if (cpcb != (undefined2 *)0x0) {
      mmu_shdrr((int)(short)cpcb[1],3);
    }
    cpcb = puVar3;
    if (uVar2 != 0) {
      mmu_shdse((int)*(short *)(&DAT_01055762 + iVar1),uVar2);
    }
    mmuswflag = uVar2;
    set_crp(0x80000002,*(uint *)(&DAT_0105576c + iVar1) & 0xfffffff0);
    set_tt0(0x38143);
    set_tt1(0xc038516);
    set_cacr(setcacr);
    set_tc(0x80a07780);
  }
  return;
}


// ==== cacr_on @ 0102c8d8

void cacr_on(void)

{
  set_cacr(setcacr);
  return;
}


// ==== cacr_off @ 0102c8ec

void cacr_off(void)

{
  set_cacr(0);
  return;
}


// ==== sym_alloc @ 0102c8fc

void sym_alloc(int param_1,uint param_2)

{
  int iVar1;
  int unaff_D7;
  
  iVar1 = (uint)((param_2 & 0x3ff) != 0) + (param_2 >> 10);
  pageget(iVar1);
  if ((unaff_D7 != 0) && (pagemake(), (short)unaff_D7 != 0)) {
    *(int *)(param_1 + 0x44) = unaff_D7;
    *(int *)(param_1 + 0x48) = iVar1;
  }
  return;
}


// ==== ttyrxint @ 0102c968

void ttyrxint(void)

{
  FUN_0102c9ea(DAT_0104ae0c,0x20000);
  return;
}


// ==== smcrxint @ 0102c982

void smcrxint(void)

{
  FUN_0102c9ea(DAT_0104ae14,0x40000);
  return;
}


// ==== ptprxint @ 0102c99c

void ptprxint(void)

{
  FUN_0102c9ea(DAT_0104ae1c,0x10000);
  return;
}


// ==== auxrxint @ 0102c9b6

void auxrxint(void)

{
  FUN_0102c9ea(DAT_0104ae24,0x80000);
  return;
}


// ==== prtrxint @ 0102c9d0

void prtrxint(void)

{
  FUN_0102c9ea(&DAT_0d01cc00,0x100000);
  return;
}


// ==== FUN_0102c9ea @ 0102c9ea

undefined2 FUN_0102c9ea(int param_1,undefined4 param_2)

{
  undefined2 uVar1;
  
  if ((*(ushort *)(param_1 + 0x22) & 0xe) != 0) {
    FUN_0102cb1c(param_1);
  }
  uVar1 = 0;
  if (*(short *)(param_1 + 0x220) != 0) {
    uVar1 = post(8,param_2);
  }
  return uVar1;
}


// ==== prttxint @ 0102ca24

void prttxint(void)

{
  post(8,0x1000);
  return;
}


// ==== ttytxint @ 0102ca3a

void ttytxint(void)

{
  post(8,0x200);
  return;
}


// ==== smctxint @ 0102ca50

void smctxint(void)

{
  post(8,0x400);
  return;
}


// ==== ptptxint @ 0102ca66

void ptptxint(void)

{
  post(8,0x100);
  return;
}


// ==== auxtxint @ 0102ca7c

void auxtxint(void)

{
  post(8,0x800);
  return;
}


// ==== ttyreset @ 0102ca92

void ttyreset(void)

{
  FUN_0102caea(1);
  return;
}


// ==== prtreset @ 0102caa4

void prtreset(void)

{
  FUN_0102caea(0);
  return;
}


// ==== smcreset @ 0102cab4

void smcreset(void)

{
  FUN_0102caea(2);
  return;
}


// ==== ptpreset @ 0102cac6

void ptpreset(void)

{
  FUN_0102caea(3);
  return;
}


// ==== auxreset @ 0102cad8

void auxreset(void)

{
  FUN_0102caea(4);
  return;
}


// ==== FUN_0102caea @ 0102caea

void FUN_0102caea(int param_1)

{
  int iVar1;
  undefined2 unaff_D7w;
  
  iVar1 = (&Portdb)[param_1 * 2];
  FUN_0102ccaa(&Portdb + param_1 * 2);
  *(undefined2 *)(iVar1 + 4) = unaff_D7w;
  sioreset(iVar1);
  return;
}


// ==== FUN_0102cb1c @ 0102cb1c

void FUN_0102cb1c(undefined2 *param_1)

{
  param_1[1] = 6;
  *param_1 = 1;
  FUN_0102ccc8(param_1);
  return;
}


// ==== sioreset @ 0102cb3a

void sioreset(undefined2 *param_1)

{
  param_1[1] = 1;
  *param_1 = 2;
  FUN_0102ccc8(param_1);
  return;
}


// ==== prtnop @ 0102cb58

void prtnop(void)

{
  return;
}


// ==== ttyinit @ 0102cb60

void ttyinit(void)

{
  undefined2 *puVar1;
  undefined2 unaff_D7w;
  
  puVar1 = DAT_0104ae0c;
  DAT_0104ae0c[1] = 1;
  FUN_0102ccaa(&DAT_0104ae0c);
  puVar1[2] = unaff_D7w;
  puVar1[5] = 0x4846;
  puVar1[6] = 0xa347;
  *puVar1 = 6;
  FUN_0102ccc8(puVar1);
  return;
}


// ==== smcinit @ 0102cba0

void smcinit(void)

{
  undefined2 *puVar1;
  undefined2 unaff_D7w;
  
  puVar1 = DAT_0104ae14;
  DAT_0104ae14[1] = 1;
  FUN_0102ccaa(&DAT_0104ae14);
  puVar1[2] = unaff_D7w;
  puVar1[5] = 0x4543;
  puVar1[6] = 0xa344;
  *puVar1 = 6;
  FUN_0102ccc8(puVar1);
  return;
}


// ==== ptpinit @ 0102cbe0

void ptpinit(void)

{
  undefined2 *puVar1;
  undefined2 unaff_D7w;
  
  puVar1 = DAT_0104ae1c;
  DAT_0104ae1c[1] = 1;
  FUN_0102ccaa(&DAT_0104ae1c);
  puVar1[2] = unaff_D7w;
  puVar1[5] = 0x4240;
  puVar1[6] = 0xa341;
  *puVar1 = 6;
  FUN_0102ccc8(puVar1);
  return;
}


// ==== auxinit @ 0102cc20

void auxinit(void)

{
  undefined2 *puVar1;
  undefined2 unaff_D7w;
  
  puVar1 = DAT_0104ae24;
  DAT_0104ae24[1] = 1;
  FUN_0102ccaa(&DAT_0104ae24);
  puVar1[2] = unaff_D7w;
  puVar1[5] = 0x4b49;
  puVar1[6] = 0xa34a;
  *puVar1 = 6;
  FUN_0102ccc8(puVar1);
  return;
}


// ==== prtinit @ 0102cc60

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void prtinit(void)

{
  undefined2 unaff_D7w;
  
  _DAT_0d01cc02 = 1;
  FUN_0102ccaa(&Portdb);
  _DAT_0d01cc0a = 0xa6a4;
  _DAT_0d01cc0c = 0xa3a5;
  _DAT_0d01cc00 = 6;
  _DAT_0d01cc04 = unaff_D7w;
  FUN_0102ccc8(&DAT_0d01cc00);
  return;
}


// ==== FUN_0102ccaa @ 0102ccaa

ushort FUN_0102ccaa(int param_1)

{
  return *(ushort *)(param_1 + 6) | *(ushort *)(param_1 + 4) | 0xf00;
}


// ==== FUN_0102ccc8 @ 0102ccc8

void FUN_0102ccc8(int param_1)

{
  ushort uVar1;
  int iVar2;
  
  iVar2 = 0x1900;
  uVar1 = *(ushort *)(param_1 + 0x20);
  while ((uVar1 & 1) != 0) {
    if (iVar2 == 0) {
      return;
    }
    iVar2 = iVar2 + -1;
    uVar1 = *(ushort *)(param_1 + 0x20);
  }
  iVar2 = 640000;
  uVar1 = *(ushort *)(param_1 + 0x20);
  while( true ) {
    if ((uVar1 & 1) != 0) {
      iVar2 = 64000;
      do {
        iVar2 = iVar2 + -1;
      } while (iVar2 != 0);
      return;
    }
    if (iVar2 == 0) break;
    iVar2 = iVar2 + -1;
    uVar1 = *(ushort *)(param_1 + 0x20);
  }
  return;
}


// ==== prttask @ 0102cd24

void prttask(void)

{
  uint unaff_D7;
  undefined1 auStack_9e [154];
  
  chck_bid();
  init_trxd();
  prtinit();
  do {
    wtmsg();
    if (unaff_D7 != 0) {
      if ((unaff_D7 & 0x1f00) != 0) {
        tx_follow(unaff_D7 & 0x1f00);
      }
      if ((unaff_D7 & 0x1f0000) != 0) {
        rx_follow(unaff_D7 & 0x1f0000);
      }
    }
    remsg(auStack_9e);
    if (unaff_D7 == 0) {
      chckmail(auStack_9e);
    }
  } while( true );
}


// ==== init_trxd @ 0102cd9c

void init_trxd(void)

{
  int iVar1;
  undefined1 *puVar2;
  undefined1 *puVar3;
  
  iVar1 = 5;
  puVar2 = &Txdb;
  puVar3 = &Rxdb;
  do {
    *puVar3 = 0;
    puVar3[1] = 0;
    *puVar2 = 0;
    puVar2[1] = 0;
    *(undefined2 *)(puVar2 + 2) = 0;
    iVar1 = iVar1 + -1;
    puVar2 = puVar2 + 0x558;
    puVar3 = puVar3 + 8;
  } while (0 < iVar1);
  Pfifoin = &Rxfifo;
  Pfifoout = &Rxfifo;
  return;
}


// ==== chckmail @ 0102cde2

void chckmail(int param_1)

{
  int iVar1;
  char *pcVar2;
  
  iVar1 = 0x14;
  pcVar2 = &Detdb;
  do {
    if (*pcVar2 == *(char *)(param_1 + 8)) {
      (**(code **)(pcVar2 + 2))(param_1,*(undefined4 *)(pcVar2 + 6));
      return;
    }
    iVar1 = iVar1 + -1;
    pcVar2 = pcVar2 + 10;
  } while (0 < iVar1);
  return;
}


// ==== tx_follow @ 0102ce18

void tx_follow(uint param_1)

{
  int iVar1;
  uint *puVar2;
  
  puVar2 = &Fltxdb;
  iVar1 = 5;
  do {
    if ((int)param_1 < 1) {
      return;
    }
    if ((param_1 & *puVar2) != 0) {
      _tx_fllw(puVar2[1]);
    }
    param_1 = ~*puVar2 & param_1;
    iVar1 = iVar1 + -1;
    puVar2 = puVar2 + 2;
  } while (0 < iVar1);
  return;
}


// ==== _tx_fllw @ 0102ce5a

void _tx_fllw(int param_1)

{
  int iVar1;
  
  iVar1 = param_1 * 0x558;
  if ((&DAT_01050268)[param_1 * 0x2ac] == 0) {
    pend_tx((&Portdb)[param_1 * 2]);
    (&Txdb)[iVar1] = 0;
    **(undefined1 **)(&DAT_010507ba + iVar1) = 1;
    post((&DAT_01050267)[iVar1],4);
  }
  else {
    tx1line((&Portdb)[param_1 * 2],&Txdb + iVar1);
  }
  return;
}


// ==== rx_follow @ 0102cebe

void rx_follow(uint param_1)

{
  int iVar1;
  uint *puVar2;
  
  puVar2 = &Flrxdb;
  iVar1 = 5;
  do {
    if ((int)param_1 < 1) {
      return;
    }
    if ((param_1 & *puVar2) != 0) {
      _rx_fllw(puVar2[1]);
    }
    param_1 = ~*puVar2 & param_1;
    iVar1 = iVar1 + -1;
    puVar2 = puVar2 + 2;
  } while (0 < iVar1);
  return;
}


// ==== _rx_fllw @ 0102cf00

void _rx_fllw(int param_1)

{
  char cVar1;
  int iVar2;
  int unaff_D7;
  
  iVar2 = param_1 * 8;
  cVar1 = (&Rxdb)[iVar2];
  if (cVar1 == '\0') {
    *(undefined2 *)((&Portdb)[param_1 * 2] + 0x220) = 0;
  }
  else {
    tmpstore((&Portdb)[param_1 * 2],&Txdb + param_1 * 0x558);
    if (cVar1 != '\x03') {
      if (cVar1 == '\x01') {
        pull_rxfi(*(undefined4 *)(&DAT_01051d20 + iVar2));
        if (unaff_D7 != 1) {
          return;
        }
      }
      else {
        if (cVar1 != '\x02') {
          return;
        }
        pullsrxfi(*(undefined4 *)(&DAT_01051d20 + iVar2),(int)*(short *)(&DAT_01051d24 + iVar2));
        if (unaff_D7 == 0) {
          return;
        }
      }
      post((&DAT_01051d1f)[iVar2],4);
      (&Rxdb)[iVar2] = '\x03';
    }
  }
  return;
}


// ==== tmpstore @ 0102cfa6

void tmpstore(int param_1,undefined4 param_2)

{
  short sVar1;
  short sVar2;
  undefined *unaff_D7;
  
  sVar1 = *(short *)(param_1 + 0x220);
  if ((sVar1 != 0) && (chck_buf(Pfifoin,Pfifoout,(int)sVar1), unaff_D7 != (undefined *)0x0)) {
    sVar2 = 0;
    if (0 < sVar1) {
      do {
        *Pfifoin = *(undefined1 *)(sVar2 + param_1 + 0x222);
        inc_ptr(Pfifoin);
        sVar2 = sVar2 + 1;
        Pfifoin = unaff_D7;
      } while (sVar2 < sVar1);
    }
    *(undefined2 *)(param_1 + 0x220) = 0;
    send_xon(param_1,param_2);
  }
  return;
}


// ==== chck_buf @ 0102d024

void chck_buf(int param_1,int param_2,short param_3)

{
  int unaff_D7;
  int iVar1;
  
  iVar1 = (int)param_3;
  while ((0 < iVar1 && (inc_ptr(param_1), param_2 != unaff_D7))) {
    iVar1 = iVar1 + -1;
    param_1 = unaff_D7;
  }
  return;
}


// ==== stt_rx @ 0102d062

void stt_rx(int param_1,char *param_2)

{
  uint uVar1;
  byte bVar2;
  char *pcVar3;
  int iVar4;
  int unaff_D7;
  undefined1 *puVar5;
  uint **ppuVar6;
  uint *local_28;
  uint local_24;
  char *local_20;
  
  iVar4 = (int)param_2 * 8;
  uVar1 = (&Portdb)[(int)param_2 * 2];
  pcVar3 = &Txdb + (int)param_2 * 0x558;
  puVar5 = &Rxdb + iVar4;
  local_20 = *(char **)(param_1 + 0xe);
  local_24 = (uint)*(byte *)(param_1 + 2);
  local_28 = (uint *)0x102d0ae;
  latopa();
  *(int *)(param_1 + 0xe) = unaff_D7;
  local_28 = &Portdb + (int)param_2 * 2;
  set_patr(param_1);
  bVar2 = *(byte *)(param_1 + 2);
  local_20 = pcVar3;
  if (*(char *)(param_1 + 10) == '\x02') {
    if (*(short *)(uVar1 + 0x220) != 0) {
      local_28 = (uint *)0x102d0e6;
      local_24 = uVar1;
      tmpstore();
    }
    if (Pfifoin != Pfifoout) {
      local_20 = (char *)(int)*(short *)(param_1 + 0xc);
      local_24 = *(undefined4 *)(param_1 + 0xe);
      local_28 = (uint *)0x102d10c;
      pullsrxfi();
      if (unaff_D7 != 0) {
LAB_0102d168:
        local_20 = (char *)0x4;
        local_24 = (uint)bVar2;
        local_28 = (uint *)0x102d178;
        post();
        (&DAT_01051d1f)[iVar4] = bVar2;
        *puVar5 = 3;
        return;
      }
    }
    *(undefined4 *)(&DAT_01051d20 + iVar4) = *(undefined4 *)(param_1 + 0xe);
    *(undefined2 *)(&DAT_01051d24 + iVar4) = *(undefined2 *)(param_1 + 0xc);
LAB_0102d18c:
    (&DAT_01051d1f)[iVar4] = bVar2;
    *puVar5 = 1;
    return;
  }
  if (*(char *)(param_1 + 10) == '\x01') {
    if (*(short *)(uVar1 + 0x220) != 0) {
      local_28 = (uint *)0x102d142;
      local_24 = uVar1;
      tmpstore();
    }
    if (Pfifoin != Pfifoout) {
      local_20 = *(char **)(param_1 + 0xe);
      local_24 = 0x102d160;
      pull_rxfi();
      if (unaff_D7 == 1) goto LAB_0102d168;
    }
    *(undefined4 *)(&DAT_01051d20 + iVar4) = *(undefined4 *)(param_1 + 0xe);
    goto LAB_0102d18c;
  }
  if (*(char *)(param_1 + 10) != '\x03') {
    return;
  }
  if ((param_2 == (char *)0x0) || (Sio4bdin != '\0')) {
    if (*pcVar3 == '\0') {
      local_20 = param_2;
      local_24 = 0x102d1be;
      res_rxint();
    }
    else {
      local_20 = param_2;
      local_24 = 0x102d1ca;
      set_rxint();
      local_28 = (uint *)0x102d1d2;
      local_24 = uVar1;
      vac_rxbuf();
    }
    if ((char)*(undefined2 *)(uVar1 + 0x22) < '\0') {
      (&DAT_01051d1f)[iVar4] = bVar2;
      *puVar5 = 3;
      local_28 = (uint *)0x102d1ee;
      local_24 = uVar1;
      local_20 = pcVar3;
      send_xon();
      ppuVar6 = &local_28;
      local_28 = (uint *)0x1;
      goto LAB_0102d1f6;
    }
  }
  ppuVar6 = (uint **)&local_20;
  local_20 = (char *)0x0;
LAB_0102d1f6:
  *(int *)((int)ppuVar6 + -4) = param_1;
  *(undefined4 *)((int)ppuVar6 + -8) = 0x102d200;
  sd_crpost();
  return;
}


// ==== stop_rx @ 0102d20a

undefined1 stop_rx(int param_1,int param_2)

{
  undefined4 uVar1;
  undefined1 uVar2;
  undefined4 unaff_D7;
  
  uVar1 = (&Portdb)[param_2 * 2];
  if (*(int *)(param_1 + 0xe) != 0) {
    latopa(*(undefined1 *)(param_1 + 2),*(undefined4 *)(param_1 + 0xe));
    *(undefined4 *)(param_1 + 0xe) = unaff_D7;
  }
  set_patr(param_1,&Portdb + param_2 * 2);
  uVar2 = 0;
  if ((&Rxdb)[param_2 * 8] != '\0') {
    (&Rxdb)[param_2 * 8] = '\0';
    Pfifoin = &Rxfifo;
    Pfifoout = &Rxfifo;
    send_str(uVar1,&Txdb + param_2 * 0x558);
    pend_rxin(uVar1);
    uVar2 = vac_rxbuf(uVar1);
  }
  return uVar2;
}


// ==== set_patr @ 0102d2aa

void set_patr(int param_1,int param_2)

{
  if (*(short *)(param_1 + 0x12) != -1) {
    *(short *)(param_2 + 4) = *(short *)(param_1 + 0x12);
  }
  if (*(short *)(param_1 + 0x14) != -1) {
    *(short *)(param_2 + 6) = *(short *)(param_1 + 0x14);
  }
  return;
}


// ==== stt_tx @ 0102d2d6

void stt_tx(int param_1,int param_2)

{
  int iVar1;
  short sVar2;
  undefined4 unaff_D7;
  undefined4 uVar3;
  
  iVar1 = (&Portdb)[param_2 * 2];
  latopa(*(undefined1 *)(param_1 + 2),*(undefined4 *)(param_1 + 0x92));
  *(undefined4 *)(param_1 + 0x92) = unaff_D7;
  set_patt(param_1,&Portdb + param_2 * 2);
  if ((Sio4bdin != '\0') || (param_2 == 0)) {
    if ((&Rxdb)[param_2 * 8] == '\0') {
      res_txint(param_2);
    }
    else {
      set_txint(param_2);
    }
    (&Txdb)[param_2 * 0x558] = 0;
    sVar2 = 0x1900;
    do {
      sVar2 = sVar2 + -1;
    } while (0 < sVar2);
    sVar2 = 0x1900;
    do {
      if ((char)*(undefined2 *)(iVar1 + 0x22) < '\0') {
        uVar3 = 1;
        goto LAB_0102d386;
      }
      sVar2 = sVar2 + -1;
    } while (0 < sVar2);
  }
  uVar3 = 0;
LAB_0102d386:
  sd_trpost(param_1,uVar3);
  return;
}


// ==== exe_tx @ 0102d398

void exe_tx(int param_1,int param_2)

{
  short *psVar1;
  int iVar2;
  short sVar3;
  short sVar4;
  int iVar5;
  undefined4 unaff_D7;
  char *pcVar6;
  undefined4 uVar7;
  
  iVar2 = (&Portdb)[param_2 * 2];
  iVar5 = param_2 * 0x558;
  pcVar6 = &Txdb + iVar5;
  latopa(*(undefined1 *)(param_1 + 2),*(undefined4 *)(param_1 + 0x92));
  *(undefined4 *)(param_1 + 0x92) = unaff_D7;
  set_patt(param_1,&Portdb + param_2 * 2);
  if (((Sio4bdin == '\0') && (param_2 != 0)) || (-1 < (char)*(undefined2 *)(iVar2 + 0x22))) {
    uVar7 = 0;
  }
  else {
    sVar3 = *(short *)(param_1 + 10);
    if (sVar3 != 0) {
      sVar4 = (&DAT_01050268)[param_2 * 0x2ac];
      if (sVar4 < 10) {
        psVar1 = (short *)(iVar5 + 0x105026a + sVar4 * 0x88);
        cpybuf(param_1 + 0xc,psVar1 + 1,(int)sVar3);
        *psVar1 = sVar3;
        (&DAT_01050268)[param_2 * 0x2ac] = sVar4 + 1;
      }
      if (*pcVar6 == '\x01') {
        return;
      }
      *pcVar6 = '\x01';
      (&DAT_01050267)[iVar5] = *(undefined1 *)(param_1 + 2);
      *(undefined4 *)(&DAT_010507ba + iVar5) = *(undefined4 *)(param_1 + 0x92);
      set_txint(param_2);
      tx1line(iVar2,pcVar6);
      return;
    }
    uVar7 = 1;
  }
  sd_trpost(param_1,uVar7);
  return;
}


// ==== set_patt @ 0102d48e

void set_patt(int param_1,int param_2)

{
  if (*(short *)(param_1 + 0x96) != -1) {
    *(short *)(param_2 + 4) = *(short *)(param_1 + 0x96);
  }
  if (*(short *)(param_1 + 0x98) != -1) {
    *(short *)(param_2 + 6) = *(short *)(param_1 + 0x98);
  }
  return;
}


// ==== sd_trpost @ 0102d4ba

void sd_trpost(int param_1,undefined1 param_2)

{
  **(undefined1 **)(param_1 + 0x92) = param_2;
  post(*(undefined1 *)(param_1 + 2),4);
  return;
}


// ==== sd_crpost @ 0102d4e4

void sd_crpost(int param_1,undefined1 param_2)

{
  **(undefined1 **)(param_1 + 0xe) = param_2;
  post(*(undefined1 *)(param_1 + 2),4);
  return;
}


// ==== tx1line @ 0102d50e

void tx1line(undefined4 param_1,int param_2)

{
  tx_str(param_1,param_2 + 4);
  dec_tlbuf(param_2);
  return;
}


// ==== tx_str @ 0102d536

void tx_str(int param_1,short *param_2)

{
  short sVar1;
  
  sVar1 = *param_2;
  if (sVar1 != 0) {
    cpybuf(param_2 + 1,param_1 + 0x42,(int)sVar1);
    *(short *)(param_1 + 0x40) = sVar1;
  }
  return;
}


// ==== pend_tx @ 0102d570

void pend_tx(undefined2 *param_1)

{
  param_1[2] = param_1[2] | 0x200;
  if (param_1 == Portdb) {
    sioreset(param_1);
  }
  else {
    param_1[1] = 0;
    *param_1 = 2;
  }
  return;
}


// ==== set_txint @ 0102d5a2

void set_txint(int param_1)

{
  undefined2 *puVar1;
  ushort unaff_D7w;
  
  puVar1 = (undefined2 *)(&Portdb)[param_1 * 2];
  mkctlwd2(param_1);
  puVar1[2] = unaff_D7w | puVar1[2] & 0xd00;
  if (param_1 == 0) {
    sioreset(puVar1);
  }
  else {
    puVar1[1] = 0;
    *puVar1 = 2;
  }
  return;
}


// ==== res_txint @ 0102d5f0

void res_txint(int param_1)

{
  int iVar1;
  ushort unaff_D7w;
  
  iVar1 = (&Portdb)[param_1 * 2];
  mkctlwd2(param_1);
  *(ushort *)(iVar1 + 4) = unaff_D7w | *(ushort *)(iVar1 + 4) & 0xd00;
  sioreset(iVar1);
  return;
}


// ==== pend_rxin @ 0102d62a

void pend_rxin(undefined2 *param_1)

{
  param_1[2] = param_1[2] | 0x100;
  if (param_1 == Portdb) {
    sioreset(param_1);
  }
  else {
    param_1[1] = 0;
    *param_1 = 2;
  }
  return;
}


// ==== set_rxint @ 0102d65c

void set_rxint(int param_1)

{
  undefined2 *puVar1;
  ushort unaff_D7w;
  
  puVar1 = (undefined2 *)(&Portdb)[param_1 * 2];
  mkctlwd2(param_1);
  puVar1[2] = unaff_D7w | puVar1[2] & 0xa00;
  if (param_1 == 0) {
    sioreset(puVar1);
  }
  else {
    puVar1[1] = 0;
    *puVar1 = 2;
  }
  return;
}


// ==== res_rxint @ 0102d6aa

void res_rxint(int param_1)

{
  int iVar1;
  ushort unaff_D7w;
  
  iVar1 = (&Portdb)[param_1 * 2];
  mkctlwd2(param_1);
  *(ushort *)(iVar1 + 4) = unaff_D7w | *(ushort *)(iVar1 + 4) & 0xa00;
  sioreset(iVar1);
  return;
}


// ==== send_xon @ 0102d6e4

void send_xon(undefined4 param_1,undefined4 param_2)

{
  send1char(param_1,0x11,param_2);
  return;
}


// ==== send1char @ 0102d6fe

void send1char(undefined4 param_1,undefined1 param_2)

{
  undefined2 local_8c;
  undefined1 local_8a;
  
  local_8c = 1;
  local_8a = param_2;
  tx_str(param_1,&local_8c);
  return;
}


// ==== send_str @ 0102d722

void send_str(undefined4 param_1)

{
  undefined2 local_8c;
  undefined1 local_8a;
  undefined1 local_89;
  
  local_8c = 2;
  local_8a = 0x13;
  local_89 = 3;
  tx_str(param_1,&local_8c);
  return;
}


// ==== dec_tlbuf @ 0102d74a

void dec_tlbuf(int param_1)

{
  short sVar1;
  short *psVar2;
  short sVar3;
  
  psVar2 = (short *)(param_1 + 2);
  sVar1 = *psVar2;
  *psVar2 = *psVar2 + -1;
  if ((sVar1 != 0) && (sVar3 = 0, 0 < sVar1)) {
    do {
      cpybuf(param_1 + sVar3 * 0x88 + 0x8c,param_1 + 4 + sVar3 * 0x88,0x88);
      sVar3 = sVar3 + 1;
    } while (sVar3 < sVar1);
  }
  return;
}


// ==== pullsrxfi @ 0102d7a0

void pullsrxfi(undefined2 *param_1,short param_2)

{
  int iVar1;
  undefined2 *puVar2;
  int unaff_D7;
  
  puVar2 = param_1 + 1;
  iVar1 = 0;
  if (0 < param_2) {
    do {
      _pl_rxfif(puVar2);
      if (unaff_D7 == 0) break;
      puVar2 = (undefined2 *)((int)puVar2 + 1);
      iVar1 = iVar1 + 1;
    } while (iVar1 < param_2);
  }
  if (iVar1 != 0) {
    *param_1 = (short)iVar1;
  }
  return;
}


// ==== pull_rxfi @ 0102d7ec

void pull_rxfi(undefined2 *param_1)

{
  int unaff_D7;
  
  _pl_rxfif(param_1 + 1);
  if (unaff_D7 == 1) {
    *param_1 = 1;
  }
  return;
}


// ==== _pl_rxfif @ 0102d818

void _pl_rxfif(byte *param_1)

{
  byte bVar1;
  byte bVar2;
  undefined *unaff_D7;
  
  do {
    if (Pfifoin == Pfifoout) {
      return;
    }
    bVar1 = *Pfifoout;
    inc_ptr(Pfifoout);
    Pfifoout = unaff_D7;
  } while ((((bVar1 != 0) && (bVar2 = bVar1 & 0x7f, bVar2 < 0x20)) && (bVar2 != 0xd)) &&
          (bVar2 != 10));
  *param_1 = bVar1;
  return;
}


// ==== chck_bid @ 0102d87a

void chck_bid(void)

{
  int iVar1;
  int unaff_D7;
  int iVar2;
  
  iVar2 = 0xfff9000;
  iVar1 = 7;
  do {
    if (*(short *)(iVar2 + 0x3fe) == 0x100f) {
      DAT_0104ae0c = iVar2 + 0x400;
      DAT_0104ae14 = iVar2 + 0x800;
      DAT_0104ae24 = iVar2 + 0xc00;
      DAT_0104ae1c = iVar2;
      ttyinit();
      if (unaff_D7 == 1) {
        smcinit();
        ptpinit();
        auxinit();
        Sio4bdin = 1;
        return;
      }
    }
    iVar1 = iVar1 + -1;
    iVar2 = iVar2 + 0x1000;
  } while (0 < iVar1);
  Sio4bdin = 0;
  return;
}


// ==== inc_ptr @ 0102d91a

void inc_ptr(void)

{
  return;
}


// ==== vac_rxbuf @ 0102d93a

undefined2 vac_rxbuf(int param_1)

{
  short sVar1;
  
  do {
    if (*(short *)(param_1 + 0x220) == 0) {
      return 0;
    }
    *(undefined2 *)(param_1 + 0x220) = 0;
    sVar1 = 0x1900;
    do {
      if (*(short *)(param_1 + 0x220) != 0) break;
      sVar1 = sVar1 + -1;
    } while (sVar1 != 0);
  } while( true );
}


// ==== mkctlwd2 @ 0102d960

ushort mkctlwd2(int param_1)

{
  return *(ushort *)(&DAT_0104ae0a + param_1 * 8) | *(ushort *)(&DAT_0104ae08 + param_1 * 8);
}


// ==== _crtask @ 0102d980

ushort _crtask(int param_1)

{
  ushort *puVar1;
  ushort uVar2;
  undefined1 uVar3;
  byte bVar4;
  ushort *unaff_D7;
  undefined2 *puVar5;
  
  puVar1 = *(ushort **)(param_1 + 4);
  uVar2 = gettcb(*(undefined1 *)((int)puVar1 + 3));
  if (unaff_D7 != (ushort *)0xfffffffd) {
    uVar2 = *unaff_D7;
    if (uVar2 == 0) {
      uVar2 = *puVar1;
      if (((0x7fff < (uVar2 & 0x800f)) && ((uVar2 & 0x800f) < 0x8003)) &&
         (uVar2 = CONCAT11((char)(uVar2 >> 8),*(byte *)(puVar1 + 1)), *(byte *)(puVar1 + 1) < 8)) {
        *(undefined4 *)(unaff_D7 + 0x18) = *(undefined4 *)(puVar1 + 2);
        *(int *)(unaff_D7 + 0x1a) = *(int *)(puVar1 + 4) + -4;
        *unaff_D7 = *puVar1;
        *(undefined1 *)(unaff_D7 + 1) = *(undefined1 *)(puVar1 + 1);
        *(undefined1 *)((int)unaff_D7 + 3) = *(undefined1 *)((int)puVar1 + 3);
        if ((*puVar1 & 0x100) == 0) {
          *(char *)((int)unaff_D7 + 0x49) = (char)*(undefined4 *)(param_1 + 8);
          if (((&syspcb)[*(int *)(param_1 + 8) * 0x40] & 1) == 0) {
            uVar3 = 0;
          }
          else {
            uVar3 = 0x40;
          }
          *(undefined1 *)(unaff_D7 + 0x24) = uVar3;
          if (((&syspcb)[*(int *)(param_1 + 8) * 0x40] & 2) == 0) {
            bVar4 = 0;
          }
          else {
            bVar4 = 0x20;
          }
          *(byte *)(unaff_D7 + 0x24) = bVar4 | *(byte *)(unaff_D7 + 0x24);
        }
        else {
          *(char *)((int)unaff_D7 + 0x49) = (char)*(undefined4 *)(param_1 + 8);
          *(undefined1 *)(unaff_D7 + 0x24) = 0xe0;
        }
        uVar2 = setipc();
        if (unaff_D7 == (ushort *)0x0) {
          uRam00000000 = 0;
        }
        else {
          uVar2 = *puVar1;
          *unaff_D7 = uVar2;
          if ((uVar2 & 0x600) == 0) {
            unaff_D7[0x25] = 0;
            unaff_D7[0x26] = 0;
          }
          else {
            _saloc(0x180);
            *(ushort **)(unaff_D7 + 0x25) = unaff_D7;
            puVar5 = *(undefined2 **)(unaff_D7 + 0x25);
            if ((*unaff_D7 & 0x200) != 0) {
              uVar2 = 0;
              do {
                *(char *)(puVar5 + 1) = (char)uVar2;
                *puVar5 = *(undefined2 *)(&DAT_01051e8c + (uint)uVar2 * 2);
                *(undefined1 *)((int)puVar5 + 3) = 6;
                uVar2 = uVar2 + 1;
                puVar5 = puVar5 + 0xc;
              } while (uVar2 < 3);
            }
          }
          tlink();
          if ((*unaff_D7 & 0x800f) == 0x8002) {
            qin();
          }
          uVar2 = gecb(*(undefined1 *)((int)puVar1 + 3));
          unaff_D7[0] = 0;
          unaff_D7[1] = 0;
        }
      }
    }
  }
  return uVar2;
}


// ==== get_ssp @ 0102db1c

void get_ssp(byte param_1)

{
  *(uint *)(&DAT_0105276e + (uint)param_1 * 0xc0) = (uint)param_1 * 0xc0 + 0x1052772;
  return;
}


// ==== setipc @ 0102db44

void setipc(ushort *param_1,int param_2)

{
  int *unaff_D7;
  int *piVar1;
  
  if ((*param_1 & 0x100) == 0) {
    get_ssp(*(undefined1 *)((int)param_1 + 3));
    if (unaff_D7 == (int *)0x0) {
      return;
    }
    *(int **)(param_1 + 0x1c) = unaff_D7;
    *(undefined2 *)(unaff_D7 + 0x11) = 0;
    _ltopa(param_1,*(undefined4 *)(param_1 + 0x1a));
    piVar1 = unaff_D7;
  }
  else {
    _ltopa(param_1,*(undefined4 *)(param_1 + 0x1a));
    piVar1 = unaff_D7 + -0x12;
    *piVar1 = (int)(unaff_D7 + -0x11);
    *(int **)(param_1 + 0x1c) = piVar1;
    *(undefined2 *)(unaff_D7 + -1) = 0x2000;
  }
  *unaff_D7 = param_2;
  *(undefined4 *)((int)piVar1 + 0x46) = *(undefined4 *)(param_1 + 0x18);
  piVar1[0x10] = *(int *)(param_1 + 0x1a);
  *(undefined2 *)((int)piVar1 + 0x4a) = 0;
  return;
}


// ==== _detask @ 0102dbd0

void _detask(int param_1)

{
  int iVar1;
  ushort *unaff_D7;
  int iVar2;
  
  gettcb(*(undefined4 *)(param_1 + 4));
  if ((unaff_D7 != (ushort *)0xfffffffd) && ((*unaff_D7 & 0xf00f) == 0x8000)) {
    iVar2 = *(int *)(unaff_D7 + 0x25);
    if (iVar2 != 0) {
      iVar1 = 0;
      do {
        if (*(int *)(iVar2 + 0x10) != 0) {
          _sfre(*(undefined4 *)(iVar2 + 0x10));
          *(undefined4 *)(iVar2 + 0x10) = 0;
        }
        iVar2 = iVar2 + 0x18;
        iVar1 = iVar1 + 1;
      } while (iVar1 < 0x10);
      _sfre(*(undefined4 *)(unaff_D7 + 0x25));
      unaff_D7[0x25] = 0;
      unaff_D7[0x26] = 0;
    }
    gecb(*(undefined4 *)(param_1 + 4));
    unaff_D7[0] = 0;
    unaff_D7[1] = 0;
    *unaff_D7 = 0;
  }
  return;
}


// ==== _start @ 0102dc5c

void _start(int param_1)

{
  ushort uVar1;
  ushort *unaff_D7;
  
  gettcb(*(undefined4 *)(param_1 + 8));
  if (((unaff_D7 != (ushort *)0xfffffffd) && (uVar1 = *unaff_D7 & 0x800f, uVar1 != 0x8000)) &&
     (uVar1 != 0)) {
    if (uVar1 == 0x8001) {
      setipc();
      callnset();
      qin();
    }
    else if (*(int *)(param_1 + 4) != 1) {
      *(undefined4 *)(unaff_D7 + 0x20) = *(undefined4 *)(param_1 + 0xc);
      *(undefined4 *)(unaff_D7 + 0x22) = etcb;
      *unaff_D7 = *unaff_D7 | 0x40;
    }
  }
  return;
}


// ==== _stop @ 0102dcea

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void _stop(void)

{
  ushort *puVar1;
  
  tlkoff(etcb);
  puVar1 = etcb;
  if ((*etcb & 0x40) == 0) {
    *etcb = *etcb & 0x720 | 0x8001;
  }
  else {
    *etcb = *etcb & 0xffbf;
    setipc(puVar1,*(undefined4 *)(puVar1 + 0x20));
    callnset(etcb,*(undefined4 *)(etcb + 0x22));
    qin(etcb);
  }
  mflag = 0;
  __svstk = 0;
  return;
}


// ==== _abort @ 0102dd62

void _abort(int param_1)

{
  ushort *unaff_D7;
  int unaff_A6;
  
  if (*(int *)(param_1 + 4) == 0) {
    mflag = 0;
    unaff_D7 = etcb;
  }
  else {
    gettcb(*(undefined4 *)(param_1 + 4));
    if (unaff_D7 == (ushort *)0xfffffffd) {
      return;
    }
    if (*unaff_D7 == 0) {
      return;
    }
    if ((*unaff_D7 & 0xf00f) == 0x8000) {
      return;
    }
  }
  kill((__pid_t)unaff_D7,unaff_A6);
  return;
}


// ==== kill @ 0102ddb6

int kill(__pid_t __pid,int __sig)

{
  int iVar1;
  undefined2 extraout_D0u;
  undefined2 extraout_D0u_00;
  undefined2 uVar2;
  uint uVar3;
  int unaff_D3;
  undefined4 *unaff_D7;
  int iVar4;
  
  tlkoff(__pid);
  iVar4 = __pid;
  while (iVar4 = *(int *)(iVar4 + 0x1c), iVar4 != 0) {
    kill(iVar4,unaff_D3);
  }
  *(undefined4 *)(__pid + 0x1c) = 0;
  if ((*(ushort *)__pid & 0xf00f) == 0x8002) {
    qout(__pid);
  }
  gecb(*(undefined1 *)(__pid + 3));
  do {
    can_ft();
  } while (unaff_D7 == (undefined4 *)0x0);
  *unaff_D7 = 0;
  iVar4 = *(int *)(__pid + 0x10);
  uVar2 = extraout_D0u;
  if (iVar4 != 0) {
    do {
      iVar1 = *(int *)(iVar4 + 4);
      _sfre(iVar4);
      iVar4 = iVar1;
    } while (iVar1 != 0);
    *(undefined4 *)(__pid + 0x10) = 0;
    *(undefined4 *)(__pid + 0x14) = 0;
    uVar2 = extraout_D0u_00;
  }
  uVar3 = CONCAT22(uVar2,*(undefined2 *)__pid) & 0xffff0720 | 0x8010;
  *(short *)__pid = (short)uVar3;
  return uVar3;
}


// ==== _release @ 0102de5c

void _release(int param_1)

{
  ushort *unaff_D7;
  
  gettcb(*(undefined4 *)(param_1 + 4));
  if ((unaff_D7 != (ushort *)0xfffffffd) && ((*unaff_D7 & 0xf00f) == 0x8000)) {
    *unaff_D7 = *unaff_D7 & 0x720 | 0x8001;
  }
  return;
}


// ==== _retun @ 0102de9c

void _retun(undefined4 param_1,undefined4 param_2)

{
  int iVar1;
  
  iVar1 = etcb;
  *(undefined4 *)(etcb + 0x38) = param_2;
  qin(iVar1);
  mflag = 0;
  return;
}


// ==== _wait @ 0102dec0

uint _wait(int param_1,int param_2)

{
  int iVar1;
  undefined4 *puVar2;
  ushort *puVar3;
  uint uVar4;
  uint *unaff_D7;
  
  puVar3 = etcb;
  if (*(int *)(param_1 + 4) == 0) {
    uVar4 = (uint)*(byte *)((int)etcb + 3);
  }
  else {
    uVar4 = *(uint *)(param_1 + 4);
  }
  uVar4 = gecb(uVar4);
  if ((unaff_D7 != (uint *)0xfffffffc) && (uVar4 = *unaff_D7, -1 < (int)uVar4)) {
    if (*unaff_D7 == 0) {
      *unaff_D7 = 0x80000000;
      *(ushort **)((int)unaff_D7 + 6) = puVar3;
      iVar1 = *(int *)(param_1 + 8);
      *(int *)((int)unaff_D7 + 0xe) = iVar1;
      if (iVar1 == 0) {
        *(undefined1 *)(unaff_D7 + 1) = 0;
      }
      else {
        *(undefined1 *)(unaff_D7 + 1) = 1;
        if (DAT_01075250 == (uint *)0x0) {
          t0_lcb = unaff_D7;
          DAT_01075250 = unaff_D7;
        }
        else {
          puVar2 = (undefined4 *)((int)DAT_01075250 + 10);
          DAT_01075250 = unaff_D7;
          *puVar2 = unaff_D7;
        }
        *(undefined4 *)((int)unaff_D7 + 10) = 0;
      }
      *(int *)(puVar3 + 0x1c) = param_2;
      if (*(int *)(param_2 + 4) == 0xc) {
        uVar4 = *puVar3 & 0xfffffff0 | 0x8005;
      }
      else {
        uVar4 = CONCAT22((short)((uint)*(int *)(param_2 + 4) >> 0x10),*puVar3) & 0xfffffff0 | 0x8003
        ;
      }
      *puVar3 = (ushort)uVar4;
      mflag = 0;
    }
    else {
      uVar4 = 0;
      if (*(int *)((int)unaff_D7 + 0xe) != 0) {
        *(undefined4 *)((int)unaff_D7 + 0xe) = 0;
        uVar4 = tqout();
      }
      *unaff_D7 = 0;
      puVar3[6] = 0;
      puVar3[7] = 0;
    }
  }
  return uVar4;
}


// ==== _post @ 0102dfb2

void _post(int param_1)

{
  int iVar1;
  uint uVar2;
  uint *unaff_D7;
  
  if (*(int *)(param_1 + 4) == 0) {
    uVar2 = (uint)*(byte *)(*(int *)(etcb + 0x3c) + 3);
  }
  else {
    uVar2 = *(uint *)(param_1 + 4);
  }
  gecb(uVar2);
  if ((unaff_D7 != (uint *)0xfffffffc) &&
     (*unaff_D7 = *unaff_D7 | *(uint *)(param_1 + 8) & 0x7fffffff, (int)*unaff_D7 < 0)) {
    iVar1 = *(int *)((int)unaff_D7 + 6);
    if (*(int *)((int)unaff_D7 + 0xe) != 0) {
      tqout();
    }
    *(uint *)(*(int *)(iVar1 + 0x38) + 0x20) = *unaff_D7 & 0x7fffffff;
    *unaff_D7 = 0;
    qin(iVar1);
  }
  return;
}


// ==== _clrecb @ 0102e048

void _clrecb(int param_1)

{
  uint uVar1;
  uint *unaff_D7;
  
  if (*(int *)(param_1 + 4) == 0) {
    uVar1 = (uint)*(byte *)(etcb + 3);
  }
  else {
    uVar1 = *(uint *)(param_1 + 4);
  }
  gecb(uVar1);
  if (unaff_D7 != (uint *)0xfffffffc) {
    *unaff_D7 = *unaff_D7 & ~*(uint *)(param_1 + 8);
  }
  return;
}


// ==== _enq @ 0102e096

void _enq(int param_1,undefined4 param_2)

{
  int iVar1;
  ushort *puVar2;
  ushort *puVar3;
  ushort *unaff_D7;
  
  if (*(int *)(param_1 + 8) == 0xff) {
    unaff_D7 = &rcbm;
  }
  else {
    getrcb(*(undefined4 *)(param_1 + 8));
    if (unaff_D7 == (ushort *)0xfffffffa) {
      return;
    }
  }
  if (*unaff_D7 == 0) {
    if (*(int *)(param_1 + 4) != 2) {
      *unaff_D7 = 1;
      *(char *)(unaff_D7 + 1) = (char)*(undefined4 *)(param_1 + 8);
      puVar2 = etcb;
      *(undefined1 *)((int)unaff_D7 + 3) = *(undefined1 *)((int)etcb + 3);
      puVar3 = etcb;
      iVar1 = *(int *)(puVar2 + 0x16);
      if (iVar1 == 0) {
        *(ushort **)(etcb + 0x14) = unaff_D7;
        *(ushort **)(puVar3 + 0x16) = unaff_D7;
      }
      else {
        *(ushort **)(puVar2 + 0x16) = unaff_D7;
        *(ushort **)(iVar1 + 4) = unaff_D7;
      }
      unaff_D7[2] = 0;
      unaff_D7[3] = 0;
    }
  }
  else if ((*(char *)((int)etcb + 3) != *(char *)((int)unaff_D7 + 3)) &&
          ((*(int *)(param_1 + 4) == 0 || (*(int *)(param_1 + 4) == 4)))) {
    *unaff_D7 = *unaff_D7 | 0x8000;
    puVar2 = etcb;
    iVar1 = *(int *)(unaff_D7 + 6);
    if (iVar1 == 0) {
      *(ushort **)(unaff_D7 + 4) = etcb;
      *(ushort **)(unaff_D7 + 6) = puVar2;
    }
    else {
      *(ushort **)(unaff_D7 + 6) = etcb;
      *(ushort **)(iVar1 + 0x24) = puVar2;
    }
    puVar2 = etcb;
    puVar2[0x12] = 0;
    puVar3 = etcb;
    puVar2[0x13] = 0;
    if (*(int *)(param_1 + 4) == 4) {
      *(undefined4 *)(param_1 + 8) = 0;
      *(undefined4 *)(param_1 + 4) = 0;
      _wait(param_1,param_2);
    }
    else {
      *etcb = *etcb & 0xfff0 | 0x8006;
      *(undefined4 *)(puVar3 + 0x1c) = param_2;
      mflag = 0;
    }
  }
  return;
}


// ==== _denq @ 0102e1d0

void _denq(int param_1)

{
  uint uVar1;
  uint uVar2;
  int iVar3;
  uint *unaff_D7;
  uint *puVar4;
  uint *puVar5;
  
  if (*(int *)(param_1 + 4) == 0xff) {
    puVar5 = (uint *)&rcbm;
  }
  else {
    getrcb(*(undefined4 *)(param_1 + 4));
    puVar5 = unaff_D7;
    if (unaff_D7 == (uint *)0xfffffffa) {
      return;
    }
  }
  iVar3 = etcb;
  if (((*puVar5 & 0x10000) != 0) && (*(char *)(etcb + 3) == (char)*puVar5)) {
    puVar4 = *(uint **)(etcb + 0x28);
    if (puVar5 == puVar4) {
      uVar1 = puVar5[1];
      *(uint *)(etcb + 0x28) = uVar1;
      if (uVar1 == 0) {
        *(undefined4 *)(iVar3 + 0x2c) = 0;
      }
    }
    else {
      for (; (uint *)puVar4[1] != puVar5; puVar4 = (uint *)puVar4[1]) {
      }
      uVar1 = puVar5[1];
      puVar4[1] = uVar1;
      if (uVar1 == 0) {
        *(uint **)(etcb + 0x2c) = puVar4;
      }
    }
    if (*(short *)puVar5 < 0) {
      uVar1 = puVar5[2];
      uVar2 = *(uint *)(uVar1 + 0x24);
      puVar5[2] = uVar2;
      if (uVar2 == 0) {
        puVar5[3] = 0;
        *(ushort *)puVar5 = *(ushort *)puVar5 & 0x7fff;
      }
      iVar3 = *(int *)(uVar1 + 0x2c);
      if (iVar3 == 0) {
        *(uint **)(uVar1 + 0x2c) = puVar5;
        *(uint **)(uVar1 + 0x28) = puVar5;
      }
      else {
        *(uint **)(uVar1 + 0x2c) = puVar5;
        *(uint **)(iVar3 + 4) = puVar5;
      }
      puVar5[1] = 0;
      *(undefined1 *)((int)puVar5 + 3) = *(undefined1 *)(uVar1 + 3);
      gecb(*(undefined1 *)(uVar1 + 3));
      if ((int)*unaff_D7 < 0) {
        *(uint *)(*(int *)(uVar1 + 0x38) + 0x20) = *unaff_D7 & 0x7fffffff;
        *unaff_D7 = 0;
      }
      else {
        *(undefined4 *)(*(int *)(uVar1 + 0x38) + 0x20) = 0;
      }
      qin(uVar1);
    }
    else {
      *(undefined2 *)puVar5 = 0;
    }
  }
  return;
}


// ==== c_semsg @ 0102e2f4

void c_semsg(int param_1,undefined1 param_2)

{
  uint uVar1;
  uint *unaff_D7;
  
  gettcb(*(undefined4 *)(param_1 + 8));
  if ((((unaff_D7 != (uint *)0xfffffffd) && (0x8001 < (*(ushort *)unaff_D7 & 0xf00f))) &&
      ((*(ushort *)unaff_D7 & 0xf00f) < 0x8010)) && ((*unaff_D7 & 0x200000) != 0)) {
    uVar1 = *(uint *)(param_1 + 4);
    _salocnf((uVar1 & 0xffff) + 8);
    if (unaff_D7 != (uint *)0x0) {
      *(char *)((int)unaff_D7 + 3) = (char)*(undefined4 *)(param_1 + 8);
      *(undefined1 *)((int)unaff_D7 + 2) = param_2;
      *(short *)unaff_D7 = (short)uVar1;
      c_copy(unaff_D7 + 2,*(undefined4 *)(param_1 + 0xc),uVar1 & 0xffff);
      uVar1 = unaff_D7[5];
      if (uVar1 == 0) {
        unaff_D7[4] = (uint)unaff_D7;
        unaff_D7[5] = (uint)unaff_D7;
      }
      else {
        unaff_D7[5] = (uint)unaff_D7;
        *(uint **)(uVar1 + 4) = unaff_D7;
      }
      unaff_D7[1] = 0;
      gecb((char)*unaff_D7);
      if ((int)*unaff_D7 < 0) {
        if (*(int *)((int)unaff_D7 + 0xe) != 0) {
          tqout();
        }
        *(uint *)(unaff_D7[0xe] + 0x20) = *unaff_D7 & 0x7fffffff;
        *unaff_D7 = 0;
        qin();
      }
    }
  }
  return;
}


// ==== _semsg @ 0102e406

void _semsg(undefined4 param_1)

{
  c_semsg(param_1,*(undefined1 *)(etcb + 3));
  return;
}


// ==== i_semsg @ 0102e428

void i_semsg(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  undefined1 auStack_14 [4];
  undefined4 local_10;
  undefined4 local_c;
  undefined4 local_8;
  
  _mskon();
  local_c = param_2;
  local_10 = param_4;
  local_8 = param_3;
  c_semsg(auStack_14,param_1);
  _mskoff();
  return;
}


// ==== _wtmsg @ 0102e466

uint _wtmsg(undefined4 param_1,undefined4 param_2)

{
  ushort *puVar1;
  uint uVar2;
  uint *unaff_D7;
  undefined1 auStack_10 [4];
  undefined4 local_c;
  undefined4 local_8;
  
  puVar1 = etcb;
  uVar2 = (uint)*etcb;
  if ((((*etcb & 0x20) != 0) &&
      (uVar2 = gecb(*(undefined1 *)((int)etcb + 3)), unaff_D7 != (uint *)0xfffffffc)) &&
     (uVar2 = *unaff_D7, -1 < (int)uVar2)) {
    if (*unaff_D7 == 0) {
      uVar2 = *(uint *)(etcb + 8);
      if (uVar2 == 0) {
        local_c = 0;
        local_8 = 0;
        uVar2 = _wait(auStack_10,param_2);
      }
    }
    else {
      uVar2 = 0;
      if (*(int *)((int)unaff_D7 + 0xe) != 0) {
        *(undefined4 *)((int)unaff_D7 + 0xe) = 0;
        uVar2 = tqout();
      }
      *unaff_D7 = 0;
      puVar1[6] = 0;
      puVar1[7] = 0;
    }
  }
  return uVar2;
}


// ==== _remsg @ 0102e500

void _remsg(int param_1)

{
  ushort *puVar1;
  int iVar2;
  ushort *puVar3;
  
  if (((*etcb & 0x20) != 0) && (puVar1 = *(ushort **)(etcb + 8), puVar1 != (ushort *)0x0)) {
    c_copy(*(undefined4 *)(param_1 + 4),puVar1,*puVar1 + 8);
    puVar3 = etcb;
    iVar2 = *(int *)(puVar1 + 2);
    *(int *)(etcb + 8) = iVar2;
    if (iVar2 == 0) {
      puVar3[10] = 0;
      puVar3[0xb] = 0;
    }
    _sfre(puVar1);
  }
  return;
}


// ==== p_remsg @ 0102e570

void p_remsg(void)

{
  int iVar1;
  ushort *puVar2;
  
  puVar2 = etcb;
  if ((((*etcb & 0x20) != 0) && (*(int *)(etcb + 8) != 0)) &&
     (iVar1 = *(int *)(*(int *)(etcb + 8) + 4), *(int *)(etcb + 8) = iVar1, iVar1 == 0)) {
    puVar2[10] = 0;
    puVar2[0xb] = 0;
  }
  return;
}


// ==== _chmsgq @ 0102e5a2

void _chmsgq(int param_1)

{
  uint uVar1;
  int iVar2;
  ushort *puVar3;
  int iVar4;
  
  uVar1 = *(uint *)(param_1 + 4);
  if (((uVar1 & 1) == 0) || ((uVar1 & 8) != 0)) {
    if ((*etcb & 0x20) == 0) {
      return;
    }
    if (((uVar1 & 8) != 0) && (iVar4 = *(int *)(etcb + 8), iVar4 != 0)) {
      do {
        iVar2 = *(int *)(iVar4 + 4);
        _sfre(iVar4);
        iVar4 = iVar2;
      } while (iVar2 != 0);
      puVar3 = etcb;
      puVar3[8] = 0;
      puVar3[9] = 0;
      puVar3[10] = 0;
      puVar3[0xb] = 0;
    }
  }
  puVar3 = etcb;
  *etcb = *etcb & 0xffdf;
  *puVar3 = *puVar3 | ((ushort)uVar1 & 1) << 5;
  return;
}


// ==== _irqvct @ 0102e632

void _irqvct(int param_1)

{
  int iVar1;
  
  iVar1 = *(int *)(param_1 + 4);
  if ((((iVar1 < 0x100) && ((iVar1 < 0x10 || (0x17 < iVar1)))) && ((iVar1 < 0x3b || (0x3f < iVar1)))
      ) && (iVar1 != 1)) {
    *(undefined4 *)(&_ivvct + iVar1 * 4) = *(undefined4 *)(param_1 + 8);
  }
  return;
}


// ==== _itrpvct @ 0102e67a

void _itrpvct(int param_1)

{
  if (*(int *)(param_1 + 4) < 0x20) {
    *(undefined4 *)(&drvtbl + *(int *)(param_1 + 4) * 4) = *(undefined4 *)(param_1 + 8);
  }
  return;
}


// ==== qin @ 0102e6a6

void qin(ushort *param_1)

{
  int iVar1;
  
  iVar1 = (uint)*(byte *)(param_1 + 1) * 8;
  if (*(int *)(&DAT_01057f7c + iVar1) == 0) {
    *(ushort **)(&DAT_01057f7c + iVar1) = param_1;
    *(ushort **)(&lcb + iVar1) = param_1;
  }
  else {
    *(ushort **)(*(int *)(&DAT_01057f7c + iVar1) + 4) = param_1;
    *(ushort **)(&DAT_01057f7c + iVar1) = param_1;
  }
  *param_1 = *param_1 & 0xfff0 | 0x8002;
  param_1[2] = 0;
  param_1[3] = 0;
  return;
}


// ==== qout @ 0102e6ee

int qout(int param_1)

{
  int iVar1;
  int iVar2;
  int iVar3;
  int *piVar4;
  
  iVar1 = (uint)*(byte *)(param_1 + 2) * 8;
  piVar4 = (int *)(&lcb + iVar1);
  iVar2 = 0;
  if (*piVar4 != 0) {
    iVar3 = *piVar4;
    if (param_1 == iVar3) {
      iVar2 = *(int *)(param_1 + 4);
      *piVar4 = iVar2;
      if (iVar2 == 0) {
        *(undefined4 *)(&DAT_01057f7c + iVar1) = 0;
      }
    }
    else {
      do {
        iVar2 = *(int *)(iVar3 + 4);
        if (iVar2 == param_1) {
          iVar2 = *(int *)(param_1 + 4);
          *(int *)(iVar3 + 4) = iVar2;
          if (iVar2 == 0) {
            *(int *)(&DAT_01057f7c + iVar1) = iVar3;
            return 0;
          }
          return iVar2;
        }
        iVar3 = *(int *)(iVar3 + 4);
      } while (iVar3 != 0);
    }
  }
  return iVar2;
}


// ==== tlink @ 0102e742

void tlink(int param_1,int param_2)

{
  int iVar1;
  uint *unaff_D7;
  
  *(int *)(param_1 + 0x3c) = param_2;
  iVar1 = *(int *)(param_2 + 0x20);
  if (iVar1 == 0) {
    *(int *)(param_2 + 0x1c) = param_1;
    *(int *)(param_2 + 0x20) = param_1;
  }
  else {
    *(int *)(param_2 + 0x20) = param_1;
    *(int *)(iVar1 + 0x18) = param_1;
  }
  *(undefined4 *)(param_1 + 0x18) = 0;
  gecb(*(undefined1 *)(param_1 + 3));
  *unaff_D7 = *unaff_D7 & 0x7fffffff;
  return;
}


// ==== callnset @ 0102e790

void callnset(int param_1,undefined4 param_2)

{
  uint *unaff_D7;
  
  *(undefined4 *)(param_1 + 0x3c) = param_2;
  gecb(*(undefined1 *)(param_1 + 3));
  *unaff_D7 = *unaff_D7 & 0x7fffffff;
  return;
}


// ==== tlkoff @ 0102e7be

void tlkoff(int param_1)

{
  int iVar1;
  ushort *puVar2;
  int iVar3;
  int iVar4;
  
  iVar4 = *(int *)(param_1 + 0x3c);
  if (iVar4 != 0) {
    iVar3 = *(int *)(iVar4 + 0x1c);
    if (iVar3 == param_1) {
      iVar3 = *(int *)(param_1 + 0x18);
      *(int *)(iVar4 + 0x1c) = iVar3;
      if (iVar3 == 0) {
        *(undefined4 *)(iVar4 + 0x20) = 0;
      }
    }
    else {
      if (iVar3 == 0) {
        return;
      }
      for (; (*(int *)(iVar3 + 0x18) != param_1 && (*(int *)(iVar3 + 0x18) != 0));
          iVar3 = *(int *)(iVar3 + 0x18)) {
      }
      if ((*(int *)(iVar3 + 0x18) != 0) &&
         (iVar1 = *(int *)(param_1 + 0x18), *(int *)(iVar3 + 0x18) = iVar1, iVar1 == 0)) {
        *(int *)(iVar4 + 0x20) = iVar3;
      }
    }
  }
  do {
    puVar2 = *(ushort **)(param_1 + 0x28);
    if (puVar2 == (ushort *)0x0) {
LAB_0102e8cc:
      *(undefined4 *)(param_1 + 0x2c) = 0;
      return;
    }
    if (*(char *)((int)puVar2 + 3) != *(char *)(param_1 + 3)) {
      iVar4 = *(int *)(puVar2 + 4);
      if (iVar4 == param_1) {
        iVar4 = *(int *)(param_1 + 0x24);
        *(int *)(puVar2 + 4) = iVar4;
        if (iVar4 == 0) {
          puVar2[6] = 0;
          puVar2[7] = 0;
          *puVar2 = *puVar2 & 0x7fff;
        }
      }
      else {
        for (; *(int *)(iVar4 + 0x24) != param_1; iVar4 = *(int *)(iVar4 + 0x24)) {
        }
        iVar3 = *(int *)(param_1 + 0x24);
        *(int *)(iVar4 + 0x24) = iVar3;
        if (iVar3 == 0) {
          *(int *)(puVar2 + 6) = iVar4;
        }
      }
      goto LAB_0102e8cc;
    }
    *(undefined4 *)(param_1 + 0x28) = *(undefined4 *)(puVar2 + 2);
    if ((short)*puVar2 < 0) {
      iVar4 = *(int *)(puVar2 + 4);
      *(undefined1 *)((int)puVar2 + 3) = *(undefined1 *)(iVar4 + 3);
      *(undefined4 *)(*(int *)(iVar4 + 0x38) + 0x20) = 0;
      iVar3 = *(int *)(iVar4 + 0x2c);
      if (iVar3 == 0) {
        *(ushort **)(iVar4 + 0x2c) = puVar2;
        *(ushort **)(iVar4 + 0x28) = puVar2;
      }
      else {
        *(ushort **)(iVar4 + 0x2c) = puVar2;
        *(ushort **)(iVar3 + 4) = puVar2;
      }
      puVar2[2] = 0;
      puVar2[3] = 0;
      qin(iVar4);
      *puVar2 = 0x8001;
    }
    else {
      *puVar2 = 0;
      puVar2[2] = 0;
      puVar2[3] = 0;
    }
  } while( true );
}


// ==== _swpeek @ 0102e8da

void _swpeek(void)

{
  return;
}


// ==== _sbpeek @ 0102e8f0

undefined1 _sbpeek(int param_1)

{
  return **(undefined1 **)(param_1 + 4);
}


// ==== _swpoke @ 0102e906

void _swpoke(int param_1)

{
  **(undefined2 **)(param_1 + 4) = (short)*(undefined4 *)(param_1 + 8);
  return;
}


// ==== _sbpoke @ 0102e920

void _sbpoke(int param_1)

{
  **(undefined1 **)(param_1 + 4) = (char)*(undefined4 *)(param_1 + 8);
  return;
}


// ==== _slpeek @ 0102e93a

void _slpeek(void)

{
  return;
}


// ==== _slpoke @ 0102e94c

void _slpoke(int param_1)

{
  **(undefined4 **)(param_1 + 4) = *(undefined4 *)(param_1 + 8);
  return;
}


// ==== _gtcb @ 0102e962

void _gtcb(void)

{
  return;
}


// ==== _gettin @ 0102e998

void _gettin(void)

{
  return;
}


// ==== _puttin @ 0102e9a2

void _puttin(void)

{
  return;
}


// ==== sduman @ 0102e9ac

void sduman(void)

{
  undefined2 *puVar1;
  int iVar2;
  int unaff_D7;
  undefined1 auStack_110 [2];
  undefined1 local_10e;
  undefined1 local_106;
  undefined2 *local_da;
  
  init_grb();
  do {
    if (wait_skp == -1) {
      swret = 0xc0;
    }
    else {
      sdu_wait(auStack_110);
      swret = unaff_D7;
    }
    iVar2 = f_tcb * 0x34;
    if (swret == 1) {
      sm_prcrq(auStack_110);
      if (unaff_D7 == -1) {
        f_pno = 0;
        f_mode = 0;
        *local_da = 0xffbf;
        *(undefined1 *)((int)local_da + 3) = local_106;
        post(local_10e,0x4000000);
      }
LAB_0102ea54:
      sm_prcdo(auStack_110);
    }
    else {
      if (swret == 0xc0) goto LAB_0102ea54;
      (&sdutcb)[f_tcb * 0x34] = 0;
      f_pno = 0;
      f_mode = 0;
      puVar1 = *(undefined2 **)(&DAT_01078664 + iVar2);
      *puVar1 = 0xffc4;
      *(undefined *)((int)puVar1 + 3) = (&DAT_01078638)[iVar2];
      ret_drv(*(undefined4 *)(&DAT_01078664 + iVar2));
      post((&DAT_01078635)[iVar2],0x4000000);
    }
    smp_req();
  } while( true );
}


// ==== init_grb @ 0102eac8

void init_grb(void)

{
  int iVar1;
  
  port_no = 0;
  f_reset = 0xffffffff;
  f_pno = 0;
  f_tcb = 0;
  f_mode = 0;
  f_sp = 0;
  f_type = 0;
  f_wp = 0;
  f_rp = 0;
  f_bc = 0;
  spl_rp = 0;
  spl_wp = 0;
  spl_full = 0;
  wait_skp = 0;
  ng_flg = 0;
  iVar1 = 0;
  do {
    (&file_tp)[iVar1] = 0;
    (&file_cp)[iVar1] = 0;
    (&wmark)[iVar1] = 0;
    (&wflash)[iVar1] = 0;
    iVar1 = iVar1 + 1;
  } while (iVar1 < 8);
  iVar1 = 0;
  do {
    (&tbl_tno)[iVar1] = 0;
    iVar1 = iVar1 + 1;
  } while (iVar1 < 0x40);
  iVar1 = 0;
  do {
    (&sdutcb)[iVar1 * 0x34] = 0;
    iVar1 = iVar1 + 1;
  } while (iVar1 < 6);
  iVar1 = 0;
  do {
    (&used_fcb)[iVar1] = 0;
    iVar1 = iVar1 + 1;
  } while (iVar1 < 8);
  init_wait();
  return;
}


// ==== day_tim @ 0102ebac

void day_tim(undefined4 param_1)

{
  int iVar1;
  int iVar2;
  int unaff_D7;
  undefined1 auStack_114 [4];
  undefined1 auStack_110 [8];
  char local_108;
  
  iVar1 = 0;
  iVar2 = -1;
  while( true ) {
    alarm(9);
    devtrp(0xd,(port_no + 0xc0) * 0x100 | 0x10006,param_1,auStack_114);
    if (unaff_D7 != 0) {
      wtmsg();
      if (unaff_D7 == 0) {
        remsg(auStack_110);
        if (local_108 == '\x04') {
          iVar2 = 0;
        }
      }
    }
    can_alrm();
    if ((iVar2 == 0) || (iVar1 == 10)) break;
    iVar1 = iVar1 + 1;
  }
  return;
}


// ==== date_set @ 0102ec36

void date_set(undefined1 *param_1)

{
  int iVar1;
  char local_c;
  char local_b;
  char local_a;
  char local_9;
  
  redwat(&local_c);
  *param_1 = 2;
  param_1[1] = 7;
  param_1[2] = 0x20;
  param_1[3] = 1;
  param_1[4] = 0;
  param_1[5] = (char)((int)(short)local_9 % 10) + (char)((int)(short)local_9 / 10) * '\x10';
  if (local_c < 'P') {
    iVar1 = 0x14;
  }
  else {
    iVar1 = -0x50;
  }
  param_1[6] = (char)((iVar1 + local_c) % 10) + (char)((iVar1 + local_c) / 10 << 4);
  param_1[7] = (char)((int)(short)local_b % 10) + (char)((int)(short)local_b / 10) * '\x10';
  param_1[8] = (char)((int)(short)local_a % 10) + (char)((int)(short)local_a / 10) * '\x10';
  setcrcs(param_1 + 1,0,0,0);
  return;
}


// ==== time_set @ 0102ed0e

void time_set(undefined1 *param_1)

{
  undefined1 auStack_c [4];
  char local_8;
  char local_7;
  char local_6;
  
  redwat(auStack_c);
  *param_1 = 2;
  param_1[1] = 6;
  param_1[2] = 0x20;
  param_1[3] = 2;
  param_1[4] = 0;
  param_1[5] = (char)((int)(short)local_8 % 10) + (char)((int)(short)local_8 / 10) * '\x10';
  param_1[6] = (char)((int)(short)local_7 % 10) + (char)((int)(short)local_7 / 10) * '\x10';
  param_1[7] = (char)((int)(short)local_6 % 10) + (char)((int)(short)local_6 / 10) * '\x10';
  setcrcs(param_1 + 1,0,0,0);
  return;
}


// ==== sm_prcdo @ 0102edb4

void sm_prcdo(undefined4 param_1)

{
  undefined2 *puVar1;
  int iVar2;
  int unaff_D7;
  
  iVar2 = f_tcb * 0x34;
  if (f_mode != 0) {
    smp_dsph(param_1);
    if (unaff_D7 == 0) {
      smp_com(param_1);
    }
    else {
      (&sdutcb)[f_tcb * 0x34] = 0;
      f_pno = 0;
      f_mode = 0;
      puVar1 = *(undefined2 **)(&DAT_01078664 + iVar2);
      *puVar1 = 0xffc4;
      *(undefined *)((int)puVar1 + 3) = (&DAT_01078638)[iVar2];
      ret_drv(*(undefined4 *)(&DAT_01078664 + iVar2));
      post((&DAT_01078635)[iVar2],0x4000000);
    }
  }
  return;
}


// ==== sdudummy @ 0102ee4e

void sdudummy(void)

{
  return;
}


// ==== smp_dsph @ 0102ee56

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void smp_dsph(int param_1)

{
  char *pcVar1;
  char cVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  
  f_bc = (uint)*(byte *)(param_1 + 9);
  if (f_bc == 0) {
    f_bc = 0x100;
  }
  if (f_mode == 5) {
    iVar3 = 0;
    while( true ) {
      if ((&cmd1tbl)[iVar3 * 0x42] == -1) break;
      if (*(char *)(param_1 + 10) == (&cmd1tbl)[iVar3 * 0x42]) {
        iVar4 = 0;
        while( true ) {
          pcVar1 = (char *)(iVar3 * 0x42 + 0x10782e6 + iVar4 * 2);
          cVar2 = *pcVar1;
          if (cVar2 == -1) {
            return;
          }
          if (*(char *)(param_1 + 0xb) == cVar2) break;
          iVar4 = iVar4 + 1;
        }
        uVar5 = (uint)(byte)pcVar1[1];
        if ((uVar5 != 0x3e) && (uVar5 != 0x40)) {
          f_pno = uVar5;
        }
        if (((f_pno == 0x1b) && (_flg_close = 0, DAT_01078738 == -1)) && (DAT_0107873a == '?')) {
          f_pno = 0x3f;
          _flg_close = 1;
        }
        if (*(byte *)(param_1 + 0xc) < 4) {
          f_type = (uint)*(byte *)(param_1 + 0xc);
          return;
        }
        return;
      }
      iVar3 = iVar3 + 1;
    }
  }
  return;
}


// ==== smp_com @ 0102ef44

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void smp_com(undefined4 param_1)

{
  undefined2 *puVar1;
  int iVar2;
  int iVar3;
  int unaff_D3;
  int iVar4;
  int iVar5;
  int unaff_D7;
  
  iVar2 = f_pno;
  iVar3 = f_tcb * 0x34;
  puVar1 = *(undefined2 **)(&DAT_01078664 + iVar3);
  do {
    iVar5 = -1;
    iVar4 = -0x3c;
    switch(f_mode) {
    case 1:
      id_proc(param_1);
      iVar4 = unaff_D7;
      if (unaff_D7 == 0) {
        f_mode = 2;
        goto switchD_0102ef8a_caseD_2;
      }
      unaff_D3 = -1;
      spl_rp = spl_rp + 1;
      if (9 < spl_rp) {
        spl_rp = 0;
      }
      break;
    case 2:
switchD_0102ef8a_caseD_2:
      busy_cnt = 0;
      wait_skp = 0;
      cp_call();
      unaff_D3 = unaff_D7;
      if (unaff_D7 == -1) {
        iVar4 = -0x3d;
      }
      break;
    case 3:
      (*(code *)(&ap_tbl)[f_pno])(&DAT_0107842e + spl_rp * 0x34);
      if (unaff_D7 == 2) {
LAB_0102f030:
        f_mode = 4;
        f_sp = 0;
        unaff_D3 = 3;
      }
      else {
        if (unaff_D7 < 3) {
          if (unaff_D7 == 0) goto LAB_0102f030;
        }
        else if (unaff_D7 == 3) {
          _ack_task = f_pno;
          unaff_D3 = unaff_D7;
          break;
        }
LAB_0102f0fc:
        f_pno = 0;
        f_mode = 0;
        unaff_D3 = unaff_D7;
      }
      break;
    case 4:
      sp_proc(f_sp);
      if (unaff_D7 != 3) goto LAB_0102f0fc;
      _ret_task = f_pno;
      f_mode = 5;
      f_sp = 0xffffffff;
      unaff_D3 = unaff_D7;
      break;
    case 5:
      (*(code *)(&rp_tbl)[f_pno])(param_1);
      if ((unaff_D7 == 3) || (unaff_D7 == 1)) {
        f_mode = 4;
        iVar5 = 0;
        unaff_D3 = unaff_D7;
      }
      else {
        if ((unaff_D7 != -0x44) && (unaff_D7 != -0x43)) goto LAB_0102f0fc;
        if (unaff_D7 == -0x44) {
          busy_cnt = busy_cnt + 1;
        }
        f_mode = 4;
        set_wait(f_pno,(&tbl_time)[f_pno]);
        unaff_D3 = 3;
      }
    }
    if (iVar5 == -1) {
      if (((unaff_D3 == 2) || (unaff_D3 == 0)) || (unaff_D3 == -1)) {
        f_pno = 0;
        f_mode = 0;
        (&sdutcb)[iVar3] = 0;
        if (unaff_D3 == -1) {
          ng_flg = 0xffffffff;
          *puVar1 = (short)iVar4;
        }
        if ((_flg_close == 0) && (iVar2 != 0x3f)) {
          if ((iVar2 == 0x14) && (**(short **)(&DAT_01078664 + iVar3) < 0)) {
            f_reset = 0xffffffff;
          }
          ret_drv(*(undefined4 *)(&DAT_01078664 + iVar3));
          post((&DAT_01078635)[iVar3],0x4000000);
        }
      }
      return;
    }
  } while( true );
}


// ==== smp_req @ 0102f192

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void smp_req(void)

{
  undefined2 *puVar1;
  short sVar2;
  int iVar3;
  int iVar4;
  int iVar5;
  int unaff_D7;
  undefined1 auStack_14 [16];
  
  do {
    iVar5 = spl_rp;
    iVar3 = spl_rp * 0x34;
    sVar2 = (&DAT_01078452)[spl_rp * 0x1a];
    if ((_ack_task == 0) || (_ret_task == 0)) {
      if ((f_mode != 0) || (chk_tcb(), unaff_D7 == -1)) {
        return;
      }
      iVar4 = 0;
      if (spl_rp != spl_wp) {
        iVar4 = -1;
      }
      if (spl_full == -1) {
        iVar4 = -1;
        spl_full = 0;
      }
      if (iVar4 == -1) {
        f_pno = (uint)(byte)(&DAT_010787ac)[(byte)(&DAT_0107842e)[iVar3]];
        if (((f_pno == 0x1a) || (f_pno == 0x1b)) &&
           ((&used_fcb)[(short)(&DAT_01078452)[iVar5 * 0x1a]] != -1)) {
          f_mode = 0;
          f_pno = 0;
          puVar1 = *(undefined2 **)(&DAT_0107845c + iVar3);
          *puVar1 = 0xfffe;
          *(undefined *)((int)puVar1 + 3) = (&used_drv)[(short)(&DAT_01078452)[iVar5 * 0x1a]];
          ret_drv(*(undefined4 *)(&DAT_0107845c + iVar3));
          post((&DAT_0107842d)[iVar3],0x4000000);
          spl_rp = spl_rp + 1;
          if (9 < spl_rp) {
            spl_rp = 0;
          }
        }
        if (f_pno == 0x18) {
LAB_0102f2ce:
          _flg_close = 0;
          if (((&file_cp)[sVar2] != 0) && ((&wmark)[sVar2] == -1)) {
            _flg_close = (uint)(f_pno == 0x18);
            f_pno = 0x3f;
            f_tcb = 5;
            DAT_010787ab = 5;
            f_mode = 2;
            wait_skp = 0xffffffff;
            DAT_01078738 = 0xff;
            DAT_0107873a = 0x3f;
            DAT_0107875e = (&DAT_01078452)[iVar5 * 0x1a];
            DAT_01078768 = &flashsts;
            goto LAB_0102f458;
          }
        }
        else if ((int)f_pno < 0x19) {
          if (f_pno == 0) goto LAB_0102f458;
        }
        else if (f_pno == 0x1a) goto LAB_0102f2ce;
        f_rp = 0;
        set_tcb(f_pno);
        iVar5 = f_tcb * 0x34;
        if ((f_pno == 0x19) || (f_pno == 0x22)) {
          date_set(auStack_14);
          day_tim(auStack_14);
          time_set(auStack_14);
          day_tim(auStack_14);
        }
        if ((f_pno == 0x14) || (ng_flg == -1)) {
          ng_flg = 0;
          ck_idc();
          if (unaff_D7 == 0) {
            f_mode = 1;
          }
          else {
            f_mode = 0;
            f_pno = 0;
            (&sdutcb)[f_tcb * 0x34] = 0;
            puVar1 = *(undefined2 **)(&DAT_01078664 + iVar5);
            *puVar1 = (short)unaff_D7;
            *(undefined *)((int)puVar1 + 3) = (&DAT_01078638)[iVar5];
            ret_drv(*(undefined4 *)(&DAT_01078664 + iVar5));
            post((&DAT_01078635)[iVar5],0x4000000);
            spl_rp = spl_rp + 1;
            if (9 < spl_rp) {
              spl_rp = 0;
            }
          }
        }
        else {
          f_mode = 2;
          wait_skp = 0xffffffff;
        }
      }
    }
LAB_0102f458:
    if (spl_rp == spl_wp) {
      return;
    }
    if (f_mode != 0) {
      return;
    }
  } while( true );
}


// ==== sm_prcrq @ 0102f47a

void sm_prcrq(int param_1)

{
  byte *pbVar1;
  int iVar2;
  int iVar3;
  byte bVar4;
  
  if (spl_full != -1) {
    (&DAT_0107842d)[spl_wp * 0x34] = *(undefined1 *)(param_1 + 2);
    cpybuf(param_1 + 8,&DAT_0107842e + spl_wp * 0x34,0x32);
    iVar2 = spl_wp;
    iVar3 = spl_wp * 0x34;
    namset8(param_1 + 0xc,iVar3 + 0x1078432);
    namset8(param_1 + 0x18,iVar3 + 0x107843e);
    pbVar1 = &DAT_01078430 + iVar3;
    if (*pbVar1 < 10) {
      bVar4 = *pbVar1 - 8;
    }
    else {
      bVar4 = *pbVar1 - 10;
    }
    *pbVar1 = bVar4;
    pbVar1 = &DAT_01078431 + iVar3;
    if (*pbVar1 < 10) {
      bVar4 = *pbVar1 - 8;
    }
    else {
      bVar4 = *pbVar1 - 10;
    }
    *pbVar1 = bVar4;
    bVar4 = (&DAT_0107842e)[iVar3];
    if ((bVar4 < 3) || ((5 < bVar4 && (bVar4 != 0x16)))) {
      port_no = (&DAT_0107842f)[iVar3];
    }
    else {
      port_no = (&fileport)[(short)(&DAT_01078452)[iVar2 * 0x1a]];
    }
    spl_wp = spl_wp + 1;
    if (9 < spl_wp) {
      spl_wp = 0;
    }
    if (spl_wp == spl_rp) {
      spl_full = -1;
    }
  }
  return;
}


// ==== set_tcb @ 0102f59a

int set_tcb(int param_1)

{
  int iVar1;
  int iVar2;
  
  iVar2 = 0;
  do {
    iVar1 = iVar2 * 0x34;
    if ((&sdutcb)[iVar1] == '\0') {
      f_tcb._3_1_ = (undefined1)iVar2;
      (&tbl_tno)[param_1] = (undefined1)f_tcb;
      f_tcb = iVar2;
      cpybuf(&sduspl + spl_rp * 0x34,&sdutcb + f_tcb * 0x34,0x34);
      iVar2 = f_tcb * 0x34;
      (&sdutcb)[iVar2] = 0xff;
      return iVar2;
    }
    iVar2 = iVar2 + 1;
  } while (iVar2 < 5);
  return CONCAT31((int3)((uint)iVar1 >> 8),(&sdutcb)[iVar1]);
}


// ==== chk_tcb @ 0102f61e

void chk_tcb(void)

{
  int iVar1;
  
  iVar1 = 0;
  do {
    iVar1 = iVar1 + 1;
  } while (iVar1 < 5);
  iVar1 = 0;
  while (((&tbl_tno)[iVar1] == 0 ||
         ((&DAT_0107842e)[spl_rp * 0x34] != (&DAT_01078636)[(uint)(byte)(&tbl_tno)[iVar1] * 0x34])))
  {
    iVar1 = iVar1 + 1;
    if (0x3f < iVar1) {
      return;
    }
  }
  return;
}


// ==== cp_call @ 0102f698

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void cp_call(void)

{
  int unaff_D7;
  
  if (f_mode == 2) {
    (*(code *)(&cp_tbl)[f_pno])();
    if (unaff_D7 == 0) {
      _ack_task = f_pno;
      switch(f_pno) {
      case 4:
      case 5:
      case 6:
      case 7:
      case 9:
      case 0xb:
      case 0xf:
      case 0x26:
      case 0x27:
      case 0x28:
      case 0x29:
      case 0x2a:
      case 0x2b:
      case 0x2c:
      case 0x2d:
      case 0x2e:
      case 0x2f:
      case 0x30:
      case 0x31:
      case 0x32:
      case 0x33:
      case 0x34:
      case 0x35:
      case 0x3c:
        f_mode = 5;
        break;
      default:
        f_mode = 3;
      }
    }
    if ((f_pno != 0x3f) && (spl_rp = spl_rp + 1, 9 < spl_rp)) {
      spl_rp = 0;
    }
  }
  return;
}


// ==== ret_drv @ 0102f78a

void ret_drv(short *param_1)

{
  undefined1 *puVar1;
  
  puVar1 = (undefined1 *)((int)param_1 + 3);
  if (*param_1 < 0) {
    switch(*puVar1) {
    case 0:
      *puVar1 = 8;
      break;
    case 1:
      *puVar1 = 9;
      break;
    case 2:
      *puVar1 = 0xc;
      break;
    case 3:
      *puVar1 = 0xd;
    }
  }
  return;
}


// ==== segcheck @ 0102f7d4

void segcheck(char param_1,short param_2)

{
  int iVar1;
  
  iVar1 = 0;
  do {
    if (*(short *)(segtbl + (uint)(byte)(param_1 - 4) * 0x14 + iVar1 * 2) == param_2) {
      return;
    }
    iVar1 = iVar1 + 1;
  } while (iVar1 < 5);
  return;
}


// ==== segcopy @ 0102f816

void segcopy(char param_1,byte param_2,byte param_3)

{
  uint uVar1;
  uint uVar2;
  int unaff_D7;
  int iVar3;
  int iVar4;
  
  iVar3 = segtbl + (uint)(byte)(param_1 - 4U) * 0x14;
  if ((byte)(param_1 - 4U) == 0) {
    iVar4 = d0_buf;
  }
  else {
    iVar4 = d1_buf;
  }
  if ((*(short *)(iVar3 + 10 + (uint)param_3 * 2) == 0) ||
     (segwrite(param_1,(uint)param_3,0), unaff_D7 == 0)) {
    uVar1 = (uint)param_3;
    uVar2 = (uint)param_2;
    cpydata(iVar4 + uVar2 * 0x400,iVar4 + uVar1 * 0x400,0x400);
    *(undefined2 *)(iVar3 + 10 + uVar1 * 2) = *(undefined2 *)(iVar3 + 10 + uVar2 * 2);
    *(undefined2 *)(iVar3 + uVar1 * 2) = *(undefined2 *)(iVar3 + uVar2 * 2);
    *(undefined2 *)(iVar3 + 10 + uVar2 * 2) = 0;
    return;
  }
  return;
}


// ==== segback @ 0102f8ba

void segback(char param_1,byte param_2,byte param_3)

{
  uint uVar1;
  int iVar2;
  
  iVar2 = segtbl + (uint)(byte)(param_1 - 4) * 0x14;
  uVar1 = (uint)param_2;
  *(undefined2 *)(iVar2 + 10 + (uint)param_3 * 2) = *(undefined2 *)(iVar2 + 10 + uVar1 * 2);
  *(undefined2 *)(iVar2 + uVar1 * 2) = 0;
  *(undefined2 *)(iVar2 + 10 + uVar1 * 2) = 0;
  return;
}


// ==== segread @ 0102f8fc

void segread(char param_1,ushort param_2,char param_3)

{
  byte bVar1;
  int iVar2;
  byte bVar3;
  int unaff_D7;
  int iVar4;
  int iVar5;
  undefined1 uStack_6;
  byte local_5;
  
  bVar1 = param_1 - 4;
  iVar2 = (uint)bVar1 * 0x2a;
  iVar4 = segtbl + (uint)bVar1 * 0x14;
  if (bVar1 == 0) {
    iVar5 = d0_buf;
  }
  else {
    iVar5 = d1_buf;
  }
  if ((((param_2 != 0) && (((&DAT_01042b35)[iVar2] != '\x02' || (param_2 < 0x20)))) &&
      (((&DAT_01042b35)[iVar2] != '\x03' || (param_2 < 5)))) &&
     (((segcheck(param_1,param_2), unaff_D7 < 0 || (3 < unaff_D7)) &&
      ((unaff_D7 != 4 || (param_3 != '\0')))))) {
    if (param_3 == '\0') {
      segwrite(param_1,4,0);
      if (unaff_D7 == 0) {
        seg1rw(param_1,param_2,4,0);
      }
    }
    else {
      segwrite(param_1,0,1);
      if (unaff_D7 == 0) {
        bVar1 = 0;
        do {
          bVar3 = bVar1;
          if (*(ushort *)(iVar4 + 8) == param_2) {
            segcopy(param_1,4,bVar3);
          }
          else {
            seg1rw(param_1,param_2,bVar3,0);
          }
          iVar2 = iVar5 + (uint)bVar3 * 0x400;
          if (*(short *)(iVar2 + 2) == 0) break;
          mvshort(*(undefined2 *)(iVar2 + 2),&uStack_6);
          param_2 = (ushort)local_5;
          bVar1 = bVar3 + 1;
        } while ((byte)(bVar3 + 1) < 4);
        while (bVar3 = bVar3 + 1, bVar3 < 4) {
          *(undefined2 *)(iVar4 + (uint)bVar3 * 2) = 0;
          *(undefined2 *)(iVar4 + 10 + (uint)bVar3 * 2) = 0;
        }
      }
    }
  }
  return;
}


// ==== segwrite @ 0102faba

void segwrite(char param_1,byte param_2,char param_3)

{
  uint uVar1;
  byte bVar2;
  byte bVar3;
  int unaff_D7;
  int iVar4;
  
  iVar4 = segtbl + (uint)(byte)(param_1 - 4) * 0x14;
  if (param_3 == '\0') {
    seg1rw(param_1,*(undefined2 *)(iVar4 + (uint)param_2 * 2),(uint)param_2,1);
  }
  else {
    bVar3 = 4;
    if (param_3 == '\x02') {
      bVar3 = 5;
    }
    bVar2 = 0;
    if (bVar3 != 0) {
      do {
        uVar1 = (uint)bVar2;
        if (((*(short *)(iVar4 + uVar1 * 2) != 0) && (*(short *)(iVar4 + 10 + uVar1 * 2) != 0)) &&
           (seg1rw(param_1,*(undefined2 *)(iVar4 + uVar1 * 2),uVar1,1), unaff_D7 != 0)) {
          return;
        }
        bVar2 = bVar2 + 1;
      } while (bVar2 < bVar3);
    }
  }
  return;
}


// ==== seg1rw @ 0102fb72

void seg1rw(char param_1,short param_2,byte param_3,char param_4)

{
  short sVar1;
  int unaff_D7;
  int iVar2;
  int iVar3;
  
  sVar1 = (param_2 + -1) * 2 + 6;
  iVar3 = segtbl + (uint)(byte)(param_1 - 4U) * 0x14;
  if ((byte)(param_1 - 4U) == 0) {
    iVar2 = d0_buf;
  }
  else {
    iVar2 = d1_buf;
  }
  if (param_4 == '\0') {
    blkread(param_1,iVar2 + (uint)param_3 * 0x400,sVar1,2);
    if (unaff_D7 != 0) {
      return;
    }
    *(short *)(iVar3 + (uint)param_3 * 2) = param_2;
  }
  else {
    blkwrite(param_1,iVar2 + (uint)param_3 * 0x400,sVar1,2);
    if (unaff_D7 != 0) {
      return;
    }
  }
  *(undefined2 *)(iVar3 + 10 + (uint)param_3 * 2) = 0;
  return;
}


// ==== sgen @ 0102fc40

void sgen(void)

{
  short *psVar1;
  
  tv_flag = 0;
  inihard();
  ivtblset();
  tvtblset();
  devgen();
  ini_vids();
  devtrp(0,2,10);
  devtrp(0,2,0x10c);
  siogen();
  for (psVar1 = &tibsgen; *psVar1 != 0; psVar1 = psVar1 + 7) {
    crtask(psVar1,0);
  }
  net_creat();
  return;
}


// ==== ivtblset @ 0102fcbe

void ivtblset(void)

{
  irqvct(0x50,dmareq);
  irqvct(0x52,fdirq);
  irqvct(0x51,hdkirq);
  irqvct(0x60,&intrd00);
  irqvct(0x61,&intred00);
  irqvct(0x62,&intrd01);
  irqvct(99,&intred01);
  irqvct(100,&intrd02);
  irqvct(0x65,&intred02);
  irqvct(0x66,&intrd03);
  irqvct(0x67,&intred03);
  irqvct(0x68,&intrd04);
  irqvct(0x69,&intred04);
  irqvct(0x6a,&intrd05);
  irqvct(0x6b,&intred05);
  irqvct(0x6c,&intrd06);
  irqvct(0x6d,&intred06);
  irqvct(0x6e,&intrd07);
  irqvct(0x6f,&intred07);
  irqvct(0x70,&intrd08);
  irqvct(0x71,&intred08);
  irqvct(0x72,&intrd09);
  irqvct(0x73,&intred09);
  irqvct(0x74,&intrd10);
  irqvct(0x75,&intred10);
  irqvct(0x76,&intrd11);
  irqvct(0x77,&intred11);
  irqvct(0x78,&intrd12);
  irqvct(0x79,&intred12);
  irqvct(0x7a,&intrd13);
  irqvct(0x7b,&intred13);
  irqvct(0x7c,&intrd14);
  irqvct(0x7d,&intred14);
  irqvct(0x7e,&intrd15);
  irqvct(0x7f,&intred15);
  irqvct(0x80,&intrd16);
  irqvct(0x81,&intred16);
  irqvct(0x82,&intrd17);
  irqvct(0x83,&intred17);
  irqvct(0x84,&intrd18);
  irqvct(0x85,&intred18);
  irqvct(0x86,&intrd19);
  irqvct(0x87,&intred19);
  irqvct(0x88,&intrd20);
  irqvct(0x89,&intred20);
  irqvct(0x8a,&intrd21);
  irqvct(0x8b,&intred21);
  irqvct(0x8c,&intrd22);
  irqvct(0x8d,&intred22);
  irqvct(0x8e,&intrd23);
  irqvct(0x8f,&intred23);
  irqvct(0x90,&intrd24);
  irqvct(0x91,&intred24);
  irqvct(0x92,&intrd25);
  irqvct(0x93,&intred25);
  irqvct(0x94,&intrd26);
  irqvct(0x95,&intred26);
  irqvct(0x96,&intrd27);
  irqvct(0x97,&intred27);
  irqvct(0x98,&intrd28);
  irqvct(0x99,&intred28);
  irqvct(0x9a,&intrd29);
  irqvct(0x9b,&intred29);
  irqvct(0x9c,&intrd30);
  irqvct(0x9d,&intred30);
  irqvct(0x9e,&intrd31);
  irqvct(0x9f,&intred31);
  irqvct(0x46,ttyrxint);
  irqvct(0x47,ttyreset);
  irqvct(0x48,ttytxint);
  irqvct(0xa3,prtnop);
  irqvct(0x43,smcrxint);
  irqvct(0x44,smcreset);
  irqvct(0x45,smctxint);
  irqvct(0xa3,prtnop);
  irqvct(0x40,ptprxint);
  irqvct(0x41,ptpreset);
  irqvct(0x42,ptptxint);
  irqvct(0xa3,prtnop);
  irqvct(0x49,auxrxint);
  irqvct(0x4a,auxreset);
  irqvct(0x4b,auxtxint);
  irqvct(0xa3,prtnop);
  irqvct(0xa4,prtrxint);
  irqvct(0xa5,prtreset);
  irqvct(0xa6,prttxint);
  irqvct(0xa3,prtnop);
  irqvct(0x53,_tup3req);
  irqvct(0x5a,_tup1req);
  irqvct(0x5b,fieldint);
  irqvct(0x5f,noServe);
  return;
}


// ==== tvtblset @ 0103016e

void tvtblset(void)

{
  itrpvct(0,icudrv);
  itrpvct(1,hdktrp);
  itrpvct(4,spfset);
  itrpvct(0xe,setPIT);
  itrpvct(0xf,DAT_010414d0);
  itrpvct(0x10,spf5selec);
  itrpvct(3,dialstat);
  itrpvct(5,set7seg);
  itrpvct(6,getdipsw);
  itrpvct(8,os_vrsex);
  itrpvct(9,spfled);
  itrpvct(10,spfledoff);
  itrpvct(0xd,&ptcmdidc);
  itrpvct(0xc,&ptprdcmd);
  return;
}


// ==== devgen @ 01030234

void devgen(void)

{
  crdcb(ksinit,kbddev,0x81);
  crdcb(dmadint,memmov,0x83);
  crdcb(inieepdv,eepdev,0x82);
  return;
}


// ==== sysdown @ 0103027e

void sysdown(void)

{
  return;
}


// ==== _sareset @ 01030288

void _sareset(int param_1)

{
  int iVar1;
  short sVar2;
  short sVar3;
  
  DAT_0107c420 = *(uint *)(param_1 + 4) & 0xfffffffe;
  DAT_0107c424 = *(uint *)(param_1 + 8) & 0xfffffffe;
  iVar1 = DAT_0107c424 - DAT_0107c420;
  if (iVar1 < 0) {
    iVar1 = iVar1 + 0x3ff;
  }
  fill(DAT_0107c420,(iVar1 >> 10) << 1,0);
  iVar1 = DAT_0107c424 - DAT_0107c420;
  if (iVar1 < 0) {
    iVar1 = iVar1 + 0x3ff;
  }
  sVar2 = (short)(iVar1 >> 10);
  sVar3 = sVar2;
  if (sVar2 < 0) {
    sVar3 = sVar2 + 0x1ff;
  }
  sVar3 = sVar3 >> 9;
  if (0 < sVar2 % 0x200) {
    sVar3 = sVar3 + 1;
  }
  DAT_0107c42c = sVar2 - sVar3;
  DAT_0107c428 = DAT_0107c420 + (short)(sVar2 - sVar3) * 2;
  return;
}


// ==== _shaloc @ 0103033e

uint _shaloc(int param_1)

{
  int iVar1;
  undefined2 extraout_D0u;
  uint uVar2;
  int iVar3;
  short unaff_D7w;
  undefined2 *puVar4;
  int iVar5;
  
  iVar1 = DAT_0107c420;
  uVar2 = 0;
  if ((*(int *)(param_1 + 4) != 0) && (uVar2 = 0, DAT_0107c420 != 0)) {
    iVar3 = *(int *)(param_1 + 4);
    if (iVar3 < 0) {
      iVar3 = iVar3 + 0x3ff;
    }
    uVar2 = *(uint *)(param_1 + 4);
    if ((int)uVar2 < 0) {
      uVar2 = uVar2 + 0x3ff;
    }
    uVar2 = (byte)-(0 < (int)-((uVar2 & 0xfffffc00) - *(int *)(param_1 + 4))) & 1;
    iVar3 = uVar2 + (iVar3 >> 10);
    if (iVar3 <= DAT_0107c42c) {
      for (iVar5 = 0; uVar2 = CONCAT22((short)(uVar2 >> 0x10),DAT_0107c42c),
          iVar3 + iVar5 < (int)DAT_0107c42c; iVar5 = (short)puVar4[-1] + iVar5) {
        puVar4 = (undefined2 *)(iVar1 + iVar5 * 2);
        srh_mem();
        if (unaff_D7w != 0) {
          *puVar4 = (short)iVar3;
          while( true ) {
            puVar4 = puVar4 + 1;
            iVar3 = iVar3 + -1;
            if (iVar3 == 0) break;
            *puVar4 = 1;
          }
          uVar2 = fill(DAT_0107c428 + iVar5 * 0x400,*(undefined4 *)(param_1 + 4),0);
          return uVar2;
        }
        uVar2 = CONCAT22(extraout_D0u,puVar4[-1]);
      }
    }
  }
  return uVar2;
}


// ==== srh_mem @ 0103041e

void srh_mem(undefined4 param_1,int param_2,short *param_3)

{
  while ((param_2 != 0 && (*param_3 == 0))) {
    param_2 = param_2 + -1;
    param_3 = param_3 + 1;
  }
  return;
}


// ==== _shfree @ 0103043e

void _shfree(int param_1)

{
  short *psVar1;
  int iVar2;
  
  if ((DAT_0107c420 <= *(uint *)(param_1 + 4)) && (*(uint *)(param_1 + 4) <= DAT_0107c424)) {
    iVar2 = *(int *)(param_1 + 4) - DAT_0107c428;
    if (iVar2 < 0) {
      iVar2 = iVar2 + 0x3ff;
    }
    psVar1 = (short *)(DAT_0107c420 + (iVar2 >> 10) * 2);
    iVar2 = (int)*psVar1;
    if (iVar2 != 0) {
      while (iVar2 = iVar2 + -1, iVar2 != -1) {
        *psVar1 = 0;
        psVar1 = psVar1 + 1;
      }
    }
  }
  return;
}


// ==== sioint @ 010304a4

void sioint(void)

{
  sioinit();
  return;
}


// ==== siotask @ 010304b4

void siotask(void)

{
  uint unaff_D7;
  undefined1 auStack_80 [28];
  undefined1 auStack_64 [96];
  
  itrpvct(0xb,siotrp);
  fill(auStack_64,0x60,0);
  siowork = siowork | 0x80000000;
  do {
    wait((void *)0x0);
    if ((unaff_D7 & 0x800) != 0) {
      siorxsig(auStack_64);
    }
    fill(auStack_80,0x14,0);
    while (remsg(auStack_80), unaff_D7 == 0) {
      siorxcmd(auStack_64,auStack_80);
    }
  } while( true );
}


// ==== siorxsig @ 0103054c

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

uint siorxsig(uint *param_1)

{
  uint uVar1;
  
  uVar1 = 0;
  do {
    if (((*param_1 & 1 << (uVar1 & 0x1f)) != 0) || (_Siodebug != 0)) {
      (*(code *)(&jtsiorxsi)[uVar1])(param_1);
    }
    uVar1 = uVar1 + 1;
  } while ((int)uVar1 < 5);
  uVar1 = *param_1;
  if (((uVar1 & 0x100) != 0) && (uVar1 = *param_1 & 0x1e, uVar1 == 0)) {
    *param_1 = *param_1 & 0xfffffeff;
    siowork = siowork & 0x7fffffff;
    uVar1 = devtrp(0xb,0x20);
  }
  return uVar1;
}


// ==== siorxcmd @ 010305c0

void siorxcmd(uint *param_1,int param_2)

{
  undefined4 *unaff_D7;
  int *piVar1;
  
  piVar1 = (int *)(param_2 + 8);
  latopa(*(undefined1 *)(param_2 + 2),*(undefined4 *)(param_2 + 0x18));
  *unaff_D7 = 0;
  if ((*piVar1 < 0x20) || (0x24 < *piVar1)) {
    *unaff_D7 = 0x80000004;
  }
  else if ((*param_1 & 1) == 0) {
    if ((*param_1 & 1 << (*piVar1 - 0x20U & 0x1f)) == 0) {
      (*(code *)(&DAT_0107c428)[*piVar1])(param_1,param_2);
      *unaff_D7 = unaff_D7;
      if (unaff_D7 == (undefined4 *)0x0) {
        *param_1 = *param_1 | 1 << (*piVar1 - 0x20U & 0x3f);
        param_1[*piVar1 + -0x1f] = 0;
        *(undefined1 *)((int)param_1 + *piVar1) = *(undefined1 *)(param_2 + 2);
      }
      else {
        post(*(undefined1 *)(param_2 + 2),0x800);
      }
    }
    else {
      *unaff_D7 = 0x80000008;
    }
  }
  else {
    *unaff_D7 = 0x80000002;
  }
  return;
}


// ==== siorsrst @ 0103068e

void siorsrst(undefined4 *param_1)

{
  if ((siowork & 0x100) == 0) {
    *param_1 = 0;
    siowork = 0x80000000;
    *(undefined4 *)param_1[1] = 1;
    post(*(undefined1 *)(param_1 + 8),0x800);
  }
  return;
}


// ==== siorsset @ 010306cc

void siorsset(void)

{
  return;
}


// ==== siorsret @ 010306d4

void siorsret(void)

{
  return;
}


// ==== siorsrxd @ 010306dc

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void siorsrxd(uint *param_1)

{
  byte bVar1;
  uint uVar2;
  undefined4 unaff_D7;
  
  bVar1 = DAT_01087a65;
  uVar2 = (uint)DAT_01087a65;
  if (uVar2 != DAT_01087a64) {
    if (_Siodebug == 0) {
      *param_1 = *param_1 & 0xfffffff7;
      siomvrxd(param_1[0x14],param_1[0xd]);
      *(undefined4 *)param_1[4] = unaff_D7;
      post(*(undefined1 *)((int)param_1 + 0x23),0x800);
    }
    else {
      DAT_01087a6e = *(undefined4 *)(&DAT_01087a66 + uVar2 * 4);
      DAT_01087a72 = 0;
      cpybuf(&DAT_01087a76 + uVar2 * 0x226,&DAT_01087ec2,DAT_01087a6e);
      *(undefined4 *)(&DAT_01087a66 + uVar2 * 4) = 0;
      DAT_01087a65 = bVar1 + 1 & 1;
      devtrp(0xb,0x24);
    }
  }
  return;
}


// ==== siorstxd @ 01030796

int siorstxd(uint *param_1)

{
  int iVar1;
  
  iVar1 = DAT_01087a6e;
  if (DAT_01087a6e == 0) {
    *param_1 = *param_1 & 0xffffffef;
    *(undefined4 *)param_1[5] = DAT_01087a72;
    iVar1 = post(*(undefined1 *)((int)param_1 + 0x23),0x800);
  }
  return iVar1;
}


// ==== siorcrst @ 010307d0

void siorcrst(uint *param_1)

{
  if ((*param_1 & 0x16) == 0) {
    siowork = siowork & 0x7fffffff;
    devtrp(0xb,0x20);
  }
  else {
    *param_1 = *param_1 | 0x100;
  }
  return;
}


// ==== siorcset @ 0103080e

void siorcset(undefined4 param_1,int param_2)

{
  undefined4 unaff_D7;
  
  if (**(int **)(param_2 + 0x14) == 0) {
    DAT_01047600 = 0x5a;
    DAT_01047604 = 0x34;
  }
  else {
    siomdeco(**(undefined4 **)(param_2 + 0x14));
    DAT_01047600 = (ushort)(byte)unaff_D7;
    DAT_01047604 = (undefined2)((uint)unaff_D7 >> 0x10);
  }
  return;
}


// ==== siorcret @ 0103085a

void siorcret(undefined4 param_1,int param_2)

{
  undefined4 unaff_D7;
  
  siomenco(CONCAT22(DAT_01047604,DAT_01047600));
  **(undefined4 **)(param_2 + 0x14) = unaff_D7;
  return;
}


// ==== siorcrxd @ 01030894

char siorcrxd(int param_1,int param_2)

{
  char cVar1;
  char cVar2;
  int unaff_D7;
  
  if (*(int *)(param_2 + 0xc) == 0) {
    cVar2 = '\0';
  }
  else {
    cVar2 = latopa(*(undefined1 *)(param_2 + 2),*(undefined4 *)(param_2 + 0x10));
    cVar1 = DAT_01087a64;
    if (unaff_D7 != 0) {
      if (DAT_01087a65 == DAT_01087a64) {
        *(int *)(param_1 + 0x50) = unaff_D7;
        *(undefined4 *)(param_1 + 0x34) = *(undefined4 *)(param_2 + 0xc);
        cVar2 = cVar1;
      }
      else {
        cVar2 = siomvrxd(param_2 + 8);
      }
    }
  }
  return cVar2;
}


// ==== siorctxd @ 01030910

void siorctxd(undefined4 param_1,int param_2)

{
  int unaff_D7;
  
  if (((*(int *)(param_2 + 0xc) != 0) && (*(int *)(param_2 + 0xc) < 0x227)) &&
     (latopa(*(undefined1 *)(param_2 + 2),*(undefined4 *)(param_2 + 0x10)), unaff_D7 != 0)) {
    DAT_01087a72 = 0;
    DAT_01087a6e = *(undefined4 *)(param_2 + 0xc);
    cpybuf();
    devtrp(0xb,0x24);
  }
  return;
}


// ==== siomvrxd @ 0103099e

void siomvrxd(undefined4 param_1,int param_2)

{
  int iVar1;
  byte bVar2;
  uint uVar3;
  
  bVar2 = DAT_01087a65;
  uVar3 = (uint)DAT_01087a65;
  iVar1 = *(int *)(&DAT_01087a66 + uVar3 * 4);
  if (iVar1 < 0) {
    *(undefined4 *)(&DAT_01087a66 + uVar3 * 4) = 0;
  }
  else {
    if (param_2 < iVar1) {
      cpybuf(&DAT_01087a76 + uVar3 * 0x226,param_1,param_2);
      cpybuf(&DAT_01087a76 + uVar3 * 0x226 + param_2,(int)(char)(&DAT_01087a76)[uVar3 * 0x226],
             *(undefined4 *)(&DAT_01087a66 + uVar3 * 4));
      *(int *)(&DAT_01087a66 + uVar3 * 4) = iVar1 - param_2;
      return;
    }
    cpybuf(&DAT_01087a76 + uVar3 * 0x226,param_1,iVar1);
    *(undefined4 *)(&DAT_01087a66 + uVar3 * 4) = 0;
  }
  DAT_01087a65 = bVar2 + 1 & 1;
  return;
}


// ==== siomdeco @ 01030a58

byte siomdeco(byte param_1)

{
  return (param_1 & 3) << 2 | param_1 & 0x30 | (param_1 & 0xc) << 3;
}


// ==== siomenco @ 01030abc

byte siomenco(uint param_1)

{
  short sVar1;
  int iVar2;
  
  iVar2 = 0;
  sVar1 = siobaud;
  while ((sVar1 != 0 && ((&siobaud)[iVar2] != (short)(param_1 >> 0x10)))) {
    iVar2 = iVar2 + 1;
    sVar1 = (&siobaud)[iVar2];
  }
  return (byte)((param_1 & 0xc) >> 2) | (byte)param_1 & 0x30 | (byte)((param_1 & 0xc0) >> 4);
}


// ==== cp_close @ 01030b44

void cp_close(void)

{
  undefined2 uVar1;
  uint uVar2;
  
  if (f_mode == 2) {
    uVar1 = *(undefined2 *)(&DAT_0107865a + f_tcb * 0x34);
    uVar2 = (uint)(byte)uVar1;
    mfree(*(undefined4 *)(&wdatabuf + uVar2 * 4));
    (&used_fcb)[uVar2] = 0;
    *(undefined4 *)(&wdatabuf + uVar2 * 4) = 0;
    sbuff = 2;
    DAT_01087959 = 4;
    DAT_0108795a = 0x22;
    DAT_0108795b = 2;
    DAT_0108795c = 0;
    DAT_0108795d = (byte)uVar1;
    setcrcs(&DAT_01087959,0,0,0);
    idc_req(&sbuff,0xa0);
  }
  return;
}


// ==== cp_creat @ 01030be0

void cp_creat(void)

{
  int iVar1;
  uint uVar2;
  uint uVar3;
  int iVar4;
  int unaff_D7;
  
  if (f_mode == 2) {
    iVar1 = f_tcb * 0x34;
    if ((byte)(&DAT_01078638)[iVar1] < 2) {
      uVar2 = 0;
      uVar3 = 4;
    }
    else {
      uVar2 = 4;
      uVar3 = 8;
    }
    iVar4 = -1;
    if (uVar2 < uVar3) {
      do {
        if ((&used_fcb)[uVar2] != -1) {
          iVar4 = 0;
        }
        uVar2 = uVar2 + 1;
      } while ((int)uVar2 < (int)uVar3);
    }
    if ((iVar4 != -1) && (malloc(0x400), rwbuf = unaff_D7, unaff_D7 != 0)) {
      sbuff = 2;
      DAT_01087959 = 0x13;
      DAT_0108795a = 0x22;
      DAT_0108795b = 3;
      DAT_0108795c = 0;
      DAT_0108795d = (&DAT_01078638)[iVar1];
      cpybuf(iVar1 + 0x107863a,&DAT_0108795e,0xb);
      cpybuf(&DAT_01078656 + iVar1,&DAT_01087969,4);
      setcrcs(&DAT_01087959,0,0,0);
      idc_req(&sbuff,0xa0);
      if (unaff_D7 != 0) {
        mfree(rwbuf);
      }
    }
  }
  return;
}


// ==== cp_flash @ 01030cec

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void cp_flash(void)

{
  short sVar1;
  
  if ((f_mode == 2) || (f_mode == 3)) {
    sVar1 = *(short *)(&DAT_0107865a + f_tcb * 0x34);
    wrem_len = (&file_cp)[sVar1];
    if (f_mode == 2) {
      _file_fp = 0;
      wreq_len = wrem_len;
      wsize = wrem_len;
    }
    if (wreq_len == 0) {
      (&wmark)[sVar1] = 0;
      set_wait(f_pno,*(undefined2 *)(&tbl_stim + f_pno * 2));
    }
    else {
      sbuff = 2;
      DAT_01087959 = 9;
      DAT_0108795a = 0x22;
      DAT_0108795b = 5;
      DAT_0108795d = (undefined1)*(undefined2 *)(&DAT_0107865a + f_tcb * 0x34);
      _DAT_0108795e = wsize;
      DAT_01087962 = 0;
      setcrcs(&DAT_01087959,*(undefined4 *)(&wdatabuf + sVar1 * 4),&file_fp,(&file_cp)[sVar1]);
      if ((DAT_0108795c == '\x02') || (DAT_0108795c == '\0')) {
        (&file_tp)[sVar1] = 0;
        (&file_cp)[sVar1] = 0;
        wreq_len = 0;
      }
      idc_req(&sbuff,0xa0);
    }
  }
  return;
}


// ==== cp_fmtrk @ 01030e44

void cp_fmtrk(void)

{
  int iVar1;
  uint uVar2;
  undefined4 uVar3;
  
  if ((f_mode == 2) || (f_mode == 3)) {
    iVar1 = f_tcb * 0x34;
    uVar2 = *(uint *)(&DAT_01078656 + iVar1) & 0xff;
    if (uVar2 == 1) {
      uVar3 = 0x2400;
    }
    else {
      if (uVar2 != 2) {
        return;
      }
      uVar3 = 0x1200;
    }
    if ((f_mode == 3) && (*(uint *)(&DAT_01078656 + iVar1) <= f_rp)) {
      set_wait(f_pno,*(undefined2 *)(&tbl_stim + f_pno * 2));
    }
    else {
      sbuff = 2;
      DAT_01087959 = 6;
      DAT_0108795a = 0x21;
      DAT_0108795b = 9;
      DAT_0108795d = (&DAT_01078638)[iVar1];
      DAT_0108795e = (&DAT_0107865d)[iVar1];
      DAT_0108795f = (&DAT_0107865e)[iVar1];
      DAT_01087960 = (char)*(uint *)(&DAT_01078656 + iVar1);
      setcrcs(&DAT_01087959,*(undefined4 *)(&DAT_01078660 + iVar1),&f_rp,uVar3);
      idc_req(&sbuff,0xa0);
    }
  }
  return;
}


// ==== cp_open @ 01030f4c

void cp_open(void)

{
  int iVar1;
  uint uVar2;
  uint uVar3;
  int iVar4;
  int unaff_D7;
  
  if (f_mode == 2) {
    iVar1 = f_tcb * 0x34;
    if ((byte)(&DAT_01078638)[iVar1] < 2) {
      uVar2 = 0;
      uVar3 = 4;
    }
    else {
      uVar2 = 4;
      uVar3 = 8;
    }
    iVar4 = -1;
    if (uVar2 < uVar3) {
      do {
        if ((&used_fcb)[uVar2] != -1) {
          iVar4 = 0;
        }
        uVar2 = uVar2 + 1;
      } while ((int)uVar2 < (int)uVar3);
    }
    if ((iVar4 != -1) && (malloc(0x400), rwbuf = unaff_D7, unaff_D7 != 0)) {
      sbuff = 2;
      DAT_01087959 = 0xf;
      DAT_0108795a = 0x22;
      DAT_0108795b = 1;
      DAT_0108795c = 0;
      DAT_0108795d = (&DAT_01078638)[iVar1];
      cpybuf(iVar1 + 0x107863a,&DAT_0108795e,0xb);
      setcrcs(&DAT_01087959,0,0,0);
      idc_req(&sbuff,0xa0);
      if (unaff_D7 != 0) {
        mfree(rwbuf);
      }
    }
  }
  return;
}


// ==== cp_read @ 01031038

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void cp_read(void)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  
  if (f_mode == 2) {
    iVar1 = f_tcb * 0x34;
    iVar3 = (int)*(short *)(&DAT_0107865a + iVar1);
    rrem_len = (&file_tp)[iVar3] - (&file_cp)[iVar3];
    rreq_len = *(uint *)(&DAT_01078656 + iVar1);
    if (rrem_len < (int)rreq_len) {
      rreq_len = rreq_len - rrem_len;
      cpydata((&file_cp)[iVar3] + *(int *)(&wdatabuf + iVar3 * 4),
              *(undefined4 *)(&DAT_01078660 + iVar1),rrem_len);
      f_wp = rrem_len;
      (&file_tp)[iVar3] = 0;
      (&file_cp)[iVar3] = 0;
      _DAT_0108795e = rreq_len;
      if ((int)rreq_len < 0) {
        _DAT_0108795e = rreq_len + 0x3ff;
      }
      _DAT_0108795e = _DAT_0108795e & 0xfffffc00;
      uVar2 = rreq_len;
      if ((int)rreq_len < 0) {
        uVar2 = rreq_len + 0x3ff;
      }
      if ((uVar2 & 0xfffffc00) != rreq_len) {
        _DAT_0108795e = _DAT_0108795e + 0x400;
      }
      sbuff = 2;
      DAT_01087959 = 8;
      DAT_0108795a = 0x22;
      DAT_0108795b = 4;
      DAT_0108795c = 0;
      DAT_0108795d = (undefined1)*(undefined2 *)(&DAT_0107865a + iVar1);
      setcrcs(&DAT_01087959,0,0,0);
      idc_req(&sbuff,0xa0);
    }
    else {
      iVar3 = (int)*(short *)(&DAT_0107865a + iVar1);
      cpydata((&file_cp)[iVar3] + *(int *)(&wdatabuf + iVar3 * 4),
              *(undefined4 *)(&DAT_01078660 + iVar1),rreq_len);
      (&file_cp)[iVar3] = rreq_len + (&file_cp)[iVar3];
      **(uint **)(&DAT_01078664 + iVar1) = rreq_len;
      dbr_data = **(undefined1 **)(&DAT_01078660 + iVar1);
      _dbr_len = rreq_len;
      _dbr_time = (&file_cp)[iVar3];
    }
  }
  return;
}


// ==== rp_read @ 010311ca

void rp_read(int param_1,int param_2,int param_3)

{
  short sVar1;
  int iVar2;
  int iVar3;
  
  param_1 = param_1 + 7;
  sVar1 = *(short *)(param_2 + 0x24);
  if (rreq_len == 0) {
    iVar3 = (int)sVar1;
    cpydata(param_1,(&file_tp)[iVar3] + *(int *)(&wdatabuf + iVar3 * 4),param_3);
    (&file_tp)[iVar3] = param_3 + (&file_tp)[iVar3];
  }
  else {
    iVar3 = param_3 - rreq_len;
    if (iVar3 < 0) {
      cpydata(param_1,f_wp + *(int *)(param_2 + 0x2a),param_3);
      f_wp = param_3 + f_wp;
      rreq_len = rreq_len - param_3;
    }
    else {
      cpydata(param_1,f_wp + *(int *)(param_2 + 0x2a),rreq_len);
      f_wp = rreq_len + f_wp;
      iVar2 = (int)sVar1;
      cpydata(rreq_len + param_1,(&file_tp)[iVar2] + *(int *)(&wdatabuf + iVar2 * 4),iVar3);
      (&file_tp)[iVar2] = iVar3 + (&file_tp)[iVar2];
      rreq_len = 0;
    }
  }
  if ((f_type == 2) || (f_type == 0)) {
    **(int **)(param_2 + 0x2e) = *(int *)(param_2 + 0x20) - rreq_len;
  }
  return;
}


// ==== cp_wcom @ 010312d8

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void cp_wcom(void)

{
  int iVar1;
  
  if ((f_mode == 2) || (f_mode == 3)) {
    iVar1 = f_tcb * 0x34;
    if ((f_mode == 3) && (*(uint *)(&DAT_01078656 + iVar1) <= f_rp)) {
      set_wait(f_pno,*(undefined2 *)(&tbl_stim + f_pno * 2));
    }
    else {
      sbuff = 2;
      DAT_01087959 = 10;
      DAT_0108795a = 0x21;
      DAT_0108795b = 5;
      DAT_0108795d = (&DAT_01078638)[iVar1];
      _DAT_0108795e = *(undefined2 *)(&DAT_01078652 + iVar1);
      _DAT_01087960 = *(undefined2 *)(&DAT_01078654 + iVar1);
      _DAT_01087962 = (undefined2)*(undefined4 *)(&DAT_01078656 + iVar1);
      setcrcs(&DAT_01087959,*(undefined4 *)(&DAT_01078660 + iVar1),&f_rp,
              *(undefined4 *)(&DAT_01078656 + iVar1));
      idc_req(&sbuff,0xa0);
    }
  }
  return;
}


// ==== cp_write @ 010313c0

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void cp_write(void)

{
  short sVar1;
  int iVar2;
  int iVar3;
  
  if ((f_mode == 2) || (f_mode == 3)) {
    iVar2 = f_tcb * 0x34;
    sVar1 = *(short *)(&DAT_0107865a + iVar2);
    iVar3 = (int)sVar1;
    wfre_len = 0x400 - (&file_tp)[iVar3];
    wrem_len = (&file_cp)[iVar3];
    if (f_mode == 2) {
      _file_fp = 0;
      (&wflash)[iVar3] = 0;
      wreq_len = *(int *)(&DAT_01078656 + iVar2);
      wsize = wreq_len + wrem_len;
      if (wreq_len < wfre_len) {
        (&wmark)[iVar3] = 0xffffffff;
        cpydata(f_rp + *(int *)(&DAT_01078660 + iVar2),
                (&file_cp)[iVar3] + *(int *)(&wdatabuf + iVar3 * 4),wreq_len);
        **(int **)(&DAT_01078664 + iVar2) = wreq_len;
        (&file_cp)[iVar3] = wreq_len + (&file_cp)[iVar3];
        if ((int)(&file_cp)[iVar3] < (int)(&file_tp)[iVar3]) {
          return;
        }
        (&file_tp)[iVar3] = (&file_cp)[iVar3];
        return;
      }
    }
    if (wreq_len == 0) {
      set_wait(f_pno,*(undefined2 *)(&tbl_stim + f_pno * 2));
    }
    else {
      sbuff = 2;
      DAT_01087959 = 9;
      DAT_0108795a = 0x22;
      DAT_0108795b = 5;
      DAT_0108795d = (undefined1)*(undefined2 *)(&DAT_0107865a + iVar2);
      _DAT_0108795e = wsize;
      DAT_01087962 = 0x80;
      iVar3 = (int)sVar1;
      if ((&file_cp)[iVar3] == 0) {
        setdtcm3(&DAT_01087959,*(undefined4 *)(&DAT_01078660 + iVar2),&f_rp,wreq_len);
        if ((&wflash)[sVar1] == -1) {
          if (DAT_0108795c == '\x01') {
            DAT_0108795c = '\x03';
          }
          if (DAT_0108795c == '\0') {
            DAT_0108795c = '\x02';
          }
        }
      }
      else {
        (&wflash)[iVar3] = 0xffffffff;
        (&wmark)[iVar3] = 0;
        setdtcm3(&DAT_01087959,*(undefined4 *)(&wdatabuf + iVar3 * 4),&file_fp,(&file_cp)[iVar3]);
        if (wreq_len != 0) {
          if (DAT_0108795c == '\x02') {
            DAT_0108795c = '\x03';
          }
          if (DAT_0108795c == '\0') {
            DAT_0108795c = '\x01';
          }
        }
      }
      if ((DAT_0108795c == '\x02') || (DAT_0108795c == '\0')) {
        (&file_tp)[sVar1] = 0;
        (&file_cp)[sVar1] = 0;
        wreq_len = 0;
      }
      calcrc(&DAT_01087959);
      calcs(&DAT_01087959);
      idc_req(&sbuff,0xa0);
    }
  }
  return;
}


// ==== cp_wsct @ 01031644

void cp_wsct(void)

{
  int iVar1;
  uint uVar2;
  
  if ((f_mode == 2) || (f_mode == 3)) {
    iVar1 = f_tcb * 0x34;
    if ((byte)(&DAT_01078638)[iVar1] < 2) {
      uVar2 = *(int *)(&DAT_01078656 + iVar1) << 9;
    }
    else {
      uVar2 = *(int *)(&DAT_01078656 + iVar1) << 7;
    }
    if ((f_mode == 3) && (uVar2 <= f_rp)) {
      set_wait(f_pno,*(undefined2 *)(&tbl_stim + f_pno * 2));
    }
    else {
      sbuff = 2;
      DAT_01087959 = 8;
      DAT_0108795a = 0x23;
      DAT_0108795b = 0x22;
      DAT_0108795d = (&DAT_01078638)[iVar1];
      DAT_0108795e = (undefined1)*(undefined2 *)(&DAT_0107865a + iVar1);
      DAT_0108795f = (undefined1)*(undefined2 *)(&DAT_01078652 + iVar1);
      DAT_01087960 = (char)*(undefined2 *)(&DAT_01078654 + iVar1);
      DAT_01087961 = (undefined1)*(undefined4 *)(&DAT_01078656 + iVar1);
      if (1 < (byte)(&DAT_01078638)[iVar1]) {
        DAT_01087960 = DAT_01087960 + '\x01';
      }
      setcrcs(&DAT_01087959,*(undefined4 *)(&DAT_01078660 + iVar1),&f_rp,uVar2);
      idc_req(&sbuff,0xa0);
    }
  }
  return;
}


// ==== setcrcs @ 01031758

void setcrcs(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  setdtcm3(param_1,param_2,param_3,param_4);
  calcrc(param_1);
  calcs(param_1);
  return;
}


// ==== setdtcm3 @ 0103178e

void setdtcm3(char *param_1,int param_2,int *param_3,int param_4)

{
  char cVar1;
  int iVar2;
  int iVar3;
  
  iVar3 = 0;
  if (param_4 != 0) {
    param_1[3] = '\0';
    if (*param_3 == 0) {
      param_1[3] = '\x01';
    }
    cVar1 = *param_1;
    iVar2 = 0xfe - cVar1;
    if (-(*param_3 - param_4) < iVar2) {
      iVar2 = param_4 - *param_3;
    }
    if (param_4 == 0) {
      param_1[3] = '\0';
    }
    else {
      iVar3 = 0;
      if (0 < iVar2) {
        do {
          param_1[iVar3 + 1 + (int)cVar1] = *(char *)(iVar3 + *param_3 + param_2);
          iVar3 = iVar3 + 1;
        } while (iVar3 < iVar2);
      }
      *param_1 = (char)iVar2 + *param_1;
    }
    iVar3 = *param_3 + iVar3;
    if (*param_3 == 0) {
      if (param_4 == iVar3) {
        param_1[3] = '\0';
      }
      else {
        param_1[3] = '\x01';
      }
    }
    else if (param_4 == iVar3) {
      param_1[3] = '\x02';
    }
    else {
      param_1[3] = '\x03';
    }
    *param_3 = iVar3;
  }
  return;
}


// ==== chkcrc @ 0103183e

void chkcrc(byte *param_1)

{
  undefined2 uVar1;
  int iVar2;
  uint uVar3;
  undefined2 unaff_D7w;
  
  uVar1 = 0;
  *param_1 = *param_1 - 2;
  uVar3 = (uint)*param_1;
  if (*param_1 == 0) {
    uVar3 = 0xfe;
  }
  iVar2 = 1;
  if (1 < uVar3 + 1) {
    do {
      crc16(uVar1,(int)(char)param_1[iVar2]);
      iVar2 = iVar2 + 1;
      uVar1 = unaff_D7w;
    } while (iVar2 < (int)(uVar3 + 1));
  }
  return;
}


// ==== chkcs @ 010318aa

void chkcs(byte *param_1)

{
  int iVar1;
  uint uVar2;
  
  *param_1 = *param_1 + 2;
  uVar2 = (uint)*param_1;
  if (*param_1 == 0) {
    uVar2 = 0x100;
  }
  iVar1 = 0;
  if (uVar2 != 0xffffffff) {
    do {
      iVar1 = iVar1 + 1;
    } while (iVar1 < (int)(uVar2 + 1));
  }
  return;
}


// ==== calcrc @ 010318f6

void calcrc(byte *param_1)

{
  int iVar1;
  uint uVar2;
  undefined2 unaff_D7w;
  undefined2 local_6;
  
  local_6 = 0;
  uVar2 = (uint)*param_1;
  if (*param_1 == 0) {
    uVar2 = 0xfe;
  }
  iVar1 = 1;
  if (1 < uVar2 + 1) {
    do {
      crc16(local_6,(int)(char)param_1[iVar1]);
      iVar1 = iVar1 + 1;
      local_6 = unaff_D7w;
    } while (iVar1 < (int)(uVar2 + 1));
  }
  param_1[iVar1] = local_6._0_1_;
  param_1[iVar1 + 1] = (byte)local_6;
  *param_1 = *param_1 + 2;
  return;
}


// ==== calcs @ 0103195c

void calcs(byte *param_1)

{
  int iVar1;
  uint uVar2;
  char cVar3;
  
  cVar3 = '\0';
  uVar2 = (uint)*param_1;
  if (*param_1 == 0) {
    uVar2 = 0x100;
  }
  iVar1 = 0;
  if (uVar2 != 0xffffffff) {
    do {
      cVar3 = param_1[iVar1] + cVar3;
      iVar1 = iVar1 + 1;
    } while (iVar1 < (int)(uVar2 + 1));
  }
  param_1[iVar1] = -cVar3;
  return;
}


// ==== spfset @ 0103199c

uint spfset(byte param_1,byte param_2)

{
  undefined4 in_D0;
  uint uVar1;
  
  if ((param_1 & 2) != 0) {
    *DAT_010414c4 = param_2 & 7;
  }
  uVar1 = CONCAT31((int3)((uint)in_D0 >> 8),DAT_0ff01fd7) & 0xfffffff0;
  if (((char)uVar1 == '\x10') ||
     (uVar1 = CONCAT31((int3)(uVar1 >> 8),DAT_0ff01fd7) & 0xfffffff0, (char)uVar1 == '0')) {
    uVar1 = (uint)*DAT_010414c8;
  }
  else {
    uVar1 = CONCAT31((int3)(uVar1 >> 8),*DAT_010414c8);
  }
  return uVar1;
}


// ==== spfled @ 01031a04

void spfled(int param_1)

{
  if (DAT_0107c518 != '\x01') {
    DAT_0107c514 = param_1;
    *DAT_010414c0 = (char)param_1;
    if (param_1 == 1) {
      timer(spfled,DAT_0107c510);
    }
  }
  return;
}


// ==== spfledoff @ 01031a42

void spfledoff(void)

{
  can_time(spfled);
  return;
}


// ==== FUN_01031a56 @ 01031a56

void FUN_01031a56(void)

{
  byte bVar1;
  
  if (DAT_0107c518 == '\x01') {
    timer(FUN_01031a56,DAT_0107c510);
  }
  bVar1 = ~(byte)DAT_0107c514;
  DAT_0107c514 = (uint)bVar1;
  *DAT_010414c0 = bVar1;
  return;
}


// ==== spfledbli @ 01031a94

void spfledbli(void)

{
  DAT_0107c518 = 1;
  FUN_01031a56();
  return;
}


// ==== spflednob @ 01031aaa

void spflednob(void)

{
  can_time(FUN_01031a56);
  DAT_0107c518 = 0;
  return;
}


// ==== _subtm @ 01031ac4

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void _subtm(char *param_1,char *param_2,char *param_3)

{
  char cVar1;
  char cVar2;
  int iVar3;
  uint unaff_D7;
  bool bVar4;
  
  if (_DAT_0107c51c == 0) {
    bitneg(&DAT_0f00b002);
    if ((unaff_D7 & 2) == 0) {
      _DAT_0107c520 = 0x1e;
    }
    else {
      _DAT_0107c520 = 0x19;
    }
    _DAT_0107c51c = 1;
  }
  cVar1 = param_1[3];
  cVar2 = param_2[3];
  param_3[3] = cVar1 - cVar2;
  bVar4 = (char)(cVar1 - cVar2) < '\0';
  if (bVar4) {
    param_3[3] = DAT_0107c523 + param_3[3];
  }
  iVar3 = 2;
  do {
    cVar1 = param_1[iVar3] - (bVar4 + param_2[iVar3]);
    param_3[iVar3] = cVar1;
    bVar4 = cVar1 < '\0';
    if (bVar4) {
      param_3[iVar3] = param_3[iVar3] + '<';
    }
    iVar3 = iVar3 + -1;
  } while (iVar3 != 0);
  cVar1 = *param_1 - (bVar4 + *param_2);
  *param_3 = cVar1;
  if (cVar1 < '\0') {
    *param_3 = *param_3 + '\x18';
  }
  return;
}


// ==== _syssetup @ 01031b74

void _syssetup(void)

{
  _initmmu();
  ctcinit();
  intinit();
  rtcinit();
  dmainit();
  sioint();
  ifdebug();
  tmupset();
  return;
}


// ==== tmupset @ 01031bac

void tmupset(void)

{
  uint unaff_D7;
  undefined *puVar1;
  
  bitneg(DAT_0f00b002);
  if ((unaff_D7 & 1) == 0) {
    puVar1 = &DAT_0107c524;
  }
  else {
    puVar1 = &DAT_0107c529;
  }
  cpybuf(puVar1,&ttb,4);
  return;
}


// ==== ctcportpu @ 01031bf8

undefined4 ctcportpu(int *param_1)

{
  for (; *param_1 != 0; param_1 = param_1 + 2) {
    *(char *)*param_1 = (char)param_1[1];
    intwait();
  }
  return 0;
}


// ==== rtcportpu @ 01031c1e

undefined4 rtcportpu(int *param_1)

{
  for (; *param_1 != 0; param_1 = param_1 + 2) {
    *(char *)*param_1 = (char)param_1[1];
    rtcwait();
  }
  return 0;
}


// ==== dmaportpu @ 01031c44

undefined4 dmaportpu(int *param_1)

{
  for (; *param_1 != 0; param_1 = param_1 + 2) {
    *(char *)*param_1 = (char)param_1[1];
    intwait();
  }
  return 0;
}


// ==== iwa_dmy @ 01031c6c

void iwa_dmy(void)

{
  fdcwait();
  return;
}


// ==== wait_sub @ 01031c7a

void wait_sub(int param_1,int param_2,int param_3)

{
  *(char *)(param_1 + 4) = (char)param_2;
  if (param_2 != 2) {
    if (param_2 < 3) {
      if (param_2 == 1) {
        if (param_3 == 0) {
          *(undefined1 *)(param_1 + 4) = 0;
        }
        else {
          *(int *)(param_1 + 0xe) = param_3;
        }
      }
    }
    else if (param_2 == 4) {
      *(char *)(param_1 + 5) = (char)param_3;
    }
  }
  return;
}


// ==== newgenq @ 01031cc2

void newgenq(undefined2 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  undefined4 *unaff_D7;
  
  getgenq();
  if (unaff_D7 != (undefined4 *)0x0) {
    *(undefined2 *)(unaff_D7 + 1) = param_1;
    *(undefined4 *)((int)unaff_D7 + 6) = param_3;
    *unaff_D7 = 0;
    *(undefined4 *)((int)unaff_D7 + 10) = param_2;
    *(undefined4 *)((int)unaff_D7 + 0xe) = param_2;
    *(undefined4 *)((int)unaff_D7 + 0x12) = param_4;
  }
  return;
}


// ==== _mrktset @ 01031d04

void _mrktset(int param_1)

{
  uint uVar1;
  int iVar2;
  uint uVar3;
  int *unaff_D7;
  
  uVar1 = *(uint *)(param_1 + 4);
  iVar2 = *(int *)(param_1 + 0xc);
  if (((byte)uVar1 < 2) && (-1 < iVar2)) {
    if ((char)*(uint *)(param_1 + 8) == '\0') {
      uVar3 = (uint)*(byte *)(etcb + 3);
    }
    else {
      uVar3 = *(uint *)(param_1 + 8) & 0xff;
    }
    gecb(uVar3);
    if ((unaff_D7 != (int *)0xfffffffc) && (-1 < *unaff_D7)) {
      wait_sub();
      newgenq(4,iVar2);
      clkqin(&g_lcb + (uVar1 & 0xff) * 8);
    }
  }
  return;
}


// ==== _redwat @ 01031dc8

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void _redwat(int param_1)

{
  int iVar1;
  int iVar2;
  int unaff_D7;
  
  day_clip(&daytim);
  if (unaff_D7 < 0) {
    daycalib(&daytim);
  }
  tim_clip(&daytim);
  if (unaff_D7 < 0) {
    timcalib(&daytim);
  }
  c_copy(*(undefined4 *)(param_1 + 4),&daytim,7);
  if (unaff_D7 < 0) {
    if (daytim < 'Q') {
      iVar1 = 2000;
    }
    else {
      iVar1 = 0x76c;
    }
    iVar1 = daytim + iVar1;
    iVar2 = iVar1;
    if (iVar1 < 0) {
      iVar2 = iVar1 + 3;
    }
    _watsts = -(((ushort)iVar2 & 0xfffc) - (short)iVar1) | 0x10;
  }
  return;
}


// ==== _setwat @ 01031e76

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void _setwat(int param_1)

{
  char *pcVar1;
  int iVar2;
  int iVar3;
  int unaff_D7;
  
  pcVar1 = *(char **)(param_1 + 4);
  daytim = *pcVar1;
  DAT_01075246 = pcVar1[1];
  DAT_01075247 = pcVar1[2];
  DAT_01075248 = pcVar1[3];
  DAT_01075249 = pcVar1[4];
  DAT_0107524a = pcVar1[5];
  DAT_0107524b = pcVar1[6];
  day_clip(&daytim);
  if (unaff_D7 < 0) {
    daycalib(&daytim);
  }
  tim_clip(&daytim);
  if (unaff_D7 < 0) {
    timcalib(&daytim);
  }
  if (daytim < 'Q') {
    iVar2 = 2000;
  }
  else {
    iVar2 = 0x76c;
  }
  iVar2 = daytim + iVar2;
  iVar3 = iVar2;
  if (iVar2 < 0) {
    iVar3 = iVar2 + 3;
  }
  _watsts = -(((ushort)iVar3 & 0xfffc) - (short)iVar2) | 0x10;
  return;
}


// ==== newdateq @ 01031f0e

void newdateq(undefined2 param_1,undefined1 *param_2,undefined4 param_3)

{
  undefined4 *unaff_D7;
  
  getdateq();
  if (unaff_D7 != (undefined4 *)0x0) {
    *(undefined2 *)(unaff_D7 + 1) = param_1;
    *(undefined4 *)((int)unaff_D7 + 6) = param_3;
    *unaff_D7 = 0;
    *(undefined1 *)((int)unaff_D7 + 10) = *param_2;
    *(undefined1 *)((int)unaff_D7 + 0xb) = param_2[1];
    *(undefined1 *)(unaff_D7 + 3) = param_2[2];
    *(undefined1 *)((int)unaff_D7 + 0xd) = param_2[3];
    *(undefined1 *)((int)unaff_D7 + 0xe) = param_2[4];
    *(undefined1 *)((int)unaff_D7 + 0xf) = param_2[5];
    *(undefined1 *)(unaff_D7 + 4) = param_2[6];
  }
  return;
}


// ==== _waitwh @ 01031f58

void _waitwh(int param_1)

{
  char cVar1;
  int unaff_D7;
  
  cVar1 = (char)*(undefined4 *)(param_1 + 4);
  if (cVar1 == '\0') {
    cVar1 = *(char *)(etcb + 3);
  }
  gecb(cVar1);
  newdateq(2,*(undefined4 *)(param_1 + 8));
  if (unaff_D7 != -4) {
    *(byte *)(unaff_D7 + 4) = *(byte *)(unaff_D7 + 4) | 2;
    wait_sub();
    clkqin(&t2_lcb);
    if ((-1 < unaff_D7) && (ev_ret(), unaff_D7 == 0)) {
      sv_cntxt();
    }
  }
  return;
}


// ==== _can_wat @ 0103200e

void _can_wat(int param_1)

{
  undefined1 uVar1;
  uint *unaff_D7;
  
  if (*(int *)(param_1 + 4) == 0) {
    uVar1 = *(undefined1 *)(etcb + 3);
  }
  else {
    uVar1 = (undefined1)*(undefined4 *)(param_1 + 4);
  }
  gecb(uVar1);
  if (unaff_D7 != (uint *)0xfffffffc) {
    *unaff_D7 = *unaff_D7 & 0xfeffffff;
    clkqout(&t2_lcb);
    if (0 < (int)unaff_D7) {
      *(undefined2 *)(unaff_D7 + 1) = 0;
    }
  }
  return;
}


// ==== _can_ftim @ 01032080

void _can_ftim(void)

{
  gecb(*(undefined1 *)(etcb + 3));
  if (*(char *)(etcb + 3) == '2') {
    iwanagalo = iwanagalo + -1;
  }
  can_ft();
  return;
}


// ==== newtimeq @ 010320c0

void newtimeq(undefined2 param_1,undefined4 param_2,undefined4 param_3)

{
  undefined4 *unaff_D7;
  
  gettimeq();
  if (unaff_D7 != (undefined4 *)0x0) {
    *(undefined2 *)(unaff_D7 + 1) = param_1;
    *(undefined4 *)((int)unaff_D7 + 6) = param_3;
    *unaff_D7 = 0;
    *(undefined4 *)((int)unaff_D7 + 10) = param_2;
    *(undefined4 *)((int)unaff_D7 + 0xe) = param_2;
  }
  return;
}


// ==== _timef @ 010320fc

void _timef(int param_1)

{
  int iVar1;
  int *unaff_D7;
  
  iVar1 = *(int *)(param_1 + 4);
  if (-1 < iVar1) {
    if ((*(char *)(etcb + 3) == '2') && (iwanagalo = iwanagalo + 1, 1 < iwanagalo)) {
      iwa_dmy();
    }
    gecb(*(undefined1 *)(etcb + 3));
    if ((unaff_D7 != (int *)0xfffffffc) && (-1 < *unaff_D7)) {
      newtimeq(0x8000,iVar1);
      clkqin(&t3_lcb);
    }
  }
  return;
}


// ==== _ggtim @ 01032198

undefined4 _ggtim(int param_1)

{
  undefined4 uVar1;
  
  if ((byte)*(uint *)(param_1 + 4) < 2) {
    if (*(int *)(&DAT_0107529e + (*(uint *)(param_1 + 4) & 0xff) * 6) == 0) {
      uVar1 = 0xfffffff4;
    }
    else {
      c_copy(*(undefined4 *)(param_1 + 8),
             *(int *)(&DAT_0107529e + (*(uint *)(param_1 + 4) & 0xff) * 6),4);
      uVar1 = 0;
    }
  }
  else {
    uVar1 = 0xfffffff9;
  }
  return uVar1;
}


// ==== _mrktm @ 010321f0

void _mrktm(undefined4 param_1,undefined4 param_2)

{
  _mrktset(param_1,param_2);
  return;
}


// ==== day_clip @ 0103220e

void day_clip(void)

{
  return;
}


// ==== tim_clip @ 01032218

undefined4 tim_clip(int param_1)

{
  undefined4 uVar1;
  
  if ((*(char *)(param_1 + 4) < '\0') || ('\x17' < *(char *)(param_1 + 4))) {
    uVar1 = 0xffffffff;
  }
  else if ((*(char *)(param_1 + 5) < '\0') || (';' < *(char *)(param_1 + 5))) {
    uVar1 = 0xfffffffe;
  }
  else if ((*(char *)(param_1 + 6) < '\0') || (';' < *(char *)(param_1 + 6))) {
    uVar1 = 0xfffffffd;
  }
  else {
    uVar1 = 0;
  }
  return uVar1;
}


// ==== daycalib @ 01032264

void daycalib(undefined1 *param_1)

{
  *param_1 = DAT_0107c874;
  param_1[1] = DAT_0107c875;
  param_1[2] = DAT_0107c876;
  param_1[3] = DAT_0107c877;
  return;
}


// ==== timcalib @ 01032290

void timcalib(int param_1)

{
  *(undefined1 *)(param_1 + 4) = DAT_0107c878;
  *(undefined1 *)(param_1 + 5) = DAT_0107c879;
  *(undefined1 *)(param_1 + 6) = DAT_0107c87a;
  return;
}


// ==== ev_ret @ 010322b4

void ev_ret(uint *param_1)

{
  uint uVar1;
  
  uVar1 = *param_1;
  *(undefined4 *)(etcb + 0xc) = 0;
  if ((uVar1 & 0x7fffffff) != 0) {
    *param_1 = 0;
  }
  return;
}


// ==== sv_cntxt @ 010322da

void sv_cntxt(undefined4 *param_1,undefined4 param_2,byte param_3)

{
  ushort *puVar1;
  
  puVar1 = etcb;
  *param_1 = 0x80000000;
  *(ushort **)((int)param_1 + 6) = puVar1;
  puVar1[6] = 0;
  puVar1[7] = 0;
  *(undefined4 *)(puVar1 + 0x1c) = param_2;
  *puVar1 = *puVar1 & 0xfff0;
  *puVar1 = *puVar1 | (ushort)param_3;
  return;
}


// ==== can_ft @ 01032316

undefined4 can_ft(uint *param_1)

{
  undefined4 uVar1;
  int unaff_D7;
  
  if (t3_lcb == 0) {
    uVar1 = 0;
  }
  else {
    *param_1 = *param_1 & 0xbfffffff;
    uVar1 = clkqout(&t3_lcb,param_1,can_qout);
    if (0 < unaff_D7) {
      *(undefined2 *)(unaff_D7 + 4) = 0;
    }
  }
  return uVar1;
}


// ==== dateqin @ 01032356

void dateqin(int param_1,int param_2)

{
  datecmp(param_1 + 10,param_2 + 10);
  return;
}


// ==== getdateq @ 01032374

short getdateq(void)

{
  short sVar1;
  int iVar2;
  undefined *puVar3;
  
  iVar2 = 0x20;
  puVar3 = &dateqm;
  do {
    sVar1 = *(short *)(puVar3 + 4);
    if (*(short *)(puVar3 + 4) == 0) {
      return sVar1;
    }
    puVar3 = puVar3 + 0x12;
    iVar2 = iVar2 + -1;
  } while (iVar2 != 0);
  return sVar1;
}


// ==== can_qout @ 01032398

undefined4 can_qout(int param_1,int param_2)

{
  return CONCAT31((int3)((uint)*(int *)(param_1 + 6) >> 8),-(*(int *)(param_1 + 6) == param_2));
}


// ==== abstqin @ 010323b2

void abstqin(int param_1,int param_2)

{
  bntccmp(*(undefined4 *)(param_2 + 10),*(undefined4 *)(param_1 + 10),
          **(undefined1 **)(param_1 + 0x12));
  return;
}


// ==== getgenq @ 010323dc

short getgenq(void)

{
  short sVar1;
  int iVar2;
  undefined *puVar3;
  
  iVar2 = 8;
  puVar3 = &genqm;
  do {
    sVar1 = *(short *)(puVar3 + 4);
    if (*(short *)(puVar3 + 4) == 0) {
      return sVar1;
    }
    puVar3 = puVar3 + 0x16;
    iVar2 = iVar2 + -1;
  } while (iVar2 != 0);
  return sVar1;
}


// ==== gettimeq @ 01032400

short gettimeq(void)

{
  short sVar1;
  int iVar2;
  undefined *puVar3;
  
  iVar2 = 0x20;
  puVar3 = &timeqm;
  do {
    sVar1 = *(short *)(puVar3 + 4);
    if (*(short *)(puVar3 + 4) == 0) {
      return sVar1;
    }
    puVar3 = puVar3 + 0x12;
    iVar2 = iVar2 + -1;
  } while (iVar2 != 0);
  return sVar1;
}


// ==== in_month @ 01032424

undefined4 in_month(byte *param_1)

{
  undefined3 uVar1;
  byte bVar3;
  int iVar2;
  uint uVar4;
  
  bVar3 = *param_1;
  if ((char)bVar3 < '\0') {
    bVar3 = bVar3 + 3;
  }
  iVar2 = (int)(char)param_1[1];
  if (iVar2 == 2) {
    uVar4 = ((byte)-(*param_1 == (bVar3 & 0xfc)) & 1) + (uint)DAT_0107c87d;
    uVar1 = 0;
  }
  else {
    uVar1 = (undefined3)((uint)iVar2 >> 8);
    uVar4 = (uint)(byte)(&DAT_0107c87b)[iVar2];
  }
  return CONCAT31(uVar1,-((int)(char)param_1[2] <= (int)uVar4));
}


// ==== datecmp @ 01032484

undefined4 datecmp(char *param_1,char *param_2)

{
  undefined4 uVar1;
  
  if ((*param_1 < *param_2) ||
     ((*param_1 <= *param_2 &&
      ((param_1[1] < param_2[1] ||
       ((param_1[1] <= param_2[1] &&
        ((param_1[2] < param_2[2] ||
         ((param_1[2] <= param_2[2] &&
          ((param_1[4] < param_2[4] ||
           ((param_1[4] <= param_2[4] &&
            ((param_1[5] < param_2[5] ||
             ((param_1[5] <= param_2[5] && ((param_1[6] < param_2[6] || (param_1[6] <= param_2[6])))
              ))))))))))))))))))) {
    uVar1 = 1;
  }
  else {
    uVar1 = 0;
  }
  return uVar1;
}


// ==== rtcinit @ 01032526

void rtcinit(void)

{
  rtcportpu(&DAT_0107c888);
  return;
}


// ==== _timer @ 0103253a

void _timer(undefined4 param_1,undefined4 param_2)

{
  newtimeq(0x8000,param_2,param_1);
  clkqin(&t1_lcb);
  return;
}


// ==== _can_tim @ 0103256a

void _can_tim(undefined4 param_1)

{
  int unaff_D7;
  
  clkqout(&t1_lcb,param_1,can_qout);
  if (0 < unaff_D7) {
    *(undefined2 *)(unaff_D7 + 4) = 0;
  }
  return;
}


// ==== _timset @ 01032596

undefined4 _timset(int param_1)

{
  int iVar1;
  undefined4 uVar2;
  undefined4 unaff_D7;
  
  iVar1 = (*(uint *)(param_1 + 4) & 0xff) * 6;
  if ((byte)*(uint *)(param_1 + 4) < 2) {
    if (**(int **)(param_1 + 0xc) < 0) {
      (&gentim)[iVar1] = 0;
      *(undefined4 *)(&DAT_0107529e + iVar1) = 0;
      uVar2 = 0xfffffff4;
    }
    else {
      (&gentim)[iVar1] = (char)*(undefined4 *)(param_1 + 8);
      latopa(*(undefined1 *)(etcb + 3),*(undefined4 *)(param_1 + 0xc));
      *(undefined4 *)(&DAT_0107529e + iVar1) = unaff_D7;
      uVar2 = 0;
    }
  }
  else {
    uVar2 = 0xfffffff9;
  }
  return uVar2;
}


// ==== _tmwait @ 01032610

void _tmwait(undefined4 param_1,undefined4 param_2)

{
  int unaff_D7;
  
  _mrktset(param_1,param_2);
  if ((0 < unaff_D7) && (ev_ret(), unaff_D7 == 0)) {
    sv_cntxt();
  }
  return;
}


// ==== _tmcan @ 0103265a

void _tmcan(int param_1)

{
  uint uVar1;
  undefined1 uVar2;
  uint *unaff_D7;
  
  uVar1 = *(uint *)(param_1 + 4);
  if ((byte)uVar1 < 2) {
    if (*(int *)(param_1 + 8) == 0) {
      uVar2 = *(undefined1 *)(etcb + 3);
    }
    else {
      uVar2 = (undefined1)*(undefined4 *)(param_1 + 8);
    }
    gecb(uVar2);
    if (unaff_D7 != (uint *)0xfffffffc) {
      *unaff_D7 = *unaff_D7 & 0xfdffffff;
      clkqout(&g_lcb + (uVar1 & 0xff) * 8);
      if (0 < (int)unaff_D7) {
        *(undefined2 *)(unaff_D7 + 1) = 0;
      }
    }
  }
  return;
}


// ==== _alarm @ 010326e6

void _alarm(int param_1)

{
  int iVar1;
  int *unaff_D7;
  
  iVar1 = *(int *)(param_1 + 4);
  if (((-1 < iVar1) && (gecb(*(undefined1 *)(etcb + 3)), unaff_D7 != (int *)0xfffffffc)) &&
     (-1 < *unaff_D7)) {
    newtimeq(0x8000,iVar1);
    clkqin(&alrm_lcb);
  }
  return;
}


// ==== _can_alrm @ 0103275c

void _can_alrm(void)

{
  uint *unaff_D7;
  
  gecb(*(undefined1 *)(etcb + 3));
  *unaff_D7 = *unaff_D7 & 0xbfffffff;
  clkqout(&alrm_lcb);
  if (0 < (int)unaff_D7) {
    *(undefined2 *)(unaff_D7 + 1) = 0;
  }
  return;
}


// ==== _setutime @ 010327b0

void _setutime(undefined4 param_1,int param_2)

{
  tv_sec = param_1;
  tv_usec = param_2 / 10000;
  tv_flag = 1;
  return;
}


// ==== _getutime @ 010327da

void _getutime(undefined4 *param_1,int *param_2)

{
  if (tv_flag != 0) {
    *param_1 = tv_sec;
    *param_2 = tv_usec * 10000;
  }
  return;
}


// ==== _tstecb @ 01032810

void _tstecb(int param_1)

{
  uint uVar1;
  
  if (*(int *)(param_1 + 4) == 0) {
    uVar1 = (uint)*(byte *)(etcb + 3);
  }
  else {
    uVar1 = *(uint *)(param_1 + 4);
  }
  gecb(uVar1);
  return;
}


// ==== _tup1req @ 0103284c

uint _tup1req(void)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  int unaff_D7;
  
  if ((tv_flag == 1) && (tv_usec = tv_usec + 1, 99 < tv_usec)) {
    tv_usec = 0;
    tv_sec = tv_sec + 1;
  }
  _tupck();
  uVar3 = _alupck();
  iVar2 = etcb;
  for (iVar1 = t0_lcb; etcb = iVar2, iVar1 != 0; iVar1 = *(int *)(iVar1 + 10)) {
    *(int *)(iVar1 + 0xe) = *(int *)(iVar1 + 0xe) + -1;
    uVar3 = *(uint *)(iVar1 + 0xe);
    if (((int)uVar3 < 1) && (uVar3 = post_sub(iVar1,0x40000000), unaff_D7 != 0)) {
      uVar3 = qin();
    }
    iVar2 = etcb;
  }
  if ((mflag == 1) && (uVar3 = (uint)*(byte *)(iVar2 + 2), *(byte *)(iVar2 + 2) == 0)) {
    *(int *)(iVar2 + 0xc) = *(int *)(iVar2 + 0xc) + -1;
    uVar3 = *(uint *)(iVar2 + 0xc);
    if (uVar3 == 0) {
      mflag = 2;
    }
  }
  return uVar3;
}


// ==== _tup2req @ 010328fe

void _tup2req(void)

{
  int iVar1;
  undefined *puVar2;
  undefined *puVar3;
  
  _fcupck();
  iVar1 = 0;
  puVar2 = &g_lcb;
  puVar3 = &gentim;
  do {
    _gupck(puVar2,puVar3);
    iVar1 = iVar1 + 1;
    puVar2 = puVar2 + 8;
    puVar3 = puVar3 + 6;
  } while (iVar1 < 1);
  return;
}


// ==== _tup3req @ 0103293e

void _tup3req(void)

{
  int unaff_D7;
  
  wr_wat();
  if (unaff_D7 != 1) {
    rd_wat();
    while( true ) {
      clkqout(&t2_lcb,&daytim,dateqout);
      if (unaff_D7 < 1) break;
      *(undefined2 *)(unaff_D7 + 4) = 0;
      post_sub(*(undefined4 *)(unaff_D7 + 6),0x1000000);
      if (unaff_D7 != 0) {
        qin();
      }
    }
  }
  return;
}


// ==== _tupck @ 010329b0

void _tupck(void)

{
  int unaff_D7;
  
  *(int *)(t1_lcb + 0xe) = *(int *)(t1_lcb + 0xe) + -1;
  while( true ) {
    clkqout(&t1_lcb,0,timeqout);
    if (unaff_D7 < 1) break;
    *(undefined2 *)(unaff_D7 + 4) = 0;
    _mskon();
    (**(code **)(unaff_D7 + 6))(1);
    _mskoff();
  }
  return;
}


// ==== _alupck @ 01032a0c

void _alupck(void)

{
  int unaff_D7;
  
  *(int *)(alrm_lcb + 0xe) = *(int *)(alrm_lcb + 0xe) + -1;
  while( true ) {
    clkqout(&alrm_lcb,0,timeqout);
    if (unaff_D7 < 1) break;
    *(undefined2 *)(unaff_D7 + 4) = 0;
    post_sub(*(undefined4 *)(unaff_D7 + 6),0x40000000);
    if (unaff_D7 != 0) {
      qin();
    }
  }
  return;
}


// ==== post_sub @ 01032a6e

void post_sub(uint *param_1,uint param_2)

{
  uint uVar1;
  
  uVar1 = *param_1;
  if ((int)uVar1 < 0) {
    *param_1 = 0;
    tqout(param_1,&t0_lcb);
    *(undefined4 *)((int)param_1 + 0xe) = 0;
    *(uint *)(*(int *)(*(int *)((int)param_1 + 6) + 0x38) + 0x20) =
         param_2 & 0x7fffffff | uVar1 & 0x7fffffff;
  }
  else {
    *param_1 = param_2 & 0x7fffffff | *param_1;
  }
  return;
}


// ==== _fcupck @ 01032aca

void _fcupck(void)

{
  int unaff_D7;
  
  if (t3_lcb != 0) {
    *(int *)(t3_lcb + 0xe) = *(int *)(t3_lcb + 0xe) + -1;
    while( true ) {
      clkqout(&t3_lcb,0,timeqout);
      if (unaff_D7 < 1) break;
      post_sub(*(undefined4 *)(unaff_D7 + 6),0x40000000);
      if (unaff_D7 != 0) {
        qin();
      }
      *(undefined4 *)(unaff_D7 + 0xe) = *(undefined4 *)(unaff_D7 + 10);
      clkqin(&t3_lcb);
    }
  }
  return;
}


// ==== _gupck @ 01032b4a

void _gupck(undefined4 param_1,undefined4 param_2)

{
  int unaff_D7;
  
  geninc(param_2);
  while (clkqout(param_1,param_2,genqout), 0 < unaff_D7) {
    *(undefined2 *)(unaff_D7 + 4) = 0;
    post_sub(*(undefined4 *)(unaff_D7 + 6),0x2000000);
    if (unaff_D7 != 0) {
      qin();
    }
  }
  return;
}


// ==== wr_wat @ 01032bba

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void wr_wat(void)

{
  char cVar1;
  uint uVar2;
  char cVar3;
  char *pcVar4;
  char *pcVar5;
  
  pcVar4 = "\r\x01\n\x01\v";
  if ((_watsts & 0x10) != 0) {
    wr_rtc(0xe,0);
    cVar3 = DAT_01032bae;
    while (cVar3 != '\0') {
      if (*pcVar4 == '\v') {
        uVar2 = (uint)(char)(DAT_01075a6b & 0xef);
      }
      else {
        uVar2 = (uint)(byte)pcVar4[1];
      }
      wr_rtc(*pcVar4,uVar2);
      pcVar4 = pcVar4 + 2;
      cVar3 = *pcVar4;
    }
    cVar3 = '\0';
    pcVar4 = &DAT_0107524b;
    do {
      wr_rtc((int)cVar3,(int)(char)((int)(short)*pcVar4 % 10));
      pcVar5 = pcVar4 + -1;
      wr_rtc((int)(char)(cVar3 + '\x01'),(int)(char)((int)(short)*pcVar4 / 10));
      cVar1 = cVar3 + '\x02';
      if ((char)(cVar3 + '\x02') == '\x06') {
        cVar1 = *pcVar5;
        pcVar5 = pcVar4 + -2;
        wr_rtc(6,(int)cVar1);
        cVar1 = cVar3 + '\x03';
      }
      cVar3 = cVar1;
      pcVar4 = pcVar5;
    } while (cVar3 < '\f');
    _watsts = 0x20;
    wr_rtc(0xd,8);
    wr_rtc(0xf,5);
  }
  return;
}


// ==== rd_wat @ 01032cb8

void rd_wat(void)

{
  int iVar1;
  int iVar2;
  char unaff_D7b;
  char *pcVar3;
  char *pcVar4;
  
  wr_rtc(0xe,0);
  wr_rtc(0xd,0);
  rd_rtc(0);
  DAT_0107524b = unaff_D7b;
  rd_rtc(1);
  DAT_0107524b = DAT_0107524b + unaff_D7b * '\n';
  iVar1 = 2;
  pcVar3 = &DAT_0107524a;
  do {
    rd_rtc(iVar1);
    *pcVar3 = unaff_D7b;
    iVar2 = iVar1 + 2;
    rd_rtc(iVar1 + 1);
    *pcVar3 = *pcVar3 + unaff_D7b * '\n';
    pcVar4 = pcVar3 + -1;
    if (iVar2 == 6) {
      iVar2 = iVar1 + 3;
      rd_rtc(6);
      *pcVar4 = unaff_D7b;
      pcVar4 = pcVar3 + -2;
    }
    iVar1 = iVar2;
    pcVar3 = pcVar4;
  } while (iVar2 < 0xc);
  wr_rtc(0xd,8);
  wr_rtc(0xf,5);
  return;
}


// ==== reltqin @ 01032d7e

void reltqin(int param_1,int param_2)

{
  if (*(int *)(param_1 + 0xe) < *(int *)(param_2 + 0xe)) {
    *(int *)(param_2 + 0xe) = *(int *)(param_2 + 0xe) - *(int *)(param_1 + 0xe);
  }
  else {
    *(int *)(param_1 + 0xe) = *(int *)(param_1 + 0xe) - *(int *)(param_2 + 0xe);
  }
  return;
}


// ==== tqout @ 01032dc0

void tqout(int param_1,int *param_2)

{
  int iVar1;
  int iVar2;
  
  iVar1 = 0;
  for (iVar2 = *param_2; (iVar2 != 0 && (param_1 != iVar2)); iVar2 = *(int *)(iVar2 + 10)) {
    iVar1 = iVar2;
  }
  if (iVar2 != 0) {
    if (iVar1 == 0) {
      iVar2 = *(int *)(iVar2 + 10);
      *param_2 = iVar2;
    }
    else {
      iVar2 = *(int *)(iVar2 + 10);
      *(int *)(iVar1 + 10) = iVar2;
    }
    if (iVar2 == 0) {
      param_2[1] = iVar1;
    }
  }
  return;
}


// ==== clkqin @ 01032e0c

void clkqin(undefined4 *param_1,undefined4 *param_2,code *param_3)

{
  undefined4 *puVar1;
  int unaff_D7;
  undefined4 *puVar2;
  undefined4 *puVar3;
  
  puVar1 = (undefined4 *)*param_1;
  puVar3 = (undefined4 *)0x0;
  if (param_2 != (undefined4 *)0x0) {
    while ((puVar2 = puVar1, puVar2 != (undefined4 *)0x0 &&
           ((*param_3)(param_2,puVar2), unaff_D7 == 0))) {
      puVar1 = (undefined4 *)*puVar2;
      puVar3 = puVar2;
    }
    *param_2 = puVar2;
    if (puVar3 == (undefined4 *)0x0) {
      *param_1 = param_2;
    }
    else {
      *puVar3 = param_2;
    }
    if (puVar2 == (undefined4 *)0x0) {
      param_1[1] = param_2;
    }
  }
  return;
}


// ==== clkqout @ 01032e6e

void clkqout(int *param_1,undefined4 param_2,code *param_3)

{
  int *piVar1;
  int *piVar2;
  int in_D0;
  int iVar3;
  int unaff_D7;
  
  piVar1 = (int *)0x0;
  piVar2 = (int *)*param_1;
  while ((piVar2 != (int *)0x0 && ((*param_3)(piVar2,param_2), in_D0 = unaff_D7, unaff_D7 == 0))) {
    piVar1 = piVar2;
    piVar2 = (int *)*piVar2;
  }
  if ((piVar2 != (int *)0x0) && (in_D0 != -0x80000000)) {
    if (piVar1 == (int *)0x0) {
      iVar3 = *piVar2;
      *param_1 = iVar3;
    }
    else {
      iVar3 = *piVar2;
      *piVar1 = iVar3;
    }
    if (iVar3 == 0) {
      param_1[1] = (int)piVar1;
    }
  }
  return;
}


// ==== geninc @ 01032ed2

void geninc(undefined1 *param_1)

{
  undefined4 unaff_D7;
  
  bntcplsn(**(undefined4 **)(param_1 + 2),1,*param_1);
  **(undefined4 **)(param_1 + 2) = unaff_D7;
  return;
}


// ==== rd_rtc @ 01032f02

byte rd_rtc(int param_1)

{
  rtcwait();
  return *(byte *)(param_1 + 0xf006000) & 0xf;
}


// ==== wr_rtc @ 01032f2a

void wr_rtc(int param_1,byte param_2)

{
  rtcwait();
  *(byte *)(param_1 + 0xf006000) = param_2 & 0xf;
  return;
}


// ==== dateqout @ 01032f52

undefined4 dateqout(int param_1,undefined4 param_2)

{
  undefined4 uVar1;
  int unaff_D7;
  
  datecmp(param_1 + 10,param_2);
  if (unaff_D7 == 1) {
    uVar1 = 1;
  }
  else {
    uVar1 = 0x80000000;
  }
  return uVar1;
}


// ==== timeqout @ 01032f7e

undefined4 timeqout(int param_1,int param_2)

{
  undefined4 uVar1;
  
  if (param_2 < *(int *)(param_1 + 0xe)) {
    uVar1 = 0x80000000;
  }
  else {
    uVar1 = 1;
  }
  return uVar1;
}


// ==== genqout @ 01032fa0

undefined4 genqout(int param_1,undefined1 *param_2)

{
  undefined4 uVar1;
  int unaff_D7;
  
  bntccmp(**(undefined4 **)(param_2 + 2),*(undefined4 *)(param_1 + 10),*param_2);
  if (unaff_D7 == 1) {
    uVar1 = 1;
  }
  else {
    uVar1 = 0x80000000;
  }
  return uVar1;
}


// ==== fieldint @ 01032fda

void fieldint(void)

{
  if ((*DAT_010414c8 & 0x40) != 0) {
    _tup2req();
  }
  return;
}


// ==== noServe @ 01032ff6

void noServe(void)

{
  return;
}


// ==== f_fileio @ 01033008

int f_fileio(undefined1 param_1)

{
  int iVar1;
  short sVar2;
  int unaff_D7;
  int iVar3;
  
  gtcb(param_1);
  iVar1 = *(int *)(unaff_D7 + 0x4a);
  iVar3 = iVar1 + 0x42;
  sVar2 = 3;
  do {
    iVar1 = CONCAT31((int3)((uint)iVar1 >> 8),*(char *)(iVar3 + 0xd));
    if (*(char *)(iVar3 + 0xd) == '\0') {
      *(undefined1 *)(iVar3 + 0xd) = 1;
      return iVar1;
    }
    sVar2 = sVar2 + 1;
    iVar3 = iVar3 + 0x16;
  } while (sVar2 < 0xc);
  return iVar1;
}


// ==== u_fcb @ 01033050

void u_fcb(void)

{
  return;
}


// ==== u_fnchk @ 01033076

void u_fnchk(int param_1)

{
  int unaff_D7;
  
  u_fnck(param_1,8);
  if (-1 < unaff_D7) {
    u_fnck(param_1 + 8,3);
  }
  return;
}


// ==== u_fnck @ 010330b0

void u_fnck(char *param_1,int param_2)

{
  bool bVar1;
  int iVar2;
  int unaff_D7;
  
  bVar1 = false;
  iVar2 = 0;
  while( true ) {
    while( true ) {
      if (param_2 <= iVar2) {
        return;
      }
      iVar2 = iVar2 + 1;
      if (*param_1 != ' ') break;
      bVar1 = true;
      param_1 = param_1 + 1;
    }
    if (bVar1) break;
    u_fnlit((int)*param_1);
    param_1 = param_1 + 1;
    if (unaff_D7 == 0) {
      return;
    }
  }
  return;
}


// ==== u_fnlit @ 010330fc

void u_fnlit(void)

{
  return;
}


// ==== u_opnmod @ 0103317a

void u_opnmod(void)

{
  return;
}


// ==== u_opnmsk @ 010331a6

void u_opnmsk(undefined4 param_1)

{
  u_opnmod(param_1);
  return;
}


// ==== u_clrfcb @ 010331d4

void u_clrfcb(undefined4 *param_1,undefined1 param_2,undefined1 param_3)

{
  param_1[1] = 0;
  param_1[2] = 0;
  param_1[3] = 0;
  *param_1 = 0;
  *(undefined1 *)((int)param_1 + 0x26) = 0;
  *(undefined1 *)((int)param_1 + 0x27) = param_2;
  *(undefined1 *)(param_1 + 10) = param_3;
  *(undefined1 *)(param_1 + 5) = 0;
  *(undefined1 *)((int)param_1 + 0x15) = 0;
  return;
}


// ==== u_dirofct @ 0103320a

byte u_dirofct(byte *param_1,undefined4 param_2)

{
  byte bVar1;
  byte unaff_D7b;
  
  u_opnmsk(param_2);
  bVar1 = *param_1;
  if ((bVar1 != 0xe5) && (bVar1 != 0)) {
    bVar1 = unaff_D7b & param_1[0xb];
  }
  return bVar1;
}


// ==== u_scanent @ 01033252

void u_scanent(int param_1,undefined4 param_2,undefined4 param_3)

{
  short sVar1;
  int iVar2;
  int iVar3;
  int unaff_D7;
  
  sVar1 = *(short *)(*(int *)(param_1 + 8) + 0x14);
  iVar2 = *(int *)(param_1 + 0x10);
  iVar3 = 0;
  do {
    if (sVar1 <= iVar3) {
      return;
    }
    u_dirofct(iVar2,param_3);
    if (unaff_D7 != 0) {
      if (unaff_D7 < 0) {
        return;
      }
      cmpbuf(param_2,iVar2,0xb);
      if (unaff_D7 == 1) {
        return;
      }
    }
    iVar3 = iVar3 + 1;
    iVar2 = iVar2 + 0x20;
  } while( true );
}


// ==== u_nwfcb @ 010332c2

char u_nwfcb(undefined1 param_1,undefined1 param_2)

{
  int iVar1;
  char cVar2;
  undefined *puVar3;
  
  puVar3 = &u_fcbtbl;
  iVar1 = 0;
  do {
    cVar2 = puVar3[0x27];
    if (cVar2 == '\0') break;
    puVar3 = puVar3 + 0x2a;
    iVar1 = iVar1 + 1;
  } while (iVar1 < 0xc);
  if (iVar1 < 0xc) {
    u_clrfcb(puVar3,param_1,param_2);
    cVar2 = (char)iVar1;
    puVar3[0x26] = cVar2;
  }
  return cVar2;
}


// ==== u_setfcb @ 0103331c

void u_setfcb(int param_1,undefined4 param_2,undefined4 param_3)

{
  *(undefined4 *)(param_1 + 8) = param_3;
  *(undefined4 *)(param_1 + 4) = param_2;
  return;
}


// ==== u_fcbqin @ 01033334

void u_fcbqin(undefined4 *param_1)

{
  int *piVar1;
  undefined4 *puVar2;
  
  piVar1 = (int *)param_1[1];
  puVar2 = (undefined4 *)piVar1[1];
  if (param_1 != (undefined4 *)0x0) {
    *param_1 = 0;
    if (*piVar1 == 0) {
      piVar1[1] = (int)param_1;
      *piVar1 = (int)param_1;
    }
    else {
      *puVar2 = param_1;
      piVar1[1] = (int)param_1;
    }
  }
  return;
}


// ==== u_fcbqout @ 01033360

void u_fcbqout(int *param_1)

{
  int iVar1;
  int *piVar2;
  int *piVar3;
  int *piVar4;
  int *piVar5;
  int *piVar6;
  
  piVar2 = (int *)param_1[1];
  piVar6 = (int *)0x0;
  if (((param_1 != (int *)0x0) && (piVar2 != (int *)0x0)) &&
     (piVar3 = piVar2, piVar5 = (int *)*piVar2, (int *)*piVar2 != (int *)0x0)) {
    while (piVar4 = piVar5, param_1 != piVar4) {
      piVar3 = piVar4;
      piVar6 = piVar4;
      piVar5 = (int *)*piVar4;
    }
    iVar1 = *piVar4;
    *piVar3 = iVar1;
    if (iVar1 == 0) {
      piVar2[1] = (int)piVar6;
    }
  }
  return;
}


// ==== u_create @ 010333a4

void u_create(undefined1 param_1,undefined1 param_2,undefined4 param_3,short param_4)

{
  uint uVar1;
  uint unaff_D7;
  
  u_dph(param_2);
  u_nwfcb(param_1,param_2);
  u_dirchk();
  uVar1 = unaff_D7;
  if (-1 < (int)unaff_D7) {
    if ((param_4 == 1) || (uVar1 = 0xfffffff6, param_4 == 2)) {
      u_fnchk(param_3);
      uVar1 = unaff_D7;
      if (-1 < (int)unaff_D7) {
        if (unaff_D7 == 0) {
          uVar1 = 0xfffffffe;
        }
        else {
          u_setfcb();
          u_cresub();
          if (-1 < (int)unaff_D7) {
            u_fcbqin();
            uVar1 = (uint)*(byte *)(unaff_D7 + 0x26);
          }
        }
      }
    }
    if ((int)uVar1 < 0) {
      u_zapfcb();
    }
  }
  mkdoserr(param_2,uVar1);
  return;
}


// ==== u_cresub @ 0103347a

void u_cresub(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int unaff_D7;
  
  u_newdir(param_1,param_2);
  if (-1 < unaff_D7) {
    u_nwfile(param_1,param_3,param_4);
    if (unaff_D7 < 0) {
      u_ersdir(param_1);
    }
  }
  return;
}


// ==== u_newdir @ 010334c4

/* WARNING: Removing unreachable block (ram,0x01033502) */

undefined4 u_newdir(int param_1,undefined4 param_2)

{
  undefined4 uVar1;
  int unaff_D7;
  
  u_scanent(*(undefined4 *)(param_1 + 4),param_2,0);
  if (unaff_D7 == 0) {
    u_credir(*(undefined4 *)(param_1 + 4),param_2);
    uVar1 = 0xffffffd5;
  }
  else {
    uVar1 = 0xffffffff;
  }
  return uVar1;
}


// ==== u_credir @ 01033514

void u_credir(int param_1,undefined4 param_2)

{
  u_opndir(param_1);
  fill();
  cpydata(param_2);
  *(byte *)(param_1 + 0x28) = *(byte *)(param_1 + 0x28) | 0x80;
  return;
}


// ==== u_opndir @ 01033560

void u_opndir(int param_1)

{
  short sVar1;
  short sVar2;
  char *pcVar3;
  
  sVar1 = *(short *)(*(int *)(param_1 + 8) + 0x14);
  pcVar3 = *(char **)(param_1 + 0x10);
  sVar2 = 0;
  if (0 < sVar1) {
    do {
      if ((*pcVar3 == '\0') || (*pcVar3 == -0x1b)) {
        pcVar3[0xb] = '\0';
        return;
      }
      sVar2 = sVar2 + 1;
      pcVar3 = pcVar3 + 0x20;
    } while (sVar2 < sVar1);
  }
  return;
}


// ==== u_nwfile @ 010335aa

void u_nwfile(int param_1,undefined4 param_2,undefined4 param_3)

{
  undefined4 unaff_D7;
  short sVar1;
  
  u_clcnt(*(int *)(*(int *)(param_1 + 4) + 8) + 0xc,param_2);
  setmap(*(undefined4 *)(param_1 + 4));
  sVar1 = (short)unaff_D7;
  if (-1 < sVar1) {
    *(short *)(param_1 + 0x16) = sVar1;
    *(short *)(param_1 + 0x1c) = sVar1;
    *(undefined4 *)(param_1 + 0x1e) = unaff_D7;
    *(undefined4 *)(param_1 + 0x10) = 0;
    *(undefined4 *)(param_1 + 0x18) = 0;
    *(undefined4 *)(param_1 + 0x22) = 0;
    u_opnmod(param_3);
    *(char *)(param_1 + 0x15) = (char)unaff_D7;
  }
  return;
}


// ==== u_open @ 01033618

void u_open(undefined1 param_1,undefined1 param_2,undefined4 param_3)

{
  uint unaff_D7;
  
  u_dph(param_2);
  u_nwfcb(param_1,param_2);
  u_dirchk();
  if (-1 < (int)unaff_D7) {
    u_fnchk(param_3);
    if (-1 < (int)unaff_D7) {
      if (unaff_D7 == 0) {
        unaff_D7 = 0xfffffffe;
      }
      else {
        u_setfcb();
        u_opnsub();
        if (-1 < (int)unaff_D7) {
          u_fcbqin();
          unaff_D7 = (uint)*(byte *)(unaff_D7 + 0x26);
        }
      }
    }
    if ((int)unaff_D7 < 0) {
      u_zapfcb();
    }
  }
  mkdoserr(param_2,unaff_D7);
  return;
}


// ==== u_opnsub @ 010336dc

void u_opnsub(int param_1,undefined4 param_2,undefined4 param_3)

{
  int unaff_D7;
  
  u_scanent(*(undefined4 *)(param_1 + 4),param_2,param_3);
  if ((unaff_D7 != 0) && (u_opnfcb(param_1), -1 < unaff_D7)) {
    u_scanfcb(param_1);
  }
  return;
}


// ==== u_filext @ 01033732

void u_filext(int param_1)

{
  undefined4 uVar1;
  short sVar2;
  short unaff_D7w;
  
  uVar1 = *(undefined4 *)(param_1 + 4);
  sVar2 = *(short *)(param_1 + 0x16);
  while ((1 < sVar2 && (sVar2 < 0xff7))) {
    getcno(uVar1,(int)sVar2);
    sVar2 = unaff_D7w;
  }
  return;
}


// ==== u_opnfcb @ 01033774

uint u_opnfcb(int param_1,int param_2,undefined4 param_3)

{
  byte bVar1;
  uint uVar2;
  uint unaff_D7;
  
  u_opnmsk(param_3);
  uVar2 = unaff_D7 & *(byte *)(param_2 + 0xb);
  if (uVar2 == 0) {
    *(int *)(param_1 + 0xc) = param_2;
    *(undefined1 *)(param_1 + 0x14) = *(undefined1 *)(param_2 + 0xb);
    revword(*(undefined2 *)(param_2 + 0x1a));
    *(short *)(param_1 + 0x16) = (short)unaff_D7;
    *(short *)(param_1 + 0x1c) = (short)unaff_D7;
    revlong(*(undefined4 *)(param_2 + 0x1c));
    *(uint *)(param_1 + 0x10) = unaff_D7;
    u_filext(param_1);
    *(uint *)(param_1 + 0x1e) = unaff_D7;
    *(undefined4 *)(param_1 + 0x18) = 0;
    *(undefined4 *)(param_1 + 0x22) = 0;
    u_opnmod(param_3);
    *(char *)(param_1 + 0x15) = (char)unaff_D7;
    uVar2 = *(byte *)(param_1 + 0x15) & 3;
    if (uVar2 == 2) {
      *(undefined4 *)(param_1 + 0x10) = 0;
      *(undefined4 *)(param_2 + 0x1c) = 0;
      *(byte *)(param_1 + 0x15) = *(byte *)(param_1 + 0x15) | 0x80;
      bVar1 = *(byte *)(*(int *)(param_1 + 4) + 0x28) | 0x80;
      uVar2 = (uint)bVar1;
      *(byte *)(*(int *)(param_1 + 4) + 0x28) = bVar1;
    }
  }
  return uVar2;
}


// ==== u_scanfcb @ 01033834

void u_scanfcb(int param_1)

{
  undefined4 *puVar1;
  undefined4 uVar2;
  int unaff_D7;
  
  puVar1 = (undefined4 *)**(undefined4 **)(param_1 + 4);
  uVar2 = *(undefined4 *)(param_1 + 0xc);
  while ((puVar1 != (undefined4 *)0x0 && (cmpbuf(uVar2,puVar1[3],0xb), unaff_D7 == 0))) {
    puVar1 = (undefined4 *)*puVar1;
  }
  return;
}


// ==== u_close @ 0103389c

void u_close(undefined1 param_1,short param_2)

{
  int iVar1;
  int iVar2;
  int unaff_D7;
  
  u_fcb((int)param_2);
  iVar1 = *(int *)(unaff_D7 + 4);
  iVar2 = 0;
  u_dirchk(iVar1,param_1);
  if (-1 < unaff_D7) {
    u_clsfcb();
    if (((unaff_D7 != -0x2e) && (unaff_D7 != -0x2d)) && (unaff_D7 != -4)) {
      u_putdir(iVar1,param_1);
      iVar2 = unaff_D7;
    }
    u_fcbqout();
    if (-1 < unaff_D7) {
      if (iVar2 == 0) {
        unaff_D7 = (int)param_2;
      }
      else {
        unaff_D7 = iVar2;
      }
    }
  }
  mkdoserr(*(undefined1 *)(iVar1 + 0x18),unaff_D7);
  return;
}


// ==== u_clsfcb @ 0103393c

uint u_clsfcb(int param_1)

{
  int iVar1;
  byte bVar2;
  uint unaff_D7;
  short sVar3;
  undefined1 auStack_c [8];
  
  iVar1 = *(int *)(param_1 + 0xc);
  bVar2 = *(byte *)(param_1 + 0x14);
  u_clcnt(*(int *)(*(int *)(param_1 + 4) + 8) + 0xc,*(undefined4 *)(param_1 + 0x10));
  if (((*(byte *)(param_1 + 0x15) & 2) != 0) && (*(char *)(param_1 + 0x15) < '\0')) {
    u_clsnm(param_1,(int)*(short *)(param_1 + 0x1c),(unaff_D7 - 1) - *(int *)(param_1 + 0x18));
    sVar3 = (short)unaff_D7;
    u_clsnm(param_1,(int)sVar3,1);
    unaff_D7 = (uint)sVar3;
    resmap(*(undefined4 *)(param_1 + 4),unaff_D7);
    putcno(*(undefined4 *)(param_1 + 4),(int)sVar3,0xff8);
    *(byte *)(iVar1 + 0xb) = *(byte *)(param_1 + 0x14) | 0x20;
    revword((int)*(short *)(param_1 + 0x16));
    *(short *)(iVar1 + 0x1a) = sVar3;
    revlong(*(undefined4 *)(param_1 + 0x10));
    *(uint *)(iVar1 + 0x1c) = unaff_D7;
    redwat(auStack_c);
    timcvt(auStack_c);
    *(short *)(iVar1 + 0x16) = sVar3;
    daycvt(auStack_c);
    *(short *)(iVar1 + 0x18) = sVar3;
    *(byte *)(*(int *)(param_1 + 4) + 0x28) = *(byte *)(*(int *)(param_1 + 4) + 0x28) | 0x80;
  }
  u_zapfcb(param_1,1);
  if (-1 < (int)unaff_D7) {
    unaff_D7 = (uint)bVar2;
  }
  return unaff_D7;
}


// ==== u_putdir @ 01033a68

char u_putdir(int param_1)

{
  undefined4 uVar1;
  ushort uVar2;
  ushort uVar3;
  undefined2 uVar4;
  ushort *puVar5;
  uint uVar6;
  char cVar7;
  int iVar8;
  uint uVar9;
  undefined4 local_8;
  
  iVar8 = *(int *)(param_1 + 8);
  uVar1 = *(undefined4 *)(param_1 + 0xc);
  local_8 = 0;
  cVar7 = *(char *)(param_1 + 0x18);
  if (iVar8 != 0) {
    puVar5 = (ushort *)(iVar8 + 0xc);
    uVar4 = *(undefined2 *)(iVar8 + 0x10);
    uVar9 = (uint)*(byte *)(iVar8 + 0x12) * (uint)*(ushort *)(iVar8 + 0x1a);
    uVar6 = (uint)*(ushort *)(iVar8 + 0x14) << 5;
    uVar2 = *puVar5;
    uVar3 = *puVar5;
    iVar8 = (uVar9 >> 1) * (uint)*puVar5;
    cVar7 = *(char *)(param_1 + 0x28);
    if (cVar7 < '\0') {
      *(byte *)(param_1 + 0x28) = *(byte *)(param_1 + 0x28) & 0x7f;
      cpybuf(*(undefined4 *)(param_1 + 0xc),*(int *)(param_1 + 0xc) + iVar8,iVar8);
      cVar7 = u_rwstrn(0x21,param_1,uVar4,uVar6 / uVar2 + (uint)(uVar6 % (uint)uVar3 != 0) + uVar9,
                       uVar1,&local_8);
    }
  }
  return cVar7;
}


// ==== cv_ubpb @ 01033b3c

void cv_ubpb(int param_1,undefined2 *param_2)

{
  undefined2 unaff_D7w;
  
  revword(*(undefined2 *)(param_1 + 0xb));
  *param_2 = unaff_D7w;
  *(undefined1 *)(param_2 + 1) = *(undefined1 *)(param_1 + 0xd);
  revword(*(undefined2 *)(param_1 + 0xe));
  param_2[2] = unaff_D7w;
  *(undefined1 *)(param_2 + 3) = *(undefined1 *)(param_1 + 0x10);
  revword(*(undefined2 *)(param_1 + 0x11));
  param_2[4] = unaff_D7w;
  revword(*(undefined2 *)(param_1 + 0x13));
  param_2[5] = unaff_D7w;
  *(undefined1 *)(param_2 + 6) = *(undefined1 *)(param_1 + 0x15);
  revword(*(undefined2 *)(param_1 + 0x16));
  param_2[7] = unaff_D7w;
  return;
}


// ==== cv_ubts @ 01033bf8

void cv_ubts(int param_1,int param_2)

{
  undefined2 unaff_D7w;
  
  cpybuf(param_1,param_2,3);
  cpybuf(param_1 + 3,param_2 + 3,3);
  *(undefined1 *)(param_2 + 6) = *(undefined1 *)(param_1 + 6);
  *(undefined1 *)(param_2 + 7) = *(undefined1 *)(param_1 + 7);
  cpybuf(param_1 + 8,param_2 + 8,3);
  cv_ubpb(param_1,param_2 + 0xc);
  revword(*(undefined2 *)(param_1 + 0x18));
  *(undefined2 *)(param_2 + 0x1c) = unaff_D7w;
  revword(*(undefined2 *)(param_1 + 0x1a));
  *(undefined2 *)(param_2 + 0x1e) = unaff_D7w;
  revword(*(undefined2 *)(param_1 + 0x1c));
  *(undefined2 *)(param_2 + 0x20) = unaff_D7w;
  *(undefined1 *)(param_2 + 0x22) = *(undefined1 *)(param_1 + 0x1e);
  return;
}


// ==== cv_dbpb @ 01033cbc

void cv_dbpb(undefined2 *param_1,int param_2)

{
  *(char *)(param_2 + 0xc) = (char)((ushort)*param_1 >> 8);
  *(char *)(param_2 + 0xb) = (char)*param_1;
  *(undefined1 *)(param_2 + 0xd) = *(undefined1 *)(param_1 + 1);
  *(char *)(param_2 + 0xf) = (char)((ushort)param_1[2] >> 8);
  *(char *)(param_2 + 0xe) = (char)param_1[2];
  *(undefined1 *)(param_2 + 0x10) = *(undefined1 *)(param_1 + 3);
  *(char *)(param_2 + 0x12) = (char)((ushort)param_1[4] >> 8);
  *(char *)(param_2 + 0x11) = (char)param_1[4];
  *(char *)(param_2 + 0x14) = (char)((ushort)param_1[5] >> 8);
  *(char *)(param_2 + 0x13) = (char)param_1[5];
  *(undefined1 *)(param_2 + 0x15) = *(undefined1 *)(param_1 + 6);
  *(char *)(param_2 + 0x17) = (char)((ushort)param_1[7] >> 8);
  *(char *)(param_2 + 0x16) = (char)param_1[7];
  return;
}


// ==== cv_dbts @ 01033d3e

void cv_dbts(int param_1,int param_2)

{
  cpybuf(param_1,param_2,3);
  cpybuf(param_1 + 3,param_2 + 3,3);
  *(undefined1 *)(param_2 + 6) = *(undefined1 *)(param_1 + 6);
  *(undefined1 *)(param_2 + 7) = *(undefined1 *)(param_1 + 7);
  cpybuf(param_1 + 8,param_2 + 8,3);
  cv_dbpb((ushort *)(param_1 + 0xc),param_2);
  *(char *)(param_2 + 0x19) = (char)((ushort)*(undefined2 *)(param_1 + 0x1c) >> 8);
  *(char *)(param_2 + 0x18) = (char)*(undefined2 *)(param_1 + 0x1c);
  *(char *)(param_2 + 0x1b) = (char)((ushort)*(undefined2 *)(param_1 + 0x1e) >> 8);
  *(char *)(param_2 + 0x1a) = (char)*(undefined2 *)(param_1 + 0x1e);
  *(char *)(param_2 + 0x1d) = (char)((ushort)*(undefined2 *)(param_1 + 0x20) >> 8);
  *(char *)(param_2 + 0x1c) = (char)*(undefined2 *)(param_1 + 0x20);
  *(undefined1 *)(param_2 + 0x1e) = *(undefined1 *)(param_1 + 0x22);
  cpybuf(param_1 + 0x23,param_2 + 0x1f,*(ushort *)(param_1 + 0xc) - 0x1f);
  return;
}


// ==== u_clsto @ 01033e04

int u_clsto(ushort *param_1)

{
  return (uint)*(byte *)(param_1 + 1) * (uint)*param_1;
}


// ==== u_ftlby @ 01033e2a

void u_ftlby(void)

{
  return;
}


// ==== u_ftlcl @ 01033e3e

void u_ftlcl(void)

{
  return;
}


// ==== u_clcnt @ 01033e52

bool u_clcnt(ushort *param_1,uint param_2)

{
  return param_2 % ((uint)*(byte *)(param_1 + 1) * (uint)*param_1) != 0;
}


// ==== u_clsnm @ 01033e92

void u_clsnm(int param_1,short param_2,int param_3)

{
  int iVar1;
  short unaff_D7w;
  
  iVar1 = 0;
  if (0 < param_3) {
    do {
      if (param_2 < 2) {
        return;
      }
      if (0xff6 < param_2) {
        return;
      }
      getcno(*(undefined4 *)(param_1 + 4),(int)param_2);
      iVar1 = iVar1 + 1;
      param_2 = unaff_D7w;
    } while (iVar1 < param_3);
  }
  return;
}


// ==== daycvt @ 01033ee0

ushort daycvt(char *param_1)

{
  char cVar1;
  short sVar2;
  
  if (*param_1 < 'P') {
    cVar1 = *param_1;
    sVar2 = 0x14;
  }
  else {
    cVar1 = *param_1;
    sVar2 = -0x50;
  }
  return (short)((char)(param_1[1] & 8U) >> 3) | (sVar2 + cVar1) * 2 |
         ((byte)param_1[2] & 0x1f | ((byte)param_1[1] & 7) << 5) << 8;
}


// ==== timcvt @ 01033f34

ushort timcvt(int param_1)

{
  return (short)((char)(*(byte *)(param_1 + 5) & 0x38) >> 3) | (short)*(char *)(param_1 + 4) << 3 |
         ((byte)(*(char *)(param_1 + 6) >> 1) & 0x1f | (*(byte *)(param_1 + 5) & 7) << 5) << 8;
}


// ==== u_ersdir @ 01033fc8

void u_ersdir(int param_1)

{
  undefined1 uVar1;
  
  if ((*(undefined1 **)(param_1 + 0xc))[0x20] == '\0') {
    uVar1 = 0;
  }
  else {
    uVar1 = 0xe5;
  }
  **(undefined1 **)(param_1 + 0xc) = uVar1;
  *(byte *)(*(int *)(param_1 + 4) + 0x28) = *(byte *)(*(int *)(param_1 + 4) + 0x28) | 0x80;
  return;
}


// ==== u_cpydir @ 01033ffe

void u_cpydir(int param_1,int param_2)

{
  ushort uVar1;
  byte bVar2;
  short unaff_D7w;
  
  revword(*(undefined2 *)(param_1 + 0x16));
  revword(*(undefined2 *)(param_1 + 0x18));
  uVar1 = *(ushort *)(param_1 + 0x18);
  cpybuf(param_1,param_2,0xb);
  *(byte *)(param_2 + 0x10) = (byte)(unaff_D7w >> 0xb) & 0x1f;
  bVar2 = (byte)(unaff_D7w >> 5);
  *(byte *)(param_2 + 0x11) = bVar2 & 0x3f;
  *(byte *)(param_2 + 0x12) = (byte)unaff_D7w & 0x1f;
  *(char *)(param_2 + 0xc) = (char)((((uVar1 & 0xfe) >> 1) + 0x50) % 100);
  *(byte *)(param_2 + 0xd) = bVar2 & 0xf;
  *(byte *)(param_2 + 0xe) = (byte)unaff_D7w & 0x1f;
  *(undefined1 *)(param_2 + 0xf) = 0;
  revword(*(undefined2 *)(param_1 + 0x1a));
  *(short *)(param_2 + 0x14) = unaff_D7w;
  *(uint *)(param_2 + 0x16) =
       *(uint *)(param_1 + 0x1c) >> 0x18 |
       (*(uint *)(param_1 + 0x1c) & 0xff0000) >> 8 |
       (*(uint *)(param_1 + 0x1c) & 0xff00) << 8 | *(int *)(param_1 + 0x1c) << 0x18;
  return;
}


// ==== u_dirsrch @ 010340e2

void u_dirsrch(undefined1 param_1,undefined1 param_2)

{
  int iVar1;
  int iVar2;
  int iVar3;
  int unaff_D7;
  undefined1 auStack_2e [42];
  
  u_dph(param_2);
  iVar3 = -10;
  if (unaff_D7 != 0) {
    if (*(char *)(unaff_D7 + 0x19) == '\0') {
      iVar3 = -4;
    }
    else {
      u_clrfcb(auStack_2e,param_1,param_2);
      u_scanent();
      if (unaff_D7 == 0) {
        iVar3 = -3;
      }
      else {
        iVar3 = 0;
        iVar2 = *(int *)(unaff_D7 + 0x10);
        while (iVar2 <= unaff_D7) {
          iVar1 = iVar2 + 0x20;
          u_dirofct(iVar2,0);
          iVar2 = iVar1;
          if (0 < unaff_D7) {
            iVar3 = iVar3 + 1;
          }
        }
      }
    }
  }
  mkdoserr(param_2,iVar3);
  return;
}


// ==== u_direxp @ 0103418a

void u_direxp(undefined1 param_1,ushort param_2,ushort param_3,int param_4)

{
  int iVar1;
  int unaff_D7;
  int iVar2;
  uint uVar3;
  short local_16;
  uint local_10;
  int local_c;
  
  iVar2 = -10;
  u_dph(param_1);
  iVar1 = *(int *)(unaff_D7 + 0x10);
  local_10 = (uint)*(ushort *)(*(int *)(unaff_D7 + 8) + 0x14);
  uVar3 = (uint)param_2;
  local_16 = 0;
  fill(param_4,(((uint)param_3 - (uint)param_2) + 1) * 0x20,0);
  if ((param_2 != 0) && (unaff_D7 != 0)) {
    if (*(char *)(unaff_D7 + 0x19) == '\0') {
      iVar2 = -4;
    }
    else {
      u_dircuup();
      if (-1 < unaff_D7) {
        iVar1 = unaff_D7 * 0x20 + iVar1;
        iVar2 = unaff_D7;
        local_c = param_4;
        while ((iVar2 < (int)local_10 && ((int)uVar3 <= (int)(uint)param_3))) {
          u_dirofct(iVar1,0);
          if (unaff_D7 < 0) break;
          if (unaff_D7 != 0) {
            u_cpydir(iVar1,local_c);
            uVar3 = uVar3 + 1;
            local_16 = local_16 + 1;
            local_c = local_c + 0x20;
          }
          iVar2 = iVar2 + 1;
          iVar1 = iVar1 + 0x20;
        }
      }
      iVar2 = (int)local_16;
    }
  }
  mkdoserr(param_1,iVar2);
  return;
}


// ==== u_dircuup @ 0103429a

int u_dircuup(int param_1,ushort param_2)

{
  bool bVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  int unaff_D7;
  int iVar5;
  
  iVar5 = *(int *)(param_1 + 0x10);
  uVar2 = (uint)*(ushort *)(*(int *)(param_1 + 8) + 0x14);
  bVar1 = false;
  iVar3 = 1;
  iVar4 = 0;
  if (uVar2 != 0) {
    do {
      if ((int)(uint)param_2 < iVar3) break;
      u_dirofct(iVar5,0);
      if (unaff_D7 < 0) break;
      if (unaff_D7 != 0) {
        if ((int)(uint)param_2 <= iVar3) {
          bVar1 = true;
          break;
        }
        iVar3 = iVar3 + 1;
      }
      iVar4 = iVar4 + 1;
      iVar5 = iVar5 + 0x20;
    } while (iVar4 < (int)uVar2);
  }
  if (!bVar1) {
    iVar4 = -3;
  }
  return iVar4;
}


// ==== u_erase @ 0103431a

void u_erase(undefined1 param_1,undefined1 param_2,undefined4 param_3)

{
  int unaff_D7;
  undefined1 auStack_2e [42];
  
  u_dph(param_2);
  u_dirchk();
  if (-1 < unaff_D7) {
    u_fnchk(param_3);
    if (-1 < unaff_D7) {
      u_clrfcb(auStack_2e,param_1,param_2);
      u_setfcb(auStack_2e);
      u_erssub(auStack_2e,param_3);
      if (-1 < unaff_D7) {
        u_putdir();
      }
    }
  }
  mkdoserr(param_2);
  return;
}


// ==== u_erssub @ 010343ba

void u_erssub(int param_1,undefined4 param_2)

{
  int unaff_D7;
  
  u_opnsub(param_1,param_2,0);
  if (-1 < unaff_D7) {
    resmap(*(undefined4 *)(param_1 + 4),(int)*(short *)(param_1 + 0x16));
    u_ersdir(param_1);
  }
  return;
}


// ==== u_rename @ 01034404

void u_rename(undefined1 param_1,undefined1 param_2,undefined4 param_3,undefined4 param_4)

{
  int unaff_D7;
  undefined1 auStack_2e [42];
  
  u_dph(param_2);
  u_dirchk();
  if (-1 < unaff_D7) {
    u_fnchk(param_3);
    if (-1 < unaff_D7) {
      u_fnchk(param_4);
      if (-1 < unaff_D7) {
        u_clrfcb(auStack_2e,param_1,param_2);
        u_setfcb(auStack_2e);
        u_rnmsub(auStack_2e,param_3,param_4);
        if (-1 < unaff_D7) {
          u_putdir();
        }
      }
    }
  }
  mkdoserr(param_2);
  return;
}


// ==== u_rnmsub @ 010344b6

void u_rnmsub(int param_1,undefined4 param_2,undefined4 param_3)

{
  int iVar1;
  int unaff_D7;
  
  iVar1 = *(int *)(param_1 + 4);
  u_scanent(iVar1,param_3,0);
  if (unaff_D7 == 0) {
    u_opnsub(param_1,param_2,0);
    cpydata(param_3,*(undefined4 *)(param_1 + 0xc),0xb);
    *(byte *)(iVar1 + 0x28) = *(byte *)(iVar1 + 0x28) | 0x80;
  }
  return;
}


// ==== u_getvol @ 01034520

void u_getvol(undefined1 param_1,undefined1 *param_2)

{
  undefined4 uVar1;
  int unaff_D7;
  
  u_dph(param_1);
  uVar1 = 0xfffffff6;
  if (unaff_D7 != 0) {
    if (*(char *)(unaff_D7 + 0x19) == '\0') {
      uVar1 = 0xfffffffc;
    }
    else {
      uVar1 = 0;
      u_srhvol();
      if (unaff_D7 != 0) {
        uVar1 = 0xb;
        cpydata();
        param_2 = param_2 + 0xb;
      }
      *param_2 = 0;
    }
  }
  mkdoserr(param_1,uVar1);
  return;
}


// ==== u_srhvol @ 0103458e

void u_srhvol(int param_1)

{
  uint uVar1;
  uint uVar2;
  char *pcVar3;
  
  pcVar3 = *(char **)(param_1 + 0x10);
  uVar2 = (uint)*(ushort *)(*(int *)(param_1 + 8) + 0x14);
  if ((pcVar3 != (char *)0x0) && (uVar1 = 0, uVar2 != 0)) {
    do {
      if (*pcVar3 != -0x1b) {
        if (*pcVar3 == '\0') {
          return;
        }
        if ((pcVar3[0xb] & 8U) != 0) {
          return;
        }
      }
      pcVar3 = pcVar3 + 0x20;
      uVar1 = uVar1 + 1;
    } while (uVar1 < uVar2);
  }
  return;
}


// ==== u_putvol @ 010345ec

/* WARNING: Removing unreachable block (ram,0x010346ba) */

void u_putvol(undefined4 param_1,undefined1 param_2,char *param_3)

{
  uint uVar1;
  uint uVar2;
  uint unaff_D7;
  undefined1 auStack_18 [8];
  undefined1 auStack_10 [12];
  
  u_dph(param_2);
  strlen(param_3);
  if (unaff_D7 < 0xb) {
    strlen(param_3);
    uVar1 = unaff_D7;
  }
  else {
    uVar1 = 0xb;
  }
  u_fnck(param_3,uVar1);
  uVar2 = unaff_D7;
  if ((-1 < (int)unaff_D7) && (u_dirchk(), -1 < (int)unaff_D7)) {
    uVar2 = 0;
    u_srhvol();
    if (unaff_D7 == 0) {
      putfnam(param_3,auStack_10);
      u_credir();
      uVar2 = 0xffffffd5;
    }
    else {
      cpydata(param_3);
      fill(unaff_D7 + uVar1,0xb - uVar1,0x20);
    }
    if (-1 < (int)uVar2) {
      redwat(auStack_18);
      daycvt(auStack_18);
      *(short *)(unaff_D7 + 0x18) = (short)unaff_D7;
      timcvt(auStack_18);
      *(short *)(unaff_D7 + 0x16) = (short)unaff_D7;
      *(byte *)(unaff_D7 + 0x28) = *(byte *)(unaff_D7 + 0x28) | 0x80;
      u_putdir();
      uVar2 = unaff_D7;
    }
  }
  mkdoserr(param_2,uVar2);
  return;
}


// ==== mk34dt @ 01034738

void mk34dt(undefined1 param_1,undefined1 param_2,int param_3,undefined1 *param_4,int param_5)

{
  ushort uVar1;
  ushort uVar2;
  ushort uVar3;
  ushort uVar4;
  byte bVar5;
  undefined4 unaff_D7;
  undefined1 *puVar6;
  byte *pbVar7;
  ushort *puVar8;
  
  uVar2 = *(ushort *)(param_3 + 0x1c);
  uVar4 = 0;
  frmfdcnfg(1,0,*(undefined2 *)(param_3 + 0xc),uVar2,0,0);
  for (puVar8 = &DAT_0107cefc; uVar1 = *puVar8, uVar1 != 0; puVar8 = puVar8 + 2) {
    uVar3 = 0;
    puVar6 = param_4;
    if (uVar1 != 0) {
      do {
        param_4 = puVar6 + 1;
        *puVar6 = *(undefined1 *)(puVar8 + 1);
        uVar4 = uVar4 + 1;
        uVar3 = uVar3 + 1;
        puVar6 = param_4;
      } while (uVar3 < uVar1);
    }
  }
  bVar5 = 1;
  if (uVar2 != 0) {
    do {
      for (puVar8 = &DAT_0107cf14; uVar1 = *puVar8, uVar1 != 0; puVar8 = puVar8 + 2) {
        uVar3 = 0;
        puVar6 = param_4;
        if (uVar1 != 0) {
          do {
            param_4 = puVar6 + 1;
            *puVar6 = *(undefined1 *)(puVar8 + 1);
            uVar4 = uVar4 + 1;
            uVar3 = uVar3 + 1;
            puVar6 = param_4;
          } while (uVar3 < uVar1);
        }
        if (*(char *)(puVar8 + 1) == -2) {
          *param_4 = param_1;
          param_4[1] = param_2;
          pbVar7 = param_4 + 3;
          param_4[2] = bVar5;
          param_4 = param_4 + 4;
          *pbVar7 = ((byte)((uint)unaff_D7 >> 0x18) & 0x3f) >> 4;
          uVar4 = uVar4 + 4;
        }
      }
      bVar5 = bVar5 + 1;
    } while (bVar5 <= uVar2);
  }
  for (; (int)(uint)uVar4 < param_5; uVar4 = uVar4 + 1) {
    *param_4 = DAT_0107cf44;
    param_4 = param_4 + 1;
  }
  return;
}


// ==== _msinivl @ 01034828

void _msinivl(undefined4 param_1,int param_2,undefined1 *param_3)

{
  ushort uVar1;
  ushort uVar2;
  ushort uVar3;
  ushort uVar4;
  byte bVar5;
  undefined1 uVar6;
  int iVar7;
  uint uVar8;
  int iVar9;
  int iVar10;
  uint uVar11;
  int unaff_D7;
  undefined4 local_8;
  
  local_8 = 0;
  u_dph(param_1);
  uVar11 = (uint)*(ushort *)(param_2 + 0xc);
  uVar1 = *(ushort *)(param_2 + 0x10);
  uVar2 = *(ushort *)(param_2 + 0x1a);
  uVar8 = (uint)*(ushort *)(param_2 + 0x14) << 5;
  iVar7 = (uint)(uVar8 % uVar11 != 0) + uVar8 / uVar11;
  iVar9 = (uint)*(byte *)(param_2 + 0x12) * (uint)uVar2;
  uVar3 = *(ushort *)(param_2 + 0x16);
  uVar4 = *(ushort *)(param_2 + 0x10);
  bVar5 = *(byte *)(param_2 + 0xe);
  u_fakdph();
  fill(param_3,uVar11 * uVar1,0x5e);
  cv_dbts(param_2,param_3);
  u_rwstrn(0x21,unaff_D7,0,*(undefined2 *)(param_2 + 0x10),param_3,&local_8);
  if (-1 < unaff_D7) {
    uVar1 = *(ushort *)(param_2 + 0x10);
    fill(param_3,uVar11 * iVar9,0);
    iVar10 = uVar2 * uVar11;
    uVar6 = *(undefined1 *)(param_2 + 0x18);
    *param_3 = uVar6;
    param_3[iVar10] = uVar6;
    param_3[1] = 0xff;
    param_3[iVar10 + 1] = 0xff;
    param_3[2] = 0xff;
    param_3[iVar10 + 2] = 0xff;
    if (0xff6 < (int)(((((uint)uVar3 - (uint)uVar4) - iVar9) - iVar7) / (uint)bVar5)) {
      param_3[3] = 0xff;
      param_3[iVar10 + 3] = 0xff;
    }
    u_rwstrn(0x21,unaff_D7,(uint)uVar1,iVar9,param_3,&local_8);
    if (-1 < unaff_D7) {
      fill(param_3,uVar8,0);
      u_rwstrn(0x21,unaff_D7,iVar9 + (uint)uVar1,iVar7,param_3,&local_8);
    }
  }
  return;
}


// ==== u_fakdph @ 010349f0

void u_fakdph(int param_1,undefined1 param_2,undefined4 param_3)

{
  *(undefined1 *)(param_1 + 0x18) = param_2;
  *(undefined4 *)(param_1 + 8) = param_3;
  u_sudcfg(param_1);
  u_supdph(param_1);
  return;
}


// ==== _msformt @ 01034a22

void _msformt(undefined1 param_1,int param_2,undefined4 param_3,undefined4 param_4)

{
  uint uVar1;
  uint uVar2;
  uint uVar3;
  int unaff_D7;
  undefined4 uVar4;
  int iVar5;
  uint local_18;
  undefined4 local_12 [3];
  
  local_12[0] = 0;
  iVar5 = 0;
  local_18 = (uint)*(ushort *)(param_2 + 0x1e);
  uVar1 = (uint)*(ushort *)(param_2 + 0x16) / (local_18 * *(ushort *)(param_2 + 0x1c));
  uVar3 = 0;
  isSPF1or2();
  if ((unaff_D7 == 1) || (9 < *(ushort *)(param_2 + 0x1c))) {
    uVar4 = 1;
  }
  else {
    uVar4 = 0;
  }
  rqfdrstr(param_1,local_12);
  rqfdstbr(param_1,uVar4,local_12);
  if (uVar1 != 0) {
    do {
      if (iVar5 < 0) {
        return;
      }
      uVar2 = 0;
      if (local_18 != 0) {
        do {
          mk34dt(uVar3,uVar2,param_2,param_3,param_4);
          rqfdtrwr(param_1,uVar3,uVar2,param_3,param_4,local_12);
          cverfdms();
          iVar5 = unaff_D7;
          if (unaff_D7 < 0) break;
          uVar2 = uVar2 + 1;
        } while (uVar2 < local_18);
      }
      uVar3 = uVar3 + 1;
    } while (uVar3 < uVar1);
  }
  return;
}


// ==== u_bts @ 01034b2c

undefined * u_bts(undefined1 param_1,int param_2,undefined4 param_3)

{
  undefined *puVar1;
  int unaff_D7;
  undefined1 auStack_208 [28];
  ushort local_1ec;
  
  puVar1 = (undefined *)isSPF1or2();
  if (unaff_D7 == 1) {
    return puVar1;
  }
  if (param_2 == 0) {
    u_ldbts(param_1,auStack_208,param_3);
    if (unaff_D7 < 0) {
      return (undefined *)0x0;
    }
    if (local_1ec < 10) goto LAB_01034b80;
  }
  else if (param_2 == 1) {
LAB_01034b80:
    return &btsD9;
  }
  return &bts_D18;
}


// ==== u_mon @ 01034b9a

char u_mon(int param_1)

{
  char cVar1;
  undefined4 local_8;
  
  local_8 = 0;
  cVar1 = *(char *)(param_1 + 0x19);
  if (cVar1 == '\0') {
    rqfdslct(*(undefined1 *)(param_1 + 0x18),&local_8);
    cVar1 = cverfdms();
  }
  return cVar1;
}


// ==== u_moff @ 01034bd2

void u_moff(undefined4 param_1)

{
  undefined4 local_8;
  
  local_8 = 0;
  rqfdrels(param_1,&local_8);
  return;
}


// ==== u_initv @ 01034bec

void u_initv(undefined1 param_1,undefined1 param_2,char param_3,undefined4 param_4,
            undefined4 param_5)

{
  int iVar1;
  int unaff_D7;
  int unaff_A4;
  undefined4 local_8;
  
  local_8 = 0;
  u_dph(param_2);
  malloc(0x3400);
  if (unaff_D7 == 0) {
    iVar1 = -0x34;
  }
  else {
    u_mon();
    iVar1 = unaff_D7;
    if (-1 < unaff_D7) {
      u_zapall(param_2,param_1,0);
      cldskchg(param_2);
      u_bts(param_2,param_3,&local_8);
      if (unaff_D7 == 0) {
        iVar1 = -10;
      }
      else if (param_3 != '\0') {
        _msformt(param_2);
      }
      unaff_A4 = unaff_D7;
      if (-1 < iVar1) {
        _msinivl(param_2);
        iVar1 = unaff_D7;
      }
    }
    mfree();
    if (-1 < iVar1) {
      u_mkdir(param_1,param_2,unaff_A4,param_5);
      iVar1 = unaff_D7;
    }
    u_moff(param_2);
  }
  mkdoserr(param_2,iVar1);
  return;
}


// ==== u_mkdir @ 01034d0c

void u_mkdir(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int unaff_D7;
  
  u_dph(param_2);
  u_mountf();
  if (-1 < unaff_D7) {
    *(undefined1 *)(unaff_D7 + 0x19) = 1;
    inc_mdst(param_1,*(undefined1 *)(unaff_D7 + 0x18));
    u_putvol(param_1,param_2,param_4);
    dosstt();
    u_zapall(param_2,param_1,1);
  }
  return;
}


// ==== ini_mdst @ 01034d88

void ini_mdst(void)

{
  fill(&mediasts,0x50,0);
  return;
}


// ==== sct_mdst @ 01034da2

char sct_mdst(int param_1,undefined4 param_2)

{
  char cVar1;
  uint uVar2;
  undefined *puVar3;
  
  puVar3 = &mediasts;
  uVar2 = 0;
  do {
    cVar1 = '\0';
    if ((puVar3[4] != '\0') && (cVar1 = puVar3[param_1], '\0' < cVar1)) {
      cVar1 = set_mdst(puVar3,param_1,param_2);
    }
    puVar3 = puVar3 + 5;
    uVar2 = uVar2 + 1;
  } while (uVar2 < 0x10);
  return cVar1;
}


// ==== clr_mdst @ 01034dea

void clr_mdst(undefined4 param_1,int param_2)

{
  int unaff_D7;
  
  srh_mdst(param_1);
  if (unaff_D7 != 0) {
    *(undefined1 *)(unaff_D7 + param_2) = 0;
  }
  return;
}


// ==== srh_lnrm @ 01034e0a

void srh_lnrm(undefined *param_1,uint param_2)

{
  int iVar1;
  
  iVar1 = 0x10;
  do {
    if (param_2 == (byte)param_1[4]) {
      return;
    }
    param_1 = param_1 + 5;
    if ((undefined *)0x107cf97 < param_1) {
      param_1 = &mediasts;
    }
    iVar1 = iVar1 + -1;
  } while (iVar1 != 0);
  return;
}


// ==== srh_mdst @ 01034e50

void srh_mdst(uint param_1)

{
  if (param_1 != 0) {
    srh_lnrm(&mediasts + (param_1 & 7) * 5,param_1);
  }
  return;
}


// ==== app_mdst @ 01034e84

void app_mdst(uint param_1)

{
  uint uVar1;
  int unaff_D7;
  
  srh_lnrm(&mediasts + (param_1 & 7) * 5,0);
  if (unaff_D7 != 0) {
    *(char *)(unaff_D7 + 4) = (char)param_1;
    uVar1 = 0;
    do {
      *(undefined1 *)(unaff_D7 + uVar1) = 0;
      uVar1 = uVar1 + 1;
    } while (uVar1 < 4);
  }
  return;
}


// ==== set_mdst @ 01034ecc

void set_mdst(int param_1,int param_2,int param_3)

{
  byte bVar1;
  int unaff_D7;
  
  u_dph(param_2);
  *(char *)(param_1 + param_2) = (char)param_3;
  if (param_3 == -4) {
    bVar1 = *(byte *)(unaff_D7 + 0x29) | 6;
  }
  else {
    if (param_3 != -0x2d) {
      return;
    }
    bVar1 = *(byte *)(unaff_D7 + 0x29) | 4;
  }
  *(byte *)(unaff_D7 + 0x29) = bVar1;
  return;
}


// ==== rd_mdst @ 01034f1e

undefined1 rd_mdst(undefined4 param_1,int param_2)

{
  undefined1 uVar1;
  int iVar2;
  int unaff_D7;
  
  iVar2 = 0;
  uVar1 = srh_mdst(param_1);
  if (unaff_D7 == 0) {
    uVar1 = app_mdst(param_1);
    iVar2 = -4;
  }
  if (-1 < iVar2) {
    uVar1 = *(undefined1 *)(unaff_D7 + param_2);
  }
  return uVar1;
}


// ==== dec_mdst @ 01034f68

void dec_mdst(undefined4 param_1,int param_2)

{
  int unaff_D7;
  
  srh_mdst(param_1);
  if (unaff_D7 != 0) {
    if (*(char *)(unaff_D7 + param_2) < '\x01') {
      *(undefined1 *)(unaff_D7 + param_2) = 0;
    }
    else {
      set_mdst();
    }
  }
  return;
}


// ==== inc_mdst @ 01034fb2

void inc_mdst(undefined4 param_1,int param_2)

{
  int iVar1;
  int unaff_D7;
  
  iVar1 = 0;
  srh_mdst(param_1);
  if (unaff_D7 == 0) {
    app_mdst(param_1);
    iVar1 = -1;
  }
  if ((-1 < iVar1) && (-1 < *(char *)(unaff_D7 + param_2))) {
    set_mdst();
  }
  return;
}


// ==== alr_mdst @ 01035012

void alr_mdst(undefined4 param_1,int param_2)

{
  if ((param_2 == -0x2d) || (param_2 == -4)) {
    sct_mdst(param_1,param_2);
  }
  return;
}


// ==== u_dstat @ 01035036

void u_dstat(undefined4 param_1,undefined1 param_2)

{
  undefined1 uVar1;
  byte bVar2;
  uint uVar3;
  uint unaff_D7;
  undefined4 local_8;
  
  local_8 = 0;
  u_dph(param_2);
  u_swpchk(param_2);
  uVar3 = unaff_D7;
  if ((unaff_D7 & 0x800000) != 0) {
    uVar3 = 0;
    if (*(char *)(unaff_D7 + 0x19) == '\0') {
      rqfdslct(param_2,&local_8);
      uVar3 = unaff_D7;
    }
    if (-1 < (char)uVar3) {
      mayiwr_d(param_2);
      if (unaff_D7 == 1) {
        bVar2 = bRam0000002a & 0xbf;
      }
      else {
        bVar2 = *(byte *)(unaff_D7 + 0x29) | 0x40;
      }
      *(byte *)(unaff_D7 + 0x29) = bVar2;
      if (*(char *)(unaff_D7 + 0x19) == '\0') {
        rqfdrels(param_2,&local_8);
      }
    }
  }
  uVar1 = *(undefined1 *)(unaff_D7 + 0x29);
  *(byte *)(unaff_D7 + 0x29) = *(byte *)(unaff_D7 + 0x29) & 0xfb;
  if (*(char *)(unaff_D7 + 0x19) != '\0') {
    cverfdms(uVar3);
    alr_mdst(param_2);
  }
  mkdoserr(param_2,uVar1);
  return;
}


// ==== u_ctusr @ 01035110

void u_ctusr(void)

{
  uint uVar1;
  
  uVar1 = 0;
  do {
    uVar1 = uVar1 + 1;
  } while (uVar1 < 0x10);
  return;
}


// ==== u_dph @ 01035164

void u_dph(byte param_1)

{
  if (param_1 < 2) {
    (&DAT_0107c8c0)[(uint)param_1 * 0x2a] = param_1;
  }
  return;
}


// ==== u_sudcfg @ 01035190

void u_sudcfg(int param_1)

{
  int iVar1;
  undefined4 unaff_A6;
  undefined4 local_10 [2];
  undefined1 local_8;
  undefined1 uStack_7;
  undefined2 uStack_6;
  undefined1 local_4;
  undefined1 uStack_3;
  undefined2 uStack_2;
  
  local_4 = (undefined1)((uint)unaff_A6 >> 0x18);
  uStack_3 = (undefined1)((uint)unaff_A6 >> 0x10);
  uStack_2 = (undefined2)unaff_A6;
  local_10[0] = 0;
  iVar1 = *(int *)(param_1 + 8);
  local_8 = 0;
  uStack_7 = 0;
  uStack_6 = 0;
  rqfdstfg(*(undefined1 *)(param_1 + 0x18),1,1,*(undefined2 *)(iVar1 + 0xc),
           (uint)*(ushort *)(iVar1 + 0x1c),
           ((uint)*(ushort *)(iVar1 + 0x16) / (uint)*(ushort *)(iVar1 + 0x1c)) /
           (uint)*(ushort *)(iVar1 + 0x1e),(uint)*(ushort *)(iVar1 + 0x1e),local_10);
  return;
}


// ==== u_ldbts @ 01035248

void u_ldbts(undefined1 param_1,undefined4 param_2,uint *param_3)

{
  uint unaff_D7;
  uint local_208;
  undefined1 auStack_204 [512];
  
  local_208 = 0;
  rqfdscrd(param_1,0,0,1,1,auStack_204,&local_208);
  cverfdms(unaff_D7 & 0xffffbfbf);
  *param_3 = local_208 | *param_3;
  if (-1 < (int)(unaff_D7 & 0xffffbfbf)) {
    cv_ubts(auStack_204,param_2);
  }
  return;
}


// ==== u_bpbchk @ 010352b8

uint u_bpbchk(int param_1)

{
  ushort uVar1;
  uint uVar2;
  
  uVar2 = (uint)*(ushort *)(param_1 + 0x1c);
  if ((*(ushort *)(param_1 + 0x1c) != 0) &&
     (uVar2 = (uint)*(ushort *)(param_1 + 0x1e), *(ushort *)(param_1 + 0x1e) != 0)) {
    uVar1 = *(ushort *)(param_1 + 0x1a);
    uVar2 = (uint)uVar1;
    if ((uVar1 != 0) &&
       ((uVar2 = (uint)CONCAT11((char)(uVar1 >> 8),*(char *)(param_1 + 0x12)),
        *(char *)(param_1 + 0x12) != '\0' &&
        (uVar2 = (uint)*(ushort *)(param_1 + 0x14), *(ushort *)(param_1 + 0x14) != 0)))) {
      uVar1 = *(ushort *)(param_1 + 0xc);
      uVar2 = (uint)uVar1;
      if ((uVar1 != 0) &&
         (uVar2 = (uint)CONCAT11((char)(uVar1 >> 8),*(char *)(param_1 + 0xe)),
         *(char *)(param_1 + 0xe) != '\0')) {
        uVar2 = ((uint)*(ushort *)(param_1 + 0x16) / (uint)*(ushort *)(param_1 + 0x1c)) /
                (uint)*(ushort *)(param_1 + 0x1e);
      }
    }
  }
  return uVar2;
}


// ==== u_supdph @ 01035322

void u_supdph(undefined4 *param_1,undefined4 param_2)

{
  int iVar1;
  ushort uVar2;
  ushort uVar3;
  int iVar4;
  uint uVar5;
  int iVar6;
  
  iVar1 = param_1[2];
  iVar6 = (uint)*(byte *)(iVar1 + 0x12) * (uint)*(ushort *)(iVar1 + 0x1a);
  uVar5 = (uint)*(ushort *)(iVar1 + 0x14) << 5;
  iVar4 = uVar5 / *(ushort *)(iVar1 + 0xc) + (uint)(uVar5 % (uint)*(ushort *)(iVar1 + 0xc) != 0);
  uVar2 = *(ushort *)(iVar1 + 0x16);
  uVar3 = *(ushort *)(iVar1 + 0x10);
  param_1[1] = 0;
  *param_1 = 0;
  param_1[5] = 0;
  *(short *)((int)param_1 + 0x1e) =
       (short)(((((uint)uVar2 - (uint)uVar3) - iVar6) - iVar4) / (uint)*(byte *)(iVar1 + 0xe));
  *(char *)(param_1 + 8) = (char)iVar6 + (char)*(undefined2 *)(iVar1 + 0x10);
  *(char *)((int)param_1 + 0x21) = (char)iVar4 + *(char *)(param_1 + 8);
  *(short *)((int)param_1 + 0x22) = (short)iVar4;
  param_1[9] = param_2;
  *(undefined1 *)(param_1 + 10) = 0;
  *(undefined1 *)((int)param_1 + 0x29) = 0;
  return;
}


// ==== u_opndph @ 010353dc

void u_opndph(int param_1)

{
  short sVar1;
  short sVar2;
  short sVar3;
  short sVar4;
  short sVar5;
  short unaff_D7w;
  short sVar6;
  
  sVar3 = 2;
  sVar5 = 0;
  sVar4 = 0;
  sVar6 = *(short *)(param_1 + 0x1e) + 2;
  sVar1 = 0;
  sVar2 = 0;
  if (2 < sVar6) {
    do {
      sVar5 = sVar2;
      sVar4 = sVar1;
      getcno(param_1,(int)sVar3);
      if (unaff_D7w != 0) {
        if (unaff_D7w == 0xff7) {
          sVar4 = sVar4 + 1;
        }
        else {
          sVar5 = sVar5 + 1;
        }
      }
      sVar3 = sVar3 + 1;
      sVar1 = sVar4;
      sVar2 = sVar5;
    } while (sVar3 < sVar6);
  }
  *(short *)(param_1 + 0x1a) = sVar4;
  *(short *)(param_1 + 0x1c) = sVar5;
  return;
}


// ==== u_mount @ 01035434

/* WARNING: Removing unreachable block (ram,0x010354d2) */
/* WARNING: Removing unreachable block (ram,0x0103551e) */

void u_mount(undefined1 param_1,byte param_2)

{
  int iVar1;
  uint uVar2;
  uint unaff_D7;
  undefined4 local_8;
  
  local_8 = 0;
  u_dph(param_2);
  uVar2 = (uint)param_2;
  if (unaff_D7 == 0) {
    uVar2 = 0xfffffff6;
  }
  else {
    *(undefined1 *)(unaff_D7 + 0x28) = 0;
    iVar1 = *(char *)(unaff_D7 + 0x19) + 1;
    if (0 < iVar1) {
      if (iVar1 == 1) {
        rqfdslct(param_2,&local_8);
        if ((unaff_D7 & 0x81) == 0) {
          u_mountf();
          *(undefined1 *)(unaff_D7 + 0x19) = 1;
          inc_mdst(param_1,*(undefined1 *)(unaff_D7 + 0x18));
          mayiwr_d(param_2);
          *(byte *)(unaff_D7 + 0x29) = *(byte *)(unaff_D7 + 0x29) | 0x40;
          uVar2 = 0;
        }
        else {
          uVar2 = 0xfffffffc;
        }
      }
      else {
        *(char *)(unaff_D7 + 0x19) = (char)iVar1;
        inc_mdst(param_1,*(undefined1 *)(unaff_D7 + 0x18));
      }
    }
  }
  mkdoserr(param_2,uVar2);
  return;
}


// ==== u_mountf @ 0103554c

void u_mountf(int param_1)

{
  int unaff_D7;
  
  malloc(0x204);
  *(int *)(param_1 + 8) = unaff_D7;
  if (unaff_D7 != 0) {
    u_ldbts(*(undefined1 *)(param_1 + 0x18));
    if (-1 < unaff_D7) {
      u_bpbchk();
      if (unaff_D7 == 0) {
        unaff_D7 = -7;
      }
      else {
        cldskchg(*(undefined1 *)(param_1 + 0x18));
        u_sudcfg(param_1);
        u_supdph(param_1);
        u_getdir(param_1);
      }
    }
    if (unaff_D7 < 0) {
      mfree();
      *(undefined4 *)(param_1 + 8) = 0;
    }
    else {
      u_opndph(param_1);
    }
  }
  return;
}


// ==== u_getdir @ 010355fa

void u_getdir(int param_1)

{
  ushort uVar1;
  ushort uVar2;
  undefined2 uVar3;
  ushort *puVar4;
  uint uVar5;
  int iVar6;
  int iVar7;
  int unaff_D7;
  
  iVar7 = *(int *)(param_1 + 8);
  puVar4 = (ushort *)(iVar7 + 0xc);
  uVar3 = *(undefined2 *)(iVar7 + 0x10);
  iVar6 = (uint)*(byte *)(iVar7 + 0x12) * (uint)*(ushort *)(iVar7 + 0x1a);
  uVar5 = (uint)*(ushort *)(iVar7 + 0x14) * 0x20;
  uVar1 = *puVar4;
  uVar2 = *puVar4;
  iVar7 = (uint)*puVar4 * iVar6;
  malloc(iVar7 + uVar5);
  *(int *)(param_1 + 0xc) = unaff_D7;
  *(undefined4 *)(param_1 + 0x10) = 0;
  if (unaff_D7 != 0) {
    u_rwstrn(0x20,param_1,uVar3,uVar5 / uVar1 + (uint)(uVar5 % (uint)uVar2 != 0) + iVar6);
    if (unaff_D7 < 0) {
      mfree();
      *(undefined4 *)(param_1 + 0xc) = 0;
    }
    else {
      *(int *)(param_1 + 0xc) = unaff_D7;
      *(int *)(param_1 + 0x10) = iVar7 + unaff_D7;
    }
  }
  return;
}


// ==== u_dirchk @ 010356d4

void u_dirchk(int param_1,char param_2)

{
  int unaff_D7;
  
  if ((((param_1 != 0) && (*(char *)(param_1 + 0x19) != '\0')) && (param_2 != '\0')) &&
     (rd_mdst(param_2,*(undefined1 *)(param_1 + 0x18)), unaff_D7 < 0)) {
    u_zapall(*(undefined1 *)(param_1 + 0x18),param_2,0);
  }
  return;
}


// ==== u_demnt @ 0103573a

void u_demnt(undefined1 param_1,undefined1 param_2)

{
  int iVar1;
  int unaff_D7;
  undefined4 local_8;
  
  local_8 = 0;
  u_dph(param_2);
  u_dmntck();
  iVar1 = unaff_D7;
  if (unaff_D7 < 0) {
    if ((unaff_D7 != -4) && (unaff_D7 != -1)) goto LAB_0103584e;
    iVar1 = 0;
  }
  u_swpchk(param_2);
  cverfdms();
  alr_mdst(param_2);
  u_dirchk();
  if ((*(byte *)(unaff_D7 + 0x28) & 0x10) == 0) {
    dec_mdst(param_1,*(undefined1 *)(unaff_D7 + 0x18));
    *(char *)(unaff_D7 + 0x19) = (char)iVar1;
    if (iVar1 < 1) {
      u_zapall(*(undefined1 *)(unaff_D7 + 0x18),param_1,1);
      rqfdrels(*(undefined1 *)(unaff_D7 + 0x18),&local_8);
    }
  }
  else {
    rqfdrels(*(undefined1 *)(unaff_D7 + 0x18),&local_8);
  }
LAB_0103584e:
  mkdoserr(param_2);
  return;
}


// ==== u_dmntck @ 0103585e

void u_dmntck(void)

{
  return;
}


// ==== mstsk @ 0103588c

/* WARNING: Restarted to delay deadcode elimination for space: stack */

void mstsk(void)

{
  byte bVar1;
  ushort *unaff_D7;
  ushort *puVar2;
  undefined1 auStack_38 [2];
  undefined1 local_36;
  undefined1 auStack_30 [36];
  ushort *in_stack_fffffff4;
  ushort *local_8;
  
  ini_mdst();
  bVar1 = 0;
  do {
    u_dph(bVar1);
    cpybuf(&u_ivdph);
    *(byte *)(unaff_D7 + 0xc) = bVar1;
    bVar1 = bVar1 + 1;
  } while (bVar1 < 2);
  bVar1 = 0;
  do {
    u_fcb(bVar1);
    cpybuf(&u_ivfcb);
    *(byte *)(unaff_D7 + 0x13) = bVar1;
    bVar1 = bVar1 + 1;
  } while (bVar1 < 0xc);
  do {
    do {
      while( true ) {
        remsg(auStack_38);
        if (-1 < (int)unaff_D7) break;
        wtmsg();
      }
      gettcb(local_36);
    } while (unaff_D7 == (ushort *)0xfffffffd);
    client = local_36;
    if ((*unaff_D7 & 0x100) == 0) {
      s_ltopa(local_36,local_8);
      s_ltopa(local_36,in_stack_fffffff4);
      puVar2 = unaff_D7;
      in_stack_fffffff4 = unaff_D7;
    }
    else {
      puVar2 = local_8;
    }
    dcdmsdr(auStack_30,local_36);
    *(ushort **)puVar2 = unaff_D7;
    post(local_36,0x80);
  } while( true );
}


// ==== dcdmsdr @ 010359ca

void dcdmsdr(short *param_1,undefined1 param_2)

{
  undefined4 uVar1;
  int unaff_D7;
  
  switch(*(undefined1 *)(param_1 + 1)) {
  case 1:
    u_mount(param_2,*(undefined1 *)((int)param_1 + 3));
    break;
  case 2:
    u_dph(*(undefined1 *)((int)param_1 + 3));
    if (unaff_D7 == 0) {
      uVar1 = 0xfffffff6;
    }
    else if (*(char *)(unaff_D7 + 0x19) == '\0') {
      uVar1 = 0xfffffffc;
    }
    else {
      cpybuf(*(undefined4 *)(unaff_D7 + 8),*(undefined4 *)(param_1 + 0x12),0x204);
      uVar1 = 0;
    }
    mkdoserr(*(undefined1 *)((int)param_1 + 3),uVar1);
    break;
  case 3:
    u_kind(*(undefined1 *)((int)param_1 + 3));
    break;
  case 4:
    u_demnt(param_2,*(undefined1 *)((int)param_1 + 3));
    break;
  default:
    mkdoserr(*(undefined1 *)((int)param_1 + 3),1);
    break;
  case 8:
    u_dirsrch(param_2,*(undefined1 *)((int)param_1 + 3),(int)param_1 + 5);
    break;
  case 9:
    u_direxp(*(undefined1 *)((int)param_1 + 3),param_1[0xe],param_1[0xf],
             *(undefined4 *)(param_1 + 0x12));
    break;
  case 10:
    u_remain(*(undefined1 *)((int)param_1 + 3));
    break;
  case 0xb:
    u_getvol(*(undefined1 *)((int)param_1 + 3),*(undefined4 *)(param_1 + 0x12));
    break;
  case 0xc:
    u_putvol(param_2,*(undefined1 *)((int)param_1 + 3),*(undefined4 *)(param_1 + 0x12));
    break;
  case 0xf:
    u_dstat(param_2,*(undefined1 *)((int)param_1 + 3));
    break;
  case 0x11:
    u_open(param_2,*(undefined1 *)((int)param_1 + 3),(int)param_1 + 5,param_1[0xe]);
    break;
  case 0x12:
    u_close(param_2,(int)*param_1);
    break;
  case 0x13:
    u_create(param_2,*(undefined1 *)((int)param_1 + 3),(int)param_1 + 5,param_1[0xe],
             *(undefined4 *)(param_1 + 0x10));
    break;
  case 0x14:
    u_rename(param_2,*(undefined1 *)((int)param_1 + 3),(int)param_1 + 5,param_1 + 8);
    break;
  case 0x15:
    u_erase(param_2,*(undefined1 *)((int)param_1 + 3),(int)param_1 + 5);
    break;
  case 0x21:
    u_read(param_2,(int)*param_1,*(undefined4 *)(param_1 + 0x10),*(undefined4 *)(param_1 + 0x12));
    break;
  case 0x22:
    u_write(param_2,(int)*param_1,*(undefined4 *)(param_1 + 0x10),*(undefined4 *)(param_1 + 0x12));
    break;
  case 0x23:
    u_seek(param_2,(int)*param_1,param_1[0xe],*(undefined4 *)(param_1 + 0x10));
    break;
  case 0x30:
    u_initv(param_2,*(undefined1 *)((int)param_1 + 3),param_1[0xe],*(undefined4 *)(param_1 + 0x10),
            *(undefined4 *)(param_1 + 0x12));
    break;
  case 0x31:
    u_volcpy(*(undefined1 *)((int)param_1 + 3),*(undefined1 *)(param_1 + 2));
    break;
  case 0x32:
    u_fcopy(param_2,*(undefined1 *)((int)param_1 + 3),(int)param_1 + 5,*(undefined1 *)(param_1 + 2),
            param_1 + 8);
    break;
  case 0x40:
    u_rdsct(*(undefined1 *)((int)param_1 + 3),(int)*param_1,param_1[0xe],param_1[0xf],
            *(undefined4 *)(param_1 + 0x10),*(undefined4 *)(param_1 + 0x12));
    break;
  case 0x41:
    u_wrsct(*(undefined1 *)((int)param_1 + 3),(int)*param_1,param_1[0xe],param_1[0xf],
            *(undefined4 *)(param_1 + 0x10),*(undefined4 *)(param_1 + 0x12));
    break;
  case 0x42:
    u_dcnfg(*(undefined1 *)((int)param_1 + 3));
  }
  return;
}


// ==== u_clsidx @ 01035e0c

int u_clsidx(int param_1,short param_2)

{
  int iVar1;
  int iVar2;
  
  iVar1 = param_2 + -2;
  iVar2 = iVar1 * (uint)*(byte *)(*(int *)(param_1 + 8) + 0xe) + (uint)*(byte *)(param_1 + 0x21);
  if (iVar1 < 0) {
    iVar2 = iVar1;
  }
  return iVar2;
}


// ==== u_clssl @ 01035e4c

undefined1 u_clssl(int param_1)

{
  return *(undefined1 *)(param_1 + 2);
}


// ==== u_clbyt @ 01035e66

undefined1 u_clbyt(int param_1)

{
  return *(undefined1 *)(param_1 + 2);
}


// ==== u_contig @ 01035e8a

void u_contig(int param_1,short param_2,int param_3)

{
  undefined4 uVar1;
  int iVar2;
  int unaff_D7;
  int iVar3;
  
  uVar1 = *(undefined4 *)(param_1 + 4);
  is_clstp(uVar1,(int)param_2);
  if ((-1 < unaff_D7) && (iVar2 = 1, 1 < param_3)) {
    while( true ) {
      iVar3 = (int)param_2;
      getcno(uVar1,iVar3);
      param_2 = (short)unaff_D7;
      is_clstp(uVar1,(int)param_2);
      if (unaff_D7 < 1) break;
      if (iVar3 + 1 != (int)param_2) {
        return;
      }
      iVar2 = iVar2 + 1;
      if (param_3 <= iVar2) {
        return;
      }
    }
  }
  return;
}


// ==== u_skfcb @ 01035efe

void u_skfcb(int param_1,uint param_2)

{
  undefined4 uVar1;
  int iVar2;
  ushort uVar3;
  uint uVar4;
  int unaff_D7;
  
  uVar1 = *(undefined4 *)(param_1 + 8);
  iVar2 = *(int *)(*(int *)(param_1 + 4) + 8) + 0xc;
  if (param_2 < *(uint *)(param_1 + 0x10)) {
    uVar4 = param_2;
  }
  else {
    uVar4 = *(uint *)(param_1 + 0x10);
  }
  u_clcnt(iVar2,uVar4);
  u_clsto(iVar2,uVar4);
  u_clsnm(param_1,(int)*(short *)(param_1 + 0x16));
  uVar3 = (ushort)unaff_D7;
  f_skfio(uVar1,*(undefined4 *)(param_1 + 0x22),param_2);
  if (unaff_D7 == 1) {
    u_flush(param_1);
  }
  if (-1 < (int)(uint)(unaff_D7 == 1)) {
    *(uint *)(param_1 + 0x22) = uVar4;
    *(int *)(param_1 + 0x18) = unaff_D7;
    if (0xff6 < uVar3) {
      uVar3 = 0xff8;
    }
    *(ushort *)(param_1 + 0x1c) = uVar3;
  }
  return;
}


// ==== u_rsize @ 01035faa

void u_rsize(undefined4 param_1)

{
  u_clbyt(param_1,1);
  return;
}


// ==== u_bbasset @ 01035fc0

int u_bbasset(int param_1)

{
  int iVar1;
  int *unaff_D7;
  int *piVar2;
  
  piVar2 = *(int **)(param_1 + 8);
  iVar1 = u_rsize(*(int *)(*(int *)(param_1 + 4) + 8) + 0xc);
  if (piVar2 == (int *)0x0) {
    iVar1 = f_fileio(*(undefined1 *)(param_1 + 0x27));
    *(int **)(param_1 + 8) = unaff_D7;
    piVar2 = unaff_D7;
  }
  if (piVar2 != (int *)0x0) {
    if ((*piVar2 == 0) && (malloc((size_t)unaff_D7), unaff_D7 != (int *)0x0)) {
      *(int **)((int)piVar2 + 0x12) = unaff_D7;
      *piVar2 = (int)unaff_D7;
      piVar2[1] = (int)unaff_D7;
      *(undefined4 *)((int)piVar2 + 0xe) = 0;
      piVar2[2] = 0;
      *(undefined1 *)(piVar2 + 3) = 0;
    }
    iVar1 = *piVar2;
  }
  return iVar1;
}


// ==== u_grwfil @ 01036040

void u_grwfil(int param_1,int param_2)

{
  short sVar1;
  int unaff_D7;
  short sVar2;
  int iVar3;
  
  setmap(*(undefined4 *)(param_1 + 4),param_2);
  sVar2 = (short)unaff_D7;
  iVar3 = (int)sVar2;
  if (0 < iVar3) {
    sVar1 = *(short *)(param_1 + 0x16);
    u_clsnm(param_1,(int)sVar1,*(int *)(param_1 + 0x1e) + -1);
    is_clstp(*(undefined4 *)(param_1 + 4),(int)sVar1);
    if (unaff_D7 < 1) {
      *(short *)(param_1 + 0x16) = sVar2;
      revword(iVar3);
      *(short *)(*(int *)(param_1 + 0xc) + 0x1a) = sVar2;
    }
    else {
      putcno(*(undefined4 *)(param_1 + 4),(int)sVar2,iVar3);
    }
    *(int *)(param_1 + 0x1e) = param_2 + *(int *)(param_1 + 0x1e);
    is_clstp(*(undefined4 *)(param_1 + 4),(int)*(short *)(param_1 + 0x1c));
    if (unaff_D7 < 1) {
      *(short *)(param_1 + 0x1c) = sVar2;
    }
  }
  return;
}


// ==== u_rdfio @ 010360fa

void u_rdfio(int param_1,uint param_2,undefined4 param_3)

{
  int *piVar1;
  int iVar2;
  uint unaff_D7;
  uint unaff_A4;
  
  u_bbasset(param_1);
  if (-1 < (int)unaff_D7) {
    piVar1 = *(int **)(param_1 + 8);
    iVar2 = (piVar1[2] + *piVar1) - *(int *)((int)piVar1 + 0x12);
    f_clpfio(piVar1,iVar2,iVar2,param_2);
    if (unaff_D7 != 0) {
      if ((int)unaff_D7 < 1) {
        u_charge(param_1);
        if ((0 < (int)unaff_D7) &&
           (unaff_A4 = (piVar1[2] + *piVar1) - *(int *)((int)piVar1 + 0x12), param_2 < unaff_A4)) {
          unaff_A4 = param_2;
        }
      }
      else {
        unaff_A4 = unaff_D7;
      }
      if (0 < (int)unaff_D7) {
        cpydata(*(undefined4 *)((int)piVar1 + 0x12),param_3,unaff_A4);
        u_skfcb(param_1,*(int *)(param_1 + 0x22) + unaff_A4);
      }
    }
  }
  return;
}


// ==== u_wrfio @ 010361a0

void u_wrfio(int param_1,uint param_2,undefined4 param_3)

{
  int *piVar1;
  uint unaff_D7;
  uint uVar2;
  
  u_bbasset(param_1);
  if ((int)unaff_D7 < 0) {
    return;
  }
  piVar1 = *(int **)(param_1 + 8);
  f_clpfio(piVar1,piVar1[2],(piVar1[1] + *piVar1) - *(int *)((int)piVar1 + 0x12),param_2);
  if (unaff_D7 == 0) {
    return;
  }
  if ((int)unaff_D7 < 1) {
    u_ftlcl(param_1,*(undefined4 *)(param_1 + 0x18));
    uVar2 = param_2;
    if ((int)unaff_D7 < 1) {
      u_grwfil(param_1,1);
    }
    else {
      if ((*(byte *)(param_1 + 0x15) & 1) != 0) {
        u_charge(param_1);
        if (0 < (int)unaff_D7) {
          uVar2 = (piVar1[1] + *piVar1) - *(int *)((int)piVar1 + 0x12);
          if (param_2 < uVar2) {
            uVar2 = param_2;
          }
          goto LAB_01036252;
        }
        if (unaff_D7 != 0xfffffff4) goto LAB_01036252;
      }
      unaff_D7 = 0;
    }
  }
  else {
    uVar2 = unaff_D7;
  }
LAB_01036252:
  if (-1 < (int)unaff_D7) {
    cpydata(param_3,*(undefined4 *)((int)piVar1 + 0x12),uVar2);
    if (uVar2 != 0) {
      *(byte *)(piVar1 + 3) = *(byte *)(piVar1 + 3) | 0x80;
      *(byte *)(param_1 + 0x15) = *(byte *)(param_1 + 0x15) | 0x80;
    }
    if (*(uint *)(param_1 + 0x10) <= uVar2 + *(int *)(param_1 + 0x22)) {
      *(uint *)(param_1 + 0x10) = uVar2 + *(int *)(param_1 + 0x22);
    }
    u_skfcb(param_1,*(int *)(param_1 + 0x22) + uVar2);
  }
  return;
}


// ==== u_charge @ 010362c0

void u_charge(int param_1)

{
  undefined4 *puVar1;
  int unaff_D7;
  
  puVar1 = *(undefined4 **)(param_1 + 8);
  if ((puVar1 != (undefined4 *)0x0) && (u_rdbuf(param_1,puVar1[1],*puVar1), -1 < unaff_D7)) {
    *(byte *)(puVar1 + 3) = *(byte *)(puVar1 + 3) | 1;
    puVar1[2] = unaff_D7;
  }
  return;
}


// ==== u_flush @ 01036302

void u_flush(int param_1)

{
  undefined4 *puVar1;
  int unaff_D7;
  
  puVar1 = *(undefined4 **)(param_1 + 8);
  if (((puVar1 != (undefined4 *)0x0) && (*(char *)(puVar1 + 3) < '\0')) &&
     (u_wrbuf(param_1,puVar1[1],*puVar1), -1 < unaff_D7)) {
    *(byte *)(puVar1 + 3) = *(byte *)(puVar1 + 3) & 0x7f;
    puVar1[2] = 0;
  }
  return;
}


// ==== u_rdbuf @ 01036350

void u_rdbuf(int param_1,uint param_2)

{
  int iVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  int unaff_D7;
  short sVar5;
  uint uVar6;
  uint local_14;
  
  iVar1 = *(int *)(param_1 + 4);
  iVar2 = *(int *)(iVar1 + 8) + 0xc;
  uVar6 = *(int *)(param_1 + 0x10) - *(int *)(param_1 + 0x22);
  if (param_2 < uVar6) {
    local_14 = param_2;
  }
  else {
    local_14 = uVar6;
  }
  u_clcnt(iVar2,local_14);
  sVar5 = *(short *)(param_1 + 0x1c);
  if ((param_2 != 0) && (iVar3 = 0, iVar4 = unaff_D7, 0 < (int)uVar6)) {
    for (; 0 < iVar4; iVar4 = iVar4 - unaff_D7) {
      u_clsnm(param_1,(int)sVar5,iVar3);
      sVar5 = (short)unaff_D7;
      u_clsidx(iVar1,(int)sVar5);
      u_contig(param_1,(int)sVar5,iVar4);
      u_clssl(iVar2);
      u_rwbkrn(0x20,iVar1);
      if (unaff_D7 < 0) {
        return;
      }
      u_clbyt(iVar2);
      iVar3 = unaff_D7;
    }
  }
  return;
}


// ==== u_wrbuf @ 01036454

/* WARNING: Removing unreachable block (ram,0x010364d0) */

void u_wrbuf(int param_1,int param_2)

{
  int iVar1;
  undefined4 uVar2;
  int iVar3;
  int iVar4;
  int unaff_D7;
  short sVar5;
  int iVar6;
  
  iVar1 = *(int *)(param_1 + 4);
  iVar3 = *(int *)(iVar1 + 8) + 0xc;
  uVar2 = *(undefined4 *)(param_1 + 0x18);
  u_clcnt(iVar3,param_2);
  u_ftlcl(param_1,uVar2);
  u_clcnt(iVar3,param_2);
  if (param_2 != 0) {
    sVar5 = *(short *)(param_1 + 0x1c);
    iVar4 = 0;
    for (iVar6 = unaff_D7; 0 < iVar6; iVar6 = iVar6 - unaff_D7) {
      u_clsnm(param_1,(int)sVar5,iVar4);
      sVar5 = (short)unaff_D7;
      u_clsidx(iVar1,(int)sVar5);
      u_contig(param_1,(int)sVar5,iVar6);
      u_clssl(iVar3);
      u_rwbkrn(0x21,iVar1);
      iVar4 = unaff_D7;
      if (unaff_D7 < 0) break;
      u_clbyt(iVar3);
    }
    if ((iVar4 == 0) && (u_clbyt(iVar3,unaff_D7), 0 < unaff_D7)) {
      *(byte *)(param_1 + 0x15) = *(byte *)(param_1 + 0x15) | 0x80;
    }
  }
  return;
}


// ==== u_read @ 010365a0

void u_read(undefined1 param_1,short param_2,int param_3)

{
  int iVar1;
  undefined1 uVar2;
  int unaff_D7;
  
  uVar2 = 0;
  u_fcb((int)param_2);
  iVar1 = -10;
  if (unaff_D7 != 0) {
    if (*(char *)(unaff_D7 + 0x27) == '\0') {
      iVar1 = -2;
    }
    else {
      uVar2 = *(undefined1 *)(*(int *)(unaff_D7 + 4) + 0x18);
      if ((*(byte *)(unaff_D7 + 0x15) & 1) != 0) {
        u_dirchk(*(int *)(unaff_D7 + 4),param_1);
        iVar1 = unaff_D7;
        if (-1 < unaff_D7) {
          if (param_3 == 0) {
            u_rdlin();
          }
          else {
            u_rdsub();
          }
        }
      }
    }
  }
  mkdoserr(uVar2,iVar1);
  return;
}


// ==== u_rdlin @ 0103663a

void u_rdlin(undefined4 param_1,undefined1 *param_2)

{
  int iVar1;
  int unaff_D7;
  
  iVar1 = 0;
  while( true ) {
    u_rdchar(param_1);
    if (unaff_D7 < 0) {
      return;
    }
    *param_2 = (char)unaff_D7;
    if (unaff_D7 == 10) break;
    iVar1 = iVar1 + 1;
    param_2 = param_2 + 1;
    if (0x87 < iVar1) {
      return;
    }
  }
  return;
}


// ==== u_rdchar @ 01036680

void u_rdchar(undefined4 param_1)

{
  undefined1 local_5;
  
  local_5 = 0;
  u_rdfio(param_1,1,&local_5);
  return;
}


// ==== u_rdsub @ 010366aa

void u_rdsub(int param_1,uint param_2,int param_3)

{
  uint unaff_D7;
  
  if (*(uint *)(param_1 + 0x10) < param_2) {
    param_2 = *(uint *)(param_1 + 0x10);
  }
  u_rdfio(param_1,param_2,param_3);
  if (-1 < (int)unaff_D7) {
    param_2 = param_2 - unaff_D7;
    if (0 < (int)param_2) {
      u_rsize(*(int *)(*(int *)(param_1 + 4) + 8) + 0xc);
      u_rdbuf(param_1,unaff_D7 * (param_2 / unaff_D7),unaff_D7 + param_3);
      if (-1 < (int)unaff_D7) {
        u_skfcb(param_1,*(int *)(param_1 + 0x22) + unaff_D7);
        if (0 < (int)(param_2 - unaff_D7)) {
          u_rdfio(param_1,param_2 - unaff_D7,unaff_D7 + unaff_D7 + param_3);
        }
      }
    }
  }
  return;
}


// ==== u_write @ 01036762

void u_write(undefined1 param_1,short param_2,int param_3)

{
  int iVar1;
  undefined1 uVar2;
  int unaff_D7;
  
  uVar2 = 0;
  u_fcb((int)param_2);
  iVar1 = -10;
  if ((unaff_D7 != 0) && (iVar1 = -2, *(char *)(unaff_D7 + 0x27) != '\0')) {
    uVar2 = *(undefined1 *)(*(int *)(unaff_D7 + 4) + 0x18);
    if ((*(byte *)(unaff_D7 + 0x15) & 2) != 0) {
      u_dirchk(*(int *)(unaff_D7 + 4),param_1);
      iVar1 = unaff_D7;
      if (-1 < unaff_D7) {
        if (param_3 == 0) {
          u_wrlin();
        }
        else {
          u_wrsub();
        }
      }
    }
  }
  mkdoserr(uVar2,iVar1);
  return;
}


// ==== u_wrlin @ 010367fa

void u_wrlin(undefined4 param_1,char *param_2)

{
  int iVar1;
  int unaff_D7;
  
  iVar1 = 0;
  while( true ) {
    u_wrchar(param_1,param_2);
    if (unaff_D7 < 0) {
      return;
    }
    if (*param_2 == '\n') break;
    iVar1 = iVar1 + 1;
    param_2 = param_2 + 1;
    if (0x87 < iVar1) {
      return;
    }
  }
  return;
}


// ==== u_wrchar @ 01036840

void u_wrchar(undefined4 param_1,undefined4 param_2)

{
  u_wrfio(param_1,1,param_2);
  return;
}


// ==== u_wrsub @ 0103685a

void u_wrsub(int param_1,int param_2,int param_3)

{
  uint uVar1;
  uint unaff_D7;
  
  u_wrfio(param_1,param_2,param_3);
  if (-1 < (int)unaff_D7) {
    uVar1 = param_2 - unaff_D7;
    if (0 < (int)uVar1) {
      u_rsize(*(int *)(*(int *)(param_1 + 4) + 8) + 0xc);
      u_wrbuf(param_1,unaff_D7 * (uVar1 / unaff_D7),unaff_D7 + param_3);
      if (-1 < (int)unaff_D7) {
        if (*(uint *)(param_1 + 0x10) <= unaff_D7 + *(int *)(param_1 + 0x22)) {
          *(uint *)(param_1 + 0x10) = unaff_D7 + *(int *)(param_1 + 0x22);
        }
        u_skfcb(param_1,*(int *)(param_1 + 0x22) + unaff_D7);
        if (0 < (int)(uVar1 - unaff_D7)) {
          u_wrfio(param_1,uVar1 - unaff_D7,unaff_D7 + unaff_D7 + param_3);
        }
      }
    }
  }
  return;
}


// ==== u_seek @ 0103691a

void u_seek(undefined4 param_1,short param_2)

{
  undefined1 uVar1;
  uint unaff_D7;
  uint uVar2;
  
  uVar1 = 0;
  u_fcb((int)param_2);
  uVar2 = 0xfffffff6;
  if (unaff_D7 != 0) {
    if (*(char *)(unaff_D7 + 0x27) == '\0') {
      uVar2 = 0xfffffffe;
    }
    else {
      uVar1 = *(undefined1 *)(*(int *)(unaff_D7 + 4) + 0x18);
      if ((*(byte *)(unaff_D7 + 0x15) & 3) != 2) {
        u_bbasset();
        uVar2 = unaff_D7;
        if (-1 < (int)unaff_D7) {
          u_target();
          uVar2 = 0xfffffffa;
          if ((-1 < (int)unaff_D7) && (unaff_D7 < *(uint *)(unaff_D7 + 0x10))) {
            u_skfcb();
            uVar2 = unaff_D7;
            if (-1 < (int)unaff_D7) {
              uVar2 = (uint)param_2;
            }
          }
        }
      }
    }
  }
  mkdoserr(uVar1,uVar2);
  return;
}


// ==== u_target @ 010369c0

int u_target(int param_1,int param_2,int param_3)

{
  if (param_1 != 0) {
    if (param_2 == 1) {
      return param_3 + *(int *)(param_1 + 0x22);
    }
    if (param_2 < 2) {
      if (param_2 == 0) {
        return param_3;
      }
    }
    else if (param_2 == 2) {
      return param_3 + *(int *)(param_1 + 0x10);
    }
  }
  return -10;
}


// ==== u_sidxge @ 01036a08

int u_sidxge(int param_1,uint param_2)

{
  return (int)(param_2 / *(ushort *)(param_1 + 0x1c)) / (int)(uint)*(ushort *)(param_1 + 0x1e);
}


// ==== u_gesidx @ 01036a6a

void u_gesidx(void)

{
  return;
}


// ==== cverfdms @ 01036a72

undefined4 cverfdms(uint param_1)

{
  if ((param_1 & 0x400000) == 0) {
    if ((param_1 & 0x4000) != 0) {
      return 0xffffffd2;
    }
    if ((param_1 & 0x8080) == 0) {
      if ((param_1 & 0x7c007e99) == 0) {
        return 0;
      }
      return 0xfffffff8;
    }
  }
  else if ((param_1 & 0x800000) == 0) {
    return 0xffffffd3;
  }
  return 0xfffffffc;
}


// ==== u_swpchk @ 01036ac0

/* WARNING: Removing unreachable block (ram,0x01036b06) */
/* WARNING: Removing unreachable block (ram,0x01036b1c) */

void u_swpchk(undefined4 param_1)

{
  byte bVar1;
  int unaff_D7;
  
  u_dph(param_1);
  bVar1 = 0;
  isdskchg(param_1);
  if (unaff_D7 == 1) {
    cldskchg(param_1);
    bVar1 = 2;
  }
  if (*(char *)(unaff_D7 + 0x19) != '\0') {
    bVar1 = *(byte *)(unaff_D7 + 0x29) & 0x40 | bVar1;
  }
  *(byte *)(unaff_D7 + 0x29) = *(byte *)(unaff_D7 + 0x29) & 4 | bVar1;
  return;
}


// ==== u_fdrq @ 01036b54

void u_fdrq(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5,
           undefined4 param_6,undefined4 param_7,uint *param_8)

{
  int unaff_D7;
  uint local_8;
  
  local_8 = 0;
  u_swpchk(param_2);
  if (unaff_D7 == 0) {
    if (param_1 == 0x20) {
      rqfdscrd(param_2,param_3,param_4,param_5,param_6,param_7,&local_8);
      unaff_D7 = 0;
    }
    else if (param_1 == 0x21) {
      rqfdscwr(param_2,param_3,param_4,param_5,param_6,param_7,&local_8);
    }
    else {
      unaff_D7 = 0x40000000;
    }
    *param_8 = local_8 | *param_8;
  }
  cverfdms(unaff_D7);
  alr_mdst(param_2);
  return;
}


// ==== u_rwstrn @ 01036c06

void u_rwstrn(undefined1 param_1,int param_2,int param_3,uint param_4,int param_5,uint *param_6)

{
  int iVar1;
  undefined1 uVar2;
  int iVar3;
  byte bVar4;
  uint uVar5;
  uint unaff_D7;
  uint local_1a;
  uint local_c;
  undefined4 local_8;
  
  local_c = 0;
  iVar1 = *(int *)(param_2 + 8);
  iVar3 = *(int *)(param_2 + 0x24);
  local_1a = (uint)*(ushort *)(iVar1 + 0xc);
  uVar2 = *(undefined1 *)(param_2 + 0x18);
  if ((param_4 != 0) && (param_4 + param_3 <= (uint)*(ushort *)(iVar1 + 0x16))) {
    for (; param_4 != 0; param_4 = param_4 - uVar5) {
      u_sidxge(iVar1,param_3);
      local_8._3_1_ = (char)unaff_D7;
      if (param_4 < (uint)*(ushort *)(iVar1 + 0x1c) - (unaff_D7 & 0xff)) {
        bVar4 = (byte)param_4;
      }
      else {
        bVar4 = (char)*(undefined2 *)(iVar1 + 0x1c) - (char)local_8;
      }
      uVar5 = (uint)bVar4;
      local_8 = unaff_D7;
      u_fdrq(param_1,uVar2,unaff_D7 >> 0x10,unaff_D7 >> 8 & 0xff,(unaff_D7 & 0xff) - (iVar3 >> 0x1f)
             ,uVar5,param_5,&local_c);
      *param_6 = local_c & 0xffff;
      param_3 = uVar5 + param_3;
      param_5 = local_1a * uVar5 + param_5;
      unaff_D7 = unaff_D7 >> 0x10;
    }
  }
  return;
}


// ==== u_fdblkrq @ 01036d24

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void u_fdblkrq(int param_1,int param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5,
              uint *param_6)

{
  int unaff_D7;
  uint local_8;
  
  local_8 = 0;
  u_swpchk(*(undefined1 *)(param_2 + 0x18));
  if (unaff_D7 == 0) {
    DAT_0107da51 = *(undefined1 *)(param_2 + 0x18);
    DAT_0107da52 = 0;
    DAT_0107da53 = 0;
    DAT_0107da54 = 0;
    DAT_0107da55 = 0;
    _DAT_0107da56 = param_5;
    _DAT_0107da5a = 0;
    _DAT_0107da6a = param_2;
    _DAT_0107da6e = param_3;
    _DAT_0107da72 = param_4;
    if (param_1 == 0x20) {
      fdreqwk = 0x40;
      fdreq(&fdreqwk,&local_8);
      unaff_D7 = 0;
    }
    else if (param_1 == 0x21) {
      fdreqwk = 0x41;
      fdreq(&fdreqwk,&local_8);
    }
    else {
      unaff_D7 = 0x40000000;
    }
    *param_6 = local_8 | *param_6;
  }
  cverfdms(unaff_D7);
  alr_mdst(*(undefined1 *)(param_2 + 0x18));
  return;
}


// ==== u_rwbkrn @ 01036e0e

void u_rwbkrn(undefined1 param_1,int param_2,int param_3,int param_4,undefined4 param_5,
             uint *param_6)

{
  uint local_8;
  
  local_8 = 0;
  if ((param_4 != 0) &&
     ((uint)(param_4 + param_3) <= (uint)*(ushort *)(*(int *)(param_2 + 8) + 0x16))) {
    u_fdblkrq(param_1,param_2,param_3,param_4,param_5,&local_8);
    *param_6 = local_8 & 0xffff;
  }
  return;
}


// ==== u_rdsct @ 01036e7c

void u_rdsct(uint param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6)

{
  int unaff_D7;
  undefined1 auStack_8 [4];
  
  if ((&DAT_0107c8c1)[param_1 * 0x2a] == '\0') {
    rqfdslct(param_1,auStack_8);
    edl_echk();
    if (unaff_D7 < 0) goto LAB_01036ef8;
  }
  rqfdscrd(param_1,param_2,param_3,param_4,param_5,param_6,auStack_8);
  if ((&DAT_0107c8c1)[param_1 * 0x2a] == '\0') {
    rqfdrels(param_1,auStack_8);
  }
LAB_01036ef8:
  mkdoserr(param_1 & 0xff);
  return;
}


// ==== u_wrsct @ 01036f10

void u_wrsct(uint param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined *param_5,undefined4 param_6)

{
  int iVar1;
  int unaff_D7;
  undefined **ppuVar2;
  undefined *local_24;
  uint local_20;
  undefined4 local_1c;
  undefined1 auStack_8 [4];
  
  iVar1 = param_1 * 0x2a;
  if ((&DAT_0107c8c1)[iVar1] == '\0') {
    local_1c = auStack_8;
    local_20 = param_1;
    local_24 = (undefined *)0x1036f3c;
    rqfdslct();
    local_24 = (undefined *)0x1;
    edl_echk();
    ppuVar2 = (undefined **)(auStack_8 + -0x10);
    if (unaff_D7 < 0) goto LAB_01036fa0;
  }
  local_20 = param_6;
  local_24 = param_5;
  local_1c = auStack_8;
  rqfdscwr(param_1,param_2,param_3,param_4);
  if ((&DAT_0107c8c1)[iVar1] == '\0') {
    local_20 = param_1;
    local_24 = (undefined *)0x1036f8a;
    local_1c = auStack_8;
    rqfdrels();
  }
  local_1c = (undefined1 *)0x0;
  local_20 = (uint)client;
  local_24 = &msdph + iVar1;
  u_zapall();
  ppuVar2 = &local_24;
LAB_01036fa0:
  *(int *)((int)ppuVar2 + -4) = unaff_D7;
  *(uint *)((int)ppuVar2 + -8) = param_1 & 0xff;
  *(undefined4 *)((int)ppuVar2 + -0xc) = 0x1036fae;
  mkdoserr();
  return;
}


// ==== u_dcnfg @ 01036fb8

void u_dcnfg(uint param_1,undefined4 param_2)

{
  uint uVar1;
  uint uVar2;
  int iVar3;
  undefined4 unaff_A6;
  byte local_c;
  undefined1 uStack_b;
  ushort uStack_a;
  byte local_8;
  undefined1 uStack_7;
  ushort uStack_6;
  undefined1 local_4;
  undefined1 uStack_3;
  undefined2 uStack_2;
  
  local_4 = (undefined1)((uint)unaff_A6 >> 0x18);
  uStack_3 = (undefined1)((uint)unaff_A6 >> 0x10);
  uStack_2 = (undefined2)unaff_A6;
  rqfdgvfg(param_1,&local_8,param_2);
  local_c = local_8 & 0xf0;
  iVar3 = ((CONCAT22(CONCAT11(local_8,uStack_7),uStack_6) & 0xfffffff) >> 0x17) << 0x16;
  local_c = local_c | (byte)((uint)iVar3 >> 0x18);
  uStack_b = (undefined1)((uint)iVar3 >> 0x10);
  uVar2 = CONCAT31(CONCAT12(uStack_b,uStack_a),local_8) & 0xc00fffff;
  uVar1 = uVar2 | ((CONCAT31(CONCAT12(uStack_7,uStack_6),local_4) & 0x7fffffff) >> 0x18) << 0x14;
  uStack_b = (undefined1)(uVar1 >> 0x18);
  uStack_a = (ushort)(uVar1 >> 8);
  local_8 = (byte)uVar2;
  uVar1 = CONCAT31(CONCAT21(uStack_a,local_8),uStack_7) & 0xf1ffffff;
  uStack_a = (ushort)(uVar1 >> 0x10) | (ushort)(((uint)(uStack_6 >> 0xf) << 0x19) >> 0x10);
  local_8 = (byte)(uVar1 >> 8);
  uStack_7 = (undefined1)uVar1;
  mkdoserr(param_1 & 0xff,CONCAT22(CONCAT11(local_c,uStack_b),uStack_a));
  return;
}


// ==== is_clstp @ 01037034

undefined4 is_clstp(int param_1,short param_2)

{
  bool bVar1;
  undefined4 uVar2;
  
  bVar1 = false;
  if ((0xff7 < param_2) && (param_2 < 0x1000)) {
    bVar1 = true;
  }
  if (bVar1) {
    uVar2 = 0;
  }
  else if (param_2 + -2 < 0) {
    uVar2 = 0xffffffff;
  }
  else if (param_2 + -2 < (int)(uint)*(ushort *)(param_1 + 0x1e)) {
    uVar2 = 1;
  }
  else {
    uVar2 = 0xfffffffe;
  }
  return uVar2;
}


// ==== getcno @ 0103707e

void getcno(int param_1,short param_2)

{
  short unaff_D7w;
  
  is_clstp(param_1,(int)param_2);
  if ((-1 < unaff_D7w) && (unaff_D7w != 0)) {
    rd_word(*(int *)(param_1 + 0xc) +
            (int)param_2 + ((int)param_2 >> (*(ushort *)(param_1 + 0x1e) < 0xff6)));
    revword((int)unaff_D7w);
  }
  return;
}


// ==== putcno @ 01037106

void putcno(int param_1,short param_2,ushort param_3)

{
  bool bVar1;
  ushort uVar2;
  uint uVar3;
  ushort unaff_D7w;
  byte *pbVar4;
  
  uVar2 = 0;
  is_clstp(param_1,(int)param_2);
  bVar1 = *(ushort *)(param_1 + 0x1e) < 0xff6;
  uVar3 = (uint)param_2;
  pbVar4 = (byte *)(*(int *)(param_1 + 0xc) + uVar3 + ((int)uVar3 >> bVar1));
  if ((-1 < (short)unaff_D7w) && (unaff_D7w != 0)) {
    if (bVar1) {
      if ((uVar3 & 1) == 0) {
        uVar2 = pbVar4[1] & 0xf0;
        param_3 = param_3 & 0xfff;
      }
      else {
        uVar2 = (*pbVar4 & 0xf) << 8;
        param_3 = param_3 << 4;
      }
    }
    revword((int)(short)param_3);
    wr_word(pbVar4,(int)(short)(unaff_D7w | uVar2));
    *(byte *)(param_1 + 0x28) = *(byte *)(param_1 + 0x28) | 0x80;
  }
  return;
}


// ==== resmap @ 010371ca

void resmap(int param_1,short param_2)

{
  short sVar1;
  int unaff_D7;
  int iVar2;
  
  sVar1 = 0;
  while( true ) {
    is_clstp(param_1,(int)param_2);
    if (unaff_D7 < 1) break;
    iVar2 = (int)param_2;
    getcno(param_1,iVar2);
    param_2 = (short)unaff_D7;
    putcno(param_1,iVar2,0);
    sVar1 = sVar1 + 1;
  }
  *(short *)(param_1 + 0x1c) = *(short *)(param_1 + 0x1c) - sVar1;
  return;
}


// ==== setmap @ 01037226

void setmap(int param_1,int param_2)

{
  int iVar1;
  short unaff_D4w;
  short unaff_D7w;
  
  u_sffrcl(param_1,param_2);
  if (0 < unaff_D7w) {
    iVar1 = param_2;
    while ((iVar1 = iVar1 + -1, 0 < iVar1 && (-1 < unaff_D7w))) {
      u_cufrcl(param_1,unaff_D7w + 1);
      putcno(param_1,(int)unaff_D7w,(int)unaff_D7w);
      unaff_D4w = unaff_D7w;
    }
    if ((unaff_D4w < 0) || (iVar1 < 1)) {
      putcno(param_1,(int)unaff_D7w,0xff8);
    }
    *(short *)(param_1 + 0x1c) = (short)param_2 + *(short *)(param_1 + 0x1c);
  }
  return;
}


// ==== u_sffrcl @ 010372aa

void u_sffrcl(int param_1,int param_2)

{
  ushort uVar1;
  short sVar2;
  short sVar3;
  int unaff_D7;
  
  uVar1 = *(ushort *)(param_1 + 0x1e);
  sVar2 = 2;
  sVar3 = 0;
  if (((-1 < param_2) && (param_2 != 0)) &&
     (param_2 <=
      (int)(-(uint)*(ushort *)(param_1 + 0x1c) - ((uint)*(ushort *)(param_1 + 0x1a) - (uint)uVar1)))
     ) {
    for (; sVar2 < (short)(uVar1 + 2); sVar2 = (short)unaff_D7 + sVar2 + 1) {
      u_ctuscl(param_1,(int)sVar2);
      sVar2 = (short)unaff_D7 + sVar2;
      if (sVar3 == 0) {
        sVar3 = sVar2;
      }
      u_ctfrcl(param_1,(int)sVar2);
      if (param_2 <= unaff_D7) {
        return;
      }
    }
  }
  return;
}


// ==== u_ctfrcl @ 01037342

void u_ctfrcl(int param_1,short param_2)

{
  short sVar1;
  short unaff_D7w;
  int iVar2;
  
  sVar1 = *(short *)(param_1 + 0x1e) + 2;
  iVar2 = 0;
  if (param_2 < sVar1) {
    do {
      getcno(param_1,iVar2 + param_2);
      if (unaff_D7w != 0) {
        return;
      }
      iVar2 = iVar2 + 1;
    } while (param_2 + iVar2 < (int)sVar1);
  }
  return;
}


// ==== u_ctuscl @ 01037392

void u_ctuscl(int param_1,short param_2)

{
  short sVar1;
  short unaff_D7w;
  int iVar2;
  
  sVar1 = *(short *)(param_1 + 0x1e) + 2;
  iVar2 = 0;
  if (param_2 < sVar1) {
    do {
      getcno(param_1,iVar2 + param_2);
      if (unaff_D7w == 0) {
        return;
      }
      iVar2 = iVar2 + 1;
    } while (param_2 + iVar2 < (int)sVar1);
  }
  return;
}


// ==== u_cufrcl @ 010373e2

undefined4 u_cufrcl(int param_1,short param_2)

{
  short sVar1;
  undefined2 extraout_D0u;
  undefined4 uVar2;
  short unaff_D7w;
  
  sVar1 = *(short *)(param_1 + 0x1e);
  u_ctuscl(param_1,(int)param_2);
  uVar2 = CONCAT22(extraout_D0u,unaff_D7w + param_2);
  if ((short)(sVar1 + 2) <= (short)(unaff_D7w + param_2)) {
    uVar2 = 0xfffffffe;
  }
  return uVar2;
}


// ==== u_kind @ 0103741c

void u_kind(void)

{
  return;
}


// ==== u_fcopy @ 01037426

void u_fcopy(undefined1 param_1,byte param_2,undefined4 param_3,undefined1 param_4,
            undefined4 param_5)

{
  short sVar1;
  uint unaff_D7;
  uint local_e;
  
  local_e = (uint)param_2;
  u_open(param_1,local_e,param_3,0);
  dosstt();
  if (-1 < (int)unaff_D7) {
    sVar1 = (short)unaff_D7;
    u_open(param_1,param_4,param_5,1);
    dosstt();
    if ((int)unaff_D7 < 0) {
      u_create(param_1,param_4,param_5,1,0x800);
    }
    dosstt();
    if (-1 < (int)unaff_D7) {
      u_fcpsub(param_1,(int)sVar1,(int)sVar1);
      dosstt();
      u_close(param_1,(int)sVar1);
      dosstt();
      if (((unaff_D7 == 0xfffffff4) || (-1 < (int)unaff_D7)) && ((int)unaff_D7 < 0)) {
        errdrive();
        local_e = unaff_D7 & 0xff;
      }
    }
    u_close(param_1,(int)sVar1);
  }
  mkdoserr(local_e);
  return;
}


// ==== u_fcpsub @ 0103754e

void u_fcpsub(undefined1 param_1,short param_2,short param_3)

{
  undefined1 *unaff_D7;
  size_t __size;
  undefined1 *puVar1;
  bool bVar2;
  undefined1 auStack_204 [512];
  
  u_fcb((int)param_2);
  if (*(uint *)(unaff_D7 + 0x10) < 0xc000) {
    __size = *(size_t *)(unaff_D7 + 0x10);
  }
  else {
    __size = 0xc000;
  }
  puVar1 = (undefined1 *)0x0;
  while ((0x200 < (int)__size && (malloc(__size), puVar1 = unaff_D7, unaff_D7 == (undefined1 *)0x0))
        ) {
    __size = (int)__size >> 1;
  }
  bVar2 = puVar1 == (undefined1 *)0x0;
  if (bVar2) {
    puVar1 = auStack_204;
  }
  while( true ) {
    u_read(param_1,(int)param_2,__size,puVar1);
    dosstt();
    errdrive();
    if ((int)unaff_D7 < 1) break;
    u_write(param_1,(int)param_3);
    dosstt();
    errdrive();
    if (((int)unaff_D7 < 0) || ((int)unaff_D7 < 1)) break;
  }
  if (!bVar2) {
    mfree(puVar1);
  }
  mkdoserr((uint)unaff_D7 & 0xff);
  return;
}


// ==== u_remain @ 01037664

void u_remain(undefined1 param_1)

{
  int iVar1;
  int unaff_D7;
  
  u_dph(param_1);
  iVar1 = -10;
  if (unaff_D7 != 0) {
    if (*(char *)(unaff_D7 + 0x19) == '\0') {
      iVar1 = -4;
    }
    else {
      u_clbyt(*(int *)(unaff_D7 + 8) + 0xc,
              -((uint)*(ushort *)(unaff_D7 + 0x1c) -
               ((uint)*(ushort *)(unaff_D7 + 0x1e) - (uint)*(ushort *)(unaff_D7 + 0x1a))));
      iVar1 = unaff_D7;
    }
  }
  mkdoserr(param_1,iVar1);
  return;
}


// ==== u_volcpy @ 010376dc

void u_volcpy(byte param_1,undefined1 param_2)

{
  int iVar1;
  ushort uVar2;
  int iVar3;
  uint uVar4;
  uint unaff_D7;
  undefined4 local_8;
  
  local_8 = 0;
  uVar4 = (uint)param_1;
  u_dph(uVar4);
  iVar3 = *(int *)(unaff_D7 + 8);
  u_dph(param_2);
  iVar1 = *(int *)(unaff_D7 + 8);
  uVar2 = *(ushort *)(iVar3 + 0x1c);
  if (uVar2 < 10) {
    iVar3 = 8;
  }
  else {
    iVar3 = 0x10;
  }
  u_dirchk();
  if (-1 < (int)unaff_D7) {
    if (uVar2 < *(ushort *)(iVar1 + 0x1c)) {
      unaff_D7 = 0xffffffdd;
    }
    else {
      malloc(iVar3 << 10);
      if (unaff_D7 == 0) {
        unaff_D7 = 0xffffffcc;
      }
      else {
        u_zapall(param_2,client,0);
        u_cpyv(param_1,param_2);
        dosstt();
        errdrive();
        uVar4 = unaff_D7 & 0xff;
        rqfdrels(param_2,&local_8);
        mfree();
      }
    }
  }
  mkdoserr(uVar4,unaff_D7);
  return;
}


// ==== u_cpyv @ 010377f8

void u_cpyv(undefined1 param_1,undefined1 param_2,undefined4 param_3,uint *param_4)

{
  int iVar1;
  ushort uVar2;
  ushort uVar3;
  ushort uVar4;
  undefined1 uVar5;
  uint uVar6;
  undefined1 uVar7;
  uint unaff_D7;
  uint uVar8;
  uint uVar9;
  uint local_8;
  
  local_8 = 0;
  uVar9 = 0;
  u_dph(param_1);
  iVar1 = *(int *)(unaff_D7 + 8);
  uVar5 = (undefined1)*(undefined2 *)(iVar1 + 0x1c);
  uVar2 = *(ushort *)(iVar1 + 0x16);
  uVar3 = *(ushort *)(iVar1 + 0x1c);
  uVar4 = *(ushort *)(iVar1 + 0x1e);
  uVar7 = param_1;
  for (uVar8 = 0; uVar8 < ((int)(uint)uVar2 / (int)((uint)uVar3 * (uint)uVar4) & 0xffU);
      uVar8 = uVar8 + 1) {
    uVar6 = 0;
    if (*(short *)(iVar1 + 0x1e) != 0) {
      do {
        rqfdscrd(param_1,uVar8,uVar6,1,uVar5,param_3,&local_8);
        *param_4 = local_8 | *param_4;
        uVar7 = param_1;
        if ((unaff_D7 & 0x7e99) == 0) {
          rqfdscwr(param_2,uVar8,uVar6,1,uVar5,param_3,&local_8);
          *param_4 = local_8 | *param_4;
          uVar7 = param_2;
          if ((unaff_D7 & 0x7e99) != 0) goto LAB_010378ea;
        }
        else {
LAB_010378ea:
          cverfdms();
          uVar9 = unaff_D7;
        }
      } while ((-1 < (int)uVar9) && (uVar6 = uVar6 + 1, uVar6 < *(ushort *)(iVar1 + 0x1e)));
    }
    if ((int)uVar9 < 0) break;
  }
  mkdoserr(uVar7,uVar9);
  return;
}


// ==== u_zapfck @ 01037930

void u_zapfck(undefined4 *param_1,char param_2)

{
  if (param_1 != (undefined4 *)0x0) {
    for (; (param_1 != (undefined4 *)0x0 && (param_2 == *(char *)((int)param_1 + 0x27)));
        param_1 = (undefined4 *)*param_1) {
    }
  }
  return;
}


// ==== u_zapchk @ 0103795e

void u_zapchk(undefined4 *param_1,undefined1 param_2)

{
  int unaff_D7;
  
  u_ctusr(*(undefined1 *)(param_1 + 6),param_2);
  if ((-1 < unaff_D7) && (unaff_D7 < 1)) {
    u_zapfck(*param_1,param_2);
  }
  return;
}


// ==== u_zapfcb @ 010379b4

void u_zapfcb(int param_1,int param_2)

{
  int iVar1;
  
  iVar1 = *(int *)(param_1 + 8);
  if (param_2 == 1) {
    u_flush(param_1);
  }
  *(undefined1 *)(iVar1 + 0xc) = 0;
  *(undefined1 *)(iVar1 + 0xd) = 0;
  zap_ptr(iVar1,mfree);
  *(undefined4 *)(param_1 + 8) = 0;
  *(undefined1 *)(param_1 + 0x27) = 0;
  return;
}


// ==== u_zapfcq @ 01037a04

void u_zapfcq(int *param_1,undefined4 param_2)

{
  int *piVar1;
  int unaff_D7;
  
  piVar1 = (int *)*param_1;
  if ((param_1 != (int *)0x0) && (piVar1 != (int *)0x0)) {
    u_zapfcq(piVar1,param_2);
    u_zapfcb(piVar1,param_2);
    if (-1 < unaff_D7) {
      *param_1 = *piVar1;
    }
  }
  return;
}


// ==== u_zapflg @ 01037a46

void u_zapflg(int param_1)

{
  *(undefined1 *)(param_1 + 0x19) = 0;
  *(byte *)(param_1 + 0x28) = *(byte *)(param_1 + 0x28) | 0x10;
  return;
}


// ==== u_zapdph @ 01037a62

void u_zapdph(int param_1,undefined1 param_2,int param_3)

{
  if (param_3 == 1) {
    u_putdir(param_1,param_2);
  }
  zap_ptr(param_1 + 8,mfree);
  zap_ptr(param_1 + 0xc,mfree);
  dec_mdst(param_2,*(undefined1 *)(param_1 + 0x18));
  u_zapflg(param_1);
  return;
}


// ==== u_zapall @ 01037ad6

void u_zapall(undefined1 param_1)

{
  undefined4 *unaff_D7;
  
  u_dph(param_1);
  u_zapfcq();
  if (-1 < (int)unaff_D7) {
    *unaff_D7 = 0;
    unaff_D7[1] = 0;
    u_zapdph();
  }
  return;
}


// ==== bcmp @ 01037b2c

int bcmp(void *__s1,void *__s2,size_t __n)

{
  char cVar1;
  char cVar2;
  
  if (__n != 0) {
    for (; 0 < (int)__n; __n = __n - 1) {
      cVar1 = *(char *)__s2;
      __s2 = (void *)((int)__s2 + 1);
      cVar2 = *(char *)__s1;
      __s1 = (void *)((int)__s1 + 1);
      if (cVar2 != cVar1) {
        return __n;
      }
    }
  }
  return __n;
}


// ==== fdrive @ 01037b52

void fdrive(undefined4 param_1)

{
  DAT_0107d7a4 = param_1;
  return;
}


// ==== fopen @ 01037b64

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

FILE * fopen(char *__filename,char *__modes)

{
  FILE *in_D0;
  int unaff_D7;
  int iVar1;
  char *pcVar2;
  undefined1 auStack_14 [4];
  char acStack_10 [8];
  char acStack_8 [4];
  
  if ((_DAT_0107d7a0 == 0) && (in_D0 = (FILE *)strcmp(__modes,"r"), unaff_D7 == 0)) {
    fill(&_iob,0x14,0);
    iVar1 = 0;
    do {
      pcVar2 = __filename;
      if ((*__filename == '.') || (*__filename == '\0')) break;
      pcVar2 = __filename + 1;
      acStack_10[iVar1] = *__filename;
      iVar1 = iVar1 + 1;
      __filename = pcVar2;
    } while (iVar1 < 8);
    if (*pcVar2 == '.') {
      pcVar2 = pcVar2 + 1;
    }
    for (; iVar1 < 8; iVar1 = iVar1 + 1) {
      acStack_10[iVar1] = ' ';
    }
    for (; (iVar1 < 0xb && (*pcVar2 != '\0')); pcVar2 = pcVar2 + 1) {
      acStack_10[iVar1] = *pcVar2;
      iVar1 = iVar1 + 1;
    }
    for (; iVar1 < 0xb; iVar1 = iVar1 + 1) {
      acStack_10[iVar1] = ' ';
    }
    acStack_10[iVar1] = '\0';
    fs_open(DAT_0107d7a4,acStack_10,0,auStack_14);
    DAT_0108670a = 0;
    in_D0 = (FILE *)0x1;
    _DAT_0107d7a0 = 1;
    DAT_01086700 = &DAT_0107da84;
    DAT_01086704 = 0x2000;
  }
  return in_D0;
}


// ==== fclose @ 01037c46

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

int fclose(FILE *__stream)

{
  int in_D0;
  int unaff_D7;
  undefined1 auStack_8 [4];
  
  if ((_DAT_0107d7a0 != 0) && (__stream == (FILE *)&_iob)) {
    in_D0 = fs_clos(DAT_0107d7a4,(int)DAT_0108670a,auStack_8);
    if (unaff_D7 < 0) {
      uRam01086708 = 0x20;
    }
    else {
      _DAT_0107d7a0 = 0;
    }
  }
  return in_D0;
}


// ==== FUN_01037c96 @ 01037c96

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_01037c96(undefined *param_1)

{
  int unaff_D7;
  undefined1 auStack_8 [4];
  
  if (_DAT_0107d7a0 == 0) {
    return;
  }
  if (param_1 != &_iob) {
    return;
  }
  if (__iob < 1) {
    fs_read(DAT_0107d7a4,(int)DAT_0108670a,DAT_01086704,DAT_01086700,auStack_8);
    if (unaff_D7 < 0) {
      __iob = unaff_D7;
      uRam01086708 = uRam01086708 | 0x20;
      return;
    }
    if (unaff_D7 == 0) {
      __iob = unaff_D7;
      uRam01086708 = uRam01086708 | 0x10;
      return;
    }
    iRam010866fc = DAT_01086700;
    __iob = unaff_D7;
  }
  iRam010866fc = iRam010866fc + 1;
  __iob = __iob + -1;
  return;
}


// ==== fread @ 01037d10

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

size_t fread(void *__ptr,size_t __size,size_t __n,FILE *__stream)

{
  size_t in_D0;
  int iVar1;
  int iVar2;
  int unaff_D7;
  undefined1 auStack_8 [4];
  
  if (((_DAT_0107d7a0 != 0) && (__stream == (FILE *)&_iob)) && (iVar2 = __n * __size, 0 < iVar2)) {
    while (0 < iVar2) {
      if (__iob < 1) {
        fs_read(DAT_0107d7a4,(int)DAT_0108670a,DAT_01086704,DAT_01086700,auStack_8);
        __iob = unaff_D7;
        if (unaff_D7 < 0) {
          uRam01086708 = uRam01086708 | 0x20;
          break;
        }
        if (unaff_D7 == 0) {
          uRam01086708 = uRam01086708 | 0x10;
          break;
        }
        iRam010866fc = DAT_01086700;
      }
      else {
        if (iVar2 < __iob) {
          iVar1 = iVar2;
        }
        else {
          iVar1 = __iob;
        }
        cpybuf(iRam010866fc,__ptr,iVar1);
        iRam010866fc = iVar1 + iRam010866fc;
        __iob = __iob - iVar1;
        __ptr = (void *)(iVar1 + (int)__ptr);
        iVar2 = iVar2 - iVar1;
      }
    }
    in_D0 = __size;
  }
  return in_D0;
}


// ==== FUN_01037dcc @ 01037dcc

void FUN_01037dcc(void)

{
  uint uVar1;
  uint uVar2;
  uint uVar3;
  
  uVar3 = 0;
  do {
    uVar2 = 0;
    uVar1 = uVar3;
    do {
      if ((uVar1 & 1) == 0) {
        uVar1 = uVar1 >> 1;
      }
      else {
        uVar1 = CONCAT22((ushort)(uVar1 >> 0x11),(short)(uVar1 >> 1)) ^ 0xa001;
      }
      uVar2 = uVar2 + 1;
    } while (uVar2 < 8);
    (&DAT_0107fa84)[uVar3] = (short)uVar1;
    uVar3 = uVar3 + 1;
  } while (uVar3 < 0x100);
  return;
}


// ==== FUN_01037e06 @ 01037e06

void FUN_01037e06(byte *param_1,int param_2)

{
  for (; param_2 != 0; param_2 = param_2 + -1) {
    DAT_0107fc84 = (&DAT_0107fa84)[((uint)*param_1 ^ (uint)DAT_0107fc84) & 0xff] ^ DAT_0107fc84 >> 8
    ;
    param_1 = param_1 + 1;
  }
  return;
}


// ==== FUN_01037e68 @ 01037e68

void FUN_01037e68(byte param_1)

{
  int iVar1;
  uint uVar2;
  byte unaff_D7b;
  int *piVar3;
  
  if (DAT_0107fc86 < param_1) {
    do {
      piVar3 = DAT_0107d7a8;
      param_1 = param_1 - DAT_0107fc86;
      DAT_0107fc88 = (short)((int)(uint)DAT_0107fc8a >> (8 - DAT_0107fc86 & 0x3f)) +
                     (DAT_0107fc88 << (DAT_0107fc86 & 0x3f));
      if (DAT_0107fc8c == 0) {
        DAT_0107fc8a = 0;
      }
      else {
        DAT_0107fc8c = DAT_0107fc8c + -1;
        iVar1 = *DAT_0107d7a8;
        *DAT_0107d7a8 = iVar1 + -1;
        if (iVar1 + -1 < 0) {
          FUN_01037c96(DAT_0107d7a8);
          DAT_0107fc8a = unaff_D7b;
        }
        else {
          piVar3 = piVar3 + 1;
          DAT_0107fc8a = *(byte *)*piVar3;
          *piVar3 = *piVar3 + 1;
        }
      }
      DAT_0107fc86 = 8;
    } while (8 < param_1);
  }
  DAT_0107fc86 = DAT_0107fc86 - param_1;
  uVar2 = (uint)param_1;
  DAT_0107fc88 = (short)((int)(uint)DAT_0107fc8a >> (8 - uVar2 & 0x3f)) +
                 (DAT_0107fc88 << (uVar2 & 0x3f));
  DAT_0107fc8a = DAT_0107fc8a << (uVar2 & 0x3f);
  return;
}


// ==== FUN_01037f4a @ 01037f4a

void FUN_01037f4a(undefined1 param_1)

{
  FUN_01037e68(param_1);
  return;
}


// ==== FUN_01037f78 @ 01037f78

void FUN_01037f78(void)

{
  DAT_0107fc88 = 0;
  DAT_0107fc8a = 0;
  DAT_0107fc86 = 0;
  FUN_01037e68(0x10);
  return;
}


// ==== FUN_01037f9c @ 01037f9c

void FUN_01037f9c(undefined4 param_1,int param_2)

{
  for (; param_2 != 0; param_2 = param_2 + -1) {
  }
  return;
}


// ==== FUN_01037fc4 @ 01037fc4

undefined2 FUN_01037fc4(void)

{
  undefined1 uVar1;
  undefined1 *puVar2;
  
  uVar1 = *DAT_0107fc90;
  puVar2 = DAT_0107fc90 + 1;
  DAT_0107fc90 = DAT_0107fc90 + 2;
  return CONCAT11(*puVar2,uVar1);
}


// ==== FUN_01037ff4 @ 01037ff4

int FUN_01037ff4(void)

{
  byte *pbVar1;
  byte *pbVar2;
  byte *pbVar3;
  
  pbVar1 = (byte *)(DAT_0107fc90 + 1);
  pbVar2 = (byte *)(DAT_0107fc90 + 2);
  pbVar3 = (byte *)(DAT_0107fc90 + 3);
  DAT_0107fc90 = DAT_0107fc90 + 4;
  return (uint)*pbVar1 * 0x100 + (uint)*pbVar2 * 0x10000 + (uint)*pbVar3 * 0x1000000;
}


// ==== FUN_0103804c @ 0103804c

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0103804c(FILE *param_1,byte *param_2)

{
  byte bVar1;
  byte *pbVar2;
  int iVar3;
  uint uVar4;
  uint uVar5;
  uint unaff_D7;
  undefined2 uVar6;
  char **ppcVar7;
  undefined4 local_1408;
  byte local_1404 [1024];
  byte abStack_1004 [7];
  byte local_ffd [13];
  byte local_ff0 [4076];
  
  local_1408 = 0;
  fill(param_2,0x126,0);
  iVar3 = param_1->_flags + -1;
  param_1->_flags = iVar3;
  if (iVar3 < 0) {
    FUN_01037c96(param_1);
    uVar4 = unaff_D7;
  }
  else {
    ppcVar7 = &param_1->_IO_read_ptr;
    bVar1 = **ppcVar7;
    *ppcVar7 = *ppcVar7 + 1;
    uVar4 = (uint)bVar1;
  }
  if ((uVar4 == 0xffffffff) || (uVar4 == 0)) {
    _ewsl_errn = 3;
    return;
  }
  fread(abStack_1004 + 1,1,uVar4 - 1,param_1);
  if ((int)unaff_D7 < (int)(uVar4 - 1)) {
    _ewsl_errn = 5;
    return;
  }
  DAT_0107fc90 = local_ff0;
  param_2[0x13] = local_ff0[0];
  DAT_0107fc90 = DAT_0107fc90 + 1;
  if ((param_2[0x13] != 2) && (fread(abStack_1004 + uVar4,1,2,param_1), (int)unaff_D7 < 2)) {
    _ewsl_errn = 4;
    return;
  }
  DAT_0107fc90 = abStack_1004 + 2;
  *param_2 = (byte)uVar4;
  cpybuf(abStack_1004 + 2,param_2 + 1,5);
  DAT_0107fc90 = local_ffd;
  FUN_01037ff4();
  *(uint *)(param_2 + 6) = unaff_D7;
  FUN_01037ff4();
  *(uint *)(param_2 + 10) = unaff_D7;
  FUN_01037ff4();
  *(uint *)(param_2 + 0xe) = unaff_D7;
  param_2[0x12] = *DAT_0107fc90;
  DAT_0107fc90 = DAT_0107fc90 + 1;
  bVar1 = *DAT_0107fc90;
  param_2[0x13] = bVar1;
  DAT_0107fc90 = DAT_0107fc90 + 1;
  if (bVar1 == 2) {
    uVar5 = 0;
  }
  else {
    FUN_01037f9c(abStack_1004 + 2,uVar4);
    if (abStack_1004[1] != unaff_D7) {
      _ewsl_errn = 5;
      return;
    }
    uVar5 = (uint)*DAT_0107fc90;
    DAT_0107fc90 = DAT_0107fc90 + 1;
    iVar3 = 0;
    if (uVar5 != 0) {
      do {
        param_2[iVar3 + 0x14] = *DAT_0107fc90;
        DAT_0107fc90 = DAT_0107fc90 + 1;
        iVar3 = iVar3 + 1;
      } while (iVar3 < (int)uVar5);
    }
    param_2[uVar5 + 0x14] = 0;
  }
  uVar6 = (undefined2)unaff_D7;
  if ((int)(uVar4 - uVar5) < 0x18) {
    if (uVar4 - uVar5 != 0x16) {
      if (uVar4 - uVar5 != 0x14) {
        _ewsl_errn = 4;
        return;
      }
      param_2[0x11a] = 0;
      param_2[0x116] = 0;
      param_2[0x117] = 0;
      param_2[0x118] = 0;
      param_2[0x119] = 0;
      goto LAB_0103822c;
    }
    FUN_01037fc4();
    *(undefined2 *)(param_2 + 0x114) = uVar6;
    param_2[0x11a] = 0;
  }
  else {
    FUN_01037fc4();
    *(undefined2 *)(param_2 + 0x114) = uVar6;
    param_2[0x11a] = *DAT_0107fc90;
    DAT_0107fc90 = DAT_0107fc90 + 1;
  }
  param_2[0x116] = 0;
  param_2[0x117] = 0;
  param_2[0x118] = 0;
  param_2[0x119] = 1;
LAB_0103822c:
  if ((param_2[0x11a] == 0x55) && (param_2[0x13] == 0)) {
    param_2[0x11b] = *DAT_0107fc90;
    DAT_0107fc90 = DAT_0107fc90 + 1;
    FUN_01037ff4();
    *(uint *)(param_2 + 0x11c) = unaff_D7;
    FUN_01037fc4();
    *(undefined2 *)(param_2 + 0x120) = uVar6;
    FUN_01037fc4();
    *(undefined2 *)(param_2 + 0x122) = uVar6;
    FUN_01037fc4();
    *(undefined2 *)(param_2 + 0x124) = uVar6;
    return;
  }
  if (param_2[0x13] != 0) {
    pbVar2 = DAT_0107fc90;
    if (param_2[0x13] != 2) {
      DAT_0107fc90 = abStack_1004 + *param_2;
      pbVar2 = DAT_0107fc90;
    }
    while( true ) {
      FUN_01037fc4();
      uVar4 = unaff_D7 & 0xffff;
      if (uVar4 == 0) break;
      if (param_2[0x13] != 2) {
        if ((int)(abStack_1004 + -(int)(DAT_0107fc90 + -0x1000)) < (int)uVar4) {
          _ewsl_errn = 4;
          return;
        }
        fread(DAT_0107fc90,1,uVar4,param_1);
        if ((int)unaff_D7 < (int)uVar4) {
          _ewsl_errn = 4;
          return;
        }
      }
      bVar1 = *DAT_0107fc90;
      DAT_0107fc90 = DAT_0107fc90 + 1;
      switch(bVar1) {
      default:
        DAT_0107fc90 = DAT_0107fc90 + (uVar4 - 3);
        break;
      case 1:
        iVar3 = 0;
        if (0 < (int)(uVar4 - 3)) {
          do {
            param_2[iVar3 + 0x14] = *DAT_0107fc90;
            DAT_0107fc90 = DAT_0107fc90 + 1;
            iVar3 = iVar3 + 1;
          } while (iVar3 < (int)(uVar4 - 3));
        }
        param_2[uVar4 + 0x11] = 0;
        break;
      case 2:
        iVar3 = 0;
        if (0 < (int)(uVar4 - 3)) {
          do {
            local_1404[iVar3] = *DAT_0107fc90;
            DAT_0107fc90 = DAT_0107fc90 + 1;
            iVar3 = iVar3 + 1;
          } while (iVar3 < (int)(uVar4 - 3));
        }
        local_1404[uVar4 - 3] = 0;
        FUN_01038ae2(local_1404,0x2f);
        local_1408 = uVar4 - 3;
        break;
      case 0x40:
        if (((param_2[0x11a] == 0x4d) || (param_2[0x11a] == 0x48)) || (param_2[0x11a] == 0)) {
          FUN_01037fc4();
          param_2[0x12] = (byte)unaff_D7;
        }
        break;
      case 0x50:
        if (param_2[0x11a] == 0x55) {
          FUN_01037fc4();
          *(undefined2 *)(param_2 + 0x120) = uVar6;
        }
        break;
      case 0x51:
        if (param_2[0x11a] == 0x55) {
          FUN_01037fc4();
          *(undefined2 *)(param_2 + 0x124) = uVar6;
          FUN_01037fc4();
          *(undefined2 *)(param_2 + 0x122) = uVar6;
        }
        break;
      case 0x54:
        if (param_2[0x11a] == 0x55) {
          FUN_01037ff4();
          *(uint *)(param_2 + 0x11c) = unaff_D7;
        }
      }
    }
    if ((param_2[0x13] != 2) && ((int)DAT_0107fc90 - (int)pbVar2 != 2)) {
      *(int *)(param_2 + 6) = (*(int *)(param_2 + 6) + 2) - ((int)DAT_0107fc90 - (int)pbVar2);
      *param_2 = ((char)DAT_0107fc90 - (char)pbVar2) + -2 + *param_2;
    }
  }
  if (local_1408 == 0) {
    return;
  }
  strcat((char *)local_1404,(char *)(param_2 + 0x14));
  strcpy((char *)(param_2 + 0x14),(char *)local_1404);
  return;
}


// ==== FUN_01038512 @ 01038512

void FUN_01038512(short param_1,undefined1 param_2,short param_3)

{
  ushort uVar1;
  char cVar2;
  ushort uVar3;
  short sVar4;
  short unaff_D7w;
  short sVar5;
  
  FUN_01037f4a(param_2);
  if (unaff_D7w == 0) {
    FUN_01037f4a(param_2);
    sVar5 = 0;
    if (0 < param_1) {
      do {
        (&DAT_0107fc94)[sVar5] = 0;
        sVar5 = sVar5 + 1;
      } while (sVar5 < param_1);
    }
    sVar5 = 0;
    do {
      (&DAT_0107fd14)[sVar5] = 0;
      sVar5 = sVar5 + 1;
    } while (sVar5 < 0x100);
  }
  else {
    sVar5 = 0;
    if (0 < unaff_D7w) {
      do {
        uVar3 = DAT_0107fc88 >> 0xd;
        if (uVar3 == 7) {
          for (uVar1 = 0x1000; (DAT_0107fc88 & uVar1) != 0; uVar1 = uVar1 >> 1) {
            uVar3 = uVar3 + 1;
          }
        }
        if ((short)uVar3 < 7) {
          cVar2 = '\x03';
        }
        else {
          cVar2 = (char)uVar3 + -3;
        }
        FUN_01037e68(cVar2);
        (&DAT_0107fc94)[sVar5] = (char)uVar3;
        sVar5 = sVar5 + 1;
        if (param_3 == sVar5) {
          FUN_01037f4a(2);
          sVar4 = unaff_D7w;
          while (sVar4 = sVar4 + -1, -1 < sVar4) {
            (&DAT_0107fc94)[sVar5] = 0;
            sVar5 = sVar5 + 1;
          }
        }
      } while (sVar5 < unaff_D7w);
    }
    for (; sVar5 < param_1; sVar5 = sVar5 + 1) {
      (&DAT_0107fc94)[sVar5] = 0;
    }
    FUN_01038940((int)param_1,&DAT_0107fc94,8,&DAT_0107fd14);
  }
  return;
}


// ==== FUN_01038626 @ 01038626

void FUN_01038626(void)

{
  ushort uVar1;
  short sVar2;
  short unaff_D7w;
  short sVar3;
  
  FUN_01037f4a(9);
  if (unaff_D7w == 0) {
    FUN_01037f4a(9);
    sVar3 = 0;
    do {
      (&DAT_0107ff14)[sVar3] = 0;
      sVar3 = sVar3 + 1;
    } while (sVar3 < 0x1fe);
    sVar3 = 0;
    do {
      (&DAT_01080112)[sVar3] = 0;
      sVar3 = sVar3 + 1;
    } while (sVar3 < 0x1000);
  }
  else {
    sVar3 = 0;
    if (0 < unaff_D7w) {
      do {
        sVar2 = (&DAT_0107fd14)[DAT_0107fc88 >> 8];
        if (0x12 < sVar2) {
          uVar1 = 0x80;
          do {
            if ((DAT_0107fc88 & uVar1) == 0) {
              sVar2 = *(short *)(&DAT_01082908 + sVar2 * 2);
            }
            else {
              sVar2 = *(short *)(&DAT_01082112 + sVar2 * 2);
            }
            uVar1 = uVar1 >> 1;
          } while (0x12 < sVar2);
        }
        FUN_01037e68((&DAT_0107fc94)[sVar2]);
        if (sVar2 < 3) {
          if (sVar2 == 0) {
            sVar2 = 1;
          }
          else if (sVar2 == 1) {
            FUN_01037f4a(4);
            sVar2 = unaff_D7w + 3;
          }
          else {
            FUN_01037f4a(9);
            sVar2 = unaff_D7w + 0x14;
          }
          while (sVar2 = sVar2 + -1, -1 < sVar2) {
            (&DAT_0107ff14)[sVar3] = 0;
            sVar3 = sVar3 + 1;
          }
        }
        else {
          (&DAT_0107ff14)[sVar3] = (char)sVar2 + -2;
          sVar3 = sVar3 + 1;
        }
      } while (sVar3 < unaff_D7w);
    }
    for (; sVar3 < 0x1fe; sVar3 = sVar3 + 1) {
      (&DAT_0107ff14)[sVar3] = 0;
    }
    FUN_01038940(0x1fe,&DAT_0107ff14,0xc,&DAT_01080112);
  }
  return;
}


// ==== FUN_01038786 @ 01038786

void FUN_01038786(void)

{
  uint uVar1;
  ushort uVar2;
  ushort uVar3;
  short unaff_D7w;
  
  if (DAT_010830fe == 0) {
    FUN_01037f4a(0x10);
    DAT_010830fe = unaff_D7w;
    FUN_01038512(0x13,5,3);
    FUN_01038626();
    FUN_01038512(0xe,4,0xffffffff);
  }
  DAT_010830fe = DAT_010830fe + -1;
  uVar3 = (&DAT_01080112)[DAT_0107fc88 >> 4];
  if (uVar3 < 0x1fe) {
    uVar1 = (uint)(byte)(&DAT_0107ff14)[uVar3];
  }
  else {
    FUN_01037e68(0xc);
    uVar2 = 0x8000;
    do {
      if ((DAT_0107fc88 & uVar2) == 0) {
        uVar3 = *(ushort *)(&DAT_01082908 + (uint)uVar3 * 2);
      }
      else {
        uVar3 = *(ushort *)(&DAT_01082112 + (uint)uVar3 * 2);
      }
      uVar2 = uVar2 >> 1;
    } while (0x1fd < uVar3);
    uVar1 = (byte)(&DAT_0107ff14)[uVar3] - 0xc;
  }
  FUN_01037e68(uVar1);
  return;
}


// ==== FUN_01038870 @ 01038870

int FUN_01038870(void)

{
  int iVar1;
  uint uVar2;
  ushort uVar3;
  ushort uVar4;
  
  uVar4 = (&DAT_0107fd14)[DAT_0107fc88 >> 8];
  if (uVar4 < 0xe) {
    uVar2 = (uint)(byte)(&DAT_0107fc94)[uVar4];
  }
  else {
    FUN_01037e68(8);
    uVar3 = 0x8000;
    do {
      if ((DAT_0107fc88 & uVar3) == 0) {
        uVar4 = *(ushort *)(&DAT_01082908 + (uint)uVar4 * 2);
      }
      else {
        uVar4 = *(ushort *)(&DAT_01082112 + (uint)uVar4 * 2);
      }
      uVar3 = uVar3 >> 1;
    } while (0xd < uVar4);
    uVar2 = (byte)(&DAT_0107fc94)[uVar4] - 8;
  }
  iVar1 = FUN_01037e68(uVar2);
  if (uVar4 != 0) {
    FUN_01037f4a(uVar4 - 1);
    iVar1 = 1 << (uVar4 - 1 & 0x3f);
  }
  return iVar1;
}


// ==== FUN_0103892c @ 0103892c

void FUN_0103892c(void)

{
  FUN_01037f78();
  DAT_010830fe = 0;
  return;
}


// ==== FUN_01038940 @ 01038940

void FUN_01038940(short param_1,int param_2,short param_3,int param_4)

{
  uint uVar1;
  int iVar2;
  uint uVar3;
  ushort uVar4;
  uint uVar5;
  int iVar6;
  int iVar7;
  uint uVar8;
  ushort *puVar9;
  uint uVar10;
  int iVar11;
  ushort uStack_6c;
  ushort auStack_6a [17];
  ushort auStack_48 [17];
  short asStack_26 [17];
  
  iVar11 = (int)param_1;
  uVar5 = 1;
  do {
    asStack_26[uVar5] = 0;
    auStack_48[uVar5] = (ushort)(1 << (0x10 - uVar5 & 0x3f));
    uVar5 = uVar5 + 1;
  } while (uVar5 < 0x11);
  uVar5 = 0;
  if (param_1 != 0) {
    do {
      asStack_26[*(byte *)(param_2 + uVar5)] = asStack_26[*(byte *)(param_2 + uVar5)] + 1;
      uVar5 = uVar5 + 1;
    } while (uVar5 < (uint)(int)param_1);
  }
  uVar4 = 0;
  uVar5 = 1;
  do {
    auStack_6a[uVar5] = uVar4;
    uVar4 = auStack_48[uVar5] * asStack_26[uVar5] + uVar4;
    uVar5 = uVar5 + 1;
  } while (uVar5 < 0x11);
  if (uVar4 != 0) {
    abort();
  }
  uVar10 = 0x10 - (int)param_3;
  uVar5 = 1;
  if (param_3 != 0) {
    do {
      auStack_6a[uVar5] = (ushort)((int)(uint)auStack_6a[uVar5] >> (uVar10 & 0x3f));
      auStack_48[uVar5] = (ushort)((int)(uint)auStack_48[uVar5] >> (uVar10 & 0x3f));
      uVar5 = uVar5 + 1;
    } while (uVar5 <= (uint)(int)param_3);
  }
  uVar5 = (int)(uint)auStack_6a[(int)param_3 + 1] >> (uVar10 & 0x3f);
  if (uVar5 != 0) {
    for (; uVar5 < (uint)(1 << ((int)param_3 & 0x3fU)); uVar5 = uVar5 + 1) {
      *(undefined2 *)(param_4 + uVar5 * 2) = 0;
    }
  }
  iVar7 = 0;
  if (0 < param_1) {
    uVar5 = (uint)param_3;
    do {
      uVar3 = (uint)*(byte *)(param_2 + iVar7);
      if (uVar3 != 0) {
        uVar8 = (uint)auStack_6a[uVar3];
        uVar1 = uVar8 + auStack_48[uVar3];
        if ((int)uVar5 < (int)uVar3) {
          puVar9 = (ushort *)(param_4 + (uint)(auStack_6a[uVar3] >> (uVar10 & 0x3f)) * 2);
          iVar6 = (uint)auStack_6a[uVar3] << (uVar5 & 0x3f);
          iVar2 = uVar3 - uVar5;
          while (iVar2 = iVar2 + -1, -1 < iVar2) {
            if (*puVar9 == 0) {
              *(undefined2 *)(&DAT_01082908 + iVar11 * 2) = 0;
              *(undefined2 *)(&DAT_01082112 + iVar11 * 2) = 0;
              *puVar9 = (ushort)iVar11;
              iVar11 = iVar11 + 1;
            }
            if ((short)iVar6 < 0) {
              puVar9 = (ushort *)(&DAT_01082112 + (uint)*puVar9 * 2);
            }
            else {
              puVar9 = (ushort *)(&DAT_01082908 + (uint)*puVar9 * 2);
            }
            iVar6 = iVar6 << 1;
          }
          *puVar9 = (ushort)iVar7;
        }
        else {
          for (; uVar8 < uVar1; uVar8 = uVar8 + 1) {
            *(ushort *)(param_4 + uVar8 * 2) = (ushort)iVar7;
          }
        }
        uStack_6c = (ushort)uVar1;
        auStack_6a[uVar3] = uStack_6c;
      }
      iVar7 = iVar7 + 1;
    } while (iVar7 < param_1);
  }
  return;
}


// ==== FUN_01038ae2 @ 01038ae2

void FUN_01038ae2(char *param_1,char param_2)

{
  char cVar1;
  
  for (; cVar1 = *param_1, cVar1 != '\0'; param_1 = param_1 + 1) {
    if (((cVar1 == '\\') || (cVar1 == '/')) || (cVar1 == -1)) {
      *param_1 = param_2;
    }
  }
  return;
}


// ==== FUN_01038b16 @ 01038b16

void FUN_01038b16(void)

{
  uint uVar1;
  ushort unaff_D7w;
  
  if (DAT_01083100 < 1) {
    DAT_01083104 = 0;
    DAT_01083100 = 0;
    for (; 0 < DAT_01083108; DAT_01083108 = DAT_01083108 + -1) {
      (&DAT_0108310c)[DAT_01083100] = (&DAT_0108310c)[DAT_0108510c & 0x1fff];
      DAT_01083100 = DAT_01083100 + 1;
      DAT_0108510c = DAT_0108510c + 1;
    }
    if (DAT_01083100 < 0x2000) {
      while (DAT_01085110 < DAT_0108511e) {
        FUN_01038786();
        if (unaff_D7w < 0x100) {
          (&DAT_0108310c)[DAT_01083100] = (char)unaff_D7w;
          DAT_01083100 = DAT_01083100 + 1;
          DAT_01085110 = DAT_01085110 + 1;
        }
        else {
          DAT_01083108 = unaff_D7w - 0xfd;
          FUN_01038870();
          DAT_0108510c = (DAT_01083100 - (uint)unaff_D7w) - 1 & 0x1fff;
          DAT_01085110 = DAT_01083108 + DAT_01085110;
          while (0 < DAT_01083108) {
            uVar1 = DAT_0108510c & 0x1fff;
            DAT_0108510c = DAT_0108510c + 1;
            DAT_01083108 = DAT_01083108 + -1;
            (&DAT_0108310c)[DAT_01083100] = (&DAT_0108310c)[uVar1];
            DAT_01083100 = DAT_01083100 + 1;
            if (0x1fff < DAT_01083100) {
              return;
            }
          }
        }
        if (0x1fff < DAT_01083100) {
          return;
        }
      }
    }
  }
  return;
}


// ==== ewsl_read @ 01038c66

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void ewsl_read(int param_1,int param_2)

{
  int iVar1;
  
  _ewsl_errn = 0;
  if (DAT_0107d7a8 == 0) {
    _ewsl_errn = 10;
  }
  else {
    iVar1 = 0;
    while( true ) {
      if ((param_2 < 1) || (FUN_01038b16(), DAT_01083100 < 1)) goto LAB_01038d24;
      if (param_2 <= DAT_01083100) break;
      cpybuf(&DAT_0108310c + DAT_01083104,param_1 + iVar1,DAT_01083100);
      param_2 = param_2 - DAT_01083100;
      iVar1 = DAT_01083100 + iVar1;
      DAT_01083104 = DAT_01083100 + DAT_01083104;
      DAT_01083100 = 0;
    }
    cpybuf(&DAT_0108310c + DAT_01083104,param_1 + iVar1,param_2);
    DAT_01083104 = param_2 + DAT_01083104;
    DAT_01083100 = DAT_01083100 - param_2;
    iVar1 = param_2 + iVar1;
LAB_01038d24:
    FUN_01037e06(param_1,iVar1);
  }
  return;
}


// ==== FUN_01038d3a @ 01038d3a

void FUN_01038d3a(void)

{
  int unaff_D7;
  undefined1 local_6 [2];
  
  ewsl_read(local_6,2);
  if (unaff_D7 != 2) {
    abort();
  }
  return;
}


// ==== FUN_01038d64 @ 01038d64

void FUN_01038d64(void)

{
  int unaff_D7;
  undefined1 local_8 [4];
  
  ewsl_read(local_8,4);
  if (unaff_D7 != 4) {
    abort();
  }
  return;
}


// ==== FUN_01038d8c @ 01038d8c

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_01038d8c(short *param_1)

{
  undefined4 unaff_D7;
  
  if (0x1b < DAT_0108511e) {
    FUN_01038d3a();
    *param_1 = (short)unaff_D7;
    if (*param_1 == -0x66d3) {
      FUN_01038d3a();
      param_1[1] = (short)unaff_D7;
      FUN_01038d64();
      *(undefined4 *)(param_1 + 2) = unaff_D7;
      FUN_01038d64();
      *(undefined4 *)(param_1 + 4) = unaff_D7;
      FUN_01038d64();
      *(undefined4 *)(param_1 + 6) = unaff_D7;
      FUN_01038d64();
      *(undefined4 *)(param_1 + 8) = unaff_D7;
      FUN_01038d64();
      *(undefined4 *)(param_1 + 10) = unaff_D7;
      FUN_01038d64();
      *(undefined4 *)(param_1 + 0xc) = unaff_D7;
      return;
    }
  }
  _ewsl_errn = 9;
  return;
}


// ==== ewsl_open @ 01038e02

/* WARNING: Removing unreachable block (ram,0x01038ed6) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void ewsl_open(int param_1,undefined4 param_2)

{
  size_t unaff_D7;
  
  _ewsl_errn = 0;
  if (param_1 == 0) {
    _ewsl_errn = 1;
  }
  else if (DAT_0107d7a8 == 0) {
    FUN_01037dcc();
    FUN_0103804c(param_1,&DAT_01085114);
    if (unaff_D7 == 0) {
      return;
    }
    if ((DAT_01085234 & 0xf000) == 0x8000) {
      strlen("-lh5-");
      bcmp(&DAT_01085115,"-lh5-",unaff_D7);
      if (unaff_D7 == 0) {
        DAT_0107fc8c = DAT_0108511a;
        DAT_0107fc84 = 0;
        DAT_0107d7a8 = param_1;
        FUN_0103892c();
        DAT_01083104 = 0;
        DAT_01083100 = 0;
        DAT_0108510c = 0;
        DAT_01083108 = 0;
        DAT_01085110 = 0;
        FUN_01038d8c(param_2);
        return;
      }
      _ewsl_errn = 7;
    }
    else {
      _ewsl_errn = 6;
    }
  }
  else {
    _ewsl_errn = 2;
  }
  return;
}


// ==== ewsl_clos @ 01038eea

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void ewsl_clos(void)

{
  _ewsl_errn = 0;
  if (DAT_0107d7a8 == 0) {
    _ewsl_errn = 10;
  }
  else {
    DAT_0107d7a8 = 0;
  }
  return;
}


// ==== ewsl_chec @ 01038f14

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void ewsl_chec(void)

{
  if (DAT_0107d7a8 == 0) {
    _ewsl_errn = 10;
  }
  else {
    if (DAT_0108522a == 0) {
      _ewsl_errn = 0;
      return;
    }
    if (DAT_01085228 == DAT_0107fc84) {
      _ewsl_errn = 0;
      return;
    }
    _ewsl_errn = 8;
  }
  return;
}


// ==== fs_creat @ 01038f54

void fs_creat(undefined4 param_1,undefined4 param_2,undefined2 param_3,undefined4 param_4,
             undefined4 param_5)

{
  ushort unaff_D7w;
  
  whichdos(param_1);
  if (unaff_D7w == 3) {
    rq8creat(param_1,param_2,param_3,param_4,param_5);
    return;
  }
  if (unaff_D7w < 4) {
    if (unaff_D7w == 1) {
      msdcreat(param_1,param_2,param_3,param_4,param_5);
      return;
    }
    if (unaff_D7w == 2) {
      hd_creat(param_1,param_2,param_3,param_4,param_5);
      return;
    }
  }
  else if ((unaff_D7w == 0x81) || (unaff_D7w == 0x83)) {
    sducreat(param_1,param_2,param_3,param_4,param_5);
    return;
  }
  mkdoserr(param_1,0xfffffff6);
  return;
}


// ==== fs_open @ 01039018

void fs_open(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6)

{
  ushort unaff_D7w;
  
  whichdos(param_1);
  if (unaff_D7w == 4) {
    netopen(param_1,param_2,param_3,param_4);
  }
  else {
    if (unaff_D7w < 5) {
      if (unaff_D7w == 2) {
        hd_open(param_1,param_2,param_3,param_4);
        return;
      }
      if (unaff_D7w < 3) {
        if (unaff_D7w == 1) {
          msd_open(param_1,param_2,param_3,param_4);
          return;
        }
      }
      else if (unaff_D7w == 3) {
        rq8_open(param_1,param_2,param_3,param_4);
        return;
      }
    }
    else {
      if (unaff_D7w == 6) {
        nm_fopen(param_6,param_2,param_3,param_4);
        return;
      }
      if (unaff_D7w < 7) {
        if (unaff_D7w == 5) {
          netnwopen(param_1,param_2,param_3,param_4,param_5);
          return;
        }
      }
      else if ((unaff_D7w == 0x81) || (unaff_D7w == 0x83)) {
        sdu_open(param_1,param_2,param_3,param_4);
        return;
      }
    }
    mkdoserr(param_1,0xfffffff6);
  }
  return;
}


// ==== fs_clos @ 01039118

void fs_clos(undefined4 param_1,short param_2,undefined4 param_3,undefined4 param_4)

{
  ushort unaff_D7w;
  
  whichdos(param_1);
  if (unaff_D7w == 4) {
    netclos((int)param_2,param_3);
  }
  else {
    if (unaff_D7w < 5) {
      if (unaff_D7w == 2) {
        hd_clos((int)param_2,param_3);
        return;
      }
      if (unaff_D7w < 3) {
        if (unaff_D7w == 1) {
          msd_clos((int)param_2,param_3);
          return;
        }
      }
      else if (unaff_D7w == 3) {
        rq8_clos((int)param_2,param_3);
        return;
      }
    }
    else {
      if (unaff_D7w == 6) {
        nm_fclose((int)param_2,param_3);
        return;
      }
      if (unaff_D7w < 7) {
        if (unaff_D7w == 5) {
          netnwclos((int)param_2,param_3,param_4);
          return;
        }
      }
      else if ((unaff_D7w == 0x81) || (unaff_D7w == 0x83)) {
        sdu_clos((int)param_2,param_3);
        return;
      }
    }
    mkdoserr(param_1,0xfffffff6);
  }
  return;
}


// ==== fs_read @ 01039202

void fs_read(undefined4 param_1,short param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6)

{
  int iVar1;
  uint uVar2;
  uint unaff_D7;
  
  whichdos(param_1);
  uVar2 = unaff_D7 & 0xffff;
  if (uVar2 == 4) {
    netread((int)param_2,param_3,param_4,param_5);
  }
  else {
    if (uVar2 < 5) {
      if (uVar2 == 2) {
        hd_read((int)param_2,param_3,param_4,param_5);
        return;
      }
      if (uVar2 < 3) {
        if (uVar2 == 1) {
          msd_read((int)param_2,param_3,param_4,param_5);
          return;
        }
      }
      else if (uVar2 == 3) {
        rq8_read((int)param_2,param_3,param_4,param_5);
        return;
      }
    }
    else {
      if (uVar2 == 6) {
        iVar1 = (short)nd_rc * 0x10;
        *(int *)(&nd_rbox + iVar1) = (int)param_2;
        *(undefined4 *)(&DAT_0107d7b0 + iVar1) = param_3;
        *(undefined4 *)(&DAT_0107d7b4 + iVar1) = param_4;
        *(undefined4 *)(&DAT_0107d7b8 + iVar1) = 0;
        nm_fread((int)param_2,param_3,param_4,param_5);
        *(uint *)(&DAT_0107d7b8 + iVar1) = unaff_D7;
        nd_rc = nd_rc + 1 & 0xf;
        return;
      }
      if (uVar2 < 7) {
        if (uVar2 == 5) {
          netnwread((int)param_2,param_3,param_4,param_5,param_6);
          return;
        }
      }
      else if ((uVar2 == 0x81) || (uVar2 == 0x83)) {
        sdu_read((int)param_2,param_3,param_4,param_5);
        return;
      }
    }
    mkdoserr(param_1,0xfffffff6);
  }
  return;
}


// ==== fs_write @ 0103934e

void fs_write(undefined4 param_1,short param_2,undefined4 param_3,undefined4 param_4,
             undefined4 param_5,undefined4 param_6)

{
  int iVar1;
  uint uVar2;
  uint unaff_D7;
  
  whichdos(param_1);
  uVar2 = unaff_D7 & 0xffff;
  if (uVar2 == 4) {
    netwrite((int)param_2,param_3,param_4,param_5);
  }
  else {
    if (uVar2 < 5) {
      if (uVar2 == 2) {
        hd_write((int)param_2,param_3,param_4,param_5);
        return;
      }
      if (uVar2 < 3) {
        if (uVar2 == 1) {
          msdwrite((int)param_2,param_3,param_4,param_5);
          return;
        }
      }
      else if (uVar2 == 3) {
        rq8write((int)param_2,param_3,param_4,param_5);
        return;
      }
    }
    else {
      if (uVar2 == 6) {
        iVar1 = (short)nd_wc * 0x10;
        *(int *)(&nd_wbox + iVar1) = (int)param_2;
        *(undefined4 *)(&DAT_0107d8b2 + iVar1) = param_3;
        *(undefined4 *)(&DAT_0107d8b6 + iVar1) = param_4;
        *(undefined4 *)(&DAT_0107d8ba + iVar1) = 0;
        nm_fwrite((int)param_2,param_3,param_4,param_5);
        *(uint *)(&DAT_0107d8ba + iVar1) = unaff_D7;
        nd_wc = nd_wc + 1 & 0xf;
        return;
      }
      if (uVar2 < 7) {
        if (uVar2 == 5) {
          netnwwrit((int)param_2,param_3,param_4,param_5,param_6);
          return;
        }
      }
      else if ((uVar2 == 0x81) || (uVar2 == 0x83)) {
        sduwrite((int)param_2,param_3,param_4,param_5);
        return;
      }
    }
    mkdoserr(param_1,0xfffffff6);
  }
  return;
}


// ==== fs_seek @ 0103949a

void fs_seek(undefined4 param_1,short param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6)

{
  ushort unaff_D7w;
  
  whichdos(param_1);
  if (unaff_D7w == 4) {
    netseek((int)param_2,param_3,param_4,param_5);
    return;
  }
  if (unaff_D7w < 5) {
    if (unaff_D7w == 1) {
      msd_seek((int)param_2,param_3,param_4,param_5);
      return;
    }
    if (unaff_D7w == 2) {
      hd_seek((int)param_2,param_3,param_4,param_5);
      return;
    }
  }
  else {
    if (unaff_D7w == 0x81) {
LAB_010394f4:
      sdu_seek((int)param_2,param_3,param_4,param_5);
      return;
    }
    if (unaff_D7w < 0x82) {
      if (unaff_D7w == 5) {
        netnwseek((int)param_2,param_3,param_4,param_5,param_6);
        return;
      }
    }
    else if (unaff_D7w == 0x83) goto LAB_010394f4;
  }
  mkdoserr(param_1,0xfffffff6);
  return;
}


// ==== fs_delet @ 0103956c

void fs_delet(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  ushort unaff_D7w;
  
  whichdos(param_1);
  if (unaff_D7w == 3) {
    rq8delet(param_1,param_2,param_3);
    return;
  }
  if (unaff_D7w < 4) {
    if (unaff_D7w == 1) {
      msddelet(param_1,param_2,param_3);
      return;
    }
    if (unaff_D7w == 2) {
      hd_delet(param_1,param_2,param_3);
      return;
    }
  }
  else {
    if (unaff_D7w == 0x81) {
LAB_010395de:
      sdu_delet(param_1,param_2,param_3);
      return;
    }
    if (unaff_D7w < 0x82) {
      if (unaff_D7w == 6) {
        nm_rm(param_4,param_2,param_3);
        return;
      }
    }
    else if (unaff_D7w == 0x83) goto LAB_010395de;
  }
  mkdoserr(param_1,0xfffffff6);
  return;
}


// ==== fs_erase @ 01039622

void fs_erase(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  ushort unaff_D7w;
  
  whichdos(param_1);
  if (unaff_D7w == 2) {
    hd_erase(param_1,param_2,param_3);
  }
  else {
    if (unaff_D7w < 3) {
      if (unaff_D7w == 1) {
        msderase(param_1,param_2,param_3);
        return;
      }
    }
    else if ((unaff_D7w == 0x81) || (unaff_D7w == 0x83)) {
      sdu_erase(param_1,param_2,param_3);
      return;
    }
    mkdoserr(param_1,0xfffffff6);
  }
  return;
}


// ==== fs_resum @ 010396a8

void fs_resum(undefined4 param_1,undefined2 param_2,undefined4 param_3)

{
  ushort unaff_D7w;
  
  whichdos(param_1);
  if (unaff_D7w == 3) {
    rq8resum(param_1,param_2,param_3);
    return;
  }
  if (unaff_D7w < 4) {
    if (unaff_D7w == 1) {
      msdresum(param_1,param_2,param_3);
      return;
    }
    if (unaff_D7w == 2) {
      hd_resum(param_1,param_2,param_3);
      return;
    }
  }
  else if ((unaff_D7w == 0x81) || (unaff_D7w == 0x83)) {
    sduresum(param_1,param_2,param_3);
    return;
  }
  mkdoserr(param_1,0xfffffff6);
  return;
}


// ==== fs_renam @ 01039754

void fs_renam(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
             undefined4 param_5)

{
  ushort unaff_D7w;
  
  whichdos(param_1);
  if (unaff_D7w == 3) {
    rq8renam(param_1,param_2,param_3,param_4);
    return;
  }
  if (unaff_D7w < 4) {
    if (unaff_D7w == 1) {
      msdrenam(param_1,param_2,param_3,param_4);
      return;
    }
    if (unaff_D7w == 2) {
      hd_renam(param_1,param_2,param_3,param_4);
      return;
    }
  }
  else {
    if (unaff_D7w == 0x81) {
LAB_010397ce:
      sdurenam(param_1,param_2,param_3,param_4);
      return;
    }
    if (unaff_D7w < 0x82) {
      if (unaff_D7w == 6) {
        nm_ren(param_5,param_2,param_3,param_4);
        return;
      }
    }
    else if (unaff_D7w == 0x83) goto LAB_010397ce;
  }
  mkdoserr(param_1,0xfffffff6);
  return;
}


// ==== fs_mount @ 01039818

void fs_mount(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  ushort unaff_D7w;
  
  whichdos(param_1);
  if (unaff_D7w == 4) {
    netmount(param_1,param_3,param_2);
  }
  else {
    if (unaff_D7w < 5) {
      if (unaff_D7w == 2) {
        hd_mount(param_1,param_2);
        return;
      }
      if (unaff_D7w < 3) {
        if (unaff_D7w == 1) {
          msdmount(param_1,param_2);
          return;
        }
      }
      else if (unaff_D7w == 3) {
        rq8mount(param_1,param_2);
        return;
      }
    }
    else {
      if (unaff_D7w == 6) {
        nm_sopen(0,param_3,param_2);
        return;
      }
      if (unaff_D7w < 7) {
        if (unaff_D7w == 5) {
          netnwmoun(param_1,param_3,param_2,param_4);
          return;
        }
      }
      else if ((unaff_D7w == 0x81) || (unaff_D7w == 0x83)) {
        sdumount(param_1,param_2);
        return;
      }
    }
    mkdoserr(param_1,0xfffffff6);
  }
  return;
}


// ==== fs_demnt @ 010398f8

void fs_demnt(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  ushort unaff_D7w;
  
  whichdos(param_1);
  if (unaff_D7w == 4) {
    netdemnt(param_1,param_3,param_2);
  }
  else {
    if (unaff_D7w < 5) {
      if (unaff_D7w == 2) {
        hd_demnt(param_1,param_2);
        return;
      }
      if (unaff_D7w < 3) {
        if (unaff_D7w == 1) {
          msddemnt(param_1,param_2);
          return;
        }
      }
      else if (unaff_D7w == 3) {
        rq8demnt(param_1,param_2);
        return;
      }
    }
    else {
      if (unaff_D7w == 6) {
        nm_sclose(param_3,param_2);
        return;
      }
      if (unaff_D7w < 7) {
        if (unaff_D7w == 5) {
          netnwdemn(param_1,param_3,param_2,param_4);
          return;
        }
      }
      else if ((unaff_D7w == 0x81) || (unaff_D7w == 0x83)) {
        sdudemnt(param_1,param_2);
        return;
      }
    }
    mkdoserr(param_1,0xfffffff6);
  }
  return;
}


// ==== fs_info @ 010399d4

void fs_info(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  ushort unaff_D7w;
  
  whichdos(param_1);
  if (unaff_D7w == 3) {
    rq8sghdr(param_1,param_2,param_3);
  }
  else {
    if (unaff_D7w < 4) {
      if (unaff_D7w == 1) {
        msd_info(param_1,param_2,param_3);
        return;
      }
    }
    else if ((unaff_D7w == 0x81) || (unaff_D7w == 0x83)) {
      sdusghdr(param_1,param_2,param_3);
      return;
    }
    mkdoserr(param_1,0xfffffff6);
  }
  return;
}


// ==== fs_srch @ 01039a5e

void fs_srch(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  ushort unaff_D7w;
  
  whichdos(param_1);
  if (unaff_D7w == 3) {
    rq8_srch(param_1,param_2,param_3);
    return;
  }
  if (unaff_D7w < 4) {
    if (unaff_D7w == 1) {
      msd_srch(param_1,param_2,param_3);
      return;
    }
    if (unaff_D7w == 2) {
      hd_srch(param_1,param_2,param_3);
      return;
    }
  }
  else {
    if (unaff_D7w == 0x81) {
LAB_01039ad0:
      sdu_srch(param_1,param_2,param_3);
      return;
    }
    if (unaff_D7w < 0x82) {
      if (unaff_D7w == 6) {
        nm_fnid(param_4,param_2,param_3);
        return;
      }
    }
    else if (unaff_D7w == 0x83) goto LAB_01039ad0;
  }
  mkdoserr(param_1,0xfffffff6);
  return;
}


// ==== fs_dire @ 01039b14

void fs_dire(undefined4 param_1,undefined2 param_2,undefined2 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6)

{
  ushort unaff_D7w;
  
  whichdos(param_1);
  if (unaff_D7w == 3) {
    rq8_dire(param_1,param_2,param_3,param_4,param_5);
    return;
  }
  if (unaff_D7w < 4) {
    if (unaff_D7w == 1) {
      msd_dire(param_1,param_2,param_3,param_4,param_5);
      return;
    }
    if (unaff_D7w == 2) {
      hd_dire(param_1,param_2,param_3,param_4,param_5);
      return;
    }
  }
  else {
    if (unaff_D7w == 0x81) {
LAB_01039bb0:
      sdu_dire(param_1,param_2,param_3,param_4,param_5);
      return;
    }
    if (unaff_D7w < 0x82) {
      if (unaff_D7w == 6) {
        nm_getdir(param_6,param_4,param_2,param_3,0,param_5);
        return;
      }
    }
    else if (unaff_D7w == 0x83) goto LAB_01039bb0;
  }
  mkdoserr(param_1,0xfffffff6);
  return;
}


// ==== fs_rxb @ 01039c18

void fs_rxb(undefined4 param_1,ushort param_2,undefined2 param_3,undefined2 param_4,
           undefined4 param_5,undefined4 param_6,undefined4 param_7)

{
  ushort unaff_D7w;
  
  whichdos(param_1);
  if (unaff_D7w == 3) {
    rq8_rxb(param_1,param_2,param_3,param_4,param_5,param_6);
    return;
  }
  if (unaff_D7w < 4) {
    if (unaff_D7w == 1) {
      msd_rxb(param_1,param_2,param_3,param_4,param_5,param_6);
      return;
    }
    if (unaff_D7w == 2) {
      hd_rxb(param_1,param_2,param_3,param_4,param_5,param_6);
      return;
    }
  }
  else {
    if (unaff_D7w == 0x81) {
LAB_01039cca:
      sdu_rxb(param_1,param_2,param_3,param_4,param_5,param_6);
      return;
    }
    if (unaff_D7w < 0x82) {
      if (unaff_D7w == 6) {
        nm_getcom(param_7,param_5,param_4,param_2 - 1,param_3,param_6);
        return;
      }
    }
    else if (unaff_D7w == 0x83) goto LAB_01039cca;
  }
  mkdoserr(param_1,0xfffffff6);
  return;
}


// ==== fs_wxb @ 01039d44

void fs_wxb(undefined4 param_1,undefined2 param_2,undefined2 param_3,undefined2 param_4,
           undefined4 param_5,undefined4 param_6)

{
  ushort unaff_D7w;
  
  whichdos(param_1);
  if (unaff_D7w == 3) {
    rq8_wxb(param_1,param_2,param_3,param_4,param_5,param_6);
    return;
  }
  if (unaff_D7w < 4) {
    if (unaff_D7w == 1) {
      msd_wxb(param_1,param_2,param_3,param_4,param_5,param_6);
      return;
    }
    if (unaff_D7w == 2) {
      hd_wxb(param_1,param_2,param_3,param_4,param_5,param_6);
      return;
    }
  }
  else if ((unaff_D7w == 0x81) || (unaff_D7w == 0x83)) {
    sdu_wxb(param_1,param_2,param_3,param_4,param_5,param_6);
    return;
  }
  mkdoserr(param_1,0xfffffff6);
  return;
}


// ==== fs_remai @ 01039e38

void fs_remai(undefined4 param_1,undefined4 param_2)

{
  ushort unaff_D7w;
  
  whichdos(param_1);
  if (unaff_D7w == 3) {
    rq8remai(param_1,param_2);
    return;
  }
  if (unaff_D7w < 4) {
    if (unaff_D7w == 1) {
      msdremai(param_1,param_2);
      return;
    }
    if (unaff_D7w == 2) {
      hd_remai(param_1,param_2);
      return;
    }
  }
  else if ((unaff_D7w == 0x81) || (unaff_D7w == 0x83)) {
    sduremai(param_1,param_2);
    return;
  }
  mkdoserr(param_1,0xfffffff6);
  return;
}


// ==== fs_rema2 @ 01039ec8

void fs_rema2(undefined4 param_1,undefined4 param_2)

{
  short unaff_D7w;
  
  whichdos(param_1);
  if (unaff_D7w == 2) {
    hd_rema2(param_1,param_2);
  }
  else {
    mkdoserr(param_1,0xfffffff6);
  }
  return;
}


// ==== fs_gtvol @ 01039f0c

void fs_gtvol(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  ushort unaff_D7w;
  
  whichdos(param_1);
  if (unaff_D7w == 3) {
    rq8gtvol(param_1,param_2,param_3);
    return;
  }
  if (unaff_D7w < 4) {
    if (unaff_D7w == 1) {
      msdgtvol(param_1,param_2,param_3);
      return;
    }
    if (unaff_D7w == 2) {
      hd_gtvol(param_1,param_2,param_3);
      return;
    }
  }
  else if ((unaff_D7w == 0x81) || (unaff_D7w == 0x83)) {
    sdugtvol(param_1,param_2,param_3);
    return;
  }
  mkdoserr(param_1,0xfffffff6);
  return;
}


// ==== fs_ptvol @ 01039fa8

void fs_ptvol(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  ushort unaff_D7w;
  
  whichdos(param_1);
  if (unaff_D7w == 3) {
    rq8ptvol(param_1,param_2,param_3);
    return;
  }
  if (unaff_D7w < 4) {
    if (unaff_D7w == 1) {
      msdptvol(param_1,param_2,param_3);
      return;
    }
    if (unaff_D7w == 2) {
      hd_ptvol(param_1,param_2,param_3);
      return;
    }
  }
  else if ((unaff_D7w == 0x81) || (unaff_D7w == 0x83)) {
    sduptvol(param_1,param_2,param_3);
    return;
  }
  mkdoserr(param_1,0xfffffff6);
  return;
}


// ==== fs_kind @ 0103a044

void fs_kind(undefined4 param_1,undefined4 param_2)

{
  ushort unaff_D7w;
  
  whichdos(param_1);
  if (unaff_D7w == 3) {
    rq8_kind(param_1,param_2);
    return;
  }
  if (unaff_D7w < 4) {
    if (unaff_D7w == 1) {
      msd_kind(param_1,param_2);
      return;
    }
    if (unaff_D7w == 2) {
      hd_kind(param_1,param_2);
      return;
    }
  }
  else if ((unaff_D7w == 0x81) || (unaff_D7w == 0x83)) {
    sdu_kind(param_1,param_2);
    return;
  }
  mkdoserr(param_1,0xfffffff6);
  return;
}


// ==== fs_init @ 0103a0d4

void fs_init(undefined4 param_1,undefined1 param_2,undefined1 param_3,undefined4 param_4,
            undefined4 param_5)

{
  ushort unaff_D7w;
  
  whichdos(param_1);
  if (unaff_D7w == 3) {
    rq8_init(param_1,param_2,param_3,param_4,param_5);
    return;
  }
  if (unaff_D7w < 4) {
    if (unaff_D7w == 1) {
      msd_init(param_1,param_2,param_3,param_4,param_5);
      return;
    }
    if (unaff_D7w == 2) {
      hd_init(param_1,param_2,param_3,param_4,param_5);
      return;
    }
  }
  else if ((unaff_D7w == 0x81) || (unaff_D7w == 0x83)) {
    sdu_init(param_1,param_2,param_3,param_4,param_5);
    return;
  }
  mkdoserr(param_1,0xfffffff6);
  return;
}


// ==== fs_pack @ 0103a1a8

void fs_pack(undefined4 param_1,undefined4 param_2)

{
  ushort unaff_D7w;
  
  whichdos(param_1);
  if (unaff_D7w == 3) {
    rq8_pack(param_1,param_2);
    return;
  }
  if (unaff_D7w < 4) {
    if (unaff_D7w == 1) {
      msd_pack(param_1,param_2);
      return;
    }
    if (unaff_D7w == 2) {
      hd_pack(param_1,param_2);
      return;
    }
  }
  else if ((unaff_D7w == 0x81) || (unaff_D7w == 0x83)) {
    sdu_pack(param_1,param_2);
    return;
  }
  mkdoserr(param_1,0xfffffff6);
  return;
}


// ==== fs_volcp @ 0103a238

/* WARNING: Removing unreachable block (ram,0x0103a266) */
/* WARNING: Removing unreachable block (ram,0x0103a26c) */
/* WARNING: Removing unreachable block (ram,0x0103a272) */
/* WARNING: Removing unreachable block (ram,0x0103a278) */
/* WARNING: Removing unreachable block (ram,0x0103a27e) */
/* WARNING: Removing unreachable block (ram,0x0103a284) */
/* WARNING: Removing unreachable block (ram,0x0103a28a) */
/* WARNING: Removing unreachable block (ram,0x0103a290) */
/* WARNING: Removing unreachable block (ram,0x0103a296) */

void fs_volcp(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  ushort unaff_D7w;
  
  whichdos(param_1);
  whichdos(param_2);
  if (unaff_D7w == 3) {
    rq8volcp(param_1,param_2,param_3);
    return;
  }
  if (unaff_D7w < 4) {
    if (unaff_D7w == 1) {
      msdvolcp(param_1,param_2,param_3);
      return;
    }
    if (unaff_D7w == 2) {
      hd_volcp(param_1,param_2,param_3);
      return;
    }
  }
  else if ((unaff_D7w == 0x81) || (unaff_D7w == 0x83)) {
    sduvolcp(param_1,param_2,param_3);
    return;
  }
  mkdoserr(param_1,0xfffffff6);
  return;
}


// ==== fs_dstat @ 0103a322

void fs_dstat(undefined4 param_1,undefined4 param_2)

{
  ushort unaff_D7w;
  
  whichdos(param_1);
  if (unaff_D7w == 3) {
    rq8dstat(param_1,param_2);
    return;
  }
  if (unaff_D7w < 4) {
    if (unaff_D7w == 1) {
      msddstat(param_1,param_2);
      return;
    }
    if (unaff_D7w == 2) {
      hd_dstat(param_1,param_2);
      return;
    }
  }
  else if ((unaff_D7w == 0x81) || (unaff_D7w == 0x83)) {
    sdudstat(param_1,param_2);
    return;
  }
  mkdoserr(param_1,0xfffffff6);
  return;
}


// ==== fs_fcpy @ 0103a3b2

/* WARNING: Removing unreachable block (ram,0x0103a412) */
/* WARNING: Removing unreachable block (ram,0x0103a418) */
/* WARNING: Removing unreachable block (ram,0x0103a41e) */
/* WARNING: Removing unreachable block (ram,0x0103a424) */
/* WARNING: Removing unreachable block (ram,0x0103a42a) */
/* WARNING: Removing unreachable block (ram,0x0103a430) */
/* WARNING: Removing unreachable block (ram,0x0103a436) */
/* WARNING: Removing unreachable block (ram,0x0103a43c) */
/* WARNING: Removing unreachable block (ram,0x0103a442) */
/* WARNING: Removing unreachable block (ram,0x0103a448) */
/* WARNING: Removing unreachable block (ram,0x0103a44e) */
/* WARNING: Removing unreachable block (ram,0x0103a454) */
/* WARNING: Removing unreachable block (ram,0x0103a45a) */
/* WARNING: Removing unreachable block (ram,0x0103a462) */
/* WARNING: Removing unreachable block (ram,0x0103a46a) */
/* WARNING: Removing unreachable block (ram,0x0103a486) */
/* WARNING: Removing unreachable block (ram,0x0103a48c) */
/* WARNING: Removing unreachable block (ram,0x0103a492) */
/* WARNING: Removing unreachable block (ram,0x0103a498) */
/* WARNING: Removing unreachable block (ram,0x0103a49e) */
/* WARNING: Removing unreachable block (ram,0x0103a4a4) */
/* WARNING: Removing unreachable block (ram,0x0103a4aa) */
/* WARNING: Removing unreachable block (ram,0x0103a4b0) */
/* WARNING: Removing unreachable block (ram,0x0103a4b6) */
/* WARNING: Removing unreachable block (ram,0x0103a4bc) */
/* WARNING: Removing unreachable block (ram,0x0103a4c2) */
/* WARNING: Removing unreachable block (ram,0x0103a4c8) */
/* WARNING: Removing unreachable block (ram,0x0103a4ce) */
/* WARNING: Removing unreachable block (ram,0x0103a4d4) */
/* WARNING: Removing unreachable block (ram,0x0103a4dc) */

void fs_fcpy(undefined4 param_1,char *param_2,undefined4 param_3,char *param_4,undefined4 param_5,
            undefined4 param_6)

{
  uint uVar1;
  uint unaff_D7;
  
  whichdos(param_1);
  whichdos(param_3);
  strlen(param_2);
  if ((unaff_D7 == 0) || (strlen(param_4), unaff_D7 == 0)) {
    mkdoserr(param_1,0xfffffff6);
    return;
  }
  uVar1 = unaff_D7 & 0xffff;
  if (uVar1 == 3) {
    rq8_fcpy(param_1,param_2,param_3,param_4,param_5);
    return;
  }
  if (uVar1 < 4) {
    if (uVar1 == 1) {
      msd_fcpy(param_1,param_2,param_3,param_4,param_5);
      return;
    }
    if (uVar1 == 2) {
      hd_fcpy(param_1,param_2,param_3,param_4,param_5);
      return;
    }
  }
  else {
    if (uVar1 == 0x81) {
LAB_0103a55a:
      sdu_fcpy(param_1,param_2,param_3,param_4,param_5);
      return;
    }
    if (uVar1 < 0x82) {
      if (uVar1 == 6) {
        nm_fcopy(param_6,param_2,param_4,param_5);
        return;
      }
    }
    else if (uVar1 == 0x83) goto LAB_0103a55a;
  }
  mkdoserr(param_1,0xfffffff6);
  return;
}


// ==== fs_ftpcpy @ 0103a5b6

void fs_ftpcpy(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  nm_fcopy(param_1,param_2,param_3,param_4);
  return;
}


// ==== fs_dcnfg @ 0103a5d4

void fs_dcnfg(undefined4 param_1,undefined4 param_2)

{
  ushort unaff_D7w;
  
  whichdos(param_1);
  if (unaff_D7w == 3) {
    rq8dcnfg(param_1,param_2);
  }
  else if (unaff_D7w < 4) {
    if (unaff_D7w == 1) {
      msddcnfg(param_1,param_2);
    }
    else {
      if (unaff_D7w != 2) {
        return;
      }
      hd_dcnfg(param_1,param_2);
    }
  }
  else {
    if ((unaff_D7w != 0x81) && (unaff_D7w != 0x83)) {
      return;
    }
    sdudcnfg(param_1,param_2);
  }
  dosstt();
  return;
}


// ==== fs_rdsct @ 0103a688

void fs_rdsct(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
             undefined4 param_5,undefined4 param_6,undefined4 param_7)

{
  ushort unaff_D7w;
  
  whichdos(param_1);
  if (unaff_D7w == 3) {
    rq8rdsct(param_1,param_2,param_3,param_4,param_5,param_6,param_7);
  }
  else if (unaff_D7w < 4) {
    if (unaff_D7w == 1) {
      msdrdsct(param_1,param_2,param_3,param_4,param_5,param_6,param_7);
    }
    else {
      if (unaff_D7w != 2) {
        return;
      }
      hd_rdsct(param_1,param_2,param_3,param_4,param_5,param_6,param_7);
    }
  }
  else {
    if ((unaff_D7w != 0x81) && (unaff_D7w != 0x83)) {
      return;
    }
    sdurdsct(param_1,param_2,param_3,param_4,param_5,param_6,param_7);
  }
  dosstt();
  return;
}


// ==== fs_wrsct @ 0103a760

void fs_wrsct(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
             undefined4 param_5,undefined4 param_6,undefined4 param_7)

{
  ushort unaff_D7w;
  
  whichdos(param_1);
  if (unaff_D7w == 3) {
    rq8wrsct(param_1,param_2,param_3,param_4,param_5,param_6,param_7);
  }
  else if (unaff_D7w < 4) {
    if (unaff_D7w == 1) {
      msdwrsct(param_1,param_2,param_3,param_4,param_5,param_6,param_7);
    }
    else {
      if (unaff_D7w != 2) {
        return;
      }
      hd_wrsct(param_1,param_2,param_3,param_4,param_5,param_6,param_7);
    }
  }
  else {
    if ((unaff_D7w != 0x81) && (unaff_D7w != 0x83)) {
      return;
    }
    sduwrsct(param_1,param_2,param_3,param_4,param_5,param_6,param_7);
  }
  dosstt();
  return;
}


// ==== fs_mkdir @ 0103a838

void fs_mkdir(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  short unaff_D7w;
  
  whichdos(param_1);
  if (unaff_D7w == 2) {
    hd_mkdir(param_1,param_2,param_3);
  }
  else if (unaff_D7w == 6) {
    nm_mkdir(param_4,param_2,param_3);
  }
  else {
    mkdoserr(param_1,0xfffffff6);
  }
  return;
}


// ==== fs_rmdir @ 0103a89e

void fs_rmdir(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  short unaff_D7w;
  
  whichdos(param_1);
  if (unaff_D7w == 2) {
    hd_rmdir(param_1,param_2,param_3);
  }
  else if (unaff_D7w == 6) {
    nm_rmdir(param_4,param_2,param_3);
  }
  else {
    mkdoserr(param_1,0xfffffff6);
  }
  return;
}


// ==== fs_chdir @ 0103a904

void fs_chdir(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  short unaff_D7w;
  
  whichdos(param_1);
  if (unaff_D7w == 2) {
    hd_chdir(param_1,param_2,param_3);
  }
  else if (unaff_D7w == 6) {
    nm_cd(param_4,param_2,param_3);
  }
  else {
    mkdoserr(param_1,0xfffffff6);
  }
  return;
}


// ==== fs_pwd @ 0103a96a

void fs_pwd(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  short unaff_D7w;
  
  whichdos(param_1);
  if (unaff_D7w == 2) {
    hd_pwd(param_1,param_2,param_3);
  }
  else if (unaff_D7w == 6) {
    nm_pwd(param_4,param_2,param_3);
  }
  else {
    mkdoserr(param_1,0xfffffff6);
  }
  return;
}


// ==== fs_dird @ 0103a9d0

void fs_dird(undefined4 param_1,undefined2 param_2,undefined2 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6)

{
  short unaff_D7w;
  
  whichdos(param_1);
  if (unaff_D7w == 2) {
    hd_dird(param_1,param_2,param_3,param_4,param_5);
  }
  else if (unaff_D7w == 6) {
    nm_getdir(param_6,param_4,param_2,param_3,0x80000000,param_5);
  }
  else {
    mkdoserr(param_1,0xfffffff6);
  }
  return;
}


// ==== chk_id @ 0103aa5c

void chk_id(uint param_1,uint param_2,ushort *param_3,ushort *param_4,undefined4 param_5)

{
  int unaff_D7;
  short sVar1;
  undefined1 auStack_38 [6];
  ushort local_32;
  undefined1 auStack_1e [6];
  ushort local_18;
  
  whichdos(param_1);
  sVar1 = (short)unaff_D7;
  whichdos(param_2);
  if (sVar1 == 0x83) {
    sdusghdr(param_1,auStack_1e,param_5);
  }
  else if (sVar1 == 3) {
    rq8sghdr(param_1,auStack_1e,param_5);
  }
  else {
    mkdoserr(param_1 & 0xff,0xfffffff6);
  }
  chk_doser();
  if (-1 < unaff_D7) {
    *param_3 = local_18;
  }
  chk_doser();
  if (-1 < unaff_D7) {
    if (sVar1 == 0x83) {
      sdusghdr(param_2,auStack_38,param_5);
    }
    else if (sVar1 == 3) {
      rq8sghdr(param_2,auStack_38,param_5);
    }
    else {
      mkdoserr(param_2 & 0xff,0xfffffff6);
    }
    chk_doser();
    if ((-1 < unaff_D7) && (*param_4 = local_32, *param_4 < *param_3)) {
      mkdoserr(param_2 & 0xff,0xffffffe9);
    }
  }
  return;
}


// ==== diffread @ 0103ab76

void diffread(uint param_1,undefined4 param_2,uint param_3,undefined4 param_4,undefined4 param_5,
             uint param_6)

{
  uint uVar1;
  uint uVar2;
  undefined *puVar3;
  int iVar4;
  undefined4 uVar5;
  undefined *unaff_D7;
  int iVar6;
  undefined1 local_10 [4];
  short sVar7;
  
  whichdos(param_1);
  uVar2 = (uint)unaff_D7 & 0xffff;
  whichdos(param_3);
  if (uVar2 == 3) {
    iVar6 = 1;
  }
  else {
    uVar1 = param_1;
    if (uVar2 < 4) {
      if (uVar2 == 1) {
        iVar6 = 2;
      }
      else {
        if (uVar2 != 2) goto LAB_0103ac4e;
        iVar6 = 3;
      }
    }
    else {
      if (uVar2 != 0x81) {
        if (uVar2 < 0x82) {
          if (uVar2 != 6) goto LAB_0103ac4e;
          iVar6 = 4;
          param_1 = param_6;
          goto LAB_0103abf8;
        }
        if (uVar2 != 0x83) goto LAB_0103ac4e;
      }
      iVar6 = 0;
    }
  }
LAB_0103abf8:
  uVar2 = (uint)unaff_D7 & 0xffff;
  if (uVar2 == 3) {
    iVar4 = 1;
  }
  else {
    uVar1 = param_3;
    if (uVar2 < 4) {
      if (uVar2 == 1) {
        iVar4 = 2;
      }
      else {
        if (uVar2 != 2) goto LAB_0103ac4e;
        iVar4 = 3;
      }
    }
    else {
      if (uVar2 != 0x81) {
        if (uVar2 < 0x82) {
          if (uVar2 == 6) {
            iVar4 = 4;
            param_3 = param_6;
            goto LAB_0103ac5a;
          }
LAB_0103ac4e:
          mkdoserr(uVar1 & 0xff,0xfffffff6);
          return;
        }
        if (uVar2 != 0x83) goto LAB_0103ac4e;
      }
      iVar4 = 0;
    }
  }
LAB_0103ac5a:
  (*(code *)(&open_func)[iVar6])(param_1,param_2,0,param_5);
  chk_doser();
  if (-1 < (int)unaff_D7) {
    sVar7 = (short)unaff_D7;
    if (iVar4 == 4) {
      (*pcRam0107d9c0)(param_3,param_4,1,param_5);
    }
    else {
      (*(code *)(&rema_func)[iVar4])(param_3,param_5);
      (*(code *)(&crea_func)[iVar4])(param_3,param_4);
    }
    chk_doser(unaff_D7);
    if ((int)unaff_D7 < 0) {
      (*(code *)(&clos_func)[iVar6])((int)sVar7,param_5);
    }
    else {
      malloc(0x1400);
      if (unaff_D7 == (undefined *)0x0) {
        uVar5 = 0x200;
        puVar3 = &fsvolbuf;
      }
      else {
        uVar5 = 0x1400;
        puVar3 = unaff_D7;
      }
      do {
        (*(code *)(&read_func)[iVar6])((int)sVar7,uVar5,puVar3,param_5);
        chk_doser();
        if ((int)unaff_D7 < 0) {
          if (((short)((uint)unaff_D7 >> 0x10) == -0xc) || (unaff_D7 == (undefined *)0xffffff13)) {
            mkdoserr(param_3 & 0xff,0);
          }
          break;
        }
        (*(code *)(&writ_func)[iVar4])((int)sVar7,unaff_D7,puVar3,param_5);
        chk_doser();
      } while (-1 < (int)unaff_D7);
      (*(code *)(&clos_func)[iVar6])((int)sVar7,param_5);
      (*(code *)(&clos_func)[iVar4])((int)sVar7,param_5);
      if (-1 < (int)unaff_D7) {
        cpybuf(local_10 + 8,local_10 + 4,4);
      }
      freefs(puVar3);
    }
  }
  return;
}


// ==== dif_fcpy @ 0103ae2c

/* WARNING: Removing unreachable block (ram,0x0103ae88) */
/* WARNING: Removing unreachable block (ram,0x0103aeb0) */
/* WARNING: Removing unreachable block (ram,0x0103aee4) */

void dif_fcpy(uint param_1,undefined4 param_2,uint param_3,undefined4 param_4,undefined4 param_5,
             undefined4 param_6)

{
  if (param_3 == param_1) {
    mkdoserr(param_3 & 0xff,0xfffffff6);
  }
  else {
    whichdos(param_1);
    whichdos(param_3);
    diffread(param_1,param_2,param_3,param_4,param_5,param_6);
    chk_doser();
  }
  return;
}


// ==== chk_doser @ 0103af18

undefined4 chk_doser(int param_1)

{
  undefined4 uVar1;
  
  if (param_1 < 0) {
    uVar1 = 0xffffffff;
  }
  else {
    uVar1 = 0;
  }
  return uVar1;
}


// ==== dif_comwr @ 0103af32

void dif_comwr(short param_1,ushort param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5
              ,undefined4 param_6,undefined4 param_7)

{
  ushort uVar1;
  int unaff_D7;
  short sVar2;
  
  whichdos(param_3);
  sVar2 = (short)unaff_D7;
  whichdos(param_5);
  if (sVar2 == 0x83) {
    sdu_srch(param_3,param_4,param_7);
  }
  else {
    rq8_srch(param_3,param_4,param_7);
  }
  chk_doser();
  if (-1 < unaff_D7) {
    fill(&fsvolbuf,param_2,0);
    uVar1 = param_2;
    if (0x28 < param_2) {
      uVar1 = 0x28;
    }
    fill(&fsvolbuf,uVar1,0x20);
    if (param_1 != 0) {
      if (sVar2 == 0x83) {
        sdu_rxb(param_3);
      }
      else {
        rq8_rxb(param_3);
      }
    }
  }
  chk_doser();
  if (-1 < unaff_D7) {
    if (sVar2 == 0x83) {
      sdu_srch(param_5,param_6,param_7);
    }
    else {
      rq8_srch(param_5,param_6,param_7);
    }
  }
  chk_doser();
  if ((-1 < unaff_D7) && (param_2 != 0)) {
    if (sVar2 == 0x83) {
      sdu_wxb(param_5);
    }
    else {
      rq8_wxb(param_5);
    }
  }
  return;
}


// ==== difvolcp @ 0103b0b4

/* WARNING: Removing unreachable block (ram,0x0103b266) */
/* WARNING: Removing unreachable block (ram,0x0103b26c) */
/* WARNING: Removing unreachable block (ram,0x0103b272) */
/* WARNING: Removing unreachable block (ram,0x0103b29a) */
/* WARNING: Removing unreachable block (ram,0x0103b2b4) */
/* WARNING: Removing unreachable block (ram,0x0103b2d4) */
/* WARNING: Removing unreachable block (ram,0x0103b2d8) */
/* WARNING: Removing unreachable block (ram,0x0103b31a) */
/* WARNING: Removing unreachable block (ram,0x0103b30c) */
/* WARNING: Removing unreachable block (ram,0x0103b31c) */
/* WARNING: Removing unreachable block (ram,0x0103b326) */
/* WARNING: Removing unreachable block (ram,0x0103b330) */
/* WARNING: Removing unreachable block (ram,0x0103b33e) */
/* WARNING: Removing unreachable block (ram,0x0103b340) */
/* WARNING: Removing unreachable block (ram,0x0103b386) */
/* WARNING: Removing unreachable block (ram,0x0103b38e) */
/* WARNING: Removing unreachable block (ram,0x0103b3d6) */
/* WARNING: Removing unreachable block (ram,0x0103b3dc) */
/* WARNING: Removing unreachable block (ram,0x0103b3e6) */
/* WARNING: Removing unreachable block (ram,0x0103b3ea) */
/* WARNING: Removing unreachable block (ram,0x0103b3f4) */
/* WARNING: Removing unreachable block (ram,0x0103b3fc) */
/* WARNING: Removing unreachable block (ram,0x0103b406) */
/* WARNING: Removing unreachable block (ram,0x0103b40e) */
/* WARNING: Removing unreachable block (ram,0x0103b418) */
/* WARNING: Removing unreachable block (ram,0x0103b448) */
/* WARNING: Removing unreachable block (ram,0x0103b43e) */
/* WARNING: Removing unreachable block (ram,0x0103b27e) */
/* WARNING: Recovered jumptable eliminated as dead code */

void difvolcp(uint param_1,uint param_2,undefined4 param_3)

{
  ushort unaff_D7w;
  
  whichdos(param_1);
  whichdos(param_2);
  if (unaff_D7w == 3) {
    rq8dcnfg(param_1,param_3);
  }
  else if (unaff_D7w < 4) {
    if (unaff_D7w != 1) goto LAB_0103b17c;
    msddcnfg(param_1,param_3);
  }
  else {
    if ((unaff_D7w != 0x81) && (unaff_D7w != 0x83)) {
LAB_0103b17c:
      param_1 = param_1 & 0xff;
      goto LAB_0103b452;
    }
    sdudcnfg(param_1,param_3);
  }
  if (unaff_D7w == 3) {
    rq8dcnfg(param_2,param_3);
LAB_0103b28c:
    param_1 = param_1 & 0xff;
  }
  else {
    if (unaff_D7w < 4) {
      if (unaff_D7w == 1) {
        msddcnfg(param_2,param_3);
        goto LAB_0103b28c;
      }
    }
    else if ((unaff_D7w == 0x81) || (unaff_D7w == 0x83)) {
      sdudcnfg(param_2,param_3);
      goto LAB_0103b28c;
    }
    param_1 = param_2 & 0xff;
  }
LAB_0103b452:
  mkdoserr(param_1,0xfffffff6);
  return;
}


// ==== freefs @ 0103b464

void freefs(undefined *param_1)

{
  if (param_1 != &fsvolbuf) {
    mfree(param_1);
  }
  return;
}


// ==== moffsub @ 0103b480

void moffsub(undefined4 param_1,undefined4 param_2)

{
  ushort unaff_D7w;
  
  whichdos(param_1);
  if (unaff_D7w == 3) {
    rq8demnt(param_1,param_2);
  }
  else if (unaff_D7w < 4) {
    if (unaff_D7w == 1) {
      msddemnt(param_1,param_2);
    }
  }
  else if ((unaff_D7w == 0x81) || (unaff_D7w == 0x83)) {
    sdudemnt(param_1,param_2);
  }
  return;
}


// ==== dif_echk @ 0103b4ec

uint dif_echk(undefined1 param_1,uint param_2,char param_3)

{
  byte bVar1;
  uint uVar2;
  int iVar3;
  
  iVar3 = 0;
  if (param_2 == 0) {
    uVar2 = mkdoserr(param_1,0);
  }
  else {
    uVar2 = param_2 & 0x7c000000;
    if (uVar2 == 0) {
      if (param_3 == '\0') {
        if ((param_2 & 0x8989) != 0) {
          uVar2 = param_2 & 0x8900;
          do {
            if ((param_2 & 1 << (uVar2 & 0x1f)) != 0) {
              switch(uVar2 & 0xff) {
              case 0:
              case 8:
                iVar3 = -8;
                break;
              case 3:
              case 0xb:
                iVar3 = -5;
                break;
              case 7:
              case 0xf:
                iVar3 = -4;
                break;
              case 0x12:
                iVar3 = -0x2d;
              }
              if (iVar3 != 0) {
                return uVar2;
              }
            }
            bVar1 = (char)uVar2 + 1;
            uVar2 = CONCAT31((int3)(uVar2 >> 8),bVar1);
            if (0x1f < bVar1) {
              return uVar2;
            }
          } while( true );
        }
      }
      else if ((param_2 & 0x8989) != 0) {
        uVar2 = param_2 & 0x8900;
        do {
          if ((param_2 & 1 << (uVar2 & 0x1f)) != 0) {
            switch(uVar2 & 0xff) {
            case 0:
            case 8:
              iVar3 = -8;
              break;
            case 3:
            case 0xb:
              iVar3 = -5;
              break;
            case 6:
            case 0xe:
              iVar3 = -0x2e;
              break;
            case 7:
            case 0xf:
              iVar3 = -4;
              break;
            case 0x12:
              iVar3 = -0x2d;
            }
            if (iVar3 != 0) {
              return uVar2;
            }
          }
          bVar1 = (char)uVar2 + 1;
          uVar2 = CONCAT31((int3)(uVar2 >> 8),bVar1);
          if (0xf < bVar1) {
            return uVar2;
          }
        } while( true );
      }
      uVar2 = param_2 & 0x8989;
    }
  }
  return uVar2;
}


// ==== eepdvrq @ 0103b614

void eepdvrq(undefined1 param_1,undefined2 param_2,undefined2 param_3,undefined4 param_4,
            uint *param_5)

{
  uint unaff_D7;
  undefined1 local_16 [4];
  undefined4 local_12;
  undefined2 local_e;
  undefined2 local_c;
  undefined1 local_a;
  undefined1 *local_8;
  
  local_a = param_1;
  local_12 = param_4;
  local_e = param_2;
  local_c = param_3;
  local_8 = local_16;
  dsemsg(0xe,0x82,&local_12);
  while( true ) {
    wait((void *)0x0);
    if ((unaff_D7 & 0x200) != 0) break;
    *param_5 = unaff_D7 | *param_5;
  }
  return;
}


// ==== rd_eep @ 0103b682

void rd_eep(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  eepdvrq(0x52,param_1,param_2,param_3,param_4);
  return;
}


// ==== wr_eep @ 0103b6a4

void wr_eep(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  eepdvrq(0x57,param_1,param_2,param_3,param_4);
  return;
}


// ==== fcpytohd @ 0103b6c8

void fcpytohd(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
             undefined4 param_5,undefined4 param_6)

{
  uint uVar1;
  uint unaff_D5;
  uint unaff_D7;
  short sVar2;
  
  whichdos(param_1);
  sVar2 = (short)unaff_D7;
  uVar1 = unaff_D7 & 0xffff;
  if (uVar1 == 6) {
    nm_fopen(param_6,param_2,0,param_5);
  }
  else if (uVar1 < 7) {
    if (uVar1 != 1) goto LAB_0103b746;
    msd_open(param_1,param_2,0,param_5);
  }
  else {
    if (uVar1 != 0x81) goto LAB_0103b746;
    sdu_open(param_1,param_2,0,param_5);
  }
  unaff_D5 = unaff_D7;
LAB_0103b746:
  dosstt(unaff_D5);
  if (-1 < (int)unaff_D7) {
    whichdos(param_3);
    if (sVar2 == 6) {
      nm_fopen(param_6,param_4,1,param_5);
    }
    else {
      hd_creat(param_3,param_4,0x800,1,param_5);
      dosstt();
      if (unaff_D7 == 0xffffffff) {
        hd_open(param_3,param_4,1,param_5);
      }
    }
    dosstt();
    if ((-1 < (int)unaff_D7) && (-1 < (int)unaff_D7)) {
      if (sVar2 == 6) {
        hdfcpsub(6,6,unaff_D7 & 0xffff,unaff_D7 & 0xffff,param_5);
        dosstt();
        nm_fclose(6,param_5);
      }
      else {
        if (sVar2 != 6) {
          hd_cpxb(param_1,param_2,param_3,param_4,unaff_D7 & 0xffff,param_5);
        }
        hdfcpsub((int)sVar2,(int)sVar2,unaff_D7 & 0xffff,unaff_D7 & 0xffff,param_5);
        dosstt();
        hd_clos((int)sVar2,param_5);
      }
      dosstt();
    }
    uVar1 = unaff_D7 & 0xffff;
    if (uVar1 == 6) {
      nm_fclose(param_6,param_5);
    }
    else if (uVar1 < 7) {
      if (uVar1 == 1) {
        msd_clos((int)sVar2,param_5);
      }
    }
    else if (uVar1 == 0x81) {
      sdu_clos((int)sVar2,param_5);
    }
  }
  return;
}


// ==== hdfcpsub @ 0103b8fe

void hdfcpsub(short param_1,short param_2,ushort param_3,short param_4,undefined4 param_5)

{
  undefined1 *puVar1;
  undefined1 *unaff_D4;
  undefined1 *unaff_D7;
  uint __size;
  int iVar2;
  undefined1 auStack_204 [512];
  
  __size = 0x1000;
  do {
    malloc(__size);
    if (unaff_D7 != (undefined1 *)0x0) break;
    __size = (int)__size >> 1;
  } while (0x200 < __size);
  puVar1 = unaff_D7;
  if (unaff_D7 == (undefined1 *)0x0) {
    puVar1 = auStack_204;
  }
  iVar2 = (int)param_1;
  do {
    if (param_3 == 6) {
      nm_fread(iVar2,__size,puVar1,param_5);
LAB_0103b9a8:
      unaff_D4 = unaff_D7;
    }
    else if (param_3 < 7) {
      if (param_3 == 1) {
        msd_read(iVar2,__size,puVar1,param_5);
        goto LAB_0103b9a8;
      }
    }
    else if (param_3 == 0x81) {
      sdu_read(iVar2,__size,puVar1,param_5);
      goto LAB_0103b9a8;
    }
    dosstt(unaff_D4);
    if ((int)unaff_D7 < 1) break;
    if (param_4 == 6) {
      nm_fwrite((int)param_2);
    }
    else {
      hd_write((int)param_2);
    }
    dosstt();
    unaff_D4 = unaff_D7;
  } while (-1 < (int)unaff_D7);
  if (unaff_D7 != (undefined1 *)0x0) {
    mfree(puVar1);
  }
  return;
}


// ==== hd_cpxb @ 0103ba1c

void hd_cpxb(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            short param_5,undefined4 param_6)

{
  uint unaff_D3;
  uint unaff_D7;
  undefined1 auStack_2c [40];
  
  if (param_5 == 1) {
    msd_srch(param_1,param_2,param_6);
LAB_0103ba6a:
    unaff_D3 = unaff_D7;
  }
  else if (param_5 == 0x81) {
    sdu_srch(param_1,param_2,param_6);
    goto LAB_0103ba6a;
  }
  dosstt(unaff_D3);
  if ((int)unaff_D7 < 1) {
    return;
  }
  if (param_5 == 1) {
    msd_rxb(param_1,unaff_D7 & 0xffff,unaff_D7 & 0xffff,0x28,auStack_2c,param_6);
  }
  else {
    if (param_5 != 0x81) goto LAB_0103bacc;
    sdu_rxb(param_1,unaff_D7 & 0xffff,unaff_D7 & 0xffff,0x28,auStack_2c,param_6);
  }
  unaff_D3 = unaff_D7;
LAB_0103bacc:
  dosstt(unaff_D3);
  if (-1 < (int)unaff_D7) {
    hd_srch(param_3,param_4,param_6);
    dosstt();
    if (-1 < (int)unaff_D7) {
      hd_wxb(param_3,unaff_D7 & 0xffff,unaff_D7 & 0xffff,0x28,auStack_2c,param_6);
    }
  }
  return;
}


// ==== fdreq @ 0103bb20

void fdreq(int param_1,undefined4 *param_2)

{
  undefined4 unaff_D7;
  undefined1 local_8 [4];
  
  *(undefined1 **)(param_1 + 0x16) = local_8;
  mailnwai(0x26,3,param_1,0x40);
  *param_2 = unaff_D7;
  return;
}


// ==== setfdreq @ 0103bb52

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void setfdreq(undefined1 param_1,undefined1 param_2,undefined1 param_3,undefined1 param_4,
             undefined1 param_5,undefined1 param_6,undefined4 param_7,undefined4 param_8)

{
  fdreqwk = param_1;
  DAT_0107da51 = param_2;
  DAT_0107da52 = param_3;
  DAT_0107da53 = param_4;
  DAT_0107da54 = param_5;
  DAT_0107da55 = param_6;
  _DAT_0107da56 = param_7;
  _DAT_0107da5a = param_8;
  return;
}


// ==== frmfdcnfg @ 0103bbaa

void frmfdcnfg(void)

{
  return;
}


// ==== rqfdrstr @ 0103bc26

void rqfdrstr(undefined1 param_1,undefined4 param_2)

{
  fdreqwk = 0x10;
  DAT_0107da51 = param_1;
  fdreq(&fdreqwk,param_2);
  return;
}


// ==== rqfdrclb @ 0103bc4e

void rqfdrclb(undefined1 param_1,undefined4 param_2)

{
  fdreqwk = 0x11;
  DAT_0107da51 = param_1;
  fdreq(&fdreqwk,param_2);
  return;
}


// ==== rqfdtrsk @ 0103bc76

void rqfdtrsk(undefined1 param_1,undefined1 param_2,undefined4 param_3)

{
  fdreqwk = 0x12;
  DAT_0107da51 = param_1;
  DAT_0107da52 = param_2;
  fdreq(&fdreqwk,param_3);
  return;
}


// ==== rqfdscrd @ 0103bca8

void rqfdscrd(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
             undefined4 param_5,undefined4 param_6)

{
  setfdreq(0x20,param_1,param_2,param_3,param_4,param_5,param_6,0);
  fdreq();
  return;
}


// ==== rqfdscwr @ 0103bce4

void rqfdscwr(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
             undefined4 param_5,undefined4 param_6)

{
  setfdreq(0x21,param_1,param_2,param_3,param_4,param_5,param_6,0);
  fdreq();
  return;
}


// ==== rqfdsdel @ 0103bd20

void rqfdsdel(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
             undefined4 param_5,undefined4 param_6)

{
  setfdreq(0x22,param_1,param_2,param_3,param_4,param_5,param_6,0);
  fdreq();
  return;
}


// ==== rqfdadrr @ 0103bd5c

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void rqfdadrr(undefined1 param_1,undefined4 param_2,undefined4 param_3)

{
  fdreqwk = 0x30;
  DAT_0107da51 = param_1;
  _DAT_0107da56 = param_2;
  fdreq(&fdreqwk,param_3);
  return;
}


// ==== rqfdtrwr @ 0103bd8c

void rqfdtrwr(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
             undefined4 param_5)

{
  setfdreq(0x32,param_1,param_2,param_3,0,0,param_4,param_5);
  fdreq();
  return;
}


// ==== rqfdrst @ 0103bdc6

void rqfdrst(undefined4 param_1)

{
  fdreqwk = 0;
  fdreq(&fdreqwk,param_1);
  return;
}


// ==== rqfdstfg @ 0103bde2

void rqfdstfg(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,int param_5,
             int param_6,undefined4 param_7,undefined4 param_8)

{
  undefined4 unaff_D7;
  
  if (param_1 < 4) {
    param_4 = 0x200;
    if (param_5 < 1) {
      param_5 = 9;
    }
    if (param_6 < 1) {
      param_6 = 0x50;
    }
  }
  fdreqwk = 1;
  DAT_0107da51 = (undefined1)param_1;
  frmfdcnfg(param_2,param_3,param_4,param_5,param_6,param_7);
  DAT_0107da5e = unaff_D7;
  fdreq(&fdreqwk,param_8);
  return;
}


// ==== rqfdgvfg @ 0103be52

void rqfdgvfg(undefined1 param_1,undefined4 param_2,undefined4 param_3)

{
  undefined1 auStackY_9c [128];
  
  fdreqwk = 2;
  DAT_0107da51 = param_1;
  fdreq(&fdreqwk,param_3);
  cpybuf(auStackY_9c + 0x94,param_2,4);
  return;
}


// ==== isdskchg @ 0103be90

void isdskchg(undefined1 param_1)

{
  undefined1 auStack_8 [4];
  
  fdreqwk = 3;
  DAT_0107da51 = param_1;
  fdreq(&fdreqwk,auStack_8);
  return;
}


// ==== cldskchg @ 0103beb8

void cldskchg(undefined1 param_1)

{
  undefined1 auStack_8 [4];
  
  fdreqwk = 4;
  DAT_0107da51 = param_1;
  fdreq(&fdreqwk,auStack_8);
  return;
}


// ==== mayiwr_d @ 0103bee0

void mayiwr_d(undefined1 param_1)

{
  undefined1 auStack_8 [4];
  
  fdreqwk = 5;
  DAT_0107da51 = param_1;
  fdreq(&fdreqwk,auStack_8);
  return;
}


// ==== rqfdsilv @ 0103bf14

void rqfdsilv(undefined1 param_1,undefined4 param_2,undefined4 param_3)

{
  fdreqwk = 6;
  DAT_0107da51 = param_1;
  cpybuf(param_2,&DAT_0107da62,3);
  fdreq(&fdreqwk,param_3);
  return;
}


// ==== rqfdslct @ 0103bf54

void rqfdslct(undefined1 param_1,undefined4 param_2)

{
  fdreqwk = 7;
  DAT_0107da51 = param_1;
  fdreq(&fdreqwk,param_2);
  return;
}


// ==== rqfdrels @ 0103bf7c

void rqfdrels(undefined1 param_1,undefined4 param_2)

{
  fdreqwk = 8;
  DAT_0107da51 = param_1;
  fdreq(&fdreqwk,param_2);
  return;
}


// ==== rqfdgtbr @ 0103bfa4

void rqfdgtbr(undefined1 param_1,undefined4 param_2)

{
  fdreqwk = 9;
  DAT_0107da51 = param_1;
  fdreq(&fdreqwk,param_2);
  return;
}


// ==== rqfdstbr @ 0103bfd2

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void rqfdstbr(undefined1 param_1,byte param_2,undefined4 param_3)

{
  fdreqwk = 10;
  DAT_0107da51 = param_1;
  _DAT_0107da5a = (uint)param_2;
  fdreq(&fdreqwk,param_3);
  return;
}


// ==== hdsreq @ 0103c008

void hdsreq(int param_1,undefined4 *param_2)

{
  undefined4 unaff_D7;
  undefined4 local_8;
  
  *(char *)(param_1 + 3) = *(char *)(param_1 + 3) + -6;
  *(char *)(param_1 + 4) = *(char *)(param_1 + 4) + -6;
  *(undefined4 **)(param_1 + 0x28) = &local_8;
  mailnwai(0x2c,9,param_1,0x10);
  *param_2 = unaff_D7;
  dosstt(local_8);
  return;
}


// ==== hd_creat @ 0103c064

void hd_creat(undefined1 param_1,undefined4 param_2,undefined4 param_3,undefined2 param_4,
             undefined4 param_5)

{
  undefined1 auStack_30 [2];
  undefined1 local_2e;
  undefined1 local_2d;
  undefined1 auStack_2b [23];
  undefined2 local_14;
  undefined4 local_10;
  
  local_2e = 0x13;
  local_2d = param_1;
  putfnam(param_2,auStack_2b);
  local_10 = param_3;
  local_14 = param_4;
  hdsreq(auStack_30,param_5);
  return;
}


// ==== hd_open @ 0103c0a8

void hd_open(undefined1 param_1,undefined4 param_2,undefined2 param_3,undefined4 param_4)

{
  undefined1 auStack_30 [2];
  undefined1 local_2e;
  undefined1 local_2d;
  undefined1 auStack_2b [23];
  undefined2 local_14;
  
  local_2e = 0x11;
  local_2d = param_1;
  putfnam(param_2,auStack_2b);
  local_14 = param_3;
  hdsreq(auStack_30,param_4);
  return;
}


// ==== hd_clos @ 0103c0e6

void hd_clos(undefined2 param_1,undefined4 param_2)

{
  undefined2 local_30;
  undefined1 local_2e;
  
  local_2e = 0x12;
  local_30 = param_1;
  hdsreq(&local_30,param_2);
  return;
}


// ==== hd_read @ 0103c10a

void hd_read(undefined2 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  undefined2 local_30;
  undefined1 local_2e;
  undefined4 local_10;
  undefined4 local_c;
  
  local_2e = 0x21;
  local_30 = param_1;
  local_10 = param_2;
  local_c = param_3;
  hdsreq(&local_30,param_4);
  return;
}


// ==== hd_write @ 0103c13a

void hd_write(undefined2 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  undefined2 local_30;
  undefined1 local_2e;
  undefined4 local_10;
  undefined4 local_c;
  
  local_2e = 0x22;
  local_30 = param_1;
  local_10 = param_2;
  local_c = param_3;
  hdsreq(&local_30,param_4);
  return;
}


// ==== hd_seek @ 0103c16a

void hd_seek(undefined2 param_1,undefined2 param_2,undefined4 param_3,undefined4 param_4)

{
  undefined2 local_30;
  undefined1 local_2e;
  undefined2 local_14;
  undefined4 local_10;
  
  local_2e = 0x23;
  local_30 = param_1;
  local_10 = param_3;
  local_14 = param_2;
  hdsreq(&local_30,param_4);
  return;
}


// ==== hd_erase @ 0103c19a

void hd_erase(undefined1 param_1,undefined4 param_2,undefined4 param_3)

{
  undefined1 auStack_30 [2];
  undefined1 local_2e;
  undefined1 local_2d;
  undefined1 auStack_2b [39];
  
  local_2e = 0x15;
  local_2d = param_1;
  putfnam(param_2,auStack_2b);
  hdsreq(auStack_30,param_3);
  return;
}


// ==== hd_renam @ 0103c1d2

void hd_renam(undefined1 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  undefined1 auStack_30 [2];
  undefined1 local_2e;
  undefined1 local_2d;
  undefined1 auStack_2b [11];
  undefined1 auStack_20 [28];
  
  local_2e = 0x14;
  local_2d = param_1;
  putfnam(param_2,auStack_2b);
  putfnam(param_3,auStack_20);
  hdsreq(auStack_30,param_4);
  return;
}


// ==== hd_mount @ 0103c21a

void hd_mount(undefined1 param_1,undefined4 param_2)

{
  undefined1 auStack_30 [2];
  undefined1 local_2e;
  undefined1 local_2d;
  
  local_2e = 1;
  local_2d = param_1;
  hdsreq(auStack_30,param_2);
  return;
}


// ==== hd_demnt @ 0103c23c

void hd_demnt(undefined1 param_1,undefined4 param_2)

{
  undefined1 auStack_30 [2];
  undefined1 local_2e;
  undefined1 local_2d;
  
  local_2e = 4;
  local_2d = param_1;
  hdsreq(auStack_30,param_2);
  return;
}


// ==== hd_info @ 0103c25e

void hd_info(undefined1 param_1,undefined4 param_2,undefined4 param_3)

{
  undefined1 auStack_30 [2];
  undefined1 local_2e;
  undefined1 local_2d;
  undefined4 local_c;
  
  local_2e = 2;
  local_2d = param_1;
  local_c = param_2;
  hdsreq(auStack_30,param_3);
  return;
}


// ==== hd_srch @ 0103c286

void hd_srch(undefined1 param_1,undefined4 param_2,undefined4 param_3)

{
  undefined1 auStack_30 [2];
  undefined1 local_2e;
  undefined1 local_2d;
  undefined1 auStack_2b [39];
  
  local_2e = 8;
  local_2d = param_1;
  putfnam(param_2,auStack_2b);
  hdsreq(auStack_30,param_3);
  return;
}


// ==== hd_remai @ 0103c2be

void hd_remai(undefined1 param_1,undefined4 param_2)

{
  undefined1 auStack_30 [2];
  undefined1 local_2e;
  undefined1 local_2d;
  
  local_2e = 0x3a;
  local_2d = param_1;
  hdsreq(auStack_30,param_2);
  return;
}


// ==== hd_rema2 @ 0103c2e0

void hd_rema2(undefined1 param_1,undefined4 param_2)

{
  undefined1 auStack_30 [2];
  undefined1 local_2e;
  undefined1 local_2d;
  
  local_2e = 0x3b;
  local_2d = param_1;
  hdsreq(auStack_30,param_2);
  return;
}


// ==== hd_gtvol @ 0103c302

void hd_gtvol(undefined1 param_1,undefined4 param_2,undefined4 param_3)

{
  undefined1 auStack_30 [2];
  undefined1 local_2e;
  undefined1 local_2d;
  undefined4 local_c;
  
  local_2e = 0xb;
  local_2d = param_1;
  local_c = param_2;
  hdsreq(auStack_30,param_3);
  return;
}


// ==== hd_ptvol @ 0103c32a

void hd_ptvol(undefined1 param_1,undefined4 param_2,undefined4 param_3)

{
  undefined1 auStack_30 [2];
  undefined1 local_2e;
  undefined1 local_2d;
  undefined4 local_c;
  
  local_2e = 0xc;
  local_2d = param_1;
  local_c = param_2;
  hdsreq(auStack_30,param_3);
  return;
}


// ==== hd_kind @ 0103c352

void hd_kind(undefined1 param_1,undefined4 param_2)

{
  undefined1 auStack_30 [2];
  undefined1 local_2e;
  undefined1 local_2d;
  
  local_2e = 3;
  local_2d = param_1;
  hdsreq(auStack_30,param_2);
  return;
}


// ==== hd_init @ 0103c374

void hd_init(undefined1 param_1,byte param_2,byte param_3,undefined4 param_4,undefined4 param_5)

{
  undefined1 auStack_30 [2];
  undefined1 local_2e;
  undefined1 local_2d;
  ushort local_14;
  ushort local_12;
  undefined4 local_c;
  
  local_2e = 0x30;
  local_2d = param_1;
  local_14 = (ushort)param_2;
  local_12 = (ushort)param_3;
  local_c = param_4;
  hdsreq(auStack_30,param_5);
  return;
}


// ==== hd_volcp @ 0103c3b4

void hd_volcp(undefined1 param_1,undefined1 param_2,undefined4 param_3)

{
  undefined1 auStack_30 [2];
  undefined1 local_2e;
  undefined1 local_2d;
  undefined1 local_2c;
  
  local_2e = 0x31;
  local_2d = param_1;
  local_2c = param_2;
  hdsreq(auStack_30,param_3);
  return;
}


// ==== hd_dstat @ 0103c3dc

void hd_dstat(undefined1 param_1,undefined4 param_2)

{
  undefined1 auStack_30 [2];
  undefined1 local_2e;
  undefined1 local_2d;
  
  local_2e = 0xf;
  local_2d = param_1;
  hdsreq(auStack_30,param_2);
  return;
}


// ==== hd_fcpy @ 0103c3fe

void hd_fcpy(undefined1 param_1,undefined4 param_2,undefined1 param_3,undefined4 param_4,
            undefined4 param_5)

{
  undefined1 auStack_30 [2];
  undefined1 local_2e;
  undefined1 local_2d;
  undefined1 local_2c;
  undefined1 auStack_2b [11];
  undefined1 auStack_20 [28];
  
  local_2e = 0x32;
  local_2d = param_1;
  putfnam(param_2,auStack_2b);
  local_2c = param_3;
  putfnam(param_4,auStack_20);
  hdsreq(auStack_30,param_5);
  return;
}


// ==== hd_delet @ 0103c44c

void hd_delet(undefined1 param_1,undefined4 param_2,undefined4 param_3)

{
  undefined1 auStack_30 [2];
  undefined1 local_2e;
  undefined1 local_2d;
  undefined1 auStack_2b [39];
  
  local_2e = 0xd;
  local_2d = param_1;
  putfnam(param_2,auStack_2b);
  hdsreq(auStack_30,param_3);
  return;
}


// ==== hd_resum @ 0103c484

void hd_resum(undefined1 param_1,undefined2 param_2,undefined4 param_3)

{
  undefined1 auStack_30 [2];
  undefined1 local_2e;
  undefined1 local_2d;
  undefined2 local_14;
  
  local_2e = 0xe;
  local_2d = param_1;
  local_14 = param_2;
  hdsreq(auStack_30,param_3);
  return;
}


// ==== hd_pack @ 0103c4ae

void hd_pack(undefined1 param_1,undefined4 param_2)

{
  undefined1 auStack_30 [2];
  undefined1 local_2e;
  undefined1 local_2d;
  
  local_2e = 0x18;
  local_2d = param_1;
  hdsreq(auStack_30,param_2);
  return;
}


// ==== hd_rxb @ 0103c4d0

void hd_rxb(undefined1 param_1,undefined2 param_2,undefined2 param_3,undefined4 param_4,
           undefined4 param_5,undefined4 param_6)

{
  undefined1 auStack_30 [2];
  undefined1 local_2e;
  undefined1 local_2d;
  undefined2 local_14;
  undefined2 local_12;
  undefined4 local_10;
  undefined4 local_c;
  
  local_2e = 0x19;
  local_2d = param_1;
  local_14 = param_2;
  local_12 = param_3;
  local_10 = param_4;
  local_c = param_5;
  hdsreq(auStack_30,param_6);
  return;
}


// ==== hd_wxb @ 0103c50e

void hd_wxb(undefined1 param_1,undefined2 param_2,undefined2 param_3,undefined4 param_4,
           undefined4 param_5,undefined4 param_6)

{
  undefined1 auStack_30 [2];
  undefined1 local_2e;
  undefined1 local_2d;
  undefined2 local_14;
  undefined2 local_12;
  undefined4 local_10;
  undefined4 local_c;
  
  local_2e = 0x1a;
  local_2d = param_1;
  local_14 = param_2;
  local_12 = param_3;
  local_10 = param_4;
  local_c = param_5;
  hdsreq(auStack_30,param_6);
  return;
}


// ==== hd_mkdir @ 0103c54c

void hd_mkdir(undefined1 param_1,undefined4 param_2,undefined4 param_3)

{
  undefined1 auStack_30 [2];
  undefined1 local_2e;
  undefined1 local_2d;
  undefined4 local_c;
  
  local_2e = 0x43;
  local_2d = param_1;
  local_c = param_2;
  hdsreq(auStack_30,param_3);
  return;
}


// ==== hd_rmdir @ 0103c574

void hd_rmdir(undefined1 param_1,undefined4 param_2,undefined4 param_3)

{
  undefined1 auStack_30 [2];
  undefined1 local_2e;
  undefined1 local_2d;
  undefined4 local_c;
  
  local_2e = 0x44;
  local_2d = param_1;
  local_c = param_2;
  hdsreq(auStack_30,param_3);
  return;
}


// ==== hd_chdir @ 0103c59c

void hd_chdir(undefined1 param_1,undefined4 param_2,undefined4 param_3)

{
  undefined1 auStack_30 [2];
  undefined1 local_2e;
  undefined1 local_2d;
  undefined4 local_c;
  
  local_2e = 0x45;
  local_2d = param_1;
  local_c = param_2;
  hdsreq(auStack_30,param_3);
  return;
}


// ==== hd_pwd @ 0103c5c4

void hd_pwd(undefined1 param_1,undefined4 param_2,undefined4 param_3)

{
  undefined1 auStack_30 [2];
  undefined1 local_2e;
  undefined1 local_2d;
  undefined4 local_c;
  
  local_2e = 0x46;
  local_2d = param_1;
  local_c = param_2;
  hdsreq(auStack_30,param_3);
  return;
}


// ==== hd_dird @ 0103c5ec

void hd_dird(undefined1 param_1,undefined2 param_2,undefined2 param_3,undefined4 param_4,
            undefined4 param_5)

{
  undefined1 auStack_30 [2];
  undefined1 local_2e;
  undefined1 local_2d;
  undefined2 local_14;
  undefined2 local_12;
  undefined4 local_c;
  
  local_2e = 0x47;
  local_2d = param_1;
  local_14 = param_2;
  local_12 = param_3;
  local_c = param_4;
  hdsreq(auStack_30,param_5);
  return;
}


// ==== hd_dire @ 0103c624

void hd_dire(undefined1 param_1,undefined2 param_2,undefined2 param_3,undefined4 param_4,
            undefined4 param_5)

{
  undefined1 auStack_30 [2];
  undefined1 local_2e;
  undefined1 local_2d;
  undefined2 local_14;
  undefined2 local_12;
  undefined4 local_c;
  
  local_2e = 9;
  local_2d = param_1;
  local_14 = param_2;
  local_12 = param_3;
  local_c = param_4;
  hdsreq(auStack_30,param_5);
  return;
}


// ==== hd_dcnfg @ 0103c65c

void hd_dcnfg(undefined1 param_1,undefined4 param_2)

{
  undefined1 auStack_30 [2];
  undefined1 local_2e;
  undefined1 local_2d;
  
  local_2e = 0x40;
  local_2d = param_1;
  hdsreq(auStack_30,param_2);
  return;
}


// ==== hd_rdsct @ 0103c67e

void hd_rdsct(undefined1 param_1,undefined2 param_2,undefined2 param_3,undefined2 param_4,
             undefined4 param_5,undefined4 param_6,undefined4 param_7)

{
  undefined2 local_30;
  undefined1 local_2e;
  undefined1 local_2d;
  undefined2 local_14;
  undefined2 local_12;
  undefined4 local_10;
  undefined4 local_c;
  
  local_2e = 0x41;
  local_2d = param_1;
  local_30 = param_2;
  local_14 = param_3;
  local_12 = param_4;
  local_10 = param_5;
  local_c = param_6;
  hdsreq(&local_30,param_7);
  return;
}


// ==== hd_wrsct @ 0103c6be

void hd_wrsct(undefined1 param_1,undefined2 param_2,undefined2 param_3,undefined2 param_4,
             undefined4 param_5,undefined4 param_6,undefined4 param_7)

{
  undefined2 local_30;
  undefined1 local_2e;
  undefined1 local_2d;
  undefined2 local_14;
  undefined2 local_12;
  undefined4 local_10;
  undefined4 local_c;
  
  local_2e = 0x42;
  local_2d = param_1;
  local_30 = param_2;
  local_14 = param_3;
  local_12 = param_4;
  local_10 = param_5;
  local_c = param_6;
  hdsreq(&local_30,param_7);
  return;
}


// ==== mailnwai @ 0103c700

uint mailnwai(undefined2 param_1,undefined4 param_2,undefined4 param_3,uint param_4)

{
  uint uVar1;
  uint unaff_D7;
  
  uVar1 = 0;
  semsg(param_1,param_2,param_3);
  do {
    wait((void *)0x0);
    uVar1 = unaff_D7 | uVar1;
  } while ((param_4 & uVar1) == 0);
  return param_4 & uVar1;
}


// ==== alloc_wai @ 0103c74c

void alloc_wai(uint *param_1)

{
  uint unaff_D7;
  
  *param_1 = *param_1 & 0xfffffdff;
  do {
    wait((void *)0x0);
    unaff_D7 = *param_1 | unaff_D7;
    *param_1 = unaff_D7;
  } while ((*param_1 & 0x200) == 0);
  *param_1 = *param_1 & 0xfffffdff;
  return;
}


// ==== alloc_com @ 0103c788

void alloc_com(undefined4 param_1,undefined4 param_2,undefined4 *param_3)

{
  undefined4 local_18;
  undefined1 local_14 [4];
  undefined4 local_10;
  undefined4 local_c;
  undefined1 *local_8;
  
  local_10 = param_1;
  local_c = param_2;
  local_8 = local_14;
  semsg(0xc,10,&local_10);
  local_18 = 0;
  if (param_3 == (undefined4 *)0x0) {
    param_3 = &local_18;
  }
  alloc_wai(param_3);
  return;
}


// ==== malloc @ 0103c7de

void * malloc(size_t __size)

{
  void *pvVar1;
  
  pvVar1 = (void *)alloc_com(0,__size,0);
  return pvVar1;
}


// ==== mfree @ 0103c7f4

void mfree(undefined4 param_1)

{
  alloc_com(1,param_1,0);
  return;
}


// ==== sralloc @ 0103c80c

void sralloc(undefined4 param_1)

{
  alloc_com(2,param_1,0);
  return;
}


// ==== srfree @ 0103c824

void srfree(undefined4 param_1)

{
  alloc_com(3,param_1,0);
  return;
}


// ==== shdalloc @ 0103c83c

void shdalloc(undefined4 param_1)

{
  alloc_com(4,param_1,0);
  return;
}


// ==== shdfree @ 0103c854

void shdfree(undefined4 param_1)

{
  alloc_com(5,param_1,0);
  return;
}


// ==== pbmalloc @ 0103c86c

void pbmalloc(undefined4 param_1,undefined4 param_2)

{
  alloc_com(0,param_1,param_2);
  return;
}


// ==== pbmfree @ 0103c884

void pbmfree(undefined4 param_1,undefined4 param_2)

{
  alloc_com(1,param_1,param_2);
  return;
}


// ==== pbsralloc @ 0103c89e

void pbsralloc(undefined4 param_1,undefined4 param_2)

{
  alloc_com(2,param_1,param_2);
  return;
}


// ==== pbsrfree @ 0103c8b8

void pbsrfree(undefined4 param_1,undefined4 param_2)

{
  alloc_com(3,param_1,param_2);
  return;
}


// ==== pbshdallo @ 0103c8d2

void pbshdallo(undefined4 param_1,undefined4 param_2)

{
  alloc_com(4,param_1,param_2);
  return;
}


// ==== pbshdfree @ 0103c8ec

void pbshdfree(undefined4 param_1,undefined4 param_2)

{
  alloc_com(5,param_1,param_2);
  return;
}


// ==== inidelid @ 0103c908

void inidelid(void)

{
  return;
}


// ==== nxtdelid @ 0103c912

void nxtdelid(void)

{
  return;
}


// ==== mkhidnam @ 0103c932

char mkhidnam(char param_1,char *param_2,char *param_3)

{
  char cVar1;
  int iVar2;
  char *pcVar3;
  char *pcVar4;
  char *pcVar5;
  
  if (param_2[7] == '@') {
    cVar1 = '@';
  }
  else {
    iVar2 = 0;
    pcVar4 = param_3;
    do {
      pcVar3 = pcVar4;
      pcVar5 = param_2;
      if (*param_2 == '.') break;
      pcVar5 = param_2 + 1;
      pcVar3 = pcVar4 + 1;
      *pcVar4 = *param_2;
      iVar2 = iVar2 + 1;
      pcVar4 = pcVar3;
      param_2 = pcVar5;
    } while (iVar2 < 6);
    for (; iVar2 < 6; iVar2 = iVar2 + 1) {
      *pcVar3 = '_';
      pcVar3 = pcVar3 + 1;
    }
    param_3[6] = param_1;
    param_3[7] = '@';
    for (; ((iVar2 < 8 && (*pcVar5 != '\0')) && (*pcVar5 != '.')); pcVar5 = pcVar5 + 1) {
      iVar2 = iVar2 + 1;
    }
    if (*pcVar5 == '.') {
      pcVar5 = pcVar5 + 1;
    }
    iVar2 = 0;
    pcVar4 = param_3 + 8;
    do {
      cVar1 = *pcVar5;
      pcVar3 = pcVar4;
      if (cVar1 == '\0') break;
      cVar1 = *pcVar5;
      pcVar3 = pcVar4 + 1;
      *pcVar4 = cVar1;
      iVar2 = iVar2 + 1;
      pcVar4 = pcVar3;
      pcVar5 = pcVar5 + 1;
    } while (iVar2 < 3);
    for (; iVar2 < 3; iVar2 = iVar2 + 1) {
      *pcVar3 = ' ';
      pcVar3 = pcVar3 + 1;
    }
  }
  return cVar1;
}


// ==== nxhidnam @ 0103c9e2

void nxhidnam(char param_1,int param_2)

{
  char unaff_D7b;
  
  inidelid();
  if ((unaff_D7b <= param_1) && (param_1 <= maxdelID)) {
    *(char *)(param_2 + 6) = param_1;
  }
  return;
}


// ==== isusedid @ 0103ca1c

void isusedid(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  undefined1 auStack_12 [14];
  
  slvfnam(param_3,auStack_12);
  msdrenam(param_1,param_2,auStack_12,param_4);
  dosstt();
  return;
}


// ==== msddelet @ 0103ca70

void msddelet(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  int unaff_D7;
  char cVar1;
  undefined1 auStack_10 [12];
  
  inidelid();
  cVar1 = (char)unaff_D7;
  mkhidnam((int)cVar1,param_2,auStack_10);
  if (-1 < unaff_D7) {
    do {
      isusedid(param_1,param_2,auStack_10,param_3);
      if (unaff_D7 < 1) goto LAB_0103caea;
      nxtdelid((int)cVar1);
      if (cVar1 < '\x01') break;
      nxhidnam((int)cVar1,auStack_10);
    } while (0 < unaff_D7);
    unaff_D7 = -0x21;
  }
LAB_0103caea:
  mkdoserr(param_1,unaff_D7);
  return;
}


// ==== msdresum @ 0103cafe

void msdresum(undefined4 param_1,undefined2 param_2,undefined4 param_3)

{
  uint uVar1;
  uint unaff_D7;
  uint in_stack_ffffffae;
  undefined1 auStack_4e [32];
  undefined1 auStack_2e [14];
  undefined1 auStack_20 [14];
  undefined1 auStack_12 [14];
  
  whichdos(param_1);
  msd_dire(param_1,param_2,param_2,auStack_4e,param_3);
  dosstt();
  if (-1 < (int)unaff_D7) {
    if (unaff_D7 == 0) {
      unaff_D7 = 0xfffffffd;
    }
    else {
      isdelfil(unaff_D7 & 0xffff,auStack_4e);
      if (unaff_D7 == 0) {
        unaff_D7 = 0xffffffd0;
      }
      else {
        msdrsmsb(unaff_D7 & 0xffff,auStack_4e,auStack_12,auStack_2e,auStack_20);
        msdrenam(param_1,auStack_12,auStack_20,param_3);
        dosstt();
        if (-1 < (int)unaff_D7) {
          msd_srch(param_1,auStack_2e,param_3);
          dosstt();
          uVar1 = unaff_D7;
          if (unaff_D7 == 0xfffffffd) {
            uVar1 = 0;
          }
          else if (0 < (int)unaff_D7) {
            msdrenam(param_1,auStack_2e,auStack_12,param_3);
            doserr();
            in_stack_ffffffae = unaff_D7;
          }
          if (-1 < (int)uVar1) {
            msdrenam(param_1,auStack_20,auStack_2e,param_3);
            dosstt();
            uVar1 = unaff_D7;
          }
          unaff_D7 = uVar1;
          if (-1 < (int)uVar1) {
            unaff_D7 = in_stack_ffffffae;
          }
        }
      }
    }
  }
  mkdoserr(param_1,unaff_D7);
  return;
}


// ==== msdrsmsb @ 0103cc40

void msdrsmsb(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
             undefined4 param_5)

{
  undefined1 auStack_28 [12];
  undefined1 auStack_1c [6];
  undefined1 local_16;
  undefined1 auStack_10 [12];
  
  dirtofnm(param_1,param_2,auStack_10);
  cpybuf(auStack_10,auStack_1c,0xb);
  cpybuf(auStack_10,auStack_28,0xb);
  local_16 = 0x5f;
  undelfnm(auStack_28);
  slvfnam(auStack_10,param_3);
  slvfnam(auStack_1c,param_5);
  slvfnam(auStack_28,param_4);
  return;
}


// ==== msd_pack @ 0103ccb8

void msd_pack(undefined4 param_1,undefined4 param_2)

{
  uint unaff_D7;
  short sVar1;
  undefined1 auStack_3e [14];
  undefined1 auStack_30 [12];
  undefined1 auStack_24 [32];
  
  sVar1 = 1;
  whichdos(param_1);
  do {
    while( true ) {
      msd_dire(param_1,sVar1,sVar1,auStack_24,param_2);
      dosstt();
      if ((int)unaff_D7 < 1) goto LAB_0103cd58;
      isdelfil(unaff_D7 & 0xffff,auStack_24);
      if (unaff_D7 != 0) break;
      sVar1 = sVar1 + 1;
    }
    dirtofnm(unaff_D7 & 0xffff,auStack_24,auStack_30);
    slvfnam(auStack_30,auStack_3e);
    msderase(param_1,auStack_3e,param_2);
    dosstt();
  } while (-1 < (int)unaff_D7);
LAB_0103cd58:
  mkdoserr(param_1);
  return;
}


// ==== msd_rxb @ 0103cd70

void msd_rxb(undefined4 param_1,ushort param_2,ushort param_3,uint param_4,int param_5,
            undefined4 param_6)

{
  uint uVar1;
  ushort uVar2;
  uint unaff_D7;
  ushort uVar3;
  
  if (param_4 < 0x28) {
    uVar2 = (ushort)param_4;
  }
  else {
    uVar2 = 0x28;
  }
  uVar3 = 0;
  uVar1 = 0;
  for (; param_2 <= param_3; param_2 = param_2 + 1) {
    msd_1rxb(param_1,param_2,(uint)uVar2,param_5,param_6);
    dosstt();
    uVar1 = unaff_D7;
    if ((int)unaff_D7 < 1) break;
    param_5 = (uint)uVar2 + param_5;
    uVar3 = uVar3 + 1;
  }
  if (uVar3 == 0) {
    if (-1 < (int)uVar1) {
      uVar1 = 0xffffffcf;
    }
  }
  else if ((-1 < (int)uVar1) || (uVar1 == 0xfffffffd)) {
    uVar1 = (uint)uVar3;
  }
  mkdoserr(param_1,uVar1);
  return;
}


// ==== msd_1rxb @ 0103ce18

void msd_1rxb(undefined4 param_1,undefined2 param_2,undefined4 param_3,undefined1 *param_4,
             undefined4 param_5)

{
  int unaff_D7;
  undefined1 auStack_3e [32];
  undefined1 auStack_1e [8];
  undefined1 auStack_16 [4];
  undefined1 auStack_12 [14];
  
  msd_dire(param_1,param_2,param_2,auStack_3e,param_5);
  dosstt();
  if (-1 < unaff_D7) {
    if (unaff_D7 == 0) {
      unaff_D7 = -3;
    }
    else {
      dirtofnm(1,auStack_3e,auStack_1e);
      slvfnam(auStack_1e,auStack_12);
      msd_open(param_1,auStack_12,0,param_5);
      dosstt();
      if (-1 < unaff_D7) {
        cmpbuf(&DAT_0103ce0c,auStack_16,3);
        if (unaff_D7 == 0) {
          cmpbuf(&DAT_0103ce10,auStack_16,3);
          cmpbuf(&DAT_0103ce14,auStack_16,3);
          *param_4 = 0x20;
        }
        else {
          *param_4 = 1;
        }
        dosstt();
        msd_xxb((int)(short)unaff_D7,param_4,param_3,param_5);
        msd_clos((int)(short)unaff_D7,param_5);
      }
    }
  }
  mkdoserr(param_1,unaff_D7);
  return;
}


// ==== msd_xxb @ 0103cf42

void msd_xxb(short param_1,char *param_2,int param_3,undefined4 param_4)

{
  int iVar1;
  byte bVar2;
  int unaff_D5;
  int unaff_D7;
  byte *unaff_A3;
  char *pcVar3;
  bool bVar4;
  
  bVar4 = *param_2 == '\x01';
  if (bVar4) {
    *param_2 = ' ';
  }
  bVar2 = 0;
  do {
    msd_read((int)param_1,0x400,&DAT_0108523a,param_4);
    dosstt();
    if (unaff_D7 < 1) break;
    unaff_A3 = &DAT_0108523a;
    unaff_D5 = 0;
    if (0 < unaff_D7) {
      do {
        if (bVar4) {
          bVar2 = *unaff_A3;
        }
        else {
          bVar2 = *unaff_A3 & 0x7f;
        }
        unaff_A3 = unaff_A3 + 1;
      } while ((bVar2 != 0x40) && (unaff_D5 = unaff_D5 + 1, unaff_D5 < unaff_D7));
    }
  } while (bVar2 != 0x40);
  if (bVar2 == 0x40) {
    if (unaff_D7 - unaff_D5 < param_3) {
      iVar1 = unaff_D7 - unaff_D5;
    }
    else {
      iVar1 = param_3;
    }
    msd_xxx(unaff_A3,param_2,iVar1,0,bVar4);
    if (iVar1 < param_3) {
      msd_read((int)param_1,0x400,&DAT_0108523a,param_4);
      dosstt();
      if (0 < unaff_D7) {
        iVar1 = unaff_D7;
        if (param_3 - unaff_D5 <= unaff_D7) {
          iVar1 = param_3 - unaff_D5;
        }
        msd_xxx(&DAT_0108523a,param_2 + unaff_D7,iVar1);
      }
    }
    pcVar3 = param_2 + unaff_D7;
    if (((bVar4) && (unaff_D7 != 0x28)) &&
       ((unaff_D7 < 1 || ((*pcVar3 != '\r' && (*pcVar3 != '\n')))))) {
      unaff_D7 = 0;
      pcVar3 = param_2;
    }
    for (; unaff_D7 < param_3; unaff_D7 = unaff_D7 + 1) {
      *pcVar3 = ' ';
      pcVar3 = pcVar3 + 1;
    }
  }
  return;
}


// ==== msd_xxx @ 0103d09e

void msd_xxx(byte *param_1,byte *param_2,int param_3,int param_4,int param_5)

{
  do {
    if (param_3 <= param_4) {
      return;
    }
    if (param_5 == 0) {
      if ((*param_1 & 0x7f) < 0x20) {
        return;
      }
    }
    else if ((*param_1 < 0x20) || (0x7e < *param_1)) {
      *param_2 = *param_1;
      return;
    }
    *param_2 = *param_1;
    param_4 = param_4 + 1;
    param_1 = param_1 + 1;
    param_2 = param_2 + 1;
  } while( true );
}


// ==== msd_wxb @ 0103d114

void msd_wxb(undefined4 param_1)

{
  mkdoserr(param_1,0xfffffff6);
  return;
}


// ==== msdreq @ 0103d12c

void msdreq(int param_1,undefined4 *param_2)

{
  undefined4 unaff_D7;
  undefined1 local_8 [4];
  
  *(undefined1 **)(param_1 + 0x28) = local_8;
  mailnwai(0x2c,4,param_1,0x80);
  *param_2 = unaff_D7;
  return;
}


// ==== msdrdsct @ 0103d15e

void msdrdsct(undefined1 param_1,undefined2 param_2,undefined2 param_3,undefined2 param_4,
             undefined4 param_5,undefined4 param_6,undefined4 param_7)

{
  undefined2 local_30;
  undefined1 local_2e;
  undefined1 local_2d;
  undefined2 local_14;
  undefined2 local_12;
  undefined4 local_10;
  undefined4 local_c;
  
  local_2e = 0x40;
  local_2d = param_1;
  local_30 = param_2;
  local_14 = param_3;
  local_12 = param_4;
  local_10 = param_5;
  local_c = param_6;
  msdreq(&local_30,param_7);
  return;
}


// ==== msdwrsct @ 0103d1a6

void msdwrsct(undefined1 param_1,undefined2 param_2,undefined2 param_3,undefined2 param_4,
             undefined4 param_5,undefined4 param_6,undefined4 param_7)

{
  undefined2 local_30;
  undefined1 local_2e;
  undefined1 local_2d;
  undefined2 local_14;
  undefined2 local_12;
  undefined4 local_10;
  undefined4 local_c;
  
  local_2e = 0x41;
  local_2d = param_1;
  local_30 = param_2;
  local_14 = param_3;
  local_12 = param_4;
  local_10 = param_5;
  local_c = param_6;
  msdreq(&local_30,param_7);
  return;
}


// ==== msddcnfg @ 0103d1ee

void msddcnfg(undefined1 param_1,undefined4 param_2)

{
  undefined1 auStack_30 [2];
  undefined1 local_2e;
  undefined1 local_2d;
  
  local_2e = 0x42;
  local_2d = param_1;
  msdreq(auStack_30,param_2);
  return;
}


// ==== msdcreat @ 0103d214

void msdcreat(undefined1 param_1,undefined4 param_2,ushort param_3,undefined2 param_4,
             undefined4 param_5)

{
  undefined1 auStack_30 [2];
  undefined1 local_2e;
  undefined1 local_2d;
  undefined1 auStack_2b [23];
  undefined2 local_14;
  uint local_10;
  
  local_2e = 0x13;
  local_2d = param_1;
  putfnam(param_2,auStack_2b);
  local_10 = (uint)param_3;
  local_14 = param_4;
  msdreq(auStack_30,param_5);
  return;
}


// ==== msd_open @ 0103d266

void msd_open(undefined1 param_1,undefined4 param_2,undefined2 param_3,undefined4 param_4)

{
  undefined1 auStack_30 [2];
  undefined1 local_2e;
  undefined1 local_2d;
  undefined1 auStack_2b [23];
  undefined2 local_14;
  
  local_2e = 0x11;
  local_2d = param_1;
  putfnam(param_2,auStack_2b);
  local_14 = param_3;
  msdreq(auStack_30,param_4);
  return;
}


// ==== msd_clos @ 0103d2a8

void msd_clos(undefined2 param_1,undefined4 param_2)

{
  undefined2 local_30;
  undefined1 local_2e;
  
  local_2e = 0x12;
  local_30 = param_1;
  msdreq(&local_30,param_2);
  return;
}


// ==== msd_read @ 0103d2cc

void msd_read(undefined2 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  undefined2 local_30;
  undefined1 local_2e;
  undefined4 local_10;
  undefined4 local_c;
  
  local_2e = 0x21;
  local_30 = param_1;
  local_10 = param_2;
  local_c = param_3;
  msdreq(&local_30,param_4);
  return;
}


// ==== msdwrite @ 0103d2fc

void msdwrite(undefined2 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  undefined2 local_30;
  undefined1 local_2e;
  undefined4 local_10;
  undefined4 local_c;
  
  local_2e = 0x22;
  local_30 = param_1;
  local_10 = param_2;
  local_c = param_3;
  msdreq(&local_30,param_4);
  return;
}


// ==== msd_seek @ 0103d32c

void msd_seek(undefined2 param_1,undefined2 param_2,undefined4 param_3,undefined4 param_4)

{
  undefined2 local_30;
  undefined1 local_2e;
  undefined2 local_14;
  undefined4 local_10;
  
  local_2e = 0x23;
  local_30 = param_1;
  local_10 = param_3;
  local_14 = param_2;
  msdreq(&local_30,param_4);
  return;
}


// ==== msderase @ 0103d35e

void msderase(undefined1 param_1,undefined4 param_2,undefined4 param_3)

{
  undefined1 auStack_30 [2];
  undefined1 local_2e;
  undefined1 local_2d;
  undefined1 auStack_2b [39];
  
  local_2e = 0x15;
  local_2d = param_1;
  putfnam(param_2,auStack_2b);
  msdreq(auStack_30,param_3);
  return;
}


// ==== msdrenam @ 0103d398

void msdrenam(undefined1 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  undefined1 auStack_30 [2];
  undefined1 local_2e;
  undefined1 local_2d;
  undefined1 auStack_2b [11];
  undefined1 auStack_20 [28];
  
  local_2e = 0x14;
  local_2d = param_1;
  putfnam(param_2,auStack_2b);
  putfnam(param_3,auStack_20);
  msdreq(auStack_30,param_4);
  return;
}


// ==== msdmount @ 0103d3e2

void msdmount(undefined1 param_1,undefined4 param_2)

{
  undefined1 auStack_30 [2];
  undefined1 local_2e;
  undefined1 local_2d;
  
  local_2e = 1;
  local_2d = param_1;
  msdreq(auStack_30,param_2);
  return;
}


// ==== msddemnt @ 0103d408

void msddemnt(undefined1 param_1,undefined4 param_2)

{
  undefined1 auStack_30 [2];
  undefined1 local_2e;
  undefined1 local_2d;
  
  local_2e = 4;
  local_2d = param_1;
  msdreq(auStack_30,param_2);
  return;
}


// ==== msd_info @ 0103d42e

void msd_info(undefined1 param_1,undefined4 param_2,undefined4 param_3)

{
  undefined1 auStack_30 [2];
  undefined1 local_2e;
  undefined1 local_2d;
  undefined4 local_c;
  
  local_2e = 2;
  local_2d = param_1;
  local_c = param_2;
  msdreq(auStack_30,param_3);
  return;
}


// ==== msd_srch @ 0103d45a

void msd_srch(undefined1 param_1,undefined4 param_2,undefined4 param_3)

{
  undefined1 auStack_30 [2];
  undefined1 local_2e;
  undefined1 local_2d;
  undefined1 auStack_2b [39];
  
  local_2e = 8;
  local_2d = param_1;
  putfnam(param_2,auStack_2b);
  msdreq(auStack_30,param_3);
  return;
}


// ==== msd_dire @ 0103d494

void msd_dire(undefined1 param_1,undefined2 param_2,undefined2 param_3,undefined4 param_4,
             undefined4 param_5)

{
  undefined1 auStack_30 [2];
  undefined1 local_2e;
  undefined1 local_2d;
  undefined2 local_14;
  undefined2 local_12;
  undefined4 local_c;
  
  local_2e = 9;
  local_2d = param_1;
  local_14 = param_2;
  local_12 = param_3;
  local_c = param_4;
  msdreq(auStack_30,param_5);
  return;
}


// ==== msdremai @ 0103d4d0

void msdremai(undefined1 param_1,undefined4 param_2)

{
  undefined1 auStack_30 [2];
  undefined1 local_2e;
  undefined1 local_2d;
  
  local_2e = 10;
  local_2d = param_1;
  msdreq(auStack_30,param_2);
  return;
}


// ==== msdgtvol @ 0103d4f6

void msdgtvol(undefined1 param_1,undefined4 param_2,undefined4 param_3)

{
  undefined1 auStack_30 [2];
  undefined1 local_2e;
  undefined1 local_2d;
  undefined4 local_c;
  
  local_2e = 0xb;
  local_2d = param_1;
  local_c = param_2;
  msdreq(auStack_30,param_3);
  return;
}


// ==== msdptvol @ 0103d522

void msdptvol(undefined1 param_1,undefined4 param_2,undefined4 param_3)

{
  undefined1 auStack_30 [2];
  undefined1 local_2e;
  undefined1 local_2d;
  undefined4 local_c;
  
  local_2e = 0xc;
  local_2d = param_1;
  local_c = param_2;
  msdreq(auStack_30,param_3);
  return;
}


// ==== msd_kind @ 0103d54e

void msd_kind(undefined1 param_1,undefined4 param_2)

{
  undefined1 auStack_30 [2];
  undefined1 local_2e;
  undefined1 local_2d;
  
  local_2e = 3;
  local_2d = param_1;
  msdreq(auStack_30,param_2);
  return;
}


// ==== msd_init @ 0103d574

void msd_init(undefined1 param_1,byte param_2,byte param_3,undefined4 param_4,undefined4 param_5)

{
  undefined1 auStack_30 [2];
  undefined1 local_2e;
  undefined1 local_2d;
  ushort local_14;
  ushort local_12;
  undefined4 local_c;
  
  local_2e = 0x30;
  local_2d = param_1;
  local_14 = (ushort)param_2;
  local_12 = (ushort)param_3;
  local_c = param_4;
  msdreq(auStack_30,param_5);
  return;
}


// ==== msdvolcp @ 0103d5b8

void msdvolcp(undefined1 param_1,undefined1 param_2,undefined4 param_3)

{
  undefined1 auStack_30 [2];
  undefined1 local_2e;
  undefined1 local_2d;
  undefined1 local_2c;
  
  local_2e = 0x31;
  local_2d = param_1;
  local_2c = param_2;
  msdreq(auStack_30,param_3);
  return;
}


// ==== msddstat @ 0103d5e6

void msddstat(undefined1 param_1,undefined4 param_2)

{
  undefined1 auStack_30 [2];
  undefined1 local_2e;
  undefined1 local_2d;
  
  local_2e = 0xf;
  local_2d = param_1;
  msdreq(auStack_30,param_2);
  return;
}


// ==== msd_fcpy @ 0103d60c

void msd_fcpy(undefined1 param_1,undefined4 param_2,undefined1 param_3,undefined4 param_4,
             undefined4 param_5)

{
  undefined1 auStack_30 [2];
  undefined1 local_2e;
  undefined1 local_2d;
  undefined1 local_2c;
  undefined1 auStack_2b [11];
  undefined1 auStack_20 [28];
  
  local_2e = 0x32;
  local_2d = param_1;
  putfnam(param_2,auStack_2b);
  local_2c = param_3;
  putfnam(param_4,auStack_20);
  msdreq(auStack_30,param_5);
  return;
}


// ==== sdu_clos @ 0103d660

void sdu_clos(undefined2 param_1,undefined4 *param_2)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36 [36];
  undefined2 local_12;
  undefined4 local_c;
  undefined1 *local_8;
  
  local_c = 0;
  local_36[0] = 3;
  local_12 = param_1;
  local_8 = local_3a;
  mailnwai(0x32,6,local_36,0x4000000);
  *param_2 = unaff_D7;
  return;
}


// ==== sdu_read @ 0103d6a4

void sdu_read(undefined2 param_1,undefined4 param_2,undefined4 param_3,undefined4 *param_4)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36 [32];
  undefined4 local_16;
  undefined2 local_12;
  undefined4 local_c;
  undefined1 *local_8;
  
  local_36[0] = 4;
  local_12 = param_1;
  local_16 = param_2;
  local_c = param_3;
  local_8 = local_3a;
  mailnwai(0x32,6,local_36,0x4000000);
  *param_4 = unaff_D7;
  return;
}


// ==== sduwrite @ 0103d6f0

void sduwrite(undefined2 param_1,undefined4 param_2,undefined4 param_3,undefined4 *param_4)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36 [32];
  undefined4 local_16;
  undefined2 local_12;
  undefined4 local_10;
  undefined4 local_c;
  undefined1 *local_8;
  
  local_36[0] = 5;
  local_12 = param_1;
  local_16 = param_2;
  local_c = param_3;
  local_10 = 0x80;
  local_8 = local_3a;
  mailnwai(0x32,6,local_36,0x4000000);
  *param_4 = unaff_D7;
  return;
}


// ==== sducreat @ 0103d744

void sducreat(undefined4 param_1,undefined4 param_2,ushort param_3,undefined4 param_4,
             undefined4 *param_5)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36;
  undefined1 local_35;
  undefined1 local_34;
  undefined1 auStack_32 [28];
  uint local_16;
  undefined4 local_c;
  undefined1 *local_8;
  
  local_c = 0;
  local_36 = 1;
  local_35 = (undefined1)((uint)param_1 >> 0x10);
  local_34 = (undefined1)param_1;
  cpyast(param_2,auStack_32);
  local_16 = (uint)param_3;
  local_8 = local_3a;
  mailnwai(0x32,6,&local_36,0x4000000);
  *param_5 = unaff_D7;
  return;
}


// ==== sdu_open @ 0103d7b6

void sdu_open(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 *param_4)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36;
  undefined1 local_35;
  undefined1 local_34;
  undefined1 auStack_32 [38];
  undefined4 local_c;
  undefined1 *local_8;
  
  local_c = 0;
  local_36 = 2;
  local_35 = (undefined1)((uint)param_1 >> 0x10);
  local_34 = (undefined1)param_1;
  cpyast(param_2,auStack_32);
  local_8 = local_3a;
  mailnwai(0x32,6,&local_36,0x4000000);
  *param_4 = unaff_D7;
  return;
}


// ==== sdu_delet @ 0103d818

void sdu_delet(undefined4 param_1,undefined4 param_2,undefined4 *param_3)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36;
  undefined1 local_35;
  undefined1 local_34;
  undefined1 auStack_32 [38];
  undefined4 local_c;
  undefined1 *local_8;
  
  local_c = 0;
  local_36 = 6;
  local_35 = (undefined1)((uint)param_1 >> 0x10);
  local_34 = (undefined1)param_1;
  cpyast(param_2,auStack_32);
  local_8 = local_3a;
  mailnwai(0x32,6,&local_36,0x4000000);
  *param_3 = unaff_D7;
  return;
}


// ==== sdu_erase @ 0103d87a

void sdu_erase(undefined4 param_1,undefined4 param_2,undefined4 *param_3)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36;
  undefined1 local_35;
  undefined1 local_34;
  undefined1 auStack_32 [38];
  undefined4 local_c;
  undefined1 *local_8;
  
  local_c = 0;
  local_36 = 0x1c;
  local_35 = (undefined1)((uint)param_1 >> 0x10);
  local_34 = (undefined1)param_1;
  cpyast(param_2,auStack_32);
  local_8 = local_3a;
  mailnwai(0x32,6,&local_36,0x4000000);
  *param_3 = unaff_D7;
  return;
}


// ==== sduresum @ 0103d8dc

void sduresum(undefined4 param_1,undefined2 param_2,undefined4 *param_3)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36;
  undefined1 local_35;
  undefined1 local_34;
  undefined2 local_1a;
  undefined4 local_c;
  undefined1 *local_8;
  
  local_c = 0;
  local_36 = 7;
  local_35 = (undefined1)((uint)param_1 >> 0x10);
  local_34 = (undefined1)param_1;
  local_1a = param_2;
  local_8 = local_3a;
  mailnwai(0x32,6,&local_36,0x4000000);
  *param_3 = unaff_D7;
  return;
}


// ==== sdurenam @ 0103d932

void sdurenam(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 *param_4)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36;
  undefined1 local_35;
  undefined1 local_34;
  undefined1 auStack_32 [12];
  undefined1 auStack_26 [26];
  undefined4 local_c;
  undefined1 *local_8;
  
  local_c = 0;
  local_36 = 8;
  local_35 = (undefined1)((uint)param_1 >> 0x10);
  local_34 = (undefined1)param_1;
  cpyast(param_2,auStack_32);
  cpyast(param_3,auStack_26);
  local_8 = local_3a;
  mailnwai(0x32,6,&local_36,0x4000000);
  *param_4 = unaff_D7;
  return;
}


// ==== sdumount @ 0103d9a4

void sdumount(undefined4 param_1,undefined4 *param_2)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36;
  undefined1 local_35;
  undefined1 local_34;
  undefined4 local_c;
  undefined1 *local_8;
  
  local_c = 0;
  local_36 = 9;
  local_35 = (undefined1)((uint)param_1 >> 0x10);
  local_34 = (undefined1)param_1;
  local_8 = local_3a;
  mailnwai(0x32,6,&local_36,0x4000000);
  *param_2 = unaff_D7;
  return;
}


// ==== sdudemnt @ 0103d9f2

void sdudemnt(undefined4 param_1,undefined4 *param_2)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36;
  undefined1 local_35;
  undefined1 local_34;
  undefined4 local_c;
  undefined1 *local_8;
  
  local_c = 0;
  local_36 = 10;
  local_35 = (undefined1)((uint)param_1 >> 0x10);
  local_34 = (undefined1)param_1;
  local_8 = local_3a;
  mailnwai(0x32,6,&local_36,0x4000000);
  *param_2 = unaff_D7;
  return;
}


// ==== sdusghdr @ 0103da40

void sdusghdr(undefined4 param_1,undefined4 param_2,undefined4 *param_3)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36;
  undefined1 local_35;
  undefined1 local_34;
  undefined4 local_c;
  undefined1 *local_8;
  
  local_36 = 0xb;
  local_35 = (undefined1)((uint)param_1 >> 0x10);
  local_34 = (undefined1)param_1;
  local_c = param_2;
  local_8 = local_3a;
  mailnwai(0x32,6,&local_36,0x4000000);
  *param_3 = unaff_D7;
  return;
}


// ==== sdu_srch @ 0103da90

void sdu_srch(undefined4 param_1,undefined4 param_2,undefined4 *param_3)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36;
  undefined1 local_35;
  undefined1 local_34;
  undefined1 auStack_32 [38];
  undefined4 local_c;
  undefined1 *local_8;
  
  local_c = 0;
  local_36 = 0xc;
  local_35 = (undefined1)((uint)param_1 >> 0x10);
  local_34 = (undefined1)param_1;
  cpyast(param_2,auStack_32);
  local_8 = local_3a;
  mailnwai(0x32,6,&local_36,0x4000000);
  *param_3 = unaff_D7;
  return;
}


// ==== sdu_dire @ 0103daf2

void sdu_dire(undefined4 param_1,undefined2 param_2,undefined2 param_3,undefined4 param_4,
             undefined4 *param_5)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36;
  undefined1 local_35;
  undefined1 local_34;
  undefined2 local_1a;
  undefined2 local_18;
  undefined4 local_c;
  undefined1 *local_8;
  
  local_36 = 0xd;
  local_35 = (undefined1)((uint)param_1 >> 0x10);
  local_34 = (undefined1)param_1;
  local_1a = param_2;
  local_18 = param_3;
  local_c = param_4;
  local_8 = local_3a;
  mailnwai(0x32,6,&local_36,0x4000000);
  *param_5 = unaff_D7;
  return;
}


// ==== sdu_rxb @ 0103db58

void sdu_rxb(undefined4 param_1,undefined2 param_2,undefined2 param_3,ushort param_4,
            undefined4 param_5,undefined4 *param_6)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36;
  undefined1 local_35;
  undefined1 local_34;
  undefined2 local_1a;
  undefined2 local_18;
  uint local_16;
  undefined4 local_c;
  undefined1 *local_8;
  
  local_36 = 0xe;
  local_35 = (undefined1)((uint)param_1 >> 0x10);
  local_34 = (undefined1)param_1;
  local_1a = param_2;
  local_18 = param_3;
  local_16 = (uint)param_4;
  local_c = param_5;
  local_8 = local_3a;
  mailnwai(0x32,6,&local_36,0x4000000);
  *param_6 = unaff_D7;
  return;
}


// ==== sdu_wxb @ 0103dbce

void sdu_wxb(undefined4 param_1,undefined2 param_2,undefined2 param_3,ushort param_4,
            undefined4 param_5,undefined4 *param_6)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36;
  undefined1 local_35;
  undefined1 local_34;
  undefined2 local_1a;
  undefined2 local_18;
  uint local_16;
  undefined4 local_c;
  undefined1 *local_8;
  
  local_36 = 0xf;
  local_35 = (undefined1)((uint)param_1 >> 0x10);
  local_34 = (undefined1)param_1;
  local_1a = param_2;
  local_18 = param_3;
  local_16 = (uint)param_4;
  local_c = param_5;
  local_8 = local_3a;
  mailnwai(0x32,6,&local_36,0x4000000);
  *param_6 = unaff_D7;
  return;
}


// ==== sduremai @ 0103dc44

void sduremai(undefined4 param_1,undefined4 *param_2)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36;
  undefined1 local_35;
  undefined1 local_34;
  undefined4 local_c;
  undefined1 *local_8;
  
  local_c = 0;
  local_36 = 0x10;
  local_35 = (undefined1)((uint)param_1 >> 0x10);
  local_34 = (undefined1)param_1;
  local_8 = local_3a;
  mailnwai(0x32,6,&local_36,0x4000000);
  *param_2 = unaff_D7;
  return;
}


// ==== sdugtvol @ 0103dc92

void sdugtvol(undefined4 param_1,undefined4 param_2,undefined4 *param_3)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36;
  undefined1 local_35;
  undefined1 local_34;
  undefined4 local_c;
  undefined1 *local_8;
  
  local_36 = 0x11;
  local_35 = (undefined1)((uint)param_1 >> 0x10);
  local_34 = (undefined1)param_1;
  local_c = param_2;
  local_8 = local_3a;
  mailnwai(0x32,6,&local_36,0x4000000);
  *param_3 = unaff_D7;
  return;
}


// ==== sduptvol @ 0103dce2

void sduptvol(undefined4 param_1,undefined4 param_2,undefined4 *param_3)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36;
  undefined1 local_35;
  undefined1 local_34;
  undefined4 local_c;
  undefined1 *local_8;
  
  local_36 = 0x12;
  local_35 = (undefined1)((uint)param_1 >> 0x10);
  local_34 = (undefined1)param_1;
  local_c = param_2;
  local_8 = local_3a;
  mailnwai(0x32,6,&local_36,0x4000000);
  *param_3 = unaff_D7;
  return;
}


// ==== sdu_kind @ 0103dd32

void sdu_kind(undefined4 param_1,undefined4 *param_2)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36;
  undefined1 local_35;
  undefined1 local_34;
  undefined4 local_c;
  undefined1 *local_8;
  
  local_c = 0;
  local_36 = 0x13;
  local_35 = (undefined1)((uint)param_1 >> 0x10);
  local_34 = (undefined1)param_1;
  local_8 = local_3a;
  mailnwai(0x32,6,&local_36,0x4000000);
  *param_2 = unaff_D7;
  return;
}


// ==== sdu_init @ 0103dd80

void sdu_init(undefined4 param_1,char param_2,byte param_3,undefined4 param_4,undefined4 *param_5)

{
  byte bVar1;
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36;
  undefined1 local_35;
  char local_34;
  uint local_10;
  undefined4 local_c;
  undefined1 *local_8;
  
  local_34 = (char)param_1;
  bVar1 = 0;
  local_36 = 0x14;
  local_35 = (undefined1)((uint)param_1 >> 0x10);
  if (param_2 == '\0') {
    bVar1 = 0x80;
  }
  if ((local_34 == '\b') || (local_34 == '\t')) {
    if (param_2 == '\x02') {
      bVar1 = bVar1 | 8;
    }
    else {
      bVar1 = bVar1 | 4;
    }
  }
  if (((local_34 == '\f') || (local_34 == '\r')) && ((param_3 & 3) != 3)) {
    bVar1 = bVar1 | 1;
  }
  local_10 = (uint)bVar1;
  local_c = param_4;
  local_8 = local_3a;
  mailnwai(0x32,6,&local_36,0x4000000);
  *param_5 = unaff_D7;
  return;
}


// ==== sdu_pack @ 0103de2a

void sdu_pack(undefined4 param_1,undefined4 *param_2)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36;
  undefined1 local_35;
  undefined1 local_34;
  undefined4 local_c;
  undefined1 *local_8;
  
  local_c = 0;
  local_36 = 0x15;
  local_35 = (undefined1)((uint)param_1 >> 0x10);
  local_34 = (undefined1)param_1;
  local_8 = local_3a;
  mailnwai(0x32,6,&local_36,0x4000000);
  *param_2 = unaff_D7;
  return;
}


// ==== sdu_seek @ 0103de78

void sdu_seek(undefined2 param_1,byte param_2,undefined4 param_3,undefined4 *param_4)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36 [32];
  undefined4 local_16;
  undefined2 local_12;
  uint local_10;
  undefined4 local_c;
  undefined1 *local_8;
  
  local_c = 0;
  local_36[0] = 0x16;
  local_12 = param_1;
  local_10 = (uint)param_2;
  local_16 = param_3;
  local_8 = local_3a;
  mailnwai(0x32,6,local_36,0x4000000);
  *param_4 = unaff_D7;
  return;
}


// ==== sduvolcp @ 0103dece

void sduvolcp(undefined4 param_1,undefined1 param_2,undefined4 *param_3)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36;
  undefined1 local_35;
  undefined1 local_34;
  undefined1 local_33;
  undefined4 local_10;
  undefined4 local_c;
  undefined1 *local_8;
  
  local_c = 0;
  local_36 = 0x17;
  local_35 = (undefined1)((uint)param_1 >> 0x10);
  local_34 = (undefined1)param_1;
  local_33 = param_2;
  local_10 = 0x80;
  local_8 = local_3a;
  mailnwai(0x32,6,&local_36,0x4000000);
  *param_3 = unaff_D7;
  return;
}


// ==== sdudstat @ 0103df2c

void sdudstat(undefined4 param_1,undefined4 *param_2)

{
  int unaff_D7;
  undefined1 auStack_3c [2];
  undefined1 local_36;
  undefined1 local_35;
  undefined1 local_34;
  undefined4 local_c;
  undefined1 *local_8;
  
  sduckdrv(param_1);
  if (unaff_D7 == 0) {
    local_c = 0;
    local_36 = 0x18;
    local_35 = (undefined1)((uint)param_1 >> 0x10);
    local_34 = (undefined1)param_1;
    local_8 = auStack_3c + 2;
    mailnwai(0x32,6,&local_36,0x4000000);
    *param_2 = 0;
  }
  return;
}


// ==== sdu_fcpy @ 0103dfa6

void sdu_fcpy(undefined4 param_1,undefined4 param_2,undefined1 param_3,undefined4 param_4,
             undefined4 *param_5)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36;
  undefined1 local_35;
  undefined1 local_34;
  undefined1 local_33;
  undefined1 auStack_32 [12];
  undefined1 auStack_26 [22];
  undefined4 local_10;
  undefined4 local_c;
  undefined1 *local_8;
  
  local_c = 0;
  local_36 = 0x19;
  local_35 = (undefined1)((uint)param_1 >> 0x10);
  local_34 = (undefined1)param_1;
  local_33 = param_3;
  cpybuf(param_2,auStack_32,0xc);
  cpybuf(param_4,auStack_26,0xc);
  local_10 = 0x80;
  local_8 = local_3a;
  mailnwai(0x32,6,&local_36,0x4000000);
  *param_5 = unaff_D7;
  return;
}


// ==== sdurdsct @ 0103e030

void sdurdsct(undefined4 param_1,undefined2 param_2,undefined2 param_3,undefined2 param_4,
             undefined4 param_5,undefined4 param_6,undefined4 *param_7)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36;
  undefined1 local_35;
  undefined1 local_34;
  undefined2 local_1a;
  undefined2 local_18;
  undefined4 local_16;
  undefined2 local_12;
  undefined4 local_c;
  undefined1 *local_8;
  
  local_36 = 0x1a;
  local_35 = (undefined1)((uint)param_1 >> 0x10);
  local_34 = (undefined1)param_1;
  local_12 = param_2;
  local_1a = param_3;
  local_18 = param_4;
  local_c = param_6;
  local_16 = param_5;
  local_8 = local_3a;
  mailnwai(0x32,6,&local_36,0x4000000);
  *param_7 = unaff_D7;
  return;
}


// ==== sduwrsct @ 0103e09e

void sduwrsct(undefined4 param_1,undefined2 param_2,undefined2 param_3,undefined2 param_4,
             undefined4 param_5,undefined4 param_6,undefined4 *param_7)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36;
  undefined1 local_35;
  undefined1 local_34;
  undefined2 local_1a;
  undefined2 local_18;
  undefined4 local_16;
  undefined2 local_12;
  undefined4 local_c;
  undefined1 *local_8;
  
  local_36 = 0x1b;
  local_35 = (undefined1)((uint)param_1 >> 0x10);
  local_34 = (undefined1)param_1;
  local_12 = param_2;
  local_1a = param_3;
  local_18 = param_4;
  local_c = param_6;
  local_16 = param_5;
  local_8 = local_3a;
  mailnwai(0x32,6,&local_36,0x4000000);
  *param_7 = unaff_D7;
  return;
}


// ==== sdudcnfg @ 0103e10c

void sdudcnfg(undefined4 param_1,undefined4 *param_2)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36;
  undefined1 local_35;
  undefined1 local_34;
  undefined4 local_c;
  undefined1 *local_8;
  
  local_c = 0;
  local_36 = 0x1d;
  local_35 = (undefined1)((uint)param_1 >> 0x10);
  local_34 = (undefined1)param_1;
  local_8 = local_3a;
  mailnwai(0x32,6,&local_36,0x4000000);
  *param_2 = unaff_D7;
  return;
}


// ==== sduckdrv @ 0103e15a

void sduckdrv(undefined1 param_1)

{
  switch(param_1) {
  case 8:
  case 9:
  case 0xc:
  case 0xd:
    break;
  default:
  }
  return;
}


// ==== rq8creat @ 0103e194

void rq8creat(undefined1 param_1,undefined4 param_2,ushort param_3,undefined4 param_4,
             undefined4 *param_5)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36 [2];
  undefined1 local_34;
  undefined1 auStack_32 [28];
  uint local_16;
  undefined1 *local_8;
  
  local_36[0] = 1;
  local_34 = param_1;
  cpyast(param_2,auStack_32);
  local_16 = (uint)param_3;
  local_8 = local_3a;
  mailnwai(0x32,5,local_36,0x4000000);
  *param_5 = unaff_D7;
  return;
}


// ==== rq8_open @ 0103e1f8

void rq8_open(undefined1 param_1,undefined4 param_2,undefined4 param_3,undefined4 *param_4)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36 [2];
  undefined1 local_34;
  undefined1 auStack_32 [42];
  undefined1 *local_8;
  
  local_36[0] = 2;
  local_34 = param_1;
  local_8 = local_3a;
  cpyast(param_2,auStack_32);
  mailnwai(0x32,5,local_36,0x4000000);
  *param_4 = unaff_D7;
  return;
}


// ==== rq8_clos @ 0103e24c

void rq8_clos(undefined2 param_1,undefined4 *param_2)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36 [36];
  undefined2 local_12;
  undefined1 *local_8;
  
  local_36[0] = 3;
  local_12 = param_1;
  local_8 = local_3a;
  mailnwai(0x32,5,local_36,0x4000000);
  *param_2 = unaff_D7;
  return;
}


// ==== rq8_read @ 0103e28c

void rq8_read(undefined2 param_1,undefined4 param_2,undefined4 param_3,undefined4 *param_4)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36 [32];
  undefined4 local_16;
  undefined2 local_12;
  undefined4 local_c;
  undefined1 *local_8;
  
  local_36[0] = 4;
  local_12 = param_1;
  local_16 = param_2;
  local_c = param_3;
  local_8 = local_3a;
  mailnwai(0x32,5,local_36,0x4000000);
  *param_4 = unaff_D7;
  return;
}


// ==== rq8write @ 0103e2d8

void rq8write(undefined2 param_1,undefined4 param_2,undefined4 param_3,undefined4 *param_4)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36 [32];
  undefined4 local_16;
  undefined2 local_12;
  undefined4 local_c;
  undefined1 *local_8;
  
  local_36[0] = 5;
  local_12 = param_1;
  local_16 = param_2;
  local_c = param_3;
  local_8 = local_3a;
  mailnwai(0x32,5,local_36,0x4000000);
  *param_4 = unaff_D7;
  return;
}


// ==== rq8delet @ 0103e324

void rq8delet(undefined1 param_1,undefined4 param_2,undefined4 *param_3)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36 [2];
  undefined1 local_34;
  undefined1 auStack_32 [42];
  undefined1 *local_8;
  
  local_36[0] = 6;
  local_34 = param_1;
  cpyast(param_2,auStack_32);
  local_8 = local_3a;
  mailnwai(0x32,5,local_36,0x4000000);
  *param_3 = unaff_D7;
  return;
}


// ==== rq8resum @ 0103e378

void rq8resum(undefined1 param_1,undefined2 param_2,undefined4 *param_3)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36 [2];
  undefined1 local_34;
  undefined2 local_1a;
  undefined1 *local_8;
  
  local_36[0] = 7;
  local_34 = param_1;
  local_1a = param_2;
  local_8 = local_3a;
  mailnwai(0x32,5,local_36,0x4000000);
  *param_3 = unaff_D7;
  return;
}


// ==== rq8renam @ 0103e3c0

void rq8renam(undefined1 param_1,undefined4 param_2,undefined4 param_3,undefined4 *param_4)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36 [2];
  undefined1 local_34;
  undefined1 auStack_32 [12];
  undefined1 auStack_26 [30];
  undefined1 *local_8;
  
  local_36[0] = 8;
  local_34 = param_1;
  cpyast(param_2,auStack_32);
  cpyast(param_3,auStack_26);
  local_8 = local_3a;
  mailnwai(0x32,5,local_36,0x4000000);
  *param_4 = unaff_D7;
  return;
}


// ==== rq8mount @ 0103e424

void rq8mount(undefined1 param_1,undefined4 *param_2)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36 [2];
  undefined1 local_34;
  undefined1 *local_8;
  
  local_36[0] = 9;
  local_34 = param_1;
  local_8 = local_3a;
  mailnwai(0x32,5,local_36,0x4000000);
  *param_2 = unaff_D7;
  return;
}


// ==== rq8demnt @ 0103e464

void rq8demnt(undefined1 param_1,undefined4 *param_2)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36 [2];
  undefined1 local_34;
  undefined1 *local_8;
  
  local_36[0] = 10;
  local_34 = param_1;
  local_8 = local_3a;
  mailnwai(0x32,5,local_36,0x4000000);
  *param_2 = unaff_D7;
  return;
}


// ==== rq8sghdr @ 0103e4a4

void rq8sghdr(undefined1 param_1,undefined4 param_2,undefined4 *param_3)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36 [2];
  undefined1 local_34;
  undefined4 local_c;
  undefined1 *local_8;
  
  local_36[0] = 0xb;
  local_34 = param_1;
  local_c = param_2;
  local_8 = local_3a;
  mailnwai(0x32,5,local_36,0x4000000);
  *param_3 = unaff_D7;
  return;
}


// ==== rq8_srch @ 0103e4ea

void rq8_srch(undefined1 param_1,undefined4 param_2,undefined4 *param_3)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36 [2];
  undefined1 local_34;
  undefined1 auStack_32 [42];
  undefined1 *local_8;
  
  local_36[0] = 0xc;
  local_34 = param_1;
  cpyast(param_2,auStack_32);
  local_8 = local_3a;
  mailnwai(0x32,5,local_36,0x4000000);
  *param_3 = unaff_D7;
  return;
}


// ==== rq8_dire @ 0103e53e

void rq8_dire(undefined1 param_1,undefined2 param_2,undefined2 param_3,undefined4 param_4,
             undefined4 *param_5)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36 [2];
  undefined1 local_34;
  undefined2 local_1a;
  undefined2 local_18;
  undefined4 local_c;
  undefined1 *local_8;
  
  local_36[0] = 0xd;
  local_34 = param_1;
  local_1a = param_2;
  local_18 = param_3;
  local_c = param_4;
  local_8 = local_3a;
  mailnwai(0x32,5,local_36,0x4000000);
  *param_5 = unaff_D7;
  return;
}


// ==== rq8_rxb @ 0103e594

void rq8_rxb(undefined1 param_1,undefined2 param_2,undefined2 param_3,ushort param_4,
            undefined4 param_5,undefined4 *param_6)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36 [2];
  undefined1 local_34;
  undefined2 local_1a;
  undefined2 local_18;
  uint local_16;
  undefined4 local_c;
  undefined1 *local_8;
  
  local_36[0] = 0xe;
  local_34 = param_1;
  local_1a = param_2;
  local_18 = param_3;
  local_16 = (uint)param_4;
  local_c = param_5;
  local_8 = local_3a;
  mailnwai(0x32,5,local_36,0x4000000);
  *param_6 = unaff_D7;
  return;
}


// ==== rq8_wxb @ 0103e5fc

void rq8_wxb(undefined1 param_1,undefined2 param_2,undefined2 param_3,ushort param_4,
            undefined4 param_5,undefined4 *param_6)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36 [2];
  undefined1 local_34;
  undefined2 local_1a;
  undefined2 local_18;
  uint local_16;
  undefined4 local_c;
  undefined1 *local_8;
  
  local_36[0] = 0xf;
  local_34 = param_1;
  local_1a = param_2;
  local_18 = param_3;
  local_16 = (uint)param_4;
  local_c = param_5;
  local_8 = local_3a;
  mailnwai(0x32,5,local_36,0x4000000);
  *param_6 = unaff_D7;
  return;
}


// ==== rq8remai @ 0103e664

void rq8remai(undefined1 param_1,undefined4 *param_2)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36 [2];
  undefined1 local_34;
  undefined1 *local_8;
  
  local_36[0] = 0x10;
  local_34 = param_1;
  local_8 = local_3a;
  mailnwai(0x32,5,local_36,0x4000000);
  *param_2 = unaff_D7;
  return;
}


// ==== rq8gtvol @ 0103e6a4

void rq8gtvol(undefined1 param_1,undefined4 param_2,undefined4 *param_3)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36 [2];
  undefined1 local_34;
  undefined4 local_c;
  undefined1 *local_8;
  
  local_36[0] = 0x11;
  local_34 = param_1;
  local_c = param_2;
  local_8 = local_3a;
  mailnwai(0x32,5,local_36,0x4000000);
  *param_3 = unaff_D7;
  return;
}


// ==== rq8ptvol @ 0103e6ea

void rq8ptvol(undefined1 param_1,undefined4 param_2,undefined4 *param_3)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36 [2];
  undefined1 local_34;
  undefined4 local_c;
  undefined1 *local_8;
  
  local_36[0] = 0x12;
  local_34 = param_1;
  local_c = param_2;
  local_8 = local_3a;
  mailnwai(0x32,5,local_36,0x4000000);
  *param_3 = unaff_D7;
  return;
}


// ==== rq8_kind @ 0103e730

void rq8_kind(undefined1 param_1,undefined4 *param_2)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36 [2];
  undefined1 local_34;
  undefined1 *local_8;
  
  local_36[0] = 0x13;
  local_34 = param_1;
  local_8 = local_3a;
  mailnwai(0x32,5,local_36,0x4000000);
  *param_2 = unaff_D7;
  return;
}


// ==== rq8_init @ 0103e770

void rq8_init(undefined1 param_1,char param_2,byte param_3,undefined4 param_4,undefined4 *param_5)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36 [2];
  undefined1 local_34;
  short local_1a;
  uint local_16;
  undefined4 local_c;
  undefined1 *local_8;
  
  local_36[0] = 0x14;
  local_34 = param_1;
  local_1a = (short)param_2;
  local_16 = (uint)param_3;
  local_c = param_4;
  local_8 = local_3a;
  mailnwai(0x32,5,local_36,0x4000000);
  *param_5 = unaff_D7;
  return;
}


// ==== rq8_pack @ 0103e7cc

void rq8_pack(undefined1 param_1,undefined4 *param_2)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36 [2];
  undefined1 local_34;
  undefined1 *local_8;
  
  local_36[0] = 0x15;
  local_34 = param_1;
  local_8 = local_3a;
  mailnwai(0x32,5,local_36,0x4000000);
  *param_2 = unaff_D7;
  return;
}


// ==== rq8_fcpy @ 0103e80c

void rq8_fcpy(undefined1 param_1,undefined4 param_2,undefined1 param_3,undefined4 param_4,
             undefined4 *param_5)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36 [2];
  undefined1 local_34;
  undefined1 local_33;
  undefined1 auStack_32 [12];
  undefined1 auStack_26 [30];
  undefined1 *local_8;
  
  local_36[0] = 0x19;
  local_34 = param_1;
  cpyast(param_2,auStack_32);
  local_33 = param_3;
  cpyast(param_4,auStack_26);
  local_8 = local_3a;
  mailnwai(0x32,5,local_36,0x4000000);
  *param_5 = unaff_D7;
  return;
}


// ==== rq8volcp @ 0103e878

void rq8volcp(undefined1 param_1,undefined1 param_2,undefined4 *param_3)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36 [2];
  undefined1 local_34;
  undefined1 local_33;
  undefined1 *local_8;
  
  local_36[0] = 0x17;
  local_34 = param_1;
  local_33 = param_2;
  local_8 = local_3a;
  mailnwai(0x32,5,local_36,0x4000000);
  *param_3 = unaff_D7;
  return;
}


// ==== rq8dstat @ 0103e8c0

void rq8dstat(undefined1 param_1,undefined4 *param_2)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36 [2];
  undefined1 local_34;
  undefined1 *local_8;
  
  local_36[0] = 0x18;
  local_34 = param_1;
  local_8 = local_3a;
  mailnwai(0x32,5,local_36,0x4000000);
  *param_2 = unaff_D7;
  return;
}


// ==== rq8rdsct @ 0103e900

void rq8rdsct(undefined1 param_1,undefined2 param_2,undefined2 param_3,undefined2 param_4,
             undefined4 param_5,undefined4 param_6,undefined4 *param_7)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36 [2];
  undefined1 local_34;
  undefined2 local_1a;
  undefined2 local_18;
  undefined4 local_16;
  undefined2 local_12;
  undefined4 local_c;
  undefined1 *local_8;
  
  local_36[0] = 0x1a;
  local_34 = param_1;
  local_12 = param_2;
  local_1a = param_3;
  local_18 = param_4;
  local_c = param_6;
  local_16 = param_5;
  local_8 = local_3a;
  mailnwai(0x32,5,local_36,0x4000000);
  *param_7 = unaff_D7;
  return;
}


// ==== rq8wrsct @ 0103e964

void rq8wrsct(undefined1 param_1,undefined2 param_2,undefined2 param_3,undefined2 param_4,
             undefined4 param_5,undefined4 param_6,undefined4 *param_7)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36 [2];
  undefined1 local_34;
  undefined2 local_1a;
  undefined2 local_18;
  undefined4 local_16;
  undefined2 local_12;
  undefined4 local_c;
  undefined1 *local_8;
  
  local_36[0] = 0x1b;
  local_34 = param_1;
  local_12 = param_2;
  local_1a = param_3;
  local_18 = param_4;
  local_c = param_6;
  local_16 = param_5;
  local_8 = local_3a;
  mailnwai(0x32,5,local_36,0x4000000);
  *param_7 = unaff_D7;
  return;
}


// ==== rq8dcnfg @ 0103e9c8

void rq8dcnfg(undefined1 param_1,undefined4 *param_2)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36 [2];
  undefined1 local_34;
  undefined1 *local_8;
  
  local_36[0] = 0x1d;
  local_34 = param_1;
  local_8 = local_3a;
  mailnwai(0x32,5,local_36,0x4000000);
  *param_2 = unaff_D7;
  return;
}


// ==== netsreq @ 0103ea08

void netsreq(int param_1,uint *param_2)

{
  uint unaff_D7;
  undefined1 local_8 [4];
  
  *(undefined1 **)(param_1 + 4) = local_8;
  mailnwai(0x18,7,param_1,0x8000000);
  *param_2 = *param_2 | unaff_D7;
  *param_2 = *param_2 & 0xf7ffffff;
  return;
}


// ==== netopen @ 0103ea50

void netopen(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  undefined4 local_1c [2];
  undefined4 local_14;
  undefined4 local_10;
  
  local_1c[0] = 3;
  local_14 = param_2;
  local_10 = param_3;
  netsreq(local_1c,param_4);
  return;
}


// ==== netclos @ 0103ea78

void netclos(short param_1,undefined4 param_2)

{
  undefined4 local_1c [2];
  int local_14;
  
  local_1c[0] = 6;
  local_14 = (int)param_1;
  netsreq(local_1c,param_2);
  return;
}


// ==== netread @ 0103ea9e

void netread(short param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  undefined4 local_1c [2];
  int local_14;
  undefined4 local_10;
  undefined4 local_c;
  
  local_1c[0] = 4;
  local_14 = (int)param_1;
  local_10 = param_2;
  local_c = param_3;
  netsreq(local_1c,param_4);
  return;
}


// ==== netwrite @ 0103ead0

void netwrite(short param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  undefined4 local_1c [2];
  int local_14;
  undefined4 local_10;
  undefined4 local_c;
  
  local_1c[0] = 5;
  local_14 = (int)param_1;
  local_10 = param_2;
  local_c = param_3;
  netsreq(local_1c,param_4);
  return;
}


// ==== netseek @ 0103eb02

void netseek(short param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  undefined4 local_1c [2];
  int local_14;
  undefined4 local_10;
  undefined4 local_c;
  
  local_1c[0] = 7;
  local_14 = (int)param_1;
  local_10 = param_2;
  local_c = param_3;
  netsreq(local_1c,param_4);
  return;
}


// ==== netmount @ 0103eb34

void netmount(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  undefined4 local_1c [2];
  undefined4 local_14;
  
  local_1c[0] = 1;
  local_14 = param_2;
  netsreq(local_1c,param_3);
  return;
}


// ==== netdemnt @ 0103eb56

void netdemnt(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  undefined4 local_1c [2];
  undefined4 local_14;
  
  local_1c[0] = 2;
  local_14 = param_2;
  netsreq(local_1c,param_3);
  return;
}


// ==== netfstest @ 0103eb78

void netfstest(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
              undefined4 param_5)

{
  undefined4 local_1c [2];
  undefined4 local_14;
  undefined4 local_10;
  undefined4 local_c;
  undefined4 local_8;
  
  local_1c[0] = 9;
  local_10 = param_2;
  local_c = param_3;
  local_8 = param_4;
  local_14 = param_1;
  netsreq(local_1c,param_5);
  return;
}


// ==== netfrtest @ 0103ebac

void netfrtest(undefined4 param_1,undefined4 param_2)

{
  undefined4 local_1c [5];
  undefined4 local_8;
  
  local_1c[0] = 10;
  local_8 = param_1;
  netsreq(local_1c,param_2);
  return;
}


// ==== netutime @ 0103ebce

void netutime(undefined4 param_1,uint *param_2)

{
  uint unaff_D7;
  undefined4 local_1c;
  undefined4 local_18;
  
  local_1c = 8;
  local_18 = param_1;
  mailnwai(0x18,7,&local_1c,0x8000000);
  *param_2 = *param_2 | unaff_D7;
  return;
}


// ==== netnwopen @ 0103ec0a

void netnwopen(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
              undefined4 param_5)

{
  undefined4 local_1c;
  undefined4 local_18;
  undefined4 local_14;
  undefined4 local_10;
  
  local_1c = 3;
  local_14 = param_2;
  local_10 = param_3;
  local_18 = param_5;
  semsg(0x18,7,&local_1c);
  return;
}


// ==== netnwclos @ 0103ec3c

void netnwclos(short param_1,undefined4 param_2,undefined4 param_3)

{
  undefined4 local_1c;
  undefined4 local_18;
  int local_14;
  
  local_1c = 6;
  local_14 = (int)param_1;
  local_18 = param_3;
  semsg(0x18,7,&local_1c);
  return;
}


// ==== netnwread @ 0103ec6c

void netnwread(short param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
              undefined4 param_5)

{
  undefined4 local_1c;
  undefined4 local_18;
  int local_14;
  undefined4 local_10;
  undefined4 local_c;
  
  local_1c = 4;
  local_14 = (int)param_1;
  local_10 = param_2;
  local_c = param_3;
  local_18 = param_5;
  semsg(0x18,7,&local_1c);
  return;
}


// ==== netnwwrit @ 0103eca8

void netnwwrit(short param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
              undefined4 param_5)

{
  undefined4 local_1c;
  undefined4 local_18;
  int local_14;
  undefined4 local_10;
  undefined4 local_c;
  
  local_1c = 5;
  local_14 = (int)param_1;
  local_10 = param_2;
  local_c = param_3;
  local_18 = param_5;
  semsg(0x18,7,&local_1c);
  return;
}


// ==== netnwseek @ 0103ece4

void netnwseek(short param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
              undefined4 param_5)

{
  undefined4 local_1c;
  undefined4 local_18;
  int local_14;
  undefined4 local_10;
  undefined4 local_c;
  
  local_1c = 7;
  local_14 = (int)param_1;
  local_10 = param_2;
  local_c = param_3;
  local_18 = param_5;
  semsg(0x18,7,&local_1c);
  return;
}


// ==== netnwmoun @ 0103ed20

void netnwmoun(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  undefined4 local_1c;
  undefined4 local_18;
  undefined4 local_14;
  
  local_1c = 1;
  local_14 = param_2;
  local_18 = param_4;
  semsg(0x18,7,&local_1c);
  return;
}


// ==== netnwdemn @ 0103ed4c

void netnwdemn(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  undefined4 local_1c;
  undefined4 local_18;
  undefined4 local_14;
  
  local_1c = 2;
  local_14 = param_2;
  local_18 = param_4;
  semsg(0x18,7,&local_1c);
  return;
}


// ==== if508_cop @ 0103ed78

void if508_cop(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  undefined1 auStack_18 [8];
  undefined4 local_10;
  undefined4 local_c;
  
  local_10 = param_1;
  local_c = param_2;
  rq_if508(auStack_18,0x20,param_3);
  return;
}


// ==== if508_ccl @ 0103eda0

void if508_ccl(undefined4 param_1,undefined4 param_2)

{
  undefined1 auStack_18 [8];
  undefined4 local_10;
  
  local_10 = param_1;
  rq_if508(auStack_18,0x21,param_2);
  return;
}


// ==== if508_cre @ 0103edc2

void if508_cre(undefined4 param_1,int param_2,int param_3,undefined4 param_4)

{
  int iVar1;
  int iVar2;
  int unaff_D7;
  undefined1 auStack_18 [8];
  undefined4 local_10;
  int local_c;
  int local_8;
  
  local_10 = param_1;
  local_8 = param_2;
  while( true ) {
    if (param_3 == 0) {
      return;
    }
    if (param_3 < 0x400) {
      iVar1 = 0;
      iVar2 = local_8;
      local_c = param_3;
    }
    else {
      local_c = 0x400;
      iVar2 = local_8 + 0x400;
      iVar1 = param_3 + -0x400;
    }
    rq_if508(auStack_18,0x22,param_4);
    if (unaff_D7 == -0xed) break;
    local_8 = iVar2;
    param_3 = iVar1;
    if (unaff_D7 < 0) {
      return;
    }
  }
  return;
}


// ==== nm_sopen @ 0103ee40

void nm_sopen(undefined4 param_1,char *param_2,undefined4 param_3)

{
  char *pcVar1;
  char local_24 [12];
  undefined1 auStack_18 [8];
  undefined4 local_10;
  char *local_c;
  
  local_10 = param_1;
  pcVar1 = local_24;
  for (; (*param_2 != '\0' && (*param_2 != ':')); param_2 = param_2 + 1) {
    *pcVar1 = *param_2;
    pcVar1 = pcVar1 + 1;
  }
  *pcVar1 = '\0';
  local_c = local_24;
  rq_if508(auStack_18,0x23,param_3);
  return;
}


// ==== nm_sclose @ 0103ee84

void nm_sclose(int param_1,undefined4 param_2)

{
  undefined1 auStack_18 [8];
  int local_10;
  
  if (param_1 != 0) {
    local_10 = param_1;
    rq_if508(auStack_18,0x24,param_2);
  }
  return;
}


// ==== nm_fopen @ 0103eeb2

void nm_fopen(undefined4 param_1,undefined4 param_2,undefined1 param_3,undefined4 param_4)

{
  undefined1 auStack_18 [8];
  undefined4 local_10;
  undefined4 local_c;
  undefined1 local_8;
  
  local_10 = param_1;
  local_c = param_2;
  local_8 = param_3;
  rq_if508(auStack_18,0x25,param_4);
  return;
}


// ==== nm_fclose @ 0103eee2

void nm_fclose(undefined4 param_1,undefined4 param_2)

{
  undefined4 uVar1;
  undefined4 uVar2;
  undefined1 auStack_18 [8];
  undefined4 local_10;
  
  local_10 = param_1;
  uVar2 = 100;
  uVar1 = 0;
  wait((void *)0x0);
  rq_if508(auStack_18,0x26,param_2,uVar1,uVar2);
  return;
}


// ==== nm_fread @ 0103ef10

void nm_fread(undefined4 param_1,int param_2,int param_3,undefined4 param_4)

{
  int iVar1;
  int iVar2;
  int unaff_D7;
  undefined1 auStack_18 [8];
  undefined4 local_10;
  int local_c;
  int local_8;
  
  local_10 = param_1;
  local_8 = param_3;
  while( true ) {
    if (param_2 == 0) {
      return;
    }
    if (param_2 < 0x400) {
      iVar1 = 0;
      iVar2 = local_8;
      local_c = param_2;
    }
    else {
      local_c = 0x400;
      iVar2 = local_8 + 0x400;
      iVar1 = param_2 + -0x400;
    }
    rq_if508(auStack_18,0x27,param_4);
    if (unaff_D7 == -0xed) break;
    param_2 = iVar1;
    local_8 = iVar2;
    if (unaff_D7 < 0) {
      return;
    }
  }
  return;
}


// ==== nm_fwrite @ 0103ef9e

void nm_fwrite(undefined4 param_1,int param_2,int param_3,undefined4 param_4)

{
  int iVar1;
  int iVar2;
  int unaff_D7;
  undefined1 auStack_18 [8];
  undefined4 local_10;
  int local_c;
  int local_8;
  
  local_10 = param_1;
  local_8 = param_3;
  do {
    if (param_2 == 0) {
      return;
    }
    if (param_2 < 0x400) {
      iVar1 = 0;
      iVar2 = local_8;
      local_c = param_2;
    }
    else {
      local_c = 0x400;
      iVar2 = local_8 + 0x400;
      iVar1 = param_2 + -0x400;
    }
    rq_if508(auStack_18,0x28,param_4);
    param_2 = iVar1;
    local_8 = iVar2;
  } while (-1 < unaff_D7);
  return;
}


// ==== nm_getdir @ 0103f016

int nm_getdir(undefined4 param_1,int param_2,int param_3,int param_4,uint param_5,undefined4 param_6
             )

{
  int in_D1;
  int iVar1;
  int unaff_D7;
  int iVar2;
  undefined1 auStack_18 [8];
  undefined4 local_10;
  uint local_c;
  int local_8;
  
  if (param_4 < param_3) {
    in_D1 = -10;
  }
  else {
    param_3 = param_3 + -1;
    iVar2 = 0;
    local_10 = param_1;
    for (param_4 = param_4 - param_3; 0 < param_4; param_4 = param_4 - unaff_D7) {
      if ((uint)(param_4 * 0x20) < 0x401) {
        iVar1 = param_4;
      }
      else {
        iVar1 = 0x20;
      }
      local_c = param_5 | iVar1 + param_3 & 0xffffU | param_3 << 0x10;
      local_8 = param_2;
      rq_if508(auStack_18,0x29,param_6);
      in_D1 = unaff_D7;
      if ((unaff_D7 < 0) || (iVar2 = unaff_D7 + iVar2, unaff_D7 < iVar1)) break;
      param_2 = unaff_D7 * 0x20 + param_2;
      param_3 = unaff_D7 + param_3;
    }
    if (iVar2 != 0) {
      in_D1 = iVar2;
    }
  }
  return in_D1;
}


// ==== nm_rm @ 0103f0c6

void nm_rm(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  undefined1 auStack_18 [8];
  undefined4 local_10;
  undefined4 local_c;
  
  local_10 = param_1;
  local_c = param_2;
  rq_if508(auStack_18,0x2a,param_3);
  return;
}


// ==== nm_ren @ 0103f0ee

void nm_ren(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  undefined1 auStack_18 [8];
  undefined4 local_10;
  undefined4 local_c;
  undefined4 local_8;
  
  local_10 = param_1;
  local_c = param_2;
  local_8 = param_3;
  rq_if508(auStack_18,0x2b,param_4);
  return;
}


// ==== nm_mkdir @ 0103f11c

void nm_mkdir(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  undefined1 auStack_18 [8];
  undefined4 local_10;
  undefined4 local_c;
  
  local_10 = param_1;
  local_c = param_2;
  rq_if508(auStack_18,0x2c,param_3);
  return;
}


// ==== nm_rmdir @ 0103f144

void nm_rmdir(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  undefined1 auStack_18 [8];
  undefined4 local_10;
  undefined4 local_c;
  
  local_10 = param_1;
  local_c = param_2;
  rq_if508(auStack_18,0x2d,param_3);
  return;
}


// ==== nm_cd @ 0103f16c

void nm_cd(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  undefined1 auStack_18 [8];
  undefined4 local_10;
  undefined4 local_c;
  
  local_10 = param_1;
  local_c = param_2;
  rq_if508(auStack_18,0x2e,param_3);
  return;
}


// ==== nm_pwd @ 0103f194

void nm_pwd(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  undefined1 auStack_18 [8];
  undefined4 local_10;
  undefined4 local_c;
  
  local_10 = param_1;
  local_c = param_2;
  rq_if508(auStack_18,0x2f,param_3);
  return;
}


// ==== nm_getcom @ 0103f1bc

void nm_getcom(void)

{
  return;
}


// ==== nm_fnid @ 0103f1c4

/* WARNING: Removing unreachable block (ram,0x0103f226) */

void nm_fnid(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  int unaff_D7;
  undefined1 auStack_58 [64];
  undefined1 auStack_18 [8];
  undefined4 local_10;
  undefined4 local_c;
  
  local_10 = param_1;
  local_c = param_2;
  rq_if508(auStack_18,0x30,param_3);
  if (unaff_D7 == -0xfc) {
    nm_getdir(param_1,auStack_58,1,1,0,param_3);
  }
  return;
}


// ==== nm_fcopy @ 0103f252

void nm_fcopy(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  undefined1 auStack_18 [8];
  undefined4 local_10;
  undefined4 local_c;
  undefined4 local_8;
  
  local_10 = param_1;
  local_c = param_2;
  local_8 = param_3;
  rq_if508(auStack_18,0x31,param_4);
  return;
}


// ==== nm_nop @ 0103f280

void nm_nop(void)

{
  return;
}


// ==== rq_if508 @ 0103f28a

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void rq_if508(undefined4 *param_1,undefined4 param_2,uint *param_3)

{
  uint uVar1;
  uint unaff_D7;
  undefined4 local_8;
  
  local_8 = 0;
  *param_1 = param_2;
  param_1[1] = &local_8;
  if ((_DAT_0ff03ff8 == -0xfaf800) && (semsg(0x14,2,param_1), -1 < (int)unaff_D7)) {
    do {
      wait((void *)0x0);
      uVar1 = *param_3 | unaff_D7;
      *param_3 = uVar1;
      unaff_D7 = 0;
    } while ((uVar1 & 0x40000400) == 0);
    *param_3 = *param_3 & 0xbffffbff;
  }
  return;
}


// ==== dirtofnm @ 0103f310

void dirtofnm(ushort param_1,int param_2,int param_3)

{
  undefined1 auStack_8 [4];
  
  if (param_1 == 3) {
LAB_0103f38c:
    rad50toa(*(undefined2 *)(param_2 + 2),param_3);
    rad50toa(*(undefined2 *)(param_2 + 4));
    fill();
    rad50toa(*(undefined2 *)(param_2 + 6),auStack_8);
    cpydata(auStack_8,param_3 + 8,3);
  }
  else {
    if ((3 < param_1) && (param_1 != 0x81)) {
      if (param_1 < 0x82) {
        if (param_1 == 6) {
          cpybuf(param_2,param_3,8);
          cpybuf(param_2 + 8,param_3 + 8,3);
          goto LAB_0103f402;
        }
      }
      else if (param_1 == 0x83) goto LAB_0103f38c;
    }
    cpybuf(param_2,param_3,0xb);
  }
LAB_0103f402:
  isdelfil(param_1,param_2);
  return;
}


// ==== mkdoserr @ 0103f41c

uint mkdoserr(undefined1 param_1,uint param_2)

{
  undefined4 in_D0;
  
  if ((int)param_2 < 0) {
    param_2 = CONCAT31((int3)((uint)in_D0 >> 8),param_1) & 0xffff | param_2 << 0x10;
  }
  return param_2;
}


// ==== dosstt @ 0103f43a

int dosstt(int param_1)

{
  int iVar1;
  
  iVar1 = param_1 >> 0x10;
  if (-1 < param_1) {
    iVar1 = param_1;
  }
  return iVar1;
}


// ==== doserr @ 0103f450

void doserr(void)

{
  return;
}


// ==== errdrive @ 0103f45e

void errdrive(void)

{
  return;
}


// ==== isdelfil @ 0103f46c

undefined4 isdelfil(ushort param_1,ushort *param_2)

{
  if (param_1 == 3) {
LAB_0103f4a0:
    if ((*param_2 & 0x200) == 0) {
      return 0;
    }
  }
  else {
    if (param_1 < 4) {
      if ((param_1 != 1) && (param_1 == 2)) {
        if (*(char *)((int)param_2 + 0xb) < '\0') {
          return 1;
        }
        return 0;
      }
    }
    else if ((param_1 != 0x81) && (param_1 == 0x83)) goto LAB_0103f4a0;
    if (*(char *)((int)param_2 + 7) != '@') {
      return 0;
    }
  }
  return 1;
}


// ==== putfnam @ 0103f4cc

char putfnam(char *param_1,char *param_2)

{
  char cVar1;
  int iVar2;
  char *pcVar3;
  char *pcVar4;
  char *pcVar5;
  
  iVar2 = 0;
  pcVar4 = param_2;
  do {
    pcVar3 = pcVar4;
    pcVar5 = param_1;
    if ((*param_1 == '.') || (*param_1 == '\0')) break;
    pcVar5 = param_1 + 1;
    pcVar3 = pcVar4 + 1;
    *pcVar4 = *param_1;
    iVar2 = iVar2 + 1;
    pcVar4 = pcVar3;
    param_1 = pcVar5;
  } while (iVar2 < 8);
  for (; iVar2 < 8; iVar2 = iVar2 + 1) {
    *pcVar3 = ' ';
    pcVar3 = pcVar3 + 1;
  }
  if (*pcVar5 == '.') {
    pcVar5 = pcVar5 + 1;
  }
  iVar2 = 0;
  pcVar4 = param_2 + 8;
  do {
    cVar1 = *pcVar5;
    pcVar3 = pcVar4;
    if (cVar1 == '\0') break;
    cVar1 = *pcVar5;
    pcVar3 = pcVar4 + 1;
    *pcVar4 = cVar1;
    iVar2 = iVar2 + 1;
    pcVar4 = pcVar3;
    pcVar5 = pcVar5 + 1;
  } while (iVar2 < 3);
  for (; iVar2 < 3; iVar2 = iVar2 + 1) {
    *pcVar3 = ' ';
    pcVar3 = pcVar3 + 1;
  }
  return cVar1;
}


// ==== slvfnam @ 0103f534

void slvfnam(char *param_1,char *param_2)

{
  bool bVar1;
  ushort uVar2;
  char *pcVar3;
  char *pcVar4;
  char *pcVar5;
  
  bVar1 = false;
  uVar2 = 0;
  pcVar5 = param_1;
  do {
    pcVar3 = param_2;
    if (*pcVar5 == ' ') break;
    pcVar3 = param_2 + 1;
    *param_2 = *pcVar5;
    uVar2 = uVar2 + 1;
    param_2 = pcVar3;
    pcVar5 = pcVar5 + 1;
  } while (uVar2 < 8);
  uVar2 = 0;
  pcVar5 = param_1 + 8;
  do {
    if (*pcVar5 == ' ') break;
    pcVar4 = pcVar3;
    if (!bVar1) {
      pcVar4 = pcVar3 + 1;
      *pcVar3 = '.';
      bVar1 = true;
    }
    pcVar3 = pcVar4 + 1;
    *pcVar4 = *pcVar5;
    uVar2 = uVar2 + 1;
    pcVar5 = pcVar5 + 1;
  } while (uVar2 < 3);
  *pcVar3 = '\0';
  return;
}


// ==== undelfnm @ 0103f58c

void undelfnm(int param_1)

{
  int iVar1;
  char *pcVar2;
  
  pcVar2 = (char *)(param_1 + 6);
  iVar1 = 0;
  do {
    pcVar2 = pcVar2 + -1;
    if (*pcVar2 != '_') break;
    *pcVar2 = ' ';
    iVar1 = iVar1 + 1;
  } while (iVar1 < 5);
  *(undefined1 *)(param_1 + 6) = 0x20;
  *(undefined1 *)(param_1 + 7) = 0x20;
  return;
}


// ==== whichdos @ 0103f5c0

undefined4 whichdos(ushort param_1)

{
  undefined4 uVar1;
  
  if ((param_1 < 4) || (5 < param_1)) {
    if ((param_1 < 6) || (7 < param_1)) {
      if ((param_1 < 8) || (9 < param_1)) {
        if ((param_1 < 0xc) || (0xd < param_1)) {
          if (param_1 == 0x10) {
            uVar1 = 4;
          }
          else if (param_1 == 0x11) {
            uVar1 = 5;
          }
          else if (param_1 == 0x12) {
            uVar1 = 6;
          }
          else {
            uVar1 = 1;
          }
        }
        else {
          uVar1 = 0x83;
        }
      }
      else {
        uVar1 = 0x81;
      }
    }
    else {
      uVar1 = 2;
    }
  }
  else {
    uVar1 = 3;
  }
  return uVar1;
}


// ==== cpydata @ 0103f634

void cpydata(undefined1 *param_1,undefined1 *param_2,int param_3)

{
  int iVar1;
  
  iVar1 = 0;
  if (0 < param_3) {
    do {
      *param_2 = *param_1;
      iVar1 = iVar1 + 1;
      param_1 = param_1 + 1;
      param_2 = param_2 + 1;
    } while (iVar1 < param_3);
  }
  return;
}


// ==== cpydataba @ 0103f658

void cpydataba(int param_1,int param_2,int param_3)

{
  int iVar1;
  undefined1 *puVar2;
  undefined1 *puVar3;
  
  puVar3 = (undefined1 *)(param_3 + param_2);
  puVar2 = (undefined1 *)(param_3 + param_1);
  iVar1 = 0;
  if (0 < param_3) {
    do {
      puVar3 = puVar3 + -1;
      puVar2 = puVar2 + -1;
      *puVar3 = *puVar2;
      iVar1 = iVar1 + 1;
    } while (iVar1 < param_3);
  }
  return;
}


// ==== revword @ 0103f688

void revword(void)

{
  return;
}


// ==== revlong @ 0103f6a8

undefined8 revlong(undefined4 param_1)

{
  ushort unaff_D7w;
  
  revword((int)(short)((uint)param_1 >> 8));
  return CONCAT44((uint)unaff_D7w << 8,0x18);
}


// ==== rd_word @ 0103f6ec

undefined1 rd_word(int param_1)

{
  return *(undefined1 *)(param_1 + 1);
}


// ==== wr_word @ 0103f70e

void wr_word(undefined1 *param_1,undefined2 param_2)

{
  *param_1 = (char)((ushort)param_2 >> 8);
  param_1[1] = (char)param_2;
  return;
}


// ==== rad50toa @ 0103f72c

undefined4 rad50toa(ushort param_1,char *param_2)

{
  char cVar1;
  undefined3 uVar2;
  undefined4 uVar3;
  char cVar4;
  char local_8 [4];
  
  local_8[0] = (char)((param_1 / 0x28) / 0x28);
  local_8[1] = (char)((param_1 / 0x28) % 0x28);
  local_8[2] = (char)(param_1 % 0x28);
  cVar4 = '\0';
  do {
    uVar2 = (undefined3)((uint)(int)cVar4 >> 8);
    uVar3 = CONCAT31(uVar2,local_8[cVar4]);
    if (local_8[cVar4] == '\0') {
      *param_2 = ' ';
    }
    else if ((local_8[cVar4] < '\x01') || ('\x1a' < local_8[cVar4])) {
      uVar3 = CONCAT31((int3)((uint)(int)cVar4 >> 8),local_8[cVar4]);
      if (local_8[cVar4] == '\x1b') {
        *param_2 = '$';
      }
      else {
        uVar2 = (undefined3)((uint)(int)cVar4 >> 8);
        uVar3 = CONCAT31(uVar2,local_8[cVar4]);
        if (local_8[cVar4] == '\x1c') {
          *param_2 = '.';
        }
        else {
          cVar1 = local_8[cVar4];
          if ((cVar1 < '\x1e') || (cVar1 = local_8[cVar4], '\'' < cVar1)) {
            uVar3 = CONCAT31(uVar2,cVar1);
            *param_2 = '\x1d';
          }
          else {
            uVar3 = CONCAT31(uVar2,local_8[cVar4] + '\x12');
            *param_2 = local_8[cVar4] + '\x12';
          }
        }
      }
    }
    else {
      uVar3 = CONCAT31(uVar2,local_8[cVar4] + '@');
      *param_2 = local_8[cVar4] + '@';
    }
    param_2 = param_2 + 1;
    cVar4 = cVar4 + '\x01';
  } while (cVar4 < '\x03');
  *param_2 = '\0';
  return uVar3;
}


// ==== mkmask @ 0103f80c

uint mkmask(int param_1,int param_2)

{
  uint uVar1;
  int iVar2;
  
  iVar2 = 0;
  uVar1 = 0;
  if ((param_1 != 0) && (param_1 != param_2)) {
    uVar1 = param_1 % 0x20;
    if (uVar1 != 0) {
      iVar2 = 1 << (uVar1 & 0x3f);
    }
    uVar1 = iVar2 - 1U ^ (1 << (param_2 % (int)uVar1 & 0x3fU)) - 1U;
  }
  return uVar1;
}


// ==== zap_ptr @ 0103f858

void zap_ptr(int *param_1,code *param_2)

{
  if ((param_1 != (int *)0x0) && (*param_1 != 0)) {
    if (param_2 != (code *)0x0) {
      (*param_2)(*param_1);
    }
    *param_1 = 0;
  }
  return;
}


// ==== ini_vids @ 0103f880

byte ini_vids(void)

{
  byte unaff_D7b;
  
  devtrp(6,0,0,0);
  Flvids = unaff_D7b & 7;
  return unaff_D7b & 7;
}


// ==== sprintf @ 0103f8a8

int sprintf(char *__s,char *__format,...)

{
  int iVar1;
  undefined4 uStack0000000c;
  
  iVar1 = _sprintf(__s,__format,&uStack0000000c);
  return iVar1;
}


// ==== _sprintf @ 0103f8c2

void _sprintf(byte *param_1,byte *param_2,int *param_3)

{
  uint uVar1;
  byte bVar2;
  uint uVar3;
  uint uVar4;
  uint unaff_D7;
  byte *pbVar5;
  byte *pbVar6;
  int *piVar7;
  bool bVar8;
  bool bVar9;
  byte local_5d;
  byte *local_58;
  byte local_54 [80];
  
  bVar2 = *param_2;
  piVar7 = param_3;
  pbVar5 = param_2;
  do {
    if (bVar2 == 0) {
      *param_1 = 0;
      return;
    }
    param_2 = pbVar5 + 1;
    if (bVar2 != 0x25) {
      pbVar6 = param_1 + 1;
      *param_1 = bVar2;
      if (bVar2 == 0x11) {
        *pbVar6 = *param_2;
        pbVar6 = param_1 + 3;
        param_1[2] = pbVar5[2];
        param_2 = pbVar5 + 3;
      }
      goto LAB_0103fad4;
    }
    local_58 = local_54;
    bVar8 = *param_2 == 0x2d;
    if (bVar8) {
      param_2 = pbVar5 + 2;
    }
    local_5d = 0x20;
    if (*param_2 == 0x30) {
      param_2 = param_2 + 1;
      local_5d = 0x30;
    }
    _gv2(&param_2);
    uVar3 = unaff_D7;
    if (unaff_D7 == 0) {
      uVar3 = 1;
    }
    bVar2 = *param_2;
    param_2 = param_2 + 1;
    bVar9 = bVar2 == 0x2e;
    uVar4 = 6;
    if (bVar9) {
      _gv2(&param_2);
      bVar2 = *param_2;
      param_2 = param_2 + 1;
      uVar4 = unaff_D7;
    }
    if ((bVar2 < 0x61) || (0x7a < bVar2)) {
      uVar1 = (uint)bVar2;
    }
    else {
      uVar1 = bVar2 - 0x20;
    }
    switch(uVar1) {
    case 0x43:
      *local_58 = (byte)*piVar7;
      local_58 = local_58 + 1;
      uVar3 = uVar3 - 1;
      break;
    case 0x44:
      if (*piVar7 < 0) {
        *local_58 = 0x2d;
        local_58 = local_58 + 1;
        *piVar7 = -*piVar7;
        uVar3 = uVar3 - 1;
      }
    case 0x55:
      _uspr(&local_58,*piVar7,10);
      uVar3 = uVar3 - (unaff_D7 & 0xff);
      break;
    default:
      pbVar6 = param_1 + 1;
      *param_1 = bVar2;
      goto LAB_0103fad4;
    case 0x4f:
      _uspr8(&local_58,*piVar7);
      goto LAB_0103fa1e;
    case 0x53:
      if (!bVar9) {
        uVar4 = 200;
      }
      pbVar5 = (byte *)*piVar7;
      for (; (*pbVar5 != 0 && (uVar4 != 0)); uVar4 = uVar4 - 1) {
        *local_58 = *pbVar5;
        local_58 = local_58 + 1;
        uVar3 = uVar3 - 1;
        pbVar5 = pbVar5 + 1;
      }
      break;
    case 0x58:
      _uspr16(&local_58,*piVar7);
LAB_0103fa1e:
      uVar3 = uVar3 - (unaff_D7 & 0xff);
    }
    piVar7 = piVar7 + 1;
    *local_58 = 0;
    local_58 = local_54;
    uVar4 = uVar3;
    pbVar6 = param_1;
    if (!bVar8) {
      while (uVar4 = uVar3 - 1, pbVar6 = param_1, 0 < (int)uVar3) {
        *param_1 = local_5d;
        uVar3 = uVar4;
        param_1 = param_1 + 1;
      }
    }
    while( true ) {
      bVar2 = *local_58;
      *pbVar6 = bVar2;
      local_58 = local_58 + 1;
      if (bVar2 == 0) break;
      pbVar6 = pbVar6 + 1;
    }
    if (bVar8) {
      for (; 0 < (int)uVar4; uVar4 = uVar4 - 1) {
        *pbVar6 = local_5d;
        pbVar6 = pbVar6 + 1;
      }
    }
LAB_0103fad4:
    bVar2 = *param_2;
    param_1 = pbVar6;
    pbVar5 = param_2;
  } while( true );
}


// ==== _gv2 @ 0103faf2

void _gv2(int *param_1)

{
  byte bVar1;
  
  bVar1 = *(byte *)*param_1;
  while ((0x2f < bVar1 && (*(byte *)*param_1 < 0x3a))) {
    *param_1 = *param_1 + 1;
    bVar1 = *(byte *)*param_1;
  }
  return;
}


// ==== _uspr @ 0103fb3a

void _uspr(int *param_1,uint param_2,uint param_3)

{
  char *pcVar1;
  char cVar2;
  
  if (param_2 < param_3) {
    pcVar1 = (char *)*param_1;
    *param_1 = *param_1 + 1;
    if (param_2 < 10) {
      cVar2 = (char)param_2 + '0';
    }
    else {
      cVar2 = (char)param_2 + '7';
    }
    *pcVar1 = cVar2;
  }
  else {
    _uspr(param_1,param_2 / param_3,param_3);
    _uspr(param_1,param_2 % param_3,param_3);
  }
  return;
}


// ==== _uspr16 @ 0103fba4

void _uspr16(int *param_1,uint param_2)

{
  char *pcVar1;
  char cVar2;
  
  if (param_2 < 0x10) {
    pcVar1 = (char *)*param_1;
    *param_1 = *param_1 + 1;
    if (param_2 < 10) {
      cVar2 = (char)param_2 + '0';
    }
    else {
      cVar2 = (char)param_2 + '7';
    }
    *pcVar1 = cVar2;
  }
  else {
    _uspr16(param_1,param_2 >> 4);
    _uspr16(param_1,param_2 & 0xf);
  }
  return;
}


// ==== _uspr8 @ 0103fc06

void _uspr8(int *param_1,uint param_2)

{
  char *pcVar1;
  char cVar2;
  
  if (param_2 < 8) {
    pcVar1 = (char *)*param_1;
    *param_1 = *param_1 + 1;
    if (param_2 < 10) {
      cVar2 = (char)param_2 + '0';
    }
    else {
      cVar2 = (char)param_2 + '7';
    }
    *pcVar1 = cVar2;
  }
  else {
    _uspr8(param_1,param_2 >> 3);
    _uspr8(param_1,param_2 & 7);
  }
  return;
}


// ==== cpybuf @ 0103fc68

uint cpybuf(uint *param_1,uint *param_2,int param_3)

{
  uint uVar1;
  ushort uVar2;
  short sVar3;
  uint *puVar4;
  uint *puVar5;
  uint *puVar6;
  uint *puVar7;
  
  if (param_3 == 0) {
    if (*(char *)param_1 == '\0') {
      return 0;
    }
    do {
      puVar4 = (uint *)((int)param_1 + 1);
      *(undefined1 *)param_2 = *(undefined1 *)param_1;
      param_1 = puVar4;
      param_2 = (uint *)((int)param_2 + 1);
    } while (*(char *)puVar4 != '\0');
    return 0;
  }
  uVar1 = (uint)param_2 & 3 | ((uint)param_1 & 3) << 4;
  puVar4 = param_1;
  puVar6 = param_2;
  switch(uVar1) {
  case 0:
    for (; 0x1f < param_3; param_3 = param_3 + -0x20) {
      *param_2 = *param_1;
      param_2[1] = param_1[1];
      param_2[2] = param_1[2];
      param_2[3] = param_1[3];
      param_2[4] = param_1[4];
      param_2[5] = param_1[5];
      param_2[6] = param_1[6];
      param_2[7] = param_1[7];
      param_2 = param_2 + 8;
      param_1 = param_1 + 8;
    }
    for (; 0xf < param_3; param_3 = param_3 + -0x10) {
      *param_2 = *param_1;
      param_2[1] = param_1[1];
      param_2[2] = param_1[2];
      param_2[3] = param_1[3];
      param_2 = param_2 + 4;
      param_1 = param_1 + 4;
    }
    for (; 3 < param_3; param_3 = param_3 + -4) {
      uVar1 = *param_1;
      *param_2 = uVar1;
      param_1 = param_1 + 1;
      param_2 = param_2 + 1;
    }
    if ((param_3 != 0) && (param_3 = param_3 + -1, param_3 != -1)) {
      do {
        do {
          puVar4 = (uint *)((int)param_1 + 1);
          uVar1 = (uint)*(byte *)param_1;
          puVar6 = (uint *)((int)param_2 + 1);
          *(byte *)param_2 = *(byte *)param_1;
          uVar2 = (ushort)((uint)param_3 >> 0x10);
          sVar3 = (short)param_3 + -1;
          param_3 = CONCAT22(uVar2,sVar3);
          param_1 = puVar4;
          param_2 = puVar6;
        } while (sVar3 != -1);
        param_3 = (uint)uVar2 * 0x10000 + -1;
      } while (uVar2 != 0);
    }
    break;
  case 1:
  case 3:
  case 0x10:
  case 0x12:
  case 0x21:
  case 0x23:
  case 0x30:
  case 0x32:
    param_3 = param_3 + -1;
    if (param_3 != -1) {
      do {
        do {
          puVar4 = (uint *)((int)param_1 + 1);
          uVar1 = (uint)*(byte *)param_1;
          puVar6 = (uint *)((int)param_2 + 1);
          *(byte *)param_2 = *(byte *)param_1;
          uVar2 = (ushort)((uint)param_3 >> 0x10);
          sVar3 = (short)param_3 + -1;
          param_3 = CONCAT22(uVar2,sVar3);
          param_1 = puVar4;
          param_2 = puVar6;
        } while (sVar3 != -1);
        param_3 = (uint)uVar2 * 0x10000 + -1;
      } while (uVar2 != 0);
    }
    break;
  case 2:
  case 0x20:
  case 0x22:
    for (; 0xf < param_3; param_3 = param_3 + -0x10) {
      *(ushort *)puVar6 = *(ushort *)puVar4;
      *(ushort *)((int)puVar6 + 2) = (ushort)*puVar4;
      *(ushort *)(puVar6 + 1) = *(ushort *)(puVar4 + 1);
      *(ushort *)((int)puVar6 + 6) = *(ushort *)((int)puVar4 + 6);
      *(ushort *)(puVar6 + 2) = *(ushort *)(puVar4 + 2);
      *(ushort *)((int)puVar6 + 10) = *(ushort *)((int)puVar4 + 10);
      *(ushort *)(puVar6 + 3) = *(ushort *)(puVar4 + 3);
      *(ushort *)((int)puVar6 + 0xe) = *(ushort *)((int)puVar4 + 0xe);
      puVar6 = puVar6 + 4;
      puVar4 = puVar4 + 4;
    }
    for (; 7 < param_3; param_3 = param_3 + -8) {
      *(ushort *)puVar6 = *(ushort *)puVar4;
      *(ushort *)((int)puVar6 + 2) = (ushort)*puVar4;
      *(ushort *)(puVar6 + 1) = *(ushort *)(puVar4 + 1);
      *(ushort *)((int)puVar6 + 6) = *(ushort *)((int)puVar4 + 6);
      puVar6 = puVar6 + 2;
      puVar4 = puVar4 + 2;
    }
    for (; 1 < param_3; param_3 = param_3 + -2) {
      uVar1 = (uint)*(ushort *)puVar4;
      *(ushort *)puVar6 = *(ushort *)puVar4;
      puVar4 = (uint *)((int)puVar4 + 2);
      puVar6 = (uint *)((int)puVar6 + 2);
    }
    goto LAB_0103feaa;
  case 0x11:
  case 0x13:
  case 0x31:
    puVar4 = (uint *)((int)param_1 + 1);
    uVar1 = (uint)*(byte *)param_1;
    puVar6 = (uint *)((int)param_2 + 1);
    *(byte *)param_2 = *(byte *)param_1;
    for (param_3 = param_3 + -1; 0xf < param_3; param_3 = param_3 + -0x10) {
      *(ushort *)puVar6 = *(ushort *)puVar4;
      *(ushort *)((int)puVar6 + 2) = (ushort)*puVar4;
      *(ushort *)(puVar6 + 1) = *(ushort *)(puVar4 + 1);
      *(ushort *)((int)puVar6 + 6) = *(ushort *)((int)puVar4 + 6);
      *(ushort *)(puVar6 + 2) = *(ushort *)(puVar4 + 2);
      *(ushort *)((int)puVar6 + 10) = *(ushort *)((int)puVar4 + 10);
      *(ushort *)(puVar6 + 3) = *(ushort *)(puVar4 + 3);
      *(ushort *)((int)puVar6 + 0xe) = *(ushort *)((int)puVar4 + 0xe);
      puVar6 = puVar6 + 4;
      puVar4 = puVar4 + 4;
    }
    for (; 7 < param_3; param_3 = param_3 + -8) {
      *(ushort *)puVar6 = *(ushort *)puVar4;
      *(ushort *)((int)puVar6 + 2) = (ushort)*puVar4;
      *(ushort *)(puVar6 + 1) = *(ushort *)(puVar4 + 1);
      *(ushort *)((int)puVar6 + 6) = *(ushort *)((int)puVar4 + 6);
      puVar6 = puVar6 + 2;
      puVar4 = puVar4 + 2;
    }
    for (; 1 < param_3; param_3 = param_3 + -2) {
      uVar1 = (uint)*(ushort *)puVar4;
      *(ushort *)puVar6 = *(ushort *)puVar4;
      puVar4 = (uint *)((int)puVar4 + 2);
      puVar6 = (uint *)((int)puVar6 + 2);
    }
LAB_0103feaa:
    if (param_3 != 0) {
      uVar1 = (uint)*(byte *)puVar4;
      *(byte *)puVar6 = *(byte *)puVar4;
    }
    break;
  case 0x33:
    puVar4 = (uint *)((int)param_1 + 1);
    uVar1 = (uint)*(byte *)param_1;
    puVar6 = (uint *)((int)param_2 + 1);
    *(byte *)param_2 = *(byte *)param_1;
    for (param_3 = param_3 + -1; 0x1f < param_3; param_3 = param_3 + -0x20) {
      *puVar6 = *puVar4;
      puVar6[1] = puVar4[1];
      puVar6[2] = puVar4[2];
      puVar6[3] = puVar4[3];
      puVar6[4] = puVar4[4];
      puVar6[5] = puVar4[5];
      puVar6[6] = puVar4[6];
      puVar6[7] = puVar4[7];
      puVar6 = puVar6 + 8;
      puVar4 = puVar4 + 8;
    }
    for (; 0xf < param_3; param_3 = param_3 + -0x10) {
      *puVar6 = *puVar4;
      puVar6[1] = puVar4[1];
      puVar6[2] = puVar4[2];
      puVar6[3] = puVar4[3];
      puVar6 = puVar6 + 4;
      puVar4 = puVar4 + 4;
    }
    for (; 3 < param_3; param_3 = param_3 + -4) {
      uVar1 = *puVar4;
      *puVar6 = uVar1;
      puVar4 = puVar4 + 1;
      puVar6 = puVar6 + 1;
    }
    if ((param_3 != 0) && (param_3 = param_3 + -1, param_3 != -1)) {
      do {
        do {
          puVar5 = (uint *)((int)puVar4 + 1);
          uVar1 = (uint)*(byte *)puVar4;
          puVar7 = (uint *)((int)puVar6 + 1);
          *(byte *)puVar6 = *(byte *)puVar4;
          uVar2 = (ushort)((uint)param_3 >> 0x10);
          sVar3 = (short)param_3 + -1;
          param_3 = CONCAT22(uVar2,sVar3);
          puVar4 = puVar5;
          puVar6 = puVar7;
        } while (sVar3 != -1);
        param_3 = (uint)uVar2 * 0x10000 + -1;
      } while (uVar2 != 0);
    }
  }
  return uVar1;
}


// ==== fill @ 0103ff54

uint fill(uint *param_1,int param_2,undefined1 param_3)

{
  uint uVar1;
  
  uVar1 = (uint)param_1 & 3;
  if (uVar1 != 0) {
    for (; (param_2 != 0 && (uVar1 = (uint)param_1 & 3, uVar1 != 0));
        param_1 = (uint *)((int)param_1 + 1)) {
      *(undefined1 *)param_1 = param_3;
      param_2 = param_2 + -1;
    }
  }
  if (3 < param_2) {
    uVar1 = CONCAT13(param_3,CONCAT12(param_3,CONCAT11(param_3,param_3)));
    for (; 0x1f < param_2; param_2 = param_2 + -0x20) {
      *param_1 = uVar1;
      param_1[1] = uVar1;
      param_1[2] = uVar1;
      param_1[3] = uVar1;
      param_1[4] = uVar1;
      param_1[5] = uVar1;
      param_1[6] = uVar1;
      param_1[7] = uVar1;
      param_1 = param_1 + 8;
    }
    for (; 0xf < param_2; param_2 = param_2 + -0x10) {
      *param_1 = uVar1;
      param_1[1] = uVar1;
      param_1[2] = uVar1;
      param_1[3] = uVar1;
      param_1 = param_1 + 4;
    }
    for (; 3 < param_2; param_2 = param_2 + -4) {
      *param_1 = uVar1;
      param_1 = param_1 + 1;
    }
  }
  for (; param_2 != 0; param_2 = param_2 + -1) {
    *(undefined1 *)param_1 = param_3;
    param_1 = (uint *)((int)param_1 + 1);
  }
  return uVar1;
}


// ==== cpyast @ 01040010

void cpyast(char *param_1,char *param_2)

{
  char cVar1;
  
  do {
    cVar1 = *param_1;
    *param_2 = cVar1;
    param_2 = param_2 + 1;
    param_1 = param_1 + 1;
  } while (cVar1 != '\0');
  return;
}


// ==== cmpbuf @ 01040030

void cmpbuf(char *param_1,char *param_2,int param_3)

{
  while( true ) {
    if (param_3 == 0) {
      return;
    }
    if (*param_2 != *param_1) break;
    param_3 = param_3 + -1;
    param_1 = param_1 + 1;
    param_2 = param_2 + 1;
  }
  return;
}


// ==== cmpstr @ 01040058

char cmpstr(char *param_1,char *param_2)

{
  char cVar1;
  char cVar2;
  
  do {
    if (*param_1 == '\0') {
      return '\0';
    }
    cVar1 = *param_2;
    cVar2 = *param_1;
    param_1 = param_1 + 1;
    param_2 = param_2 + 1;
  } while (cVar1 == cVar2);
  return cVar1;
}


// ==== atoi @ 0104007c

int atoi(char *__nptr)

{
  byte bVar1;
  uint3 uVar2;
  undefined3 uVar3;
  int in_D0;
  int iVar4;
  
  for (; (uVar2 = (uint3)((uint)in_D0 >> 8), *__nptr == 9 || (*__nptr == 0x20)); __nptr = __nptr + 1
      ) {
    in_D0 = (uint)uVar2 << 8;
  }
  if (*__nptr == 0x2d) {
    __nptr = __nptr + 1;
  }
  bVar1 = *__nptr;
  iVar4 = CONCAT31(uVar2,bVar1);
  while( true ) {
    if (bVar1 < 0x30) {
      return iVar4;
    }
    uVar3 = (undefined3)((uint)iVar4 >> 8);
    if (0x39 < (byte)*__nptr) break;
    __nptr = __nptr + 1;
    bVar1 = *__nptr;
    iVar4 = CONCAT31(uVar3,bVar1);
  }
  return CONCAT31(uVar3,*__nptr);
}


// ==== bitneg @ 010400dc

byte bitneg(byte param_1)

{
  byte bVar1;
  short sVar2;
  byte bVar3;
  
  bVar3 = 0x80;
  sVar2 = 8;
  do {
    bVar1 = bVar3 & param_1;
    sVar2 = sVar2 + -1;
    bVar3 = bVar3 >> 1;
  } while (sVar2 != 0);
  return bVar1;
}


// ==== strcat @ 01040114

char * strcat(char *__dest,char *__src)

{
  char cVar1;
  char *in_D0;
  
  for (; in_D0 = (char *)((uint)in_D0 & 0xffffff00), *__dest != '\0'; __dest = __dest + 1) {
  }
  do {
    cVar1 = *__src;
    in_D0 = (char *)CONCAT31((int3)((uint)in_D0 >> 8),cVar1);
    *__dest = cVar1;
    __dest = __dest + 1;
    __src = __src + 1;
  } while (cVar1 != '\0');
  return in_D0;
}


// ==== strcpy @ 01040138

char * strcpy(char *__dest,char *__src)

{
  char cVar1;
  char *in_D0;
  
  do {
    cVar1 = *__src;
    in_D0 = (char *)CONCAT31((int3)((uint)in_D0 >> 8),cVar1);
    *__dest = cVar1;
    __dest = __dest + 1;
    __src = __src + 1;
  } while (cVar1 != '\0');
  return in_D0;
}


// ==== strcmp @ 01040154

int strcmp(char *__s1,char *__s2)

{
  int in_D0;
  
  while( true ) {
    if (*__s2 != *__s1) {
      return (uint)(byte)*__s2;
    }
    in_D0 = CONCAT31((int3)((uint)in_D0 >> 8),*__s1);
    if (*__s1 == 0) break;
    __s1 = __s1 + 1;
    __s2 = __s2 + 1;
  }
  return in_D0;
}


// ==== strlen @ 01040188

size_t strlen(char *__s)

{
  char cVar1;
  size_t in_D0;
  
  do {
    cVar1 = *__s;
    in_D0 = CONCAT31((int3)(in_D0 >> 8),cVar1);
    __s = __s + 1;
  } while (cVar1 != '\0');
  return in_D0;
}


// ==== abort @ 010401a0

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void abort(void)

{
  com1();
  return;
}


// ==== alarm @ 010401a8

uint alarm(uint __seconds)

{
  uint uVar1;
  
  uVar1 = com1();
  return uVar1;
}


// ==== can_alrm @ 010401b0

void can_alrm(void)

{
  com1();
  return;
}


// ==== clrecb @ 010401b8

void clrecb(void)

{
  com1();
  return;
}


// ==== crdcb @ 010401c0

void crdcb(void)

{
  com1();
  return;
}


// ==== crpcb @ 010401c8

void crpcb(void)

{
  com1();
  return;
}


// ==== crtask @ 010401d0

void crtask(void)

{
  com1();
  return;
}


// ==== delpcb @ 010401d8

void delpcb(void)

{
  com1();
  return;
}


// ==== dsemsg @ 010401e0

void dsemsg(void)

{
  com1();
  return;
}


// ==== getpar @ 010401e8

void getpar(void)

{
  com1();
  return;
}


// ==== ggtim @ 010401f0

void ggtim(void)

{
  com1();
  return;
}


// ==== gtcb @ 010401f8

void gtcb(void)

{
  com1();
  return;
}


// ==== iodone @ 01040200

void iodone(void)

{
  com1();
  return;
}


// ==== itrpvct @ 01040208

void itrpvct(void)

{
  com1();
  return;
}


// ==== post @ 01040210

void post(void)

{
  com1();
  return;
}


// ==== redwat @ 01040218

void redwat(void)

{
  com1();
  return;
}


// ==== remsg @ 01040220

void remsg(void)

{
  com1();
  return;
}


// ==== sbpeek @ 01040228

void sbpeek(void)

{
  com1();
  return;
}


// ==== semsg @ 01040230

void semsg(void)

{
  com1();
  return;
}


// ==== timset @ 01040238

void timset(void)

{
  com1();
  return;
}


// ==== wait @ 01040240

__pid_t wait(void *__stat_loc)

{
  __pid_t _Var1;
  
  _Var1 = com1();
  return _Var1;
}


// ==== wtmsg @ 01040248

void wtmsg(void)

{
  com1();
  return;
}


// ==== devtrp @ 01040250

void devtrp(void)

{
  com2();
  return;
}


// ==== latopa @ 01040258

void latopa(void)

{
  com2();
  return;
}


// ==== dremsg @ 01040260

void dremsg(void)

{
  com2();
  return;
}


// ==== dioreq @ 01040268

void dioreq(void)

{
  com2();
  return;
}


// ==== irqvct @ 01040270

void irqvct(void)

{
  com2();
  return;
}


// ==== timer @ 01040278

undefined4 timer(void)

{
  __m68k_trap(3);
  return 0;
}


// ==== can_time @ 01040280

undefined4 can_time(void)

{
  __m68k_trap(3);
  return 1;
}


// ==== com1 @ 01040288

void com1(void)

{
  __m68k_trap(1);
  return;
}


// ==== com2 @ 01040290

void com2(void)

{
  __m68k_trap(2);
  return;
}


// ==== trapv @ 01040298

void trapv(void)

{
  __m68k_trapv();
  return;
}


// ==== ivaridc @ 010411d6

void ivaridc(short param_1)

{
  int iVar1;
  
  iVar1 = *(int *)((int)&PTR_DAT_010103c4 + (uint)(ushort)((param_1 + -0xc0) * 4));
  *(undefined2 *)(iVar1 + 0x60) = 0;
  *(undefined2 *)(iVar1 + 0x62) = 0;
  *(undefined2 *)(iVar1 + 100) = 0;
  return;
}


