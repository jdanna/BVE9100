// ==== FUN_0103002a @ 0103002a

void FUN_0103002a(int param_1)

{
  int iVar1;
  int iVar2;
  
  for (iVar2 = 0; iVar2 < param_1; iVar2 = iVar2 + 1) {
    for (iVar1 = 0; iVar1 < 0x1ec; iVar1 = iVar1 + 1) {
    }
  }
  return;
}


// ==== FUN_0103007e @ 0103007e

void FUN_0103007e(void)

{
  FUN_0105ef12();
  return;
}


// ==== FUN_010300da @ 010300da

void FUN_010300da(void)

{
  short unaff_D7w;
  
  do {
    FUN_0103fffc();
    if (unaff_D7w == -1) {
      return;
    }
  } while (unaff_D7w != 0x20);
  return;
}


// ==== FUN_0103010c @ 0103010c

void FUN_0103010c(void)

{
  short unaff_D7w;
  
  while( true ) {
    FUN_0103fffc();
    if (unaff_D7w == -1) {
      return;
    }
    if (unaff_D7w == 0x20) break;
    if (unaff_D7w == 10) {
      return;
    }
  }
  return;
}


// ==== FUN_01030156 @ 01030156

void FUN_01030156(void)

{
  short unaff_D7w;
  
  do {
    FUN_0103fffc();
    if (unaff_D7w == -1) {
      return;
    }
    if (unaff_D7w == 0x20) {
      return;
    }
    if (unaff_D7w == 10) {
      return;
    }
  } while (unaff_D7w != 0xca);
  return;
}


// ==== FUN_010301b4 @ 010301b4

void FUN_010301b4(void)

{
  int iVar1;
  undefined1 *puVar2;
  
  puVar2 = &DAT_0103da76;
  for (iVar1 = 0; iVar1 < 0x50; iVar1 = iVar1 + 1) {
    *puVar2 = 0x20;
    puVar2 = puVar2 + 1;
  }
  *puVar2 = 0;
  puVar2[1] = 0;
  return;
}


// ==== FUN_010301f6 @ 010301f6

void FUN_010301f6(int param_1,int param_2,int param_3)

{
  int *piVar1;
  int local_8;
  
  local_8 = param_2;
  if (param_1 == 1) {
    piVar1 = &DAT_0103da6e;
  }
  else {
    if (param_1 != 2) {
      return;
    }
    piVar1 = &DAT_0103da5a;
  }
  do {
    if (local_8 == 0) {
      return;
    }
    while (*piVar1 == 0) {
      if (param_3 == 1) {
        FUN_0103010c();
        FUN_0105ef12();
        return;
      }
    }
    *piVar1 = 0;
    local_8 = local_8 + -1;
  } while( true );
}


// ==== FUN_01030266 @ 01030266

void FUN_01030266(char param_1,char param_2)

{
  byte local_5;
  
  if (param_1 == '\0') {
    local_5 = DAT_0f004001;
  }
  else {
    local_5 = DAT_0f003001;
  }
  if (((int)param_2 & (uint)local_5) == (int)param_2) {
    return;
  }
  return;
}


// ==== FUN_010302b2 @ 010302b2

void FUN_010302b2(char param_1,undefined4 param_2)

{
  int unaff_D7;
  
  if (param_1 == '\0') {
    DAT_0f003001 = DAT_0f003001 | 8;
    DAT_0103da6e = 0;
    DAT_0103da66 = 0;
    DAT_0103da6a = 0;
    DAT_0103da62 = 0;
    return;
  }
  FUN_01030266(1,8);
  if (unaff_D7 == 0x12d) {
    return;
  }
  FUN_010303e8();
  DAT_0103da72 = param_2;
  DAT_0103da6a = 0;
  DAT_0103da6e = 0;
  DAT_0103da62 = 0;
  DAT_0103da66 = 0;
  DAT_0f003001 = DAT_0f003001 & 0xf7;
  return;
}


// ==== FUN_01030352 @ 01030352

void FUN_01030352(char param_1,undefined4 param_2)

{
  int unaff_D7;
  
  if (param_1 == '\0') {
    DAT_0f003001 = DAT_0f003001 | 2;
    DAT_0103da5a = 0;
  }
  else {
    FUN_01030266(1,2,0x136);
    if (unaff_D7 != 0x12d) {
      FUN_01032a52(0,0,0x34,20000);
      FUN_0103040c();
      DAT_0103da5e = param_2;
      DAT_0103da56 = 0;
      DAT_0103da5a = 0;
      DAT_0f003001 = DAT_0f003001 & 0xfd;
    }
  }
  return;
}


// ==== FUN_010303e8 @ 010303e8

void FUN_010303e8(void)

{
  DAT_0f003001 = DAT_0f003001 | 0x80;
  *(undefined1 **)(DAT_01092c58 + 0x16c) = &LAB_0103070c;
  return;
}


// ==== FUN_0103040c @ 0103040c

void FUN_0103040c(void)

{
  DAT_0f003001 = DAT_0f003001 | 2;
  *(undefined1 **)(DAT_01092c58 + 0x164) = &LAB_01030726;
  return;
}


// ==== FUN_01030430 @ 01030430

void FUN_01030430(void)

{
  DAT_0103da6a = DAT_0103da6a + 1;
  DAT_0103da62 = DAT_0103da62 + 1;
  if (DAT_0103da72 <= DAT_0103da6a) {
    DAT_0103da6a = 0;
    DAT_0103da6e = 1;
  }
  if (DAT_0103da72 <= DAT_0103da62) {
    DAT_0103da62 = 0;
    DAT_0103da66 = DAT_0103da66 + 1;
  }
  return;
}


// ==== FUN_01030474 @ 01030474

void FUN_01030474(void)

{
  DAT_0103da56 = DAT_0103da56 + 1;
  if (DAT_0103da5e <= DAT_0103da56) {
    DAT_0103da56 = 0;
    DAT_0103da5a = 1;
  }
  return;
}


// ==== FUN_01030498 @ 01030498

void FUN_01030498(void)

{
  int unaff_D7;
  undefined1 auStack_a [5];
  undefined1 local_5;
  
  FUN_01030352(1,1);
  FUN_010378ac(auStack_a,&local_5);
  if (unaff_D7 == 0x136) {
    FUN_01030352(0,1);
  }
  return;
}


// ==== FUN_010304de @ 010304de

void FUN_010304de(void)

{
  char cVar1;
  undefined1 *local_a;
  
  cVar1 = DAT_0f00b002;
  FUN_01034dd6(DAT_0f00b002);
  FUN_01035538();
  if (cVar1 == '\0') {
    local_a = &DAT_0ff01ff7;
  }
  else {
    if ((DAT_0ff01fd7 & 0xf0) == 0x10) {
      FUN_0103058e();
      return;
    }
    if ((DAT_0ff01fd7 & 0xf0) == 0x30) {
      FUN_0103058e();
      return;
    }
    local_a = (undefined1 *)0xff01e09;
  }
  FUN_01035646(local_a);
  FUN_01035672();
  return;
}


// ==== FUN_0103058e @ 0103058e

void FUN_0103058e(void)

{
  if ((DAT_0ff01fd7 & 3) == 1) {
    DAT_0ff01fd3 = 8;
  }
  else if ((DAT_0ff01fd7 & 3) == 2) {
    DAT_0ff01fd3 = 0;
  }
  else {
    DAT_0ff01fd3 = 0;
  }
  return;
}


// ==== FUN_010305d4 @ 010305d4

undefined8 FUN_010305d4(void)

{
  undefined4 in_D0;
  undefined4 in_D1;
  
  FUN_01032e3a();
  DAT_0f003000 = 0x20;
  return CONCAT44(in_D0,in_D1);
}


// ==== FUN_010307fa @ 010307fa

void FUN_010307fa(uint param_1,char param_2)

{
  byte local_9;
  
  if (param_1 == 0) {
    return;
  }
  if ((param_1 & 0x7c000000) == 0) {
    if (param_2 == '\0') {
      if ((param_1 & 0x48989) != 0) {
        for (local_9 = 0; local_9 < 0x20; local_9 = local_9 + 1) {
          if ((param_1 & 1 << (local_9 & 0x3f)) != 0) {
            FUN_0105ef12();
            return;
          }
        }
      }
    }
    else if ((param_1 & 0x4c9c9) != 0) {
      for (local_9 = 0; local_9 < 0x20; local_9 = local_9 + 1) {
        if ((param_1 & 1 << (local_9 & 0x3f)) != 0) {
          FUN_0105ef12();
          return;
        }
      }
    }
  }
  return;
}


// ==== FUN_0103092c @ 0103092c

/* WARNING: Removing unreachable block (ram,0x01030990) */

void FUN_0103092c(void)

{
  int unaff_D7;
  undefined1 auStack_22 [22];
  undefined4 local_c;
  
  local_c = 1;
  FUN_010309b8(auStack_22);
  FUN_010300da();
  if (unaff_D7 == 1) {
    local_c = 0;
    FUN_010310f6(3,auStack_22);
    return;
  }
  FUN_01030a66(auStack_22);
  FUN_0105ef12();
  return;
}


// ==== FUN_010309b8 @ 010309b8

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_010309b8(undefined2 *param_1)

{
  int local_c;
  
  *param_1 = _DAT_00000400;
  FUN_010301b4();
  for (local_c = 0; local_c < 0x10; local_c = local_c + 1) {
    (&DAT_0103da76)[local_c] = "EPROM Version = "[local_c];
  }
  DAT_0103da86 = 0x56;
  FUN_0105ee14(0,*(undefined1 *)param_1,2,&DAT_0103da87);
  DAT_0103da89 = 0x2e;
  FUN_0105ee14(0,*(undefined1 *)((int)param_1 + 1),2,&DAT_0103da8a);
  FUN_01058f82(1,0x13,&DAT_0103da76);
  return;
}


// ==== FUN_01030a66 @ 01030a66

int FUN_01030a66(int param_1)

{
  int iVar1;
  int unaff_D7;
  int iVar2;
  int local_10;
  
  local_10 = 0x800000;
  iVar2 = 0;
  FUN_01030c6c(0x800000,0x880000);
  *(int *)(param_1 + 2) = unaff_D7;
  if (unaff_D7 != 0) {
    FUN_010456d4(0x1000);
    iVar2 = *(int *)(param_1 + 2);
    for (iVar1 = 0; iVar1 < iVar2 / 0x1000; iVar1 = iVar1 + 1) {
      FUN_0103107c(local_10);
      FUN_01031466(local_10,unaff_D7);
      FUN_01030e00(local_10,param_1);
      FUN_01031466(unaff_D7,local_10);
      if (local_10 != 1) break;
      local_10 = 0x1001;
    }
    FUN_01045712();
    iVar2 = unaff_D7;
  }
  return iVar2;
}


// ==== FUN_01030b34 @ 01030b34

int FUN_01030b34(int param_1)

{
  int iVar1;
  int iVar2;
  int unaff_D7;
  int iVar3;
  int iVar4;
  
  FUN_010456d4(0x1000);
  FUN_010456d4(0x1000);
  FUN_010456d4(0x1000);
  FUN_01030c6c(0x1000000,0x1400000,3);
  *(int *)(param_1 + 2) = unaff_D7;
  if (unaff_D7 != 0) {
    iVar1 = *(int *)(param_1 + 2);
    iVar3 = 0x1100000;
    for (iVar2 = 0; iVar2 < (int)((iVar1 - 0x100000U) / 0x1000); iVar2 = iVar2 + 1) {
      FUN_0103107c(iVar3);
      FUN_01030db2(iVar3,unaff_D7,unaff_D7,unaff_D7);
      FUN_01031466(iVar3,iVar3);
      FUN_01030e00(iVar3,param_1);
      iVar4 = iVar3;
      FUN_01031466(iVar3);
      if (iVar3 != 1) {
        return iVar4;
      }
      iVar3 = 0x1001;
    }
  }
  FUN_01045712(unaff_D7);
  FUN_01045712(unaff_D7);
  FUN_01045712();
  return unaff_D7;
}


// ==== FUN_01030c6c @ 01030c6c

void FUN_01030c6c(undefined4 *param_1,byte *param_2,byte param_3)

{
  undefined4 uVar1;
  undefined4 uVar2;
  uint uVar3;
  int local_10;
  int local_c;
  
  FUN_01058f82(0,0x17,&DAT_01030c6a);
  uVar1 = *param_1;
  uVar2 = *(undefined4 *)param_2;
  *param_1 = 0x55555555;
  param_2[0] = 0xaa;
  param_2[1] = 0xaa;
  param_2[2] = 0xaa;
  param_2[3] = 0xaa;
  local_10 = 0;
  do {
    local_c = 0;
    if (3 < local_10) {
LAB_01030d24:
      *param_1 = uVar1;
      *(undefined4 *)param_2 = uVar2;
      uVar3 = (uint)param_3;
      FUN_010301b4();
      if (uVar3 + local_c == 2) {
        FUN_01058f82(1,0x15,PTR_s_SRAM_0x800000___0x87FFFF_0103ca2e);
        FUN_01058f82(1,0x17,DAT_0103ca32);
      }
      else {
        FUN_01058f82(1,0x15,(&PTR_s_SRAM_DON_T_EXSIT_0103ca2a)[uVar3 + local_c]);
      }
      return;
    }
    if (((**(char **)((int)&param_1 + local_10) == 'U') && (local_10 + (uint)*param_2 != 0xaa)) ||
       (**(char **)((int)&param_1 + local_10) == -0x56)) {
      local_c = 1;
      goto LAB_01030d24;
    }
    if ((**(char **)((int)&param_1 + local_10) == 'U') &&
       (**(char **)((int)&param_2 + local_10) == -0x56)) {
      local_c = 2;
      goto LAB_01030d24;
    }
    local_10 = local_10 + 1;
  } while( true );
}


// ==== FUN_01030db2 @ 01030db2

void FUN_01030db2(void)

{
  return;
}


// ==== FUN_01030e00 @ 01030e00

void FUN_01030e00(undefined4 param_1,undefined4 param_2)

{
  int unaff_D7;
  int iVar1;
  
  iVar1 = 1;
  FUN_01030eb2(param_1,param_2,1,1);
  if (unaff_D7 == 2) {
    iVar1 = 0;
  }
  FUN_010300da();
  if (unaff_D7 == 1) {
    iVar1 = 0;
  }
  if ((iVar1 != 0) && (FUN_01030f22(param_1,param_2), unaff_D7 == 2)) {
    iVar1 = 0;
  }
  FUN_010300da();
  if (unaff_D7 == 1) {
    iVar1 = 0;
  }
  if (iVar1 != 0) {
    FUN_01030fc4(param_1,param_2);
  }
  return;
}


// ==== FUN_01030eb2 @ 01030eb2

void FUN_01030eb2(int *param_1,int param_2)

{
  int iVar1;
  int iVar2;
  int *piVar3;
  
  iVar2 = 0x400;
  piVar3 = param_1;
  while (0 < iVar2) {
    *piVar3 = 0x5a5a5a5a;
    iVar2 = iVar2 + -1;
    piVar3 = piVar3 + 1;
  }
  iVar2 = 0x400;
  do {
    piVar3 = param_1;
    if (iVar2 < 1) {
      return;
    }
    iVar1 = *piVar3;
    iVar2 = iVar2 + -1;
    param_1 = piVar3 + 1;
  } while (iVar1 == 0x5a5a5a5a);
  *(int **)(param_2 + 6) = piVar3;
  *(undefined4 *)(param_2 + 10) = 0x5a5a5a5a;
  *(int **)(param_2 + 0xe) = piVar3;
  *(int *)(param_2 + 0x12) = iVar1;
  return;
}


// ==== FUN_01030f22 @ 01030f22

void FUN_01030f22(int *param_1,int param_2)

{
  int iVar1;
  int iVar2;
  int iVar3;
  
  iVar3 = 0x400;
  while( true ) {
    if (iVar3 < 1) {
      return;
    }
    *param_1 = -0x5a5a5a5b;
    iVar2 = *param_1;
    if (iVar2 != -0x5a5a5a5b) break;
    for (iVar2 = 1; iVar2 <= iVar3 + -1; iVar2 = iVar2 << 1) {
      iVar1 = param_1[iVar2];
      if (iVar1 != 0x5a5a5a5a) {
        *(int **)(param_2 + 6) = param_1;
        *(undefined4 *)(param_2 + 10) = 0x5a5a5a5a;
        *(int **)(param_2 + 0xe) = param_1 + iVar2;
        *(int *)(param_2 + 0x12) = iVar1;
        return;
      }
    }
    param_1 = param_1 + 1;
    iVar3 = iVar3 + -1;
  }
  *(int **)(param_2 + 6) = param_1;
  *(undefined4 *)(param_2 + 10) = 0xa5a5a5a5;
  *(int **)(param_2 + 0xe) = param_1;
  *(int *)(param_2 + 0x12) = iVar2;
  return;
}


// ==== FUN_01030fc4 @ 01030fc4

void FUN_01030fc4(byte *param_1,int param_2)

{
  byte bVar1;
  int iVar2;
  int iVar3;
  
  iVar3 = 0x1000;
  while( true ) {
    if (iVar3 < 1) {
      return;
    }
    *param_1 = 0x5a;
    bVar1 = *param_1;
    if (bVar1 != 0x5a) break;
    for (iVar2 = 1; (iVar2 < 4 && (iVar2 <= iVar3 + -1)); iVar2 = iVar2 + 1) {
      bVar1 = param_1[iVar2];
      if (bVar1 != 0xa5) {
        *(byte **)(param_2 + 6) = param_1;
        *(undefined4 *)(param_2 + 10) = 0xa5;
        *(byte **)(param_2 + 0xe) = param_1 + iVar2;
        *(uint *)(param_2 + 0x12) = (uint)bVar1;
        return;
      }
    }
    param_1 = param_1 + 1;
    iVar3 = iVar3 + -1;
  }
  *(byte **)(param_2 + 6) = param_1;
  *(undefined4 *)(param_2 + 10) = 0x5a;
  *(byte **)(param_2 + 0xe) = param_1;
  *(uint *)(param_2 + 0x12) = (uint)bVar1;
  return;
}


// ==== FUN_0103107c @ 0103107c

undefined1 * FUN_0103107c(undefined4 param_1)

{
  int iVar1;
  undefined1 *puVar2;
  
  FUN_010301b4();
  for (iVar1 = 0; iVar1 < 9; iVar1 = iVar1 + 1) {
    (&DAT_0103da76)[iVar1] = **(undefined1 **)((int)&DAT_0103c9d4 + iVar1);
  }
  FUN_0105ee14(0,param_1,8,&DAT_0103da80);
  puVar2 = &DAT_0103da76;
  FUN_01058f82(1,0x19);
  return puVar2;
}


// ==== FUN_010310f6 @ 010310f6

void FUN_010310f6(int param_1,undefined1 *param_2)

{
  int local_8;
  
  FUN_010301b4();
  FUN_01048236("CPU-88 : Memories.");
  if (param_1 == 1) {
    FUN_01058f82(0,0x13,&DAT_010310e4);
    FUN_01058f82(0,0x15,&DAT_010310e6);
    FUN_01058f82(0,0x17,&DAT_010310e8);
    FUN_01058f82(0,0x19,&DAT_010310ea);
    FUN_01058f82(1,0x13,PTR_s_Check_Pass__0103c98e);
    FUN_01048236(PTR_s_Check_Pass__0103c98e);
    FUN_0103002a(1000);
  }
  else if (param_1 == 2) {
    FUN_01048236(PTR_s_Check_Fault__0103c9a0);
    FUN_01048236(&DAT_010310ec);
    FUN_010301b4();
    for (local_8 = 0; local_8 < 0x10; local_8 = local_8 + 1) {
      (&DAT_0103da78)[local_8] = "EPROM Version = "[local_8];
    }
    DAT_0103da88 = 0x56;
    FUN_0105ec54(0,*param_2,2,&DAT_0103da89);
    DAT_0103da8b = 0x2e;
    FUN_0105ec54(0,param_2[1],2,&DAT_0103da8c);
    FUN_01048236(&DAT_0103da76);
    FUN_010301b4();
    FUN_01048236(&DAT_0103da76);
    for (local_8 = 0; local_8 < 0xd; local_8 = local_8 + 1) {
      (&DAT_0103da78)[local_8] = **(undefined1 **)((int)&PTR_s_Write_Address_0103c9e2 + local_8);
    }
    for (local_8 = 0; local_8 < 10; local_8 = local_8 + 1) {
      (&DAT_0103da88)[local_8] = **(undefined1 **)((int)&PTR_s_Write_data_0103c9e6 + local_8);
    }
    for (local_8 = 0; local_8 < 0xc; local_8 = local_8 + 1) {
      (&DAT_0103da98)[local_8] = **(undefined1 **)((int)&PTR_s_Read_Address_0103c9ea + local_8);
    }
    for (local_8 = 0; local_8 < 9; local_8 = local_8 + 1) {
      (&DAT_0103daa8)[local_8] = **(undefined1 **)((int)&PTR_s_Read_data_0103c9ee + local_8);
    }
    FUN_01058f82(1,0x19,&DAT_0103da78);
    FUN_01048236(&DAT_0103da76);
    FUN_010301b4();
    FUN_0105ee14(0,*(undefined4 *)(param_2 + 6),8,&DAT_0103da78);
    DAT_0103da80 = 0x20;
    FUN_0105ee14(0,*(undefined4 *)(param_2 + 10),8,&DAT_0103da88);
    DAT_0103da90 = 0x20;
    FUN_0105ee14(0,*(undefined4 *)(param_2 + 0xe),8,&DAT_0103da98);
    DAT_0103daa0 = 0x20;
    FUN_0105ee14(0,*(undefined4 *)(param_2 + 0x12),8,&DAT_0103daa8);
    DAT_0103dab0 = 0x20;
    FUN_01058f82(1,0x1a,&DAT_0103da78);
    FUN_01048236(&DAT_0103da76);
    FUN_0103002a(1000);
  }
  else {
    FUN_01058f82(0,0x13,&DAT_010310ee);
    FUN_01058f82(0,0x15,&DAT_010310f0);
    FUN_01058f82(0,0x17,&DAT_010310f2);
    FUN_01058f82(0,0x19,&DAT_010310f4);
    FUN_01048236(PTR_s_Check_Abort__0103c9b2);
  }
  return;
}


// ==== FUN_01031466 @ 01031466

void FUN_01031466(undefined1 *param_1,undefined1 *param_2)

{
  int iVar1;
  
  for (iVar1 = 0; iVar1 < 0x1000; iVar1 = iVar1 + 1) {
    *param_2 = *param_1;
    param_2 = param_2 + 1;
    param_1 = param_1 + 1;
  }
  return;
}


// ==== FUN_0103148e @ 0103148e

void FUN_0103148e(void)

{
  int iVar1;
  int unaff_D7;
  int iVar2;
  int local_20;
  undefined4 local_18;
  int local_14;
  int local_10;
  int local_8;
  
  local_10 = 1;
  local_14 = 1;
  local_18 = 0;
  FUN_010456d4(0xa000);
  FUN_010300da();
  if (unaff_D7 == 1) {
    local_14 = 0;
    local_10 = 3;
  }
  if (local_14 != 0) {
    local_20 = 0xf00a000;
    FUN_010456d4(0x800);
    iVar2 = unaff_D7;
    for (local_8 = 0; iVar1 = local_8, local_8 < 0x800; local_8 = local_8 + 1) {
      **(undefined1 **)((int)register0x0000003c + local_8 + -0x1c) =
           **(undefined1 **)((int)&local_20 + local_8);
      FUN_0103002a(1);
      iVar2 = iVar1;
    }
    FUN_010315a8(unaff_D7,&local_18);
    local_10 = iVar2;
    FUN_01031626(unaff_D7,local_20);
    FUN_01045712(unaff_D7);
    FUN_010300da();
    if (iVar2 == 1) {
      local_10 = 3;
    }
  }
  FUN_01031ca2(unaff_D7,local_18,local_10);
  FUN_01045712(unaff_D7);
  return;
}


// ==== FUN_010315a8 @ 010315a8

void FUN_010315a8(undefined4 param_1,undefined4 param_2)

{
  undefined1 local_d [5];
  undefined4 local_8;
  
  local_8 = 1;
  FUN_01059654(1);
  local_d[0] = 0x14;
  FUN_010316ec(param_1,param_2,local_d);
  FUN_0105ef12();
  return;
}


// ==== FUN_01031626 @ 01031626

void FUN_01031626(undefined4 param_1,undefined4 param_2)

{
  int local_c;
  undefined4 local_8;
  
  for (local_8 = 0x13; local_8 < 0x1c; local_8 = local_8 + 1) {
    FUN_01058f82(0,(int)(char)local_8,&DAT_01031612);
  }
  FUN_01058f82(1,0x13,"Now on Recovery ");
  for (local_8 = 0; local_8 < 0x800; local_8 = local_8 + 1) {
    **(undefined1 **)((int)&param_2 + local_8) = **(undefined1 **)((int)&param_1 + local_8);
    FUN_0103002a(0x12);
    local_c = 0;
    while ((local_c < 5 &&
           (**(char **)((int)&param_2 + local_8) != **(char **)((int)&param_1 + local_8)))) {
      **(undefined1 **)((int)&param_2 + local_8) = **(undefined1 **)((int)&param_1 + local_8);
      FUN_0103002a(0x12);
      local_c = local_c + 1;
    }
  }
  return;
}


// ==== FUN_010316ec @ 010316ec

void FUN_010316ec(int param_1,int *param_2,char *param_3)

{
  int unaff_D7;
  uint uVar1;
  uint local_10 [3];
  
  local_10[2] = 1;
  FUN_010300da();
  if (unaff_D7 == 1) {
    return;
  }
  local_10[0] = 0xf00a000;
  local_10[1] = 0;
  while( true ) {
    if (0x7ff < local_10[1]) {
      return;
    }
    if (*param_2 == 0) {
      FUN_01031b74(*(undefined4 *)((int)local_10 + local_10[1]));
    }
    **(undefined1 **)((int)local_10 + local_10[1]) = 0x55;
    FUN_0103002a(0x12);
    uVar1 = local_10[1];
    if (**(char **)((int)local_10 + local_10[1]) != 'U') {
      if (*param_2 == 0) {
        FUN_01058f82(1,0x13,"  Write Address   Write data      Read Address    Read data");
      }
      *(undefined4 *)(&param_1)[*param_2] = *(undefined4 *)((int)local_10 + local_10[1]);
      *(undefined1 *)(param_1 + 0x4000 + *param_2) = 0x55;
      *(undefined4 *)(param_1 + 0x5000 + *param_2 * 4) =
           *(undefined4 *)((int)local_10 + local_10[1]);
      *(undefined1 *)(param_1 + 0x9000 + *param_2) = **(undefined1 **)((int)local_10 + local_10[1]);
      uVar1 = (uint)*param_3;
      FUN_01031ba8(param_1,*param_2,uVar1);
      *param_2 = *param_2 + 1;
      *param_3 = *param_3 + '\x01';
      local_10[2] = 2;
    }
    FUN_010300da();
    if (uVar1 == 1) break;
    local_10[1] = local_10[1] + 1;
  }
  return;
}


// ==== FUN_0103183c @ 0103183c

void FUN_0103183c(int param_1,int *param_2,char *param_3)

{
  int unaff_D7;
  int iVar1;
  uint uVar2;
  int local_1c [6];
  
  local_1c[5] = 1;
  FUN_010300da();
  if (unaff_D7 == 1) {
    return;
  }
  local_1c[0] = 0xf00a000;
  local_1c[4] = 0;
  do {
    if (0x7ff < (uint)local_1c[4]) {
      return;
    }
    if (*param_2 == 0) {
      FUN_01031b74(*(undefined4 *)((int)local_1c + local_1c[4]));
    }
    **(undefined1 **)((int)local_1c + local_1c[4]) = 0xaa;
    FUN_0103002a(0x12);
    iVar1 = CONCAT31((int3)((uint)local_1c[4] >> 8),**(char **)((int)local_1c + local_1c[4]));
    if (**(char **)((int)local_1c + local_1c[4]) != -0x56) {
      if (*param_2 == 0) {
        FUN_01058f82(1,0x13,"  Write Address   Write data      Read Address    Read data");
      }
      *(undefined4 *)(&param_1)[*param_2] = *(undefined4 *)((int)local_1c + local_1c[4]);
      *(undefined1 *)(param_1 + 0x4000 + *param_2) = 0xaa;
      *(undefined4 *)(param_1 + 0x5000 + *param_2 * 4) =
           *(undefined4 *)((int)local_1c + local_1c[4]);
      *(undefined1 *)(param_1 + 0x9000 + *param_2) = **(undefined1 **)((int)local_1c + local_1c[4]);
      iVar1 = (int)*param_3;
      FUN_01031ba8(param_1,*param_2,iVar1);
      *param_2 = *param_2 + 1;
      *param_3 = *param_3 + '\x01';
      local_1c[5] = 2;
    }
    FUN_010300da();
    if (iVar1 == 1) {
      return;
    }
    if (0x7ff < local_1c[4] + 1U) {
      return;
    }
    if (*(char *)(local_1c[0] + 1 + local_1c[4]) != 'U') {
      if (*param_2 == 0) {
        FUN_01058f82(1,0x13,"  Write Address   Write data      Read Address    Read data");
      }
      *(undefined4 *)(&param_1)[*param_2] = *(undefined4 *)((int)local_1c + local_1c[4]);
      *(undefined1 *)(param_1 + 0x4000 + *param_2) = 0xaa;
      *(int *)(param_1 + 0x5000 + *param_2 * 4) = local_1c[4] + local_1c[0] + 1;
      *(undefined1 *)(param_1 + 0x9000 + *param_2) = *(undefined1 *)(local_1c[0] + 1 + local_1c[4]);
      FUN_01031ba8(param_1,*param_2,(int)*param_3);
      *param_2 = *param_2 + 1;
      *param_3 = *param_3 + '\x01';
      local_1c[5] = 2;
    }
    local_1c[3] = 0;
    local_1c[2] = 1;
    while( true ) {
      uVar2 = local_1c[4] + (local_1c[2] << (local_1c[3] & 0x3fU));
      local_1c[1] = uVar2;
      if (0x7ff < uVar2) break;
      if (**(char **)((int)local_1c + uVar2) != 'U') {
        if (*param_2 == 0) {
          FUN_01058f82(1,0x13,"  Write Address   Write data      Read Address    Read data");
        }
        *(undefined4 *)(&param_1)[*param_2] = *(undefined4 *)((int)local_1c + local_1c[4]);
        *(undefined1 *)(param_1 + 0x4000 + *param_2) = 0xaa;
        *(undefined4 *)(param_1 + 0x5000 + *param_2 * 4) =
             *(undefined4 *)((int)local_1c + local_1c[1]);
        *(undefined1 *)(param_1 + 0x9000 + *param_2) =
             **(undefined1 **)((int)local_1c + local_1c[1]);
        uVar2 = (uint)*param_3;
        FUN_01031ba8(param_1,*param_2,uVar2);
        *param_2 = *param_2 + 1;
        *param_3 = *param_3 + '\x01';
        local_1c[5] = 2;
      }
      FUN_010300da();
      if (uVar2 == 1) {
        local_1c[5] = 3;
        break;
      }
      local_1c[3] = local_1c[3] + 1;
    }
    local_1c[4] = local_1c[4] + 1;
  } while( true );
}


// ==== FUN_01031b74 @ 01031b74

void FUN_01031b74(undefined4 param_1)

{
  FUN_0105ee14(0,param_1,8,&DAT_0103da82);
  FUN_0105969e(1,&DAT_0103da82);
  return;
}


// ==== FUN_01031ba8 @ 01031ba8

void FUN_01031ba8(int param_1,int param_2,char param_3)

{
  FUN_010301b4();
  FUN_0105ee14(0,*(undefined4 *)(&param_1)[param_2],8,&DAT_0103da7e);
  DAT_0103da86 = 0x20;
  FUN_0105ee14(0,*(undefined1 *)(param_1 + 0x4000 + param_2),2,&DAT_0103da8e);
  DAT_0103da90 = 0x20;
  FUN_0105ee14(0,*(undefined4 *)(param_1 + 0x5000 + param_2 * 4),8,&DAT_0103da9e);
  DAT_0103daa6 = 0x20;
  FUN_0105ee14(0,*(undefined1 *)(param_1 + 0x9000 + param_2),2,&DAT_0103daae);
  DAT_0103dab0 = 0x20;
  if (param_3 < '\x1c') {
    FUN_01058f82(1,(int)param_3,&DAT_0103da78);
  }
  return;
}


// ==== FUN_01031ca2 @ 01031ca2

void FUN_01031ca2(int param_1,int param_2,int param_3)

{
  int local_8;
  
  FUN_01048236("CPU-88 : EEPROM.");
  FUN_010301b4();
  if (param_3 == 1) {
    FUN_01048236(PTR_s_Check_Pass__0103c98e);
  }
  else if (param_3 == 3) {
    FUN_01048236(PTR_s_Check_Abort__0103c9b2);
  }
  else {
    FUN_01048236(PTR_s_Check_Fault__0103c9a0);
    FUN_01048236(&DAT_01031ca0);
    FUN_01048236("  Write Address   Write data      Read Address    Read data");
    for (local_8 = 0; local_8 < param_2; local_8 = local_8 + 1) {
      FUN_010301b4();
      FUN_0105ee14(0,*(undefined4 *)(&param_1)[local_8],8,&DAT_0103da7c);
      DAT_0103da84 = 0x20;
      FUN_0105ee14(0,*(undefined1 *)(param_1 + 0x4000 + local_8),2,&DAT_0103da8c);
      DAT_0103da8e = 0x20;
      FUN_0105ee14(0,*(undefined4 *)(param_1 + 0x5000 + local_8 * 4),8,&DAT_0103da9c);
      DAT_0103daa4 = 0x20;
      FUN_0105ee14(0,*(undefined1 *)(param_1 + 0x9000 + local_8),2,&DAT_0103daac);
      DAT_0103daae = 0x20;
      FUN_01048236(&DAT_0103da76);
    }
  }
  return;
}


// ==== FUN_01031e06 @ 01031e06

void FUN_01031e06(void)

{
  uint uVar1;
  undefined1 auStack_ca [16];
  int local_ba [11];
  undefined1 auStack_8e [60];
  undefined1 auStack_52 [40];
  undefined1 auStack_2a [21];
  byte local_15;
  int local_14;
  int local_10;
  uint local_c;
  uint local_8;
  
  local_8 = 1;
  local_c = 0;
  local_10 = 1;
  local_15 = DAT_0f00b002;
  uVar1 = (uint)DAT_0f00b002;
  FUN_01034dd6(uVar1);
  FUN_010300da();
  if (uVar1 == 1) {
    local_10 = 0;
  }
  local_c = uVar1;
  if (local_10 != 0) {
    for (local_14 = 0; local_14 < 9; local_14 = local_14 + 1) {
      uVar1 = local_14 * 0x14;
      local_ba[local_14 * 5] = -1;
    }
    FUN_01031f18();
    FUN_0103200c(auStack_ca);
    if (local_ba[0] == 100) {
      FUN_010300da();
      local_c = uVar1;
      if (uVar1 != 1) {
        FUN_01032036(auStack_8e);
        FUN_010300da();
        local_c = uVar1;
        if (uVar1 != 1) {
          FUN_01032068(auStack_52);
          FUN_010300da();
          local_c = uVar1;
          if (uVar1 != 1) {
            FUN_010326b6(auStack_2a);
          }
        }
      }
    }
  }
  FUN_01032b56(auStack_ca,local_c);
  local_8 = uVar1;
  FUN_01031ff4();
  return;
}


// ==== FUN_01031f18 @ 01031f18

void FUN_01031f18(void)

{
  DAT_0f004001 = DAT_0f004001 | 0xf0;
  DAT_0f003001 = DAT_0f003001 | 0x1e;
  *(undefined1 **)(DAT_01092c58 + 0x150) = &LAB_010306be;
  *(undefined1 **)(DAT_01092c58 + 0x154) = &LAB_010305ee;
  *(undefined1 **)(DAT_01092c58 + 0x158) = &LAB_01030656;
  *(undefined1 **)(DAT_01092c58 + 0x15c) = &LAB_010306f2;
  *(undefined1 **)(DAT_01092c58 + 0x164) = &LAB_0103068a;
  *(undefined1 **)(DAT_01092c58 + 0x168) = &LAB_010306a4;
  *(code **)(DAT_01092c58 + 0x16c) = FUN_010305d4;
  *(undefined1 **)(DAT_01092c58 + 0x170) = &LAB_010306d8;
  return;
}


// ==== FUN_01031fc0 @ 01031fc0

void FUN_01031fc0(void)

{
  DAT_0f004001 = DAT_0f004001 | 0x60;
  *(undefined1 **)(DAT_01092c58 + 0x154) = &LAB_01030608;
  *(undefined1 **)(DAT_01092c58 + 0x158) = &LAB_01030670;
  return;
}


// ==== FUN_01031ff4 @ 01031ff4

void FUN_01031ff4(void)

{
  FUN_01044654();
  *(undefined1 **)(DAT_01092c58 + 0x15c) = &LAB_010454fc;
  return;
}


// ==== FUN_0103200c @ 0103200c

void FUN_0103200c(int param_1)

{
  int unaff_D7;
  
  FUN_0103208a(param_1);
  if (unaff_D7 == 1) {
    FUN_010322b8(param_1 + 0x28);
  }
  return;
}


// ==== FUN_01032036 @ 01032036

void FUN_01032036(int param_1)

{
  FUN_010323c2(param_1);
  FUN_010324b2(param_1 + 0x14);
  FUN_010325b4(param_1 + 0x28);
  return;
}


// ==== FUN_01032068 @ 01032068

void FUN_01032068(int param_1)

{
  FUN_0103282e(param_1);
  FUN_01032922(param_1 + 0x14);
  return;
}


// ==== FUN_0103208a @ 0103208a

/* WARNING: Removing unreachable block (ram,0x010320fe) */

void FUN_0103208a(undefined4 *param_1)

{
  int unaff_D7;
  
  *param_1 = 0;
  param_1[5] = 1;
  FUN_01032ae2(param_1,1);
  *(undefined1 *)(param_1 + 1) = 0x34;
  param_1[4] = 100;
  *(undefined1 *)(param_1 + 6) = 0x74;
  param_1[9] = 100;
  FUN_01032172();
  if (unaff_D7 == 1) {
    FUN_01032204();
  }
  else {
    param_1[4] = 0x15;
    DAT_0103da4e = 100;
  }
  *(undefined2 *)((int)param_1 + 6) = 4000;
  param_1[2] = DAT_0103da4e;
  param_1[3] = DAT_0103da52;
  *(undefined2 *)((int)param_1 + 0x1a) = 4000;
  param_1[7] = DAT_0103da52;
  param_1[8] = DAT_0103da4e;
  return;
}


// ==== FUN_01032172 @ 01032172

void FUN_01032172(void)

{
  DAT_0103da36 = 0;
  DAT_0103da52 = 0;
  FUN_01032a52(0,0,0x34,4000,1);
  FUN_01032a52(0,1,0x74,4000);
  DAT_0f003001 = DAT_0f003001 & 0xfd;
  FUN_0103002a(200);
  DAT_0f003001 = DAT_0f003001 | 6;
  return;
}


// ==== FUN_01032204 @ 01032204

/* WARNING: Removing unreachable block (ram,0x0103225c) */
/* WARNING: Removing unreachable block (ram,0x01032276) */
/* WARNING: Removing unreachable block (ram,0x01032280) */
/* WARNING: Removing unreachable block (ram,0x01032242) */
/* WARNING: Removing unreachable block (ram,0x0103224e) */
/* WARNING: Removing unreachable block (ram,0x0103226a) */
/* WARNING: Removing unreachable block (ram,0x01032294) */
/* WARNING: Removing unreachable block (ram,0x0103229a) */

void FUN_01032204(void)

{
                    /* WARNING: Do nothing block with infinite loop */
  do {
  } while( true );
}


// ==== FUN_010322b8 @ 010322b8

undefined4 * FUN_010322b8(undefined4 *param_1)

{
  *param_1 = 2;
  FUN_01032ae2();
  DAT_0103da52 = 0;
  DAT_0103da36 = 2;
  *(undefined1 *)(param_1 + 1) = 0xb4;
  FUN_01032a52(0,2,0xb4,400);
  do {
  } while (DAT_0103da52 < 0xc);
  DAT_0f004001 = DAT_0f004001 & 0xef | 0x10;
  DAT_0f003001 = DAT_0f003001 & 0xfd | 2;
  if ((DAT_0103da4a < 0x62) || (0x66 < DAT_0103da4a)) {
    if (DAT_0103da4a == 0) {
      param_1[4] = 0x15;
    }
    else {
      param_1[4] = 0x16;
    }
  }
  else {
    param_1[4] = 100;
  }
  *(undefined2 *)((int)param_1 + 6) = 400;
  param_1[2] = 100;
  param_1[3] = DAT_0103da4a;
  return param_1;
}


// ==== FUN_010323c2 @ 010323c2

void FUN_010323c2(undefined4 *param_1)

{
  int local_8;
  
  *param_1 = 3;
  *(undefined1 *)(param_1 + 1) = 0;
  FUN_01032ae2(param_1);
  if ((DAT_0103dac8 == 3) || (DAT_0103dac8 == 2)) {
    local_8 = 0x14;
  }
  else {
    local_8 = 0x10;
  }
  DAT_0103da32 = 2;
  DAT_0f003001 = DAT_0f003001 & 0xf7;
  FUN_0103002a(local_8 << 2);
  DAT_0f003001 = DAT_0f003001 | 10;
  if ((DAT_0103da52 < local_8 + -2) || (local_8 + 2 < DAT_0103da52)) {
    if (DAT_0103da52 == 0) {
      param_1[4] = 0x15;
    }
    else {
      param_1[4] = 0x16;
    }
  }
  else {
    param_1[4] = 100;
  }
  *(undefined2 *)((int)param_1 + 6) = 4000;
  param_1[2] = local_8;
  param_1[3] = DAT_0103da52;
  return;
}


// ==== FUN_010324b2 @ 010324b2

void FUN_010324b2(undefined4 *param_1)

{
  int local_8;
  
  *param_1 = 4;
  *(undefined1 *)(param_1 + 1) = 0;
  FUN_01032ae2(param_1);
  if ((DAT_0103dac8 == 3) || (DAT_0103dac8 == 2)) {
    local_8 = 0x28;
  }
  else {
    local_8 = 0x20;
  }
  DAT_0103da2e = 2;
  DAT_0f004001 = DAT_0f004001 & 0xdf;
  FUN_0103002a(local_8 << 2);
  DAT_0f003001 = DAT_0f003001 | 2;
  DAT_0f004001 = DAT_0f004001 | 0x20;
  if ((DAT_0103da52 < local_8 + -2) || (local_8 + 2 < DAT_0103da52)) {
    if (DAT_0103da52 == 0) {
      param_1[4] = 0x15;
    }
    else {
      param_1[4] = 0x16;
    }
  }
  else {
    param_1[4] = 100;
  }
  *(undefined2 *)((int)param_1 + 6) = 4000;
  param_1[2] = local_8;
  param_1[3] = DAT_0103da52;
  return;
}


// ==== FUN_010325b4 @ 010325b4

void FUN_010325b4(undefined4 *param_1)

{
  int local_8;
  
  *param_1 = 5;
  *(undefined1 *)(param_1 + 1) = 0;
  FUN_01032ae2(param_1);
  if ((DAT_0103dac8 == 3) || (DAT_0103dac8 == 2)) {
    local_8 = 0x28;
  }
  else {
    local_8 = 0x20;
  }
  DAT_0103da2a = 2;
  DAT_0f004001 = DAT_0f004001 & 0xbf;
  FUN_0103002a(local_8 << 2);
  DAT_0f003001 = DAT_0f003001 | 2;
  DAT_0f004001 = DAT_0f004001 | 0x40;
  if ((DAT_0103da52 < local_8 + -2) || (local_8 + 2 < DAT_0103da52)) {
    if (DAT_0103da52 == 0) {
      param_1[4] = 0x15;
    }
    else {
      param_1[4] = 0x16;
    }
  }
  else {
    param_1[4] = 100;
  }
  *(undefined2 *)((int)param_1 + 6) = 4000;
  param_1[2] = local_8;
  param_1[3] = DAT_0103da52;
  return;
}


// ==== FUN_010326b6 @ 010326b6

/* WARNING: Removing unreachable block (ram,0x01032822) */
/* WARNING: Removing unreachable block (ram,0x010327ac) */
/* WARNING: Removing unreachable block (ram,0x01032794) */
/* WARNING: Removing unreachable block (ram,0x0103277c) */
/* WARNING: Removing unreachable block (ram,0x01032762) */
/* WARNING: Removing unreachable block (ram,0x01032764) */
/* WARNING: Removing unreachable block (ram,0x0103277e) */
/* WARNING: Removing unreachable block (ram,0x01032796) */
/* WARNING: Removing unreachable block (ram,0x010327ae) */
/* WARNING: Removing unreachable block (ram,0x01032824) */

void FUN_010326b6(undefined4 *param_1)

{
  int local_8;
  
  *param_1 = 8;
  *(undefined1 *)(param_1 + 1) = 0;
  FUN_01032ae2(param_1);
  if ((DAT_0103dac8 == 3) || (DAT_0103dac8 == 2)) {
    local_8 = 0x28;
  }
  else {
    local_8 = 0x20;
  }
  FUN_01031fc0();
  DAT_0103da2e = 3;
  DAT_0f004001 = DAT_0f004001 & 0xdf;
  FUN_0103002a(local_8 << 2);
  DAT_0f003001 = DAT_0f003001 | 2;
  DAT_0f004001 = DAT_0f004001 | 0x60;
  DAT_0103da3a = DAT_0103da52 - DAT_0103da3e;
  local_8 = local_8 >> 1;
  if ((DAT_0103da3e < local_8 + -2) || (local_8 + 2 < DAT_0103da3e)) {
    param_1[4] = 0x16;
    param_1[3] = DAT_0103da3e;
  }
  else if ((DAT_0103da3a < local_8 + -2) || (local_8 + 2 < DAT_0103da3a)) {
    param_1[4] = 0x16;
    param_1[3] = DAT_0103da3e;
  }
  else {
    param_1[4] = 100;
    param_1[3] = DAT_0103da3a;
  }
  *(undefined2 *)((int)param_1 + 6) = 4000;
  param_1[2] = local_8;
  return;
}


// ==== FUN_0103282e @ 0103282e

undefined4 * FUN_0103282e(undefined4 *param_1)

{
  *param_1 = 6;
  FUN_01032ae2();
  DAT_0103da52 = 0;
  DAT_0103da46 = 0;
  DAT_0103da36 = 2;
  *(undefined1 *)(param_1 + 1) = 0x34;
  FUN_01032a52(1,0,0x34,400);
  do {
  } while (DAT_0103da52 < 0xc);
  DAT_0f003001 = DAT_0f003001 & 0xed | 0x12;
  if ((DAT_0103da46 < 0x62) || (0x66 < DAT_0103da46)) {
    if (DAT_0103da46 == 0) {
      param_1[4] = 0x15;
    }
    else {
      param_1[4] = 0x16;
    }
  }
  else {
    param_1[4] = 100;
  }
  *(undefined2 *)((int)param_1 + 6) = 400;
  param_1[2] = 100;
  param_1[3] = DAT_0103da46;
  return param_1;
}


// ==== FUN_01032922 @ 01032922

undefined4 * FUN_01032922(undefined4 *param_1)

{
  *param_1 = 7;
  FUN_01032ae2();
  DAT_0103da52 = 0;
  DAT_0103da46 = 0;
  DAT_0103da42 = 0;
  DAT_0103da36 = 2;
  *(undefined1 *)(param_1 + 1) = 0x74;
  FUN_01032a52(1,1,0x74,800);
  FUN_01032a52(1,0,0x34,2);
  do {
  } while (DAT_0103da52 < 0xc);
  DAT_0f004001 = DAT_0f004001 & 0x7f | 0x80;
  DAT_0f003001 = DAT_0f003001 & 0xfd | 2;
  if ((DAT_0103da42 < 0x17) || (0x1b < DAT_0103da42)) {
    if (DAT_0103da42 == 0) {
      param_1[4] = 0x15;
    }
    else {
      param_1[4] = 0x16;
    }
  }
  else {
    param_1[4] = 100;
  }
  *(undefined2 *)((int)param_1 + 6) = 800;
  param_1[2] = 0x19;
  param_1[3] = DAT_0103da42;
  return param_1;
}


// ==== FUN_01032a52 @ 01032a52

void FUN_01032a52(char param_1,char param_2,undefined1 param_3,undefined4 param_4)

{
  undefined1 *puVar1;
  
  if (param_1 == '\0') {
    puVar1 = &DAT_0f002000;
  }
  else {
    puVar1 = &DAT_0f005000;
  }
  puVar1[3] = param_3;
  if (param_2 == '\0') {
    *puVar1 = (undefined1)param_4;
    *puVar1 = param_4._2_1_;
  }
  else if (param_2 == '\x01') {
    puVar1[1] = (undefined1)param_4;
    puVar1[1] = param_4._2_1_;
  }
  else {
    puVar1[2] = (undefined1)param_4;
    puVar1[2] = param_4._2_1_;
  }
  return;
}


// ==== FUN_01032ae2 @ 01032ae2

void FUN_01032ae2(int *param_1)

{
  int local_8;
  
  FUN_010301b4();
  for (local_8 = 0; local_8 < 6; local_8 = local_8 + 1) {
    (&DAT_0103da76)[local_8] = *(undefined1 *)(*(int *)(&DAT_0103cb82 + *param_1 * 4) + local_8);
    (&DAT_0103da80)[local_8] = "Check "[local_8];
  }
  FUN_01058f82(1,0x13,&DAT_0103da76);
  return;
}


// ==== FUN_01032b56 @ 01032b56

void FUN_01032b56(undefined4 param_1,int param_2)

{
  char local_15;
  int local_14;
  int local_10;
  int local_c;
  
  FUN_010301b4();
  FUN_01048236(PTR_s_CPU_88___Counter___Timer__0103cafa);
  if (param_2 == 1) {
    FUN_01048236(PTR_s_Check_Abort__0103c9b2);
  }
  else {
    FUN_01048236(&DAT_01032b54);
    FUN_010301b4();
    for (local_c = 0; local_c < 0x2f; local_c = local_c + 1) {
      (&DAT_0103da78)[local_c] =
           **(undefined1 **)((int)&PTR_s_CH_Cmd_Count_Ref_IRQ_Result_0103cb18 + local_c);
    }
    local_15 = '\x14';
    FUN_01058f82(1,0x13,&DAT_0103da78);
    FUN_01048236(&DAT_0103da76);
    for (local_c = 0; local_c < 9; local_c = local_c + 1) {
      if (*(int *)(*(int *)((int)&param_1 + local_c * 0x14) + 0x10) != -1) {
        FUN_010301b4();
        for (local_10 = 0; local_10 < 6; local_10 = local_10 + 1) {
          (&DAT_0103da78)[local_10] =
               *(undefined1 *)
                (*(int *)(&DAT_0103cb82 + **(int **)((int)&param_1 + local_c * 0x14) * 4) + local_10
                );
        }
        FUN_0105ee14(0,(int)*(char *)(*(int *)((int)&param_1 + local_c * 0x14) + 4),2,&DAT_0103da80)
        ;
        DAT_0103da82 = 0x20;
        FUN_0105ec54(1,*(undefined2 *)(*(int *)((int)&param_1 + local_c * 0x14) + 6),4,&DAT_0103da88
                    );
        DAT_0103da8c = 0x20;
        FUN_0105ec54(1,*(undefined4 *)(*(int *)((int)&param_1 + local_c * 0x14) + 8),3,&DAT_0103da91
                    );
        DAT_0103da94 = 0x20;
        FUN_0105ec54(1,*(undefined4 *)(*(int *)((int)&param_1 + local_c * 0x14) + 0xc),3,
                     &DAT_0103da99);
        DAT_0103da9c = 0x20;
        if (*(int *)(*(int *)((int)&param_1 + local_c * 0x14) + 0x10) == 100) {
          local_14 = 0;
        }
        else {
          local_14 = *(int *)(*(int *)((int)&param_1 + local_c * 0x14) + 0x10) + -0x14;
        }
        for (local_10 = 0; local_10 < 0xc; local_10 = local_10 + 1) {
          (&DAT_0103daa1)[local_10] = (&PTR_s_Pass_0103cb4e)[local_14][local_10];
        }
        FUN_01048236(&DAT_0103da76);
        if (local_15 < '\x1d') {
          FUN_01058f82(1,(int)local_15,&DAT_0103da78);
          local_15 = local_15 + '\x01';
        }
      }
    }
    FUN_0103002a(0x5dc);
  }
  return;
}


// ==== FUN_01032e0c @ 01032e0c

void FUN_01032e0c(void)

{
  if (DAT_0103da36 != 0) {
    DAT_0103da4e = 0;
    DAT_0103da4a = 0;
    DAT_0103da46 = 0;
    DAT_0103da42 = 0;
    DAT_0103da36 = DAT_0103da36 + -1;
  }
  DAT_0103da52 = DAT_0103da52 + 1;
  return;
}


// ==== FUN_01032e3a @ 01032e3a

void FUN_01032e3a(void)

{
  byte bVar1;
  
  bVar1 = DAT_0f003001 | 10;
  if (DAT_0103da32 != 0) {
    DAT_0103da32 = DAT_0103da32 + -1;
    DAT_0103da52 = 0;
    bVar1 = DAT_0f003001 & 0xf5;
  }
  DAT_0f003001 = bVar1;
  return;
}


// ==== FUN_01032e7c @ 01032e7c

void FUN_01032e7c(void)

{
  byte bVar1;
  byte bVar2;
  
  bVar1 = DAT_0f003001 | 2;
  bVar2 = DAT_0f004001 | 0x20;
  if (DAT_0103da2e != 0) {
    DAT_0103da2e = DAT_0103da2e + -1;
    DAT_0103da52 = 0;
    bVar1 = DAT_0f003001 & 0xfd;
    bVar2 = DAT_0f004001 & 0xdf;
  }
  DAT_0f004001 = bVar2;
  DAT_0f003001 = bVar1;
  return;
}


// ==== FUN_01032eda @ 01032eda

void FUN_01032eda(void)

{
  byte bVar1;
  byte bVar2;
  
  bVar1 = DAT_0f003001 | 2;
  bVar2 = DAT_0f004001 | 0x40;
  if (DAT_0103da2a != 0) {
    DAT_0103da2a = DAT_0103da2a + -1;
    DAT_0103da52 = 0;
    bVar1 = DAT_0f003001 & 0xfd;
    bVar2 = DAT_0f004001 & 0xbf;
  }
  DAT_0f004001 = bVar2;
  DAT_0f003001 = bVar1;
  return;
}


// ==== FUN_01032f38 @ 01032f38

void FUN_01032f38(void)

{
  byte bVar1;
  
  bVar1 = DAT_0f004001 | 0x60;
  if (DAT_0103da2e < 2) {
    DAT_0f004001 = bVar1;
    if (DAT_0103da2e == 1) {
      DAT_0103da2e = 0;
      DAT_0f003001 = DAT_0f003001 | 2;
    }
  }
  else {
    DAT_0103da2e = DAT_0103da2e + -1;
    DAT_0103da52 = 0;
    DAT_0f003001 = DAT_0f003001 & 0xfd;
    DAT_0f004001 = DAT_0f004001 & 0x9f;
  }
  return;
}


// ==== FUN_01032fb6 @ 01032fb6

void FUN_01032fb6(void)

{
  DAT_0103da3e = DAT_0103da52;
  return;
}


// ==== FUN_01032fc2 @ 01032fc2

void FUN_01032fc2(void)

{
  undefined4 unaff_D7;
  int iVar1;
  uint uVar2;
  undefined1 auStack_1e [11];
  char local_13;
  undefined4 local_10;
  undefined4 local_c;
  uint local_8;
  
  local_8 = 1;
  FUN_010301b4();
  if ((DAT_0103dac8 == 3) || (DAT_0103dac8 == 2)) {
    local_c = 0x32;
  }
  else {
    local_c = 0x3c;
  }
  iVar1 = CONCAT22((short)((uint)unaff_D7 >> 0x10),DAT_0103dac8);
  FUN_010302b2(1,local_c);
  if (iVar1 == 0x137) {
    local_8 = 3;
  }
  FUN_010300da();
  if (iVar1 == 1) {
    local_8 = 3;
  }
  DAT_0f00600f = 9;
  FUN_0103ad30();
  DAT_0f00600d = 0xc;
  FUN_0103ad30();
  FUN_01033a1e();
  uVar2 = (int)(char)DAT_0f004001 & 0xfffffff7;
  DAT_0f004001 = (byte)uVar2;
  DAT_0103da16 = 0;
  if (local_8 == 1) {
    FUN_0103311e(&local_10);
    local_8 = uVar2;
  }
  if (local_8 == 1) {
    FUN_01033490(auStack_1e);
    FUN_0103319a(&local_10,local_c);
    local_13 = (char)DAT_0103da66 + local_13 + '\x01';
    local_8 = uVar2;
    FUN_01033612(auStack_1e);
  }
  DAT_0f004001 = DAT_0f004001 | 8;
  FUN_010302b2(0,local_c);
  FUN_01048236(PTR_s_CPU_88___Real_Timer__0103cbec);
  if (local_8 == 3) {
    FUN_01048236(PTR_s_Check_Abort__0103c9b2);
  }
  else {
    FUN_01033bf6(local_10);
  }
  return;
}


// ==== FUN_0103311e @ 0103311e

/* WARNING: Removing unreachable block (ram,0x01033162) */
/* WARNING: Removing unreachable block (ram,0x01033170) */
/* WARNING: Removing unreachable block (ram,0x0103317a) */
/* WARNING: Removing unreachable block (ram,0x01033192) */

void FUN_0103311e(void)

{
                    /* WARNING: Do nothing block with infinite loop */
  do {
  } while( true );
}


// ==== FUN_0103319a @ 0103319a

int FUN_0103319a(undefined4 param_1,int param_2)

{
  int iVar1;
  int unaff_D7;
  int iVar2;
  undefined1 local_21;
  undefined1 local_20;
  undefined1 local_1f;
  undefined1 local_1e;
  undefined1 local_1d;
  undefined1 local_1c;
  undefined1 local_1b;
  undefined4 local_1a;
  undefined1 auStack_15 [13];
  int iVar3;
  
  local_21 = 99;
  local_20 = 0xc;
  local_1f = 0x1f;
  local_1b = 5;
  local_1e = 0x17;
  local_1d = 0x3b;
  local_1c = 0x39;
  FUN_0105953c(1);
  FUN_0103385e(&local_21);
  DAT_0f00600d = 0xc;
  local_1a = DAT_0103da16;
  FUN_010332ae(DAT_0103da16);
  iVar1 = 0;
  while( true ) {
    iVar3 = 1;
    if (4 < iVar1) {
      return param_2;
    }
    local_1a = DAT_0103da16;
    FUN_010300da();
    if (unaff_D7 == 1) {
      iVar3 = 3;
    }
    iVar2 = 0;
    FUN_010301f6(1,1);
    if (iVar3 != 1) break;
    FUN_01033490(auStack_15);
    FUN_01033a42(iVar1);
    FUN_01033a96(auStack_15);
    param_2 = iVar1;
    FUN_0103331a(auStack_15,local_1a,param_1);
    if (unaff_D7 != 1) {
      return param_2;
    }
    iVar1 = iVar1 + 1;
  }
  return iVar2;
}


// ==== FUN_010332ae @ 010332ae

void FUN_010332ae(int param_1,int param_2)

{
  int iVar1;
  int local_c;
  int local_8;
  
  local_8 = 300000;
  if (param_2 == 0x32) {
    iVar1 = 20000;
  }
  else {
    iVar1 = 0x413c;
  }
  while ((param_1 == DAT_0103da16 && (local_8 = local_8 + -1, local_8 != 0))) {
    FUN_0103ad30();
  }
  for (local_c = 0; local_c < iVar1; local_c = local_c + 1) {
    FUN_0103ad30();
  }
  DAT_0103da6a = 0;
  DAT_0103da6e = 0;
  return;
}


// ==== FUN_0103331a @ 0103331a

void FUN_0103331a(byte *param_1,undefined4 param_2,undefined4 *param_3,int param_4)

{
  int iVar1;
  int iVar2;
  
  iVar1 = (uint)param_1[5] +
          (uint)param_1[4] * 10 +
          (uint)param_1[3] * 100 +
          (uint)param_1[2] * 1000 + (uint)param_1[1] * 10000 + (uint)*param_1 * 100000;
  iVar2 = (uint)param_1[0xb] +
          (uint)param_1[10] * 10 +
          (uint)param_1[9] * 100 +
          (uint)param_1[8] * 1000 + (uint)param_1[7] * 10000 + (uint)param_1[6] * 100000;
  if (((*(int *)(&DAT_0103cd0a + param_4 * 4) == iVar1) &&
      (*(int *)(&DAT_0103cd1e + param_4 * 4) == iVar2)) &&
     ((uint)param_1[0xc] == *(uint *)(&DAT_0103cd32 + param_4 * 4))) {
    *param_3 = 0;
  }
  else if ((iVar1 == 0xf1fff) && (iVar2 == 0x399b6)) {
    *param_3 = 1;
  }
  else {
    *param_3 = 2;
  }
  return;
}


// ==== FUN_01033490 @ 01033490

void FUN_01033490(undefined1 *param_1)

{
  undefined1 unaff_D7b;
  
  FUN_01033596(0xc);
  *param_1 = unaff_D7b;
  FUN_01033596(0xb);
  param_1[1] = unaff_D7b;
  FUN_01033596(10);
  param_1[2] = unaff_D7b;
  FUN_01033596(9);
  param_1[3] = unaff_D7b;
  FUN_01033596(8);
  param_1[4] = unaff_D7b;
  FUN_01033596(7);
  param_1[5] = unaff_D7b;
  FUN_01033596(6);
  param_1[0xc] = unaff_D7b;
  FUN_01033596(5);
  param_1[6] = unaff_D7b;
  FUN_01033596(4);
  param_1[7] = unaff_D7b;
  FUN_01033596(3);
  param_1[8] = unaff_D7b;
  FUN_01033596(2);
  param_1[9] = unaff_D7b;
  FUN_01033596(1);
  param_1[10] = unaff_D7b;
  FUN_01033596(0);
  param_1[0xb] = unaff_D7b;
  return;
}


// ==== FUN_01033596 @ 01033596

void FUN_01033596(int param_1)

{
  byte bVar1;
  byte bVar2;
  
  bVar1 = (&DAT_0f006000)[param_1];
  FUN_0103ad30();
  bVar2 = (&DAT_0f006000)[param_1];
  FUN_0103ad30();
  if ((bVar1 & 0xf) != (bVar2 & 0xf)) {
    FUN_0103ad30();
  }
  return;
}


// ==== FUN_01033612 @ 01033612

void FUN_01033612(undefined4 param_1)

{
  undefined1 auStack_b [7];
  
  FUN_01033662(param_1,auStack_b);
  FUN_01033644();
  FUN_0103385e(auStack_b);
  DAT_0f00600d = 8;
  return;
}


// ==== FUN_01033644 @ 01033644

void FUN_01033644(void)

{
  do {
  } while (DAT_0103da66 + 1 != DAT_0103da66);
  return;
}


// ==== FUN_01033662 @ 01033662

void FUN_01033662(char *param_1,byte *param_2)

{
  param_2[5] = param_1[0xb] + param_1[10] * '\n';
  param_2[4] = param_1[9] + param_1[8] * '\n';
  param_2[3] = param_1[7] + param_1[6] * '\n';
  param_2[6] = param_1[0xc];
  param_2[2] = param_1[5] + param_1[4] * '\n';
  param_2[1] = param_1[3] + param_1[2] * '\n';
  *param_2 = param_1[1] + *param_1 * '\n';
  if (0x3b < param_2[5]) {
    param_2[5] = param_2[5] % 0x3c;
    param_2[4] = param_2[4] + 1;
  }
  if (0x3b < param_2[4]) {
    param_2[4] = param_2[4] % 0x3c;
    param_2[3] = param_2[3] + 1;
  }
  if (0x17 < param_2[3]) {
    param_2[3] = param_2[3] % 0x18;
    param_2[6] = (byte)((param_2[6] + 1) % 7);
    param_2[2] = param_2[2] + 1;
  }
  if ((uint)*param_2 % 4 == 0) {
    DAT_0103cd48 = DAT_0103cd48 + '\x01';
  }
  if ((byte)(&DAT_0103cd46)[param_2[1]] < param_2[2]) {
    param_2[2] = 1;
    param_2[1] = param_2[1] + 1;
  }
  if (0xc < param_2[1]) {
    *param_2 = *param_2 + 1;
    param_2[1] = 1;
  }
  return;
}


// ==== FUN_0103385e @ 0103385e

void FUN_0103385e(byte *param_1)

{
  DAT_0f00600e = 0;
  FUN_0103ad30();
  DAT_0f00600d = 0;
  FUN_0103ad30();
  DAT_0f00600f = 3;
  FUN_0103ad30();
  DAT_0f00600c = *param_1 / 10;
  FUN_0103ad30();
  DAT_0f00600b = *param_1 % 10;
  FUN_0103ad30();
  DAT_0f00600a = param_1[1] / 10;
  FUN_0103ad30();
  DAT_0f006009 = param_1[1] % 10;
  FUN_0103ad30();
  DAT_0f006008 = param_1[2] / 10;
  FUN_0103ad30();
  DAT_0f006007 = param_1[2] % 10;
  FUN_0103ad30();
  DAT_0f006006 = param_1[6];
  FUN_0103ad30();
  DAT_0f006005 = param_1[3] / 10;
  FUN_0103ad30();
  DAT_0f006004 = param_1[3] % 10;
  FUN_0103ad30();
  DAT_0f006003 = param_1[4] / 10;
  FUN_0103ad30();
  DAT_0f006002 = param_1[4] % 10;
  FUN_0103ad30();
  DAT_0f006001 = param_1[5] / 10;
  FUN_0103ad30();
  DAT_0f006000 = param_1[5] % 10;
  FUN_0103ad30();
  DAT_0f00600f = 9;
  FUN_0103ad30();
  return;
}


// ==== FUN_01033a1e @ 01033a1e

void FUN_01033a1e(void)

{
  DAT_0f004001 = DAT_0f004001 | 8;
  *(undefined1 **)(DAT_01092c58 + 0x14c) = &LAB_01030740;
  return;
}


// ==== FUN_01033a42 @ 01033a42

void FUN_01033a42(int param_1)

{
  int local_8;
  
  FUN_010301b4();
  for (local_8 = 0; local_8 < 0x18; local_8 = local_8 + 1) {
    (&DAT_0103da76)[local_8] = (&PTR_s__99__12__31_5_23_59_59_0103cc78)[param_1][local_8];
  }
  FUN_0105946e(1,&DAT_0103da76);
  return;
}


// ==== FUN_01033a96 @ 01033a96

void FUN_01033a96(byte *param_1)

{
  DAT_0103da95 = 0x27;
  DAT_0103da96 = "0123456789"[*param_1];
  DAT_0103da97 = "0123456789"[param_1[1]];
  DAT_0103da98 = 0x2e;
  DAT_0103da9a = "0123456789"[param_1[2]];
  DAT_0103da9b = "0123456789"[param_1[3]];
  DAT_0103da9c = 0x2e;
  DAT_0103da9e = "0123456789"[param_1[4]];
  DAT_0103da9f = "0123456789"[param_1[5]];
  DAT_0103daa2 = "0123456789"[param_1[0xc]];
  DAT_0103daa5 = "0123456789"[param_1[6]];
  DAT_0103daa6 = "0123456789"[param_1[7]];
  DAT_0103daa7 = 0x3a;
  DAT_0103daa8 = "0123456789"[param_1[8]];
  DAT_0103daa9 = "0123456789"[param_1[9]];
  DAT_0103daaa = 0x3a;
  DAT_0103daab = "0123456789"[param_1[10]];
  DAT_0103daac = "0123456789"[param_1[0xb]];
  FUN_010594e2(1,&DAT_0103da95);
  return;
}


// ==== FUN_01033bf6 @ 01033bf6

undefined1 * FUN_01033bf6(int param_1)

{
  int iVar1;
  undefined1 *puVar2;
  undefined1 local_56 [82];
  
  local_56[0x50] = 0;
  local_56[0x51] = 0;
  for (iVar1 = 0; iVar1 < 0x50; iVar1 = iVar1 + 1) {
    local_56[iVar1] = 0x20;
  }
  for (iVar1 = 0; iVar1 < 10; iVar1 = iVar1 + 1) {
    local_56[iVar1 + 9] = **(undefined1 **)((int)&DAT_0103cc3a + iVar1);
    local_56[iVar1 + 0x26] = **(undefined1 **)((int)&DAT_0103cc3e + iVar1);
    local_56[iVar1 + 0x3b] = **(undefined1 **)(&DAT_0103cc42 + iVar1);
  }
  FUN_01058f82(1,0x13,local_56);
  FUN_01048236(&DAT_01033bf4);
  FUN_01048236(local_56);
  for (iVar1 = 0; iVar1 < 0xc; iVar1 = iVar1 + 1) {
    (&DAT_0103dab1)[iVar1] = *(undefined1 *)(*(int *)(&DAT_0103cc06 + param_1 * 4) + iVar1);
  }
  FUN_01058f82(1,0x14,&DAT_0103da76);
  puVar2 = &DAT_0103da76;
  FUN_01048236();
  return puVar2;
}


// ==== FUN_01033cde @ 01033cde

void FUN_01033cde(void)

{
  int unaff_D7;
  int iVar1;
  undefined *puVar2;
  undefined4 uVar3;
  int iVar4;
  int local_c6;
  undefined1 auStack_c2 [4];
  char local_be;
  char local_bd;
  int local_bc;
  undefined1 auStack_b8 [4];
  int iStack_b4;
  undefined1 auStack_b0 [2];
  int aiStack_ae [42];
  
  local_be = '\x01';
  iVar4 = 1;
  for (local_c6 = 0; local_c6 < 4; local_c6 = local_c6 + 1) {
    *(undefined4 *)(auStack_b8 + local_c6 * 0x16 + 4) = 0;
    auStack_b0[local_c6 * 0x16] = 0;
    *(undefined4 *)((int)aiStack_ae + local_c6 * 0x16) = 0;
    *(undefined4 *)((int)aiStack_ae + local_c6 * 0x16 + 4) = 0;
    *(undefined4 *)((int)aiStack_ae + local_c6 * 0x16 + 8) = 1;
    unaff_D7 = local_c6 * 0x16;
    *(undefined4 *)((int)aiStack_ae + unaff_D7 + 0xc) = 0;
  }
  for (local_c6 = 4; local_c6 < 8; local_c6 = local_c6 + 1) {
    *(undefined4 *)(auStack_b8 + local_c6 * 0x16 + 4) = 1;
    auStack_b0[local_c6 * 0x16] = 0;
    *(undefined4 *)((int)aiStack_ae + local_c6 * 0x16) = 0;
    *(undefined4 *)((int)aiStack_ae + local_c6 * 0x16 + 4) = 0;
    *(undefined4 *)((int)aiStack_ae + local_c6 * 0x16 + 8) = 1;
    unaff_D7 = local_c6 * 0x16;
    *(undefined4 *)((int)aiStack_ae + unaff_D7 + 0xc) = 0;
  }
  local_bd = '\x14';
  FUN_01059738(1);
  if (local_be != '\0') {
    for (local_c6 = 0; local_c6 < 2; local_c6 = local_c6 + 1) {
      FUN_010300da();
      if (unaff_D7 == 1) {
        iVar4 = 3;
        local_be = '\0';
        FUN_010463de(local_c6,auStack_c2);
        local_bc = 1;
        break;
      }
      puVar2 = (&PTR_DAT_0103cdbc)[*(int *)(auStack_b8 + local_c6 * 0x58 + 4)];
      iVar1 = (int)local_bd + local_c6 * 2;
      FUN_0105977a(1,iVar1,puVar2);
      FUN_010463aa(local_c6,auStack_c2);
      local_bc = iVar1;
      FUN_0103002a(0x5dc);
      FUN_010300da();
      if (iVar1 == 1) {
        iVar4 = 3;
        local_be = '\0';
        FUN_010463de(local_c6,auStack_c2,puVar2,3);
        local_bc = 1;
        break;
      }
      uVar3 = 0;
      FUN_0103452a(local_bc,0);
      aiStack_ae[local_c6 * 0x16 + 3] = iVar1;
      iVar1 = local_c6 * 0x58;
      if (aiStack_ae[local_c6 * 0x16 + 3] == 100) {
        FUN_01045ff8(local_c6,auStack_c2);
        local_bc = iVar1;
        FUN_0103002a(0x5dc);
        FUN_010300da();
        if (iVar1 == 1) {
          iVar4 = 3;
          local_be = '\0';
          FUN_010463de(local_c6,auStack_c2,uVar3,3);
          local_bc = 1;
          break;
        }
        FUN_0104625c(local_c6,auStack_b8,auStack_c2);
        FUN_01034056(auStack_b8);
        if (iVar1 == 1) {
          iVar4 = local_c6 * 0x58;
          FUN_0103405a(auStack_b8,auStack_b8 + iVar4 + 4);
          if (iVar4 == 3) {
            local_be = '\0';
          }
        }
        else {
          aiStack_ae[local_c6 * 0x16 + 3] = 0x37;
          FUN_010346fc(auStack_b8 + local_c6 * 0x58 + 4);
        }
      }
      else {
        iVar4 = 2;
        FUN_010346fc(auStack_b8 + local_c6 * 0x58 + 4,uVar3,2);
      }
      unaff_D7 = local_c6 * 0x58;
      FUN_010463de(local_c6,auStack_c2);
      local_bc = unaff_D7;
      if (local_be == '\0') break;
    }
  }
  FUN_010347ac(&iStack_b4,iVar4);
  return;
}


// ==== FUN_01034056 @ 01034056

void FUN_01034056(void)

{
  return;
}


// ==== FUN_0103405a @ 0103405a

void FUN_0103405a(uint *param_1,int param_2)

{
  *(undefined4 *)(param_2 + 6) = 0;
  *(undefined4 *)(param_2 + 10) = 0;
  *(undefined4 *)(param_2 + 0xe) = 1;
  FUN_010341be(param_2,1);
  if ((*(int *)(param_2 + 0x12) != 0x34) && (*(int *)(param_2 + 0x12) != 3)) {
    *(undefined4 *)(param_2 + 0x1c) = 1;
    *(undefined4 *)(param_2 + 0x20) = 1;
    *(undefined4 *)(param_2 + 0x24) = 1;
    FUN_010341be(param_2 + 0x16);
    if ((*(int *)(param_2 + 0x28) != 0x34) && (*(int *)(param_2 + 0x28) != 3)) {
      *(undefined4 *)(param_2 + 0x32) = 1;
      *(uint *)(param_2 + 0x36) = ((*param_1 & 0xffff) >> 9) - 1;
      *(undefined4 *)(param_2 + 0x3a) = 1;
      FUN_010341be(param_2 + 0x2c);
      if ((*(int *)(param_2 + 0x3e) != 0x34) && (*(int *)(param_2 + 0x3e) != 3)) {
        *(undefined4 *)(param_2 + 0x48) = 0;
        *(uint *)(param_2 + 0x4c) = ((*param_1 & 0xffff) >> 9) - 2;
        *(undefined4 *)(param_2 + 0x50) = 1;
        FUN_010341be(param_2 + 0x42);
      }
    }
  }
  return;
}


// ==== FUN_010341be @ 010341be

uint FUN_010341be(undefined4 *param_1)

{
  uint uVar1;
  uint uVar2;
  uint unaff_D7;
  uint uVar3;
  undefined1 auStack_28 [4];
  undefined4 local_24;
  undefined4 local_20;
  undefined4 local_1c;
  undefined4 local_18;
  undefined4 local_14;
  
  FUN_010456d4(0x200);
  FUN_010456d4(0x200);
  FUN_010456d4(0x200);
  local_14 = *param_1;
  local_18 = *(undefined4 *)((int)param_1 + 10);
  local_1c = *(undefined4 *)((int)param_1 + 6);
  local_20 = *(undefined4 *)((int)param_1 + 0xe);
  local_24 = 1;
  uVar2 = 0;
  uVar3 = unaff_D7;
  while (uVar1 = uVar2, uVar1 < 0x200) {
    **(undefined1 **)(auStack_28 + uVar1 + 0x1c) = (char)uVar1;
    uVar3 = uVar1;
    uVar2 = uVar1 + 1;
  }
  FUN_010300da();
  if (uVar3 == 1) {
    *(undefined4 *)((int)param_1 + 0x12) = 3;
  }
  else {
    *(undefined1 *)(param_1 + 1) = 0;
    FUN_0104606c(local_14,local_18,local_1c,local_20,local_24,unaff_D7,auStack_28);
    FUN_0103452a(uVar3,0);
    *(uint *)((int)param_1 + 0x12) = uVar3;
    FUN_010345c6(param_1);
    FUN_010346fc(param_1);
    if (*(int *)((int)param_1 + 0x12) == 100) {
      FUN_010300da();
      if (uVar3 == 1) {
        *(undefined4 *)((int)param_1 + 0x12) = 3;
      }
      else {
        *(undefined1 *)(param_1 + 1) = 1;
        FUN_01046312(local_14);
        if (uVar3 == 0) {
          *(undefined4 *)((int)param_1 + 0x12) = 0x34;
          FUN_010345c6(param_1);
          FUN_010346fc(param_1);
        }
        else {
          FUN_010300da();
          if (uVar3 == 1) {
            *(undefined4 *)((int)param_1 + 0x12) = 3;
          }
          else {
            FUN_010460ae(local_14,local_18,local_1c,local_20,local_24,unaff_D7,auStack_28);
            FUN_0103452a(uVar3,0);
            *(uint *)((int)param_1 + 0x12) = uVar3;
            FUN_010345c6(param_1);
            FUN_010346fc(param_1);
            if (*(int *)((int)param_1 + 0x12) == 100) {
              FUN_010300da();
              if (uVar3 == 1) {
                *(undefined4 *)((int)param_1 + 0x12) = 3;
              }
              else {
                *(undefined1 *)(param_1 + 1) = 0;
                FUN_0104606c(local_14,local_18,local_1c,local_20,local_24,unaff_D7,auStack_28);
                FUN_0103452a(uVar3,0);
                *(uint *)((int)param_1 + 0x12) = uVar3;
                for (uVar2 = 0; uVar2 < 0x200; uVar2 = uVar2 + 1) {
                  uVar3 = CONCAT31((int3)(uVar2 >> 8),**(char **)(auStack_28 + uVar2 + 0x18));
                  if (**(char **)(auStack_28 + uVar2 + 0x18) !=
                      **(char **)(auStack_28 + uVar2 + 0x1c)) {
                    *(undefined4 *)((int)param_1 + 0x12) = 0x39;
                    break;
                  }
                }
                FUN_010345c6(param_1);
                FUN_010346fc(param_1);
                FUN_010300da();
                if (uVar3 == 1) {
                  *(undefined4 *)((int)param_1 + 0x12) = 3;
                }
              }
              FUN_010460ae(local_14,local_18,local_1c,local_20,local_24,unaff_D7,auStack_28);
              if (*(int *)((int)param_1 + 0x12) != 3) {
                FUN_010300da();
                if (uVar3 == 1) {
                  *(undefined4 *)((int)param_1 + 0x12) = 3;
                }
              }
            }
          }
        }
      }
    }
  }
  FUN_01045712(unaff_D7);
  FUN_01045712(unaff_D7);
  FUN_01045712();
  return unaff_D7;
}


// ==== FUN_0103452a @ 0103452a

void FUN_0103452a(undefined4 param_1,char param_2)

{
  FUN_010307fa(param_1,param_2,100);
  if (param_2 == '\0') {
    return;
  }
  if (param_2 == '\0') {
    FUN_0105ef12();
    return;
  }
  FUN_0105ef12();
  return;
}


// ==== FUN_010345c6 @ 010345c6

void FUN_010345c6(int *param_1)

{
  int local_8;
  
  FUN_010301b4();
  DAT_0103da78 = *(&PTR_DAT_0103cdbc)[*param_1];
  for (local_8 = 0; local_8 < 6; local_8 = local_8 + 1) {
    (&UNK_0103da81)[local_8] = (&PTR_s_READ_0103cdc8)[*(byte *)(param_1 + 1)][local_8];
  }
  if ((*(int *)((int)param_1 + 0x12) != 0x34) && (*(int *)((int)param_1 + 0x12) != 0x33)) {
    FUN_0105ec54(1,*(undefined4 *)((int)param_1 + 6),1,&DAT_0103da87);
    DAT_0103da88 = 0x20;
    FUN_0105ec54(1,*(undefined4 *)((int)param_1 + 10),3,&DAT_0103da8d);
    DAT_0103da90 = 0x20;
    FUN_0105ec54(1,*(undefined4 *)((int)param_1 + 0xe),2,&DAT_0103da94);
    DAT_0103da96 = 0x20;
  }
  FUN_01058f82(1,(int)(char)(*(char *)(param_1 + 1) + (char)*param_1 * '\x02' + '\x14'),
               &DAT_0103da78);
  return;
}


// ==== FUN_010346fc @ 010346fc

void FUN_010346fc(undefined4 *param_1)

{
  int local_e;
  int local_8;
  
  FUN_010301b4();
  if ((*(int *)((int)param_1 + 0x12) == 100) || (*(int *)((int)param_1 + 0x12) == 0)) {
    local_e = 0;
  }
  else {
    local_e = *(int *)((int)param_1 + 0x12) + -0x32;
  }
  for (local_8 = 0; local_8 < 0x10; local_8 = local_8 + 1) {
    (&DAT_0103da9c)[local_8] = *(undefined1 *)(*(int *)(&DAT_0103cdde + local_e * 4) + local_8);
  }
  FUN_010599aa(1,(int)(char)(*(char *)(param_1 + 1) + (char)*param_1 * '\x02' + '\x14'),
               &DAT_0103da9c);
  return;
}


// ==== FUN_010347ac @ 010347ac

void FUN_010347ac(int param_1,int param_2)

{
  int local_18;
  int local_c;
  int local_8;
  
  FUN_010301b4();
  for (local_8 = 0; local_8 < 0x14; local_8 = local_8 + 1) {
    (&DAT_0103da76)[local_8] = **(undefined1 **)((int)&PTR_s_CPU_88___MFD_Block__0103cda4 + local_8)
    ;
  }
  FUN_01048236(&DAT_0103da76);
  if (param_2 == 3) {
    FUN_010301b4();
    for (local_8 = 0; local_8 < 0xc; local_8 = local_8 + 1) {
      (&DAT_0103da76)[local_8] = **(undefined1 **)((int)&PTR_s_Check_Abort__0103c9b2 + local_8);
    }
    FUN_01048236(&DAT_0103da76);
  }
  else {
    FUN_01034996();
    local_18 = 4;
    if ((*(int *)(param_1 + 0x12) == 0x34) || (*(int *)(param_1 + 0x12) == 0x33)) {
      local_18 = 1;
    }
    else if ((*(int *)(param_1 + 0x12) == 100) &&
            (((*(int *)(param_1 + 0x28) == 100 && (*(int *)(param_1 + 0x3e) == 100)) &&
             (*(int *)(param_1 + 0x54) == 100)))) {
      local_18 = 1;
    }
    for (local_c = 0; local_c < local_18; local_c = local_c + 1) {
      FUN_01034a64(*(undefined4 *)((int)&param_1 + local_c * 0x16),local_18);
    }
    local_18 = 8;
    if ((*(int *)(param_1 + 0x6a) == 0x34) || (*(int *)(param_1 + 0x6a) == 0x33)) {
      local_18 = 5;
    }
    else if (((*(int *)(param_1 + 0x6a) == 100) &&
             ((*(int *)(param_1 + 0x80) == 100 && (*(int *)(param_1 + 0x96) == 100)))) &&
            (*(int *)(param_1 + 0xac) == 100)) {
      local_18 = 5;
    }
    for (local_c = 4; local_c < local_18; local_c = local_c + 1) {
      FUN_01034a64(*(undefined4 *)((int)&param_1 + local_c * 0x16),local_18);
    }
  }
  return;
}


// ==== FUN_01034996 @ 01034996

void FUN_01034996(void)

{
  int local_8;
  
  FUN_010301b4();
  FUN_01048236(&DAT_0103da76);
  for (local_8 = 0; local_8 < 6; local_8 = local_8 + 1) {
    (&DAT_0103da78)[local_8] = **(undefined1 **)((int)&PTR_s_DRIVE_0103ce9c + local_8);
    (&UNK_0103da81)[local_8] = **(undefined1 **)((int)&PTR_s_MODE_0103cea0 + local_8);
    (&DAT_0103da87)[local_8] = **(undefined1 **)((int)&PTR_s_SIDE_0103cea4 + local_8);
    (&DAT_0103da8d)[local_8] = **(undefined1 **)((int)&PTR_s_TRACK_0103cea8 + local_8);
    (&DAT_0103da94)[local_8] = **(undefined1 **)((int)&PTR_s_SECTOR_0103ceac + local_8);
    (&DAT_0103da9c)[local_8] = **(undefined1 **)((int)&PTR_s_RESULT_0103ceb0 + local_8);
  }
  FUN_01048236(&DAT_0103da76);
  return;
}


// ==== FUN_01034a64 @ 01034a64

void FUN_01034a64(int *param_1,int param_2)

{
  int local_c;
  int local_8;
  
  FUN_010301b4();
  DAT_0103da78 = *(&PTR_DAT_0103cdbc)[*param_1];
  if ((*(int *)((int)param_1 + 0x12) == 0) || (*(int *)((int)param_1 + 0x12) == 0x33)) {
    if (*(int *)((int)param_1 + 0x12) == 0x33) {
      for (local_8 = 0; local_8 < 0x10; local_8 = local_8 + 1) {
        (&DAT_0103da9c)[local_8] =
             *(undefined1 *)
              (*(int *)(&DAT_0103cdde + (*(int *)((int)param_1 + 0x12) + -0x32) * 4) + local_8);
      }
    }
  }
  else {
    if ((*(int *)((int)param_1 + 0x12) != 0x34) && (param_2 % 4 != 1)) {
      for (local_8 = 0; local_8 < 6; local_8 = local_8 + 1) {
        (&UNK_0103da81)[local_8] = (&PTR_s_READ_0103cdc8)[*(byte *)(param_1 + 1)][local_8];
      }
      FUN_0105ec54(1,*(undefined4 *)((int)param_1 + 6),1,&DAT_0103da87);
      DAT_0103da88 = 0x20;
      FUN_0105ec54(1,*(undefined4 *)((int)param_1 + 10),3,&DAT_0103da8d);
      DAT_0103da90 = 0x20;
      FUN_0105ec54(1,*(undefined4 *)((int)param_1 + 0xe),2,&DAT_0103da94);
      DAT_0103da96 = 0x20;
    }
    if (*(int *)((int)param_1 + 0x12) == 100) {
      local_c = 0;
    }
    else {
      local_c = *(int *)((int)param_1 + 0x12) + -0x32;
    }
    for (local_8 = 0; local_8 < 0x10; local_8 = local_8 + 1) {
      (&DAT_0103da9c)[local_8] = *(undefined1 *)(*(int *)(&DAT_0103cdde + local_c * 4) + local_8);
    }
  }
  if (*(int *)((int)param_1 + 0x12) != 0) {
    FUN_01048236(&DAT_0103da76);
  }
  return;
}


// ==== FUN_01034c4c @ 01034c4c

void FUN_01034c4c(void)

{
  int unaff_D7;
  uint uVar1;
  byte local_d;
  uint local_c;
  
  FUN_01059172(1);
  FUN_01030352(1,0x14);
  FUN_01034f68(&local_d);
  FUN_01030352(0,0x14);
  FUN_01048236("CPU-88 : LED & DIP-SW - No Auto Checked.");
  uVar1 = (uint)local_d;
  FUN_0105ee14(1,uVar1,2,"   CPU-88 : Memories.");
  FUN_01048236("  DIP-SW =    CPU-88 : Memories.");
  if (unaff_D7 != 9) {
    return;
  }
  do {
    FUN_0103010c();
    local_c = uVar1;
  } while (uVar1 == 0);
  FUN_0105ef12();
  return;
}


// ==== FUN_01034cfe @ 01034cfe

void FUN_01034cfe(undefined1 *param_1)

{
  undefined1 auStack_8 [2];
  undefined1 local_6;
  undefined1 local_5;
  
  *param_1 = DAT_0f00b002;
  FUN_0105ee14(0,*param_1,2,auStack_8);
  local_6 = 0;
  local_5 = 0;
  FUN_0105922e(1,auStack_8);
  FUN_01034dd6(*param_1);
  FUN_01058f82(1,0x16,"  ON  ON  ON    NTSC " + (uint)DAT_0103dac8 * 0x18);
  FUN_01034e5e(*param_1);
  FUN_01034eec(*param_1);
  return;
}


// ==== FUN_01034dd6 @ 01034dd6

void FUN_01034dd6(void)

{
  FUN_0105ef12();
  return;
}


// ==== FUN_01034e5e @ 01034e5e

void FUN_01034e5e(void)

{
  FUN_0105ef12();
  return;
}


// ==== FUN_01034eec @ 01034eec

void FUN_01034eec(void)

{
  FUN_0105ef12();
  return;
}


// ==== FUN_01034f68 @ 01034f68

void FUN_01034f68(undefined4 param_1)

{
  bool bVar1;
  int iVar2;
  int local_e;
  int local_a;
  byte local_5;
  
  bVar1 = true;
  DAT_0103da56 = 0;
  DAT_0103da5a = 0;
  iVar2 = -1;
  DAT_0f00b003 = 0xff;
  do {
    if (!bVar1) {
      return;
    }
    local_5 = 1;
    for (local_a = 0; local_a < 8; local_a = local_a + 1) {
      FUN_01034cfe(param_1);
      for (local_e = 0; local_e < 2; local_e = local_e + 1) {
        FUN_01035056();
        if (iVar2 != 9) {
          return;
        }
      }
      DAT_0f00b003 = ~local_5;
      iVar2 = (uint)local_5 << 1;
      local_5 = (byte)iVar2;
    }
    FUN_01035056();
    if (iVar2 != 9) {
      bVar1 = false;
    }
  } while( true );
}


// ==== FUN_01035056 @ 01035056

void FUN_01035056(void)

{
  FUN_010301f6(2,1,1,9);
  FUN_0105ef12();
  return;
}


// ==== FUN_01035106 @ 01035106

void FUN_01035106(void)

{
  int unaff_D7;
  
  FUN_01058f82(1,0x15," and  \'ENTER\' key to Check ! ");
  FUN_01058f82(1,0x17," or   \'Sheft\'+\'ENTER\' key to Pass ! ");
  do {
    FUN_01030156();
  } while (unaff_D7 == 0);
  FUN_0105ef12();
  return;
}


// ==== FUN_0103520a @ 0103520a

void FUN_0103520a(void)

{
  FUN_01058f82(1,0x13,"Please NTSC(525) Reference Video Input");
  FUN_01035106("<<NTSC(525) Reference Video Test>>");
  return;
}


// ==== FUN_0103527a @ 0103527a

void FUN_0103527a(void)

{
  FUN_01058f82(1,0x13,"Please PAL(625) Reference Video Input");
  FUN_01035106("<<PAL(625) Reference Video Test>>");
  return;
}


// ==== FUN_01035330 @ 01035330

void FUN_01035330(void)

{
  int unaff_D7;
  
  FUN_01058f82(1,0x13,"Please Reference Video Input !! ");
  FUN_01058f82(1,0x15," and  \'ENTER\' key to Check ! ");
  FUN_01058f82(1,0x17," or   \'Sheft\'+\'ENTER\' key to Pass ! ");
  do {
    FUN_01030156();
  } while (unaff_D7 == 0);
  FUN_0105ef12();
  return;
}


// ==== FUN_010353e2 @ 010353e2

void FUN_010353e2(void)

{
  DAT_0ff01fd3 = 8;
  DAT_0103dac8 = 0;
  return;
}


// ==== FUN_01035400 @ 01035400

void FUN_01035400(void)

{
  DAT_0ff01fd3 = 0;
  DAT_0103dac8 = 3;
  return;
}


// ==== FUN_0103541e @ 0103541e

void FUN_0103541e(void)

{
  return;
}


// ==== FUN_0103543c @ 0103543c

void FUN_0103543c(void)

{
  uint uVar1;
  uint uVar2;
  undefined1 *local_10;
  uint local_c;
  undefined4 local_8;
  
  local_8 = 1;
  uVar1 = (uint)DAT_0f00b002;
  FUN_01034dd6(uVar1);
  FUN_010300da();
  if (uVar1 == 1) {
    local_8 = 3;
  }
  else {
    FUN_01035538();
    if (uVar1 == 0) {
      local_10 = &DAT_0ff01ff7;
      uVar2 = 0;
    }
    else {
      if (((DAT_0ff01fd7 & 0xf0) == 0x10) || (uVar2 = DAT_0ff01fd7 & 0xf0, uVar2 == 0x30)) {
        FUN_0103058e();
        local_c = 8;
        goto LAB_010354ce;
      }
      local_10 = (undefined1 *)0xff01e09;
    }
    FUN_010300da();
    if (uVar2 == 1) {
      local_8 = 3;
      local_c = uVar1;
    }
    else {
      FUN_01035646(local_10);
      local_c = uVar2 * 2 + uVar1;
      FUN_01035672();
      FUN_010300da();
      if (uVar2 == 1) {
        local_8 = 3;
      }
    }
  }
LAB_010354ce:
  FUN_01035696(local_c,local_8);
  FUN_0103578e();
  return;
}


// ==== FUN_01035538 @ 01035538

void FUN_01035538(void)

{
  undefined4 auStack_20 [4];
  int local_10;
  undefined4 local_c;
  undefined4 local_8;
  
  local_8 = 3;
  local_10 = 0;
  for (local_c = 0; local_c < 8; local_c = local_c + 1) {
    *(undefined2 *)((int)auStack_20 + local_c * 2) =
         **(undefined2 **)((int)auStack_20 + (local_c + -2) * 2);
    FUN_0103002a(1);
  }
  for (local_c = 0; local_c < 8; local_c = local_c + 1) {
    **(undefined2 **)((int)auStack_20 + (local_c + -2) * 2) = local_c._2_2_;
    FUN_0103002a(0xf);
  }
  for (local_c = 0; local_c < 8; local_c = local_c + 1) {
    if ((**(ushort **)((int)auStack_20 + (local_c + -2) * 2) & 0xff) == local_c._2_2_) {
      local_10 = local_10 + 1;
    }
    FUN_0103002a(1);
  }
  for (local_c = 0; local_c < 8; local_c = local_c + 1) {
    **(undefined2 **)((int)auStack_20 + (local_c + -2) * 2) =
         *(undefined2 *)((int)auStack_20 + local_c * 2);
    FUN_0103002a(0xf);
  }
  return;
}


// ==== FUN_01035646 @ 01035646

void FUN_01035646(void)

{
  return;
}


// ==== FUN_01035672 @ 01035672

void FUN_01035672(void)

{
  return;
}


// ==== FUN_01035696 @ 01035696

void FUN_01035696(int param_1,int param_2)

{
  FUN_01048236("SPF : Board Name Check.");
  if (param_2 == 3) {
    FUN_01048236(PTR_s_Check_Abort__0103c9b2);
  }
  else {
    if ((((DAT_0103dac8 == 0) && (param_1 != 0)) && (param_1 != 3)) && (param_1 != 8)) {
      DAT_0103da02 = 7;
    }
    else {
      DAT_0103da02 = param_1;
    }
    FUN_01058f82(1,0x15,"  SPF-1  Mounted." + DAT_0103da02 * 0x12 + 2);
    FUN_01048236(&DAT_01035694);
    FUN_01048236("  SPF-1  Mounted." + DAT_0103da02 * 0x12);
    FUN_0103002a(1000);
  }
  return;
}


// ==== FUN_0103578e @ 0103578e

void FUN_0103578e(void)

{
  FUN_0105ef12();
  return;
}


// ==== FUN_01035814 @ 01035814

void FUN_01035814(void)

{
  DAT_0ff01e05 = DAT_0103dac8 == 4;
  return;
}


// ==== FUN_0103585c @ 0103585c

/* WARNING: Removing unreachable block (ram,0x010358c2) */

void FUN_0103585c(void)

{
  int unaff_D7;
  int iVar1;
  undefined4 uVar2;
  
  uVar2 = 1;
  iVar1 = 1;
  if (DAT_0103da02 != 7) {
    FUN_010302b2(1,1);
    if (unaff_D7 == 0x137) {
      iVar1 = 0;
      uVar2 = 2;
    }
    if (iVar1 != 0) {
      FUN_0103010c();
      FUN_0105ef12(iVar1,uVar2);
      return;
    }
    FUN_010302b2(0,1);
  }
  FUN_01048236("SPF : Color Frame Check - No Auto Checked.");
  return;
}


// ==== FUN_010358fc @ 010358fc

void FUN_010358fc(void)

{
  FUN_01059a14(1);
  FUN_01059a5c(1,0x14,"  ON  ON  ON    NTSC " + (uint)DAT_0103dac8 * 0x18 + 0x10);
  return;
}


// ==== FUN_010359a6 @ 010359a6

void FUN_010359a6(void)

{
  FUN_0105ef12();
  return;
}


// ==== FUN_01035b18 @ 01035b18

void FUN_01035b18(byte param_1,char param_2)

{
  undefined1 local_10 [4];
  undefined4 local_c;
  int local_8;
  
  local_c = 1;
  for (local_8 = 0; local_8 < 4; local_8 = local_8 + 1) {
    local_10[local_8] = 0;
  }
  if ((param_1 & 8) == 8) {
    local_10[0] = 0x31;
  }
  else {
    local_10[0] = 0x30;
    local_c = 0;
  }
  FUN_01059aca(1,param_2 + '\x14',local_10);
  return;
}


// ==== FUN_01035b8e @ 01035b8e

void FUN_01035b8e(byte param_1,int param_2)

{
  uint uVar1;
  
  uVar1 = param_1 & 7;
  if (param_2 == 1) {
    if (((DAT_0103dac8 == 0) || (DAT_0103dac8 == 2)) && (3 < uVar1)) {
      FUN_01059bac(1,uVar1 + 0x14,"  1(Valid)    " + (uVar1 + 4) * 0x10 + 2);
    }
    else {
      FUN_01059bac(1,uVar1 + 0x14,"  1(Valid)    " + uVar1 * 0x10 + 2);
    }
  }
  else {
    FUN_01059bac(1,uVar1 + 0x14,"XXX(Invalid)");
  }
  return;
}


// ==== FUN_01035c46 @ 01035c46

void FUN_01035c46(byte param_1,int param_2,char param_3)

{
  byte local_5;
  
  if (param_2 == 1) {
    local_5 = (byte)((int)(param_1 & 0x30) >> 4);
  }
  else {
    local_5 = 4;
  }
  FUN_01059b3a(1,param_3 + '\x14',"EARLY" + (uint)local_5 * 6);
  return;
}


// ==== FUN_01035ca6 @ 01035ca6

void FUN_01035ca6(byte param_1,int param_2,char param_3)

{
  byte local_5;
  
  if (param_2 == 1) {
    local_5 = (byte)((int)(param_1 & 0x40) >> 6);
  }
  else {
    local_5 = 2;
  }
  FUN_01059c1e(1,param_3 + '\x14',&UNK_0103d0f1 + (uint)local_5 * 6);
  return;
}


// ==== FUN_01035d3e @ 01035d3e

void FUN_01035d3e(void)

{
  undefined1 uVar1;
  undefined1 uVar2;
  undefined2 uVar3;
  undefined4 unaff_D7;
  uint uVar4;
  int iVar5;
  
  uVar3 = (undefined2)((uint)unaff_D7 >> 0x10);
  uVar4 = CONCAT22(uVar3,DAT_0103dac8);
  if ((((DAT_0103dac8 != 4) && (DAT_0103dac8 != 0)) &&
      (uVar4 = CONCAT22(uVar3,DAT_0103dac8), DAT_0103dac8 != 3)) &&
     ((uVar4 = CONCAT22(uVar3,DAT_0103dac8), DAT_0103dac8 != 1 &&
      (uVar4 = CONCAT22(uVar3,DAT_0103dac8), DAT_0103dac8 != 2)))) {
    uVar4 = (uint)DAT_0f00b002;
    FUN_01034dd6(uVar4);
  }
  uVar2 = DAT_0f004001;
  FUN_0103ad44();
  uVar1 = DAT_0f003001;
  iVar5 = CONCAT31((int3)(uVar4 >> 8),DAT_0f003001);
  FUN_0103ad44();
  DAT_0f004001 = 0xff;
  FUN_0103ad44();
  DAT_0f003001 = 0xff;
  FUN_0103ad44();
  FUN_01030352(1,200);
  if (iVar5 == 0x136) {
    FUN_0105ef12();
    return;
  }
  FUN_01030352(0,200);
  DAT_0f004001 = uVar2;
  FUN_0103ad44();
  DAT_0f003001 = uVar1;
  FUN_0103ad44();
  return;
}


// ==== FUN_01035f1e @ 01035f1e

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_01035f1e(void)

{
  undefined1 auStack_1e [8];
  undefined1 auStack_16 [16];
  short local_6;
  
  if ((DAT_0103dac8 == 3) || (DAT_0103dac8 == 2)) {
    local_6 = 0x271;
  }
  else {
    local_6 = 0x20d;
  }
  _DAT_0103da12 = 0;
  _DAT_0103da0e = 0;
  _DAT_0103da0a = 0;
  _DAT_0103da06 = 0;
  FUN_01036e84();
  DAT_0103da2e = 2;
  FUN_010364ec(local_6);
  DAT_0f003001 = DAT_0f003001 & 0xf7;
  FUN_0103ad44();
  if (local_6 == 0x271) {
    FUN_0103002a(400);
  }
  else {
    FUN_0103002a(300);
  }
  _DAT_0103da12 = 0;
  _DAT_0103da0e = 0;
  _DAT_0103da0a = 0;
  _DAT_0103da06 = 0;
  FUN_0103602e(auStack_16,auStack_1e);
  if (DAT_0103da02 == 8) {
    FUN_01036ef4(auStack_16,auStack_1e,local_6,4);
  }
  else {
    FUN_01036ef4(auStack_16,auStack_1e,local_6,3);
  }
  return;
}


// ==== FUN_0103602e @ 0103602e

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0103602e(undefined4 *param_1,short *param_2)

{
  short *psVar1;
  short *psVar2;
  short *psVar3;
  int local_8;
  
  psVar3 = param_2 + 1;
  psVar1 = param_2 + 2;
  psVar2 = param_2 + 3;
  for (local_8 = 500000; local_8 != 0; local_8 = local_8 + -1) {
    if (_DAT_0103da12 == 0) {
      DAT_0ff01fef = 0;
      FUN_0103ad44();
      *(undefined1 *)((int)param_2 + 1) = DAT_0ff01fe9;
      FUN_0103ad44();
      *(undefined1 *)param_2 = DAT_0ff01fe9;
      FUN_0103ad44();
      if (*param_2 < 1) {
        *param_1 = DAT_0103da26;
        _DAT_0103da12 = 1;
      }
      *param_2 = 0;
    }
    if (_DAT_0103da0e == 0) {
      DAT_0ff01fef = 0x40;
      FUN_0103ad44();
      *(undefined1 *)((int)param_2 + 3) = DAT_0ff01feb;
      FUN_0103ad44();
      *(undefined1 *)psVar3 = DAT_0ff01feb;
      FUN_0103ad44();
      if (*psVar3 < 1) {
        param_1[1] = DAT_0103da22;
        _DAT_0103da0e = 1;
      }
      *psVar3 = 0;
    }
    if (_DAT_0103da0a == 0) {
      DAT_0ff01fef = 0x80;
      FUN_0103ad44();
      *(undefined1 *)((int)param_2 + 5) = DAT_0ff01fed;
      FUN_0103ad44();
      *(undefined1 *)psVar1 = DAT_0ff01fed;
      FUN_0103ad44();
      if (*psVar1 < 1) {
        param_1[2] = DAT_0103da1e;
        _DAT_0103da0a = 1;
      }
      *psVar1 = 0;
    }
    if ((DAT_0103da02 == 8) && (_DAT_0103da06 == 0)) {
      DAT_0ff01fe7 = 0;
      FUN_0103ad44();
      *(undefined1 *)((int)param_2 + 7) = DAT_0ff01fe1;
      FUN_0103ad44();
      *(undefined1 *)psVar2 = DAT_0ff01fe1;
      FUN_0103ad44();
      if (*psVar2 < 1) {
        param_1[3] = DAT_0103da1a;
        _DAT_0103da06 = 1;
      }
      *psVar2 = 0;
    }
  }
  DAT_0f003001 = DAT_0f003001 | 8;
  DAT_0f004001 = DAT_0f004001 | 0x20;
  return;
}


// ==== FUN_010364ec @ 010364ec

void FUN_010364ec(short param_1)

{
  undefined1 local_6;
  undefined1 uStack_5;
  
  DAT_0ff01ff9 = 0;
  FUN_0103ad30();
  DAT_0ff01ffb = 0;
  FUN_0103ad30();
  DAT_0ff01ffd = 0;
  FUN_0103ad30();
  if (DAT_0103da02 == 8) {
    DAT_0ff01fd1 = 0;
    FUN_0103ad30();
  }
  DAT_0ff01ff7 = 0;
  FUN_0103ad30();
  DAT_0ff01fef = 0x3a;
  FUN_0103ad30();
  uStack_5 = (undefined1)(param_1 * 0x14);
  DAT_0ff01fe9 = uStack_5;
  FUN_0103ad30();
  local_6 = (undefined1)((ushort)(param_1 * 0x14) >> 8);
  DAT_0ff01fe9 = local_6;
  FUN_0103ad30();
  DAT_0ff01fef = 0x7a;
  FUN_0103ad30();
  uStack_5 = (undefined1)(param_1 * 0x1e);
  DAT_0ff01feb = uStack_5;
  FUN_0103ad30();
  local_6 = (undefined1)((ushort)(param_1 * 0x1e) >> 8);
  DAT_0ff01feb = local_6;
  FUN_0103ad30();
  DAT_0ff01fef = 0xba;
  FUN_0103ad30();
  uStack_5 = (undefined1)(param_1 * 0x28);
  DAT_0ff01fed = uStack_5;
  FUN_0103ad30();
  local_6 = (undefined1)((ushort)(param_1 * 0x28) >> 8);
  DAT_0ff01fed = local_6;
  FUN_0103ad30();
  if (DAT_0103da02 == 8) {
    DAT_0ff01fe7 = 0x3a;
    FUN_0103ad30();
    uStack_5 = (undefined1)(param_1 * 0x32);
    DAT_0ff01fe1 = uStack_5;
    FUN_0103ad30();
    local_6 = (undefined1)((ushort)(param_1 * 0x32) >> 8);
    DAT_0ff01fe1 = local_6;
    FUN_0103ad30();
  }
  return;
}


// ==== FUN_01036638 @ 01036638

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_01036638(void)

{
  if (DAT_0103da2e == 2) {
    DAT_0103da2e = 1;
  }
  else if (DAT_0103da2e == 1) {
    DAT_0103da2e = 0;
    DAT_0103da26 = 0;
    DAT_0103da22 = 0;
    DAT_0103da1e = 0;
    DAT_0ff01ff9 = 1;
    FUN_0103ad30();
    DAT_0ff01ffb = 1;
    FUN_0103ad30();
    DAT_0ff01ffd = 1;
    FUN_0103ad30();
    if (DAT_0103da02 == 8) {
      DAT_0103da1a = 0;
      DAT_0ff01fd1 = 1;
      FUN_0103ad30();
    }
  }
  else {
    if (_DAT_0103da12 == 0) {
      DAT_0103da26 = DAT_0103da26 + 1;
    }
    if (_DAT_0103da0e == 0) {
      DAT_0103da22 = DAT_0103da22 + 1;
    }
    if (_DAT_0103da0a == 0) {
      DAT_0103da1e = DAT_0103da1e + 1;
    }
    if ((DAT_0103da02 == 8) && (_DAT_0103da06 == 0)) {
      DAT_0103da1a = DAT_0103da1a + 1;
    }
  }
  return;
}


// ==== FUN_010367d2 @ 010367d2

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_010367d2(void)

{
  undefined1 auStack_1e [8];
  undefined1 auStack_16 [16];
  short local_6;
  
  if ((DAT_0103dac8 == 3) || (DAT_0103dac8 == 2)) {
    local_6 = 0x271;
  }
  else {
    local_6 = 0x20d;
  }
  _DAT_0103da12 = 0;
  _DAT_0103da0e = 0;
  _DAT_0103da0a = 0;
  _DAT_0103da06 = 0;
  FUN_01036e84();
  DAT_0103da2e = 2;
  FUN_01036d48(local_6);
  DAT_0f003001 = DAT_0f003001 & 0xf7;
  FUN_0103ad44();
  if (local_6 == 0x271) {
    FUN_0103002a(0x15e);
  }
  else {
    FUN_0103002a(200);
  }
  FUN_0103689e(auStack_16,auStack_1e);
  FUN_01036ef4(auStack_16,auStack_1e,local_6,4);
  return;
}


// ==== FUN_0103689e @ 0103689e

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0103689e(undefined4 *param_1,short *param_2)

{
  int local_1c;
  int local_18;
  
  local_1c = 0;
  local_18 = 500000;
  while ((local_18 != 0 && (local_1c != 4))) {
    if (_DAT_0103da12 == 0) {
      DAT_0ff01207 = 0;
      FUN_0103ad44();
      *(undefined1 *)((int)param_2 + 1) = DAT_0ff01201;
      FUN_0103ad44();
      *(undefined1 *)param_2 = DAT_0ff01201;
      FUN_0103ad44();
      if (*param_2 < 1) {
        *param_1 = DAT_0103da26;
        _DAT_0103da12 = 1;
        local_1c = local_1c + 1;
      }
    }
    if (_DAT_0103da0e == 0) {
      DAT_0ff01207 = 0x40;
      FUN_0103ad44();
      *(undefined1 *)((int)param_2 + 3) = DAT_0ff01203;
      FUN_0103ad44();
      *(undefined1 *)(param_2 + 1) = DAT_0ff01203;
      FUN_0103ad44();
      if (param_2[1] < 1) {
        param_1[1] = DAT_0103da22;
        _DAT_0103da0e = 1;
        local_1c = local_1c + 1;
      }
    }
    if (_DAT_0103da0a == 0) {
      DAT_0ff01207 = 0x80;
      FUN_0103ad44();
      *(undefined1 *)((int)param_2 + 5) = DAT_0ff01205;
      FUN_0103ad44();
      *(undefined1 *)(param_2 + 2) = DAT_0ff01205;
      FUN_0103ad44();
      if (param_2[2] < 1) {
        param_1[2] = DAT_0103da1e;
        _DAT_0103da0a = 1;
        local_1c = local_1c + 1;
      }
    }
    if (_DAT_0103da06 == 0) {
      DAT_0ff01007 = 0;
      FUN_0103ad44();
      *(undefined1 *)((int)param_2 + 7) = DAT_0ff01001;
      FUN_0103ad44();
      *(undefined1 *)(param_2 + 3) = DAT_0ff01001;
      FUN_0103ad44();
      if (param_2[3] < 1) {
        param_1[3] = DAT_0103da1a;
        _DAT_0103da06 = 1;
        local_1c = local_1c + 1;
      }
    }
    local_18 = local_18 + -1;
  }
  DAT_0f003001 = DAT_0f003001 | 8;
  DAT_0f004001 = DAT_0f004001 | 0x20;
  return;
}


// ==== FUN_01036d48 @ 01036d48

void FUN_01036d48(short param_1)

{
  undefined1 local_6;
  undefined1 uStack_5;
  
  DAT_0ff01e03 = 0;
  DAT_0ff01e07 = 0;
  DAT_0ff01207 = 0x3a;
  FUN_0103ad44();
  uStack_5 = (undefined1)(param_1 * 0x14);
  DAT_0ff01201 = uStack_5;
  FUN_0103ad44();
  local_6 = (undefined1)((ushort)(param_1 * 0x14) >> 8);
  DAT_0ff01201 = local_6;
  FUN_0103ad44();
  DAT_0ff01207 = 0x7a;
  FUN_0103ad44();
  uStack_5 = (undefined1)(param_1 * 0x1e);
  DAT_0ff01203 = uStack_5;
  FUN_0103ad44();
  local_6 = (undefined1)((ushort)(param_1 * 0x1e) >> 8);
  DAT_0ff01203 = local_6;
  FUN_0103ad44();
  DAT_0ff01207 = 0xba;
  FUN_0103ad44();
  uStack_5 = (undefined1)(param_1 * 0x28);
  DAT_0ff01205 = uStack_5;
  FUN_0103ad44();
  local_6 = (undefined1)((ushort)(param_1 * 0x28) >> 8);
  DAT_0ff01205 = local_6;
  FUN_0103ad44();
  DAT_0ff01007 = 0x3a;
  FUN_0103ad44();
  uStack_5 = (undefined1)(param_1 * 0x32);
  DAT_0ff01001 = uStack_5;
  FUN_0103ad44();
  local_6 = (undefined1)((ushort)(param_1 * 0x32) >> 8);
  DAT_0ff01001 = local_6;
  FUN_0103ad44();
  return;
}


// ==== FUN_01036e84 @ 01036e84

void FUN_01036e84(void)

{
  DAT_0f003001 = DAT_0f003001 | 8;
  FUN_0103ad30();
  DAT_0f004001 = DAT_0f004001 | 0x20;
  FUN_0103ad30();
  FUN_0105ef12();
  return;
}


// ==== FUN_01036ef4 @ 01036ef4

void FUN_01036ef4(int *param_1,short *param_2,short param_3,int param_4)

{
  int local_18;
  undefined4 local_14 [4];
  
  for (local_18 = 0; local_18 < 4; local_18 = local_18 + 1) {
    local_14[local_18] = 2;
  }
  if ((*param_1 < 0x26) || (0x2a < *param_1)) {
    if (*param_2 == (short)(param_3 * 10)) {
      local_14[0] = 1;
    }
    else {
      local_14[0] = 0;
    }
  }
  if ((param_1[1] < 0x3a) || (0x3e < param_1[1])) {
    if (param_2[1] == (short)(param_3 * 0x14)) {
      local_14[1] = 1;
    }
    else {
      local_14[1] = 0;
    }
  }
  if ((param_1[2] < 0x4c) || (0x54 < param_1[2])) {
    if (param_2[2] == (short)(param_3 * 0x1e)) {
      local_14[2] = 1;
    }
    else {
      local_14[2] = 0;
    }
  }
  if ((param_4 == 4) && ((param_1[3] < 0x60 || (0x68 < param_1[3])))) {
    if (param_2[3] == (short)(param_3 * 0x28)) {
      local_14[3] = 1;
    }
    else {
      local_14[3] = 0;
    }
  }
  FUN_01037088(param_1,local_14,param_4,param_3);
  FUN_010371fc(local_14,param_4);
  return;
}


// ==== FUN_01037088 @ 01037088

void FUN_01037088(undefined4 param_1,undefined4 param_2,int param_3,undefined2 param_4)

{
  int local_c;
  int local_8;
  
  FUN_01048236("SPF : GPI port Check - No Auto Checked.");
  FUN_01048236(&DAT_01037086);
  FUN_01048236("  GPI  Cmd  Base  Ref  Cnt  Result ");
  for (local_8 = 0; local_8 < param_3; local_8 = local_8 + 1) {
    FUN_010301b4();
    for (local_c = 0; local_c < 0x13; local_c = local_c + 1) {
      (&DAT_0103da78)[local_c] = *(undefined1 *)(*(int *)(&DAT_0103d326 + local_8 * 4) + local_c);
    }
    FUN_0105ec54(1,param_4,3,&DAT_0103da82);
    DAT_0103da85 = 0x20;
    if (local_8 < 3) {
      FUN_0105ec54(1,**(undefined4 **)((int)&param_1 + local_8 * 4),2,&DAT_0103da8d);
      DAT_0103da8f = 0x20;
    }
    else {
      FUN_0105ec54(1,**(undefined4 **)((int)&param_1 + local_8 * 4),3,&DAT_0103da8d);
      DAT_0103da90 = 0x20;
    }
    for (local_c = 0; local_c < 0xc; local_c = local_c + 1) {
      (&UNK_0103da92)[local_c] =
           *(undefined1 *)
            (*(int *)(&DAT_0103d386 + **(int **)((int)&param_2 + local_8 * 4) * 4) + local_c);
    }
    FUN_01048236(&DAT_0103da76);
  }
  return;
}


// ==== FUN_010371fc @ 010371fc

char * FUN_010371fc(undefined4 param_1,int param_2)

{
  char *pcVar1;
  int local_e;
  int local_a;
  char local_5;
  
  local_5 = '\x13';
  for (local_a = 0; local_a < param_2; local_a = local_a + 1) {
    FUN_010301b4();
    if (**(int **)((int)&param_1 + local_a * 4) != 2) {
      FUN_010301b4();
      for (local_e = 0; local_e < 0x14; local_e = local_e + 1) {
        (&DAT_0103da78)[local_e] =
             *(undefined1 *)
              (*(int *)(&DAT_0103d3ba + (**(int **)((int)&param_1 + local_a * 4) + local_a * 2) * 4)
              + local_e);
      }
      FUN_01058f82(1,(int)local_5,&DAT_0103da78);
      local_5 = local_5 + '\x01';
    }
  }
  pcVar1 = "Press \'ENTER\' key to next ! ";
  FUN_01058f82(1,(int)local_5);
  return pcVar1;
}


// ==== FUN_010372c4 @ 010372c4

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_010372c4(void)

{
  if (DAT_0103da2e == 2) {
    DAT_0103da2e = 1;
  }
  else if (DAT_0103da2e == 1) {
    DAT_0103da2e = 0;
    DAT_0103da26 = 0;
    DAT_0103da22 = 0;
    DAT_0103da1e = 0;
    DAT_0103da1a = 0;
    DAT_0ff01e03 = 0xf;
  }
  else {
    if (_DAT_0103da12 == 0) {
      DAT_0103da26 = DAT_0103da26 + 1;
    }
    if (_DAT_0103da0e == 0) {
      DAT_0103da22 = DAT_0103da22 + 1;
    }
    if (_DAT_0103da0a == 0) {
      DAT_0103da1e = DAT_0103da1e + 1;
    }
    if (_DAT_0103da06 == 0) {
      DAT_0103da1a = DAT_0103da1a + 1;
    }
  }
  return;
}


// ==== FUN_01037346 @ 01037346

void FUN_01037346(void)

{
  int unaff_D7;
  
  FUN_010300da();
  if (unaff_D7 == 1) {
    unaff_D7 = 3;
  }
  else {
    FUN_01037382();
  }
  FUN_010373aa(unaff_D7);
  return;
}


// ==== FUN_01037382 @ 01037382

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_01037382(void)

{
  return;
}


// ==== FUN_010373aa @ 010373aa

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */
/* WARNING: Restarted to delay deadcode elimination for space: stack */

void FUN_010373aa(int param_1)

{
  undefined2 uVar1;
  undefined1 local_a;
  undefined1 uStack_9;
  int local_8;
  
  FUN_010301b4();
  FUN_01048236("DSC-63 : Board-ID & ROM Version Number.");
  if (param_1 == 1) {
    FUN_01048236(PTR_s_Check_Pass__0103c98e);
    FUN_01048236(&DAT_010373a6);
    uVar1 = _DAT_0d01cbfc;
    for (local_8 = 0; local_8 < 10; local_8 = local_8 + 1) {
      (&DAT_0103da78)[local_8] = "Version : "[local_8];
    }
    DAT_0103da82 = 0x56;
    local_a = (undefined1)((ushort)uVar1 >> 8);
    FUN_0105ee14(1,local_a,2,&DAT_0103da83);
    DAT_0103da85 = 0x2e;
    uStack_9 = (undefined1)uVar1;
    FUN_0105ee14(1,uStack_9,2,&DAT_0103da86);
    FUN_01058f82(1,0x13,&DAT_0103da78);
    FUN_01048236(&DAT_0103da76);
    FUN_0103002a(1000);
  }
  else if (param_1 == 2) {
    FUN_01048236(PTR_s_Check_Fault__0103c9a0);
    FUN_01048236(&DAT_010373a8);
    for (local_8 = 0; local_8 < 0x1c; local_8 = local_8 + 1) {
      (&DAT_0103da78)[local_8] = "DSC-63 Board Not Ready "[local_8];
    }
    FUN_01058f82(1,0x13,&DAT_0103da78);
    FUN_01048236(&DAT_0103da76);
    FUN_0103002a(1000);
  }
  else {
    FUN_01048236(PTR_s_Check_Abort__0103c9b2);
  }
  return;
}


// ==== FUN_01037536 @ 01037536

void FUN_01037536(void)

{
  int unaff_D7;
  undefined4 local_18;
  undefined2 local_14;
  undefined1 local_11;
  int local_10;
  int iVar1;
  int iVar2;
  
  iVar1 = 1;
  local_10 = 1;
  local_11 = 0;
  local_14 = 0;
  local_18 = 100;
  FUN_01030352(1,1);
  if (unaff_D7 == 0x137) {
    iVar1 = 2;
    local_10 = 0;
  }
  iVar2 = 0;
  if (local_10 != 0) {
    FUN_010300da();
    iVar2 = unaff_D7;
    if (unaff_D7 != 1) {
      FUN_0103766a(&local_18);
      iVar1 = unaff_D7;
      if (unaff_D7 != 2) {
        FUN_010300da();
        if (unaff_D7 != 1) {
          FUN_0103776a(&local_18);
          if (unaff_D7 != 2) {
            FUN_010300da();
            if (unaff_D7 != 1) {
              FUN_010378ac(&local_18,&local_11);
              if (unaff_D7 == 1) {
                FUN_0103796a(&local_18,&local_14);
              }
            }
          }
        }
      }
    }
  }
  FUN_01030352(0,1);
  if (iVar2 == 1) {
    iVar1 = 3;
  }
  FUN_01037c08(local_18,local_11,&local_14,iVar1);
  return;
}


// ==== FUN_0103766a @ 0103766a

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0103766a(undefined4 *param_1)

{
  undefined4 uVar1;
  
  uVar1 = 1;
  FUN_01037700(param_1,1);
  if ((_DAT_0d01ca20 & 1) == 1) {
    if ((_DAT_0d01ca22 & 0x80) == 0x80) {
      if ((_DAT_0d01ca22 & 0xe) != 0) {
        FUN_01037700(param_1,uVar1);
      }
    }
    else {
      *param_1 = 0x4d;
    }
  }
  else {
    *param_1 = 0x4c;
  }
  return;
}


// ==== FUN_01037700 @ 01037700

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_01037700(undefined4 *param_1)

{
  _DAT_0d01ca02 = 2;
  _DAT_0d01ca04 = 0xf77;
  FUN_010301f6(2,1,0);
  _DAT_0d01ca00 = 2;
  FUN_010301f6(2,2,0);
  if (_DAT_0d01ca00 == 0) {
    *param_1 = 100;
  }
  else {
    *param_1 = 0x49;
  }
  return;
}


// ==== FUN_0103776a @ 0103776a

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0103776a(undefined4 *param_1)

{
  int unaff_D7;
  int iVar1;
  int local_8;
  
  DAT_0d01ca42 = 0x82;
  DAT_0d01ca43 = 3;
  DAT_0d01ca44 = 0x57;
  DAT_0d01ca45 = 1;
  DAT_0d01ca46 = 1;
  DAT_0d01ca47 = 0xa7;
  FUN_010300da();
  if (unaff_D7 != 0) {
    return;
  }
  FUN_010301f6(2,1,0);
  _DAT_0d01ca40 = 6;
  FUN_010301f6(2,2,0);
  if (_DAT_0d01ca40 == 0) {
    *param_1 = 0x4a;
    for (local_8 = 0; local_8 < 4; local_8 = local_8 + 1) {
      FUN_010301f6(2,1,0);
      if (_DAT_0d01cae0 != 0) {
        iVar1 = (int)_DAT_0d01cae0;
        _DAT_0d01cae0 = _DAT_0d01cae0 + -1;
        if (*(char *)(iVar1 + 0xd01cae1) == -0x7d) {
          *param_1 = 100;
          _DAT_0d01cae0 = 0;
          return;
        }
        if (*(char *)(iVar1 + 0xd01cae1) == -0x7c) {
          *param_1 = 0x4b;
          _DAT_0d01cae0 = 0;
          return;
        }
      }
    }
  }
  else {
    *param_1 = 0x49;
  }
  _DAT_0d01cae0 = 0;
  return;
}


// ==== FUN_010378ac @ 010378ac

void FUN_010378ac(undefined4 *param_1,char *param_2)

{
  undefined4 unaff_D7;
  undefined1 *puVar1;
  
  puVar1 = &DAT_0d01ca00;
  DAT_0d01ca42 = 0x82;
  DAT_0d01ca43 = 2;
  DAT_0d01ca44 = 0x52;
  DAT_0d01ca45 = 0x5a;
  DAT_0d01ca46 = 0x54;
  FUN_01037aa2(&DAT_0d01ca00,&DAT_0d01ca00,1);
  FUN_010301f6(2,1,0);
  *(undefined2 *)(puVar1 + 0x40) = 5;
  FUN_010301f6(2,2,0);
  FUN_01037ae0(puVar1,param_2);
  *param_1 = unaff_D7;
  if (*param_2 == '\0') {
    *param_1 = 0x4e;
  }
  return;
}


// ==== FUN_0103796a @ 0103796a

void FUN_0103796a(int *param_1,int param_2)

{
  int unaff_D7;
  undefined1 *puVar1;
  
  puVar1 = &DAT_0d01ca00;
  DAT_0d01ca42 = 0x82;
  DAT_0d01ca43 = 2;
  DAT_0d01ca44 = 0x52;
  DAT_0d01ca45 = 0x47;
  DAT_0d01ca46 = 0x67;
  FUN_01037aa2(&DAT_0d01ca00,&DAT_0d01ca00,param_2);
  FUN_010301f6(2,1,0);
  *(undefined2 *)(puVar1 + 0x40) = 5;
  FUN_010301f6(2,2,0);
  FUN_01037ae0(puVar1,param_2 + 1);
  *param_1 = unaff_D7;
  if (*param_1 != 100) {
    return;
  }
  puVar1[0x42] = 0x82;
  puVar1[0x43] = 2;
  puVar1[0x44] = 0x52;
  puVar1[0x45] = 0x48;
  puVar1[0x46] = 0x66;
  FUN_01037aa2(puVar1);
  FUN_010301f6(2,1,0);
  *(undefined2 *)(puVar1 + 0x40) = 5;
  FUN_010301f6(2,2,0);
  FUN_01037ae0(puVar1,param_2);
  *param_1 = unaff_D7;
  if (*param_1 == 100) {
    return;
  }
  return;
}


// ==== FUN_01037aa2 @ 01037aa2

void FUN_01037aa2(int param_1)

{
  *(undefined2 *)(param_1 + 0x40) = 0;
  while (*(short *)(param_1 + 0xe0) != 0) {
    *(undefined2 *)(param_1 + 0xe0) = 0;
    FUN_010301f6(2,1,0);
  }
  *(undefined2 *)(param_1 + 0x40) = 0;
  return;
}


// ==== FUN_01037ae0 @ 01037ae0

undefined4 FUN_01037ae0(int param_1,undefined1 *param_2)

{
  undefined4 in_D0;
  int iVar1;
  int iVar2;
  undefined4 local_18;
  int local_8;
  
  local_18 = in_D0;
  if (*(short *)(param_1 + 0x40) == 0) {
    local_8 = 0x4a;
    for (iVar2 = 0; iVar2 < 4; iVar2 = iVar2 + 1) {
      FUN_010301f6(2,1);
      if (*(short *)(param_1 + 0xe0) != 0) {
        for (iVar1 = 0; iVar1 < *(short *)(param_1 + 0xe0); iVar1 = iVar1 + 1) {
          if (*(char *)(param_1 + 0xe2 + iVar1) == -0x7e) {
            if (iVar1 < *(short *)(param_1 + 0xe0) + -1) {
              *param_2 = *(undefined1 *)(param_1 + iVar1 + 0xe3);
              local_8 = 100;
              break;
            }
            *(undefined2 *)(param_1 + 0xe0) = 0;
            FUN_010301f6(2,1);
            if (*(short *)(param_1 + 0xe0) != 0) {
              *param_2 = *(undefined1 *)(param_1 + 0xe2);
              local_8 = 100;
              break;
            }
          }
        }
        local_18 = 0;
        if (local_8 == 100) break;
        *(undefined2 *)(param_1 + 0xe0) = 0;
      }
      local_18 = 0;
    }
  }
  while (*(short *)(param_1 + 0xe0) != 0) {
    *(undefined2 *)(param_1 + 0xe0) = 0;
    local_18 = 0;
    FUN_010301f6(2,1);
  }
  return local_18;
}


// ==== FUN_01037c08 @ 01037c08

void FUN_01037c08(int param_1,int param_2,ushort *param_3,int param_4)

{
  int local_c;
  
  FUN_01048236("DSC-63 : Keyboard I/F.");
  FUN_010301b4();
  if (param_4 == 1) {
    for (local_c = 0; local_c < 0xc; local_c = local_c + 1) {
      (&DAT_0103da78)[local_c] = **(undefined1 **)((int)&PTR_s_Check_Pass__0103c98e + local_c);
    }
    (&DAT_0103da78)[local_c] = 0;
    FUN_01058f82(1,0x13,&DAT_0103da76);
    FUN_01048236(&DAT_0103da78);
    FUN_01048236(&DAT_01037c06);
    FUN_010301b4();
    for (local_c = 0; local_c < 0xe; local_c = local_c + 1) {
      (&DAT_0103da78)[local_c] =
           "BKE-9400/9400A  BKE-9410        Check Pass             "
           [local_c + (param_2 + -1) * 0x10];
    }
    DAT_0103da88 = 0x56;
    FUN_0105ee14(0,(int)(uint)*param_3 >> 0xc,1,&DAT_0103da89);
    DAT_0103da8a = 0x2e;
    FUN_0105ee14(0,*param_3 & 0xfff,3,&DAT_0103da8b);
    FUN_01048236(&DAT_0103da76);
    FUN_01058f82(1,0x15,&DAT_0103da76);
    FUN_0103002a(1000);
  }
  else if (param_4 == 2) {
    FUN_01048236(PTR_s_Check_Fault__0103c9a0);
    FUN_010301b4();
    for (local_c = 0; local_c < 0x17; local_c = local_c + 1) {
      (&DAT_0103da78)[local_c] =
           "BKE-9400/9400A  BKE-9410        Check Pass             "
           [local_c + (param_1 + -0x46) * 0x1c + 0x20];
    }
    (&DAT_0103da78)[local_c] = 0;
    FUN_01048236(&DAT_0103da76);
    FUN_0103002a(1000);
  }
  else if (param_4 == 3) {
    FUN_01048236(PTR_s_Check_Abort__0103c9b2);
  }
  return;
}


// ==== FUN_01037e1a @ 01037e1a

/* WARNING: Removing unreachable block (ram,0x01037f3e) */
/* WARNING: Removing unreachable block (ram,0x01037ec8) */
/* WARNING: Removing unreachable block (ram,0x01037f04) */
/* WARNING: Removing unreachable block (ram,0x01037f18) */
/* WARNING: Removing unreachable block (ram,0x01037f56) */

void FUN_01037e1a(void)

{
  int unaff_D7;
  int iVar1;
  int local_10 [3];
  
  local_10[1] = 1;
  FUN_010456d4(0xd3c);
  iVar1 = unaff_D7;
  for (local_10[0] = 0; local_10[0] < 0x79; local_10[0] = local_10[0] + 1) {
    *(undefined4 *)local_10[local_10[0] + -2] = 99;
    iVar1 = local_10[0] * 4;
    *(undefined4 *)(unaff_D7 + 0x790 + iVar1) = 100;
  }
  FUN_01030352(1,1);
  FUN_010300da();
  if ((iVar1 != 1) && (FUN_01037f9c(unaff_D7,0), local_10[1] = iVar1, iVar1 == 1)) {
    FUN_010300da();
  }
  FUN_01030352(0,1);
  if (iVar1 == 1) {
    local_10[1] = 3;
  }
  FUN_01038824(unaff_D7,local_10[1]);
  FUN_01045712(unaff_D7);
  return;
}


// ==== FUN_01037f9c @ 01037f9c

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_01037f9c(int param_1,int param_2)

{
  int local_8;
  
  if ((_DAT_0d01cc20 & 1) == 1) {
    if ((_DAT_0d01cc22 & 0x80) == 0x80) {
      _DAT_0d01cc02 = 3;
      _DAT_0d01cc00 = 1;
      FUN_010301f6(2,2,0);
      *(undefined4 *)(param_1 + 0x790 + param_2 * 4) = 0x53;
      for (local_8 = 0; local_8 < 5; local_8 = local_8 + 1) {
        if ((_DAT_0d01cc22 & 1) == 1) {
          *(undefined4 *)(param_1 + 0x790 + param_2 * 4) = 100;
          return;
        }
        FUN_010301f6(2,200,0);
      }
    }
    else {
      *(undefined4 *)(param_1 + 0x790 + param_2 * 4) = 0x52;
    }
  }
  else {
    *(undefined4 *)(param_1 + 0x790 + param_2 * 4) = 0x51;
  }
  return;
}


// ==== FUN_010380bc @ 010380bc

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_010380bc(int param_1,int param_2)

{
  _DAT_0d01cc04 =
       *(ushort *)(&DAT_0103d676 + *(int *)(param_1 + 0x5ac + param_2 * 4) * 2) |
       *(ushort *)(&DAT_0103d670 + *(int *)(param_1 + 0x3c8 + param_2 * 4) * 2) |
       *(ushort *)(&DAT_0103d66c + *(int *)(param_1 + 0x1e4 + param_2 * 4) * 2) |
       *(ushort *)(&DAT_0103d658 + *(int *)(&param_1)[param_2] * 2);
  _DAT_0d01cc02 = 3;
  _DAT_0d01cc00 = 2;
  FUN_010301f6(2,4,0);
  if (_DAT_0d01cc00 == 0) {
    *(undefined4 *)(param_1 + 0x790 + param_2 * 4) = 100;
  }
  else {
    *(undefined4 *)(param_1 + 0x790 + param_2 * 4) = 0x53;
  }
  return;
}


// ==== FUN_010381ce @ 010381ce

void FUN_010381ce(int param_1,int param_2)

{
  char cVar1;
  undefined4 local_16 [2];
  char local_d;
  int local_8;
  
  local_16[1] = 1;
  FUN_010301b4();
  for (local_8 = 0; local_8 < 0x50; local_8 = local_8 + 1) {
    (&DAT_0103da78)[local_8] =
         "Char  Parity  Stop  Baud Rate    Result                Adr    W-data    R-data"[local_8];
  }
  FUN_01058f82(1,0x13,&DAT_0103da78);
  FUN_010456d4(0x1dc);
  local_16[0] = 0x1dc;
  local_d = ' ';
  for (local_8 = 0; cVar1 = local_d, local_8 < 0x1dc; local_8 = local_8 + 1) {
    local_d = local_d + '\x01';
    **(char **)((int)local_16 + local_8) = cVar1;
    if (local_d == '~') {
      local_d = ' ';
    }
  }
  FUN_010384c2();
  FUN_01038508(local_16[0],0x1dc);
  FUN_0103856a(local_16[0],0x1dc,param_1,0,1);
  if (*(int *)(param_1 + 0x790 + param_2 * 4) != 100) {
    local_16[1] = 2;
  }
  FUN_01045712(local_16[0]);
  FUN_0103872a(param_1,0);
  return;
}


// ==== FUN_010382f6 @ 010382f6

void FUN_010382f6(int param_1)

{
  int iVar1;
  int local_1c;
  int local_18;
  int local_14;
  int local_10;
  int local_c;
  
  local_c = 1;
  local_10 = 0;
  do {
    if (9 < local_10) {
      return;
    }
    for (local_14 = 0; local_14 < 2; local_14 = local_14 + 1) {
      for (local_18 = 0; local_18 < 3; local_18 = local_18 + 1) {
        for (local_1c = 0; local_1c < 2; local_1c = local_1c + 1) {
          *(int *)(&param_1)[local_c] = local_10;
          *(int *)(param_1 + 0x1e4 + local_c * 4) = local_14;
          *(int *)(param_1 + 0x3c8 + local_c * 4) = local_18;
          iVar1 = local_c * 4;
          *(int *)(param_1 + 0x5ac + iVar1) = local_1c;
          FUN_010383fe(param_1,local_c);
          FUN_0103872a(param_1,local_c);
          local_c = local_c + 1;
          FUN_010300da();
          if (iVar1 == 1) {
            return;
          }
        }
      }
    }
    local_10 = local_10 + 1;
  } while( true );
}


// ==== FUN_010383fe @ 010383fe

void FUN_010383fe(undefined4 param_1,int param_2)

{
  int unaff_D7;
  int iVar1;
  char acStack_1a [8];
  undefined2 local_12;
  undefined1 *local_10;
  int local_c;
  undefined4 local_8;
  
  local_8 = 1;
  local_10 = &DAT_0d01cc00;
  local_12 = 8;
  for (local_c = 0; local_c < 8; local_c = local_c + 1) {
    acStack_1a[local_c] = (char)local_c + ' ';
    unaff_D7 = local_c;
  }
  FUN_010380bc(param_1,param_2);
  if (unaff_D7 == 1) {
    FUN_010384c2();
    iVar1 = 10 - *(int *)(&param_1)[param_2];
    FUN_01038508(acStack_1a,local_12,iVar1);
    FUN_0103856a(acStack_1a,local_12,param_1,param_2,iVar1);
  }
  return;
}


// ==== FUN_010384c2 @ 010384c2

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_010384c2(void)

{
  _DAT_0d01cc40 = 0;
  while (_DAT_0d01ce20 != 0) {
    _DAT_0d01ce20 = 0;
    FUN_010301f6(2,1,0);
  }
  _DAT_0d01cc40 = 0;
  return;
}


// ==== FUN_01038508 @ 01038508

void FUN_01038508(undefined4 param_1,ushort param_2)

{
  undefined1 *puVar1;
  int iVar2;
  
  puVar1 = &DAT_0d01cc00;
  for (iVar2 = 0; iVar2 < (int)(uint)param_2; iVar2 = iVar2 + 1) {
    *(undefined1 *)(iVar2 + 0xd01cc42) = **(undefined1 **)((int)&param_1 + iVar2);
  }
  FUN_010301f6(2,1,0,&DAT_0d01cc00,iVar2,100);
  *(ushort *)(puVar1 + 0x40) = param_2;
  return;
}


// ==== FUN_0103856a @ 0103856a

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

uint FUN_0103856a(undefined4 param_1,ushort param_2,int param_3,int param_4,int param_5)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  uint local_a;
  
  uVar3 = (uint)param_2;
  FUN_010456d4(uVar3);
  local_a = uVar3;
  FUN_010301f6(2,param_5 * 6,0);
  if (_DAT_0d01ce20 == 0) {
    *(undefined4 *)(param_3 + 0x790 + param_4 * 4) = 0x54;
  }
  else {
    iVar2 = 0;
    *(undefined4 *)(param_3 + 0x790 + param_4 * 4) = 100;
    while (_DAT_0d01ce20 != 0) {
      for (iVar1 = 0; iVar1 < (int)(uint)_DAT_0d01ce20; iVar1 = iVar1 + 1) {
        **(undefined1 **)((int)&local_a + iVar2) = (&DAT_0d01ce22)[iVar1];
        iVar2 = iVar2 + 1;
      }
      _DAT_0d01ce20 = 0;
      FUN_010301f6(2,1,0);
    }
    if ((_DAT_0d01cc22 & 0xe) == 0) {
      for (iVar2 = 0; iVar2 < (int)(uint)param_2; iVar2 = iVar2 + 1) {
        if (**(char **)((int)&local_a + iVar2) != **(char **)((int)&param_1 + iVar2)) {
          *(undefined4 *)(param_3 + 0x790 + param_4 * 4) = 0x56;
          *(int *)(param_3 + 0x974 + param_4 * 4) = iVar2;
          *(undefined1 *)(param_3 + 0xb58 + param_4) = **(undefined1 **)((int)&param_1 + iVar2);
          *(undefined1 *)(param_3 + 0xbd1 + param_4) = **(undefined1 **)((int)&local_a + iVar2);
          break;
        }
      }
    }
    else {
      *(undefined4 *)(param_3 + 0x790 + param_4 * 4) = 0x55;
    }
  }
  if (_DAT_0d01cc40 != 0) {
    *(undefined4 *)(param_3 + 0x790 + param_4 * 4) = 0x53;
  }
  uVar3 = local_a;
  FUN_01045712();
  for (iVar2 = 0; iVar2 < 0x19; iVar2 = iVar2 + 1) {
    uVar3 = 0;
    FUN_010301f6(2,1);
  }
  return uVar3;
}


// ==== FUN_0103872a @ 0103872a

void FUN_0103872a(int param_1,int param_2)

{
  int local_c;
  
  FUN_010301b4();
  DAT_0103da78 = "78NoneODD EVEN21300   600   1200  2400  4800  9600  19.2k 38.4k 76.8k 153.6kPass                Printer CH Not ReadyPrinter Not Ready   Send Error          Receive Time Out    Receive Error       Receive Data Error  RS-422 : Board-ID & Communication. "
                 [*(int *)(param_1 + 0x5ac + param_2 * 4)];
  for (local_c = 0; local_c < 4; local_c = local_c + 1) {
    (&DAT_0103da7e)[local_c] =
         "78NoneODD EVEN21300   600   1200  2400  4800  9600  19.2k 38.4k 76.8k 153.6kPass                Printer CH Not ReadyPrinter Not Ready   Send Error          Receive Time Out    Receive Error       Receive Data Error  RS-422 : Board-ID & Communication. "
         [local_c + *(int *)(param_1 + 0x3c8 + param_2 * 4) * 4 + 2];
  }
  DAT_0103da86 = "78NoneODD EVEN21300   600   1200  2400  4800  9600  19.2k 38.4k 76.8k 153.6kPass                Printer CH Not ReadyPrinter Not Ready   Send Error          Receive Time Out    Receive Error       Receive Data Error  RS-422 : Board-ID & Communication. "
                 [*(int *)(param_1 + 0x1e4 + param_2 * 4) + 0xe];
  for (local_c = 0; local_c < 6; local_c = local_c + 1) {
    (&DAT_0103da8c)[local_c] =
         "78NoneODD EVEN21300   600   1200  2400  4800  9600  19.2k 38.4k 76.8k 153.6kPass                Printer CH Not ReadyPrinter Not Ready   Send Error          Receive Time Out    Receive Error       Receive Data Error  RS-422 : Board-ID & Communication. "
         [local_c + *(int *)(&param_1)[param_2] * 6 + 0x10];
  }
  FUN_010389fa(param_1,param_2);
  FUN_01059ea6(1,param_2,&DAT_0103da78);
  return;
}


// ==== FUN_01038824 @ 01038824

void FUN_01038824(int param_1,int param_2)

{
  int local_c;
  int local_8;
  
  FUN_01048236("DSC-63 : Printer I/F.");
  FUN_010301b4();
  if (param_2 == 1) {
    FUN_01048236(PTR_s_Check_Pass__0103c98e);
  }
  else if (param_2 == 3) {
    FUN_01048236(PTR_s_Check_Abort__0103c9b2);
  }
  else {
    FUN_01048236(&DAT_01038822);
    for (local_8 = 0; local_8 < 0x50; local_8 = local_8 + 1) {
      (&DAT_0103da78)[local_8] =
           "Char  Parity  Stop  Baud Rate    Result                Adr    W-data    R-data"[local_8]
      ;
    }
    FUN_01048236(&DAT_0103da76);
    for (local_8 = 0; local_8 < 0x79; local_8 = local_8 + 1) {
      FUN_010301b4();
      if (*(int *)(&param_1)[local_8] != 99) {
        DAT_0103da78 = "78NoneODD EVEN21300   600   1200  2400  4800  9600  19.2k 38.4k 76.8k 153.6kPass                Printer CH Not ReadyPrinter Not Ready   Send Error          Receive Time Out    Receive Error       Receive Data Error  RS-422 : Board-ID & Communication. "
                       [*(int *)(param_1 + 0x5ac + local_8 * 4)];
        for (local_c = 0; local_c < 4; local_c = local_c + 1) {
          (&DAT_0103da7e)[local_c] =
               "78NoneODD EVEN21300   600   1200  2400  4800  9600  19.2k 38.4k 76.8k 153.6kPass                Printer CH Not ReadyPrinter Not Ready   Send Error          Receive Time Out    Receive Error       Receive Data Error  RS-422 : Board-ID & Communication. "
               [local_c + *(int *)(param_1 + 0x3c8 + local_8 * 4) * 4 + 2];
        }
        DAT_0103da86 = "78NoneODD EVEN21300   600   1200  2400  4800  9600  19.2k 38.4k 76.8k 153.6kPass                Printer CH Not ReadyPrinter Not Ready   Send Error          Receive Time Out    Receive Error       Receive Data Error  RS-422 : Board-ID & Communication. "
                       [*(int *)(param_1 + 0x1e4 + local_8 * 4) + 0xe];
        for (local_c = 0; local_c < 6; local_c = local_c + 1) {
          (&DAT_0103da8c)[local_c] =
               "78NoneODD EVEN21300   600   1200  2400  4800  9600  19.2k 38.4k 76.8k 153.6kPass                Printer CH Not ReadyPrinter Not Ready   Send Error          Receive Time Out    Receive Error       Receive Data Error  RS-422 : Board-ID & Communication. "
               [local_c + *(int *)(&param_1)[local_8] * 6 + 0x10];
        }
      }
      FUN_010389fa(param_1,local_8);
      FUN_01048236(&DAT_0103da76);
      if (*(int *)(param_1 + 0x790 + local_8 * 4) == 0x51) {
        return;
      }
      if (*(int *)(param_1 + 0x790 + local_8 * 4) == 0x52) {
        return;
      }
    }
  }
  return;
}


// ==== FUN_010389fa @ 010389fa

undefined * FUN_010389fa(int param_1,int param_2)

{
  undefined *in_D0;
  int local_8;
  
  if (*(int *)(param_1 + 0x790 + param_2 * 4) == 100) {
    for (local_8 = 0; local_8 < 4; local_8 = local_8 + 1) {
      (&DAT_0103da99)[local_8] =
           "78NoneODD EVEN21300   600   1200  2400  4800  9600  19.2k 38.4k 76.8k 153.6kPass                Printer CH Not ReadyPrinter Not Ready   Send Error          Receive Time Out    Receive Error       Receive Data Error  RS-422 : Board-ID & Communication. "
           [local_8 + 0x4c];
    }
  }
  else {
    for (local_8 = 0; local_8 < 0x14; local_8 = local_8 + 1) {
      (&DAT_0103da99)[local_8] =
           "78NoneODD EVEN21300   600   1200  2400  4800  9600  19.2k 38.4k 76.8k 153.6kPass                Printer CH Not ReadyPrinter Not Ready   Send Error          Receive Time Out    Receive Error       Receive Data Error  RS-422 : Board-ID & Communication. "
           [local_8 + (*(int *)(param_1 + 0x790 + param_2 * 4) + -0x50) * 0x14 + 0x4c];
    }
    if (*(int *)(param_1 + 0x790 + param_2 * 4) == 0x56) {
      FUN_0105ec54(1,*(undefined4 *)(param_1 + 0x974 + param_2 * 4),3,&DAT_0103daaf);
      DAT_0103dab2 = 0x20;
      FUN_0105ee14(1,(int)*(char *)(param_1 + 0xb58 + param_2),2,&DAT_0103dab8);
      DAT_0103daba = 0x20;
      in_D0 = &DAT_0103dac2;
      FUN_0105ee14(1,(int)*(char *)(param_1 + 0xbd1 + param_2),2);
    }
  }
  return in_D0;
}


// ==== FUN_01038d08 @ 01038d08

/* WARNING: Removing unreachable block (ram,0x01038dd2) */

void FUN_01038d08(void)

{
  int unaff_D7;
  int iVar1;
  undefined1 local_25;
  undefined *local_24;
  int local_20;
  int local_1c;
  int local_18;
  int local_14;
  int local_10;
  undefined4 local_c;
  undefined4 local_8;
  
  local_8 = 0;
  local_c = 1;
  local_25 = 0x13;
  local_24 = &DAT_01038b48;
  FUN_01030352(1,1);
  for (local_20 = 0; local_20 < 8; local_20 = local_20 + 1) {
    unaff_D7 = local_20 * 0x38;
    *(undefined4 *)(&DAT_01038b48 + unaff_D7) = 0xffffffff;
    for (local_18 = 0; local_18 < 4; local_18 = local_18 + 1) {
      for (local_1c = 0; local_1c < 4; local_1c = local_1c + 1) {
        unaff_D7 = local_1c * 2;
        *(undefined2 *)(&UNK_01038b58 + unaff_D7 + local_18 * 10 + local_20 * 0x38) = 0;
      }
    }
  }
  FUN_01038f68(local_24);
  local_10 = unaff_D7;
  if (unaff_D7 == 0) {
    FUN_010300da();
  }
  else {
    for (local_18 = 0; local_18 < local_10; local_18 = local_18 + 1) {
      FUN_010391e0((&local_24)[local_18 * 0xe]);
      FUN_01039226((&local_24)[local_18 * 0xe]);
      if ((*(short *)((&local_24)[local_18 * 0xe] + 0x10) == 0x28) ||
         (*(short *)((&local_24)[local_18 * 0xe] + 0x10) == 0x26)) {
        local_c = 2;
      }
      else if (*(short *)((&local_24)[local_18 * 0xe] + 0x10) == 0) {
        iVar1 = local_18 * 0x38;
        FUN_01039298((&local_24)[local_18 * 0xe]);
        local_14 = iVar1;
        if (iVar1 == 2) {
          local_c = 2;
        }
        else if (iVar1 == 3) {
          local_c = 3;
          break;
        }
      }
      iVar1 = local_18 * 0x38;
      FUN_010395e4((&local_24)[local_18 * 0xe],&local_25);
      FUN_010300da();
      if (iVar1 == 1) {
        local_c = 3;
        break;
      }
    }
  }
  FUN_01030352(0,1);
  FUN_01039742(local_24,local_10,local_c);
  return;
}


// ==== FUN_01038f68 @ 01038f68

void FUN_01038f68(undefined4 param_1)

{
  int local_8;
  
  local_8 = 0;
  while( true ) {
    if (7 < local_8) {
      local_8 = 0;
      while( true ) {
        if (-1 < local_8) {
          return;
        }
        if ((*(ushort *)(*(int *)((int)&param_1 + local_8 * 0x38) + 8) & 0xf000) == 0x2000) break;
        local_8 = local_8 + 1;
      }
      FUN_0105ef12();
      return;
    }
    if (*(short *)(&DAT_0103fa52 + local_8 * 2) != -1) break;
    local_8 = local_8 + 1;
  }
  FUN_0105ef12();
  return;
}


// ==== FUN_010391e0 @ 010391e0

void FUN_010391e0(undefined4 *param_1)

{
  int unaff_D7;
  
  FUN_01039342(*param_1,0);
  *(undefined2 *)((int)param_1 + 10) = *(undefined2 *)(unaff_D7 + 0x3fc);
  return;
}


// ==== FUN_01039226 @ 01039226

void FUN_01039226(void)

{
  FUN_0105ef12();
  return;
}


// ==== FUN_01039298 @ 01039298

void FUN_01039298(undefined4 *param_1)

{
  int local_c;
  
  for (local_c = 0; local_c < (int)param_1[3]; local_c = local_c + 1) {
    FUN_01039342(*param_1,local_c);
    if ((*(ushort *)(local_c + 0x3a0) & 0x8000) == 0) {
      *(undefined2 *)((int)param_1 + local_c * 10 + 0x10) = 0x22;
    }
    else {
      FUN_01039370(local_c,local_c,param_1);
    }
  }
  return;
}


// ==== FUN_01039342 @ 01039342

void FUN_01039342(void)

{
  return;
}


// ==== FUN_01039370 @ 01039370

void FUN_01039370(int param_1,int param_2,int param_3)

{
  ushort uVar1;
  bool bVar2;
  int local_e;
  
  bVar2 = false;
  while( true ) {
    uVar1 = *(ushort *)(param_1 + 0x3a0);
    if ((uVar1 & 0xfb) != 0) {
      *(undefined2 *)(param_1 + 0x3c0) = 3;
      FUN_010301f6(2,1,0);
    }
    local_e = 0;
    while ((local_e < 2 && ((uVar1 & 0x300) != 0x300))) {
      FUN_010301f6(2,1,0);
      local_e = local_e + 1;
    }
    *(undefined2 *)(param_1 + 0x382) = 0xf77;
    FUN_01039436(param_1,param_2,param_3);
    if ((*(short *)(param_3 + 0x10 + param_2 * 10) != 0x20) || (bVar2)) break;
    bVar2 = true;
  }
  return;
}


// ==== FUN_01039436 @ 01039436

void FUN_01039436(short *param_1,int param_2,int param_3)

{
  uint uVar1;
  int iVar2;
  int local_8;
  
  *(undefined1 *)(param_1 + 0x100) = 2;
  *(undefined1 *)((int)param_1 + 0x201) = 2;
  *(undefined1 *)(param_1 + 0x101) = 9;
  *(undefined1 *)((int)param_1 + 0x203) = 1;
  *(undefined1 *)(param_1 + 0x102) = 0xf6;
  param_1[0x1cc] = 5;
  *(undefined2 *)(param_3 + 0x10 + param_2 * 10) = 0x1f;
  local_8 = 0;
  do {
    if (3 < local_8) {
LAB_010394e6:
      if (*(short *)(param_3 + 0x10 + param_2 * 10) == 100) {
        FUN_010301f6(2,4,0);
        if (*param_1 == 0) {
          *(undefined2 *)(param_3 + 0x10 + param_2 * 10) = 0x20;
        }
        else {
          *(undefined2 *)(param_3 + 0x10 + param_2 * 10) = 0x21;
          if ((param_1[0x1d0] & 0xf8U) == 0) {
            uVar1 = (byte)*param_1 - 2;
            iVar2 = (int)uVar1 >> 1;
            if ((((int)uVar1 < 0 != iVar2 < 0) != iVar2 < 0) && ((uVar1 & 1) != 0)) {
              iVar2 = iVar2 + 1;
            }
            for (local_8 = 0; local_8 < iVar2; local_8 = local_8 + 1) {
              *(undefined2 *)(param_2 * 10 + param_3 + 0x10 + (local_8 + 1) * 2) =
                   *(undefined2 *)(*(int *)((int)&param_1 + local_8 * 2) + 4);
            }
            *(undefined2 *)(param_3 + 0x10 + param_2 * 10) = 100;
          }
        }
      }
      return;
    }
    FUN_010301f6(2,2,0);
    if (param_1[0x1cc] == 0) {
      *(undefined2 *)(param_3 + 0x10 + param_2 * 10) = 100;
      goto LAB_010394e6;
    }
    local_8 = local_8 + 1;
  } while( true );
}


// ==== FUN_010395e4 @ 010395e4

void FUN_010395e4(undefined4 *param_1,byte *param_2)

{
  byte bVar1;
  int local_8;
  
  if (*param_2 == 0x13) {
    bVar1 = *param_2;
    *param_2 = *param_2 + 1;
    FUN_01058f82(1,bVar1,"Slot Number  Board Name  Board-ID  Version    CH   IDC Version & Status");
  }
  if (*param_2 < 0x1d) {
    FUN_010301b4();
    FUN_010398be(*param_1);
    FUN_010398f2(param_1[1]);
    FUN_01039930(*(undefined2 *)(param_1 + 2));
    FUN_0103995e(*(undefined2 *)((int)param_1 + 10));
    if (((*(short *)(param_1 + 4) == 0x26) || (*(short *)(param_1 + 4) == 0x27)) ||
       (*(short *)(param_1 + 4) == 0x28)) {
      FUN_01039a1a(param_1,0);
      bVar1 = *param_2;
      *param_2 = *param_2 + 1;
      FUN_01058f82(1,bVar1,&DAT_0103da78);
    }
    else {
      for (local_8 = 0; local_8 < (int)param_1[3]; local_8 = local_8 + 1) {
        if (*param_2 < 0x1d) {
          FUN_010399dc(local_8);
          FUN_01039a1a(param_1,local_8);
          bVar1 = *param_2;
          *param_2 = *param_2 + 1;
          FUN_01058f82(1,bVar1,&DAT_0103da78);
          FUN_010301b4();
        }
      }
    }
  }
  return;
}


// ==== FUN_01039742 @ 01039742

void FUN_01039742(undefined4 param_1,int param_2,int param_3)

{
  int local_8;
  
  FUN_01048236("RS-422 : Board-ID & Communication. ");
  if (param_3 == 3) {
    FUN_01048236(PTR_s_Check_Abort__0103c9b2);
  }
  else {
    FUN_01048236(&DAT_0103972a);
    if (param_2 == 0) {
      FUN_01048236("  No Board");
      FUN_01058f82(1,0x13,"  No Board");
    }
    else {
      FUN_01048236("  Slot Number  Board Name  Board-ID  Version    CH   IDC Version & Status");
      for (local_8 = 0; local_8 < param_2; local_8 = local_8 + 1) {
        FUN_010397ea(*(undefined4 *)((int)&param_1 + local_8 * 0x38));
      }
    }
    FUN_0103002a(0x5dc);
  }
  return;
}


// ==== FUN_010397ea @ 010397ea

void FUN_010397ea(undefined4 *param_1)

{
  int local_8;
  
  FUN_010301b4();
  FUN_010398be(*param_1);
  FUN_010398f2(param_1[1]);
  FUN_01039930(*(undefined2 *)(param_1 + 2));
  FUN_0103995e(*(undefined2 *)((int)param_1 + 10));
  if (((*(short *)(param_1 + 4) == 0x26) || (*(short *)(param_1 + 4) == 0x27)) ||
     (*(short *)(param_1 + 4) == 0x28)) {
    FUN_01039a1a(param_1,0);
    FUN_01048236(&DAT_0103da76);
  }
  else {
    for (local_8 = 0; local_8 < (int)param_1[3]; local_8 = local_8 + 1) {
      FUN_010399dc(local_8);
      FUN_01039a1a(param_1,local_8);
      FUN_01048236(&DAT_0103da76);
      FUN_010301b4();
    }
  }
  return;
}


// ==== FUN_010398be @ 010398be

void FUN_010398be(undefined4 param_1)

{
  DAT_0103da7c = 0x23;
  FUN_0105ec54(1,param_1,1,&DAT_0103da7d);
  DAT_0103da7e = 0x20;
  return;
}


// ==== FUN_010398f2 @ 010398f2

void FUN_010398f2(int param_1)

{
  int local_8;
  
  for (local_8 = 0; local_8 < 8; local_8 = local_8 + 1) {
    (&DAT_0103da87)[local_8] =
         "UNKNOWN SIO-3   IF-51   IF-263  IF-328  IF-342  CH-1CH-2CH-3CH-4Pass              Send Error        Receive Time Out  Receive Error     Not Ready         Receive Data ErrorTerminal Not ReadyNo Board          Board Error       Display Board     Unknown Board     RS-232 : Board-ID & Communication. "
         [local_8 + param_1 * 8];
  }
  return;
}


// ==== FUN_01039930 @ 01039930

void FUN_01039930(undefined2 param_1)

{
  FUN_0105ee14(0,param_1,4,&DAT_0103da93);
  DAT_0103da97 = 0x20;
  return;
}


// ==== FUN_0103995e @ 0103995e

void FUN_0103995e(ushort param_1)

{
  DAT_0103da9b = 0x56;
  FUN_0105ee14(0,(int)(uint)param_1 >> 0xc,1,&DAT_0103da9c);
  DAT_0103da9d = 0x2e;
  FUN_0105ee14(0,param_1 & 0xfff,3,&DAT_0103da9e);
  DAT_0103daa1 = 0x20;
  return;
}


// ==== FUN_010399dc @ 010399dc

void FUN_010399dc(int param_1)

{
  int local_8;
  
  for (local_8 = 0; local_8 < 4; local_8 = local_8 + 1) {
    (&DAT_0103daa5)[local_8] =
         "UNKNOWN SIO-3   IF-51   IF-263  IF-328  IF-342  CH-1CH-2CH-3CH-4Pass              Send Error        Receive Time Out  Receive Error     Not Ready         Receive Data ErrorTerminal Not ReadyNo Board          Board Error       Display Board     Unknown Board     RS-232 : Board-ID & Communication. "
         [local_8 + param_1 * 4 + 0x30];
  }
  return;
}


// ==== FUN_01039a1a @ 01039a1a

void FUN_01039a1a(int param_1,int param_2)

{
  uint uVar1;
  int local_10;
  int local_8;
  
  local_10 = 0x35;
  uVar1 = (uint)*(ushort *)(param_1 + 0x10 + param_2 * 10);
  if (uVar1 == 100) {
    for (local_8 = 1; local_8 < 5; local_8 = local_8 + 1) {
      if (*(short *)(param_2 * 10 + param_1 + 0x10 + local_8 * 2) != 0) {
        (&DAT_0103da76)[local_10] = 0x56;
        FUN_0105ee14(0,(int)(uint)*(ushort *)(param_2 * 10 + param_1 + 0x10 + local_8 * 2) >> 0xc,1,
                     &DAT_0103da77 + local_10);
        (&DAT_0103da78)[local_10] = 0x2e;
        FUN_0105ee14(0,*(ushort *)(param_2 * 10 + param_1 + 0x10 + local_8 * 2) & 0xfff,3,
                     &UNK_0103da79 + local_10);
        (&DAT_0103da7c)[local_10] = 0x20;
      }
      local_10 = local_10 + 7;
    }
  }
  else {
    for (local_8 = 0; local_8 < 0x12; local_8 = local_8 + 1) {
      (&DAT_0103da76)[local_10] =
           "UNKNOWN SIO-3   IF-51   IF-263  IF-328  IF-342  CH-1CH-2CH-3CH-4Pass              Send Error        Receive Time Out  Receive Error     Not Ready         Receive Data ErrorTerminal Not ReadyNo Board          Board Error       Display Board     Unknown Board     RS-232 : Board-ID & Communication. "
           [local_8 + (uVar1 - 0x1e) * 0x12 + 0x40];
      local_10 = local_10 + 1;
    }
  }
  return;
}


// ==== FUN_01039cd0 @ 01039cd0

/* WARNING: Removing unreachable block (ram,0x01039d6c) */
/* WARNING: Removing unreachable block (ram,0x01039db0) */

void FUN_01039cd0(void)

{
  int unaff_D7;
  int iVar1;
  undefined *local_16;
  char local_11;
  int local_10;
  int local_c;
  undefined4 local_8;
  
  local_8 = 1;
  local_11 = '\x13';
  local_16 = &DAT_01039bb4;
  for (local_c = 0; local_c < 8; local_c = local_c + 1) {
    *(undefined4 *)((&local_16)[local_c * 8] + 0x10) = 100;
    *(undefined4 *)((&local_16)[local_c * 8] + 0x14) = 100;
    *(undefined4 *)((&local_16)[local_c * 8] + 0x18) = 100;
    unaff_D7 = local_c * 0x20;
    *(undefined4 *)((&local_16)[local_c * 8] + 0x1c) = 100;
  }
  FUN_01030352(1,1);
  FUN_01039e6e(local_16);
  local_10 = unaff_D7;
  if (unaff_D7 == 0) {
    FUN_010300da();
  }
  else {
    iVar1 = (int)local_11;
    local_11 = local_11 + '\x01';
    FUN_01058f82(1,iVar1,"Slot Number  Board Name  Board ID  Version    CH    Result");
    local_c = 0;
    if (0 < local_10) {
      FUN_010300da();
      FUN_0103a06a((&local_16)[local_c * 8]);
      FUN_0103a0de((&local_16)[local_c * 8],&local_11);
      FUN_0105ef12();
      return;
    }
  }
  FUN_01030352(0,1);
  FUN_0103a990(local_16,local_10,local_8);
  return;
}


// ==== FUN_01039e6e @ 01039e6e

void FUN_01039e6e(undefined4 param_1)

{
  int local_c;
  
  local_c = 0;
  while( true ) {
    if (7 < local_c) {
      local_c = 0;
      while( true ) {
        if (-1 < local_c) {
          return;
        }
        if ((*(ushort *)(*(int *)((int)&param_1 + local_c * 0x20) + 8) & 0xf000) == 0x1000) break;
        local_c = local_c + 1;
      }
      FUN_0105ef12();
      return;
    }
    if ((*(short *)(&DAT_0103fa52 + local_c * 2) != 0x1203) &&
       (*(short *)(&DAT_0103fa52 + local_c * 2) != -1)) break;
    local_c = local_c + 1;
  }
  FUN_0105ef12();
  return;
}


// ==== FUN_0103a06a @ 0103a06a

void FUN_0103a06a(undefined4 *param_1)

{
  int unaff_D7;
  
  FUN_0103a094(*param_1,0);
  *(undefined2 *)((int)param_1 + 10) = *(undefined2 *)(unaff_D7 + 0x3fc);
  return;
}


// ==== FUN_0103a094 @ 0103a094

void FUN_0103a094(void)

{
  return;
}


// ==== FUN_0103a0de @ 0103a0de

void FUN_0103a0de(int param_1,undefined4 param_2)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  
  uVar3 = 1;
  if ((*(int *)(param_1 + 0x10) == 0x30) || (*(int *)(param_1 + 0x10) == 0x31)) {
    FUN_0103a8c2(param_1,0,param_2);
  }
  else {
    iVar1 = 0;
    while (iVar1 < *(int *)(param_1 + 0xc)) {
      iVar2 = iVar1;
      FUN_0103a1b6(param_1,iVar1,iVar1,uVar3);
      if (iVar1 == 1) {
        FUN_0103a264(param_1,iVar2);
        FUN_0105ef12();
        return;
      }
      uVar3 = 2;
      FUN_0103a8c2(param_1,iVar2,param_2);
      iVar1 = iVar2 + 1;
    }
  }
  return;
}


// ==== FUN_0103a1b6 @ 0103a1b6

void FUN_0103a1b6(undefined4 *param_1,int param_2)

{
  undefined2 *unaff_D7;
  
  FUN_0103a094(*param_1,param_2);
  unaff_D7[1] = 3;
  *unaff_D7 = 1;
  FUN_010301f6(2,4,0);
  if ((unaff_D7[0x10] & 1) == 1) {
    if ((unaff_D7[0x11] & 0x80) != 0x80) {
      param_1[param_2 + 4] = 0x2a;
    }
  }
  else {
    param_1[param_2 + 4] = 0x29;
  }
  return;
}


// ==== FUN_0103a264 @ 0103a264

/* WARNING: Removing unreachable block (ram,0x0103a322) */
/* WARNING: Removing unreachable block (ram,0x0103a33a) */
/* WARNING: Removing unreachable block (ram,0x0103a334) */
/* WARNING: Removing unreachable block (ram,0x0103a32e) */
/* WARNING: Removing unreachable block (ram,0x0103a328) */
/* WARNING: Removing unreachable block (ram,0x0103a354) */

void FUN_0103a264(undefined4 param_1,undefined4 param_2)

{
  int unaff_D7;
  undefined4 local_14;
  undefined4 local_10;
  undefined4 local_c;
  undefined4 local_8;
  
  local_14 = 0;
  local_10 = 0;
  local_c = 0;
  local_8 = 5;
  FUN_0103a440(param_1,param_2,&local_14,1);
  if (unaff_D7 == 1) {
    local_8 = 0;
    local_c = 0;
    local_10 = 0;
    local_14 = 0;
    FUN_0103a54c(param_1,param_2,&local_14);
    FUN_010300da();
    return;
  }
  return;
}


// ==== FUN_0103a35c @ 0103a35c

void FUN_0103a35c(undefined4 *param_1,int param_2,int *param_3)

{
  ushort uVar1;
  ushort uVar2;
  ushort uVar3;
  ushort uVar4;
  short *unaff_D7;
  
  FUN_0103a094(*param_1,param_2);
  uVar1 = *(ushort *)(&DAT_0103d658 + param_3[3] * 2);
  uVar2 = *(ushort *)(&DAT_0103d66c + param_3[2] * 2);
  uVar3 = *(ushort *)(&DAT_0103d670 + param_3[1] * 2);
  uVar4 = *(ushort *)(&DAT_0103d676 + *param_3 * 2);
  unaff_D7[1] = 1;
  unaff_D7[2] = uVar4 | uVar3 | uVar2 | uVar1 | 0xff00;
  *unaff_D7 = 2;
  FUN_010301f6(2,2,0);
  if (*unaff_D7 != 0) {
    param_1[param_2 + 4] = 0x2b;
  }
  return;
}


// ==== FUN_0103a440 @ 0103a440

void FUN_0103a440(undefined4 *param_1,int param_2,undefined4 param_3)

{
  char cVar1;
  int unaff_D7;
  undefined4 local_14;
  char local_f;
  ushort local_e;
  undefined4 local_c;
  int local_8;
  
  local_c = 1;
  FUN_0103a35c(param_1,param_2,param_3);
  if (unaff_D7 == 1) {
    FUN_0103a094(*param_1,param_2);
    local_e = 0x1de;
    FUN_010456d4(0x1de);
    local_14 = 0x1de;
    local_f = ' ';
    for (local_8 = 0; cVar1 = local_f, local_8 < (int)(uint)local_e; local_8 = local_8 + 1) {
      local_f = local_f + '\x01';
      **(char **)((int)&local_14 + local_8) = cVar1;
      if (local_f == '~') {
        local_f = ' ';
      }
    }
    FUN_0103a62a(1);
    FUN_0103a668(1,local_14,local_e);
    FUN_0103a6c2(param_1,param_2,local_14,local_e,param_3);
    if (param_1[param_2 + 4] != 100) {
      local_c = 2;
    }
    FUN_01045712(local_14);
  }
  return;
}


// ==== FUN_0103a54c @ 0103a54c

void FUN_0103a54c(undefined4 *param_1,undefined4 param_2,int param_3)

{
  int unaff_D7;
  char acStack_1a [8];
  ushort local_12;
  int local_10;
  int local_c;
  undefined4 local_8;
  
  local_8 = 1;
  FUN_0103a35c(param_1,param_2,param_3);
  if (unaff_D7 == 1) {
    FUN_0103a094(*param_1,param_2);
    local_12 = 8;
    for (local_c = 0; local_c < (int)(uint)local_12; local_c = local_c + 1) {
      acStack_1a[local_c] = (char)local_c + '0';
    }
    FUN_0103a62a(1);
    local_10 = 10 - *(int *)(param_3 + 0xc);
    FUN_0103a668(1,acStack_1a,local_12);
    FUN_0103a6c2(param_1,param_2,acStack_1a,local_12,param_3);
  }
  return;
}


// ==== FUN_0103a62a @ 0103a62a

void FUN_0103a62a(int param_1)

{
  *(undefined2 *)(param_1 + 0x40) = 0;
  while (*(short *)(param_1 + 0x220) != 0) {
    *(undefined2 *)(param_1 + 0x220) = 0;
    FUN_010301f6(2,1,0);
  }
  *(undefined2 *)(param_1 + 0x40) = 0;
  return;
}


// ==== FUN_0103a668 @ 0103a668

void FUN_0103a668(int param_1,undefined4 param_2,ushort param_3)

{
  int iVar1;
  
  for (iVar1 = 0; iVar1 < (int)(uint)param_3; iVar1 = iVar1 + 1) {
    *(undefined1 *)(param_1 + 0x42 + iVar1) = **(undefined1 **)((int)&param_2 + iVar1);
  }
  FUN_010301f6(2,1,0,iVar1,100);
  *(ushort *)(param_1 + 0x40) = param_3;
  return;
}


// ==== FUN_0103a6c2 @ 0103a6c2

undefined4
FUN_0103a6c2(undefined4 *param_1,int param_2,undefined4 param_3,ushort param_4,int *param_5)

{
  int unaff_D7;
  uint uVar1;
  undefined4 uVar2;
  uint local_10 [3];
  
  FUN_0103a094(*param_1,param_2);
  uVar1 = (uint)param_4;
  FUN_010456d4(uVar1);
  local_10[0] = uVar1;
  if (*param_5 == 0) {
    for (local_10[2] = 0; (int)local_10[2] < (int)(uint)param_4; local_10[2] = local_10[2] + 1) {
      **(byte **)((int)&param_3 + local_10[2]) = **(byte **)((int)&param_3 + local_10[2]) & 0x7f;
    }
  }
  FUN_010301f6(2,10 - param_5[3],0);
  if (*(short *)(unaff_D7 + 0x220) == 0) {
    param_1[param_2 + 4] = 0x2c;
  }
  else {
    local_10[1] = 0;
    while (*(short *)(unaff_D7 + 0x220) != 0) {
      for (local_10[2] = 0; uVar1 = local_10[1],
          (int)local_10[2] < (int)*(short *)(unaff_D7 + 0x220); local_10[2] = local_10[2] + 1) {
        local_10[1] = local_10[1] + 1;
        **(undefined1 **)((int)local_10 + uVar1) = *(undefined1 *)(unaff_D7 + 0x222 + local_10[2]);
      }
      *(undefined2 *)(unaff_D7 + 0x220) = 0;
      FUN_010301f6(2,10 - param_5[3],0);
    }
    if (*param_5 == 0) {
      for (local_10[2] = 0; (int)local_10[2] < (int)(uint)param_4; local_10[2] = local_10[2] + 1) {
        **(byte **)((int)local_10 + local_10[2]) = **(byte **)((int)local_10 + local_10[2]) & 0x7f;
      }
    }
    if ((*(ushort *)(unaff_D7 + 0x22) & 0xe) == 0) {
      for (local_10[2] = 0; (int)local_10[2] < (int)(uint)param_4; local_10[2] = local_10[2] + 1) {
        if (**(char **)((int)local_10 + local_10[2]) != **(char **)((int)&param_3 + local_10[2])) {
          param_1[param_2 + 4] = 0x2e;
          break;
        }
      }
    }
    else {
      param_1[param_2 + 4] = 0x2d;
    }
  }
  if (*(short *)(unaff_D7 + 0x40) != 0) {
    param_1[param_2 + 4] = 0x2b;
  }
  FUN_01045712(local_10[0]);
  uVar2 = 0;
  FUN_010301f6(2,0x14);
  return uVar2;
}


// ==== FUN_0103a8c2 @ 0103a8c2

void FUN_0103a8c2(undefined4 *param_1,int param_2,byte *param_3)

{
  byte bVar1;
  
  FUN_010301b4();
  if (*param_3 < 0x1d) {
    if (param_2 == 0) {
      FUN_0103aade(*param_1);
      FUN_0103ab12(param_1[1]);
      FUN_0103ab50(*(undefined2 *)(param_1 + 2));
      FUN_0103ab7e(*(undefined2 *)((int)param_1 + 10));
    }
    if ((param_1[4] != 0x30) && (param_1[4] != 0x31)) {
      FUN_0103abee(param_2);
    }
    FUN_0103ac2c(param_1,param_2);
    bVar1 = *param_3;
    *param_3 = *param_3 + 1;
    FUN_01058f82(1,bVar1,&DAT_0103da78);
  }
  return;
}


// ==== FUN_0103a990 @ 0103a990

void FUN_0103a990(undefined4 param_1,int param_2,int param_3)

{
  int local_8;
  
  FUN_01048236("RS-232 : Board-ID & Communication. ");
  if (param_3 == 3) {
    FUN_01048236(PTR_s_Check_Abort__0103c9b2);
  }
  else {
    FUN_01048236(&DAT_0103a978);
    if (param_2 == 0) {
      FUN_01048236("  No Board");
      FUN_01058f82(1,0x13,"  No Board");
    }
    else {
      FUN_01048236("  Slot Number  Board Name  Board ID  Version    CH    Result");
      for (local_8 = 0; local_8 < param_2; local_8 = local_8 + 1) {
        FUN_0103aa32(*(undefined4 *)((int)&param_1 + local_8 * 0x20));
      }
    }
    FUN_0103002a(1000);
  }
  return;
}


// ==== FUN_0103aa32 @ 0103aa32

void FUN_0103aa32(undefined4 *param_1)

{
  int local_8;
  
  FUN_010301b4();
  FUN_0103aade(*param_1);
  FUN_0103ab12(param_1[1]);
  FUN_0103ab50(*(undefined2 *)(param_1 + 2));
  FUN_0103ab7e(*(undefined2 *)((int)param_1 + 10));
  for (local_8 = 0; local_8 < (int)param_1[3]; local_8 = local_8 + 1) {
    if ((param_1[4] != 0x30) && (param_1[4] != 0x31)) {
      FUN_0103abee(local_8);
    }
    FUN_0103ac2c(param_1,local_8);
    FUN_01048236(&DAT_0103da76);
    FUN_010301b4();
  }
  return;
}


// ==== FUN_0103aade @ 0103aade

void FUN_0103aade(undefined4 param_1)

{
  DAT_0103da7c = 0x23;
  FUN_0105ec54(1,param_1,1,&DAT_0103da7d);
  DAT_0103da7e = 0x20;
  return;
}


// ==== FUN_0103ab12 @ 0103ab12

void FUN_0103ab12(int param_1)

{
  int local_8;
  
  for (local_8 = 0; local_8 < 8; local_8 = local_8 + 1) {
    (&DAT_0103da87)[local_8] = "UNKNOWN SIO-4   Pass               "[local_8 + param_1 * 8];
  }
  return;
}


// ==== FUN_0103ab50 @ 0103ab50

void FUN_0103ab50(undefined2 param_1)

{
  FUN_0105ee14(0,param_1,4,&DAT_0103da93);
  DAT_0103da97 = 0x20;
  return;
}


// ==== FUN_0103ab7e @ 0103ab7e

/* WARNING: Restarted to delay deadcode elimination for space: stack */

void FUN_0103ab7e(undefined2 param_1)

{
  undefined1 uVar1;
  undefined2 uVar2;
  undefined2 local_a;
  undefined2 *local_8;
  
  local_a = param_1;
  uVar2 = local_a;
  DAT_0103da9b = 0x56;
  local_8 = &local_a;
  local_a._0_1_ = (undefined1)((ushort)param_1 >> 8);
  uVar1 = local_a._0_1_;
  local_a = uVar2;
  FUN_0105ee14(0,uVar1,2,&DAT_0103da9c);
  DAT_0103da9e = 0x2e;
  FUN_0105ee14(0,*(undefined1 *)((int)local_8 + 1),2,&DAT_0103da9f);
  DAT_0103daa1 = 0x20;
  return;
}


// ==== FUN_0103abee @ 0103abee

void FUN_0103abee(int param_1)

{
  int local_8;
  
  for (local_8 = 0; local_8 < 4; local_8 = local_8 + 1) {
    (&DAT_0103daa5)[local_8] =
         "UNKNOWN SIO-3   IF-51   IF-263  IF-328  IF-342  CH-1CH-2CH-3CH-4Pass              Send Error        Receive Time Out  Receive Error     Not Ready         Receive Data ErrorTerminal Not ReadyNo Board          Board Error       Display Board     Unknown Board     RS-232 : Board-ID & Communication. "
         [local_8 + param_1 * 4 + 0x30];
  }
  return;
}


// ==== FUN_0103ac2c @ 0103ac2c

void FUN_0103ac2c(int param_1,int param_2)

{
  int local_8;
  
  if (*(int *)(param_1 + 0x10 + param_2 * 4) == 100) {
    for (local_8 = 0; local_8 < 0x13; local_8 = local_8 + 1) {
      (&DAT_0103daac)[local_8] = "UNKNOWN SIO-4   Pass               "[local_8 + 0x10];
    }
  }
  else {
    for (local_8 = 0; local_8 < 0x13; local_8 = local_8 + 1) {
      (&DAT_0103daac)[local_8] =
           "UNKNOWN SIO-4   Pass               "
           [local_8 + (*(int *)(param_1 + 0x10 + param_2 * 4) + -0x28) * 0x14 + 0x10];
    }
  }
  return;
}


// ==== FUN_0103ad30 @ 0103ad30

void FUN_0103ad30(void)

{
  return;
}


// ==== FUN_0103ad44 @ 0103ad44

void FUN_0103ad44(void)

{
  return;
}


// ==== FUN_0103fed0 @ 0103fed0

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0103fed0(void)

{
  int local_8;
  
  _DAT_0103fa50 = 0;
  FUN_01040466();
  _DAT_0103f97a = 0xb;
  _DAT_0103f978 = 0xb;
  DAT_0103f97c = 0xb;
  FUN_0104084c();
  FUN_0103ff76();
  while (_DAT_0d01cae0 != 0) {
    _DAT_0d01cae0 = 0;
    for (local_8 = 0; local_8 < 500; local_8 = local_8 + 1) {
    }
  }
  for (local_8 = 0; local_8 < 0xfe; local_8 = local_8 + 1) {
    (&DAT_0d01cae2)[local_8] = 0;
  }
  return;
}


// ==== FUN_0103ff76 @ 0103ff76

/* WARNING: Removing unreachable block (ram,0x0103fff8) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0103ff76(void)

{
  _DAT_0103fa62 = 0xfff83fe;
  FUN_0105ef12();
  return;
}


// ==== FUN_0103fffc @ 0103fffc

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0103fffc(void)

{
  int local_14;
  undefined1 *local_8;
  
  local_8 = &DAT_0d01cae2;
  if (_DAT_0d01cae0 != 0) {
    _DAT_0103fa4e = _DAT_0d01cae0;
    for (local_14 = 0; local_14 < 0x10; local_14 = local_14 + 1) {
      (&DAT_0103fa3e)[local_14] = (&DAT_0d01cae2)[local_14];
    }
    for (local_14 = 0; local_14 < _DAT_0d01cae0; local_14 = local_14 + 1) {
      **(undefined1 **)((int)&local_8 + local_14) = 0;
    }
    _DAT_0d01cae0 = 0;
  }
  return;
}


// ==== FUN_010400ea @ 010400ea

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_010400ea(void)

{
  int local_14;
  undefined1 *local_8;
  
  local_8 = &DAT_0d01cae2;
  if (_DAT_0d01cae0 != 0) {
    _DAT_0103fa4e = _DAT_0d01cae0;
    for (local_14 = 0; local_14 < 0x10; local_14 = local_14 + 1) {
      (&DAT_0103fa3e)[local_14] = (&DAT_0d01cae2)[local_14];
    }
    for (local_14 = 0; local_14 < _DAT_0d01cae0; local_14 = local_14 + 1) {
      **(undefined1 **)((int)&local_8 + local_14) = 0;
    }
    _DAT_0d01cae0 = 0;
  }
  return;
}


// ==== FUN_01040228 @ 01040228

void FUN_01040228(void)

{
  return;
}


// ==== FUN_01040284 @ 01040284

void FUN_01040284(void)

{
  FUN_0105ef12();
  return;
}


// ==== FUN_010403a4 @ 010403a4

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_010403a4(short param_1,undefined4 param_2)

{
  uint local_c;
  
  if ((DAT_0d01cc23 & 0x80) != 0) {
    _DAT_0d01ce20 = 0;
    for (local_c = 0; local_c < (uint)(int)param_1; local_c = local_c + 1) {
      *(undefined1 *)(local_c + 0xd01cc42) = **(undefined1 **)((int)&param_2 + local_c);
    }
    _DAT_0d01cc40 = param_1;
    local_c = 0;
    while ((local_c < 500000 && (param_1 != 0))) {
      local_c = local_c + 1;
    }
  }
  return;
}


// ==== FUN_01040466 @ 01040466

void FUN_01040466(void)

{
  char unaff_D7b;
  int local_14;
  
  FUN_0105a9e6();
  FUN_01030498();
  DAT_0103fa3c = unaff_D7b == '\x02';
  if ((bool)DAT_0103fa3c) {
    DAT_0103ada2 = 0x31;
  }
  DAT_0103f1c6 = 0;
  DAT_0103dacb = 1;
  DAT_0103daca = 1;
  for (local_14 = 0; local_14 < 0xf; local_14 = local_14 + 1) {
    (&DAT_0103f9c4)[local_14] = 0;
    (&DAT_0103f9b4)[local_14] = 0;
  }
  DAT_0103f9d3 = 0;
  DAT_0103f9c3 = 0;
  DAT_0103f1b6 = 0;
  DAT_0103f1b5 = 0;
  DAT_0103f1b4 = 0;
  FUN_010304de();
  FUN_0105ef12();
  return;
}


// ==== FUN_0104084c @ 0104084c

void FUN_0104084c(void)

{
  DAT_0103f981 = 0x20;
  DAT_0103f982 = 0x20;
  DAT_0103f983 = 0;
  DAT_0103f980 = 2;
  DAT_0103f1c5 = 1;
  FUN_0105e8ea();
  FUN_01051742(1);
  FUN_010522c4(1);
  return;
}


// ==== FUN_01040bac @ 01040bac

void FUN_01040bac(void)

{
  int local_8;
  
  FUN_0105ed0e(&DAT_0103f981,DAT_0103f980,&local_8);
  if (local_8 == -1) {
    return;
  }
  if ((local_8 < 0x11) && ((&DAT_0103ae6e)[local_8] == '\x01')) {
    return;
  }
  return;
}


// ==== FUN_01040e34 @ 01040e34

void FUN_01040e34(void)

{
  DAT_0103f981 = 0x20;
  DAT_0103f982 = 0x20;
  DAT_0103f983 = 0;
  DAT_0103f980 = 2;
  DAT_0103f1c5 = 3;
  FUN_0104121c(&DAT_0103f9c4,&DAT_0103f9b4);
  DAT_0103f1c0 = 0;
  DAT_0103f1c4 = '\x01';
  FUN_0105e8ea();
  FUN_01051742(1);
  FUN_01052a62(1);
  FUN_010533e4(1,(int)DAT_0103f1c4);
  return;
}


// ==== FUN_01040ffe @ 01040ffe

void FUN_01040ffe(void)

{
  int local_8;
  
  FUN_0105ed0e(&DAT_0103f981,DAT_0103f980,&local_8);
  if (local_8 == -1) {
    return;
  }
  if ((local_8 < 1) || (5 < local_8)) {
    return;
  }
  return;
}


// ==== FUN_01041050 @ 01041050

void FUN_01041050(void)

{
  FUN_010532c8(1,(int)(char)DAT_0103f1c4,DAT_0103f1c0);
  (&DAT_0103f9b3)[(char)DAT_0103f1c4] = (undefined1)DAT_0103f1c0;
  if (DAT_0103f9c3 < DAT_0103f1c4) {
    DAT_0103f9c3 = DAT_0103f1c4;
  }
  if ((char)DAT_0103f1c4 < '\x0f') {
    FUN_010410dc(0x52);
  }
  return;
}


// ==== FUN_010410dc @ 010410dc

void FUN_010410dc(void)

{
  FUN_010533e4(0,(int)DAT_0103f1c4);
  FUN_0105ef12();
  return;
}


// ==== FUN_01041136 @ 01041136

void FUN_01041136(void)

{
  char local_5;
  
  for (local_5 = '\0'; local_5 < '\x0f'; local_5 = local_5 + '\x01') {
    (&DAT_0103f9b4)[local_5] = 0;
  }
  DAT_0103f9c3 = 0;
  DAT_0103f981 = 0x20;
  DAT_0103f982 = 0x20;
  DAT_0103f983 = 0;
  DAT_0103f1c0 = 0;
  FUN_01053216(0);
  FUN_010536f6(1);
  FUN_010410dc(0x54);
  return;
}


// ==== FUN_0104119e @ 0104119e

void FUN_0104119e(void)

{
  char local_5;
  
  if (DAT_0103f9d3 == '\0') {
    DAT_0103fa04 = 0;
    DAT_0103f9a4 = 1;
    DAT_0103f9a5 = 2;
    DAT_0103f9a6 = 3;
    DAT_0103f9a7 = 4;
    DAT_0103f9a8 = 5;
    for (local_5 = '\x06'; local_5 < '\x0f'; local_5 = local_5 + '\x01') {
      (&DAT_0103f9a4)[local_5] = 0;
    }
    DAT_0103f9b3 = 5;
  }
  else {
    FUN_0104121c(&DAT_0103f9c4,&DAT_0103f9a4);
  }
  return;
}


// ==== FUN_0104121c @ 0104121c

void FUN_0104121c(int param_1,int param_2)

{
  char local_5;
  
  for (local_5 = '\0'; local_5 < '\x0f'; local_5 = local_5 + '\x01') {
    **(undefined1 **)((int)&param_2 + (int)local_5) =
         **(undefined1 **)((int)&param_1 + (int)local_5);
  }
  *(undefined1 *)(param_2 + 0xf) = *(undefined1 *)(param_1 + 0xf);
  return;
}


// ==== FUN_010412aa @ 010412aa

void FUN_010412aa(void)

{
  DAT_0103f981 = 0x20;
  DAT_0103f982 = 0;
  DAT_0103f980 = 1;
  DAT_0103db45 = 1;
  FUN_0105e8ea();
  FUN_01051742(1);
  FUN_01054672(1);
  return;
}


// ==== FUN_0104179a @ 0104179a

void FUN_0104179a(void)

{
  int local_8;
  
  FUN_0105ed0e(&DAT_0103f981,DAT_0103f980,&local_8);
  if (local_8 == -1) {
    return;
  }
  if (local_8 == 0) {
    return;
  }
  return;
}


// ==== FUN_010418ba @ 010418ba

void FUN_010418ba(void)

{
  DAT_0103f981 = 0x20;
  DAT_0103f982 = 0;
  DAT_0103f980 = 1;
  DAT_0103db44 = 1;
  FUN_0105e8ea();
  FUN_01051742(1);
  FUN_01054df6(1);
  return;
}


// ==== FUN_01041e5c @ 01041e5c

void FUN_01041e5c(char param_1)

{
  FUN_01055660(0,(int)DAT_0103db42);
  DAT_0103db42 = param_1;
  FUN_01055660(1,(int)param_1);
  return;
}


// ==== FUN_01041e96 @ 01041e96

void FUN_01041e96(void)

{
  if (DAT_0103db43 < '\x02') {
    FUN_010518f8(1,1);
  }
  else {
    DAT_0103db43 = DAT_0103db43 + -1;
    FUN_01041f3a((int)DAT_0103db43);
  }
  return;
}


// ==== FUN_01041ed0 @ 01041ed0

void FUN_01041ed0(void)

{
  if (DAT_0103db43 < DAT_0103f9b3) {
    DAT_0103db43 = DAT_0103db43 + 1;
    FUN_01041f3a((int)(char)DAT_0103db43);
  }
  else {
    FUN_010518f8(1,2);
  }
  return;
}


// ==== FUN_01041f3a @ 01041f3a

void FUN_01041f3a(char param_1)

{
  FUN_01055728(0);
  FUN_010518f8(0,1);
  FUN_01051890(1,"ABIJEFMNAll Test  " + (short)(char)(&DAT_0103f9a3)[param_1] * 0xc + 8);
  FUN_0105ef12();
  return;
}


// ==== FUN_010421c4 @ 010421c4

void FUN_010421c4(void)

{
  DAT_0103f1c5 = 2;
  DAT_0103f1bf = 0;
  DAT_0103f1b6 = 0;
  DAT_0103f1b4 = 0;
  DAT_0103db47 = 0;
  DAT_0103f9d4 = 0x41;
  DAT_0103f9d5 = 0;
  DAT_0103f9d6 = 0;
  DAT_0103f9d8 = 0;
  FUN_0105e8ea();
  FUN_01051742(1);
  FUN_01053896(1);
  FUN_010539ee(1);
  FUN_01053b0e(1);
  FUN_01053c38(1);
  FUN_01053d64(1);
  DAT_0103f981 = DAT_0103f9d4;
  DAT_0103f982 = 0;
  FUN_01053a40(1,0x6e);
  FUN_0105ec54(0,DAT_0103f9d5,1,&DAT_0103f981);
  FUN_01053b66(1,0x6e);
  FUN_0105ec54(0,DAT_0103f9d6,3,&DAT_0103f981);
  FUN_01053c92(1,0x6e);
  FUN_0105ec54(0,DAT_0103f9d8,3,&DAT_0103f981);
  FUN_01053dbe(1,0x6e);
  return;
}


// ==== FUN_01042354 @ 01042354

void FUN_01042354(void)

{
  bool bVar1;
  ushort uVar3;
  uint uVar2;
  uint uVar4;
  int unaff_D7;
  uint uVar5;
  uint *puVar6;
  uint *puVar7;
  
  FUN_01042be6();
  if (unaff_D7 == 0) {
    return;
  }
  FUN_010519aa(0,1);
  uVar5 = (uint)DAT_0103f97e;
  puVar6 = (uint *)&UNK_01042304;
  while( true ) {
    puVar7 = puVar6 + 1;
    uVar2 = *puVar6;
    if (uVar2 == 0) break;
    uVar5 = uVar5 - *puVar7;
    if (uVar5 < uVar2) {
                    /* WARNING: Could not recover jumptable at 0x0105ef2c. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      (*(code *)puVar6[uVar5 + 2])();
      return;
    }
    uVar5 = *puVar7 + uVar5;
    puVar6 = puVar6 + uVar2 + 2;
  }
  uVar2 = *puVar7;
  if (uVar2 != 0) {
    if (8 < uVar2) {
      puVar6 = puVar6 + 2;
      puVar7 = puVar6 + uVar2 * 2;
      do {
        uVar4 = uVar2 & 0xfffffffe;
        if (puVar6[uVar4 + 1] <= uVar5) {
          if (uVar5 <= puVar6[uVar4 + 1]) {
                    /* WARNING: Could not recover jumptable at 0x0105ef6c. Too many branches */
                    /* WARNING: Treating indirect jump as call */
            (*(code *)puVar6[uVar4])();
            return;
          }
          puVar6 = puVar6 + uVar4 + 2;
          uVar2 = uVar2 - 1;
        }
        bVar1 = -1 < (int)uVar2;
        uVar2 = uVar2 >> 1;
      } while (uVar2 != 0 && bVar1);
                    /* WARNING: Could not recover jumptable at 0x0105ef7a. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      (*(code *)*puVar7)();
      return;
    }
    uVar2 = uVar2 - 1;
    do {
      if (uVar5 == puVar7[2]) break;
      puVar7 = puVar7 + 2;
      uVar3 = (short)uVar2 - 1;
      uVar2 = (uint)uVar3;
    } while (uVar3 != 0xffff);
  }
                    /* WARNING: Could not recover jumptable at 0x0105ef4c. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (*(code *)puVar7[1])();
  return;
}


// ==== FUN_01042532 @ 01042532

void FUN_01042532(void)

{
  int unaff_D7;
  
  FUN_01042be6();
  if (unaff_D7 == 0) {
    return;
  }
  if ((DAT_0103f97e == 0x118) || (DAT_0103f97e == 0x119)) {
    DAT_0103f981 = "ABIJEFMNAll Test  "[(short)(DAT_0103f97e + -0x118)];
    FUN_01053a40(1,0x72);
    return;
  }
  DAT_0103f1bf = 0;
  FUN_0105ef12();
  return;
}


// ==== FUN_0104268a @ 0104268a

void FUN_0104268a(void)

{
  FUN_01042be6();
  FUN_0105ef12();
  return;
}


// ==== FUN_010427ee @ 010427ee

void FUN_010427ee(void)

{
  FUN_01042be6();
  FUN_0105ef12();
  return;
}


// ==== FUN_010429a6 @ 010429a6

void FUN_010429a6(void)

{
  FUN_01042be6();
  FUN_0105ef12();
  return;
}


// ==== FUN_01042be6 @ 01042be6

void FUN_01042be6(void)

{
  if (DAT_0103fa3c == '\x01') {
    if (DAT_0103f97e == 0x69) {
      DAT_0103f97e = 0x5c;
    }
    if (DAT_0103f97e == 0x75) {
      DAT_0103f97e = 0x5e;
    }
  }
  FUN_0105ef12();
  return;
}


// ==== FUN_0104360c @ 0104360c

void FUN_0104360c(void)

{
  char local_10;
  char local_f;
  undefined1 local_e;
  undefined1 local_d;
  undefined1 *local_a;
  short local_6;
  
  local_6 = 0;
  local_a = &DAT_0103db48;
  DAT_0103f1b5 = (char)((DAT_0103f1b8 + 0xf) / 0x10);
  if ('F' < DAT_0103f1b5) {
    DAT_0103f1b5 = 'F';
  }
  DAT_0103f1b6 = (undefined1)((DAT_0103f1b5 + 0xf) / 0x10);
  for (local_f = '\0'; local_f < 'F'; local_f = local_f + '\x01') {
    for (local_10 = '\0'; local_10 < 'R'; local_10 = local_10 + '\x01') {
      **(undefined1 **)((int)&local_a + (int)local_10 + (short)local_f * 0x52) = 0x20;
    }
  }
  for (local_f = '\0'; local_f < DAT_0103f1b5; local_f = local_f + '\x01') {
    FUN_0105ee14(0,(int)local_6,3,&local_e);
    *local_a = local_e;
    local_a[1] = local_d;
    local_10 = '\0';
    for (; (local_10 < '\x10' && (local_6 < DAT_0103f1b8)); local_6 = local_6 + 1) {
      FUN_0105ee14(0,(int)**(char **)(&DAT_0103f1ba + local_6),2,&local_e);
      local_a[(short)local_10 * 3 + 10] = local_e;
      local_a[(short)local_10 * 3 + 0xb] = local_d;
      if ((' ' < **(char **)(&DAT_0103f1ba + local_6)) &&
         (**(char **)(&DAT_0103f1ba + local_6) < '\x7f')) {
        local_a[local_10 + 0x3d] = **(undefined1 **)(&DAT_0103f1ba + local_6);
      }
      local_10 = local_10 + '\x01';
    }
    local_a[0x50] = 0;
    local_a[0x51] = 0;
    local_a = local_a + 0x52;
  }
  return;
}


// ==== FUN_01043920 @ 01043920

void FUN_01043920(char param_1)

{
  DAT_0103db40 = 1;
  if (param_1 == '\0') {
    FUN_0105e8ea();
  }
  FUN_01051742(1);
  FUN_01056faa(1);
  return;
}


// ==== FUN_01043954 @ 01043954

void FUN_01043954(void)

{
  DAT_0103db40 = 2;
  DAT_0103db36 = 1;
  FUN_0104427c();
  if (DAT_0103db36 <= DAT_0103db38) {
    FUN_0105796e(1,(int)DAT_0103db36);
  }
  FUN_01057a26(1);
  return;
}


// ==== FUN_010439a2 @ 010439a2

void FUN_010439a2(void)

{
  FUN_01040284();
  FUN_0104427c();
  DAT_0103db34 = 1;
  DAT_0103db36 = 1;
  DAT_0103db32 = 1;
  FUN_01057b74(1);
  return;
}


// ==== FUN_010439d4 @ 010439d4

void FUN_010439d4(void)

{
  DAT_0103db40 = 4;
  DAT_0103dadc = '\0';
  FUN_01043a70(&DAT_0103f9df,&DAT_0103f9da);
  FUN_0104427c();
  FUN_010570f8(1);
  FUN_01043ec6((int)DAT_0103dadc);
  FUN_01057204(1,0x72);
  FUN_010574e6(1,0x6e);
  FUN_010575e6(1,0x6e);
  FUN_0105773e(1,0x6e);
  FUN_0105788e(1,0x6e);
  return;
}


// ==== FUN_01043a70 @ 01043a70

void FUN_01043a70(undefined1 *param_1,undefined1 *param_2)

{
  *param_2 = *param_1;
  param_2[1] = param_1[1];
  param_2[2] = param_1[2];
  param_2[3] = param_1[3];
  param_2[4] = param_1[4];
  return;
}


// ==== FUN_01043c32 @ 01043c32

void FUN_01043c32(void)

{
  (&DAT_0103f9da)[DAT_0103dadc] = (char)DAT_0103f97e + -0x18;
  FUN_01043e1a((int)DAT_0103dadc,0x72);
  return;
}


// ==== FUN_01043c76 @ 01043c76

void FUN_01043c76(void)

{
  char *pcVar1;
  
  pcVar1 = &DAT_0103f9da + DAT_0103dadc;
  if (*pcVar1 == '\0') {
    if (DAT_0103dadc == '\0') {
      DAT_0103f9da = 6;
    }
    else {
      *pcVar1 = '\x01';
    }
  }
  else {
    *pcVar1 = *pcVar1 + -1;
  }
  FUN_01043e1a((int)DAT_0103dadc,0x72);
  return;
}


// ==== FUN_01043cd0 @ 01043cd0

void FUN_01043cd0(void)

{
  char *pcVar1;
  
  pcVar1 = (char *)(&DAT_0103f9da + DAT_0103dadc);
  if (DAT_0103dadc == '\0') {
    if (DAT_0103f9da < 6) {
      DAT_0103f9da = DAT_0103f9da + 1;
    }
    else {
      DAT_0103f9da = 0;
    }
  }
  else if (*pcVar1 == '\0') {
    *pcVar1 = '\x01';
  }
  else {
    *pcVar1 = '\0';
  }
  FUN_01043e1a((int)DAT_0103dadc,0x72);
  return;
}


// ==== FUN_01043d3a @ 01043d3a

void FUN_01043d3a(void)

{
  FUN_01043e1a((int)DAT_0103dadc,0x6e);
  if (DAT_0103dadc < '\x01') {
    DAT_0103dadc = '\x04';
  }
  else {
    DAT_0103dadc = DAT_0103dadc + -1;
  }
  FUN_01043e1a((int)DAT_0103dadc,0x72);
  FUN_01043ec6((int)DAT_0103dadc);
  return;
}


// ==== FUN_01043d96 @ 01043d96

void FUN_01043d96(void)

{
  FUN_01043e1a((int)DAT_0103dadc,0x6e);
  if (DAT_0103dadc < '\x04') {
    DAT_0103dadc = DAT_0103dadc + '\x01';
  }
  else {
    DAT_0103dadc = '\0';
  }
  FUN_01043e1a((int)DAT_0103dadc,0x72);
  FUN_01043ec6((int)DAT_0103dadc);
  return;
}


// ==== FUN_01043e1a @ 01043e1a

void FUN_01043e1a(void)

{
  FUN_0105ef12();
  return;
}


// ==== FUN_01043ec6 @ 01043ec6

void FUN_01043ec6(void)

{
  FUN_0105ef12();
  return;
}


// ==== FUN_01043f22 @ 01043f22

void FUN_01043f22(void)

{
  int unaff_D7;
  
  if (0 < DAT_0103db38) {
    FUN_01040228();
    if (unaff_D7 == 0) {
      FUN_010519aa(1,1);
    }
    else {
      FUN_010439a2();
      do {
        FUN_01043f92();
        if (unaff_D7 == 7) {
          return;
        }
      } while (unaff_D7 != 6);
    }
  }
  return;
}


// ==== FUN_01043f92 @ 01043f92

/* WARNING: Removing unreachable block (ram,0x01043fdc) */

void FUN_01043f92(void)

{
  int unaff_D7;
  
  while( true ) {
    unaff_D7 = CONCAT22((short)((uint)unaff_D7 >> 0x10),DAT_0103db38);
    if (DAT_0103db38 < DAT_0103db32) {
      FUN_01043920(1);
      return;
    }
    FUN_01044062();
    if (unaff_D7 == 5) {
      FUN_01044132();
      FUN_010441d8();
    }
    if (unaff_D7 == 7) break;
    if (unaff_D7 == 6) {
      return;
    }
  }
  FUN_01043920(0);
  return;
}


// ==== FUN_01044062 @ 01044062

/* WARNING: Removing unreachable block (ram,0x0104412a) */

void FUN_01044062(void)

{
  FUN_0103fffc();
  FUN_0105ef12();
  return;
}


// ==== FUN_01044132 @ 01044132

undefined * FUN_01044132(void)

{
  int local_8;
  
  for (local_8 = 0; *(char *)(local_8 + *(int *)(&UNK_0103dae8 + DAT_0103db32 * 0x54)) != '\0';
      local_8 = local_8 + 1) {
    (&DAT_0103dadd)[local_8] =
         *(undefined1 *)(local_8 + *(int *)(&UNK_0103dae8 + DAT_0103db32 * 0x54));
  }
  (&DAT_0103dadd)[local_8] = 10;
  (&DAT_0103dade)[local_8] = 0xd;
  FUN_010403a4(local_8 + 2);
  if (local_8 == 1) {
    DAT_0103db32 = DAT_0103db32 + 1;
  }
  return &DAT_0103dadd;
}


// ==== FUN_010441d8 @ 010441d8

void FUN_010441d8(void)

{
  char local_6;
  
  if ((int)DAT_0103db36 % 0x14 == 1) {
    local_6 = '\x02';
    FUN_0104427c();
  }
  else if ((int)DAT_0103db36 % 0x14 == 0) {
    local_6 = '\x15';
  }
  else {
    local_6 = (char)((int)DAT_0103db36 % 0x14) + '\x01';
  }
  FUN_0105d368(0,local_6,*(undefined4 *)(&UNK_0103dae8 + DAT_0103db36 * 0x54),7,0);
  DAT_0103db36 = DAT_0103db36 + 1;
  return;
}


// ==== FUN_0104427c @ 0104427c

void FUN_0104427c(void)

{
  byte local_5;
  
  for (local_5 = 0; local_5 < 0x19; local_5 = local_5 + 1) {
    FUN_0105e89e(local_5 + 2);
  }
  return;
}


// ==== FUN_0104438a @ 0104438a

void FUN_0104438a(void)

{
  FUN_010518f8(0,1);
  if ((int)DAT_0103db38 < DAT_0103db36 + 0x14) {
    FUN_010518f8(1,2);
  }
  else {
    DAT_0103db36 = DAT_0103db36 + 0x14;
    if ((int)DAT_0103db38 < DAT_0103db36 + 0x14) {
      FUN_010518f8(1,2);
    }
    FUN_0105796e(1,(int)DAT_0103db36);
  }
  return;
}


// ==== FUN_01044410 @ 01044410

void FUN_01044410(void)

{
  FUN_010518f8(0,2);
  if (DAT_0103db36 == 1) {
    FUN_010518f8(1,1);
  }
  else {
    DAT_0103db36 = DAT_0103db36 + -0x14;
    if (DAT_0103db36 == 1) {
      FUN_010518f8(1,1);
    }
    FUN_0105796e(1,(int)DAT_0103db36);
  }
  return;
}


// ==== FUN_01044482 @ 01044482

void FUN_01044482(void)

{
  return;
}


// ==== FUN_01044488 @ 01044488

void FUN_01044488(void)

{
  return;
}


// ==== FUN_0104459e @ 0104459e

undefined8 FUN_0104459e(void)

{
  undefined4 in_D0;
  undefined4 in_D1;
  int in_VBR;
  
  FUN_01045476(0xfc);
  *(undefined4 *)(in_VBR + 0x10) = DAT_0104453a;
  return CONCAT44(in_D0,in_D1);
}


// ==== FUN_01044640 @ 01044640

void FUN_01044640(void)

{
  FUN_01044482("=== DUMMY ADDRESS ===\n");
  return;
}


// ==== FUN_01044654 @ 01044654

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_01044654(void)

{
  _DAT_0105f004 = 0;
  DAT_0105f008 = 0;
  DAT_0105f00c = 0;
  _DAT_0105f010 = 0;
  DAT_0105f014 = 0;
  PTR_FUN_0105f018 = FUN_01044640;
  return;
}


// ==== FUN_0104467e @ 0104467e

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0104467e(undefined4 param_1,int param_2)

{
  FUN_0104514c(1,0x80);
  if (((_DAT_0105f004 == 0) && (param_2 != 0)) && (DAT_0105f008 = param_2, DAT_0105f014 == 0)) {
    FUN_010447ec();
  }
  if (DAT_0105f014 != 0) {
    FUN_0104514c(2,0x80);
  }
  do {
  } while (_DAT_0105f004 == 0);
  _DAT_0105f004 = 0;
  return;
}


// ==== FUN_010446e6 @ 010446e6

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_010446e6(undefined4 param_1,undefined4 param_2)

{
  FUN_0104514c(1,0x80);
  if (_DAT_0105f004 == 0) {
    _DAT_0105f004 = 1;
    DAT_0105f008 = 0;
    DAT_0105f00c = param_2;
  }
  if ((DAT_0105f014 != 0) || (DAT_0105f008 != 0)) {
    FUN_0104514c(2,0x80);
  }
  return;
}


// ==== FUN_0104473c @ 0104473c

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0104473c(void)

{
  if ((DAT_0105f008 != 0) && (DAT_0105f008 = DAT_0105f008 + -1, DAT_0105f008 == 0)) {
    _DAT_0105f004 = 1;
    DAT_0105f00c = 0x40000000;
  }
  if ((DAT_0105f014 != 0) && (DAT_0105f014 = DAT_0105f014 + -1, DAT_0105f014 == 0)) {
    (*(code *)PTR_FUN_0105f018)();
  }
  if ((DAT_0105f008 == 0) && (DAT_0105f014 == 0)) {
    FUN_0104514c(1,0x80);
  }
  return;
}


// ==== FUN_010447a4 @ 010447a4

void FUN_010447a4(undefined *param_1,undefined4 param_2)

{
  FUN_0104514c(1,0x80);
  PTR_FUN_0105f018 = param_1;
  DAT_0105f014 = param_2;
  if (DAT_0105f008 == 0) {
    FUN_010447ec();
  }
  else {
    FUN_0104514c(2,0x80);
  }
  return;
}


// ==== FUN_010447ec @ 010447ec

void FUN_010447ec(void)

{
  FUN_01045402(1,0,400);
  FUN_01045402(1,1,100);
  FUN_0104514c(2,0x80);
  return;
}


// ==== FUN_01044828 @ 01044828

void FUN_01044828(undefined *param_1)

{
  FUN_0104514c(1,0x80);
  if ((DAT_0105f014 != 0) && (param_1 == PTR_FUN_0105f018)) {
    DAT_0105f014 = 0;
  }
  if ((DAT_0105f014 != 0) || (DAT_0105f008 != 0)) {
    FUN_0104514c(2,0x80);
  }
  return;
}


// ==== FUN_0104488c @ 0104488c

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0104488c(void)

{
  DAT_0105f01c = 0;
  DAT_0105f01d = 0;
  DAT_0105f01e = 0;
  DAT_0105f030 = 0xc0;
  DAT_0f00c000 = 0xc0;
  DAT_0f008001 = 3;
  _DAT_0f008008 = 0x22c;
  DAT_0f00800e = 0xf;
  DAT_0f008000 = 3;
  DAT_0f00800b = 0x40;
  FUN_01044f80(3);
  return;
}


// ==== FUN_01044940 @ 01044940

void FUN_01044940(void)

{
  FUN_0105ef12();
  return;
}


// ==== FUN_01044a2c @ 01044a2c

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_01044a2c(uint param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int iVar1;
  undefined4 in_D0;
  byte bVar2;
  undefined4 local_10;
  ushort local_8;
  
  local_8 = _DAT_0f008008 & 0xff | 0x2c;
  if ((param_1 == 3) || (local_10 = in_D0, param_1 == 2)) {
    iVar1 = 1 << (param_1 & 0x3f);
    bVar2 = DAT_0f00800e | (byte)iVar1;
    DAT_0f008000 = (undefined1)param_1;
    local_10 = param_2;
    _DAT_0f008008 = local_8;
    DAT_0f00800e = bVar2;
    FUN_01044eb2();
    if (CONCAT31((int3)((uint)iVar1 >> 8),(undefined1)param_1) != 0) {
      local_10 = param_4;
      FUN_01044afc(param_3);
      if (-1 < iVar1) {
        DAT_0f00800e = ~(byte)(1 << (param_1 & 0x3f)) & bVar2;
      }
    }
  }
  local_8 = local_8 & 0xfffb;
  _DAT_0f008008 = local_8;
  return local_10;
}


// ==== FUN_01044afc @ 01044afc

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_01044afc(int param_1,int param_2)

{
  param_2 = param_2 + -1;
  if (param_2 < 0) {
    param_2 = -param_2;
  }
  if (param_1 != 0) {
    DAT_0105f030 = DAT_0105f030 & 0xe0 | (byte)((uint)param_1 >> 0x18) & 0x1f;
    DAT_0f008007 = (undefined1)((uint)param_1 >> 0x10);
    _DAT_0f008004 = (undefined2)param_1;
    DAT_0f00c000 = DAT_0105f030;
    if (-1 < param_2) {
      _DAT_0f008002 = (undefined2)param_2;
    }
  }
  return;
}


// ==== FUN_01044b9a @ 01044b9a

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_01044b9a(uint param_1,undefined4 param_2,uint param_3,undefined1 param_4)

{
  byte bVar1;
  undefined4 in_D0;
  
  _DAT_0f008008 = _DAT_0f008008 | 0x2c;
  bVar1 = DAT_0f00800e | 3;
  DAT_0f00800e = bVar1;
  FUN_01044eb2(1);
  if ((bVar1 != 0) && ((param_1 & 1) == (param_3 & 1))) {
    FUN_01044cbe(&param_1,&param_2,&param_3,param_4);
    DAT_0f008000 = 0;
    FUN_01044afc(param_1,param_2);
    DAT_0f008000 = 1;
    FUN_01044afc(param_3);
    DAT_0f00800e = DAT_0f00800e & 0xfe;
    DAT_0f008000 = 0;
    _DAT_0f008008 = _DAT_0f008008 & 0xfb;
    DAT_0f00800f = DAT_0f00800f | 1;
    in_D0 = param_2;
  }
  return in_D0;
}


// ==== FUN_01044cbe @ 01044cbe

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_01044cbe(uint *param_1,uint *param_2,uint *param_3,undefined1 param_4)

{
  int iVar1;
  uint uVar2;
  
  if ((int)*param_2 < 0) {
    uVar2 = -*param_2;
  }
  else {
    uVar2 = *param_2;
  }
  if (*param_1 == 0) {
    _DAT_0105f032 = CONCAT11(param_4,param_4);
    *param_1 = (uint)&DAT_0105f032;
    _DAT_0f008008 = _DAT_0f008008 | 2;
  }
  else {
    _DAT_0f008008 = _DAT_0f008008 & 0xfffd;
  }
  if ((((*param_3 & 1) == 0) && ((*param_1 & 1) == 0)) && ((uVar2 & 1) == 0)) {
    *param_2 = (int)*param_2 >> 1;
    DAT_0f00800b = DAT_0f00800b | 1;
    iVar1 = 2;
  }
  else {
    DAT_0f00800b = DAT_0f00800b & 0xfe;
    iVar1 = 1;
  }
  if ((int)*param_2 < 0) {
    *param_2 = -*param_2;
    *param_1 = *param_1 - iVar1;
    *param_3 = *param_3 - iVar1;
    DAT_0f00800b = DAT_0f00800b | 0x20;
  }
  else {
    DAT_0f00800b = DAT_0f00800b & 0xdf;
  }
  DAT_0f008000 = 1;
  return;
}


// ==== FUN_01044eb2 @ 01044eb2

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_01044eb2(int param_1)

{
  if (param_1 == 1) {
    _DAT_0f008008 = _DAT_0f008008 & 0xff | 1;
  }
  else {
    _DAT_0f008008 = _DAT_0f008008 & 0xfc;
    DAT_0f00800b = DAT_0f00800b & 0xd2;
    if ((param_1 != 0) && ((param_1 == 4 || (param_1 == 8)))) {
      DAT_0f00800b = (byte)param_1 | DAT_0f00800b;
    }
  }
  return;
}


// ==== FUN_01044f80 @ 01044f80

void FUN_01044f80(undefined1 param_1)

{
  DAT_0f008000 = param_1;
  return;
}


// ==== FUN_01044fb4 @ 01044fb4

void FUN_01044fb4(void)

{
  byte bVar1;
  byte bVar2;
  ushort local_6;
  
  bVar2 = DAT_0f00800a;
  bVar1 = 0x11;
  for (local_6 = 0; local_6 < 4; local_6 = local_6 + 1) {
    if ((bVar1 & bVar2) != 0) {
      (*(code *)(&PTR_LAB_0105f020)[local_6])();
    }
    bVar1 = bVar1 << 1;
  }
  return;
}


// ==== FUN_010450a2 @ 010450a2

void FUN_010450a2(undefined1 *param_1,int param_2,undefined1 param_3)

{
  *(undefined1 *)(param_2 + 3) = 0x13;
  *param_1 = *(undefined1 *)(param_2 + 3);
  *(undefined1 *)(param_2 + 7) = param_3;
  param_1[1] = *(undefined1 *)(param_2 + 7);
  *(undefined1 *)(param_2 + 9) = 0xf;
  param_1[1] = *(undefined1 *)(param_2 + 9);
  *(undefined1 *)(param_2 + 4) = 0;
  *param_1 = *(undefined1 *)(param_2 + 4);
  *(undefined1 *)(param_2 + 5) = 0xb;
  *param_1 = *(undefined1 *)(param_2 + 5);
  *(undefined1 *)(param_2 + 10) = 0xff;
  param_1[1] = *(undefined1 *)(param_2 + 10);
  return;
}


// ==== FUN_0104514c @ 0104514c

void FUN_0104514c(undefined4 param_1,int param_2)

{
  undefined1 *puVar1;
  undefined *puVar2;
  
  if (param_2 >> 8 == 0) {
    puVar1 = (undefined1 *)0xf004000;
    puVar2 = &DAT_0105f034;
  }
  else {
    puVar1 = &DAT_0f003000;
    puVar2 = &DAT_0105f03f;
  }
  FUN_0105ef12(puVar2,puVar1);
  return;
}


// ==== FUN_010451ec @ 010451ec

void FUN_010451ec(int param_1,int param_2,byte param_3)

{
  *(byte *)(param_2 + 10) = ~param_3 & *(byte *)(param_2 + 10);
  *(undefined1 *)(param_1 + 1) = *(undefined1 *)(param_2 + 10);
  return;
}


// ==== FUN_01045214 @ 01045214

void FUN_01045214(int param_1,int param_2,byte param_3)

{
  *(byte *)(param_2 + 10) = param_3 | *(byte *)(param_2 + 10);
  *(undefined1 *)(param_1 + 1) = *(undefined1 *)(param_2 + 10);
  return;
}


// ==== FUN_01045246 @ 01045246

undefined2 FUN_01045246(int param_1)

{
  undefined2 uVar1;
  
  uVar1 = *(undefined2 *)(&DAT_0105f050 + param_1 * 2);
  FUN_01045402(1,2);
  DAT_0f001001 = DAT_0105f04c;
  FUN_01045324();
  DAT_0f001001 = DAT_0105f04c;
  FUN_01045324();
  DAT_0f001001 = DAT_0105f04c;
  FUN_01045324();
  DAT_0f001001 = DAT_0105f04d;
  FUN_01045324();
  DAT_0f001001 = DAT_0105f04f;
  FUN_01045324();
  DAT_0f001001 = DAT_0105f04e;
  return uVar1;
}


// ==== FUN_01045324 @ 01045324

void FUN_01045324(void)

{
  int local_8;
  
  for (local_8 = 0; local_8 < 100000; local_8 = local_8 + 1) {
  }
  return;
}


// ==== FUN_01045340 @ 01045340

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_01045340(void)

{
  _DAT_0105f064 = 0;
  DAT_0f00600e = 0;
  DAT_0f00600d = 8;
  DAT_0f00600f = 4;
  return;
}


// ==== FUN_01045384 @ 01045384

void FUN_01045384(void)

{
  return;
}


// ==== FUN_010453b2 @ 010453b2

void FUN_010453b2(void)

{
  DAT_0f003001 = DAT_0f003001 & 0xfe;
  return;
}


// ==== FUN_010453cc @ 010453cc

void FUN_010453cc(void)

{
  DAT_0f003001 = DAT_0f003001 | 1;
  return;
}


// ==== FUN_01045402 @ 01045402

void FUN_01045402(int param_1)

{
  undefined1 *puVar1;
  
  if (param_1 == 0) {
    puVar1 = &DAT_0f002000;
  }
  else {
    puVar1 = &DAT_0f005000;
  }
  FUN_0105ef12(puVar1);
  return;
}


// ==== FUN_01045476 @ 01045476

void FUN_01045476(byte param_1)

{
  DAT_0f00b003 = ~param_1;
  return;
}


// ==== FUN_01045496 @ 01045496

void FUN_01045496(undefined1 param_1,undefined1 param_2)

{
  DAT_0f00b006 = param_1;
  DAT_0f00b007 = param_2;
  return;
}


// ==== FUN_010454ae @ 010454ae

undefined8 FUN_010454ae(void)

{
  undefined4 in_D0;
  undefined4 in_D1;
  
  FUN_01044488();
  DAT_0f003000 = 0x20;
  return CONCAT44(in_D0,in_D1);
}


// ==== FUN_010455e6 @ 010455e6

undefined4 FUN_010455e6(int param_1,int param_2)

{
  int iVar1;
  undefined4 in_D0;
  int iVar2;
  int unaff_D4;
  short *psVar3;
  short *psVar4;
  int iVar5;
  
  iVar1 = (uint)(0 < param_1 % 0x400) + param_1 / 0x400;
  if ((0 < param_1) && (iVar1 <= DAT_0105f074)) {
    psVar3 = DAT_0105f068;
    for (iVar5 = 0; iVar5 + iVar1 < (int)DAT_0105f074; iVar5 = unaff_D4 + iVar2 + iVar5) {
      psVar4 = psVar3;
      for (iVar2 = 0; iVar2 < iVar1; iVar2 = iVar2 + 1) {
        unaff_D4 = (int)*psVar4;
        if (unaff_D4 != 0) break;
        psVar4 = psVar4 + 1;
      }
      if (iVar1 <= iVar2) {
        *psVar3 = (short)iVar1;
        while( true ) {
          psVar3 = psVar3 + 1;
          if (iVar2 + -1 == 0 || iVar2 < 1) break;
          *psVar3 = -0x8000;
          iVar2 = iVar2 + -1;
        }
        if (param_2 == 1) {
          FUN_01045e5a(iVar5 * 0x400 + DAT_0105f070,param_1);
          return 0;
        }
        return in_D0;
      }
      psVar3 = psVar4 + unaff_D4;
    }
  }
  return in_D0;
}


// ==== FUN_010456d4 @ 010456d4

undefined4 FUN_010456d4(undefined4 param_1)

{
  FUN_010455e6(param_1);
  return 0;
}


// ==== FUN_010456f4 @ 010456f4

void FUN_010456f4(undefined4 param_1)

{
  FUN_010455e6(param_1,1);
  return;
}


// ==== FUN_01045712 @ 01045712

void FUN_01045712(uint param_1)

{
  int iVar1;
  bool bVar2;
  undefined2 *puVar3;
  short *psVar4;
  int local_18;
  short local_14;
  short local_12;
  
  bVar2 = 0 < (int)(param_1 - DAT_0105f070) % 0x400;
  iVar1 = *(int *)((int)&DAT_0105f068 + ((int)(param_1 - DAT_0105f070) / 0x400) * 2);
  psVar4 = (short *)(iVar1 + 2);
  if ((DAT_0105f070 <= param_1) && (param_1 <= DAT_0105f06c)) {
    local_12 = 0;
    while (DAT_0105f068 < psVar4) {
      psVar4 = psVar4 + -1;
      local_14 = *psVar4;
      if (-1 < local_14) {
        local_12 = (ushort)bVar2 + local_12;
        break;
      }
      local_12 = local_12 + 1;
    }
    if (local_12 <= local_14) {
      puVar3 = (undefined2 *)((uint)bVar2 * 2 + iVar1);
      local_18 = (int)local_14 - (int)local_12;
      while (0 < local_18) {
        *puVar3 = 0;
        puVar3 = puVar3 + 1;
        local_18 = local_18 + -1;
      }
      *psVar4 = local_12;
    }
  }
  return;
}


// ==== FUN_010457da @ 010457da

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined1 * FUN_010457da(int param_1)

{
  int unaff_D7;
  int iVar1;
  bool bVar2;
  undefined1 *puVar3;
  
  FUN_01045a70(&DAT_010928df);
  bVar2 = unaff_D7 < 0;
  if (bVar2) {
    FUN_01045b86(&DAT_010928df);
  }
  puVar3 = &DAT_010928df;
  FUN_01045b26();
  if (bVar2) {
    puVar3 = &DAT_010928df;
    FUN_01045bb4();
  }
  FUN_01045e0a(*(undefined4 *)(param_1 + 4),&DAT_010928df,7);
  if (bVar2) {
    if (DAT_010928df < 0x51) {
      iVar1 = 2000;
    }
    else {
      iVar1 = 0x76c;
    }
    _DAT_01092c56 = (ushort)(((uint)DAT_010928df + iVar1) % 4) | 0x10;
  }
  return puVar3;
}


// ==== FUN_01045894 @ 01045894

/* WARNING: Removing unreachable block (ram,0x010458c2) */
/* WARNING: Removing unreachable block (ram,0x010458d6) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined1 * FUN_01045894(int param_1)

{
  int iVar1;
  undefined1 *puVar2;
  
  FUN_0105ef7c(&DAT_010928df,*(undefined4 *)(param_1 + 4));
  FUN_01045a70(&DAT_010928df);
  puVar2 = &DAT_010928df;
  FUN_01045b26();
  if (DAT_010928df < 0x51) {
    iVar1 = 2000;
  }
  else {
    iVar1 = 0x76c;
  }
  _DAT_01092c56 = (ushort)(((uint)DAT_010928df + iVar1) % 4) | 0x10;
  return puVar2;
}


// ==== FUN_01045924 @ 01045924

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_01045924(void)

{
  int unaff_D7;
  
  FUN_010459c8();
  FUN_01045a0e();
  if (unaff_D7 != 0) {
    FUN_01045b86(&DAT_010928df);
    FUN_01045bb4(&DAT_010928df);
    _DAT_01092c56 = (ushort)((DAT_010928df + 0x76c) % 4) | 0x10;
    FUN_010459c8();
  }
  return;
}


// ==== FUN_01045980 @ 01045980

void FUN_01045980(void)

{
  return;
}


// ==== FUN_010459a6 @ 010459a6

void FUN_010459a6(int param_1,byte param_2)

{
  (&DAT_0f006000)[param_1] = param_2 & 0xf;
  return;
}


// ==== FUN_010459c8 @ 010459c8

uint FUN_010459c8(void)

{
  uint in_D0;
  undefined1 *puVar1;
  uint local_e;
  byte local_5;
  
  puVar1 = &DAT_0106b07d;
  local_e = in_D0;
  for (local_5 = 0; local_5 < 6; local_5 = local_5 + 1) {
    local_e = (uint)(byte)puVar1[1];
    FUN_010459a6(*puVar1);
    puVar1 = puVar1 + 2;
  }
  return local_e;
}


// ==== FUN_01045a0e @ 01045a0e

int FUN_01045a0e(void)

{
  int in_D0;
  int iVar1;
  uint unaff_D7;
  uint uVar2;
  int *piVar3;
  int local_18;
  uint local_8;
  
  local_8 = 0;
  iVar1 = 0xc;
  piVar3 = &DAT_0106b08a;
  local_18 = in_D0;
  do {
    if (iVar1 < 0) {
      return local_18;
    }
    if (iVar1 != 6) {
      FUN_01045980();
      if ((int)unaff_D7 < *piVar3) {
LAB_01045a48:
        uVar2 = 1;
      }
      else {
        FUN_01045980();
        if (piVar3[1] < (int)unaff_D7) goto LAB_01045a48;
        uVar2 = 0;
      }
      local_8 = uVar2 | local_8;
      piVar3 = piVar3 + 2;
      local_18 = iVar1;
    }
    unaff_D7 = local_8 << 1;
    iVar1 = iVar1 + -1;
    local_8 = unaff_D7;
  } while( true );
}


// ==== FUN_01045a70 @ 01045a70

byte * FUN_01045a70(byte *param_1)

{
  byte *in_D0;
  byte *local_c;
  
  local_c = in_D0;
  if ((((0x4f < *param_1) && (*param_1 < 0x65)) && (param_1[1] != 0)) &&
     ((param_1[1] < 0xd && (param_1[2] != 0)))) {
    local_c = param_1;
    FUN_01045ac2();
  }
  return local_c;
}


// ==== FUN_01045ac2 @ 01045ac2

void FUN_01045ac2(void)

{
  return;
}


// ==== FUN_01045b26 @ 01045b26

void FUN_01045b26(void)

{
  return;
}


// ==== FUN_01045b86 @ 01045b86

void FUN_01045b86(undefined1 *param_1)

{
  *param_1 = DAT_0106b076;
  param_1[1] = DAT_0106b077;
  param_1[2] = DAT_0106b078;
  param_1[3] = DAT_0106b079;
  return;
}


// ==== FUN_01045bb4 @ 01045bb4

void FUN_01045bb4(int param_1)

{
  *(undefined1 *)(param_1 + 4) = DAT_0106b07a;
  *(undefined1 *)(param_1 + 5) = DAT_0106b07b;
  *(undefined1 *)(param_1 + 6) = DAT_0106b07c;
  return;
}


// ==== FUN_01045be0 @ 01045be0

void FUN_01045be0(undefined1 *param_1,ushort param_2,ushort param_3)

{
  undefined1 *puVar1;
  int local_c;
  ushort local_8;
  
  if (0x7ff < param_2) {
    param_2 = 0x800;
  }
  if ((int)(0x800 - (uint)param_2) <= (int)(uint)param_3) {
    param_3 = 0x800 - param_2;
  }
  puVar1 = (undefined1 *)(param_2 + 0xf00a000);
  DAT_0106b108 = param_3;
  for (local_8 = param_3; local_8 != 0; local_8 = local_8 - 1) {
    *param_1 = *puVar1;
    for (local_c = 0; local_c < 100; local_c = local_c + 1) {
    }
    puVar1 = puVar1 + 1;
    param_1 = param_1 + 1;
  }
  return;
}


// ==== FUN_01045c84 @ 01045c84

undefined2 FUN_01045c84(undefined2 param_1,undefined2 param_2,undefined4 param_3)

{
  FUN_01045cc0(param_3,param_1);
  DAT_0106b108 = param_1;
  FUN_01045d4e();
  return param_2;
}


// ==== FUN_01045cc0 @ 01045cc0

void FUN_01045cc0(undefined4 param_1,ushort param_2,ushort param_3)

{
  if (0x7ff < param_2) {
    param_2 = 0x800;
  }
  DAT_0106b105 = 0;
  if ((int)(0x800 - (uint)param_2) <= (int)(uint)param_3) {
    param_3 = 0x800 - param_2;
  }
  DAT_0106b106 = param_3;
  DAT_0106b100 = param_2 + 0xf00a000;
  DAT_0106b0fc = param_1;
  return;
}


// ==== FUN_01045d4e @ 01045d4e

void FUN_01045d4e(void)

{
  short local_6;
  
  local_6 = DAT_0106b106;
  if (DAT_0106b0f8 == 0x53) {
    if ((DAT_0106b105 < 2) || (*DAT_0106b100 == *DAT_0106b0fc)) {
      DAT_0106b100 = DAT_0106b100 + 1;
      DAT_0106b0fc = DAT_0106b0fc + 1;
      local_6 = DAT_0106b106 + -1;
      DAT_0106b105 = 0;
    }
    else {
      DAT_0106b105 = DAT_0106b105 + 1;
    }
  }
  for (; (*DAT_0106b100 == *DAT_0106b0fc && (local_6 != 0)); local_6 = local_6 + -1) {
    DAT_0106b100 = DAT_0106b100 + 1;
    DAT_0106b0fc = DAT_0106b0fc + 1;
  }
  DAT_0106b106 = local_6;
  if (local_6 != 0) {
    *DAT_0106b100 = *DAT_0106b0fc;
    FUN_010447a4(&DAT_01045df6,2);
  }
  return;
}


// ==== FUN_01045df8 @ 01045df8

void FUN_01045df8(void)

{
  return;
}


// ==== FUN_01045e0a @ 01045e0a

void FUN_01045e0a(undefined1 *param_1,undefined1 *param_2,int param_3)

{
  for (; param_3 != 0; param_3 = param_3 + -1) {
    *param_1 = *param_2;
    param_1 = param_1 + 1;
    param_2 = param_2 + 1;
  }
  return;
}


// ==== FUN_01045e26 @ 01045e26

void FUN_01045e26(void)

{
  return;
}


// ==== FUN_01045e5a @ 01045e5a

undefined1 FUN_01045e5a(uint *param_1,uint param_2,undefined1 param_3)

{
  uint uVar1;
  uint uVar2;
  
  uVar1 = (uint)param_1 & 1;
  FUN_01045e26();
  for (uVar2 = uVar1; (param_2 != 0 && (uVar2 != 0)); uVar2 = uVar2 - 1) {
    *(char *)param_1 = (char)uVar1;
    param_2 = param_2 - 1;
    param_1 = (uint *)((int)param_1 + 1);
  }
  uVar2 = param_2 & 3;
  param_2 = param_2 >> 2;
  while (param_2 != 0) {
    *param_1 = uVar1;
    param_1 = param_1 + 1;
    param_2 = param_2 - 1;
  }
  for (; uVar2 != 0; uVar2 = uVar2 - 1) {
    *(char *)param_1 = (char)uVar1;
    param_1 = (uint *)((int)param_1 + 1);
  }
  return param_3;
}


// ==== FUN_01045eca @ 01045eca

void FUN_01045eca(char *param_1,char *param_2,int param_3)

{
  if (param_3 == 0) {
    while( true ) {
      if (*param_1 == '\0') break;
      *param_2 = *param_1;
      param_1 = param_1 + 1;
      param_2 = param_2 + 1;
    }
  }
  else if (-1 < param_3) {
    do {
      *param_2 = *param_1;
      param_3 = param_3 + -1;
      param_1 = param_1 + 1;
      param_2 = param_2 + 1;
    } while (param_3 != 0);
  }
  return;
}


// ==== FUN_01045eea @ 01045eea

void FUN_01045eea(undefined1 param_1,undefined1 param_2,undefined1 param_3,undefined1 param_4,
                 undefined1 param_5,undefined1 param_6,undefined4 param_7,undefined4 param_8)

{
  DAT_01092c5e = param_1;
  DAT_01092c5f = param_2;
  DAT_01092c60 = param_3;
  DAT_01092c61 = param_4;
  DAT_01092c62 = param_5;
  DAT_01092c63 = param_6;
  DAT_01092c64 = param_7;
  DAT_01092c68 = param_8;
  return;
}


// ==== FUN_01045f38 @ 01045f38

void FUN_01045f38(void)

{
  return;
}


// ==== FUN_01045fc4 @ 01045fc4

void FUN_01045fc4(undefined1 param_1,undefined4 param_2)

{
  DAT_01092c5e = 0x10;
  DAT_01092c5f = param_1;
  FUN_01047354(&DAT_01092c5e,param_2);
  return;
}


// ==== FUN_01045ff8 @ 01045ff8

void FUN_01045ff8(undefined1 param_1,undefined4 param_2)

{
  DAT_01092c5e = 0x11;
  DAT_01092c5f = param_1;
  FUN_01047354(&DAT_01092c5e,param_2);
  return;
}


// ==== FUN_0104602c @ 0104602c

void FUN_0104602c(undefined1 param_1,undefined1 param_2,undefined4 param_3)

{
  DAT_01092c5e = 0x12;
  DAT_01092c5f = param_1;
  DAT_01092c60 = param_2;
  FUN_01047354(&DAT_01092c5e,param_3);
  return;
}


// ==== FUN_0104606c @ 0104606c

void FUN_0104606c(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5,undefined4 param_6)

{
  FUN_01045eea(0x20,param_1,param_2,param_3,param_4,param_5,param_6,0);
  FUN_01047354();
  return;
}


// ==== FUN_010460ae @ 010460ae

void FUN_010460ae(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5,undefined4 param_6)

{
  FUN_01045eea(0x21,param_1,param_2,param_3,param_4,param_5,param_6,0);
  FUN_01047354();
  return;
}


// ==== FUN_010460f0 @ 010460f0

void FUN_010460f0(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5,undefined4 param_6)

{
  FUN_01045eea(0x22,param_1,param_2,param_3,param_4,param_5,param_6,0);
  FUN_01047354();
  return;
}


// ==== FUN_01046132 @ 01046132

void FUN_01046132(undefined1 param_1,undefined4 param_2,undefined4 param_3)

{
  DAT_01092c5e = 0x30;
  DAT_01092c5f = param_1;
  DAT_01092c64 = param_2;
  FUN_01047354(&DAT_01092c5e,param_3);
  return;
}


// ==== FUN_01046170 @ 01046170

void FUN_01046170(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5)

{
  FUN_01045eea(0x32,param_1,param_2,param_3,0,0,param_4,param_5);
  FUN_01047354();
  return;
}


// ==== FUN_010461b0 @ 010461b0

void FUN_010461b0(undefined4 param_1)

{
  DAT_01092c5e = 0;
  FUN_01047354(&DAT_01092c5e,param_1);
  return;
}


// ==== FUN_010461d6 @ 010461d6

void FUN_010461d6(int param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,int param_5,
                 int param_6,undefined4 param_7,undefined4 param_8)

{
  undefined4 unaff_D7;
  
  if (param_1 < 4) {
    param_4 = 0x200;
    if (param_5 < 1) {
      param_5 = 9;
    }
    if (param_6 < 1) {
      param_6 = 0x50;
    }
  }
  DAT_01092c5e = 1;
  DAT_01092c5f = (undefined1)param_1;
  FUN_01045f38(param_2,param_3,param_4,param_5,param_6,param_7);
  DAT_01092c6c = CONCAT31((int3)((uint)unaff_D7 >> 8),(undefined1)param_1);
  FUN_01047354(&DAT_01092c5e,param_8);
  return;
}


// ==== FUN_0104625c @ 0104625c

void FUN_0104625c(undefined1 param_1,undefined4 param_2,undefined4 param_3)

{
  undefined4 unaff_D7;
  undefined4 local_c;
  undefined1 *local_8;
  
  local_8 = &DAT_01092c5e;
  DAT_01092c5e = 2;
  DAT_01092c5f = param_1;
  FUN_01047354(&DAT_01092c5e,param_3);
  local_c = CONCAT31((int3)((uint)unaff_D7 >> 8),param_1);
  FUN_01045eca(&local_c,param_2,4);
  return;
}


// ==== FUN_010462aa @ 010462aa

void FUN_010462aa(undefined1 param_1)

{
  undefined1 auStack_c [4];
  undefined1 *local_8;
  
  local_8 = &DAT_01092c5e;
  DAT_01092c5e = 3;
  DAT_01092c5f = param_1;
  FUN_01047354(&DAT_01092c5e,auStack_c);
  return;
}


// ==== FUN_010462de @ 010462de

void FUN_010462de(undefined1 param_1)

{
  undefined1 auStack_c [4];
  undefined1 *local_8;
  
  local_8 = &DAT_01092c5e;
  DAT_01092c5e = 4;
  DAT_01092c5f = param_1;
  FUN_01047354(&DAT_01092c5e,auStack_c);
  return;
}


// ==== FUN_01046312 @ 01046312

void FUN_01046312(undefined1 param_1)

{
  undefined1 auStack_c [4];
  undefined1 *local_8;
  
  local_8 = &DAT_01092c5e;
  DAT_01092c5e = 5;
  DAT_01092c5f = param_1;
  FUN_01047354(&DAT_01092c5e,auStack_c);
  return;
}


// ==== FUN_0104635c @ 0104635c

void FUN_0104635c(undefined1 param_1,undefined4 param_2,undefined4 param_3)

{
  DAT_01092c5e = 6;
  DAT_01092c5f = param_1;
  FUN_01045eca(param_2,&DAT_01092c70,3);
  FUN_01047354(&DAT_01092c5e,param_3);
  return;
}


// ==== FUN_010463aa @ 010463aa

void FUN_010463aa(undefined1 param_1,undefined4 param_2)

{
  DAT_01092c5e = 7;
  DAT_01092c5f = param_1;
  FUN_01047354(&DAT_01092c5e,param_2);
  return;
}


// ==== FUN_010463de @ 010463de

void FUN_010463de(undefined1 param_1,undefined4 param_2)

{
  DAT_01092c5e = 8;
  DAT_01092c5f = param_1;
  FUN_01047354(&DAT_01092c5e,param_2);
  return;
}


// ==== FUN_01046412 @ 01046412

void FUN_01046412(undefined1 param_1,undefined4 param_2)

{
  DAT_01092c5e = 9;
  DAT_01092c5f = param_1;
  FUN_01047354(&DAT_01092c5e,param_2);
  return;
}


// ==== FUN_01046446 @ 01046446

void FUN_01046446(undefined1 param_1,byte param_2,undefined4 param_3)

{
  DAT_01092c5e = 10;
  DAT_01092c5f = param_1;
  DAT_01092c68 = (uint)param_2;
  FUN_01047354(&DAT_01092c5e,param_3);
  return;
}


// ==== FUN_01046488 @ 01046488

void FUN_01046488(int param_1,undefined4 param_2)

{
  *(undefined4 *)(&DAT_01093166 + param_1 * 4) = param_2;
  FUN_01047210(param_1);
  FUN_010464b4();
  return;
}


// ==== FUN_010464b4 @ 010464b4

void FUN_010464b4(void)

{
  return;
}


// ==== FUN_010464c8 @ 010464c8

/* WARNING: Removing unreachable block (ram,0x01046550) */

void FUN_010464c8(int param_1,int param_2)

{
  bool bVar1;
  byte bVar2;
  
  if ((param_1 < 4) || (5 < param_1)) {
    bVar1 = false;
  }
  else {
    bVar1 = true;
  }
  if (param_2 == 0) {
    bVar2 = 0;
  }
  else {
    bVar2 = 4;
  }
  DAT_0109323e = !bVar1 | 8U | bVar2;
  DAT_0f007000 = DAT_0109323e;
  FUN_01046dcc(0x96);
  (&DAT_0109314f)[param_1 * 4] = DAT_0f007001;
  return;
}


// ==== FUN_01046582 @ 01046582

void FUN_01046582(undefined4 param_1)

{
  uint unaff_D7;
  
  FUN_010464c8(param_1,1);
  if (((unaff_D7 & 0x81) == 0) && ((unaff_D7 & 0x18) != 0)) {
    FUN_010465e6(param_1,0x14,0);
    FUN_010464c8(param_1,0);
  }
  return;
}


// ==== FUN_010465e6 @ 010465e6

/* WARNING: Removing unreachable block (ram,0x0104672a) */

void FUN_010465e6(int param_1,int param_2,int param_3)

{
  bool bVar1;
  byte bVar2;
  
  if ((param_1 < 4) || (5 < param_1)) {
    bVar1 = false;
  }
  else {
    bVar1 = true;
  }
  if (param_2 < (int)((*(uint *)(&DAT_01093166 + param_1 * 4) & 0xffff) >> 9)) {
    if (param_2 < 0x2c) {
      (&DAT_0109314e)[param_1 * 4] = (&DAT_0109314e)[param_1 * 4] & 0x7f;
    }
    else {
      (&DAT_0109314e)[param_1 * 4] = (&DAT_0109314e)[param_1 * 4] | 0x80;
    }
    if (param_2 < 0x3c) {
      (&DAT_0109314e)[param_1 * 4] = (&DAT_0109314e)[param_1 * 4] & 0xf7;
      DAT_0f00b001 = (&DAT_0109314e)[param_1 * 4];
    }
    else {
      (&DAT_0109314e)[param_1 * 4] = (&DAT_0109314e)[param_1 * 4] | 8;
      DAT_0f00b001 = (&DAT_0109314e)[param_1 * 4];
    }
    if (param_1 != DAT_0109314c) {
      DAT_0f007001 = (&DAT_0109314f)[param_1 * 4];
    }
    DAT_0f007003 = (undefined1)param_2;
    if (param_3 == 0) {
      bVar2 = 0xfb;
    }
    else {
      bVar2 = 0xff;
    }
    DAT_0109323e = (!bVar1 | 0x1cU) & bVar2;
    DAT_0f007000 = DAT_0109323e;
    FUN_01046dcc(0x96);
    if (param_3 == 0) {
      FUN_0104467e(0,2);
    }
    (&DAT_0109314f)[param_1 * 4] = DAT_0f007001;
    DAT_0109314c = (char)param_1;
  }
  return;
}


// ==== FUN_0104677a @ 0104677a

/* WARNING: Removing unreachable block (ram,0x010467fe) */

uint FUN_0104677a(uint param_1,undefined4 param_2)

{
  uint in_D0;
  uint uVar1;
  uint local_12;
  short local_6;
  
  local_6 = 0;
  uVar1 = param_1;
  local_12 = in_D0;
  while ((((local_6 < 3 && (FUN_010465e6(param_1,param_2,1), (uVar1 & 0x81) == 0)) &&
          ((uVar1 & 0x10000000) == 0)) && (uVar1 = uVar1 & 0x18, uVar1 != 0))) {
    if ((&DAT_01093151)[param_1 * 4] == '\0') {
      local_12 = param_1;
      FUN_01046582();
      uVar1 = 1;
      (&DAT_01093151)[param_1 * 4] = '\x01';
    }
    else {
      local_12 = 0;
      FUN_010464c8(param_1);
    }
    local_6 = local_6 + 1;
  }
  return local_12;
}


// ==== FUN_01046814 @ 01046814

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 *
FUN_01046814(int param_1,int param_2,undefined4 *param_3,undefined4 *param_4,undefined1 param_5,
            byte param_6,undefined4 param_7)

{
  uint uVar1;
  uint uVar2;
  byte bVar3;
  byte bVar4;
  undefined4 *local_22;
  
  if (param_1 == 0x20) {
    bVar3 = 0x82;
  }
  else if (param_1 == 0x21) {
    bVar3 = 0xa2;
  }
  else if (param_1 == 0x22) {
    bVar3 = 0xa3;
  }
  else {
    bVar3 = 0;
  }
  uVar1 = *(uint *)(&DAT_01093166 + param_2 * 4);
  uVar2 = *(uint *)(&DAT_01093166 + param_2 * 4);
  local_22 = param_3;
  FUN_0104677a(param_2);
  if ((((uVar1 & 0x1ff) >> 4) - ((int)(uVar2 << 0x1f) >> 0x1f) & 0x10000099) == 0) {
    local_22 = param_4;
    FUN_010471c6(param_2);
    if (param_4 == (undefined4 *)0x0) {
      bVar4 = 0;
    }
    else {
      bVar4 = 8;
    }
    DAT_01092c8a = 0;
    DAT_01092c8b = param_6;
    if ((bVar3 & 0xe0) == 0x80) {
      DAT_01092c8c = 4;
    }
    else {
      DAT_01092c8c = 8;
    }
    DAT_01092c8e = param_7;
    DAT_01092c78 = param_7;
    uVar1 = 0x80 << ((*(uint *)(&DAT_01093166 + param_2 * 4) & 0xf) >> 2);
    DAT_01092c92 = (undefined2)uVar1;
    DAT_01092c80 = uVar1 & 0xffff;
    DAT_01092c94 = param_5;
    _DAT_01092c86 = &DAT_0109317e + param_2 * 0x20;
    do {
      if (DAT_01092c8b <= DAT_01092c8a) {
        return local_22;
      }
      local_22 = &DAT_01092c78;
      FUN_010469ac(bVar4 | bVar3,param_2,param_3);
    } while (bVar4 == 0 && (bVar3 & 0x99) == 0);
  }
  return local_22;
}


// ==== FUN_010469ac @ 010469ac

undefined4 *
FUN_010469ac(undefined1 param_1,undefined4 param_2,undefined4 *param_3,undefined4 *param_4)

{
  undefined4 *in_D0;
  uint unaff_D7;
  undefined4 *local_16;
  short local_6;
  
  local_6 = 0;
  local_16 = in_D0;
  while( true ) {
    if (2 < local_6) {
      return local_16;
    }
    FUN_01046a24(param_1);
    if ((unaff_D7 & 0x81) != 0) break;
    if ((unaff_D7 & 0x7e) == 0) {
      return param_4;
    }
    local_16 = param_3;
    FUN_0104677a(param_2);
    unaff_D7 = 0;
    *param_4 = DAT_01092c8e;
    local_6 = local_6 + 1;
  }
  return param_4;
}


// ==== FUN_01046a24 @ 01046a24

int FUN_01046a24(undefined1 param_1,undefined4 param_2)

{
  int iVar1;
  
  FUN_01044940(3,DAT_01092c8c,param_2);
  DAT_0f007002 = **(undefined1 **)(&DAT_01092c86 + DAT_01092c94);
  DAT_0109323e = param_1;
  DAT_0f007000 = param_1;
  iVar1 = (uint)DAT_01092c8b * 0x78;
  FUN_01046dcc();
  return iVar1;
}


// ==== FUN_01046aa8 @ 01046aa8

uint FUN_01046aa8(void)

{
  byte bVar1;
  uint in_D0;
  int iVar2;
  uint local_e;
  
  bVar1 = DAT_0109323e;
  if ((((DAT_0109323e & 0xc0) == 0x80) && (DAT_0f007000 == 0)) &&
     (DAT_01092c8a = DAT_01092c8a + 1, DAT_01092c8a < DAT_01092c8b)) {
    DAT_01092c94 = DAT_01092c94 + 1;
    DAT_0f007002 = **(undefined1 **)(&DAT_01092c86 + DAT_01092c94);
    DAT_01092c8e = (uint)DAT_01092c92 + DAT_01092c8e;
    local_e = (uint)DAT_01092c92;
    FUN_01044a2c(3,DAT_01092c8c,DAT_01092c8e);
    DAT_0f007000 = bVar1;
    DAT_0109323e = bVar1;
  }
  else {
    if ((DAT_0f007000 & 0x81) != 0) {
      iVar2 = 0;
      while ((iVar2 < 0x10000 && ((DAT_0f007000 & 0x81) != 0))) {
        iVar2 = iVar2 + 1;
      }
    }
    local_e = in_D0;
    if (((DAT_0f007000 & 0x81) == 0) && ((DAT_0109323e & 0xc0) == 0x80)) {
      DAT_01092c8a = DAT_01092c8a + 1;
      if (DAT_01092c8a < DAT_01092c8b) {
        DAT_01092c94 = DAT_01092c94 + 1;
        DAT_0f007002 = **(undefined1 **)(&DAT_01092c86 + DAT_01092c94);
        DAT_01092c8e = (uint)DAT_01092c92 + DAT_01092c8e;
        local_e = (uint)DAT_01092c92;
        FUN_01044a2c(3,DAT_01092c8c,DAT_01092c8e);
        DAT_0f007000 = bVar1;
        DAT_0109323e = bVar1;
      }
      else {
        FUN_010446e6(3,0x40);
      }
    }
    else {
      FUN_010446e6(3,0x40);
    }
  }
  return local_e;
}


// ==== FUN_01046c56 @ 01046c56

undefined4 * FUN_01046c56(undefined4 param_1,undefined4 param_2)

{
  DAT_01092c78 = param_2;
  DAT_01092c80 = 6;
  FUN_01044940(3,4);
  DAT_0109323e = 0xc0;
  DAT_0f007000 = 0xc0;
  FUN_01046dcc(0x78);
  return &DAT_01092c78;
}


// ==== FUN_01046cc8 @ 01046cc8

undefined4
FUN_01046cc8(int param_1,int param_2,undefined4 param_3,undefined4 param_4,ushort param_5)

{
  uint uVar1;
  undefined4 in_D0;
  
  uVar1 = (*(uint *)(&DAT_01093166 + param_1 * 4) & 0xffff) >> 9;
  if (param_2 < (int)uVar1) {
    in_D0 = 0;
    FUN_010465e6(param_1,param_2);
    if ((uVar1 & 0x10000099) == 0) {
      DAT_01092c78 = param_4;
      DAT_01092c80 = (uint)param_5;
      FUN_01044940(3,8,&DAT_01092c78);
      FUN_010471c6(param_1);
      DAT_0109323e = 0xf4;
      DAT_0f007000 = 0xf4;
      FUN_01046dcc(0x78);
      in_D0 = param_3;
    }
  }
  return in_D0;
}


// ==== FUN_01046d8c @ 01046d8c

void FUN_01046d8c(void)

{
  return;
}


// ==== FUN_01046daa @ 01046daa

void FUN_01046daa(void)

{
  return;
}


// ==== FUN_01046dcc @ 01046dcc

/* WARNING: Removing unreachable block (ram,0x01046e04) */

void FUN_01046dcc(undefined4 param_1)

{
  undefined4 uVar1;
  
  uVar1 = 0;
  FUN_0104514c(2,4);
  do {
    FUN_0104467e(0,param_1,uVar1);
    uVar1 = 0;
  } while( true );
}


// ==== FUN_01046e0c @ 01046e0c

/* WARNING: Removing unreachable block (ram,0x01046e46) */

void FUN_01046e0c(undefined4 param_1)

{
  undefined4 uVar1;
  
  uVar1 = 0;
  FUN_010447a4(&LAB_01046e5a,2);
  do {
    FUN_0104467e(0,param_1,uVar1);
    uVar1 = 0;
  } while( true );
}


// ==== FUN_01046e8a @ 01046e8a

void FUN_01046e8a(undefined4 param_1)

{
  int unaff_D7;
  byte bVar1;
  
  FUN_01046daa(param_1);
  if (unaff_D7 == 1) {
    bVar1 = 0x10;
  }
  else {
    bVar1 = 0;
  }
  DAT_0f00b000 = (byte)param_1 | bVar1 | 0x80;
  FUN_010465e6(param_1,DAT_0f007001,0);
  return;
}


// ==== FUN_01046ee4 @ 01046ee4

undefined4 FUN_01046ee4(int param_1)

{
  byte bVar1;
  undefined *puVar2;
  undefined4 uVar3;
  undefined2 local_a;
  
  FUN_01046daa(param_1);
  if (param_1 * 0x20 == 1) {
    bVar1 = 0x10;
  }
  else {
    bVar1 = 0;
  }
  DAT_0f00b000 = (byte)param_1 | bVar1 | 0x80;
  (&DAT_0109314e)[param_1 * 4] = 0;
  DAT_0f00b001 = (&DAT_0109314e)[param_1 * 4];
  uVar3 = DAT_01092c96;
  FUN_01046488(param_1);
  puVar2 = &DAT_0109317e + param_1 * 0x20;
  for (local_a = 0; local_a < 0x20; local_a = local_a + 1) {
    *puVar2 = (undefined1)local_a;
    puVar2 = puVar2 + 1;
  }
  return uVar3;
}


// ==== FUN_01046f76 @ 01046f76

uint FUN_01046f76(uint param_1)

{
  uint uVar1;
  byte bVar2;
  byte local_5;
  
  (&DAT_0109314e)[param_1 * 4] = (&DAT_0109314e)[param_1 * 4] | 0x20;
  local_5 = (&DAT_0109314e)[param_1 * 4];
  FUN_01046daa(param_1);
  if (param_1 == 1) {
    uVar1 = 0x10;
  }
  else {
    uVar1 = 0;
  }
  uVar1 = param_1 | uVar1 | 0x80;
  bVar2 = (byte)uVar1;
  DAT_0f00b000 = bVar2;
  FUN_01046d8c(param_1);
  if (uVar1 == 0) {
    local_5 = local_5 | 3;
  }
  else {
    FUN_010472be();
    local_5 = bVar2 | local_5 & 0xfd;
  }
  DAT_0f00b001 = local_5 | 4;
  (&DAT_0109314e)[param_1 * 4] = DAT_0f00b001;
  FUN_01046d8c(param_1);
  if (param_1 == 0) {
    uVar1 = 200;
  }
  else {
    uVar1 = 100;
  }
  FUN_01046e0c();
  if ((DAT_0f007000 & 0x80) != 0) {
    FUN_01047054();
    uVar1 = param_1;
  }
  return uVar1;
}


// ==== FUN_01047054 @ 01047054

int FUN_01047054(int param_1)

{
  byte bVar1;
  byte bVar2;
  int iVar3;
  
  bVar2 = (&DAT_0109314e)[param_1 * 4];
  FUN_01046daa(param_1);
  if (param_1 == 1) {
    bVar1 = 0x10;
  }
  else {
    bVar1 = 0;
  }
  DAT_0f00b000 = (byte)param_1 | bVar1 | 0x80;
  (&DAT_0109314e)[param_1 * 4] = bVar2 & 0xdb;
  DAT_0f00b001 = (&DAT_0109314e)[param_1 * 4];
  iVar3 = param_1;
  FUN_01046daa();
  if (param_1 != 0) {
    iVar3 = 0;
    FUN_01046daa();
    if (param_1 == 1) {
      bVar2 = 0x10;
    }
    else {
      bVar2 = 0;
    }
    DAT_0f00b000 = bVar2 | 0x80;
  }
  return iVar3;
}


// ==== FUN_010470ea @ 010470ea

void FUN_010470ea(int param_1,byte param_2,char param_3,char param_4)

{
  uint uVar1;
  byte bVar2;
  bool bVar3;
  byte *pbVar4;
  byte local_9;
  byte local_8;
  byte local_5;
  
  uVar1 = *(uint *)(&DAT_01093166 + param_1 * 4);
  bVar2 = (byte)((*(uint *)(&DAT_01093166 + param_1 * 4) & 0x1ff) >> 4);
  local_8 = param_2;
  local_9 = param_2;
  bVar3 = true;
  pbVar4 = &DAT_0109317e + param_1 * 0x20;
  for (local_5 = (byte)uVar1 & 1; local_5 < (byte)(bVar2 + ((uVar1 & 1) == 0));
      local_5 = local_5 + 1) {
    if (bVar2 < local_9) {
      local_9 = local_9 % bVar2;
    }
    if (bVar3) {
      bVar3 = !bVar3;
    }
    else if (local_9 == local_8) {
      local_9 = param_4 + local_9;
      local_8 = local_9;
    }
    *pbVar4 = local_9;
    local_9 = param_3 + local_9;
    pbVar4 = pbVar4 + 1;
  }
  return;
}


// ==== FUN_010471c6 @ 010471c6

void FUN_010471c6(int param_1,int param_2)

{
  byte bVar1;
  
  if (param_2 == 0) {
    bVar1 = (&DAT_0109314e)[param_1 * 4] & 0xbf;
  }
  else {
    bVar1 = (&DAT_0109314e)[param_1 * 4] | 0x40;
  }
  (&DAT_0109314e)[param_1 * 4] = bVar1;
  DAT_0f00b001 = (&DAT_0109314e)[param_1 * 4];
  return;
}


// ==== FUN_01047210 @ 01047210

void FUN_01047210(int param_1)

{
  byte *pbVar1;
  
  pbVar1 = &DAT_0109314e + param_1 * 4;
  if (*(int *)(&DAT_01093166 + param_1 * 4) << 0x1e < 0) {
    *pbVar1 = *pbVar1 & 0xfe;
  }
  else {
    *pbVar1 = *pbVar1 | 1;
  }
  return;
}


// ==== FUN_01047266 @ 01047266

void FUN_01047266(undefined4 param_1,byte param_2)

{
  FUN_01045df8(0xf00a7ff);
  DAT_01092c9a = param_2 & 1;
  FUN_01045c84();
  return;
}


// ==== FUN_010472be @ 010472be

void FUN_010472be(void)

{
  return;
}


// ==== FUN_010472ca @ 010472ca

/* WARNING: Removing unreachable block (ram,0x0104732e) */

int FUN_010472ca(void)

{
  int in_D0;
  int iVar1;
  byte unaff_D7b;
  
  for (iVar1 = 0; iVar1 < 6; iVar1 = iVar1 + 1) {
    FUN_01046ee4(iVar1);
    (&DAT_0109314f)[iVar1 * 4] = 0;
    FUN_01047d9c(iVar1);
    in_D0 = iVar1;
    FUN_01046f76();
    unaff_D7b = unaff_D7b & 0x81;
    if (unaff_D7b == 0) {
      FUN_01046582(iVar1);
      unaff_D7b = 1;
      (&DAT_01093151)[iVar1 * 4] = 1;
      in_D0 = iVar1;
      FUN_01047054();
    }
    else {
      (&DAT_01093151)[iVar1 * 4] = 0;
    }
  }
  FUN_0104748a();
  return in_D0;
}


// ==== FUN_01047354 @ 01047354

byte * FUN_01047354(byte *param_1,undefined4 *param_2)

{
  uint uVar1;
  int unaff_D7;
  byte bVar3;
  uint uVar2;
  byte *pbVar4;
  undefined1 auStack_8 [4];
  
  *(undefined1 **)(param_1 + 0x16) = auStack_8;
  uVar1 = (uint)param_1[1];
  FUN_01046daa(uVar1);
  uVar2 = 0;
  if ((unaff_D7 == 0) || (uVar2 = *param_1 & 0xf0, (*param_1 & 0xf0) != 0)) {
    FUN_01046daa(param_1[1]);
    if (uVar2 == 1) {
      bVar3 = 0x10;
    }
    else {
      bVar3 = 0;
    }
    uVar1 = (uint)param_1[1];
    DAT_0f00b000 = param_1[1] | bVar3 | 0x80;
    uVar2 = *param_1 & 0xf0;
    if (((*param_1 & 0xf0) != 0) && (((&DAT_0109314e)[uVar1 * 4] & 4) != 0)) {
      FUN_01046daa(uVar1);
      if (uVar2 == 1) {
        bVar3 = 0x20;
      }
      else {
        bVar3 = 0;
      }
      DAT_01093241 = bVar3 | 0x40;
      DAT_0109323e = 0xfe;
      DAT_0f007000 = 0xfe;
      DAT_0f007003 = DAT_01093241;
      (&DAT_0109314e)[uVar1 * 4] = (&DAT_0109314e)[uVar1 * 4] | 0x20;
      DAT_0f00b001 = (&DAT_0109314e)[uVar1 * 4];
      uVar2 = (uint)DAT_0f00b001;
      FUN_01046e0c(0x1e);
    }
  }
  pbVar4 = param_1;
  FUN_0104755e();
  **(uint **)(param_1 + 0x16) = uVar2;
  (&DAT_0109314e)[uVar1 * 4] = (&DAT_0109314e)[uVar1 * 4] & 0xdf;
  DAT_0f00b001 = (&DAT_0109314e)[uVar1 * 4];
  *param_2 = 0x40;
  return pbVar4;
}


// ==== FUN_0104748a @ 0104748a

/* WARNING: Removing unreachable block (ram,0x010474ac) */

void FUN_0104748a(void)

{
  DAT_0109314c = 0;
  FUN_01046daa(0);
  DAT_0f00b000 = DAT_0109314c | 0x80;
  return;
}


// ==== FUN_0104755e @ 0104755e

void FUN_0104755e(void)

{
  FUN_0105ef12();
  return;
}


// ==== FUN_010479ca @ 010479ca

void FUN_010479ca(void)

{
  return;
}


// ==== FUN_010479f0 @ 010479f0

void FUN_010479f0(byte *param_1,int param_2,uint param_3)

{
  *param_1 = ~(byte)(3 << (param_2 << 1 & 0x3fU)) & *param_1;
  *param_1 = (byte)((param_3 & 3) << (param_2 << 1 & 0x3fU)) | *param_1;
  return;
}


// ==== FUN_01047a20 @ 01047a20

void FUN_01047a20(void)

{
  FUN_01045e5a(&DAT_01093242,0x10,0);
  return;
}


// ==== FUN_01047a3c @ 01047a3c

undefined4 FUN_01047a3c(undefined4 param_1,undefined4 param_2)

{
  undefined4 in_D0;
  uint uVar1;
  undefined *puVar2;
  undefined4 local_14;
  
  puVar2 = &DAT_01093242;
  local_14 = in_D0;
  for (uVar1 = 0; uVar1 < 8; uVar1 = uVar1 + 1) {
    if (puVar2[1] != '\0') {
      local_14 = param_2;
      FUN_01047b70(puVar2,param_1);
    }
    puVar2 = puVar2 + 2;
  }
  return local_14;
}


// ==== FUN_01047a7c @ 01047a7c

void FUN_01047a7c(undefined *param_1,uint param_2)

{
  int iVar1;
  
  iVar1 = 8;
  while ((iVar1 != 0 && ((byte)param_1[1] != param_2))) {
    param_1 = param_1 + 2;
    if ((undefined *)0x1093251 < param_1) {
      param_1 = &DAT_01093242;
    }
    iVar1 = iVar1 + -1;
  }
  return;
}


// ==== FUN_01047ac8 @ 01047ac8

uint FUN_01047ac8(uint param_1)

{
  uint in_D0;
  uint local_c;
  
  local_c = in_D0;
  if (param_1 != 0) {
    local_c = param_1;
    FUN_01047a7c(&DAT_01093242 + (param_1 & 7) * 2);
  }
  return local_c;
}


// ==== FUN_01047afe @ 01047afe

undefined4 FUN_01047afe(uint param_1)

{
  undefined1 *puVar1;
  
  puVar1 = (undefined1 *)((param_1 & 7) * 2);
  FUN_01047a7c(puVar1 + 0x1093242);
  if ((param_1 & 7) != 0) {
    puVar1[1] = (undefined1)param_1;
    *puVar1 = 0;
  }
  return 0;
}


// ==== FUN_01047b3a @ 01047b3a

undefined4 FUN_01047b3a(undefined4 param_1,undefined4 param_2)

{
  FUN_010479ca(param_1);
  return param_2;
}


// ==== FUN_01047b70 @ 01047b70

uint FUN_01047b70(undefined4 param_1,undefined4 param_2,uint param_3)

{
  uint unaff_D7;
  uint uVar1;
  
  FUN_010479ca(param_1,param_2);
  uVar1 = param_3 & 3 | unaff_D7;
  FUN_010479f0(param_1,param_2);
  return uVar1;
}


// ==== FUN_01047bae @ 01047bae

void FUN_01047bae(int param_1,undefined4 param_2)

{
  if (param_1 != 0) {
    FUN_010479f0(param_1,param_2,0);
  }
  return;
}


// ==== FUN_01047bcc @ 01047bcc

/* WARNING: Removing unreachable block (ram,0x01047c2c) */
/* WARNING: Removing unreachable block (ram,0x01047c0a) */

undefined4 FUN_01047bcc(undefined4 param_1)

{
  FUN_01047ac8(param_1);
  FUN_01047afe();
  return param_1;
}


// ==== FUN_01047c68 @ 01047c68

/* WARNING: Removing unreachable block (ram,0x01047cc2) */
/* WARNING: Removing unreachable block (ram,0x01047ce4) */
/* WARNING: Removing unreachable block (ram,0x01047ce8) */
/* WARNING: Removing unreachable block (ram,0x01047ca6) */

undefined4 FUN_01047c68(undefined4 param_1)

{
  FUN_01047ac8(param_1);
  FUN_01047afe();
  return param_1;
}


// ==== FUN_01047d16 @ 01047d16

/* WARNING: Removing unreachable block (ram,0x01047d4a) */

int FUN_01047d16(char param_1)

{
  int local_c;
  
  FUN_01046daa();
  if (param_1 == '\0') {
    FUN_01046daa();
    DAT_0f00b000 = 0x80;
  }
  local_c = (int)param_1;
  return local_c;
}


// ==== FUN_01047d9c @ 01047d9c

/* WARNING: Removing unreachable block (ram,0x01047dd2) */

int FUN_01047d9c(char param_1)

{
  int local_c;
  
  FUN_01046daa();
  if (param_1 == '\0') {
    FUN_01046daa();
    DAT_0f00b000 = 0x80;
    DAT_0f00b001 = DAT_0109314e & 0xef;
    DAT_01093150 = (~DAT_0f00b004 & 2) != 0;
    DAT_0109314e = DAT_0f00b001;
  }
  local_c = (int)param_1;
  return local_c;
}


// ==== FUN_01047ff6 @ 01047ff6

void FUN_01047ff6(void)

{
  byte local_5;
  
  FUN_0105e8ea();
  FUN_01051742(1);
  DAT_0103dacb = false;
  if ((DAT_0103fa04 == '\0') || (DAT_0103fa04 == '\x01')) {
    DAT_0103dacb = DAT_0103fa0a == '\x01';
    if ((DAT_0103fa0a == '\x02') && (DAT_0103fa03 == 'A')) {
      DAT_0103dacb = true;
    }
    if ((DAT_0103fa0a == '\x03') && (DAT_0103fa02 == '\x01')) {
      DAT_0103dacb = true;
    }
  }
  else if (DAT_0103fa04 == '\x10') {
    for (local_5 = 0; local_5 < DAT_0103f9b3; local_5 = local_5 + 1) {
      if ((&DAT_0103f9a4)[(char)local_5] == '\x01') {
        DAT_0103dacb = DAT_0103fa0a == '\x01';
        if ((DAT_0103fa0a == '\x02') && (DAT_0103fa03 == 'A')) {
          DAT_0103dacb = true;
        }
        if ((DAT_0103fa0a == '\x03') && (DAT_0103fa02 == '\x01')) {
          DAT_0103dacb = true;
        }
        break;
      }
    }
  }
  if (DAT_0103f97c == 0xf) {
    DAT_0103dacb = 0;
    DAT_0103f1c7 = 0;
    DAT_0103f1c6 = 0;
    FUN_01051e52(1);
    FUN_01058fd8(1);
    FUN_010521f4(1);
  }
  else {
    FUN_0104814a();
    DAT_0103f1c6 = 1;
  }
  return;
}


// ==== FUN_0104814a @ 0104814a

void FUN_0104814a(void)

{
  if (DAT_0103fa04 == '\0') {
    if (DAT_0103fa05 == '\x01') {
      DAT_0103f1c7 = 1;
    }
    else if (DAT_0103fa05 == '\x02') {
      DAT_0103f1c7 = 2;
    }
    else {
      DAT_0103f1c7 = 3;
    }
  }
  else if (DAT_0103fa04 == '\x10') {
    if (DAT_0103fa05 == '\x01') {
      DAT_0103f1c7 = 4;
    }
    else if (DAT_0103fa05 == '\x02') {
      DAT_0103f1c7 = 5;
    }
    else {
      DAT_0103f1c7 = 6;
    }
  }
  else if (DAT_0103fa05 == '\x01') {
    DAT_0103f1c7 = 7;
  }
  else if (DAT_0103fa05 == '\x02') {
    DAT_0103f1c7 = 8;
  }
  else {
    DAT_0103f1c7 = 9;
  }
  return;
}


// ==== FUN_010481f4 @ 010481f4

void FUN_010481f4(void)

{
  short unaff_D7w;
  
  FUN_01058496(1);
  do {
    FUN_0103fffc();
  } while (unaff_D7w == -1);
  FUN_01058496(0);
  if (unaff_D7w == 10) {
    return;
  }
  return;
}


// ==== FUN_01048236 @ 01048236

void FUN_01048236(undefined4 param_1)

{
  short local_8;
  short local_6;
  
  local_8 = 0;
  local_6 = 0;
  while ((local_6 < 0x50 && (**(char **)((int)&param_1 + (int)local_6) != '\0'))) {
    *(undefined1 *)(*(int *)(&DAT_0103db3c + DAT_0103db3a * 0x54) + (int)local_8) =
         **(undefined1 **)((int)&param_1 + (int)local_6);
    local_6 = local_6 + 1;
    local_8 = local_8 + 1;
  }
  *(undefined1 *)(*(int *)(&DAT_0103db3c + DAT_0103db3a * 0x54) + (int)local_8) = 0;
  DAT_0103db3a = DAT_0103db3a + 1;
  if (4999 < DAT_0103db3a) {
    DAT_0103db3a = 0;
  }
  if (DAT_0103db38 < 5000) {
    DAT_0103db38 = DAT_0103db38 + 1;
  }
  return;
}


// ==== FUN_010482ca @ 010482ca

void FUN_010482ca(void)

{
  int unaff_D7;
  
  FUN_0105854a(1);
  FUN_01055784(1);
  FUN_01055a46(1);
  FUN_01055ad2(1);
  if (DAT_0103fa0a == '\x03') {
    FUN_010559ac(1);
  }
  FUN_0104a512();
  if ((unaff_D7 != 3) && ((DAT_0103fa0a != '\x03' || (FUN_0104a110(), unaff_D7 != 0)))) {
    FUN_01055a46(0);
    FUN_01055ad2(0);
    FUN_010559ac(0);
    FUN_01055784(0);
    FUN_01055bac(1);
    FUN_01055e6e(1);
    FUN_01055efa(1);
    if (DAT_0103fa0a == '\x03') {
      FUN_01055dd4(1);
    }
    FUN_0104b7f6();
    if (unaff_D7 != 3) {
      FUN_01055e6e(0);
      FUN_01055efa(0);
      FUN_01055dd4(0);
      FUN_01055bac(0);
      FUN_01055fd6(1);
      FUN_01056298(1);
      FUN_01056324(1);
      if (DAT_0103fa0a == '\x03') {
        FUN_010561fe(1);
      }
      FUN_0104c600();
      if (unaff_D7 != 3) {
        FUN_01056298(0);
        FUN_01056324(0);
        FUN_010561fe(0);
        FUN_01055fd6(0);
        FUN_01056400(1);
        FUN_0105669a(1);
        FUN_01056726(1);
        if (DAT_0103fa0a == '\x03') {
          FUN_01056600(1);
        }
        FUN_01050e6e();
        if (unaff_D7 != 3) {
          FUN_0105669a(0);
          FUN_01056726(0);
          FUN_01056600(0);
          FUN_01056400(0);
          FUN_01056802(1);
          FUN_01056a9c(1);
          FUN_01056b28(1);
          if (DAT_0103fa0a == '\x03') {
            FUN_01056a02(1);
          }
          FUN_01051138();
        }
      }
    }
  }
  FUN_0105854a(0);
  FUN_01051e52(1);
  FUN_01058fd8(1);
  DAT_0103f1c7 = 0;
  return;
}


// ==== FUN_0104851a @ 0104851a

void FUN_0104851a(void)

{
  bool bVar1;
  int unaff_D7;
  
  bVar1 = true;
  FUN_0105854a(1);
  while( true ) {
    FUN_01055784(1);
    FUN_01055a46(1);
    FUN_01055ad2(1);
    if (DAT_0103fa0a == '\x03') {
      FUN_010559ac(1);
    }
    FUN_0104a512();
    if ((unaff_D7 == 3) || (unaff_D7 == 2)) break;
    if ((DAT_0103fa0a == '\x03') && (bVar1)) {
      bVar1 = false;
      FUN_0104a110();
      if (unaff_D7 == 0) break;
    }
    FUN_01055a46(0);
    FUN_01055ad2(0);
    FUN_010559ac(0);
    FUN_01055784(0);
    FUN_01055bac(1);
    FUN_01055e6e(1);
    FUN_01055efa(1);
    if (DAT_0103fa0a == '\x03') {
      FUN_01055dd4(1);
    }
    FUN_0104b7f6();
    if ((unaff_D7 == 3) || (unaff_D7 == 2)) break;
    FUN_01055e6e(0);
    FUN_01055efa(0);
    FUN_01055dd4(0);
    FUN_01055bac(0);
    FUN_01055fd6(1);
    FUN_01056298(1);
    FUN_01056324(1);
    if (DAT_0103fa0a == '\x03') {
      FUN_010561fe(1);
    }
    FUN_0104c600();
    if ((unaff_D7 == 3) || (unaff_D7 == 2)) break;
    FUN_01056298(0);
    FUN_01056324(0);
    FUN_010561fe(0);
    FUN_01055fd6(0);
    FUN_01056400(1);
    FUN_0105669a(1);
    FUN_01056726(1);
    if (DAT_0103fa0a == '\x03') {
      FUN_01056600(1);
    }
    FUN_01050e6e();
    if ((unaff_D7 == 3) || (unaff_D7 == 2)) break;
    FUN_0105669a(0);
    FUN_01056726(0);
    FUN_01056600(0);
    FUN_01056400(0);
    FUN_01056802(1);
    FUN_01056a9c(1);
    FUN_01056b28(1);
    if (DAT_0103fa0a == '\x03') {
      FUN_01056a02(1);
    }
    FUN_01051138();
    if ((unaff_D7 == 3) || (unaff_D7 == 2)) break;
    FUN_01056a9c(0);
    FUN_01056b28(0);
    FUN_01056a02(0);
    FUN_01056802(0);
  }
  FUN_0105854a(0);
  FUN_01051e52(1);
  FUN_01058fd8(1);
  DAT_0103f1c7 = 0;
  return;
}


// ==== FUN_010487ea @ 010487ea

undefined4 FUN_010487ea(void)

{
  bool bVar1;
  int iVar2;
  uint uVar3;
  undefined4 uVar4;
  
  bVar1 = true;
  DAT_0103fa08 = 0;
  FUN_0105854a(1);
  for (iVar2 = 0; uVar3 = (uint)DAT_0103fa06, iVar2 < (int)uVar3; iVar2 = iVar2 + 1) {
    DAT_0103fa08 = DAT_0103fa08 + 1;
    FUN_0105854a(1);
    FUN_01055784(1);
    FUN_01055a46(1);
    FUN_01055ad2(1);
    if (DAT_0103fa0a == '\x03') {
      FUN_010559ac(1);
    }
    FUN_0104a512();
    if (uVar3 == 3) break;
    if ((DAT_0103fa0a == '\x03') && (bVar1)) {
      bVar1 = false;
      FUN_0104a110();
      if (uVar3 == 0) break;
    }
    FUN_01055a46(0);
    FUN_01055ad2(0);
    FUN_010559ac(0);
    FUN_01055784(0);
    FUN_01055bac(1);
    FUN_01055e6e(1);
    FUN_01055efa(1);
    if (DAT_0103fa0a == '\x03') {
      FUN_01055dd4(1);
    }
    FUN_0104b7f6();
    if (uVar3 == 3) break;
    FUN_01055e6e(0);
    FUN_01055efa(0);
    FUN_01055dd4(0);
    FUN_01055bac(0);
    FUN_01055fd6(1);
    FUN_01056298(1);
    FUN_01056324(1);
    if (DAT_0103fa0a == '\x03') {
      FUN_010561fe(1);
    }
    FUN_0104c600();
    if (uVar3 == 3) break;
    FUN_01056298(0);
    FUN_01056324(0);
    FUN_010561fe(0);
    FUN_01055fd6(0);
    FUN_01056400(1);
    FUN_0105669a(1);
    FUN_01056726(1);
    if (DAT_0103fa0a == '\x03') {
      FUN_01056600(1);
    }
    FUN_01050e6e();
    if (uVar3 == 3) break;
    FUN_0105669a(0);
    FUN_01056726(0);
    FUN_01056600(0);
    FUN_01056400(0);
    FUN_01056802(1);
    FUN_01056a9c(1);
    FUN_01056b28(1);
    if (DAT_0103fa0a == '\x03') {
      FUN_01056a02(1);
    }
    FUN_01051138();
    if ((uVar3 == 3) || ((int)(uint)DAT_0103fa06 <= iVar2 + 1)) break;
    FUN_01056a9c(0);
    FUN_01056b28(0);
    FUN_01056a02(0);
    FUN_01056802(0);
  }
  uVar4 = 0;
  FUN_0105854a();
  FUN_01051e52(1);
  FUN_01058fd8(1);
  DAT_0103f1c7 = 0;
  return uVar4;
}


// ==== FUN_01048aa6 @ 01048aa6

undefined4 FUN_01048aa6(void)

{
  bool bVar1;
  int iVar2;
  undefined4 uVar3;
  
  bVar1 = true;
  FUN_0105854a(1);
  iVar2 = 0;
  do {
    if ((int)(uint)DAT_0103f9b3 <= iVar2) {
LAB_01048d82:
      uVar3 = 0;
      FUN_0105854a();
      FUN_01051e52(1);
      FUN_01058fd8(1);
      DAT_0103f1c7 = 0;
      return uVar3;
    }
    if ((&DAT_0103f9a4)[iVar2] == '\x01') {
      FUN_01055a46(0);
      FUN_01055ad2(0);
      FUN_010559ac(0);
      FUN_01055784(0);
      FUN_01055784(1);
      FUN_01055a46(1);
      FUN_01055ad2(1);
      if (DAT_0103fa0a == '\x03') {
        FUN_010559ac(1);
      }
      FUN_0104a512();
      if (iVar2 == 3) goto LAB_01048d82;
LAB_01048d3c:
      if ((DAT_0103fa0a == '\x02') && (bVar1)) {
        bVar1 = false;
        FUN_01049efe();
        if (iVar2 == 0) goto LAB_01048d82;
      }
      if ((DAT_0103fa0a == '\x03') && (bVar1)) {
        bVar1 = false;
        FUN_0104a110();
        if (iVar2 == 0) goto LAB_01048d82;
      }
    }
    else {
      if ((&DAT_0103f9a4)[iVar2] == '\x02') {
        FUN_01055a46(0);
        FUN_01055ad2(0);
        FUN_010559ac(0);
        FUN_01055784(0);
        FUN_01055bac(1);
        FUN_01055e6e(1);
        FUN_01055efa(1);
        if (DAT_0103fa0a == '\x03') {
          FUN_01055dd4(1);
        }
        FUN_0104b7f6();
joined_r0x01048bc6:
        if (iVar2 != 3) goto LAB_01048d3c;
        goto LAB_01048d82;
      }
      if ((&DAT_0103f9a4)[iVar2] == '\x03') {
        FUN_01055a46(0);
        FUN_01055ad2(0);
        FUN_010559ac(0);
        FUN_01055784(0);
        FUN_01055fd6(1);
        FUN_01056298(1);
        FUN_01056324(1);
        if (DAT_0103fa0a == '\x03') {
          FUN_010561fe(1);
        }
        FUN_0104c600();
        goto joined_r0x01048bc6;
      }
      if ((&DAT_0103f9a4)[iVar2] != '\x04') {
        if ((&DAT_0103f9a4)[iVar2] != '\x05') goto LAB_01048d3c;
        FUN_01055a46(0);
        FUN_01055ad2(0);
        FUN_010559ac(0);
        FUN_01055784(0);
        FUN_01056802(1);
        FUN_01056a9c(1);
        FUN_01056b28(1);
        if (DAT_0103fa0a == '\x03') {
          FUN_01056a02(1);
        }
        FUN_01051138();
        goto joined_r0x01048bc6;
      }
      FUN_01055a46(0);
      FUN_01055ad2(0);
      FUN_010559ac(0);
      FUN_01055784(0);
      FUN_01056400(1);
      FUN_0105669a(1);
      FUN_01056726(1);
      if (DAT_0103fa0a == '\x03') {
        FUN_01056600(1);
      }
      FUN_01050e6e();
      if (iVar2 == 3) goto LAB_01048d82;
    }
    iVar2 = iVar2 + 1;
  } while( true );
}


// ==== FUN_01048db2 @ 01048db2

undefined4 FUN_01048db2(void)

{
  bool bVar1;
  int iVar2;
  undefined4 uVar3;
  int local_8;
  
  local_8 = 2;
  bVar1 = true;
  FUN_0105854a(1);
  do {
    for (iVar2 = 0; iVar2 < (int)(uint)DAT_0103f9b3; iVar2 = iVar2 + 1) {
      if ((&DAT_0103f9a4)[iVar2] == '\x01') {
        FUN_01055a46(0);
        FUN_01055ad2(0);
        FUN_010559ac(0);
        FUN_01055784(0);
        FUN_01055784(1);
        FUN_01055a46(1);
        FUN_01055ad2(1);
        if (DAT_0103fa0a == '\x03') {
          FUN_010559ac(1);
        }
        FUN_0104a512();
        local_8 = iVar2;
        if (iVar2 == 2) break;
joined_r0x01049020:
        local_8 = iVar2;
        if (iVar2 == 3) break;
      }
      else {
        if ((&DAT_0103f9a4)[iVar2] == '\x02') {
          FUN_01055a46(0);
          FUN_01055ad2(0);
          FUN_010559ac(0);
          FUN_01055784(0);
          FUN_01055bac(1);
          FUN_01055e6e(1);
          FUN_01055efa(1);
          if (DAT_0103fa0a == '\x03') {
            FUN_01055dd4(1);
          }
          FUN_0104b7f6();
joined_r0x01048ef4:
          local_8 = iVar2;
          if (iVar2 != 2) goto joined_r0x01049020;
          break;
        }
        if ((&DAT_0103f9a4)[iVar2] == '\x03') {
          FUN_01055a46(0);
          FUN_01055ad2(0);
          FUN_010559ac(0);
          FUN_01055784(0);
          FUN_01055fd6(1);
          FUN_01056298(1);
          FUN_01056324(1);
          if (DAT_0103fa0a == '\x03') {
            FUN_010561fe(1);
          }
          FUN_0104c600();
          goto joined_r0x01048ef4;
        }
        if ((&DAT_0103f9a4)[iVar2] == '\x04') {
          FUN_01055a46(0);
          FUN_01055ad2(0);
          FUN_010559ac(0);
          FUN_01055784(0);
          FUN_01056400(1);
          FUN_0105669a(1);
          FUN_01056726(1);
          if (DAT_0103fa0a == '\x03') {
            FUN_01056600(1);
          }
          FUN_01050e6e();
          goto joined_r0x01048ef4;
        }
        if ((&DAT_0103f9a4)[iVar2] == '\x05') {
          FUN_01055a46(0);
          FUN_01055ad2(0);
          FUN_010559ac(0);
          FUN_01055784(0);
          FUN_01056802(1);
          FUN_01056a9c(1);
          FUN_01056b28(1);
          if (DAT_0103fa0a == '\x03') {
            FUN_01056a02(1);
          }
          FUN_01051138();
          goto joined_r0x01048ef4;
        }
      }
      if ((DAT_0103fa0a == '\x02') && (bVar1)) {
        bVar1 = false;
        FUN_01049efe();
        if (iVar2 == 0) {
          local_8 = 3;
          break;
        }
      }
      if ((DAT_0103fa0a == '\x03') && (bVar1)) {
        bVar1 = false;
        FUN_0104a110();
        if (iVar2 == 0) {
          local_8 = 3;
          break;
        }
      }
    }
    if ((local_8 == 2) || (local_8 == 3)) {
      uVar3 = 0;
      FUN_0105854a();
      FUN_01051e52(1);
      FUN_01058fd8(1);
      DAT_0103f1c7 = 0;
      return uVar3;
    }
  } while( true );
}


// ==== FUN_01049148 @ 01049148

undefined4 FUN_01049148(void)

{
  bool bVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  int local_8;
  
  local_8 = 3;
  bVar1 = true;
  DAT_0103fa08 = 0;
  FUN_0105854a(1);
  for (iVar2 = 0; iVar2 < (int)(uint)DAT_0103fa06; iVar2 = iVar2 + 1) {
    DAT_0103fa08 = DAT_0103fa08 + 1;
    FUN_0105854a(1);
    for (iVar3 = 0; iVar3 < (int)(uint)DAT_0103f9b3; iVar3 = iVar3 + 1) {
      if ((&DAT_0103f9a4)[iVar3] == '\x01') {
        FUN_01055a46(0);
        FUN_01055ad2(0);
        FUN_010559ac(0);
        FUN_01055784(0);
        FUN_01055784(1);
        FUN_01055a46(1);
        FUN_01055ad2(1);
        if (DAT_0103fa0a == '\x03') {
          FUN_010559ac(1);
        }
        FUN_0104a512();
joined_r0x010493b0:
        local_8 = iVar3;
        if (iVar3 == 3) break;
      }
      else {
        if ((&DAT_0103f9a4)[iVar3] == '\x02') {
          FUN_01055a46(0);
          FUN_01055ad2(0);
          FUN_010559ac(0);
          FUN_01055784(0);
          FUN_01055bac(1);
          FUN_01055e6e(1);
          FUN_01055efa(1);
          if (DAT_0103fa0a == '\x03') {
            FUN_01055dd4(1);
          }
          FUN_0104b7f6();
          goto joined_r0x010493b0;
        }
        if ((&DAT_0103f9a4)[iVar3] == '\x03') {
          FUN_01055a46(0);
          FUN_01055ad2(0);
          FUN_010559ac(0);
          FUN_01055784(0);
          FUN_01055fd6(1);
          FUN_01056298(1);
          FUN_01056324(1);
          if (DAT_0103fa0a == '\x03') {
            FUN_010561fe(1);
          }
          FUN_0104c600();
          goto joined_r0x010493b0;
        }
        if ((&DAT_0103f9a4)[iVar3] == '\x04') {
          FUN_01055a46(0);
          FUN_01055ad2(0);
          FUN_010559ac(0);
          FUN_01055784(0);
          FUN_01056400(1);
          FUN_0105669a(1);
          FUN_01056726(1);
          if (DAT_0103fa0a == '\x03') {
            FUN_01056600(1);
          }
          FUN_01050e6e();
          goto joined_r0x010493b0;
        }
        if ((&DAT_0103f9a4)[iVar3] == '\x05') {
          FUN_01055a46(0);
          FUN_01055ad2(0);
          FUN_010559ac(0);
          FUN_01055784(0);
          FUN_01056802(1);
          FUN_01056a9c(1);
          FUN_01056b28(1);
          if (DAT_0103fa0a == '\x03') {
            FUN_01056a02(1);
          }
          FUN_01051138();
          goto joined_r0x010493b0;
        }
      }
      if ((DAT_0103fa0a == '\x02') && (bVar1)) {
        bVar1 = false;
        FUN_01049efe();
        if (iVar3 == 0) {
          local_8 = 3;
          break;
        }
      }
      if ((DAT_0103fa0a == '\x03') && (bVar1)) {
        bVar1 = false;
        FUN_0104a110();
        if (iVar3 == 0) {
          local_8 = 3;
          break;
        }
      }
    }
    if (local_8 == 3) break;
  }
  uVar4 = 0;
  FUN_0105854a();
  FUN_01051e52(1);
  FUN_01058fd8(1);
  DAT_0103f1c7 = 0;
  return uVar4;
}


// ==== FUN_010494c4 @ 010494c4

void FUN_010494c4(void)

{
  FUN_0105854a(1);
  if (DAT_0103f9a4 == '\x01') {
    FUN_01055784(1);
    FUN_01055a46(1);
    FUN_01055ad2(1);
    if (DAT_0103fa0a == '\x03') {
      FUN_010559ac(1);
    }
    FUN_0104a512();
  }
  else if (DAT_0103f9a4 == '\x02') {
    FUN_01055bac(1);
    FUN_01055e6e(1);
    FUN_01055efa(1);
    if (DAT_0103fa0a == '\x03') {
      FUN_01055dd4(1);
    }
    FUN_0104b7f6();
  }
  else if (DAT_0103f9a4 == '\x03') {
    FUN_01055fd6(1);
    FUN_01056298(1);
    FUN_01056324(1);
    if (DAT_0103fa0a == '\x03') {
      FUN_010561fe(1);
    }
    FUN_0104c600();
  }
  else if (DAT_0103f9a4 == '\x04') {
    FUN_01056400(1);
    FUN_0105669a(1);
    FUN_01056726(1);
    if (DAT_0103fa0a == '\x03') {
      FUN_01056600(1);
    }
    FUN_01050e6e();
  }
  else if (DAT_0103f9a4 == '\x05') {
    FUN_01056802(1);
    FUN_01056a9c(1);
    FUN_01056b28(1);
    if (DAT_0103fa0a == '\x03') {
      FUN_01056a02(1);
    }
    FUN_01051138();
  }
  else if (DAT_0103f9a4 == '\x06') {
    FUN_01056c04(1);
    FUN_01056e9e(1);
    FUN_01056f2a(1);
    if (DAT_0103fa0a == '\x03') {
      FUN_01056e04(1);
    }
    FUN_01051402();
  }
  FUN_0105854a(0);
  FUN_01051e52(1);
  FUN_01058fd8(1);
  DAT_0103f1c7 = 0;
  return;
}


// ==== FUN_01049704 @ 01049704

void FUN_01049704(void)

{
  bool bVar1;
  int unaff_D7;
  
  bVar1 = true;
  FUN_0105854a(1);
  do {
    do {
      if (DAT_0103f9a4 == '\x01') {
        FUN_01055a46(0);
        FUN_01055ad2(0);
        FUN_010559ac(0);
        FUN_01055784(0);
        FUN_01055784(1);
        FUN_01055a46(1);
        FUN_01055ad2(1);
        if (DAT_0103fa0a == '\x03') {
          FUN_010559ac(1);
        }
        FUN_0104a512();
joined_r0x0104996a:
        if (unaff_D7 != 1) goto LAB_01049a28;
      }
      else {
        if (DAT_0103f9a4 == '\x02') {
          FUN_01055e6e(0);
          FUN_01055efa(0);
          FUN_01055dd4(0);
          FUN_01055bac(0);
          FUN_01055bac(1);
          FUN_01055e6e(1);
          FUN_01055efa(1);
          if (DAT_0103fa0a == '\x03') {
            FUN_01055dd4(1);
          }
          FUN_0104b7f6();
          goto joined_r0x0104996a;
        }
        if (DAT_0103f9a4 == '\x03') {
          FUN_01056298(0);
          FUN_01056324(0);
          FUN_010561fe(0);
          FUN_01055fd6(0);
          FUN_01055fd6(1);
          FUN_01056298(1);
          FUN_01056324(1);
          if (DAT_0103fa0a == '\x03') {
            FUN_010561fe(1);
          }
          FUN_0104c600();
          goto joined_r0x0104996a;
        }
        if (DAT_0103f9a4 == '\x04') {
          FUN_0105669a(0);
          FUN_01056726(0);
          FUN_01056600(0);
          FUN_01056400(0);
          FUN_01056400(1);
          FUN_0105669a(1);
          FUN_01056726(1);
          if (DAT_0103fa0a == '\x03') {
            FUN_01056600(1);
          }
          FUN_01050e6e();
          goto joined_r0x0104996a;
        }
        if (DAT_0103f9a4 == '\x05') {
          FUN_01056a9c(0);
          FUN_01056b28(0);
          FUN_01056a02(0);
          FUN_01056802(0);
          FUN_01056802(1);
          FUN_01056a9c(1);
          FUN_01056b28(1);
          if (DAT_0103fa0a == '\x03') {
            FUN_01056a02(1);
          }
          FUN_01051138();
          goto joined_r0x0104996a;
        }
        if (DAT_0103f9a4 == '\x06') {
          FUN_01056e9e(0);
          FUN_01056f2a(0);
          FUN_01056e04(0);
          FUN_01056c04(0);
          FUN_01056c04(1);
          FUN_01056e9e(1);
          FUN_01056f2a(1);
          if (DAT_0103fa0a == '\x03') {
            FUN_01056e04(1);
          }
          FUN_01051402();
          goto joined_r0x0104996a;
        }
      }
      if ((DAT_0103fa0a == '\x02') && (bVar1)) {
        bVar1 = false;
        FUN_01049efe();
        if (unaff_D7 == 0) goto LAB_01049a28;
      }
    } while ((DAT_0103fa0a != '\x03') || (!bVar1));
    bVar1 = false;
    FUN_0104a110();
  } while (unaff_D7 != 0);
LAB_01049a28:
  FUN_0105854a(0);
  FUN_01051e52(1);
  FUN_01058fd8(1);
  DAT_0103f1c7 = 0;
  return;
}


// ==== FUN_01049a54 @ 01049a54

undefined4 FUN_01049a54(void)

{
  bool bVar1;
  int iVar2;
  uint uVar3;
  undefined4 uVar4;
  
  bVar1 = true;
  DAT_0103fa08 = 0;
  FUN_0105854a(1);
  for (iVar2 = 0; uVar3 = (uint)DAT_0103fa06, iVar2 < (int)uVar3; iVar2 = iVar2 + 1) {
    DAT_0103fa08 = DAT_0103fa08 + 1;
    FUN_0105854a(1);
    if (DAT_0103f9a4 == '\x01') {
      FUN_01055a46(0);
      FUN_01055ad2(0);
      FUN_010559ac(0);
      FUN_01055784(0);
      FUN_01055784(1);
      FUN_01055a46(1);
      FUN_01055ad2(1);
      if (DAT_0103fa0a == '\x03') {
        FUN_010559ac(1);
      }
      FUN_0104a512();
joined_r0x01049cee:
      if (uVar3 == 3) break;
    }
    else {
      if (DAT_0103f9a4 == '\x02') {
        FUN_01055e6e(0);
        FUN_01055efa(0);
        FUN_01055dd4(0);
        FUN_01055bac(0);
        FUN_01055bac(1);
        FUN_01055e6e(1);
        FUN_01055efa(1);
        if (DAT_0103fa0a == '\x03') {
          FUN_01055dd4(1);
        }
        FUN_0104b7f6();
        goto joined_r0x01049cee;
      }
      if (DAT_0103f9a4 == '\x03') {
        FUN_01056298(0);
        FUN_01056324(0);
        FUN_010561fe(0);
        FUN_01055fd6(0);
        FUN_01055fd6(1);
        FUN_01056298(1);
        FUN_01056324(1);
        if (DAT_0103fa0a == '\x03') {
          FUN_010561fe(1);
        }
        FUN_0104c600();
        goto joined_r0x01049cee;
      }
      if (DAT_0103f9a4 == '\x04') {
        FUN_0105669a(0);
        FUN_01056726(0);
        FUN_01056600(0);
        FUN_01056400(0);
        FUN_01056400(1);
        FUN_0105669a(1);
        FUN_01056726(1);
        if (DAT_0103fa0a == '\x03') {
          FUN_01056600(1);
        }
        FUN_01050e6e();
        goto joined_r0x01049cee;
      }
      if (DAT_0103f9a4 == '\x05') {
        FUN_01056a9c(0);
        FUN_01056b28(0);
        FUN_01056a02(0);
        FUN_01056802(0);
        FUN_01056802(1);
        FUN_01056a9c(1);
        FUN_01056b28(1);
        if (DAT_0103fa0a == '\x03') {
          FUN_01056a02(1);
        }
        FUN_01051138();
        goto joined_r0x01049cee;
      }
      if (DAT_0103f9a4 == '\x06') {
        FUN_01056e9e(0);
        FUN_01056f2a(0);
        FUN_01056e04(0);
        FUN_01056c04(0);
        FUN_01056c04(1);
        FUN_01056e9e(1);
        FUN_01056f2a(1);
        if (DAT_0103fa0a == '\x03') {
          FUN_01056e04(1);
        }
        FUN_01051402();
        goto joined_r0x01049cee;
      }
    }
    if ((DAT_0103fa0a == '\x02') && (bVar1)) {
      bVar1 = false;
      FUN_01049efe();
      if (uVar3 == 0) break;
    }
    if ((DAT_0103fa0a == '\x03') && (bVar1)) {
      bVar1 = false;
      FUN_0104a110();
      if (uVar3 == 0) break;
    }
  }
  uVar4 = 0;
  FUN_0105854a();
  FUN_01051e52(1);
  FUN_01058fd8(1);
  DAT_0103f1c7 = 0;
  return uVar4;
}


// ==== FUN_01049efe @ 01049efe

void FUN_01049efe(void)

{
  int unaff_D5;
  int iVar1;
  int unaff_D7;
  
  if (DAT_0103fa04 == '\0') {
    FUN_0104a322();
    if (unaff_D7 == 1) {
      return;
    }
    FUN_0104a37a();
    if (unaff_D7 == 1) {
      return;
    }
    FUN_0104a3a8();
    if (unaff_D7 == 1) {
      return;
    }
    FUN_0104a3e4();
    if (unaff_D7 == 1) {
      return;
    }
    FUN_0104a3f6();
    if (unaff_D7 == 1) {
      return;
    }
  }
  else if (DAT_0103fa04 == '\x10') {
    for (iVar1 = 0; iVar1 < (int)(uint)DAT_0103f9b3; iVar1 = iVar1 + 1) {
      if ((&DAT_0103f9a4)[iVar1] == '\x01') {
        FUN_0104a322();
        if (iVar1 == 1) {
          return;
        }
      }
      if ((&DAT_0103f9a4)[iVar1] == '\x02') {
        FUN_0104a37a();
        if (iVar1 == 1) {
          return;
        }
      }
      if ((&DAT_0103f9a4)[iVar1] == '\x03') {
        FUN_0104a3a8();
        if (iVar1 == 1) {
          return;
        }
      }
      if ((&DAT_0103f9a4)[iVar1] == '\x04') {
        FUN_0104a3e4();
        if (iVar1 == 1) {
          return;
        }
      }
      if ((&DAT_0103f9a4)[iVar1] == '\x05') {
        FUN_0104a3f6();
        if (iVar1 == 1) {
          return;
        }
      }
    }
  }
  else if ((&DAT_0103f9a4)[unaff_D5] == '\x01') {
    FUN_0104a322();
    if (unaff_D5 == 1) {
      return;
    }
  }
  else if ((&DAT_0103f9a4)[unaff_D5] == '\x02') {
    FUN_0104a37a();
    if (unaff_D5 == 1) {
      return;
    }
  }
  else if ((&DAT_0103f9a4)[unaff_D5] == '\x03') {
    FUN_0104a3a8();
    if (unaff_D5 == 1) {
      return;
    }
  }
  else if ((&DAT_0103f9a4)[unaff_D5] == '\x04') {
    FUN_0104a3e4();
    if (unaff_D5 == 1) {
      return;
    }
  }
  else if ((&DAT_0103f9a4)[unaff_D5] == '\x05') {
    FUN_0104a3f6();
    if (unaff_D5 == 1) {
      return;
    }
  }
  else if ((&DAT_0103f9a4)[unaff_D5] == '\x06') {
    FUN_0104a408();
    if (unaff_D5 == 1) {
      return;
    }
  }
  return;
}


// ==== FUN_0104a110 @ 0104a110

void FUN_0104a110(void)

{
  int unaff_D5;
  int iVar1;
  int unaff_D7;
  
  if (DAT_0103fa04 == '\0') {
    FUN_0104a41a();
    if (unaff_D7 == 1) {
      return;
    }
    FUN_0104a472();
    if (unaff_D7 == 1) {
      return;
    }
    FUN_0104a4a0();
    if (unaff_D7 == 1) {
      return;
    }
    FUN_0104a4dc();
    if (unaff_D7 == 1) {
      return;
    }
    FUN_0104a4ee();
    if (unaff_D7 == 1) {
      return;
    }
  }
  else if (DAT_0103fa04 == '\x10') {
    for (iVar1 = 0; iVar1 < (int)(uint)DAT_0103f9b3; iVar1 = iVar1 + 1) {
      if ((&DAT_0103f9a4)[iVar1] == '\x01') {
        FUN_0104a41a();
        if (iVar1 == 1) {
          return;
        }
      }
      if ((&DAT_0103f9a4)[iVar1] == '\x02') {
        FUN_0104a472();
        if (iVar1 == 1) {
          return;
        }
      }
      if ((&DAT_0103f9a4)[iVar1] == '\x03') {
        FUN_0104a4a0();
        if (iVar1 == 1) {
          return;
        }
      }
      if ((&DAT_0103f9a4)[iVar1] == '\x05') {
        FUN_0104a4dc();
        if (iVar1 == 1) {
          return;
        }
      }
      if ((&DAT_0103f9a4)[iVar1] == '\x06') {
        FUN_0104a4ee();
        if (iVar1 == 1) {
          return;
        }
      }
    }
  }
  else if ((&DAT_0103f9a4)[unaff_D5] == '\x01') {
    FUN_0104a41a();
    if (unaff_D5 == 1) {
      return;
    }
  }
  else if ((&DAT_0103f9a4)[unaff_D5] == '\x02') {
    FUN_0104a472();
    if (unaff_D5 == 1) {
      return;
    }
  }
  else if ((&DAT_0103f9a4)[unaff_D5] == '\x03') {
    FUN_0104a4a0();
    if (unaff_D5 == 1) {
      return;
    }
  }
  else if ((&DAT_0103f9a4)[unaff_D5] == '\x04') {
    FUN_0104a4dc();
    if (unaff_D5 == 1) {
      return;
    }
  }
  else if ((&DAT_0103f9a4)[unaff_D5] == '\x05') {
    FUN_0104a4ee();
    if (unaff_D5 == 1) {
      return;
    }
  }
  else if ((&DAT_0103f9a4)[unaff_D5] == '\x06') {
    FUN_0104a500();
    if (unaff_D5 == 1) {
      return;
    }
  }
  return;
}


// ==== FUN_0104a322 @ 0104a322

void FUN_0104a322(void)

{
  if (DAT_0103f9f9 == 'A') {
    return;
  }
  if (DAT_0103f9fb == 'A') {
    return;
  }
  if (DAT_0103f9fd == 'A') {
    return;
  }
  if (DAT_0103f9ff == 'A') {
    return;
  }
  if (DAT_0103fa01 == 'A') {
    return;
  }
  if (DAT_0103fa03 == 'A') {
    return;
  }
  return;
}


// ==== FUN_0104a37a @ 0104a37a

void FUN_0104a37a(void)

{
  if (DAT_0103f9f3 == 'A') {
    return;
  }
  if (DAT_0103f9f5 == 'A') {
    return;
  }
  if (DAT_0103f9f7 == 'A') {
    return;
  }
  return;
}


// ==== FUN_0104a3a8 @ 0104a3a8

void FUN_0104a3a8(void)

{
  if (DAT_0103f9eb == 'A') {
    return;
  }
  if (DAT_0103f9ed == 'A') {
    return;
  }
  if (DAT_0103f9ef == 'A') {
    return;
  }
  if (DAT_0103f9f1 == 'A') {
    return;
  }
  return;
}


// ==== FUN_0104a3e4 @ 0104a3e4

void FUN_0104a3e4(void)

{
  if (DAT_0103f9e9 == 'A') {
    return;
  }
  return;
}


// ==== FUN_0104a3f6 @ 0104a3f6

void FUN_0104a3f6(void)

{
  if (DAT_0103f9e7 == 'A') {
    return;
  }
  return;
}


// ==== FUN_0104a408 @ 0104a408

void FUN_0104a408(void)

{
  if (DAT_0103f9e5 == 'A') {
    return;
  }
  return;
}


// ==== FUN_0104a41a @ 0104a41a

void FUN_0104a41a(void)

{
  if (DAT_0103f9f8 == '\x01') {
    return;
  }
  if (DAT_0103f9fa == '\x01') {
    return;
  }
  if (DAT_0103f9fc == '\x01') {
    return;
  }
  if (DAT_0103f9fe == '\x01') {
    return;
  }
  if (DAT_0103fa00 == '\x01') {
    return;
  }
  if (DAT_0103fa02 == '\x01') {
    return;
  }
  return;
}


// ==== FUN_0104a472 @ 0104a472

void FUN_0104a472(void)

{
  if (DAT_0103f9f2 == '\x01') {
    return;
  }
  if (DAT_0103f9f4 == '\x01') {
    return;
  }
  if (DAT_0103f9f6 == '\x01') {
    return;
  }
  return;
}


// ==== FUN_0104a4a0 @ 0104a4a0

void FUN_0104a4a0(void)

{
  if (DAT_0103f9ea == '\x01') {
    return;
  }
  if (DAT_0103f9ec == '\x01') {
    return;
  }
  if (DAT_0103f9ee == '\x01') {
    return;
  }
  if (DAT_0103f9f0 == '\x01') {
    return;
  }
  return;
}


// ==== FUN_0104a4dc @ 0104a4dc

void FUN_0104a4dc(void)

{
  if (DAT_0103f9e8 == '\x01') {
    return;
  }
  return;
}


// ==== FUN_0104a4ee @ 0104a4ee

void FUN_0104a4ee(void)

{
  if (DAT_0103f9e6 == '\x01') {
    return;
  }
  return;
}


// ==== FUN_0104a500 @ 0104a500

void FUN_0104a500(void)

{
  if (DAT_0103f9e4 == '\x01') {
    return;
  }
  return;
}


// ==== FUN_0104a512 @ 0104a512

void FUN_0104a512(void)

{
  undefined4 uVar1;
  
  uVar1 = 1;
  FUN_01058968(1);
  FUN_01051890(1,"CPU-88    ",uVar1);
  if (DAT_0103fa0a == '\x01') {
    FUN_0104a596();
  }
  else if (DAT_0103fa0a == '\x02') {
    FUN_0104ab68();
  }
  else if (DAT_0103fa0a == '\x03') {
    FUN_0104b182();
  }
  FUN_01058968(0);
  return;
}


// ==== FUN_0104a596 @ 0104a596

void FUN_0104a596(void)

{
  int unaff_D7;
  
  FUN_0105881e(1,1,0x69);
  FUN_01034c4c();
  FUN_01048236(&DAT_0104a58a);
  if (unaff_D7 == 1) {
    FUN_0105881e(1,1,0x70);
  }
  else if (unaff_D7 == 2) {
    FUN_0105881e(1,1,0x66);
  }
  else if (unaff_D7 == 3) {
    FUN_0105881e(1,1,0x61);
  }
  if ((unaff_D7 == 3) ||
     ((unaff_D7 == 2 &&
      (((DAT_0103f1c7 == '\x02' || (DAT_0103f1c7 == '\x05')) || (DAT_0103f1c7 == '\b')))))) {
    return;
  }
  if ((unaff_D7 == 2) && (DAT_0103f9f9 == 'M')) {
    return;
  }
  FUN_0105e75a(0,0x1e);
  FUN_0105881e(1,2,0x69);
  FUN_0103092c();
  FUN_01048236(&DAT_0104a58c);
  if (unaff_D7 == 1) {
    FUN_0105881e(1,2,0x70);
  }
  else if (unaff_D7 == 2) {
    FUN_0105881e(1,2,0x66);
  }
  else if (unaff_D7 == 3) {
    FUN_0105881e(1,2,0x61);
  }
  if ((unaff_D7 == 3) ||
     ((unaff_D7 == 2 &&
      (((DAT_0103f1c7 == '\x02' || (DAT_0103f1c7 == '\x05')) || (DAT_0103f1c7 == '\b')))))) {
    return;
  }
  if ((unaff_D7 == 2) && (DAT_0103f9fb == 'M')) {
    return;
  }
  FUN_0105e75a(0,0x1e);
  FUN_0105881e(1,3,0x69);
  FUN_01031e06();
  FUN_01048236(&DAT_0104a58e);
  if (unaff_D7 == 1) {
    FUN_0105881e(1,3,0x70);
  }
  else if (unaff_D7 == 2) {
    FUN_0105881e(1,3,0x66);
  }
  else if (unaff_D7 == 3) {
    FUN_0105881e(1,3,0x61);
  }
  if ((unaff_D7 == 3) ||
     ((unaff_D7 == 2 &&
      (((DAT_0103f1c7 == '\x02' || (DAT_0103f1c7 == '\x05')) || (DAT_0103f1c7 == '\b')))))) {
    return;
  }
  if ((unaff_D7 == 2) && (DAT_0103f9fd == 'M')) {
    return;
  }
  FUN_0105e75a(0,0x1e);
  FUN_0105881e(1,4,0x69);
  FUN_01032fc2();
  FUN_01048236(&DAT_0104a590);
  if (unaff_D7 == 1) {
    FUN_0105881e(1,4,0x70);
  }
  else if (unaff_D7 == 2) {
    FUN_0105881e(1,4,0x66);
  }
  else if (unaff_D7 == 3) {
    FUN_0105881e(1,4,0x61);
  }
  if ((unaff_D7 == 3) ||
     ((unaff_D7 == 2 &&
      (((DAT_0103f1c7 == '\x02' || (DAT_0103f1c7 == '\x05')) || (DAT_0103f1c7 == '\b')))))) {
    return;
  }
  if ((unaff_D7 == 2) && (DAT_0103f9ff == 'M')) {
    return;
  }
  FUN_0105e75a(0,0x1e);
  FUN_0105881e(1,5,0x69);
  FUN_0103148e();
  FUN_01048236(&DAT_0104a592);
  if (unaff_D7 == 1) {
    FUN_0105881e(1,5,0x70);
  }
  else if (unaff_D7 == 2) {
    FUN_0105881e(1,5,0x66);
  }
  else if (unaff_D7 == 3) {
    FUN_0105881e(1,5,0x61);
  }
  if ((unaff_D7 == 3) ||
     ((unaff_D7 == 2 &&
      (((DAT_0103f1c7 == '\x02' || (DAT_0103f1c7 == '\x05')) || (DAT_0103f1c7 == '\b')))))) {
    return;
  }
  if ((unaff_D7 == 2) && (DAT_0103fa01 == 'M')) {
    return;
  }
  FUN_0105e75a(0,0x1e);
  FUN_0105881e(1,6,0x69);
  if (DAT_0103daca == '\x01') {
    FUN_01033cde();
  }
  else {
    FUN_0104b790();
  }
  FUN_01048236(&DAT_0104a594);
  if (unaff_D7 == 1) {
    FUN_0105881e(1,6,0x70);
  }
  else if (unaff_D7 == 2) {
    FUN_0105881e(1,6,0x66);
  }
  else if (unaff_D7 == 3) {
    FUN_0105881e(1,6,0x61);
  }
  if ((unaff_D7 == 3) ||
     ((unaff_D7 == 2 &&
      (((DAT_0103f1c7 == '\x02' || (DAT_0103f1c7 == '\x05')) || (DAT_0103f1c7 == '\b')))))) {
    return;
  }
  if ((unaff_D7 == 2) && (DAT_0103fa03 == 'M')) {
    return;
  }
  return;
}


// ==== FUN_0104ab68 @ 0104ab68

void FUN_0104ab68(void)

{
  int unaff_D7;
  
  if (DAT_0103f9f9 == 'A') {
    FUN_0105881e(1,1,0x69);
    FUN_01034c4c();
    FUN_01048236(&DAT_0104ab5c);
    if (unaff_D7 == 1) {
      FUN_0105881e(1,1,0x70);
    }
    else if (unaff_D7 == 2) {
      FUN_0105881e(1,1,0x66);
    }
    else if (unaff_D7 == 3) {
      FUN_0105881e(1,1,0x61);
    }
    if ((unaff_D7 == 3) ||
       ((unaff_D7 == 2 &&
        (((DAT_0103f1c7 == '\x02' || (DAT_0103f1c7 == '\x05')) || (DAT_0103f1c7 == '\b')))))) {
      return;
    }
    if ((unaff_D7 == 2) && (DAT_0103f9f9 == 'M')) {
      return;
    }
  }
  if (DAT_0103f9fb == 'A') {
    FUN_0105e75a(0,0x1e);
    FUN_0105881e(1,2,0x69);
    FUN_0103092c();
    FUN_01048236(&DAT_0104ab5e);
    if (unaff_D7 == 1) {
      FUN_0105881e(1,2,0x70);
    }
    else if (unaff_D7 == 2) {
      FUN_0105881e(1,2,0x66);
    }
    else if (unaff_D7 == 3) {
      FUN_0105881e(1,2,0x61);
    }
    if ((unaff_D7 == 3) ||
       ((unaff_D7 == 2 &&
        (((DAT_0103f1c7 == '\x02' || (DAT_0103f1c7 == '\x05')) || (DAT_0103f1c7 == '\b')))))) {
      return;
    }
    if ((unaff_D7 == 2) && (DAT_0103f9fb == 'M')) {
      return;
    }
  }
  if (DAT_0103f9fd == 'A') {
    FUN_0105e75a(0,0x1e);
    FUN_0105881e(1,3,0x69);
    FUN_01031e06();
    FUN_01048236(&DAT_0104ab60);
    if (unaff_D7 == 1) {
      FUN_0105881e(1,3,0x70);
    }
    else if (unaff_D7 == 2) {
      FUN_0105881e(1,3,0x66);
    }
    else if (unaff_D7 == 3) {
      FUN_0105881e(1,3,0x61);
    }
    if ((unaff_D7 == 3) ||
       ((unaff_D7 == 2 &&
        (((DAT_0103f1c7 == '\x02' || (DAT_0103f1c7 == '\x05')) || (DAT_0103f1c7 == '\b')))))) {
      return;
    }
    if ((unaff_D7 == 2) && (DAT_0103f9fd == 'M')) {
      return;
    }
  }
  if (DAT_0103f9ff == 'A') {
    FUN_0105e75a(0,0x1e);
    FUN_0105881e(1,4,0x69);
    FUN_01032fc2();
    FUN_01048236(&DAT_0104ab62);
    if (unaff_D7 == 1) {
      FUN_0105881e(1,4,0x70);
    }
    else if (unaff_D7 == 2) {
      FUN_0105881e(1,4,0x66);
    }
    else if (unaff_D7 == 3) {
      FUN_0105881e(1,4,0x61);
    }
    if ((unaff_D7 == 3) ||
       ((unaff_D7 == 2 &&
        (((DAT_0103f1c7 == '\x02' || (DAT_0103f1c7 == '\x05')) || (DAT_0103f1c7 == '\b')))))) {
      return;
    }
    if ((unaff_D7 == 2) && (DAT_0103f9ff == 'M')) {
      return;
    }
  }
  if (DAT_0103fa01 == 'A') {
    FUN_0105e75a(0,0x1e);
    FUN_0105881e(1,5,0x69);
    FUN_0103148e();
    FUN_01048236(&DAT_0104ab64);
    if (unaff_D7 == 1) {
      FUN_0105881e(1,5,0x70);
    }
    else if (unaff_D7 == 2) {
      FUN_0105881e(1,5,0x66);
    }
    else if (unaff_D7 == 3) {
      FUN_0105881e(1,5,0x61);
    }
    if ((unaff_D7 == 3) ||
       ((unaff_D7 == 2 &&
        (((DAT_0103f1c7 == '\x02' || (DAT_0103f1c7 == '\x05')) || (DAT_0103f1c7 == '\b')))))) {
      return;
    }
    if ((unaff_D7 == 2) && (DAT_0103fa01 == 'M')) {
      return;
    }
  }
  if (DAT_0103fa03 == 'A') {
    FUN_0105e75a(0,0x1e);
    FUN_0105881e(1,6,0x69);
    if (DAT_0103daca == '\x01') {
      FUN_01033cde();
    }
    else {
      FUN_0104b790();
    }
    FUN_01048236(&DAT_0104ab66);
    if (unaff_D7 == 1) {
      FUN_0105881e(1,6,0x70);
    }
    else if (unaff_D7 == 2) {
      FUN_0105881e(1,6,0x66);
    }
    else if (unaff_D7 == 3) {
      FUN_0105881e(1,6,0x61);
    }
    if ((unaff_D7 == 3) ||
       ((unaff_D7 == 2 &&
        (((DAT_0103f1c7 == '\x02' || (DAT_0103f1c7 == '\x05')) || (DAT_0103f1c7 == '\b')))))) {
      return;
    }
    if ((unaff_D7 == 2) && (DAT_0103fa03 == 'M')) {
      return;
    }
  }
  return;
}


// ==== FUN_0104b182 @ 0104b182

void FUN_0104b182(void)

{
  int unaff_D7;
  
  if (DAT_0103f9f8 == '\x01') {
    FUN_0105881e(1,1,0x69);
    FUN_01034c4c();
    FUN_01048236(&DAT_0104b176);
    if (unaff_D7 == 1) {
      FUN_0105881e(1,1,0x70);
    }
    else if (unaff_D7 == 2) {
      FUN_0105881e(1,1,0x66);
    }
    else if (unaff_D7 == 3) {
      FUN_0105881e(1,1,0x61);
    }
    if ((unaff_D7 == 3) ||
       ((unaff_D7 == 2 &&
        (((DAT_0103f1c7 == '\x02' || (DAT_0103f1c7 == '\x05')) || (DAT_0103f1c7 == '\b')))))) {
      return;
    }
    if ((unaff_D7 == 2) && (DAT_0103f9f9 == 'M')) {
      return;
    }
  }
  if (DAT_0103f9fa == '\x01') {
    FUN_0105e75a(0,0x1e);
    FUN_0105881e(1,2,0x69);
    FUN_0103092c();
    FUN_01048236(&DAT_0104b178);
    if (unaff_D7 == 1) {
      FUN_0105881e(1,2,0x70);
    }
    else if (unaff_D7 == 2) {
      FUN_0105881e(1,2,0x66);
    }
    else if (unaff_D7 == 3) {
      FUN_0105881e(1,2,0x61);
    }
    if ((unaff_D7 == 3) ||
       ((unaff_D7 == 2 &&
        (((DAT_0103f1c7 == '\x02' || (DAT_0103f1c7 == '\x05')) || (DAT_0103f1c7 == '\b')))))) {
      return;
    }
    if ((unaff_D7 == 2) && (DAT_0103f9fb == 'M')) {
      return;
    }
  }
  if (DAT_0103f9fc == '\x01') {
    FUN_0105e75a(0,0x1e);
    FUN_0105881e(1,3,0x69);
    FUN_01031e06();
    FUN_01048236(&DAT_0104b17a);
    if (unaff_D7 == 1) {
      FUN_0105881e(1,3,0x70);
    }
    else if (unaff_D7 == 2) {
      FUN_0105881e(1,3,0x66);
    }
    else if (unaff_D7 == 3) {
      FUN_0105881e(1,3,0x61);
    }
    if ((unaff_D7 == 3) ||
       ((unaff_D7 == 2 &&
        (((DAT_0103f1c7 == '\x02' || (DAT_0103f1c7 == '\x05')) || (DAT_0103f1c7 == '\b')))))) {
      return;
    }
    if ((unaff_D7 == 2) && (DAT_0103f9fd == 'M')) {
      return;
    }
  }
  if (DAT_0103f9fe == '\x01') {
    FUN_0105e75a(0,0x1e);
    FUN_0105881e(1,4,0x69);
    FUN_01032fc2();
    FUN_01048236(&DAT_0104b17c);
    if (unaff_D7 == 1) {
      FUN_0105881e(1,4,0x70);
    }
    else if (unaff_D7 == 2) {
      FUN_0105881e(1,4,0x66);
    }
    else if (unaff_D7 == 3) {
      FUN_0105881e(1,4,0x61);
    }
    if ((unaff_D7 == 3) ||
       ((unaff_D7 == 2 &&
        (((DAT_0103f1c7 == '\x02' || (DAT_0103f1c7 == '\x05')) || (DAT_0103f1c7 == '\b')))))) {
      return;
    }
    if ((unaff_D7 == 2) && (DAT_0103f9ff == 'M')) {
      return;
    }
  }
  if (DAT_0103fa00 == '\x01') {
    FUN_0105e75a(0,0x1e);
    FUN_0105881e(1,5,0x69);
    FUN_0103148e();
    FUN_01048236(&DAT_0104b17e);
    if (unaff_D7 == 1) {
      FUN_0105881e(1,5,0x70);
    }
    else if (unaff_D7 == 2) {
      FUN_0105881e(1,5,0x66);
    }
    else if (unaff_D7 == 3) {
      FUN_0105881e(1,5,0x61);
    }
    if ((unaff_D7 == 3) ||
       ((unaff_D7 == 2 &&
        (((DAT_0103f1c7 == '\x02' || (DAT_0103f1c7 == '\x05')) || (DAT_0103f1c7 == '\b')))))) {
      return;
    }
    if ((unaff_D7 == 2) && (DAT_0103fa01 == 'M')) {
      return;
    }
  }
  if (DAT_0103fa02 == '\x01') {
    FUN_0105e75a(0,0x1e);
    FUN_0105881e(1,6,0x69);
    if (DAT_0103daca == '\x01') {
      FUN_01033cde();
    }
    else {
      FUN_0104b790();
    }
    FUN_01048236(&DAT_0104b180);
    if (unaff_D7 == 1) {
      FUN_0105881e(1,6,0x70);
    }
    else if (unaff_D7 == 2) {
      FUN_0105881e(1,6,0x66);
    }
    else if (unaff_D7 == 3) {
      FUN_0105881e(1,6,0x61);
    }
    if ((unaff_D7 == 3) ||
       ((unaff_D7 == 2 &&
        (((DAT_0103f1c7 == '\x02' || (DAT_0103f1c7 == '\x05')) || (DAT_0103f1c7 == '\b')))))) {
      return;
    }
    if ((unaff_D7 == 2) && (DAT_0103fa03 == 'M')) {
      return;
    }
  }
  return;
}


// ==== FUN_0104b790 @ 0104b790

void FUN_0104b790(void)

{
  short unaff_D7w;
  int local_8;
  
  local_8 = 1;
  FUN_0103fffc();
  if ((unaff_D7w != -1) && (unaff_D7w == 0x20)) {
    local_8 = 3;
  }
  FUN_01048236(PTR_s_CPU_88___MFD_Block__0103cda4);
  if (local_8 == 1) {
    FUN_01048236(PTR_s_Check_Pass__0103c98e);
  }
  else {
    FUN_01048236(PTR_s_Check_Abort__0103c9b2);
  }
  return;
}


// ==== FUN_0104b7f6 @ 0104b7f6

void FUN_0104b7f6(void)

{
  undefined4 uVar1;
  
  uVar1 = 1;
  FUN_01058968(1);
  FUN_01051890(1,"SPF       ",uVar1);
  if (DAT_0103fa0a == '\x01') {
    FUN_0104ba6a();
  }
  else if (DAT_0103fa0a == '\x02') {
    FUN_0104bef0();
  }
  else if (DAT_0103fa0a == '\x03') {
    FUN_0104c382();
  }
  FUN_01058968(0);
  return;
}


// ==== FUN_0104b872 @ 0104b872

void FUN_0104b872(void)

{
  int unaff_D7;
  
  FUN_0105e75a(0,0x1e);
  FUN_0105881e(1,2,0x69);
  FUN_0103585c();
  FUN_01048236(&DAT_0104b86e);
  if (unaff_D7 == 1) {
    FUN_0105881e(1,2,0x70);
  }
  else if (unaff_D7 == 2) {
    FUN_0105881e(1,2,0x66);
  }
  else if (unaff_D7 == 3) {
    FUN_0105881e(1,2,0x61);
  }
  if ((unaff_D7 == 3) ||
     ((unaff_D7 == 2 &&
      (((DAT_0103f1c7 == '\x02' || (DAT_0103f1c7 == '\x05')) || (DAT_0103f1c7 == '\b')))))) {
    return;
  }
  if ((unaff_D7 == 2) && (DAT_0103f9f5 == 'M')) {
    return;
  }
  FUN_0105e75a(0,0x1e);
  FUN_0105881e(1,3,0x69);
  FUN_01035d3e();
  FUN_01048236(&DAT_0104b870);
  if (unaff_D7 == 1) {
    FUN_0105881e(1,3,0x70);
  }
  else if (unaff_D7 == 2) {
    FUN_0105881e(1,3,0x66);
  }
  else if (unaff_D7 == 3) {
    FUN_0105881e(1,3,0x61);
  }
  if ((unaff_D7 == 3) ||
     ((unaff_D7 == 2 &&
      (((DAT_0103f1c7 == '\x02' || (DAT_0103f1c7 == '\x05')) || (DAT_0103f1c7 == '\b')))))) {
    return;
  }
  if ((unaff_D7 == 2) && (DAT_0103f9f7 == 'M')) {
    return;
  }
  return;
}


// ==== FUN_0104ba6a @ 0104ba6a

/* WARNING: Removing unreachable block (ram,0x0104bc0a) */
/* WARNING: Removing unreachable block (ram,0x0104bc64) */
/* WARNING: Removing unreachable block (ram,0x0104bbe6) */
/* WARNING: Removing unreachable block (ram,0x0104bc90) */
/* WARNING: Removing unreachable block (ram,0x0104bb98) */

void FUN_0104ba6a(void)

{
  int unaff_D7;
  
  FUN_0105881e(1,1,0x69);
  FUN_0103543c();
  FUN_01048236(&DAT_0104ba68);
  if (unaff_D7 == 1) {
    FUN_0105881e(1,1,0x70);
  }
  else if (unaff_D7 == 2) {
    FUN_0105881e(1,1,0x66);
  }
  else if (unaff_D7 == 3) {
    FUN_0105881e(1,1,0x61);
  }
  if ((unaff_D7 == 3) ||
     ((unaff_D7 == 2 &&
      (((DAT_0103f1c7 == '\x02' || (DAT_0103f1c7 == '\x05')) || (DAT_0103f1c7 == '\b')))))) {
    return;
  }
  if ((unaff_D7 == 2) && (DAT_0103f9f3 == 'M')) {
    return;
  }
  if (DAT_0103da02 == 8) {
    FUN_0103541e();
    if (unaff_D7 == 0) {
      FUN_0105e75a(0,0x1e);
      FUN_01035330();
    }
    FUN_0105e75a(0,0x1e);
    if (unaff_D7 == 1) {
      FUN_0103520a();
      FUN_010353e2();
      FUN_0104b872();
    }
    else {
      FUN_0103527a();
      if (unaff_D7 == 2) {
        FUN_01035400();
        FUN_0103007e();
        return;
      }
    }
    FUN_0105e75a(0,0x1e);
    if (unaff_D7 == 1) {
      FUN_0103527a();
      FUN_01035400();
      FUN_0104b872();
    }
    else {
      FUN_0103520a();
      if (unaff_D7 == 2) {
        FUN_01035400();
        FUN_0103007e();
        return;
      }
    }
    if (unaff_D7 == 1) {
      FUN_010353e2();
    }
    else {
      FUN_01035400();
    }
    FUN_0103007e();
  }
  else {
    FUN_0104b872();
  }
  return;
}


// ==== FUN_0104bce0 @ 0104bce0

void FUN_0104bce0(void)

{
  int unaff_D7;
  
  if (DAT_0103f9f5 == 'A') {
    FUN_0105e75a(0,0x1e);
    FUN_0105881e(1,2,0x69);
    FUN_0103585c();
    FUN_01048236(&DAT_0104bcdc);
    if (unaff_D7 == 1) {
      FUN_0105881e(1,2,0x70);
    }
    else if (unaff_D7 == 2) {
      FUN_0105881e(1,2,0x66);
    }
    else if (unaff_D7 == 3) {
      FUN_0105881e(1,2,0x61);
    }
    if ((unaff_D7 == 3) ||
       ((unaff_D7 == 2 &&
        (((DAT_0103f1c7 == '\x02' || (DAT_0103f1c7 == '\x05')) || (DAT_0103f1c7 == '\b')))))) {
      return;
    }
    if ((unaff_D7 == 2) && (DAT_0103f9f5 == 'M')) {
      return;
    }
  }
  if (DAT_0103f9f7 == 'A') {
    FUN_0105e75a(0,0x1e);
    FUN_0105881e(1,3,0x69);
    FUN_01035d3e();
    FUN_01048236(&DAT_0104bcde);
    if (unaff_D7 == 1) {
      FUN_0105881e(1,3,0x70);
    }
    else if (unaff_D7 == 2) {
      FUN_0105881e(1,3,0x66);
    }
    else if (unaff_D7 == 3) {
      FUN_0105881e(1,3,0x61);
    }
    if ((unaff_D7 == 3) ||
       ((unaff_D7 == 2 &&
        (((DAT_0103f1c7 == '\x02' || (DAT_0103f1c7 == '\x05')) || (DAT_0103f1c7 == '\b')))))) {
      return;
    }
    if ((unaff_D7 == 2) && (DAT_0103f9f7 == 'M')) {
      return;
    }
  }
  return;
}


// ==== FUN_0104bef0 @ 0104bef0

/* WARNING: Removing unreachable block (ram,0x0104c09c) */
/* WARNING: Removing unreachable block (ram,0x0104c0f6) */
/* WARNING: Removing unreachable block (ram,0x0104c078) */
/* WARNING: Removing unreachable block (ram,0x0104c122) */
/* WARNING: Removing unreachable block (ram,0x0104c02a) */

void FUN_0104bef0(void)

{
  int unaff_D7;
  
  if (DAT_0103f9f3 == 'A') {
    FUN_0105881e(1,1,0x69);
    FUN_0103543c();
    FUN_01048236(&DAT_0104beee);
    if (unaff_D7 == 1) {
      FUN_0105881e(1,1,0x70);
    }
    else if (unaff_D7 == 2) {
      FUN_0105881e(1,1,0x66);
    }
    else if (unaff_D7 == 3) {
      FUN_0105881e(1,1,0x61);
    }
    if ((unaff_D7 == 3) ||
       ((unaff_D7 == 2 &&
        (((DAT_0103f1c7 == '\x02' || (DAT_0103f1c7 == '\x05')) || (DAT_0103f1c7 == '\b')))))) {
      return;
    }
    if ((unaff_D7 == 2) && (DAT_0103f9f3 == 'M')) {
      return;
    }
  }
  if (DAT_0103da02 == 8) {
    FUN_0103541e();
    if (unaff_D7 == 0) {
      FUN_0105e75a(0,0x1e);
      FUN_01035330();
    }
    FUN_0105e75a(0,0x1e);
    if (unaff_D7 == 1) {
      FUN_0103520a();
      FUN_010353e2();
      FUN_0104bce0();
    }
    else {
      FUN_0103527a();
      if (unaff_D7 == 2) {
        FUN_01035400();
        FUN_0103007e();
        return;
      }
    }
    FUN_0105e75a(0,0x1e);
    if (unaff_D7 == 1) {
      FUN_0103527a();
      FUN_01035400();
      FUN_0104bce0();
    }
    else {
      FUN_0103520a();
      if (unaff_D7 == 2) {
        FUN_01035400();
        FUN_0103007e();
        return;
      }
    }
    if (unaff_D7 == 1) {
      FUN_010353e2();
    }
    else {
      FUN_01035400();
    }
    FUN_0103007e();
  }
  else {
    FUN_0104bce0();
  }
  return;
}


// ==== FUN_0104c172 @ 0104c172

void FUN_0104c172(void)

{
  int unaff_D7;
  
  if (DAT_0103f9f4 == '\x01') {
    FUN_0105e75a(0,0x1e);
    FUN_0105881e(1,2,0x69);
    FUN_0103585c();
    FUN_01048236(&DAT_0104c16e);
    if (unaff_D7 == 1) {
      FUN_0105881e(1,2,0x70);
    }
    else if (unaff_D7 == 2) {
      FUN_0105881e(1,2,0x66);
    }
    else if (unaff_D7 == 3) {
      FUN_0105881e(1,2,0x61);
    }
    if ((unaff_D7 == 3) ||
       ((unaff_D7 == 2 &&
        (((DAT_0103f1c7 == '\x02' || (DAT_0103f1c7 == '\x05')) || (DAT_0103f1c7 == '\b')))))) {
      return;
    }
    if ((unaff_D7 == 2) && (DAT_0103f9f5 == 'M')) {
      return;
    }
  }
  if (DAT_0103f9f6 == '\x01') {
    FUN_0105e75a(0,0x1e);
    FUN_0105881e(1,3,0x69);
    FUN_01035d3e();
    FUN_01048236(&DAT_0104c170);
    if (unaff_D7 == 1) {
      FUN_0105881e(1,3,0x70);
    }
    else if (unaff_D7 == 2) {
      FUN_0105881e(1,3,0x66);
    }
    else if (unaff_D7 == 3) {
      FUN_0105881e(1,3,0x61);
    }
    if ((unaff_D7 == 3) ||
       ((unaff_D7 == 2 &&
        (((DAT_0103f1c7 == '\x02' || (DAT_0103f1c7 == '\x05')) || (DAT_0103f1c7 == '\b')))))) {
      return;
    }
    if ((unaff_D7 == 2) && (DAT_0103f9f7 == 'M')) {
      return;
    }
  }
  return;
}


// ==== FUN_0104c382 @ 0104c382

/* WARNING: Removing unreachable block (ram,0x0104c52e) */
/* WARNING: Removing unreachable block (ram,0x0104c588) */
/* WARNING: Removing unreachable block (ram,0x0104c50a) */
/* WARNING: Removing unreachable block (ram,0x0104c5b4) */
/* WARNING: Removing unreachable block (ram,0x0104c4bc) */

void FUN_0104c382(void)

{
  int unaff_D7;
  
  if (DAT_0103f9f2 == '\x01') {
    FUN_0105881e(1,1,0x69);
    FUN_0103543c();
    FUN_01048236(&DAT_0104c380);
    if (unaff_D7 == 1) {
      FUN_0105881e(1,1,0x70);
    }
    else if (unaff_D7 == 2) {
      FUN_0105881e(1,1,0x66);
    }
    else if (unaff_D7 == 3) {
      FUN_0105881e(1,1,0x61);
    }
    if ((unaff_D7 == 3) ||
       ((unaff_D7 == 2 &&
        (((DAT_0103f1c7 == '\x02' || (DAT_0103f1c7 == '\x05')) || (DAT_0103f1c7 == '\b')))))) {
      return;
    }
    if ((unaff_D7 == 2) && (DAT_0103f9f3 == 'M')) {
      return;
    }
  }
  if (DAT_0103da02 == 8) {
    FUN_0103541e();
    if (unaff_D7 == 0) {
      FUN_0105e75a(0,0x1e);
      FUN_01035330();
    }
    FUN_0105e75a(0,0x1e);
    if (unaff_D7 == 1) {
      FUN_0103520a();
      FUN_010353e2();
      FUN_0104c172();
    }
    else {
      FUN_0103527a();
      if (unaff_D7 == 2) {
        FUN_01035400();
        FUN_0103007e();
        return;
      }
    }
    FUN_0105e75a(0,0x1e);
    if (unaff_D7 == 1) {
      FUN_0103527a();
      FUN_01035400();
      FUN_0104c172();
    }
    else {
      FUN_0103520a();
      if (unaff_D7 == 2) {
        FUN_01035400();
        FUN_0103007e();
        return;
      }
    }
    if (unaff_D7 == 1) {
      FUN_010353e2();
    }
    else {
      FUN_01035400();
    }
    FUN_0103007e();
  }
  else {
    FUN_0104bce0();
  }
  return;
}


// ==== FUN_0104c600 @ 0104c600

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0104c600(void)

{
  undefined4 uVar1;
  
  uVar1 = 1;
  FUN_01058968(1);
  DAT_0103dacc = 0;
  _DAT_0103dad0 = 0;
  _DAT_0103dad4 = 0;
  _DAT_0103dad8 = 0;
  FUN_01051890(1,"DSC-63    ",uVar1);
  if (DAT_0103fa0a == '\x01') {
    FUN_0104c698();
  }
  else if (DAT_0103fa0a == '\x02') {
    FUN_0104ca98();
  }
  else if (DAT_0103fa0a == '\x03') {
    FUN_0104cec8();
  }
  FUN_01058bc6(0);
  return;
}


// ==== FUN_0104c698 @ 0104c698

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0104c698(void)

{
  int unaff_D7;
  
  FUN_0105e75a(0,0x1e);
  FUN_0105881e(1,1,0x69);
  FUN_01037346();
  DAT_0103dacc = unaff_D7;
  FUN_01048236(&DAT_0104c690);
  if (unaff_D7 == 1) {
    FUN_0105881e(1,1,0x70);
  }
  else if (unaff_D7 == 2) {
    FUN_0105881e(1,1,0x66);
  }
  else if (unaff_D7 == 3) {
    FUN_0105881e(1,1,0x61);
  }
  if ((unaff_D7 == 3) ||
     ((unaff_D7 == 2 &&
      (((DAT_0103f1c7 == '\x02' || (DAT_0103f1c7 == '\x05')) || (DAT_0103f1c7 == '\b')))))) {
    return;
  }
  if ((unaff_D7 == 2) && (DAT_0103f9eb == 'M')) {
    return;
  }
  FUN_0105e75a(0,0x1e);
  FUN_0105881e(1,2,0x69);
  FUN_01037536();
  _DAT_0103dad0 = unaff_D7;
  FUN_01048236(&DAT_0104c692);
  if (unaff_D7 == 1) {
    FUN_0105881e(1,2,0x70);
  }
  else if (unaff_D7 == 2) {
    FUN_0105881e(1,2,0x66);
  }
  else if (unaff_D7 == 3) {
    FUN_0105881e(1,2,0x61);
  }
  if ((unaff_D7 == 3) ||
     ((unaff_D7 == 2 &&
      (((DAT_0103f1c7 == '\x02' || (DAT_0103f1c7 == '\x05')) || (DAT_0103f1c7 == '\b')))))) {
    return;
  }
  if ((unaff_D7 == 2) && (DAT_0103f9ed == 'M')) {
    return;
  }
  FUN_0105e75a(0,0x1e);
  FUN_0105881e(1,3,0x69);
  FUN_01037e1a();
  _DAT_0103dad4 = unaff_D7;
  FUN_01048236(&DAT_0104c694);
  if (unaff_D7 == 1) {
    FUN_0105881e(1,3,0x70);
  }
  else if (unaff_D7 == 2) {
    FUN_0105881e(1,3,0x66);
  }
  else if (unaff_D7 == 3) {
    FUN_0105881e(1,3,0x61);
  }
  if ((unaff_D7 == 3) ||
     ((unaff_D7 == 2 &&
      (((DAT_0103f1c7 == '\x02' || (DAT_0103f1c7 == '\x05')) || (DAT_0103f1c7 == '\b')))))) {
    return;
  }
  if ((unaff_D7 == 2) && (DAT_0103f9ef == 'M')) {
    return;
  }
  FUN_0105881e(1,4,0x69);
  FUN_01058bc6(1);
  FUN_0104d2f0();
  _DAT_0103dad8 = unaff_D7;
  FUN_01048236(&DAT_0104c696);
  if (unaff_D7 == 1) {
    FUN_0105881e(1,4,0x70);
  }
  else if (unaff_D7 == 2) {
    FUN_0105881e(1,4,0x66);
  }
  else if (unaff_D7 == 3) {
    FUN_0105881e(1,4,0x61);
  }
  if ((unaff_D7 == 3) ||
     ((unaff_D7 == 2 &&
      (((DAT_0103f1c7 == '\x02' || (DAT_0103f1c7 == '\x05')) || (DAT_0103f1c7 == '\b')))))) {
    return;
  }
  if ((unaff_D7 == 2) && (DAT_0103f9f1 == 'M')) {
    return;
  }
  return;
}


// ==== FUN_0104ca98 @ 0104ca98

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0104ca98(void)

{
  int unaff_D7;
  
  if (DAT_0103f9eb == 'A') {
    FUN_0105e75a(0,0x1e);
    FUN_0105881e(1,1,0x69);
    FUN_01037346();
    DAT_0103dacc = unaff_D7;
    FUN_01048236(&DAT_0104ca90);
    if (unaff_D7 == 1) {
      FUN_0105881e(1,1,0x70);
    }
    else if (unaff_D7 == 2) {
      FUN_0105881e(1,1,0x66);
    }
    else if (unaff_D7 == 3) {
      FUN_0105881e(1,1,0x61);
    }
    if ((unaff_D7 == 3) ||
       ((unaff_D7 == 2 &&
        (((DAT_0103f1c7 == '\x02' || (DAT_0103f1c7 == '\x05')) || (DAT_0103f1c7 == '\b')))))) {
      return;
    }
    if ((unaff_D7 == 2) && (DAT_0103f9eb == 'M')) {
      return;
    }
  }
  if (DAT_0103f9ed == 'A') {
    FUN_0105e75a(0,0x1e);
    FUN_0105881e(1,2,0x69);
    FUN_01037536();
    _DAT_0103dad0 = unaff_D7;
    FUN_01048236(&DAT_0104ca92);
    if (unaff_D7 == 1) {
      FUN_0105881e(1,2,0x70);
    }
    else if (unaff_D7 == 2) {
      FUN_0105881e(1,2,0x66);
    }
    else if (unaff_D7 == 3) {
      FUN_0105881e(1,2,0x61);
    }
    if ((unaff_D7 == 3) ||
       ((unaff_D7 == 2 &&
        (((DAT_0103f1c7 == '\x02' || (DAT_0103f1c7 == '\x05')) || (DAT_0103f1c7 == '\b')))))) {
      return;
    }
    if ((unaff_D7 == 2) && (DAT_0103f9ed == 'M')) {
      return;
    }
  }
  if (DAT_0103f9ef == 'A') {
    FUN_0105e75a(0,0x1e);
    FUN_0105881e(1,3,0x69);
    FUN_01037e1a();
    _DAT_0103dad4 = unaff_D7;
    FUN_01048236(&DAT_0104ca94);
    if (unaff_D7 == 1) {
      FUN_0105881e(1,3,0x70);
    }
    else if (unaff_D7 == 2) {
      FUN_0105881e(1,3,0x66);
    }
    else if (unaff_D7 == 3) {
      FUN_0105881e(1,3,0x61);
    }
    if ((unaff_D7 == 3) ||
       ((unaff_D7 == 2 &&
        (((DAT_0103f1c7 == '\x02' || (DAT_0103f1c7 == '\x05')) || (DAT_0103f1c7 == '\b')))))) {
      return;
    }
    if ((unaff_D7 == 2) && (DAT_0103f9ef == 'M')) {
      return;
    }
  }
  if (DAT_0103f9f1 == 'A') {
    FUN_0105881e(1,4,0x69);
    FUN_01058bc6(1);
    FUN_0104d2f0();
    _DAT_0103dad8 = unaff_D7;
    FUN_01048236(&DAT_0104ca96);
    if (unaff_D7 == 1) {
      FUN_0105881e(1,4,0x70);
    }
    else if (unaff_D7 == 2) {
      FUN_0105881e(1,4,0x66);
    }
    else if (unaff_D7 == 3) {
      FUN_0105881e(1,4,0x61);
    }
    if ((unaff_D7 == 3) ||
       ((unaff_D7 == 2 &&
        (((DAT_0103f1c7 == '\x02' || (DAT_0103f1c7 == '\x05')) || (DAT_0103f1c7 == '\b')))))) {
      return;
    }
    if ((unaff_D7 == 2) && (DAT_0103f9f1 == 'M')) {
      return;
    }
  }
  return;
}


// ==== FUN_0104cec8 @ 0104cec8

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_0104cec8(void)

{
  int unaff_D7;
  
  if (DAT_0103f9ea == '\x01') {
    FUN_0105e75a(0,0x1e);
    FUN_0105881e(1,1,0x69);
    FUN_01037346();
    _DAT_0103dad8 = unaff_D7;
    FUN_01048236(&DAT_0104cec0);
    if (unaff_D7 == 1) {
      FUN_0105881e(1,1,0x70);
    }
    else if (unaff_D7 == 2) {
      FUN_0105881e(1,1,0x66);
    }
    else if (unaff_D7 == 3) {
      FUN_0105881e(1,1,0x61);
    }
    if ((unaff_D7 == 3) ||
       ((unaff_D7 == 2 &&
        (((DAT_0103f1c7 == '\x02' || (DAT_0103f1c7 == '\x05')) || (DAT_0103f1c7 == '\b')))))) {
      return;
    }
    if ((unaff_D7 == 2) && (DAT_0103f9eb == 'M')) {
      return;
    }
  }
  if (DAT_0103f9ec == '\x01') {
    FUN_0105e75a(0,0x1e);
    FUN_0105881e(1,2,0x69);
    FUN_01037536();
    _DAT_0103dad8 = unaff_D7;
    FUN_01048236(&DAT_0104cec2);
    if (unaff_D7 == 1) {
      FUN_0105881e(1,2,0x70);
    }
    else if (unaff_D7 == 2) {
      FUN_0105881e(1,2,0x66);
    }
    else if (unaff_D7 == 3) {
      FUN_0105881e(1,2,0x61);
    }
    if ((unaff_D7 == 3) ||
       ((unaff_D7 == 2 &&
        (((DAT_0103f1c7 == '\x02' || (DAT_0103f1c7 == '\x05')) || (DAT_0103f1c7 == '\b')))))) {
      return;
    }
    if ((unaff_D7 == 2) && (DAT_0103f9ed == 'M')) {
      return;
    }
  }
  if (DAT_0103f9ee == '\x01') {
    FUN_0105e75a(0,0x1e);
    FUN_0105881e(1,3,0x69);
    FUN_01037e1a();
    _DAT_0103dad8 = unaff_D7;
    FUN_01048236(&DAT_0104cec4);
    if (unaff_D7 == 1) {
      FUN_0105881e(1,3,0x70);
    }
    else if (unaff_D7 == 2) {
      FUN_0105881e(1,3,0x66);
    }
    else if (unaff_D7 == 3) {
      FUN_0105881e(1,3,0x61);
    }
    if ((unaff_D7 == 3) ||
       ((unaff_D7 == 2 &&
        (((DAT_0103f1c7 == '\x02' || (DAT_0103f1c7 == '\x05')) || (DAT_0103f1c7 == '\b')))))) {
      return;
    }
    if ((unaff_D7 == 2) && (DAT_0103f9ef == 'M')) {
      return;
    }
  }
  if (DAT_0103f9f0 == '\x01') {
    FUN_0105881e(1,4,0x69);
    FUN_01058bc6(1);
    FUN_0104d2f0();
    _DAT_0103dad8 = unaff_D7;
    FUN_01048236(&DAT_0104cec6);
    if (unaff_D7 == 1) {
      FUN_0105881e(1,4,0x70);
    }
    else if (unaff_D7 == 2) {
      FUN_0105881e(1,4,0x66);
    }
    else if (unaff_D7 == 3) {
      FUN_0105881e(1,4,0x61);
    }
    if ((unaff_D7 == 3) ||
       ((unaff_D7 == 2 &&
        (((DAT_0103f1c7 == '\x02' || (DAT_0103f1c7 == '\x05')) || (DAT_0103f1c7 == '\b')))))) {
      return;
    }
    if ((unaff_D7 == 2) && (DAT_0103f9f1 == 'M')) {
      return;
    }
  }
  return;
}


// ==== FUN_0104d2f0 @ 0104d2f0

char * FUN_0104d2f0(void)

{
  int unaff_D7;
  
  FUN_01048236();
  FUN_0104d406();
  if ((((unaff_D7 == 2) || (FUN_0104d46c(), unaff_D7 == 2)) || (FUN_0104d9c4(), unaff_D7 == 2)) ||
     ((FUN_0104dc04(), unaff_D7 == 2 || (FUN_0104deaa(), unaff_D7 == 2)))) {
    return "DSC-63 : Video Display - No Auto Checked.";
  }
  FUN_0104e942();
  if ((unaff_D7 != 2) && ((FUN_0104f7b0(), unaff_D7 != 2 && (FUN_0104fa20(), unaff_D7 != 2)))) {
    FUN_01050290();
  }
  return "DSC-63 : Video Display - No Auto Checked.";
}


// ==== FUN_0104d406 @ 0104d406

void FUN_0104d406(void)

{
  short unaff_D7w;
  
  FUN_0105a03a(1);
  if (DAT_0103fa3d == 'c') {
    FUN_0105a074(1,"Color");
  }
  else {
    FUN_0105a074(1,"Monochrome");
  }
  do {
    FUN_0104e8ba();
    if (unaff_D7w == 10) {
      return;
    }
  } while (unaff_D7w != 0x20);
  return;
}


// ==== FUN_0104d46c @ 0104d46c

/* WARNING: Removing unreachable block (ram,0x0104d5c4) */
/* WARNING: Removing unreachable block (ram,0x0104d5d6) */
/* WARNING: Removing unreachable block (ram,0x0104d5de) */
/* WARNING: Removing unreachable block (ram,0x0104d5e6) */
/* WARNING: Removing unreachable block (ram,0x0104d5be) */
/* WARNING: Removing unreachable block (ram,0x0104d5ec) */
/* WARNING: Removing unreachable block (ram,0x0104d5f4) */
/* WARNING: Removing unreachable block (ram,0x0104d5b8) */
/* WARNING: Removing unreachable block (ram,0x0104d5fc) */

void FUN_0104d46c(void)

{
  int unaff_D7;
  short local_e;
  char local_9;
  
  FUN_0105e75a(0,0x1e);
  FUN_0105dc90(0,0x1e,0x4f,0x31,0);
  for (local_9 = '\x1e'; local_9 < '2'; local_9 = local_9 + '\x01') {
    unaff_D7 = (int)local_9;
    FUN_0105d68e(0,unaff_D7,0x4f,(int)local_9,8,0);
  }
  FUN_0105a0b2(1);
  FUN_0104d658(0x73);
  FUN_0104d6d6();
  FUN_0104e8ba();
  local_e = (short)unaff_D7;
  if ((local_e != 0x20) && (local_e != 10)) {
    local_e = -1;
  }
  if (local_e == -1) {
    if (DAT_0103fa3d != 'm') {
      FUN_010302b2(0,0);
      FUN_010302b2(1,1);
      do {
      } while (DAT_0103da6e == 0);
      FUN_0104d8ec(0x3f);
      FUN_0104d946(0x3f);
      do {
                    /* WARNING: Do nothing block with infinite loop */
      } while( true );
    }
    FUN_0104d87e();
  }
  for (local_9 = '\"'; local_9 < '2'; local_9 = local_9 + '\x01') {
    FUN_0105d68e(0,(int)local_9,0x4f,(int)local_9,0,0);
  }
  FUN_0104d658(0x72);
  return;
}


// ==== FUN_0104d658 @ 0104d658

void FUN_0104d658(char param_1)

{
  undefined4 unaff_D7;
  
  if (param_1 == 's') {
    FUN_010456d4(0x180);
    DAT_0104d654 = unaff_D7;
    FUN_0105eedc();
  }
  else if (param_1 == 'r') {
    FUN_0105eedc(0xd01c800,DAT_0104d654,0x180);
    FUN_01045712(DAT_0104d654);
  }
  return;
}


// ==== FUN_0104d6d6 @ 0104d6d6

uint FUN_0104d6d6(void)

{
  uint in_D0;
  uint uVar1;
  byte local_b;
  byte local_a;
  byte local_9;
  
  local_b = 0x3f;
  for (local_9 = 0; local_9 < 0x10; local_9 = local_9 + 1) {
    for (local_a = 0; local_a < 4; local_a = local_a + 1) {
      FUN_0105a3c0(local_9,local_a,0,local_b);
      FUN_0105a3c0(local_9,local_a,1,local_b);
      in_D0 = (uint)local_b;
      FUN_0105a3c0(local_9,local_a,2);
      local_b = local_b - 1;
    }
  }
  for (uVar1 = 0; uVar1 < 0x10; uVar1 = uVar1 + 1) {
    FUN_0105d68e(0,uVar1 + 0x22,0x4f,uVar1 + 0x22,uVar1,4);
    for (local_a = 0; local_a < 0x14; local_a = local_a + 1) {
      in_D0 = 0;
      FUN_0105a7c6(local_a,uVar1 + 0x22);
    }
    for (local_a = 0x14; local_a < 0x28; local_a = local_a + 1) {
      FUN_0105a7c6(local_a,uVar1 + 0x22,0x10);
    }
    for (local_a = 0x28; local_a < 0x3c; local_a = local_a + 1) {
      FUN_0105a7c6(local_a,uVar1 + 0x22,8);
    }
    for (local_a = 0x3c; local_a < 0x50; local_a = local_a + 1) {
      FUN_0105a7c6(local_a,uVar1 + 0x22,0x18);
    }
  }
  return in_D0;
}


// ==== FUN_0104d87e @ 0104d87e

void FUN_0104d87e(void)

{
  short unaff_D7w;
  undefined4 uVar1;
  
  uVar1 = 1;
  FUN_01030352(0,0,1);
  FUN_01030352(1,400);
  do {
    if (DAT_0103da5a == 1) goto LAB_0104d8d8;
    FUN_0104e8ba();
    if (unaff_D7w == 10) {
      uVar1 = 1;
      goto LAB_0104d8d8;
    }
  } while (unaff_D7w != 0x20);
  uVar1 = 2;
LAB_0104d8d8:
  FUN_01030352(0,0,uVar1);
  return;
}


// ==== FUN_0104d8ec @ 0104d8ec

void FUN_0104d8ec(byte param_1)

{
  char local_6;
  char local_5;
  
  for (local_5 = '\0'; local_5 < '\x10'; local_5 = local_5 + '\x01') {
    for (local_6 = '\0'; local_6 < '\x04'; local_6 = local_6 + '\x01') {
      FUN_0105a3c0((int)local_5,(int)local_6,0,(int)(char)param_1);
      param_1 = param_1 - 1 & 0x3f;
    }
  }
  return;
}


// ==== FUN_0104d946 @ 0104d946

void FUN_0104d946(byte param_1)

{
  char local_6;
  char local_5;
  
  for (local_5 = '\0'; local_5 < '\x10'; local_5 = local_5 + '\x01') {
    for (local_6 = '\0'; local_6 < '\x04'; local_6 = local_6 + '\x01') {
      FUN_0105a3c0((int)local_5,(int)local_6,1,(int)(char)param_1);
      param_1 = param_1 - 1 & 0x3f;
    }
  }
  return;
}


// ==== FUN_0104d9c4 @ 0104d9c4

void FUN_0104d9c4(void)

{
  uint unaff_D7;
  short sVar1;
  undefined4 uVar2;
  char cVar3;
  undefined4 uVar4;
  
  uVar4 = 1;
  FUN_0105e75a(0,0x1e);
  uVar2 = 0;
  FUN_0105dc90(0,0x1e,0x4f,0x31,0);
  for (cVar3 = '\x1e'; cVar3 < '2'; cVar3 = cVar3 + '\x01') {
    uVar2 = 0;
    unaff_D7 = (uint)cVar3;
    FUN_0105d68e(0,unaff_D7,0x4f,(int)cVar3,8);
  }
  FUN_0105a178(1,uVar2,cVar3,uVar4);
  for (cVar3 = '\0'; cVar3 < ' '; cVar3 = cVar3 + '\x01') {
    FUN_0105d68e(cVar3 + 8,0x21,cVar3 + 8,0x21,7,(int)cVar3);
    FUN_0105d68e(cVar3 + 0x28,0x21,cVar3 + 0x28,0x21,7,(int)cVar3);
    FUN_0105d68e(cVar3 + 8,0x22,cVar3 + 8,0x22,7,(int)cVar3);
    unaff_D7 = (int)cVar3 + 0x28;
    FUN_0105d68e(unaff_D7,0x22,cVar3 + 0x28,0x22,7,(int)cVar3);
  }
  FUN_0105d3d2(8,0x21,"                                ",7,0);
  FUN_0105d3d2(0x28,0x21,"                                ",7,0x10);
  FUN_0105d3d2(8,0x22,"                                ",7,8);
  FUN_0105d3d2(0x28,0x22,"                                ",7,0x18);
  FUN_01030352(0,0);
  FUN_01030352(1,400);
  do {
    if (DAT_0103da5a != 0) goto LAB_0104dbf0;
    FUN_0104e8ba();
    sVar1 = (short)unaff_D7;
    if (sVar1 == 10) {
      uVar4 = 1;
      goto LAB_0104dbf0;
    }
    unaff_D7 = unaff_D7 & 0xffff;
  } while (sVar1 != 0x20);
  uVar4 = 2;
LAB_0104dbf0:
  FUN_01030352(0,0,cVar3,uVar4);
  return;
}


// ==== FUN_0104dc04 @ 0104dc04

undefined4 FUN_0104dc04(void)

{
  ushort uVar1;
  uint uVar2;
  uint uVar3;
  ushort unaff_D7w;
  undefined4 uVar4;
  char local_b;
  ushort local_a;
  
  local_a = 0;
  for (uVar2 = 1; uVar2 < 0x1d; uVar2 = uVar2 + 1) {
    FUN_0105d68e(0,uVar2,0x4f,uVar2,0);
    FUN_0105e89e(uVar2);
  }
  FUN_0105dc90(0,1,0x4f,0x1c,0);
  FUN_0105a752(0);
  FUN_0105a9c0();
  FUN_0105a8c4(1,0,0x1d);
  FUN_0105a9c0();
  for (uVar2 = 1; uVar2 < 0x1c; uVar2 = uVar2 + 1) {
    for (uVar3 = 2; uVar3 < 0x4e; uVar3 = uVar3 + 1) {
      if (((((uVar3 != 2) || (uVar2 != 1)) && ((uVar3 != 0x4d || (uVar2 != 1)))) &&
          ((uVar3 != 2 || (uVar2 != 0x1b)))) && ((uVar3 != 0x4d || (uVar2 != 0x1b)))) {
        FUN_0105d53c(uVar3,uVar2,local_a,7,0);
        unaff_D7w = local_a + 1;
        local_a = unaff_D7w;
        if (0x7ff < unaff_D7w) {
          local_a = 0;
        }
      }
    }
  }
  FUN_01030352(0,0);
  FUN_010302b2(0,0);
  FUN_01030352(1,400);
  FUN_010302b2(1,1);
  uVar1 = 1;
  while( true ) {
    while (FUN_0104e8ba(), unaff_D7w != 0xffff) {
      if ((unaff_D7w == 10) || (unaff_D7w == 0x20)) goto LAB_0104dd8e;
    }
    if (DAT_0103da5a == 1) break;
    if (DAT_0103da6e != 0) {
      if ((uVar1 & 3) == 0) {
        local_b = '\0';
      }
      else if ((uVar1 & 3) == 1) {
        local_b = '\x10';
      }
      else if ((uVar1 & 3) == 2) {
        local_b = '\b';
      }
      else {
        local_b = '\x18';
      }
      unaff_D7w = uVar1 & 3;
      for (uVar2 = 1; uVar2 < 0x1c; uVar2 = uVar2 + 1) {
        for (uVar3 = 2; uVar3 < 0x4e; uVar3 = uVar3 + 1) {
          if ((((uVar3 != 2) || (uVar2 != 1)) && ((uVar3 != 0x4d || (uVar2 != 1)))) &&
             (((uVar3 != 2 || (uVar2 != 0x1b)) && ((uVar3 != 0x4d || (uVar2 != 0x1b)))))) {
            unaff_D7w = (ushort)local_b;
            FUN_0105a7c6(uVar3,uVar2,unaff_D7w);
          }
        }
      }
      uVar1 = uVar1 + 1;
      DAT_0103da6e = 0;
    }
  }
LAB_0104dd8e:
  FUN_01030352(0,0);
  uVar4 = 0;
  FUN_010302b2(0);
  FUN_0104f498();
  FUN_01058bc6(1);
  FUN_0105a752(1);
  FUN_0105a9c0();
  return uVar4;
}


// ==== FUN_0104deaa @ 0104deaa

uint FUN_0104deaa(void)

{
  byte bVar1;
  byte bVar2;
  uint in_D0;
  uint uVar3;
  uint unaff_D7;
  uint local_18;
  undefined1 uStack_10;
  undefined1 local_f;
  undefined1 local_e;
  undefined1 local_d;
  ushort local_c;
  byte local_9;
  undefined4 local_8;
  
  local_8 = 1;
  FUN_0105a1b8(1);
  uVar3 = 0;
  local_9 = 0xf;
  local_18 = in_D0;
  do {
    if (0xf < uVar3) {
LAB_0104dffc:
      local_e = 0x20;
      local_d = 0;
      local_f = 8;
      FUN_0105a930(0,0,&local_e,&uStack_10);
      FUN_0105a9c0();
      return local_18;
    }
    FUN_0104e8ba();
    bVar1 = local_9;
    local_c = (ushort)unaff_D7;
    if (local_c == 10) {
      local_8 = 1;
      goto LAB_0104dffc;
    }
    if (local_c == 0x20) {
      local_8 = 2;
      goto LAB_0104dffc;
    }
    local_18 = (uint)local_9;
    FUN_0104e034(uVar3);
    bVar2 = local_9;
    local_c = (ushort)bVar1;
    if (local_c == 10) {
      local_8 = 1;
      goto LAB_0104dffc;
    }
    if (local_c == 0x20) {
      local_8 = 2;
      goto LAB_0104dffc;
    }
    local_18 = (uint)local_9;
    FUN_0104e1d4(uVar3);
    bVar1 = local_9;
    local_c = (ushort)bVar2;
    if (local_c == 10) {
      local_8 = 1;
      goto LAB_0104dffc;
    }
    if (local_c == 0x20) {
      local_8 = 2;
      goto LAB_0104dffc;
    }
    local_18 = (uint)local_9;
    FUN_0104e40c(uVar3);
    bVar2 = local_9;
    local_c = (ushort)bVar1;
    if (local_c == 10) {
      local_8 = 1;
      goto LAB_0104dffc;
    }
    if (local_c == 0x20) {
      local_8 = 2;
      goto LAB_0104dffc;
    }
    unaff_D7 = (uint)local_9;
    FUN_0104e650(uVar3);
    local_c = (ushort)bVar2;
    local_18 = unaff_D7;
    if (local_c == 10) {
      local_8 = 1;
      goto LAB_0104dffc;
    }
    if (local_c == 0x20) {
      local_8 = 2;
      goto LAB_0104dffc;
    }
    FUN_0105e89e(uVar3 + 0x22);
    uVar3 = uVar3 + 1;
    local_9 = local_9 - 1;
  } while( true );
}


// ==== FUN_0104e034 @ 0104e034

void FUN_0104e034(int param_1,undefined1 param_2)

{
  uint uVar1;
  short unaff_D7w;
  undefined1 uStack_12;
  undefined1 local_11;
  char local_10 [4];
  uint local_c;
  undefined4 local_8;
  
  local_8 = 1;
  local_10[2] = -1;
  local_10[3] = -1;
  local_11 = param_2;
  local_10[0] = '\0';
  local_10[1] = 8;
  for (uVar1 = 0; uVar1 < 9; uVar1 = uVar1 + 1) {
    FUN_0105a930(uVar1,param_1 + 0x22,local_10,&uStack_12);
    FUN_0105a9c0();
    for (local_c = 0; local_c < 25000; local_c = local_c + 1) {
    }
    local_10[0] = local_10[0] + '\x01';
  }
  FUN_0104e8ba();
  if ((unaff_D7w == 10) || (unaff_D7w == 0x20)) {
    return;
  }
  local_10[0] = '\b';
  FUN_0105a930(9,param_1 + 0x22,local_10,&uStack_12);
  FUN_0105a9c0();
  for (local_c = 0; local_c < 25000; local_c = local_c + 1) {
  }
  FUN_0105a930(10,param_1 + 0x22,local_10,&uStack_12);
  FUN_0105a9c0();
  for (local_c = 0; local_c < 25000; local_c = local_c + 1) {
  }
  FUN_0104e8ba();
  if ((unaff_D7w != 10) && (unaff_D7w != 0x20)) {
    for (uVar1 = 0xb; uVar1 < 0x14; uVar1 = uVar1 + 1) {
      FUN_0105a930(uVar1,param_1 + 0x22,local_10,&uStack_12);
      FUN_0105a9c0();
      for (local_c = 0; local_c < 25000; local_c = local_c + 1) {
      }
      local_10[0] = local_10[0] + -1;
    }
    FUN_0104e8ba();
  }
  return;
}


// ==== FUN_0104e1d4 @ 0104e1d4

void FUN_0104e1d4(int param_1,undefined1 param_2)

{
  uint uVar1;
  short unaff_D7w;
  undefined1 uStack_12;
  undefined1 local_11;
  char local_10;
  char local_f;
  undefined2 local_e;
  uint local_c;
  undefined4 local_8;
  
  local_8 = 1;
  local_e = 0xffff;
  local_11 = param_2;
  local_10 = 'G';
  local_f = '\b';
  for (uVar1 = 0x14; uVar1 < 0x1c; uVar1 = uVar1 + 1) {
    FUN_0105a930(uVar1,param_1 + 0x22,&local_10,&uStack_12);
    FUN_0105a9c0();
    for (local_c = 0; local_c < 35000; local_c = local_c + 1) {
    }
    local_10 = local_10 + -1;
    local_f = local_f + -1;
  }
  FUN_0104e8ba();
  if ((unaff_D7w == 10) || (unaff_D7w == 0x20)) {
    return;
  }
  local_10 = '@';
  local_f = 1;
  FUN_0105a930(0x1c,param_1 + 0x22,&local_10,&uStack_12);
  FUN_0105a9c0();
  for (local_c = 0; local_c < 35000; local_c = local_c + 1) {
  }
  local_f = 2;
  FUN_0105a930(0x1d,param_1 + 0x22,&local_10,&uStack_12);
  FUN_0105a9c0();
  for (local_c = 0; local_c < 35000; local_c = local_c + 1) {
  }
  FUN_0105a930(0x1e,param_1 + 0x22,&local_10,&uStack_12);
  FUN_0105a9c0();
  for (local_c = 0; local_c < 35000; local_c = local_c + 1) {
  }
  local_f = '\x01';
  FUN_0105a930(0x1f,param_1 + 0x22,&local_10,&uStack_12);
  FUN_0105a9c0();
  for (local_c = 0; local_c < 35000; local_c = local_c + 1) {
  }
  FUN_0104e8ba();
  if ((unaff_D7w == 10) || (unaff_D7w == 0x20)) {
    return;
  }
  for (uVar1 = 0x20; uVar1 < 0x28; uVar1 = uVar1 + 1) {
    FUN_0105a930(uVar1,param_1 + 0x22,&local_10,&uStack_12);
    FUN_0105a9c0();
    for (local_c = 0; local_c < 35000; local_c = local_c + 1) {
    }
    local_10 = local_10 + '\x01';
    local_f = local_f + '\x01';
  }
  FUN_0104e8ba();
  return;
}


// ==== FUN_0104e40c @ 0104e40c

void FUN_0104e40c(int param_1,undefined1 param_2)

{
  uint uVar1;
  short unaff_D7w;
  undefined1 uStack_12;
  undefined1 local_11;
  char local_10;
  char local_f;
  undefined2 local_e;
  uint local_c;
  undefined4 local_8;
  
  local_8 = 1;
  local_e = 0xffff;
  local_11 = param_2;
  local_10 = '`';
  local_f = '\x01';
  for (uVar1 = 0x28; uVar1 < 0x30; uVar1 = uVar1 + 1) {
    FUN_0105a930(uVar1,param_1 + 0x22,&local_10,&uStack_12);
    FUN_0105a9c0();
    for (local_c = 0; local_c < 45000; local_c = local_c + 1) {
    }
    local_10 = local_10 + '\x01';
    local_f = local_f + '\x01';
  }
  FUN_0104e8ba();
  if ((unaff_D7w == 10) || (unaff_D7w == 0x20)) {
    return;
  }
  local_10 = 'g';
  local_f = '\b';
  FUN_0105a930(0x30,param_1 + 0x22,&local_10,&uStack_12);
  FUN_0105a9c0();
  for (local_c = 0; local_c < 45000; local_c = local_c + 1) {
  }
  local_10 = 'f';
  FUN_0105a930(0x31,param_1 + 0x22,&local_10,&uStack_12);
  FUN_0105a9c0();
  for (local_c = 0; local_c < 45000; local_c = local_c + 1) {
  }
  FUN_0105a930(0x32,param_1 + 0x22,&local_10,&uStack_12);
  FUN_0105a9c0();
  for (local_c = 0; local_c < 45000; local_c = local_c + 1) {
  }
  local_10 = 'g';
  FUN_0105a930(0x33,param_1 + 0x22,&local_10,&uStack_12);
  FUN_0105a9c0();
  for (local_c = 0; local_c < 45000; local_c = local_c + 1) {
  }
  FUN_0104e8ba();
  if ((unaff_D7w == 10) || (unaff_D7w == 0x20)) {
    return;
  }
  for (uVar1 = 0x34; uVar1 < 0x3c; uVar1 = uVar1 + 1) {
    FUN_0105a930(uVar1,param_1 + 0x22,&local_10,&uStack_12);
    FUN_0105a9c0();
    for (local_c = 0; local_c < 45000; local_c = local_c + 1) {
    }
    local_10 = local_10 + -1;
    local_f = local_f + -1;
  }
  FUN_0104e8ba();
  return;
}


// ==== FUN_0104e650 @ 0104e650

undefined4 FUN_0104e650(int param_1,byte param_2)

{
  undefined4 in_D0;
  uint uVar1;
  ushort unaff_D7w;
  undefined4 uVar2;
  undefined1 uStack_12;
  undefined1 local_11;
  undefined1 local_10;
  char local_f;
  ushort local_e;
  uint local_c;
  undefined4 local_8;
  
  local_8 = 1;
  local_e = 0xffff;
  local_10 = 0;
  local_f = '\b';
  local_11 = 0x10;
  for (uVar1 = 0x3c; uVar1 < 0x45; uVar1 = uVar1 + 1) {
    FUN_0105a930(uVar1,param_1 + 0x22,&local_10,&uStack_12);
    FUN_0105a9c0();
    FUN_0105e89e(param_1 + 0x22);
    in_D0 = 0;
    unaff_D7w = (ushort)param_2;
    FUN_0105d53c(uVar1,param_1 + 0x22,0xb2,unaff_D7w);
    for (local_c = 0; local_c < 30000; local_c = local_c + 1) {
    }
    local_f = local_f + -1;
  }
  FUN_0104e8ba();
  if ((unaff_D7w == 10) || (unaff_D7w == 0x20)) {
    return in_D0;
  }
  local_10 = 0;
  local_f = '\0';
  local_e = unaff_D7w;
  FUN_0105a930(0x45,param_1 + 0x22,&local_10,&uStack_12);
  FUN_0105a9c0();
  FUN_0105e89e(param_1 + 0x22);
  FUN_0105d53c(0x45,param_1 + 0x22,0xb2,param_2,0);
  for (local_c = 0; local_c < 30000; local_c = local_c + 1) {
  }
  FUN_0105a930(0x46,param_1 + 0x22,&local_10,&uStack_12);
  FUN_0105a9c0();
  FUN_0105e89e(param_1 + 0x22);
  uVar2 = 0;
  FUN_0105d53c(0x46,param_1 + 0x22,0xb2,param_2);
  for (local_c = 0; local_c < 30000; local_c = local_c + 1) {
  }
  FUN_0104e8ba();
  local_e = (ushort)param_2;
  if ((local_e == 10) || (local_e == 0x20)) {
    return uVar2;
  }
  for (uVar1 = 0x47; uVar1 < 0x50; uVar1 = uVar1 + 1) {
    FUN_0105a930(uVar1,param_1 + 0x22,&local_10,&uStack_12);
    FUN_0105a9c0();
    FUN_0105e89e(param_1 + 0x22);
    uVar2 = 0;
    FUN_0105d53c(uVar1,param_1 + 0x22,0xb2,param_2);
    for (local_c = 0; local_c < 30000; local_c = local_c + 1) {
    }
    local_f = local_f + '\x01';
  }
  FUN_0104e8ba();
  return uVar2;
}


// ==== FUN_0104e8ba @ 0104e8ba

void FUN_0104e8ba(void)

{
  short unaff_D7w;
  
  while( true ) {
    FUN_0103fffc();
    if (unaff_D7w == -1) {
      return;
    }
    if (unaff_D7w == 0x20) break;
    if (unaff_D7w == 10) {
      return;
    }
  }
  return;
}


// ==== FUN_0104e942 @ 0104e942

void FUN_0104e942(void)

{
  short unaff_D7w;
  undefined4 uVar1;
  
  uVar1 = 1;
  FUN_0104ea48();
  do {
    FUN_0103fffc();
  } while (unaff_D7w == -1);
  FUN_0105ef12(uVar1);
  return;
}


// ==== FUN_0104ea48 @ 0104ea48

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

uint FUN_0104ea48(void)

{
  uint uVar1;
  uint uVar2;
  uint uVar3;
  byte local_6;
  byte local_5;
  
  uVar3 = 0;
  FUN_0105a752();
  FUN_0105a9c0();
  for (uVar1 = 0; uVar1 < 0xcc; uVar1 = uVar1 + 1) {
    FUN_0105e89e(uVar1);
    uVar3 = 0;
    FUN_0105d68e(0,uVar1,0x4f,uVar1,8);
  }
  local_5 = 0;
  for (uVar1 = 0; uVar1 < 0xcc; uVar1 = uVar1 + 1) {
    local_6 = local_5;
    for (uVar2 = 0; uVar2 < 0x50; uVar2 = uVar2 + 1) {
      uVar3 = (uint)local_6;
      FUN_0105dc90(uVar2,uVar1,uVar2,uVar1);
      local_6 = local_6 + 1 & 0xf;
    }
    local_5 = local_5 + 1 & 0xf;
  }
  FUN_0105a8c4(1,0,7);
  FUN_0105a8c4(2,7,7);
  FUN_0105a8c4(3,0xe,7);
  FUN_0105a8c4(4,0x15,8);
  _DAT_0103f98c = 0;
  DAT_0103f98e = 7;
  DAT_0103f990 = 0;
  _DAT_0103f992 = 7;
  DAT_0103f994 = 7;
  DAT_0103f996 = 7;
  _DAT_0103f998 = 0xe;
  _DAT_0103f99a = 7;
  _DAT_0103f99c = 0xe;
  _DAT_0103f99e = 0x15;
  _DAT_0103f9a0 = 8;
  _DAT_0103f9a2 = 0x15;
  DAT_0103f986 = 0xe;
  DAT_0103f988 = 3;
  DAT_0103f98a = 0xe;
  FUN_0104f61e();
  FUN_0104f730();
  FUN_0105a9c0();
  return uVar3;
}


// ==== FUN_0104f498 @ 0104f498

void FUN_0104f498(void)

{
  FUN_0105e8ea();
  FUN_01051742(1);
  FUN_01051890(1,"DSC-63    ");
  FUN_01055fd6(1);
  FUN_01056298(1);
  FUN_01056324(1);
  if (DAT_0103fa0a == '\x03') {
    FUN_010561fe(1);
  }
  FUN_0105ef12();
  return;
}


// ==== FUN_0104f61e @ 0104f61e

undefined4 FUN_0104f61e(void)

{
  short sVar1;
  undefined4 in_D0;
  uint uVar2;
  int iVar3;
  uint uVar4;
  undefined1 auStack_c [8];
  
  for (uVar2 = 0; uVar2 < 4; uVar2 = uVar2 + 1) {
    iVar3 = (int)(short)(&DAT_0103f990)[uVar2 * 3];
    sVar1 = (&DAT_0103f98e)[uVar2 * 3];
    for (uVar4 = 0; uVar4 < (uint)(int)sVar1; uVar4 = uVar4 + 1) {
      FUN_0105d68e(0,uVar4 + iVar3,0x4f,uVar4 + iVar3,8,0);
      in_D0 = 0;
      FUN_0105d3d2(0,uVar4 + iVar3,"       ",7);
    }
  }
  for (uVar2 = 0; uVar2 < 4; uVar2 = uVar2 + 1) {
    iVar3 = (int)(short)(&DAT_0103f990)[uVar2 * 3];
    FUN_0105d68e(0,iVar3,0x4f,iVar3,3,0x19);
    FUN_0105ee14(0,iVar3 * 0x140 + 0xd000000,7,auStack_c);
    FUN_0105d3d2(0,iVar3,auStack_c,2,1);
  }
  return in_D0;
}


// ==== FUN_0104f730 @ 0104f730

void FUN_0104f730(void)

{
  undefined1 auStack_c [4];
  undefined1 uStack_8;
  undefined1 local_7;
  undefined1 local_6;
  undefined1 local_5;
  
  local_6 = 0x60;
  local_5 = 8;
  local_7 = 7;
  FUN_0105a930(0x28,(int)DAT_0103f98a,&local_6,&uStack_8);
  FUN_0105ec54(0,(int)DAT_0103f986,3,auStack_c);
  FUN_0105d3d2(0x2a,(int)DAT_0103f98a,auStack_c,7,0x10);
  return;
}


// ==== FUN_0104f7b0 @ 0104f7b0

undefined4 FUN_0104f7b0(void)

{
  ushort uVar1;
  uint uVar2;
  uint uVar3;
  ushort unaff_D7w;
  undefined4 uVar4;
  char local_b;
  ushort local_a;
  
  local_a = 0;
  FUN_0105a8fa(1,0,0x1d);
  FUN_0105a752(0);
  FUN_0105a9c0();
  FUN_0105ea86(0,0);
  FUN_0105e654(0,0,0x4f,0x1c,0);
  for (uVar2 = 1; uVar2 < 0x1c; uVar2 = uVar2 + 1) {
    for (uVar3 = 2; uVar3 < 0x4e; uVar3 = uVar3 + 1) {
      if (((((uVar3 != 2) || (uVar2 != 1)) && ((uVar3 != 0x4d || (uVar2 != 1)))) &&
          ((uVar3 != 2 || (uVar2 != 0x1b)))) && ((uVar3 != 0x4d || (uVar2 != 0x1b)))) {
        FUN_0105df3e(uVar3,uVar2,local_a,7,0);
        unaff_D7w = local_a + 1;
        local_a = unaff_D7w;
        if (0x7ff < unaff_D7w) {
          local_a = 0;
        }
      }
    }
  }
  FUN_0105a752(1);
  FUN_0105a9c0();
  FUN_01030352(0,0);
  FUN_010302b2(0,0);
  FUN_01030352(1,400);
  FUN_010302b2(1,1);
  uVar1 = 1;
  while( true ) {
    while (FUN_0104e8ba(), unaff_D7w == 0xffff) {
      if (DAT_0103da5a == 1) {
        FUN_01030352(0,0);
        uVar4 = 0;
        FUN_010302b2(0);
        FUN_0105ec16();
        return uVar4;
      }
      if (DAT_0103da6e != 0) {
        unaff_D7w = uVar1 & 1;
        if (unaff_D7w == 0) {
          local_b = '\0';
        }
        else {
          local_b = '\b';
        }
        for (uVar2 = 1; uVar2 < 0x1c; uVar2 = uVar2 + 1) {
          for (uVar3 = 2; uVar3 < 0x4e; uVar3 = uVar3 + 1) {
            if ((((uVar3 != 2) || (uVar2 != 1)) && ((uVar3 != 0x4d || (uVar2 != 1)))) &&
               (((uVar3 != 2 || (uVar2 != 0x1b)) && ((uVar3 != 0x4d || (uVar2 != 0x1b)))))) {
              unaff_D7w = (ushort)local_b;
              FUN_0105a852(uVar3,uVar2,unaff_D7w);
            }
          }
        }
        uVar1 = uVar1 + 1;
        DAT_0103da6e = 0;
      }
    }
    if (unaff_D7w == 10) break;
    if (unaff_D7w == 0x20) {
      FUN_01030352(0,0);
      uVar4 = 0;
      FUN_010302b2(0);
      FUN_0105ec16();
      return uVar4;
    }
  }
  FUN_01030352(0,0);
  uVar4 = 0;
  FUN_010302b2(0);
  FUN_0105ec16();
  return uVar4;
}


// ==== FUN_0104fa20 @ 0104fa20

/* WARNING: Removing unreachable block (ram,0x0104fb8a) */
/* WARNING: Removing unreachable block (ram,0x0104fd84) */
/* WARNING: Removing unreachable block (ram,0x0104ff90) */

undefined4 FUN_0104fa20(void)

{
  ushort uVar1;
  int iVar2;
  int iVar3;
  ushort unaff_D7w;
  ushort uVar4;
  undefined4 uVar5;
  char local_b;
  ushort local_a;
  
  local_a = 0;
  FUN_0105a8fa(1,0,0x1d);
  FUN_0105a9c0();
  for (iVar2 = 0; iVar2 < 0x1b; iVar2 = iVar2 + 1) {
    for (iVar3 = 0; iVar3 < 0x4c; iVar3 = iVar3 + 1) {
      if (((((iVar3 != 0) || (iVar2 != 0)) && ((iVar3 != 0x4b || (iVar2 != 0)))) &&
          ((iVar3 != 0 || (iVar2 != 0x1a)))) && ((iVar3 != 0x4b || (iVar2 != 0x1a)))) {
        FUN_0105df3e(iVar3,iVar2,local_a,7,0);
        unaff_D7w = local_a + 1;
        local_a = unaff_D7w;
        if (0x7ff < unaff_D7w) {
          local_a = 0;
        }
      }
    }
  }
  FUN_01030352(0,0);
  FUN_010302b2(0,0);
  FUN_01030352(1,200);
  FUN_010302b2(1,1);
  uVar1 = 1;
  do {
    while (FUN_0104e8ba(), unaff_D7w == 0xffff) {
      if (DAT_0103da5a == 1) {
        for (iVar2 = 0; iVar2 < 0x1d; iVar2 = iVar2 + 1) {
          FUN_0105ebca(iVar2);
        }
        local_a = 0;
        uVar4 = 0xffff;
        for (iVar2 = 0; iVar2 < 0x1b; iVar2 = iVar2 + 1) {
          for (iVar3 = 4; iVar3 < 0x50; iVar3 = iVar3 + 1) {
            if (((((iVar3 != 4) || (iVar2 != 0)) && ((iVar3 != 0x4f || (iVar2 != 0)))) &&
                ((iVar3 != 4 || (iVar2 != 0x1a)))) && ((iVar3 != 0x4f || (iVar2 != 0x1a)))) {
              FUN_0105df3e(iVar3,iVar2,local_a,7,0);
              uVar4 = local_a + 1;
              local_a = uVar4;
              if (0x7ff < uVar4) {
                local_a = 0;
              }
            }
          }
        }
        FUN_01030352(0,0);
        FUN_010302b2(0,0);
        FUN_01030352(1,200);
        FUN_010302b2(1,1);
        do {
          while (FUN_0104e8ba(), uVar4 == 0xffff) {
            if (DAT_0103da5a == 1) {
              for (iVar2 = 0; iVar2 < 0x1d; iVar2 = iVar2 + 1) {
                FUN_0105ebca(iVar2);
              }
              local_a = 0;
              uVar4 = 0xffff;
              for (iVar2 = 2; iVar2 < 0x1d; iVar2 = iVar2 + 1) {
                for (iVar3 = 4; iVar3 < 0x50; iVar3 = iVar3 + 1) {
                  if ((((iVar3 != 4) || (iVar2 != 2)) && ((iVar3 != 0x4f || (iVar2 != 2)))) &&
                     (((iVar3 != 4 || (iVar2 != 0x1c)) && ((iVar3 != 0x4f || (iVar2 != 0x1c)))))) {
                    FUN_0105df3e(iVar3,iVar2,local_a,7,0);
                    uVar4 = local_a + 1;
                    local_a = uVar4;
                    if (0x7ff < uVar4) {
                      local_a = 0;
                    }
                  }
                }
              }
              FUN_01030352(0,0);
              FUN_010302b2(0,0);
              FUN_01030352(1,200);
              FUN_010302b2(1,1);
              do {
                while (FUN_0104e8ba(), uVar4 == 0xffff) {
                  if (DAT_0103da5a == 1) {
                    for (iVar2 = 0; iVar2 < 0x1d; iVar2 = iVar2 + 1) {
                      FUN_0105ebca(iVar2);
                    }
                    uVar4 = 0xffff;
                    for (iVar2 = 2; iVar2 < 0x1d; iVar2 = iVar2 + 1) {
                      for (iVar3 = 0; iVar3 < 0x4c; iVar3 = iVar3 + 1) {
                        if (((((iVar3 != 0) || (iVar2 != 2)) && ((iVar3 != 0x4b || (iVar2 != 2))))
                            && ((iVar3 != 0 || (iVar2 != 0x1c)))) &&
                           ((iVar3 != 0x4b || (iVar2 != 0x1c)))) {
                          FUN_0105df3e(iVar3,iVar2,local_a,7,0);
                          uVar4 = local_a + 1;
                          local_a = uVar4;
                          if (0x7ff < uVar4) {
                            local_a = 0;
                          }
                        }
                      }
                    }
                    FUN_01030352(0,0);
                    FUN_010302b2(0,0);
                    FUN_01030352(1,200);
                    FUN_010302b2(1,1);
                    while( true ) {
                      while (FUN_0104e8ba(), uVar4 == 0xffff) {
                        if (DAT_0103da5a == 1) {
                          FUN_01030352(0,0);
                          uVar5 = 0;
                          FUN_010302b2(0);
                          FUN_0105ec16();
                          return uVar5;
                        }
                        if (DAT_0103da6e != 0) {
                          uVar4 = uVar1 & 1;
                          if (uVar4 == 0) {
                            local_b = '\0';
                          }
                          else {
                            local_b = '\b';
                          }
                          for (iVar2 = 2; iVar2 < 0x1d; iVar2 = iVar2 + 1) {
                            for (iVar3 = 0; iVar3 < 0x4c; iVar3 = iVar3 + 1) {
                              if ((((iVar3 != 0) || (iVar2 != 2)) &&
                                  ((iVar3 != 0x4b || (iVar2 != 2)))) &&
                                 (((iVar3 != 0 || (iVar2 != 0x1c)) &&
                                  ((iVar3 != 0x4b || (iVar2 != 0x1c)))))) {
                                uVar4 = (ushort)local_b;
                                FUN_0105a852(iVar3,iVar2,uVar4);
                              }
                            }
                          }
                          uVar1 = uVar1 + 1;
                          DAT_0103da6e = 0;
                        }
                      }
                      if (uVar4 == 10) break;
                      if (uVar4 == 0x20) {
                        FUN_01030352(0,0);
                        uVar5 = 0;
                        FUN_010302b2(0);
                        FUN_0105ec16();
                        return uVar5;
                      }
                    }
                    FUN_01030352(0,0);
                    uVar5 = 0;
                    FUN_010302b2(0);
                    FUN_0105ec16();
                    return uVar5;
                  }
                  if (DAT_0103da6e != 0) {
                    uVar4 = uVar1 & 1;
                    if (uVar4 == 0) {
                      local_b = '\0';
                    }
                    else {
                      local_b = '\b';
                    }
                    for (iVar2 = 2; iVar2 < 0x1d; iVar2 = iVar2 + 1) {
                      for (iVar3 = 4; iVar3 < 0x50; iVar3 = iVar3 + 1) {
                        if ((((iVar3 != 4) || (iVar2 != 2)) && ((iVar3 != 0x4f || (iVar2 != 2)))) &&
                           (((iVar3 != 4 || (iVar2 != 0x1c)) && ((iVar3 != 0x4f || (iVar2 != 0x1c)))
                            ))) {
                          uVar4 = (ushort)local_b;
                          FUN_0105a852(iVar3,iVar2,uVar4);
                        }
                      }
                    }
                    uVar1 = uVar1 + 1;
                    DAT_0103da6e = 0;
                  }
                }
                if (uVar4 == 10) {
                  FUN_01030352(0,0);
                  uVar5 = 0;
                  FUN_010302b2(0);
                  FUN_0105ec16();
                  return uVar5;
                }
              } while (uVar4 != 0x20);
              FUN_01030352(0,0);
              uVar5 = 0;
              FUN_010302b2(0);
              FUN_0105ec16();
              return uVar5;
            }
            if (DAT_0103da6e != 0) {
              uVar4 = uVar1 & 1;
              if (uVar4 == 0) {
                local_b = '\0';
              }
              else {
                local_b = '\b';
              }
              for (iVar2 = 0; iVar2 < 0x1b; iVar2 = iVar2 + 1) {
                for (iVar3 = 4; iVar3 < 0x50; iVar3 = iVar3 + 1) {
                  if (((((iVar3 != 4) || (iVar2 != 0)) && ((iVar3 != 0x4f || (iVar2 != 0)))) &&
                      ((iVar3 != 4 || (iVar2 != 0x1a)))) && ((iVar3 != 0x4f || (iVar2 != 0x1a)))) {
                    uVar4 = (ushort)local_b;
                    FUN_0105a852(iVar3,iVar2,uVar4);
                  }
                }
              }
              uVar1 = uVar1 + 1;
              DAT_0103da6e = 0;
            }
          }
          if (uVar4 == 10) {
            FUN_01030352(0,0);
            uVar5 = 0;
            FUN_010302b2(0);
            FUN_0105ec16();
            return uVar5;
          }
        } while (uVar4 != 0x20);
        FUN_01030352(0,0);
        uVar5 = 0;
        FUN_010302b2(0);
        FUN_0105ec16();
        return uVar5;
      }
      if (DAT_0103da6e != 0) {
        unaff_D7w = uVar1 & 1;
        if (unaff_D7w == 0) {
          local_b = '\0';
        }
        else {
          local_b = '\b';
        }
        for (iVar2 = 0; iVar2 < 0x1b; iVar2 = iVar2 + 1) {
          for (iVar3 = 0; iVar3 < 0x4c; iVar3 = iVar3 + 1) {
            if ((((iVar3 != 0) || (iVar2 != 0)) && ((iVar3 != 0x4b || (iVar2 != 0)))) &&
               (((iVar3 != 0 || (iVar2 != 0x1a)) && ((iVar3 != 0x4b || (iVar2 != 0x1a)))))) {
              unaff_D7w = (ushort)local_b;
              FUN_0105a852(iVar3,iVar2,unaff_D7w);
            }
          }
        }
        uVar1 = uVar1 + 1;
        DAT_0103da6e = 0;
      }
    }
    if (unaff_D7w == 10) {
      FUN_01030352(0,0);
      uVar5 = 0;
      FUN_010302b2(0);
      FUN_0105ec16();
      return uVar5;
    }
  } while (unaff_D7w != 0x20);
  FUN_01030352(0,0);
  uVar5 = 0;
  FUN_010302b2(0);
  FUN_0105ec16();
  return uVar5;
}


// ==== FUN_01050290 @ 01050290

void FUN_01050290(void)

{
  short unaff_D7w;
  
  FUN_01050330(1);
  do {
    FUN_0103fffc();
  } while (unaff_D7w == -1);
  FUN_0105ef12();
  return;
}


// ==== FUN_01050330 @ 01050330

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

uint FUN_01050330(void)

{
  uint in_D0;
  uint uVar1;
  uint uVar2;
  uint local_1e;
  byte local_6;
  byte local_5;
  
  local_5 = 0;
  local_1e = in_D0;
  for (uVar1 = 0; uVar1 < 0x99; uVar1 = uVar1 + 1) {
    local_6 = local_5;
    for (uVar2 = 0; uVar2 < 0x50; uVar2 = uVar2 + 1) {
      local_1e = (uint)local_6;
      FUN_0105e654(uVar2,uVar1,uVar2,uVar1);
      local_6 = local_6 + 1 & 0xf;
    }
    local_5 = local_5 + 1 & 0xf;
  }
  FUN_0105a8fa(1,0,7);
  FUN_0105a8fa(2,7,7);
  FUN_0105a8fa(3,0xe,7);
  FUN_0105a8fa(4,0x15,8);
  _DAT_0103f98c = 0;
  DAT_0103f98e = 7;
  DAT_0103f990 = 0;
  _DAT_0103f992 = 7;
  DAT_0103f994 = 7;
  DAT_0103f996 = 7;
  _DAT_0103f998 = 0xe;
  _DAT_0103f99a = 7;
  _DAT_0103f99c = 0xe;
  _DAT_0103f99e = 0x15;
  _DAT_0103f9a0 = 8;
  _DAT_0103f9a2 = 0x15;
  DAT_0103f986 = 0xe;
  DAT_0103f988 = 3;
  DAT_0103f98a = 0xe;
  FUN_01050ce8();
  FUN_01050df8();
  FUN_0105a9c0();
  return local_1e;
}


// ==== FUN_01050ce8 @ 01050ce8

undefined4 FUN_01050ce8(void)

{
  short sVar1;
  undefined4 in_D0;
  uint uVar2;
  int iVar3;
  uint uVar4;
  undefined4 local_20;
  undefined1 auStack_c [8];
  
  local_20 = in_D0;
  for (uVar2 = 0; uVar2 < 4; uVar2 = uVar2 + 1) {
    iVar3 = (int)(short)(&DAT_0103f990)[uVar2 * 3];
    sVar1 = (&DAT_0103f98e)[uVar2 * 3];
    for (uVar4 = 0; uVar4 < (uint)(int)sVar1; uVar4 = uVar4 + 1) {
      FUN_0105e060(0,uVar4 + iVar3,0x4f,uVar4 + iVar3,0,0x20);
      local_20 = 0;
      FUN_0105de00(0,uVar4 + iVar3,"       ",0);
    }
  }
  for (uVar2 = 0; uVar2 < 4; uVar2 = uVar2 + 1) {
    iVar3 = (int)(short)(&DAT_0103f990)[uVar2 * 3];
    FUN_0105e060(0,iVar3,0x4f,iVar3,3,0x84);
    FUN_0105ee14(0,iVar3 * 0x140 + 0xd010000,7,auStack_c);
    FUN_0105de00(0,iVar3,auStack_c,2,1);
  }
  return local_20;
}


// ==== FUN_01050df8 @ 01050df8

void FUN_01050df8(void)

{
  undefined1 local_8;
  undefined1 local_7;
  
  local_8 = 0xb2;
  local_7 = 0;
  FUN_0105de00(0x28,(int)DAT_0103f98a,&local_8,7,0);
  FUN_0105ec54(0,(int)DAT_0103f986,3,&local_8);
  FUN_0105de00(0x2a,(int)DAT_0103f98a,&local_8,7,1);
  return;
}


// ==== FUN_01050e6e @ 01050e6e

void FUN_01050e6e(void)

{
  undefined4 uVar1;
  
  uVar1 = 1;
  FUN_01058968(1);
  FUN_01051890(1,"RS-422    ",uVar1);
  if (DAT_0103fa0a == '\x01') {
    FUN_01050ee8();
  }
  else if (DAT_0103fa0a == '\x02') {
    FUN_01050fa6();
  }
  else if (DAT_0103fa0a == '\x03') {
    FUN_01051070();
  }
  FUN_01058968(0);
  return;
}


// ==== FUN_01050ee8 @ 01050ee8

void FUN_01050ee8(void)

{
  int unaff_D7;
  
  FUN_0105881e(1,1,0x69);
  FUN_01038d08();
  FUN_01048236(&DAT_01050ee6);
  if (unaff_D7 == 1) {
    FUN_0105881e(1,1,0x70);
  }
  else if (unaff_D7 == 2) {
    FUN_0105881e(1,1,0x66);
  }
  else if (unaff_D7 == 3) {
    FUN_0105881e(1,1,0x61);
  }
  if ((unaff_D7 == 2) && (DAT_0103f9e9 == 'M')) {
    return;
  }
  return;
}


// ==== FUN_01050fa6 @ 01050fa6

void FUN_01050fa6(void)

{
  int unaff_D7;
  int iVar1;
  
  iVar1 = 1;
  if (DAT_0103f9e9 == 'A') {
    FUN_0105881e(1,1,0x69);
    FUN_01038d08();
    FUN_01048236(&DAT_01050fa4);
    iVar1 = unaff_D7;
    if (unaff_D7 == 1) {
      FUN_0105881e(1,1,0x70);
    }
    else if (unaff_D7 == 2) {
      FUN_0105881e(1,1,0x66);
    }
    else if (unaff_D7 == 3) {
      FUN_0105881e(1,1,0x61);
    }
  }
  if ((iVar1 == 2) && (DAT_0103f9e9 == 'M')) {
    return;
  }
  return;
}


// ==== FUN_01051070 @ 01051070

void FUN_01051070(void)

{
  int unaff_D7;
  int iVar1;
  
  iVar1 = 1;
  if (DAT_0103f9e8 == '\x01') {
    FUN_0105881e(1,1,0x69);
    FUN_01038d08();
    FUN_01048236(&DAT_0105106e);
    iVar1 = unaff_D7;
    if (unaff_D7 == 1) {
      FUN_0105881e(1,1,0x70);
    }
    else if (unaff_D7 == 2) {
      FUN_0105881e(1,1,0x66);
    }
    else if (unaff_D7 == 3) {
      FUN_0105881e(1,1,0x61);
    }
  }
  if ((iVar1 == 2) && (DAT_0103f9e9 == 'M')) {
    return;
  }
  return;
}


// ==== FUN_01051138 @ 01051138

void FUN_01051138(void)

{
  undefined4 uVar1;
  
  uVar1 = 1;
  FUN_01058968(1);
  FUN_01051890(1,"RS-232    ",uVar1);
  if (DAT_0103fa0a == '\x01') {
    FUN_010511b2();
  }
  else if (DAT_0103fa0a == '\x02') {
    FUN_01051270();
  }
  else if (DAT_0103fa0a == '\x03') {
    FUN_0105133a();
  }
  FUN_01058968(0);
  return;
}


// ==== FUN_010511b2 @ 010511b2

void FUN_010511b2(void)

{
  int unaff_D7;
  
  FUN_0105881e(1,1,0x69);
  FUN_01039cd0();
  FUN_01048236(&DAT_010511b0);
  if (unaff_D7 == 1) {
    FUN_0105881e(1,1,0x70);
  }
  else if (unaff_D7 == 2) {
    FUN_0105881e(1,1,0x66);
  }
  else if (unaff_D7 == 3) {
    FUN_0105881e(1,1,0x61);
  }
  if ((unaff_D7 == 2) && (DAT_0103f9e7 == 'M')) {
    return;
  }
  return;
}


// ==== FUN_01051270 @ 01051270

void FUN_01051270(void)

{
  int unaff_D7;
  int iVar1;
  
  iVar1 = 1;
  if (DAT_0103f9e7 == 'A') {
    FUN_0105881e(1,1,0x69);
    FUN_01039cd0();
    FUN_01048236(&DAT_0105126e);
    iVar1 = unaff_D7;
    if (unaff_D7 == 1) {
      FUN_0105881e(1,1,0x70);
    }
    else if (unaff_D7 == 2) {
      FUN_0105881e(1,1,0x66);
    }
    else if (unaff_D7 == 3) {
      FUN_0105881e(1,1,0x61);
    }
  }
  if ((iVar1 == 2) && (DAT_0103f9e7 == 'M')) {
    return;
  }
  return;
}


// ==== FUN_0105133a @ 0105133a

void FUN_0105133a(void)

{
  int unaff_D7;
  int iVar1;
  
  iVar1 = 1;
  if (DAT_0103f9e6 == '\x01') {
    FUN_0105881e(1,1,0x69);
    FUN_01039cd0();
    FUN_01048236(&DAT_01051338);
    iVar1 = unaff_D7;
    if (unaff_D7 == 1) {
      FUN_0105881e(1,1,0x70);
    }
    else if (unaff_D7 == 2) {
      FUN_0105881e(1,1,0x66);
    }
    else if (unaff_D7 == 3) {
      FUN_0105881e(1,1,0x61);
    }
  }
  if ((iVar1 == 2) && (DAT_0103f9e7 == 'M')) {
    return;
  }
  return;
}


// ==== FUN_01051402 @ 01051402

void FUN_01051402(void)

{
  undefined4 uVar1;
  
  uVar1 = 1;
  FUN_01058968(1);
  FUN_01051890(1,&DAT_0103ad9c,uVar1);
  FUN_0105a2c2(1);
  if (DAT_0103fa0a == '\x01') {
    FUN_01051486();
  }
  else if (DAT_0103fa0a == '\x02') {
    FUN_01051536();
  }
  else if (DAT_0103fa0a == '\x03') {
    FUN_010515f2();
  }
  FUN_01058968(0);
  return;
}


// ==== FUN_01051486 @ 01051486

void FUN_01051486(void)

{
  int unaff_D7;
  
  FUN_0105881e(1,1,0x69,1);
  FUN_010516ae();
  if (unaff_D7 == 1) {
    FUN_0105881e(1,1,0x70);
  }
  else if (unaff_D7 == 2) {
    FUN_0105881e(1,1,0x66);
  }
  else if (unaff_D7 == 3) {
    FUN_0105881e(1,1,0x61);
  }
  if ((unaff_D7 == 2) && (DAT_0103f9e5 == 'M')) {
    return;
  }
  return;
}


// ==== FUN_01051536 @ 01051536

void FUN_01051536(void)

{
  int unaff_D7;
  int iVar1;
  
  iVar1 = 1;
  if (DAT_0103f9e5 == 'A') {
    FUN_0105881e(1,1,0x69);
    FUN_010516ae();
    iVar1 = unaff_D7;
    if (unaff_D7 == 1) {
      FUN_0105881e(1,1,0x70);
    }
    else if (unaff_D7 == 2) {
      FUN_0105881e(1,1,0x66);
    }
    else if (unaff_D7 == 3) {
      FUN_0105881e(1,1,0x61);
    }
  }
  if ((iVar1 == 2) && (DAT_0103f9e5 == 'M')) {
    return;
  }
  return;
}


// ==== FUN_010515f2 @ 010515f2

void FUN_010515f2(void)

{
  int unaff_D7;
  int iVar1;
  
  iVar1 = 1;
  if (DAT_0103f9e4 == '\x01') {
    FUN_0105881e(1,1,0x69);
    FUN_010516ae();
    iVar1 = unaff_D7;
    if (unaff_D7 == 1) {
      FUN_0105881e(1,1,0x70);
    }
    else if (unaff_D7 == 2) {
      FUN_0105881e(1,1,0x66);
    }
    else if (unaff_D7 == 3) {
      FUN_0105881e(1,1,0x61);
    }
  }
  if ((iVar1 == 2) && (DAT_0103f9e5 == 'M')) {
    return;
  }
  return;
}


// ==== FUN_010516ae @ 010516ae

void FUN_010516ae(void)

{
  ushort unaff_D7w;
  undefined1 auStack_10 [10];
  ushort local_6;
  
  while( true ) {
    do {
      FUN_010400ea();
    } while (unaff_D7w == 0xffff);
    local_6 = unaff_D7w;
    if ((unaff_D7w & 0xff00) == 0) {
      FUN_0105ee14(0,unaff_D7w,2,auStack_10);
    }
    else {
      FUN_0105ee14(0,unaff_D7w,4,auStack_10);
    }
    FUN_0105a30c(1,auStack_10);
    if (local_6 == 10) break;
    unaff_D7w = local_6;
    if (local_6 == 0x20) {
      return;
    }
  }
  return;
}


// ==== FUN_01051742 @ 01051742

void FUN_01051742(char param_1)

{
  if (param_1 == '\x01') {
    FUN_0105dc48(0,0,0x15,0,7);
    FUN_0105dc48(0x3e,0,0x4f,0,7);
    FUN_0105dc48(0x16,0,0x3d,0,1);
    FUN_0105d368(1,0,&DAT_0103b678,4,0);
    FUN_0105d368(0x17,0,"BVE-9100 Diagnosis V1.07",7,0);
    if (DAT_0103fa3d == 'c') {
      FUN_0105e012(0,0,0,0x1d,7,0x89);
      FUN_0105e012(0x4f,0,0x4f,0x1d,7,0x90);
    }
  }
  if (param_1 == '\0') {
    FUN_0105e89e(0);
    FUN_0105e012(0,0,0,0x1d,8,0x20);
    FUN_0105e012(0x4f,0,0x4f,0x1d,8,0x20);
    FUN_0105dc48(0,0,0x4f,0,8);
  }
  return;
}


// ==== FUN_01051890 @ 01051890

void FUN_01051890(char param_1,undefined4 param_2)

{
  if (param_1 == '\x01') {
    FUN_0105d368(0x32,0,&DAT_01051880,7,0);
    FUN_0105d368(0x34,0,param_2,7,0);
  }
  if (param_1 == '\0') {
    FUN_0105d368(0x32,0,"            ",7,0);
  }
  return;
}


// ==== FUN_010518f8 @ 010518f8

void FUN_010518f8(char param_1,char param_2)

{
  FUN_0105e89e(0x19);
  if (param_1 == '\0') {
    return;
  }
  if (param_1 == '\x01') {
    if (param_2 == '\x01') {
      FUN_0105d368(10,0x19,"top of page",3,0);
    }
    if (param_2 == '\x02') {
      FUN_0105d368(10,0x19,"end of page",3,0);
    }
  }
  return;
}


// ==== FUN_010519aa @ 010519aa

void FUN_010519aa(char param_1)

{
  FUN_0105e89e(0x19);
  if (param_1 == '\0') {
    return;
  }
  FUN_0105ef12();
  return;
}


// ==== FUN_01051b08 @ 01051b08

void FUN_01051b08(char param_1)

{
  undefined1 local_9;
  byte local_8;
  undefined1 local_7;
  byte local_6;
  char local_5;
  
  if (param_1 == '\x01') {
    for (local_6 = 1; (char)local_6 < '\t'; local_6 = local_6 + 1) {
      local_5 = local_6 * '\n' + -6;
      local_9 = 0x46;
      local_8 = local_6 & 0xf | 0x30;
      local_7 = 0;
      FUN_0105d368((int)local_5,0x1b,&local_9,7,2);
    }
  }
  if (param_1 == '\0') {
    for (local_6 = '\x01'; (char)local_6 < '\t'; local_6 = local_6 + '\x01') {
      local_5 = local_6 * '\n' + -6;
      local_9 = 0x20;
      local_8 = 0x20;
      local_7 = 0;
      FUN_0105d368((int)local_5,0x1b,&local_9,7,2);
    }
  }
  return;
}


// ==== FUN_01051bd6 @ 01051bd6

void FUN_01051bd6(char param_1,char param_2,char param_3,undefined4 param_4)

{
  uint uVar1;
  int iVar2;
  undefined1 auStackY_8f [101];
  char local_11;
  undefined1 local_f [11];
  
  if ((param_2 < '\x01') || ('\b' < param_2)) {
    return;
  }
  if (param_1 == '\0') {
    FUN_0105e89e(0x1c);
    FUN_0105dc48(0,0x1c,0x4f,0x1c,8);
    return;
  }
  if (DAT_0103fa3d == 'm') {
    for (local_11 = '\0'; local_11 < '\n'; local_11 = local_11 + '\x01') {
      local_f[local_11] = 0x20;
    }
    local_f[10] = 0;
    FUN_0105d368((int)(char)(param_2 * '\n' + -10),0x1c,local_f,8,0);
  }
  else {
    FUN_0105dc48(0,0x1c,0x4f,0x1c,10);
    for (local_11 = '\t'; local_11 < 'P'; local_11 = local_11 + '\n') {
      FUN_0105dc48((int)local_11,0x1c,(int)local_11,0x1c,8);
    }
    local_f[1] = 0;
    if (param_2 == '\x01') {
      local_f[0] = 0x8f;
      FUN_0105d368(0,0x1c,local_f,10,1);
    }
    else {
      local_f[0] = 0xab;
      FUN_0105d368((int)(char)(param_2 * '\n' + -10),0x1c,local_f,8,0);
    }
    for (local_11 = '\0'; local_11 < '\b'; local_11 = local_11 + '\x01') {
      local_f[local_11] = 0xb2;
    }
    local_f[8] = 0xb1;
    if (param_2 == '\b') {
      local_f[8] = 0xaf;
    }
    local_f[9] = 0;
    FUN_0105d368((int)(char)(param_2 * '\n' + -9),0x1c,local_f,10,0);
  }
  if ('\b' < param_3) {
    param_3 = '\b';
  }
  uVar1 = (uint)param_3;
  iVar2 = (int)uVar1 >> 1;
  if ((((int)uVar1 < 0 != iVar2 < 0) != iVar2 < 0) && ((uVar1 & 1) != 0)) {
    iVar2 = iVar2 + 1;
  }
  for (local_11 = '\0'; local_11 < param_3; local_11 = local_11 + '\x01') {
    local_f[local_11] = **(undefined1 **)((int)&param_4 + (int)local_11);
  }
  local_f[param_3] = 0;
  FUN_0105d368((int)(char)(param_2 * '\n' + (-5 - (param_3 % '\x02' + (char)iVar2))),0x1c,local_f,8,
               1);
  return;
}


// ==== FUN_01051e52 @ 01051e52

void FUN_01051e52(char param_1)

{
  FUN_01051e8e((int)param_1);
  FUN_01051f8c((int)param_1);
  if (DAT_0103fa05 == '\x03') {
    FUN_010520ba((int)param_1);
  }
  return;
}


// ==== FUN_01051e8e @ 01051e8e

void FUN_01051e8e(char param_1)

{
  if (param_1 == '\x01') {
    FUN_0105dc48(0x33,0x15,0x4b,0x17,9);
    FUN_0105e202(0x33,0x15,0x4b,0x17,2);
  }
  else if (param_1 == '\0') {
    FUN_0105e012(0x33,0x15,0x33,0x17,8,0x20);
    FUN_0105e012(0x4b,0x15,0x4b,0x17,8,0x20);
    FUN_0105e012(0x33,0x15,0x4b,0x15,8,0x20);
    FUN_0105e012(0x33,0x17,0x4b,0x17,8,0x20);
    FUN_0105dc48(0x33,0x15,0x4b,0x17,8);
  }
  return;
}


// ==== FUN_01051f8c @ 01051f8c

void FUN_01051f8c(char param_1)

{
  if (param_1 == '\x01') {
    FUN_0105d368(0x33,0x15,"Option : ",3,0);
    FUN_0105d368(0x3c,0x15,"ABIJEFMNAll Test  " + (uint)DAT_0103fa04 * 0xc + 8,3,0);
    FUN_0105d368(0x33,0x16,"Loop   : ",3,0);
    FUN_0105d368(0x3c,0x16,"Disk View " + (uint)DAT_0103fa05 * 0x12 + 6,3,0);
    FUN_0105d368(0x33,0x17,"Item   : ",3,0);
    FUN_0105d368(0x3c,0x17,"Count           " + (uint)DAT_0103fa0a * 8 + 10,3,0);
  }
  else if (param_1 == '\0') {
    FUN_0105e84a(0x33,0x15);
    FUN_0105e84a(0x33,0x16);
    FUN_0105e84a(0x33,0x17);
  }
  return;
}


// ==== FUN_010520ba @ 010520ba

void FUN_010520ba(char param_1)

{
  char acStackY_8e [94];
  char local_1c;
  char local_1b;
  char acStack_1a [6];
  char acStack_14 [6];
  char acStack_e [10];
  
  if (param_1 == '\0') {
    FUN_0105e84a(0x42,0x16);
    return;
  }
  if (param_1 == '\x01') {
    FUN_0105ec54(1,DAT_0103fa08,4,acStack_14);
    FUN_0105ec54(1,DAT_0103fa06,4,acStack_1a);
    local_1b = '\0';
    for (local_1c = '\0'; local_1c < '\x04'; local_1c = local_1c + '\x01') {
      if (acStack_14[local_1c] != ' ') {
        acStack_e[local_1b] = acStack_14[local_1c];
        local_1b = local_1b + '\x01';
      }
    }
    acStack_e[local_1b] = '/';
    local_1b = local_1b + '\x01';
    for (local_1c = '\0'; local_1c < '\x04'; local_1c = local_1c + '\x01') {
      if (acStack_1a[local_1c] != ' ') {
        acStack_e[local_1b] = acStack_1a[local_1c];
        local_1b = local_1b + '\x01';
      }
    }
    acStack_e[local_1b] = '\0';
    FUN_0105d368(0x42,0x16,acStack_e,7,0);
  }
  return;
}


// ==== FUN_010521f4 @ 010521f4

void FUN_010521f4(void)

{
  FUN_0105ef12();
  return;
}


// ==== FUN_010522c4 @ 010522c4

void FUN_010522c4(char param_1)

{
  FUN_01052304((int)param_1);
  FUN_01052766((int)param_1);
  FUN_01051e52((int)param_1);
  FUN_01052884((int)param_1);
  return;
}


// ==== FUN_01052304 @ 01052304

void FUN_01052304(char param_1)

{
  FUN_01052350((int)param_1);
  FUN_01052668((int)param_1);
  FUN_01052562((int)param_1);
  FUN_010525ee((int)param_1);
  return;
}


// ==== FUN_01052350 @ 01052350

void FUN_01052350(char param_1)

{
  if (param_1 == '\x01') {
    FUN_0105dc48(6,2,0x10,2,10);
    FUN_0105e012(5,1,5,1,7,0x108);
    FUN_0105e012(6,1,0x10,1,7,0x80);
    FUN_0105e012(0x11,1,0x11,1,7,0x109);
    FUN_0105e012(5,2,5,2,7,0x90);
    FUN_0105e012(0x11,2,0x11,2,7,0x89);
    FUN_0105e012(5,3,5,3,7,0x107);
    FUN_0105e012(6,3,0x10,3,7,0xa2);
    FUN_0105e012(0x11,3,0x11,3,7,0x106);
    FUN_0105d368(6,2,"Option Menu",4,1);
  }
  else if (param_1 == '\0') {
    FUN_0105d368(6,2,"           ",0,0);
    FUN_0105e012(6,2,0x10,1,8,0x20);
    FUN_0105e012(6,2,0x10,2,8,0x20);
    FUN_0105e012(6,2,0x10,3,8,0x20);
    FUN_0105dc48(6,2,0x10,2,8);
  }
  return;
}


// ==== FUN_01052562 @ 01052562

void FUN_01052562(char param_1)

{
  char local_5;
  
  if (param_1 == '\x01') {
    for (local_5 = '\0'; local_5 < '\x11'; local_5 = local_5 + '\x01') {
      FUN_0105d368(3,local_5 + 4,&UNK_0103b1e2 + (short)local_5 * 6,7,0);
    }
  }
  else if (param_1 == '\0') {
    for (local_5 = '\0'; local_5 < '\x11'; local_5 = local_5 + '\x01') {
      FUN_0105d368(3,local_5 + 4,"     ",0,0);
    }
  }
  return;
}


// ==== FUN_010525ee @ 010525ee

void FUN_010525ee(char param_1)

{
  char local_5;
  
  if (param_1 == '\x01') {
    for (local_5 = '\0'; local_5 < '\x11'; local_5 = local_5 + '\x01') {
      FUN_0105d368(8,local_5 + 4,"All Test(default) " + (short)local_5 * 0x14,7,0);
    }
  }
  else if (param_1 == '\0') {
    for (local_5 = '\0'; local_5 < '\x11'; local_5 = local_5 + '\x01') {
      FUN_0105e89e(local_5 + 4);
    }
  }
  return;
}


// ==== FUN_01052668 @ 01052668

void FUN_01052668(char param_1)

{
  if (param_1 == '\x01') {
    FUN_0105dc48(3,4,0x1a,0x14,4);
    FUN_0105e202(3,4,0x1a,0x14,6);
  }
  else if (param_1 == '\0') {
    FUN_0105e012(3,4,3,0x14,8,0x20);
    FUN_0105e012(3,4,0x1a,4,8,0x20);
    FUN_0105e012(0x1a,4,0x1a,0x14,8,0x20);
    FUN_0105e012(3,0x14,0x1a,0x14,8,0x20);
    FUN_0105dc48(3,4,0x1a,0x14,8);
  }
  return;
}


// ==== FUN_01052766 @ 01052766

void FUN_01052766(char param_1)

{
  FUN_010527a0((int)param_1);
  FUN_01052832((int)param_1);
  return;
}


// ==== FUN_010527a0 @ 010527a0

void FUN_010527a0(char param_1)

{
  if (param_1 == '\x01') {
    FUN_0105dc48(3,0x17,0x17,0x17,4);
    FUN_0105d368(3,0x17,"Select Option ==>    ",7,0);
  }
  else if (param_1 == '\0') {
    FUN_0105d368(3,0x17,"                     ",0,0);
    FUN_0105dc48(3,0x17,0x17,0x17,8);
  }
  return;
}


// ==== FUN_01052832 @ 01052832

void FUN_01052832(char param_1)

{
  if (param_1 == '\x01') {
    FUN_0105d368(0x15,0x17,&DAT_0103f981,7,0);
  }
  else if (param_1 == '\0') {
    FUN_0105d368(0x15,0x17,&DAT_0105282e,0,0);
  }
  return;
}


// ==== FUN_01052884 @ 01052884

void FUN_01052884(char param_1)

{
  if (param_1 == '\x01') {
    FUN_01051b08(1);
    if (DAT_0103fa04 == '\x0f') {
      FUN_01051bd6(1,1,8,"        ");
      FUN_01051bd6(1,3,8,"        ");
      FUN_01051bd6(1,4,8,"        ");
      FUN_01051bd6(1,6,8,"        ");
    }
    else {
      FUN_01051bd6(1,1,4,&DAT_0103b248);
      FUN_01051bd6(1,3,4,&DAT_0103b25c);
      FUN_01051bd6(1,4,4,&DAT_0103b266);
      FUN_01051bd6(1,6,6,"RESULT");
    }
    FUN_01051bd6(1,2,8,"        ");
    FUN_01051bd6(1,5,8,"        ");
    FUN_01051bd6(1,7,8,"        ");
    FUN_01051bd6(1,8,4,&DAT_0103b28e);
  }
  else if (param_1 == '\0') {
    FUN_01051b08(0);
    FUN_01051bd6(0,0,0,0);
  }
  return;
}


// ==== FUN_01052a62 @ 01052a62

void FUN_01052a62(char param_1)

{
  FUN_01052aa2((int)param_1);
  FUN_01053628((int)param_1);
  FUN_01051e52((int)param_1);
  FUN_01053748((int)param_1);
  return;
}


// ==== FUN_01052aa2 @ 01052aa2

void FUN_01052aa2(char param_1)

{
  FUN_01052afc((int)param_1);
  FUN_01052fc4((int)param_1);
  FUN_01052d66((int)param_1);
  FUN_01052f36((int)param_1);
  FUN_01053216((int)param_1);
  return;
}


// ==== FUN_01052afc @ 01052afc

void FUN_01052afc(char param_1)

{
  if (param_1 == '\x01') {
    FUN_0105dc48(6,2,0xf,2,10);
    FUN_0105e012(5,1,5,1,7,0x108);
    FUN_0105e012(6,1,0xf,1,7,0x80);
    FUN_0105e012(0x10,1,0x10,1,7,0x109);
    FUN_0105e012(5,2,5,2,7,0x90);
    FUN_0105e012(0x10,2,0x10,2,7,0x89);
    FUN_0105e012(5,3,5,3,7,0x107);
    FUN_0105e012(6,3,0xf,3,7,0xa2);
    FUN_0105e012(0x10,3,0x10,3,7,0x106);
    FUN_0105d368(6,2,"Board Turn",4,1);
  }
  else if (param_1 == '\0') {
    FUN_0105d368(6,2,"           ",0,0);
    FUN_0105e012(6,1,0xf,2,8,0x20);
    FUN_0105e012(6,2,0xf,2,8,0x20);
    FUN_0105e012(6,3,0xf,2,8,0x20);
    FUN_0105dc48(6,2,0xf,2,8);
  }
  return;
}


// ==== FUN_01052d66 @ 01052d66

void FUN_01052d66(char param_1)

{
  if (param_1 == '\x01') {
    FUN_0105d368(4,5,"No Board      ",7,0);
    FUN_0105d368(0x12,5," 1  2  3  4  5 ",7,0);
    FUN_0105d368(0x21,5," 6  7  8  9 10 ",7,0);
    FUN_0105d368(0x30,5,"11 12 13 14 15 ",7,0);
    FUN_0105d368(4,6,&DAT_01052d47,7,0);
    FUN_0105d368(4,7,&DAT_01052d4a,7,0);
    FUN_0105d368(4,8,&DAT_01052d4d,7,0);
    FUN_0105d368(4,9,&DAT_01052d50,7,0);
    FUN_0105d368(4,10,&DAT_01052d53,7,0);
  }
  else if (param_1 == '\0') {
    FUN_0105e89e(5);
    FUN_0105d368(4,6,&DAT_01052d56,0,0);
    FUN_0105d368(4,7,&DAT_01052d59,0,0);
    FUN_0105d368(4,8,&DAT_01052d5c,0,0);
    FUN_0105d368(4,9,&DAT_01052d5f,0,0);
    FUN_0105d368(4,10,&DAT_01052d62,0,0);
  }
  return;
}


// ==== FUN_01052f36 @ 01052f36

void FUN_01052f36(char param_1)

{
  char local_5;
  
  if (param_1 == '\x01') {
    for (local_5 = '\0'; local_5 < '\x05'; local_5 = local_5 + '\x01') {
      FUN_0105d368(7,local_5 + 6,&UNK_0103afd4 + (short)local_5 * 0xc,7,0);
    }
  }
  else if (param_1 == '\0') {
    for (local_5 = '\0'; local_5 < '\x05'; local_5 = local_5 + '\x01') {
      FUN_0105d368(7,local_5 + 6,"           ",8,0);
    }
  }
  return;
}


// ==== FUN_01052fc4 @ 01052fc4

void FUN_01052fc4(char param_1)

{
  uint uVar1;
  uint uVar2;
  
  if (param_1 == '\x01') {
    FUN_0105dc48(4,5,0x3e,10,4);
    FUN_0105e012(4,5,0x3e,5,6,0x100);
    FUN_0105e012(4,5,4,5,6,0x102);
    FUN_0105e012(6,5,6,5,6,0x102);
    for (uVar2 = 0x11; uVar2 < 0x3f; uVar2 = uVar2 + 3) {
      FUN_0105e012(uVar2,5,uVar2,5,6,0x103);
    }
    for (uVar2 = 6; uVar2 < 0xb; uVar2 = uVar2 + 1) {
      FUN_0105e012(4,uVar2,0x3e,uVar2,6,0x80);
      FUN_0105e012(4,uVar2,4,uVar2,6,0xdf);
      FUN_0105e012(6,uVar2,6,uVar2,6,0xdf);
      for (uVar1 = 0x11; uVar1 < 0x3f; uVar1 = uVar1 + 3) {
        FUN_0105e012(uVar1,uVar2,uVar1,uVar2,6,0xde);
      }
    }
  }
  else if (param_1 == '\0') {
    FUN_0105dc48(4,5,0x3e,10,8);
    FUN_0105e012(4,5,0x3e,5,8,0x20);
    FUN_0105e012(4,6,0x3e,6,8,0x20);
    FUN_0105e012(4,7,0x3e,7,8,0x20);
    FUN_0105e012(4,8,0x3e,8,8,0x20);
    FUN_0105e012(4,9,0x3e,9,8,0x20);
    FUN_0105e012(4,10,0x3e,10,8,0x20);
  }
  return;
}


// ==== FUN_01053216 @ 01053216

void FUN_01053216(char param_1)

{
  byte local_5;
  
  if (param_1 == '\x01') {
    if ((DAT_0103f9c3 == 0) || (0xf < DAT_0103f9c3)) {
      return;
    }
    for (local_5 = 1; local_5 <= DAT_0103f9c3; local_5 = local_5 + 1) {
      FUN_0105d368((short)(char)local_5 * 3 + 0x10,(byte)(&DAT_0103f9b3)[(char)local_5] + 5,
                   &DAT_01053214,3,0);
    }
  }
  else if (param_1 == '\0') {
    for (local_5 = '\0'; (char)local_5 < '\x05'; local_5 = local_5 + '\x01') {
      FUN_0105e84a(0x13,(char)local_5 + 6);
    }
  }
  return;
}


// ==== FUN_010532c8 @ 010532c8

void FUN_010532c8(char param_1,char param_2,char param_3)

{
  char local_5;
  
  if (param_1 == '\x01') {
    for (local_5 = '\x06'; local_5 < '\v'; local_5 = local_5 + '\x01') {
      FUN_0105d368((short)param_2 * 3 + 0x10,(int)local_5,&DAT_010532c2,7,0);
    }
    FUN_0105d368((short)param_2 * 3 + 0x10,param_3 + 5,&DAT_010532c4,3,0);
  }
  else if (param_1 == '\0') {
    for (local_5 = '\x06'; local_5 < '\v'; local_5 = local_5 + '\x01') {
      FUN_0105d368((short)param_2 * 3 + 0x10,(int)local_5,&DAT_010532c6,7,0);
    }
  }
  return;
}


// ==== FUN_010533e4 @ 010533e4

void FUN_010533e4(void)

{
  FUN_0105ef12();
  return;
}


// ==== FUN_01053628 @ 01053628

void FUN_01053628(char param_1)

{
  FUN_01053664((int)param_1);
  FUN_010536f6((int)param_1);
  return;
}


// ==== FUN_01053664 @ 01053664

void FUN_01053664(char param_1)

{
  if (param_1 == '\x01') {
    FUN_0105dc48(4,0x13,0x19,0x13,4);
    FUN_0105d368(4,0x13,"Enter Board No ==>    ",7,0);
  }
  else if (param_1 == '\0') {
    FUN_0105d368(4,0x13,"                      ",0,0);
    FUN_0105dc48(4,0x13,0x19,0x13,8);
  }
  return;
}


// ==== FUN_010536f6 @ 010536f6

void FUN_010536f6(char param_1)

{
  if (param_1 == '\x01') {
    FUN_0105d368(0x17,0x13,&DAT_0103f981,7,0);
  }
  else if (param_1 == '\0') {
    FUN_0105d368(0x17,0x13,&DAT_010536f2,0,0);
  }
  return;
}


// ==== FUN_01053748 @ 01053748

void FUN_01053748(char param_1)

{
  if (param_1 == '\x01') {
    FUN_01051b08(1);
    FUN_01051bd6(1,1,4,&DAT_0103b248);
    FUN_01051bd6(1,2,6,"OPTION");
    FUN_01051bd6(1,3,4,&DAT_0103b25c);
    FUN_01051bd6(1,4,4,&DAT_0103b266);
    FUN_01051bd6(1,5,8,"        ");
    FUN_01051bd6(1,6,6,"RESULT");
    FUN_01051bd6(1,7,5,"CLEAR");
    FUN_01051bd6(1,8,4,&DAT_0103b28e);
  }
  else if (param_1 == '\0') {
    FUN_01051b08(0);
    FUN_01051bd6(0,0,0,0);
  }
  return;
}


// ==== FUN_01053896 @ 01053896

void FUN_01053896(char param_1)

{
  if (param_1 == '\x01') {
    FUN_01051b08(1);
    FUN_01051bd6(1,1,3,&DAT_0103b37e);
    FUN_01051bd6(1,2,8,"        ");
    FUN_01051bd6(1,3,8,"        ");
    FUN_01051bd6(1,4,4,&DAT_0103b39c);
    FUN_01051bd6(1,5,5,"TRACK");
    FUN_01051bd6(1,6,6,"SECTOR");
    FUN_01051bd6(1,7,8,"        ");
    FUN_01051bd6(1,8,4,&DAT_0103b28e);
  }
  else if (param_1 == '\0') {
    FUN_01051b08(0);
    FUN_01051bd6(0,0,0,0);
  }
  return;
}


// ==== FUN_010539ee @ 010539ee

void FUN_010539ee(char param_1)

{
  if (param_1 == '\x01') {
    FUN_0105d368(0,0x14,"DRIVE:    ",7,0);
  }
  else if (param_1 == '\0') {
    FUN_0105d368(0,0x14,"        ",0,0);
  }
  return;
}


// ==== FUN_01053a40 @ 01053a40

void FUN_01053a40(char param_1,char param_2)

{
  undefined1 local_5;
  
  if (param_1 == '\x01') {
    if (param_2 == 'n') {
      local_5 = 0;
      FUN_0105dc48(6,0x14,6,0x14,8);
    }
    else {
      local_5 = 8;
      FUN_0105dc90(6,0x14,6,0x14,7);
    }
    FUN_0105d368(6,0x14,&DAT_0103f981,7,local_5);
  }
  else if (param_1 == '\0') {
    FUN_0105d368(6,0x14,&DAT_01053a3c,0,0);
    FUN_0105dc48(6,0x14,6,0x14,8);
  }
  return;
}


// ==== FUN_01053b0e @ 01053b0e

void FUN_01053b0e(char param_1)

{
  if (param_1 == '\x01') {
    FUN_0105d368(0xc,0x14,"SIDE:     ",7,0);
  }
  else if (param_1 == '\0') {
    FUN_0105d368(0xc,0x14,"      ",7,0);
  }
  return;
}


// ==== FUN_01053b66 @ 01053b66

void FUN_01053b66(char param_1,char param_2)

{
  undefined1 local_5;
  
  if (param_1 == '\x01') {
    if (param_2 == 'n') {
      local_5 = 0;
      FUN_0105dc48(0x11,0x14,0x11,0x14,8);
    }
    else {
      local_5 = 8;
      FUN_0105dc90(0x11,0x14,0x11,0x14,7);
    }
    FUN_0105d368(0x11,0x14,&DAT_0103f981,7,local_5);
  }
  else if (param_1 == '\0') {
    FUN_0105d368(0x11,0x14,&DAT_01053b62,0,0);
    FUN_0105dc48(0x11,0x14,0x11,0x14,8);
  }
  return;
}


// ==== FUN_01053c38 @ 01053c38

void FUN_01053c38(char param_1)

{
  if (param_1 == '\x01') {
    FUN_0105d368(0x14,0x14,"TRACK:    ",7,0);
  }
  else if (param_1 == '\0') {
    FUN_0105d368(0x14,0x14,"          ",7,0);
  }
  return;
}


// ==== FUN_01053c92 @ 01053c92

void FUN_01053c92(char param_1,char param_2)

{
  undefined1 local_5;
  
  if (param_1 == '\x01') {
    if (param_2 == 'n') {
      local_5 = 0;
      FUN_0105dc48(0x1a,0x14,0x1c,0x14,8);
    }
    else {
      local_5 = 8;
      FUN_0105dc90(0x1a,0x14,0x1c,0x14,7);
    }
    FUN_0105d368(0x1a,0x14,&DAT_0103f981,7,local_5);
  }
  else if (param_1 == '\0') {
    FUN_0105d368(0x1a,0x14,&DAT_01053c8c,0,0);
    FUN_0105dc48(0x1a,0x14,0x1c,0x14,8);
  }
  return;
}


// ==== FUN_01053d64 @ 01053d64

void FUN_01053d64(char param_1)

{
  if (param_1 == '\x01') {
    FUN_0105d368(0x1f,0x14,"SECTOR:   ",7,0);
  }
  else if (param_1 == '\0') {
    FUN_0105d368(0x1f,0x14,"           ",7,0);
  }
  return;
}


// ==== FUN_01053dbe @ 01053dbe

void FUN_01053dbe(char param_1,char param_2)

{
  undefined1 local_5;
  
  if (param_1 == '\x01') {
    if (param_2 == 'n') {
      local_5 = 0;
      FUN_0105dc48(0x26,0x14,0x28,0x14,8);
    }
    else {
      local_5 = 8;
      FUN_0105dc90(0x26,0x14,0x28,0x14,7);
    }
    FUN_0105d368(0x26,0x14,&DAT_0103f981,7,local_5);
  }
  else if (param_1 == '\0') {
    FUN_0105d368(0x26,0x14,&DAT_01053db8,0,0);
    FUN_0105dc48(0x26,0x14,0x28,0x14,8);
  }
  return;
}


// ==== FUN_01053fec @ 01053fec

void FUN_01053fec(char param_1)

{
  if (param_1 == '\x01') {
    FUN_01051b08(1);
    FUN_01051bd6(1,1,1,&DAT_0103b3ba);
    FUN_01051bd6(1,2,1,&DAT_0103b3c4);
    FUN_01051bd6(1,3,8,"        ");
    FUN_01051bd6(1,4,8,"        ");
    FUN_01051bd6(1,5,8,"        ");
    FUN_01051bd6(1,6,8,"        ");
    FUN_01051bd6(1,7,8,"        ");
    FUN_01051bd6(1,8,4,&DAT_0103b28e);
  }
  else if (param_1 == '\0') {
    FUN_01051b08(0);
    FUN_01051bd6(0,0,0,0);
  }
  return;
}


// ==== FUN_0105413a @ 0105413a

void FUN_0105413a(char param_1)

{
  if (param_1 == '\x01') {
    FUN_01051b08(1);
    FUN_01051bd6(1,1,1,&DAT_0103b3e2);
    FUN_01051bd6(1,2,1,&DAT_0103b3ec);
    FUN_01051bd6(1,3,1,&DAT_0103b3f6);
    FUN_01051bd6(1,4,1,&DAT_0103b400);
    FUN_01051bd6(1,5,8,"        ");
    FUN_01051bd6(1,6,8,"        ");
    FUN_01051bd6(1,7,8,"        ");
    FUN_01051bd6(1,8,4,&DAT_0103b28e);
  }
  else if (param_1 == '\0') {
    FUN_01051b08(0);
    FUN_01051bd6(0,0,0,0);
  }
  return;
}


// ==== FUN_01054288 @ 01054288

void FUN_01054288(char param_1)

{
  if (param_1 == '\x01') {
    FUN_01051b08(1);
    FUN_01051bd6(1,1,8,"        ");
    FUN_01051bd6(1,2,8,"        ");
    FUN_01051bd6(1,3,8,"        ");
    FUN_01051bd6(1,4,8,"        ");
    FUN_01051bd6(1,5,8,"        ");
    FUN_01051bd6(1,6,8,"        ");
    FUN_01051bd6(1,7,8,"        ");
    FUN_01051bd6(1,8,4,&DAT_0103b28e);
  }
  else if (param_1 == '\0') {
    FUN_01051b08(0);
    FUN_01051bd6(0,0,0,0);
  }
  return;
}


// ==== FUN_010543d6 @ 010543d6

void FUN_010543d6(char param_1)

{
  if (param_1 == '\x01') {
    FUN_01051b08(1);
    FUN_01051bd6(1,1,8,"        ");
    FUN_01051bd6(1,2,8,"        ");
    FUN_01051bd6(1,3,8,"        ");
    FUN_01051bd6(1,4,8,"        ");
    FUN_01051bd6(1,5,8,"        ");
    FUN_01051bd6(1,6,8,"        ");
    FUN_01051bd6(1,7,8,"        ");
    FUN_01051bd6(1,8,4,&DAT_0103b28e);
  }
  else if (param_1 == '\0') {
    FUN_01051b08(0);
    FUN_01051bd6(0,0,0,0);
  }
  return;
}


// ==== FUN_01054524 @ 01054524

void FUN_01054524(char param_1)

{
  if (param_1 == '\x01') {
    FUN_01051b08(1);
    FUN_01051bd6(1,1,8,"        ");
    FUN_01051bd6(1,2,8,"        ");
    FUN_01051bd6(1,3,8,"        ");
    FUN_01051bd6(1,4,8,"        ");
    FUN_01051bd6(1,5,8,"        ");
    FUN_01051bd6(1,6,8,"        ");
    FUN_01051bd6(1,7,8,"        ");
    FUN_01051bd6(1,8,4,&DAT_0103b28e);
  }
  else if (param_1 == '\0') {
    FUN_01051b08(0);
    FUN_01051bd6(0,0,0,0);
  }
  return;
}


// ==== FUN_01054672 @ 01054672

void FUN_01054672(char param_1)

{
  FUN_010546b2((int)param_1);
  FUN_01054ab8((int)param_1);
  FUN_01051e52((int)param_1);
  FUN_01054ca8((int)param_1);
  return;
}


// ==== FUN_010546b2 @ 010546b2

void FUN_010546b2(char param_1)

{
  FUN_01054a24((int)param_1);
  FUN_010546f2((int)param_1);
  FUN_010548f4((int)param_1);
  FUN_01054998((int)param_1);
  return;
}


// ==== FUN_010546f2 @ 010546f2

void FUN_010546f2(char param_1)

{
  if (param_1 == '\x01') {
    FUN_0105dc48(6,2,0x16,2,10);
    FUN_0105e012(5,1,5,1,7,0x108);
    FUN_0105e012(6,1,0x16,1,7,0x80);
    FUN_0105e012(0x17,1,0x17,1,7,0x109);
    FUN_0105e012(5,2,5,2,7,0x90);
    FUN_0105e012(0x17,2,0x17,2,7,0x89);
    FUN_0105e012(5,3,5,3,7,0x107);
    FUN_0105e012(6,3,0x16,3,7,0xa2);
    FUN_0105e012(0x17,3,0x17,3,7,0x106);
    FUN_0105d368(6,2,"Loop Control Menu",4,1);
  }
  else if (param_1 == '\0') {
    FUN_0105e89e(2);
    FUN_0105e012(6,2,0x16,1,8,0x20);
    FUN_0105e012(6,2,0x16,2,8,0x20);
    FUN_0105e012(6,2,0x16,3,8,0x20);
    FUN_0105dc48(6,2,0x16,2,8);
  }
  return;
}


// ==== FUN_010548f4 @ 010548f4

void FUN_010548f4(char param_1)

{
  char local_5;
  
  if (param_1 == '\x01') {
    for (local_5 = '\x01'; local_5 < '\x04'; local_5 = local_5 + '\x01') {
      FUN_0105d368(4,local_5 + 3,&UNK_0103b1e3 + (short)local_5 * 6,7,0);
    }
  }
  else if (param_1 == '\0') {
    for (local_5 = '\x01'; local_5 < '\x04'; local_5 = local_5 + '\x01') {
      FUN_0105d368(4,local_5 + 3,&DAT_010548ee,7,0);
    }
  }
  return;
}


// ==== FUN_01054998 @ 01054998

void FUN_01054998(char param_1)

{
  char local_5;
  
  if (param_1 == '\x01') {
    for (local_5 = '\0'; local_5 < '\x03'; local_5 = local_5 + '\x01') {
      FUN_0105d368(8,local_5 + 4,"Do not Loop Test(default)" + (short)local_5 * 0x1a,7,0);
    }
  }
  else if (param_1 == '\0') {
    for (local_5 = '\0'; local_5 < '\x03'; local_5 = local_5 + '\x01') {
      FUN_0105d368(8,local_5 + 4,"                 ",0,0);
    }
  }
  return;
}


// ==== FUN_01054a24 @ 01054a24

void FUN_01054a24(char param_1)

{
  if (param_1 == '\x01') {
    FUN_0105dc48(4,4,0x21,6,4);
    FUN_0105e202(4,4,0x21,6,6);
  }
  else if (param_1 == '\0') {
    FUN_0105e012(4,4,0x21,6,8,0x20);
    FUN_0105dc48(4,4,0x21,6,8);
  }
  return;
}


// ==== FUN_01054ab8 @ 01054ab8

void FUN_01054ab8(char param_1)

{
  FUN_01054adc((int)param_1);
  FUN_01054b5e((int)param_1);
  return;
}


// ==== FUN_01054adc @ 01054adc

void FUN_01054adc(char param_1)

{
  if (param_1 == '\x01') {
    FUN_0105dc48(4,9,0x1d,9,4);
    FUN_0105d368(4,9,"Select Loop Control ==>   ",7,0);
  }
  else if (param_1 == '\0') {
    FUN_0105e89e(9);
    FUN_0105dc48(4,9,0x1d,9,8);
  }
  return;
}


// ==== FUN_01054b5e @ 01054b5e

void FUN_01054b5e(char param_1)

{
  if (param_1 == '\x01') {
    FUN_0105d368(0x1c,9,&DAT_0103f981,7,0);
  }
  else if (param_1 == '\0') {
    FUN_0105d368(0x1c,9,&DAT_01054b5a,0,0);
  }
  return;
}


// ==== FUN_01054bb0 @ 01054bb0

void FUN_01054bb0(char param_1)

{
  FUN_01054bd4((int)param_1);
  FUN_01054c56((int)param_1);
  return;
}


// ==== FUN_01054bd4 @ 01054bd4

void FUN_01054bd4(char param_1)

{
  if (param_1 == '\x01') {
    FUN_0105dc48(4,0xb,0x1c,0xb,4);
    FUN_0105d368(4,0xb,"Enter Loop Data ==>      ",7,0);
  }
  else if (param_1 == '\0') {
    FUN_0105e89e(0xb);
    FUN_0105dc48(4,0xb,0x1c,0xb,8);
  }
  return;
}


// ==== FUN_01054c56 @ 01054c56

void FUN_01054c56(char param_1)

{
  if (param_1 == '\x01') {
    FUN_0105d368(0x18,0xb,&DAT_0103f981,7,0);
  }
  else if (param_1 == '\0') {
    FUN_0105d368(0x18,0xb,&DAT_01054c52,0,0);
  }
  return;
}


// ==== FUN_01054ca8 @ 01054ca8

void FUN_01054ca8(char param_1)

{
  if (param_1 == '\x01') {
    FUN_01051b08(1);
    FUN_01051bd6(1,1,4,&DAT_0103b248);
    FUN_01051bd6(1,2,6,"OPTION");
    FUN_01051bd6(1,3,8,"        ");
    FUN_01051bd6(1,4,4,&DAT_0103b266);
    FUN_01051bd6(1,5,8,"        ");
    FUN_01051bd6(1,6,6,"RESULT");
    FUN_01051bd6(1,7,8,"        ");
    FUN_01051bd6(1,8,4,&DAT_0103b28e);
  }
  else if (param_1 == '\0') {
    FUN_01051b08(0);
    FUN_01051bd6(0,0,0,0);
  }
  return;
}


// ==== FUN_01054df6 @ 01054df6

void FUN_01054df6(char param_1)

{
  FUN_01054e36((int)param_1);
  FUN_01055216((int)param_1);
  FUN_01051e52((int)param_1);
  FUN_0105530e((int)param_1);
  return;
}


// ==== FUN_01054e36 @ 01054e36

void FUN_01054e36(char param_1)

{
  FUN_01055182((int)param_1);
  FUN_01054e76((int)param_1);
  FUN_01055078((int)param_1);
  FUN_01055108((int)param_1);
  return;
}


// ==== FUN_01054e76 @ 01054e76

void FUN_01054e76(char param_1)

{
  if (param_1 == '\x01') {
    FUN_0105dc48(6,2,0x15,2,10);
    FUN_0105e012(5,1,5,1,7,0x108);
    FUN_0105e012(6,1,0x15,1,7,0x80);
    FUN_0105e012(0x16,1,0x16,1,7,0x109);
    FUN_0105e012(5,2,5,2,7,0x90);
    FUN_0105e012(0x16,2,0x16,2,7,0x89);
    FUN_0105e012(5,3,5,3,7,0x107);
    FUN_0105e012(6,3,0x15,3,7,0xa2);
    FUN_0105e012(0x16,3,0x16,3,7,0x106);
    FUN_0105d368(6,2,"Item Select Menu",4,1);
  }
  else if (param_1 == '\0') {
    FUN_0105e89e(2);
    FUN_0105e012(6,2,0x15,1,8,0x20);
    FUN_0105e012(6,2,0x15,2,8,0x20);
    FUN_0105e012(6,2,0x15,3,8,0x20);
    FUN_0105dc48(6,2,0x15,2,8);
  }
  return;
}


// ==== FUN_01055078 @ 01055078

void FUN_01055078(char param_1)

{
  char local_5;
  
  if (param_1 == '\x01') {
    for (local_5 = '\x01'; local_5 < '\x04'; local_5 = local_5 + '\x01') {
      FUN_0105d368(4,local_5 + 3,&UNK_0103b1e3 + (short)local_5 * 6,7,0);
    }
  }
  else if (param_1 == '\0') {
    for (local_5 = '\x01'; local_5 < '\x04'; local_5 = local_5 + '\x01') {
      FUN_0105d368(4,local_5 + 3,&DAT_01055072,0,0);
    }
  }
  return;
}


// ==== FUN_01055108 @ 01055108

void FUN_01055108(char param_1)

{
  char local_5;
  
  if (param_1 == '\x01') {
    for (local_5 = '\0'; local_5 < '\x03'; local_5 = local_5 + '\x01') {
      FUN_0105d368(8,local_5 + 4,"All Check(default)" + (short)local_5 * 0x14,7,0);
    }
  }
  else if (param_1 == '\0') {
    for (local_5 = '\x04'; local_5 < '\a'; local_5 = local_5 + '\x01') {
      FUN_0105e89e((int)local_5);
    }
  }
  return;
}


// ==== FUN_01055182 @ 01055182

void FUN_01055182(char param_1)

{
  if (param_1 == '\x01') {
    FUN_0105dc48(4,4,0x19,6,4);
    FUN_0105e202(4,4,0x19,6,6);
  }
  else if (param_1 == '\0') {
    FUN_0105e012(4,4,0x19,6,8,0x20);
    FUN_0105dc48(4,4,0x19,6,8);
  }
  return;
}


// ==== FUN_01055216 @ 01055216

void FUN_01055216(char param_1)

{
  FUN_0105523a((int)param_1);
  FUN_010552bc((int)param_1);
  return;
}


// ==== FUN_0105523a @ 0105523a

void FUN_0105523a(char param_1)

{
  if (param_1 == '\x01') {
    FUN_0105dc48(4,9,0x15,9,4);
    FUN_0105d368(4,9,"Select Item ==>   ",7,0);
  }
  else if (param_1 == '\0') {
    FUN_0105e89e(9);
    FUN_0105dc48(4,9,0x15,9,8);
  }
  return;
}


// ==== FUN_010552bc @ 010552bc

void FUN_010552bc(char param_1)

{
  if (param_1 == '\x01') {
    FUN_0105d368(0x14,9,&DAT_0103f981,7,0);
  }
  else if (param_1 == '\0') {
    FUN_0105d368(0x14,9,&DAT_010552b8,0,0);
  }
  return;
}


// ==== FUN_0105530e @ 0105530e

void FUN_0105530e(char param_1)

{
  if (param_1 == '\x01') {
    FUN_01051b08(1);
    FUN_01051bd6(1,1,4,&DAT_0103b248);
    FUN_01051bd6(1,2,6,"OPTION");
    FUN_01051bd6(1,3,4,&DAT_0103b25c);
    FUN_01051bd6(1,4,8,"        ");
    FUN_01051bd6(1,5,8,"        ");
    FUN_01051bd6(1,6,6,"RESULT");
    FUN_01051bd6(1,7,8,"        ");
    FUN_01051bd6(1,8,4,&DAT_0103b28e);
  }
  else if (param_1 == '\0') {
    FUN_01051b08(0);
    FUN_01051bd6(0,0,0,0);
  }
  return;
}


// ==== FUN_0105545c @ 0105545c

void FUN_0105545c(char param_1)

{
  if (param_1 == '\x01') {
    FUN_01051b08(1);
    FUN_01051bd6(1,1,4,&DAT_0103b248);
    FUN_01051bd6(1,2,6,"OPTION");
    FUN_01051bd6(1,3,4,&DAT_0103b25c);
    FUN_01051bd6(1,4,8,"        ");
    FUN_01051bd6(1,5,8,"        ");
    FUN_01051bd6(1,6,6,"RESULT");
    FUN_01051bd6(1,7,8,"        ");
    FUN_01051bd6(1,8,4,&DAT_0103b28e);
    if ((DAT_0103fa04 == '\0') || (1 < DAT_0103f9b3)) {
      FUN_01051bd6(1,4,4,&DAT_0103b298);
      FUN_01051bd6(1,5,5,"FOWRD");
    }
  }
  else if (param_1 == '\0') {
    FUN_01051b08(0);
    FUN_01051bd6(0,0,0,0);
  }
  return;
}


// ==== FUN_01055660 @ 01055660

void FUN_01055660(char param_1,byte param_2)

{
  byte local_6 [2];
  
  local_6[0] = param_2 & 0xf | 0x30;
  local_6[1] = 0;
  if (param_1 == '\x01') {
    FUN_0105d368(4,(char)param_2 + 4,local_6,7,8);
    FUN_0105dc90(4,(char)param_2 + 4,4,(char)param_2 + 4,7);
  }
  else if (param_1 == '\0') {
    FUN_0105d368(4,(char)param_2 + 4,local_6,7,0);
    FUN_0105dc48(4,(char)param_2 + 4,4,(char)param_2 + 4,4);
  }
  return;
}


// ==== FUN_01055728 @ 01055728

void FUN_01055728(char param_1)

{
  FUN_01054e76((int)param_1);
  FUN_01055784((int)param_1);
  FUN_010559ac((int)param_1);
  FUN_01055a46((int)param_1);
  FUN_01055ad2((int)param_1);
  return;
}


// ==== FUN_01055784 @ 01055784

void FUN_01055784(char param_1)

{
  char local_5;
  
  if (param_1 == '\x01') {
    FUN_0105dc48(3,4,0x2d,10,4);
    FUN_0105e012(3,4,0x2d,4,6,0x100);
    FUN_0105e012(3,4,3,4,6,0x102);
    FUN_0105e012(0x20,4,0x20,4,6,0x103);
    FUN_0105e012(0x2d,4,0x2d,4,6,0x103);
    for (local_5 = '\x05'; local_5 < '\v'; local_5 = local_5 + '\x01') {
      FUN_0105e012(3,(int)local_5,0x2d,(int)local_5,6,0x80);
      FUN_0105e012(3,(int)local_5,3,(int)local_5,6,0xdf);
      FUN_0105e012(0x20,(int)local_5,0x20,(int)local_5,6,0xde);
      FUN_0105e012(0x2d,(int)local_5,0x2d,(int)local_5,6,0xde);
    }
    FUN_0105d368(4,4,"No  Item",7,0);
    FUN_0105d368(0x22,4,"Result",7,0);
  }
  else if (param_1 == '\0') {
    FUN_0105e89e(4);
    for (local_5 = '\x03'; local_5 < '\v'; local_5 = local_5 + '\x01') {
      FUN_0105e012(3,(int)local_5,0x2d,(int)local_5,8,0x20);
    }
    FUN_0105dc48(3,4,0x2d,10,8);
  }
  return;
}


// ==== FUN_010559ac @ 010559ac

void FUN_010559ac(char param_1)

{
  char local_5;
  
  if (param_1 == '\x01') {
    for (local_5 = '\0'; local_5 < '\x06'; local_5 = local_5 + '\x01') {
      if ((&DAT_0103f9f8)[local_5 * 2] == '\x01') {
        FUN_0105d368(3,local_5 + 5,&DAT_010559a8,7,0);
      }
    }
  }
  else if (param_1 == '\0') {
    for (local_5 = '\0'; local_5 < '\x06'; local_5 = local_5 + '\x01') {
      FUN_0105d368(3,local_5 + 5,&DAT_010559aa,0,0);
    }
  }
  return;
}


// ==== FUN_01055a46 @ 01055a46

void FUN_01055a46(char param_1)

{
  char local_5;
  
  if (param_1 == '\x01') {
    for (local_5 = '\0'; local_5 < '\x06'; local_5 = local_5 + '\x01') {
      FUN_0105d368(4,local_5 + 5,&DAT_0103b1e9 + (short)local_5 * 6,7,0);
    }
  }
  else if (param_1 == '\0') {
    for (local_5 = '\0'; local_5 < '\x06'; local_5 = local_5 + '\x01') {
      FUN_0105d368(4,local_5 + 5,&DAT_01055a40,0,0);
    }
  }
  return;
}


// ==== FUN_01055ad2 @ 01055ad2

void FUN_01055ad2(char param_1)

{
  char local_5;
  
  if (param_1 == '\x01') {
    for (local_5 = '\0'; local_5 < '\x06'; local_5 = local_5 + '\x01') {
      FUN_0105d368(8,local_5 + 5,"LED & DIP-SW   " + local_5 * 0x10,7,0);
    }
  }
  else if (param_1 == '\0') {
    for (local_5 = '\0'; local_5 < '\x06'; local_5 = local_5 + '\x01') {
      FUN_0105e84a(8,local_5 + 5);
    }
  }
  return;
}


// ==== FUN_01055b50 @ 01055b50

void FUN_01055b50(char param_1)

{
  FUN_01054e76((int)param_1);
  FUN_01055bac((int)param_1);
  FUN_01055dd4((int)param_1);
  FUN_01055e6e((int)param_1);
  FUN_01055efa((int)param_1);
  return;
}


// ==== FUN_01055bac @ 01055bac

void FUN_01055bac(char param_1)

{
  char local_5;
  
  if (param_1 == '\x01') {
    FUN_0105dc48(3,4,0x2d,7,4);
    FUN_0105e012(3,4,0x2d,4,6,0x100);
    FUN_0105e012(3,4,3,4,6,0x102);
    FUN_0105e012(0x20,4,0x20,4,6,0x103);
    FUN_0105e012(0x2d,4,0x2d,4,6,0x103);
    for (local_5 = '\x05'; local_5 < '\b'; local_5 = local_5 + '\x01') {
      FUN_0105e012(3,(int)local_5,0x2d,(int)local_5,6,0x80);
      FUN_0105e012(3,(int)local_5,3,(int)local_5,6,0xdf);
      FUN_0105e012(0x20,(int)local_5,0x20,(int)local_5,6,0xde);
      FUN_0105e012(0x2d,(int)local_5,0x2d,(int)local_5,6,0xde);
    }
    FUN_0105d368(4,4,"No  Item",7,0);
    FUN_0105d368(0x22,4,"Result",7,0);
  }
  else if (param_1 == '\0') {
    FUN_0105e89e(4);
    FUN_0105dc48(3,4,0x2d,7,8);
    for (local_5 = '\x04'; local_5 < '\b'; local_5 = local_5 + '\x01') {
      FUN_0105e012(3,(int)local_5,0x2d,(int)local_5,8,0x20);
    }
  }
  return;
}


// ==== FUN_01055dd4 @ 01055dd4

void FUN_01055dd4(char param_1)

{
  char local_5;
  
  if (param_1 == '\x01') {
    for (local_5 = '\0'; local_5 < '\x03'; local_5 = local_5 + '\x01') {
      if ((&DAT_0103f9f2)[local_5 * 2] == '\x01') {
        FUN_0105d368(3,local_5 + 5,&DAT_01055dd0,7,0);
      }
    }
  }
  else if (param_1 == '\0') {
    for (local_5 = '\0'; local_5 < '\x03'; local_5 = local_5 + '\x01') {
      FUN_0105d368(3,local_5 + 5,&DAT_01055dd2,0,0);
    }
  }
  return;
}


// ==== FUN_01055e6e @ 01055e6e

void FUN_01055e6e(char param_1)

{
  char local_5;
  
  if (param_1 == '\x01') {
    for (local_5 = '\0'; local_5 < '\x03'; local_5 = local_5 + '\x01') {
      FUN_0105d368(4,local_5 + 5,&DAT_0103b1e9 + (short)local_5 * 6,7,0);
    }
  }
  else if (param_1 == '\0') {
    for (local_5 = '\0'; local_5 < '\x03'; local_5 = local_5 + '\x01') {
      FUN_0105d368(4,local_5 + 5,&DAT_01055e68,0,0);
    }
  }
  return;
}


// ==== FUN_01055efa @ 01055efa

void FUN_01055efa(char param_1)

{
  char local_5;
  
  if (param_1 == '\x01') {
    for (local_5 = '\0'; local_5 < '\x03'; local_5 = local_5 + '\x01') {
      FUN_0105d368(8,local_5 + 5,"SPF Board Name   " + (short)local_5 * 0x12,7,0);
    }
  }
  else if (param_1 == '\0') {
    for (local_5 = '\0'; local_5 < '\x03'; local_5 = local_5 + '\x01') {
      FUN_0105e84a(8,local_5 + 5);
    }
  }
  return;
}


// ==== FUN_01055f7a @ 01055f7a

void FUN_01055f7a(char param_1)

{
  FUN_01054e76((int)param_1);
  FUN_01055fd6((int)param_1);
  FUN_010561fe((int)param_1);
  FUN_01056298((int)param_1);
  FUN_01056324((int)param_1);
  return;
}


// ==== FUN_01055fd6 @ 01055fd6

void FUN_01055fd6(char param_1)

{
  char local_5;
  
  if (param_1 == '\x01') {
    FUN_0105dc48(3,4,0x2d,8,4);
    FUN_0105e012(3,4,0x2d,4,6,0x100);
    FUN_0105e012(3,4,3,4,6,0x102);
    FUN_0105e012(0x20,4,0x20,4,6,0x103);
    FUN_0105e012(0x2d,4,0x2d,4,6,0x103);
    for (local_5 = '\x05'; local_5 < '\t'; local_5 = local_5 + '\x01') {
      FUN_0105e012(3,(int)local_5,0x2d,(int)local_5,6,0x80);
      FUN_0105e012(3,(int)local_5,3,(int)local_5,6,0xdf);
      FUN_0105e012(0x20,(int)local_5,0x20,(int)local_5,6,0xde);
      FUN_0105e012(0x2d,(int)local_5,0x2d,(int)local_5,6,0xde);
    }
    FUN_0105d368(4,4,"No  Item",7,0);
    FUN_0105d368(0x22,4,"Result",7,0);
  }
  else if (param_1 == '\0') {
    FUN_0105e89e(4);
    FUN_0105dc48(3,4,0x2d,8,8);
    for (local_5 = '\x04'; local_5 < '\t'; local_5 = local_5 + '\x01') {
      FUN_0105e012(3,(int)local_5,0x2d,(int)local_5,8,0x20);
    }
  }
  return;
}


// ==== FUN_010561fe @ 010561fe

void FUN_010561fe(char param_1)

{
  char local_5;
  
  if (param_1 == '\x01') {
    for (local_5 = '\0'; local_5 < '\x04'; local_5 = local_5 + '\x01') {
      if ((&DAT_0103f9ea)[local_5 * 2] == '\x01') {
        FUN_0105d368(3,local_5 + 5,&DAT_010561fa,7,0);
      }
    }
  }
  else if (param_1 == '\0') {
    for (local_5 = '\0'; local_5 < '\x04'; local_5 = local_5 + '\x01') {
      FUN_0105d368(3,local_5 + 5,&DAT_010561fc,0,0);
    }
  }
  return;
}


// ==== FUN_01056298 @ 01056298

void FUN_01056298(char param_1)

{
  char local_5;
  
  if (param_1 == '\x01') {
    for (local_5 = '\0'; local_5 < '\x04'; local_5 = local_5 + '\x01') {
      FUN_0105d368(4,local_5 + 5,&DAT_0103b1e9 + (short)local_5 * 6,7,0);
    }
  }
  else if (param_1 == '\0') {
    for (local_5 = '\0'; local_5 < '\x04'; local_5 = local_5 + '\x01') {
      FUN_0105d368(4,local_5 + 5,&DAT_01056292,0,0);
    }
  }
  return;
}


// ==== FUN_01056324 @ 01056324

void FUN_01056324(char param_1)

{
  char local_5;
  
  if (param_1 == '\x01') {
    for (local_5 = '\0'; local_5 < '\x04'; local_5 = local_5 + '\x01') {
      FUN_0105d368(8,local_5 + 5,"Board-ID & ROM Ver. No." + (short)local_5 * 0x18,7,0);
    }
  }
  else if (param_1 == '\0') {
    for (local_5 = '\0'; local_5 < '\x04'; local_5 = local_5 + '\x01') {
      FUN_0105e84a(8,local_5 + 5);
    }
  }
  return;
}


// ==== FUN_010563a4 @ 010563a4

void FUN_010563a4(char param_1)

{
  FUN_01054e76((int)param_1);
  FUN_01056400((int)param_1);
  FUN_01056600((int)param_1);
  FUN_0105669a((int)param_1);
  FUN_01056726((int)param_1);
  return;
}


// ==== FUN_01056400 @ 01056400

undefined4 FUN_01056400(char param_1)

{
  undefined4 in_D0;
  int iVar1;
  
  if (param_1 == '\x01') {
    FUN_0105dc48(3,4,0x2d,5,4);
    FUN_0105e012(3,4,0x2d,4,6,0x100);
    FUN_0105e012(3,4,3,4,6,0x102);
    FUN_0105e012(0x20,4,0x20,4,6,0x103);
    FUN_0105e012(0x2d,4,0x2d,4,6,0x103);
    for (iVar1 = 5; iVar1 < 6; iVar1 = iVar1 + 1) {
      FUN_0105e012(3,iVar1,0x2d,iVar1,6,0x80);
      FUN_0105e012(3,iVar1,3,iVar1,6,0xdf);
      FUN_0105e012(0x20,iVar1,0x20,iVar1,6,0xde);
      FUN_0105e012(0x2d,iVar1,0x2d,iVar1,6,0xde);
    }
    FUN_0105d368(4,4,"No  Item",7,0);
    in_D0 = 0;
    FUN_0105d368(0x22,4,"Result",7);
  }
  else if (param_1 == '\0') {
    FUN_0105e89e(4);
    FUN_0105e012(3,4,0x2d,5,8,0x20);
    FUN_0105e012(3,5,0x2d,5,8,0x20);
    FUN_0105dc48(3,4,0x2d,5,8);
  }
  return in_D0;
}


// ==== FUN_01056600 @ 01056600

void FUN_01056600(char param_1)

{
  char local_5;
  
  if (param_1 == '\x01') {
    for (local_5 = '\0'; local_5 < '\x01'; local_5 = local_5 + '\x01') {
      if ((&DAT_0103f9e8)[local_5 * 2] == '\x01') {
        FUN_0105d368(3,local_5 + 5,&DAT_010565fc,7,0);
      }
    }
  }
  else if (param_1 == '\0') {
    for (local_5 = '\0'; local_5 < '\x01'; local_5 = local_5 + '\x01') {
      FUN_0105d368(3,local_5 + 5,&DAT_010565fe,0,0);
    }
  }
  return;
}


// ==== FUN_0105669a @ 0105669a

void FUN_0105669a(char param_1)

{
  char local_5;
  
  if (param_1 == '\x01') {
    for (local_5 = '\0'; local_5 < '\x01'; local_5 = local_5 + '\x01') {
      FUN_0105d368(4,local_5 + 5,&DAT_0103b1e9 + (short)local_5 * 6,7,0);
    }
  }
  else if (param_1 == '\0') {
    for (local_5 = '\0'; local_5 < '\x01'; local_5 = local_5 + '\x01') {
      FUN_0105d368(4,local_5 + 5,&DAT_01056694,0,0);
    }
  }
  return;
}


// ==== FUN_01056726 @ 01056726

void FUN_01056726(char param_1)

{
  char local_5;
  
  if (param_1 == '\x01') {
    for (local_5 = '\0'; local_5 < '\x01'; local_5 = local_5 + '\x01') {
      FUN_0105d368(8,local_5 + 5,"Board-ID & Communication" + (short)local_5 * 0x1a,7,0);
    }
  }
  else if (param_1 == '\0') {
    for (local_5 = '\0'; local_5 < '\x01'; local_5 = local_5 + '\x01') {
      FUN_0105e84a(8,local_5 + 5);
    }
  }
  return;
}


// ==== FUN_010567a6 @ 010567a6

void FUN_010567a6(char param_1)

{
  FUN_01054e76((int)param_1);
  FUN_01056802((int)param_1);
  FUN_01056a02((int)param_1);
  FUN_01056a9c((int)param_1);
  FUN_01056b28((int)param_1);
  return;
}


// ==== FUN_01056802 @ 01056802

undefined4 FUN_01056802(char param_1)

{
  undefined4 in_D0;
  int iVar1;
  
  if (param_1 == '\x01') {
    FUN_0105dc48(3,4,0x2d,5,4);
    FUN_0105e012(3,4,0x2d,4,6,0x100);
    FUN_0105e012(3,4,3,4,6,0x102);
    FUN_0105e012(0x20,4,0x20,4,6,0x103);
    FUN_0105e012(0x2d,4,0x2d,4,6,0x103);
    for (iVar1 = 5; iVar1 < 6; iVar1 = iVar1 + 1) {
      FUN_0105e012(3,iVar1,0x2d,iVar1,6,0x80);
      FUN_0105e012(3,iVar1,3,iVar1,6,0xdf);
      FUN_0105e012(0x20,iVar1,0x20,iVar1,6,0xde);
      FUN_0105e012(0x2d,iVar1,0x2d,iVar1,6,0xde);
    }
    FUN_0105d368(4,4,"No  Item",7,0);
    in_D0 = 0;
    FUN_0105d368(0x22,4,"Result",7);
  }
  else if (param_1 == '\0') {
    FUN_0105e89e(4);
    FUN_0105e012(3,4,0x2d,5,8,0x20);
    FUN_0105e012(3,5,0x2d,5,8,0x20);
    FUN_0105dc48(3,4,0x2d,5,8);
  }
  return in_D0;
}


// ==== FUN_01056a02 @ 01056a02

void FUN_01056a02(char param_1)

{
  char local_5;
  
  if (param_1 == '\x01') {
    for (local_5 = '\0'; local_5 < '\x01'; local_5 = local_5 + '\x01') {
      if ((&DAT_0103f9e6)[local_5 * 2] == '\x01') {
        FUN_0105d368(3,local_5 + 5,&DAT_010569fe,7,0);
      }
    }
  }
  else if (param_1 == '\0') {
    for (local_5 = '\0'; local_5 < '\x01'; local_5 = local_5 + '\x01') {
      FUN_0105d368(3,local_5 + 5,&DAT_01056a00,0,0);
    }
  }
  return;
}


// ==== FUN_01056a9c @ 01056a9c

void FUN_01056a9c(char param_1)

{
  char local_5;
  
  if (param_1 == '\x01') {
    for (local_5 = '\0'; local_5 < '\x01'; local_5 = local_5 + '\x01') {
      FUN_0105d368(4,local_5 + 5,&DAT_0103b1e9 + (short)local_5 * 6,7,0);
    }
  }
  else if (param_1 == '\0') {
    for (local_5 = '\0'; local_5 < '\x01'; local_5 = local_5 + '\x01') {
      FUN_0105d368(4,local_5 + 5,&DAT_01056a96,0,0);
    }
  }
  return;
}


// ==== FUN_01056b28 @ 01056b28

void FUN_01056b28(char param_1)

{
  char local_5;
  
  if (param_1 == '\x01') {
    for (local_5 = '\0'; local_5 < '\x01'; local_5 = local_5 + '\x01') {
      FUN_0105d368(8,local_5 + 5,"Board-ID & Communication" + (short)local_5 * 0x1a,7,0);
    }
  }
  else if (param_1 == '\0') {
    for (local_5 = '\0'; local_5 < '\x01'; local_5 = local_5 + '\x01') {
      FUN_0105e84a(8,local_5 + 5);
    }
  }
  return;
}


// ==== FUN_01056ba8 @ 01056ba8

void FUN_01056ba8(char param_1)

{
  FUN_01054e76((int)param_1);
  FUN_01056c04((int)param_1);
  FUN_01056e04((int)param_1);
  FUN_01056e9e((int)param_1);
  FUN_01056f2a((int)param_1);
  return;
}


// ==== FUN_01056c04 @ 01056c04

undefined4 FUN_01056c04(char param_1)

{
  undefined4 in_D0;
  int iVar1;
  
  if (param_1 == '\x01') {
    FUN_0105dc48(3,4,0x2d,5,4);
    FUN_0105e012(3,4,0x2d,4,6,0x100);
    FUN_0105e012(3,4,3,4,6,0x102);
    FUN_0105e012(0x20,4,0x20,4,6,0x103);
    FUN_0105e012(0x2d,4,0x2d,4,6,0x103);
    for (iVar1 = 5; iVar1 < 6; iVar1 = iVar1 + 1) {
      FUN_0105e012(3,iVar1,0x2d,iVar1,6,0x80);
      FUN_0105e012(3,iVar1,3,iVar1,6,0xdf);
      FUN_0105e012(0x20,iVar1,0x20,iVar1,6,0xde);
      FUN_0105e012(0x2d,iVar1,0x2d,iVar1,6,0xde);
    }
    FUN_0105d368(4,4,"No  Item",7,0);
    in_D0 = 0;
    FUN_0105d368(0x22,4,"Result",7);
  }
  else if (param_1 == '\0') {
    FUN_0105e89e(4);
    FUN_0105e012(3,4,0x2d,5,8,0x20);
    FUN_0105e012(3,5,0x2d,5,8,0x20);
    FUN_0105dc48(3,4,0x2d,5,8);
  }
  return in_D0;
}


// ==== FUN_01056e04 @ 01056e04

void FUN_01056e04(char param_1)

{
  char local_5;
  
  if (param_1 == '\x01') {
    for (local_5 = '\0'; local_5 < '\x01'; local_5 = local_5 + '\x01') {
      if ((&DAT_0103f9e4)[local_5 * 2] == '\x01') {
        FUN_0105d368(3,local_5 + 5,&DAT_01056e00,7,0);
      }
    }
  }
  else if (param_1 == '\0') {
    for (local_5 = '\0'; local_5 < '\x01'; local_5 = local_5 + '\x01') {
      FUN_0105d368(3,local_5 + 5,&DAT_01056e02,0,0);
    }
  }
  return;
}


// ==== FUN_01056e9e @ 01056e9e

void FUN_01056e9e(char param_1)

{
  char local_5;
  
  if (param_1 == '\x01') {
    for (local_5 = '\0'; local_5 < '\x01'; local_5 = local_5 + '\x01') {
      FUN_0105d368(4,local_5 + 5,&DAT_0103b1e9 + (short)local_5 * 6,7,0);
    }
  }
  else if (param_1 == '\0') {
    for (local_5 = '\0'; local_5 < '\x01'; local_5 = local_5 + '\x01') {
      FUN_0105d368(4,local_5 + 5,&DAT_01056e98,0,0);
    }
  }
  return;
}


// ==== FUN_01056f2a @ 01056f2a

void FUN_01056f2a(char param_1)

{
  char local_5;
  
  if (param_1 == '\x01') {
    for (local_5 = '\0'; local_5 < '\x01'; local_5 = local_5 + '\x01') {
      FUN_0105d368(8,local_5 + 5,"Key Code Display" + (short)local_5 * 0x12,7,0);
    }
  }
  else if (param_1 == '\0') {
    for (local_5 = '\0'; local_5 < '\x01'; local_5 = local_5 + '\x01') {
      FUN_0105e84a(8,local_5 + 5);
    }
  }
  return;
}


// ==== FUN_01056faa @ 01056faa

void FUN_01056faa(char param_1)

{
  if (param_1 == '\x01') {
    FUN_01051b08(1);
    FUN_01051bd6(1,1,3,&DAT_0103b2b6);
    FUN_01051bd6(1,2,7,"PRINTER");
    FUN_01051bd6(1,3,5,"SETUP");
    FUN_01051bd6(1,4,8,"        ");
    FUN_01051bd6(1,5,8,"        ");
    FUN_01051bd6(1,6,8,"        ");
    FUN_01051bd6(1,7,8,"        ");
    FUN_01051bd6(1,8,4,&DAT_0103b28e);
  }
  else if (param_1 == '\0') {
    FUN_01051b08(0);
    FUN_01051bd6(0,0,0,0);
  }
  return;
}


// ==== FUN_010570f8 @ 010570f8

void FUN_010570f8(char param_1)

{
  char local_5;
  
  if (param_1 == '\x01') {
    FUN_0105d368(4,4,"BAUD RATE",7,0);
    FUN_0105d368(4,6,"CHA LENGTH",7,0);
    FUN_0105d368(4,8,"PARITY",7,0);
    FUN_0105d368(4,10,"PARITY",7,0);
    FUN_0105d368(4,0xc,&DAT_0103b5f4,7,0);
  }
  else if (param_1 == '\0') {
    for (local_5 = '\0'; local_5 < '\r'; local_5 = local_5 + '\x01') {
      FUN_0105e89e((int)local_5);
    }
  }
  return;
}


// ==== FUN_01057204 @ 01057204

void FUN_01057204(char param_1)

{
  if (param_1 == '\0') {
    FUN_0105dc48(0x17,4,0x1b,4,8);
    FUN_0105d368(0x17,4,"     ",7,0);
    return;
  }
  if (param_1 == '\x01') {
    FUN_0105d368(0x17,4,"     ",7,0);
    FUN_0105dc48(0x17,4,0x1b,4,8);
    FUN_0105ef12();
    return;
  }
  return;
}


// ==== FUN_010574e6 @ 010574e6

void FUN_010574e6(char param_1,char param_2)

{
  undefined1 local_6;
  undefined1 local_5;
  
  if (param_1 == '\x01') {
    if (DAT_0103f9db == '\0') {
      local_6 = 0x38;
    }
    else {
      local_6 = 0x37;
    }
    local_5 = 0;
    if (param_2 == 'n') {
      FUN_0105dc48(0x17,6,0x17,6,8);
      FUN_0105d368(0x17,6,&local_6,7,0);
    }
    else {
      FUN_0105dc90(0x17,6,0x17,6,7);
      FUN_0105d368(0x17,6,&local_6,7,8);
    }
  }
  else if (param_1 == '\0') {
    FUN_0105dc48(0x17,6,0x17,6,8);
    FUN_0105d368(0x17,6,&DAT_010574e4,0,0);
  }
  return;
}


// ==== FUN_010575e6 @ 010575e6

void FUN_010575e6(char param_1,char param_2)

{
  undefined1 local_5;
  
  if (param_1 == '\x01') {
    FUN_0105d368(0x17,8,"       ",0,0);
    FUN_0105dc48(0x17,8,0x1d,8,8);
    if (param_2 == 'n') {
      local_5 = 0;
    }
    else {
      local_5 = 8;
    }
    if (DAT_0103f9dc == '\0') {
      if (param_2 == 'r') {
        FUN_0105dc90(0x17,8,0x1c,8,7);
      }
      FUN_0105d368(0x17,8,"ENABLE",7,local_5);
    }
    else if (DAT_0103f9dc == '\x01') {
      if (param_2 == 'r') {
        FUN_0105dc90(0x17,8,0x1d,8,7);
      }
      FUN_0105d368(0x17,8,"DISABLE",7,local_5);
    }
  }
  else if (param_1 == '\0') {
    FUN_0105d368(0x17,8,"       ",0,0);
    FUN_0105dc48(0x17,8,0x1d,8,8);
  }
  return;
}


// ==== FUN_0105773e @ 0105773e

void FUN_0105773e(char param_1,char param_2)

{
  undefined1 local_5;
  
  if (param_1 == '\x01') {
    FUN_0105d368(0x17,10,&DAT_01057734,0,0);
    FUN_0105dc48(0x17,10,0x1a,10,8);
    if (param_2 == 'n') {
      local_5 = 0;
    }
    else {
      local_5 = 8;
    }
    if (DAT_0103f9dd == '\x01') {
      if (param_2 == 'r') {
        FUN_0105dc90(0x17,10,0x19,10,7);
      }
      FUN_0105d368(0x17,10,&DAT_0103b360,7,local_5);
    }
    else if (DAT_0103f9dd == '\0') {
      if (param_2 == 'r') {
        FUN_0105dc90(0x17,10,0x1a,10,7);
      }
      FUN_0105d368(0x17,10,&DAT_0103b356,7,local_5);
    }
  }
  else if (param_1 == '\0') {
    FUN_0105d368(0x17,10,&DAT_01057739,0,0);
    FUN_0105dc48(0x17,10,0x1a,10,8);
  }
  return;
}


// ==== FUN_0105788e @ 0105788e

void FUN_0105788e(char param_1,char param_2)

{
  undefined1 local_7;
  undefined1 local_6;
  undefined1 local_5;
  
  if (param_1 == '\x01') {
    local_5 = 0;
    if (DAT_0103f9de == '\0') {
      local_6 = 0x31;
    }
    else {
      local_6 = 0x32;
    }
    if (param_2 == 'n') {
      local_7 = 0;
      FUN_0105dc48(0x17,0xc,0x17,0xc,8);
    }
    else {
      local_7 = 8;
      FUN_0105dc90(0x17,0xc,0x17,0xc,7);
    }
    FUN_0105d368(0x17,0xc,&local_6,7,local_7);
  }
  else if (param_1 == '\0') {
    FUN_0105d368(0x17,0xc,&DAT_0105788c,0,0);
    FUN_0105dc48(0x17,0xc,0x17,0xc,8);
  }
  return;
}


// ==== FUN_0105796e @ 0105796e

void FUN_0105796e(char param_1,short param_2)

{
  char local_5;
  
  if (param_1 == '\x01') {
    for (local_5 = '\0'; local_5 < '\x14'; local_5 = local_5 + '\x01') {
      FUN_0105e89e(local_5 + 2);
      if ((int)local_5 + (int)param_2 + -1 < (int)DAT_0103db38) {
        FUN_0105d368(0,local_5 + 2,
                     *(undefined4 *)(&UNK_0103dae8 + ((int)local_5 + (int)param_2) * 0x54),7,0);
      }
    }
  }
  else if (param_1 == '\0') {
    for (local_5 = '\x01'; local_5 < '\x17'; local_5 = local_5 + '\x01') {
      FUN_0105e89e((int)local_5);
    }
  }
  return;
}


// ==== FUN_01057a26 @ 01057a26

void FUN_01057a26(char param_1)

{
  if (param_1 == '\x01') {
    FUN_01051b08(1);
    FUN_01051bd6(1,1,4,&DAT_0103b2d4);
    FUN_01051bd6(1,2,4,&DAT_0103b2de);
    FUN_01051bd6(1,3,8,"        ");
    FUN_01051bd6(1,4,8,"        ");
    FUN_01051bd6(1,5,8,"        ");
    FUN_01051bd6(1,6,8,"        ");
    FUN_01051bd6(1,7,8,"        ");
    FUN_01051bd6(1,8,4,&DAT_0103b28e);
  }
  else if (param_1 == '\0') {
    FUN_01051b08(0);
    FUN_01051bd6(0,0,0,0);
  }
  return;
}


// ==== FUN_01057b74 @ 01057b74

void FUN_01057b74(char param_1)

{
  if (param_1 == '\x01') {
    FUN_01051b08(1);
    FUN_01051bd6(1,1,8,"        ");
    FUN_01051bd6(1,2,8,"        ");
    FUN_01051bd6(1,3,8,"        ");
    FUN_01051bd6(1,4,8,"        ");
    FUN_01051bd6(1,5,8,"        ");
    FUN_01051bd6(1,6,8,"        ");
    FUN_01051bd6(1,7,8,"        ");
    FUN_01051bd6(1,8,8,"        ");
  }
  else if (param_1 == '\0') {
    FUN_01051b08(0);
    FUN_01051bd6(0,0,0,0);
  }
  return;
}


// ==== FUN_01057cc2 @ 01057cc2

void FUN_01057cc2(char param_1)

{
  if (param_1 == '\x01') {
    FUN_01051b08(1);
    FUN_01051bd6(1,1,8,"        ");
    FUN_01051bd6(1,2,8,"        ");
    FUN_01051bd6(1,3,8,"        ");
    FUN_01051bd6(1,4,8,"        ");
    FUN_01051bd6(1,5,8,"        ");
    FUN_01051bd6(1,6,8,"        ");
    FUN_01051bd6(1,7,8,"        ");
    FUN_01051bd6(1,8,4,&DAT_0103b28e);
  }
  else if (param_1 == '\0') {
    FUN_01051b08(0);
    FUN_01051bd6(0,0,0,0);
  }
  return;
}


// ==== FUN_01057e10 @ 01057e10

void FUN_01057e10(char param_1)

{
  if (param_1 == '\x01') {
    FUN_01051b08(1);
    FUN_01051bd6(1,1,3,&DAT_0103b2e8);
    FUN_01051bd6(1,2,4,&DAT_0103b2f2);
    FUN_01051bd6(1,3,4,&DAT_0103b2fc);
    FUN_01051bd6(1,4,4,&DAT_0103b306);
    FUN_01051bd6(1,5,4,&DAT_0103b310);
    FUN_01051bd6(1,6,5,"19.2K");
    FUN_01051bd6(1,7,5,"38.4K");
    FUN_01051bd6(1,8,4,&DAT_0103b28e);
  }
  else if (param_1 == '\0') {
    FUN_01051b08(0);
    FUN_01051bd6(0,0,0,0);
  }
  return;
}


// ==== FUN_01057f5e @ 01057f5e

void FUN_01057f5e(char param_1)

{
  if (param_1 == '\x01') {
    FUN_01051b08(1);
    FUN_01051bd6(1,1,5,"8BITS");
    FUN_01051bd6(1,2,5,"7BITS");
    FUN_01051bd6(1,3,8,"        ");
    FUN_01051bd6(1,4,8,"        ");
    FUN_01051bd6(1,5,8,"        ");
    FUN_01051bd6(1,6,8,"        ");
    FUN_01051bd6(1,7,8,"        ");
    FUN_01051bd6(1,8,4,&DAT_0103b28e);
  }
  else if (param_1 == '\0') {
    FUN_01051b08(0);
    FUN_01051bd6(0,0,0,0);
  }
  return;
}


// ==== FUN_010580ac @ 010580ac

void FUN_010580ac(char param_1)

{
  if (param_1 == '\x01') {
    FUN_01051b08(1);
    FUN_01051bd6(1,1,6,"ENABLE");
    FUN_01051bd6(1,2,7,"DISABLE");
    FUN_01051bd6(1,3,8,"        ");
    FUN_01051bd6(1,4,8,"        ");
    FUN_01051bd6(1,5,8,"        ");
    FUN_01051bd6(1,6,8,"        ");
    FUN_01051bd6(1,7,8,"        ");
    FUN_01051bd6(1,8,4,&DAT_0103b28e);
  }
  else if (param_1 == '\0') {
    FUN_01051b08(0);
    FUN_01051bd6(0,0,0,0);
  }
  return;
}


// ==== FUN_010581fa @ 010581fa

void FUN_010581fa(char param_1)

{
  if (param_1 == '\x01') {
    FUN_01051b08(1);
    FUN_01051bd6(1,1,4,&DAT_0103b356);
    FUN_01051bd6(1,2,3,&DAT_0103b360);
    FUN_01051bd6(1,3,8,"        ");
    FUN_01051bd6(1,4,8,"        ");
    FUN_01051bd6(1,5,8,"        ");
    FUN_01051bd6(1,6,8,"        ");
    FUN_01051bd6(1,7,8,"        ");
    FUN_01051bd6(1,8,4,&DAT_0103b28e);
  }
  else if (param_1 == '\0') {
    FUN_01051b08(0);
    FUN_01051bd6(0,0,0,0);
  }
  return;
}


// ==== FUN_01058348 @ 01058348

void FUN_01058348(char param_1)

{
  if (param_1 == '\x01') {
    FUN_01051b08(1);
    FUN_01051bd6(1,1,4,&DAT_0103b36a);
    FUN_01051bd6(1,2,4,&DAT_0103b374);
    FUN_01051bd6(1,3,8,"        ");
    FUN_01051bd6(1,4,8,"        ");
    FUN_01051bd6(1,5,8,"        ");
    FUN_01051bd6(1,6,8,"        ");
    FUN_01051bd6(1,7,8,"        ");
    FUN_01051bd6(1,8,4,&DAT_0103b28e);
  }
  else if (param_1 == '\0') {
    FUN_01051b08(0);
    FUN_01051bd6(0,0,0,0);
  }
  return;
}


// ==== FUN_01058496 @ 01058496

void FUN_01058496(char param_1)

{
  if (param_1 == '\x01') {
    FUN_0105d368(0,0x17,"CPU-88 : MFD Block",7,0);
    FUN_0105e89e(0x18);
    FUN_0105d368(0,0x19,"  Disk Write OK ?   Yes ... ENTER key",7,0);
    FUN_0105d368(0,0x1a,"                    No  ... Other key",7,0);
    FUN_0105e89e(0x1b);
    FUN_0105e89e(0x1c);
  }
  else if (param_1 == '\0') {
    FUN_0105e89e(0x17);
    FUN_0105e89e(0x19);
    FUN_0105e89e(0x1a);
  }
  return;
}


// ==== FUN_0105854a @ 0105854a

void FUN_0105854a(char param_1)

{
  char acStackY_8e [86];
  char local_1c;
  char local_1b;
  char acStack_1a [6];
  char acStack_14 [6];
  char acStack_e [10];
  
  if (param_1 == '\0') {
    FUN_0105e84a(0x33,0xc);
    FUN_0105e84a(0x33,0xd);
    FUN_0105e84a(0x33,0xe);
    for (local_1b = '\f'; local_1b < '\x0f'; local_1b = local_1b + '\x01') {
      FUN_0105e012(0x33,(int)local_1b,0x4b,(int)local_1b,2,0x20);
    }
    FUN_0105dc48(0x33,0xc,0x4b,0xe,8);
  }
  else if (param_1 == '\x01') {
    FUN_0105dc48(0x33,0xc,0x4b,0xe,9);
    FUN_0105e202(0x33,0xc,0x4b,0xe,2);
    FUN_0105d368(0x33,0xc,"Option : ",3,0);
    FUN_0105d368(0x3c,0xc,"ABIJEFMNAll Test  " + (uint)DAT_0103fa04 * 0xc + 8,3,0);
    FUN_0105d368(0x33,0xd,"Loop   : ",3,0);
    FUN_0105d368(0x3c,0xd,"Disk View " + (uint)DAT_0103fa05 * 0x12 + 6,3,0);
    FUN_0105d368(0x33,0xe,"Item   : ",3,0);
    FUN_0105d368(0x3c,0xe,"Count           " + (uint)DAT_0103fa0a * 8 + 10,3,0);
    if (DAT_0103fa05 == 3) {
      FUN_0105ec54(1,DAT_0103fa08,4,acStack_14);
      FUN_0105ec54(1,DAT_0103fa06,4,acStack_1a);
      local_1b = '\0';
      for (local_1c = '\0'; local_1c < '\x04'; local_1c = local_1c + '\x01') {
        if (acStack_14[local_1c] != ' ') {
          acStack_e[local_1b] = acStack_14[local_1c];
          local_1b = local_1b + '\x01';
        }
      }
      acStack_e[local_1b] = '/';
      local_1b = local_1b + '\x01';
      for (local_1c = '\0'; local_1c < '\x04'; local_1c = local_1c + '\x01') {
        if (acStack_1a[local_1c] != ' ') {
          acStack_e[local_1b] = acStack_1a[local_1c];
          local_1b = local_1b + '\x01';
        }
      }
      acStack_e[local_1b] = '\0';
      FUN_0105d368(0x42,0xd,acStack_e,7,0);
    }
  }
  return;
}


// ==== FUN_0105881e @ 0105881e

void FUN_0105881e(char param_1,char param_2,char param_3)

{
  char local_5;
  
  if (param_1 == '\x01') {
    FUN_0105d368(0x22,param_2 + 4,"           ",0,0);
    if (param_3 == 'i') {
      FUN_0105d368(0x22,param_2 + 4,"In Progress",3,0x10);
    }
    else if (param_3 == 'p') {
      FUN_0105d368(0x22,param_2 + 4,&DAT_0103b4f6,3,0);
    }
    else if (param_3 == 'f') {
      FUN_0105d368(0x22,param_2 + 4,"Fault",0xb,0);
    }
    else if (param_3 == 'a') {
      FUN_0105d368(0x22,param_2 + 4,"Abort",5,0);
    }
  }
  else if (param_1 == '\0') {
    for (local_5 = '\x05'; local_5 < '\v'; local_5 = local_5 + '\x01') {
      FUN_0105d368(0x22,(int)local_5,"           ",0,0);
    }
  }
  return;
}


// ==== FUN_01058968 @ 01058968

undefined4 FUN_01058968(char param_1)

{
  undefined4 in_D0;
  char local_5;
  
  if (param_1 == '\x01') {
    for (local_5 = '\x1d'; local_5 < ')'; local_5 = local_5 + '\x01') {
      FUN_0105e89e((int)local_5);
      FUN_0105d63c(0,(int)local_5,0x4f,(int)local_5,0,0);
      FUN_0105ebca((int)local_5);
      FUN_0105e012(0,(int)local_5,0x4f,(int)local_5,0,0x20);
    }
    FUN_0105d368(0,0x1d,"--------------------",10,0);
    FUN_0105d368(0xc,0x1d,"--------------------",10,0);
    FUN_0105d368(0x29,0x1d,"--------------------",10,0);
    FUN_0105d368(0x3c,0x1d,"--------------------",10,0);
    FUN_0105d368(0x21,0x1d,"Message",10,0);
    FUN_0105dc48(0,0x1d,0x1f,0x1d,10);
    FUN_0105dc48(0x29,0x1d,0x4f,0x1d,10);
    FUN_0105dc48(0x20,0x1d,0x28,0x1d,7);
    in_D0 = 0;
    FUN_0105dc48(0,0x1e,0x4f,0x28);
    FUN_0105a8c4(1,0,0x10);
    FUN_0105a8c4(2,0x1d,0xd);
    FUN_0105a8fa(1,0,0x10);
    FUN_0105a8fa(2,0x1d,0xd);
    FUN_0105a9c0();
  }
  else if (param_1 == '\0') {
    FUN_0105a8c4(1,0,0x1d);
    FUN_0105a8c4(2,0,0);
    FUN_0105a8fa(1,0,0x1d);
    in_D0 = 0;
    FUN_0105a8fa(2,0);
    FUN_0105a9c0();
  }
  return in_D0;
}


// ==== FUN_01058bc6 @ 01058bc6

undefined4 FUN_01058bc6(char param_1)

{
  undefined4 in_D0;
  char local_5;
  
  if (param_1 == '\x01') {
    for (local_5 = '\x1d'; local_5 < ':'; local_5 = local_5 + '\x01') {
      FUN_0105e89e((int)local_5);
      if (DAT_0103fa3d == 'c') {
        FUN_0105d63c(0,(int)local_5,0x4f,(int)local_5,0,0);
      }
    }
    for (local_5 = '\0'; local_5 < '\b'; local_5 = local_5 + '\x01') {
      if (DAT_0103fa3d == 'c') {
        FUN_0105e012(0,(int)local_5,0,(int)local_5,7,0x89);
        FUN_0105e012(1,(int)local_5,0x4e,(int)local_5,0,0x20);
        FUN_0105e012(0x4f,(int)local_5,0x4f,(int)local_5,7,0x90);
      }
      else {
        FUN_0105e012(0,(int)local_5,0x4f,(int)local_5,0,0x20);
      }
    }
    for (local_5 = '\x1d'; local_5 < ':'; local_5 = local_5 + '\x01') {
      FUN_0105e012(0,(int)local_5,0x4f,(int)local_5,0,0x20);
    }
    FUN_0105d368(0,0x1d,"--------------------",10,0);
    FUN_0105d368(0xc,0x1d,"--------------------",10,0);
    FUN_0105d368(0x29,0x1d,"--------------------",10,0);
    FUN_0105d368(0x3c,0x1d,"--------------------",10,0);
    FUN_0105d368(0x21,0x1d,"Message",10,0);
    FUN_0105dc48(0,0x1d,0x1f,0x1d,10);
    FUN_0105dc48(0x29,0x1d,0x4f,0x1d,10);
    FUN_0105dc48(0x20,0x1d,0x28,0x1d,7);
    FUN_0105dc48(0,0x32,0x4f,0x38,8);
    in_D0 = 0;
    FUN_0105dc48(0,0x1e,0x4f,0x31);
    FUN_0105a8c4(1,0,3);
    FUN_0105a8c4(2,0x32,5);
    FUN_0105a8c4(3,0x1d,0x15);
    FUN_0105a8fa(1,0,8);
    FUN_0105a8fa(2,0x1d,0x15);
    FUN_0105a9c0();
  }
  else if (param_1 == '\0') {
    if (DAT_0103fa3d == 'c') {
      FUN_0105e012(0,0,0,0x1c,7,0x89);
      FUN_0105e012(0x4f,0,0x4f,0x1c,7,0x90);
      for (local_5 = '\0'; local_5 < '\x1d'; local_5 = local_5 + '\x01') {
        FUN_0105e012(1,(int)local_5,0x4e,(int)local_5,0,0x20);
      }
    }
    FUN_01055fd6(1);
    FUN_0105854a(1);
    FUN_0105a8c4(1,0,0x1d);
    FUN_0105a8fa(1,0,0x1d);
    FUN_0105a9c0();
  }
  return in_D0;
}


// ==== FUN_01058f82 @ 01058f82

int FUN_01058f82(char param_1,char param_2,undefined4 param_3)

{
  int in_D0;
  int local_c;
  
  if (param_1 == '\x01') {
    local_c = 0;
    FUN_0105d368(0,param_2 + 0xc,param_3,7);
  }
  else {
    local_c = in_D0;
    if (param_1 == '\0') {
      local_c = param_2 + 0xc;
      FUN_0105e89e();
    }
  }
  return local_c;
}


// ==== FUN_01058fd8 @ 01058fd8

void FUN_01058fd8(char param_1)

{
  if (param_1 == '\x01') {
    FUN_01051b08(1);
    FUN_01051bd6(1,1,4,&DAT_0103b248);
    FUN_01051bd6(1,2,6,"OPTION");
    FUN_01051bd6(1,3,4,&DAT_0103b25c);
    FUN_01051bd6(1,4,4,&DAT_0103b266);
    FUN_01051bd6(1,5,8,"        ");
    FUN_01051bd6(1,6,6,"RESULT");
    FUN_01051bd6(1,7,8,"        ");
    FUN_01051bd6(1,8,4,&DAT_0103b28e);
  }
  else if (param_1 == '\0') {
    FUN_01051b08(0);
    FUN_01051bd6(0,0,0,0);
  }
  return;
}


// ==== FUN_01059172 @ 01059172

void FUN_01059172(char param_1)

{
  if (param_1 == '\x01') {
    FUN_0105d368(0,0x1f,"DIP-SW = ",7,0);
    FUN_0105d368(0,0x21,"  b8  b7  b6    Video System",7,0);
    FUN_0105d368(0,0x24,"  b5  b4        Boot Drive",7,0);
    FUN_0105d368(0,0x27,"  b3  b2  b1    Operating Mode",7,0);
  }
  else if (param_1 == '\0') {
    FUN_0105e89e(0x1f);
    FUN_0105e89e(0x21);
    FUN_0105e89e(0x24);
    FUN_0105e89e(0x27);
  }
  return;
}


// ==== FUN_0105922e @ 0105922e

undefined4 FUN_0105922e(char param_1,undefined4 param_2)

{
  undefined4 in_D0;
  undefined4 local_c;
  
  if (param_1 == '\x01') {
    local_c = 0;
    FUN_0105d368(9,0x1f,param_2,7);
  }
  else {
    local_c = in_D0;
    if (param_1 == '\0') {
      local_c = 0;
      FUN_0105d368(9,0x1f,&DAT_0105922a,7);
    }
  }
  return local_c;
}


// ==== FUN_0105928a @ 0105928a

void FUN_0105928a(char param_1)

{
  if (param_1 == '\x01') {
    FUN_0105d368(0,0x1f,"EEPROM Version = ",7,0);
    FUN_0105d368(0,0x25,"Memories Check",7,0);
    FUN_0105d368(0,0x27,"Address = ",7,0);
  }
  else if (param_1 == '\0') {
    FUN_0105e89e(0x1f);
    FUN_0105e89e(0x25);
    FUN_0105e89e(0x27);
  }
  return;
}


// ==== FUN_010593d4 @ 010593d4

void FUN_010593d4(char param_1)

{
  if (param_1 == '\x01') {
    FUN_0105d368(0,0x27,"Write Address   Write Data      Read Data  Read Address",7,0);
  }
  else if (param_1 == '\0') {
    FUN_0105e89e(0x27);
  }
  return;
}


// ==== FUN_01059414 @ 01059414

void FUN_01059414(char param_1)

{
  if (param_1 == '\x01') {
    FUN_0105d368(0,0x1f,"CH      Cmd     Count    Ref     IRQ     Rsult",7,0);
  }
  else if (param_1 == '\0') {
    FUN_0105e89e(0x1f);
  }
  return;
}


// ==== FUN_0105946e @ 0105946e

undefined4 FUN_0105946e(char param_1,undefined4 param_2)

{
  undefined4 in_D0;
  undefined4 local_c;
  
  if (param_1 == '\x01') {
    local_c = 0;
    FUN_0105d368(2,0x20,param_2,7);
  }
  else {
    local_c = in_D0;
    if (param_1 == '\0') {
      local_c = 0;
      FUN_0105d368(2,0x20,"                        ",0);
    }
  }
  return local_c;
}


// ==== FUN_010594e2 @ 010594e2

undefined4 FUN_010594e2(char param_1,undefined4 param_2)

{
  undefined4 in_D0;
  undefined4 local_c;
  
  if (param_1 == '\x01') {
    local_c = 0;
    FUN_0105d368(0x1e,0x20,param_2,7);
  }
  else {
    local_c = in_D0;
    if (param_1 == '\0') {
      local_c = 0;
      FUN_0105d368(0x1e,0x20,"                        ",0);
    }
  }
  return local_c;
}


// ==== FUN_0105953c @ 0105953c

void FUN_0105953c(char param_1)

{
  if (param_1 == '\x01') {
    FUN_0105d368(7,0x1f,"REF TIME",7,0);
    FUN_0105d368(0x21,0x1f,"Timer Read Out",7,0);
  }
  else if (param_1 == '\0') {
    FUN_0105e89e(0x1f);
    FUN_0105e89e(0x20);
  }
  return;
}


// ==== FUN_01059604 @ 01059604

void FUN_01059604(char param_1,undefined4 param_2)

{
  if (param_1 == '\x01') {
    FUN_0105d368(0x38,0x20,param_2,7,0);
  }
  else if (param_1 == '\0') {
    FUN_0105e84a(0x38,0x20);
  }
  return;
}


// ==== FUN_01059654 @ 01059654

void FUN_01059654(char param_1)

{
  if (param_1 == '\x01') {
    FUN_0105d368(0,0x1f,"Address = ",7,0);
  }
  else if (param_1 == '\0') {
    FUN_0105e89e(0x1f);
  }
  return;
}


// ==== FUN_0105969e @ 0105969e

undefined4 FUN_0105969e(char param_1,undefined4 param_2)

{
  undefined4 in_D0;
  undefined4 local_c;
  
  if (param_1 == '\x01') {
    local_c = 0;
    FUN_0105d368(10,0x1f,param_2,7);
  }
  else {
    local_c = in_D0;
    if (param_1 == '\0') {
      local_c = 0;
      FUN_0105d368(10,0x1f,"        ",0);
    }
  }
  return local_c;
}


// ==== FUN_010596f8 @ 010596f8

void FUN_010596f8(char param_1)

{
  if (param_1 == '\x01') {
    FUN_0105d368(0,0x1f,"Write Address   Write Data      Read Address   Read Data",7,0);
  }
  else if (param_1 == '\0') {
    FUN_0105e89e(0x1f);
  }
  return;
}


// ==== FUN_01059738 @ 01059738

void FUN_01059738(char param_1)

{
  if (param_1 == '\x01') {
    FUN_0105d368(0,0x1f,"DRIVE    MODE  SIDE  TRACK  SECTOR  RESULT",7,0);
  }
  else if (param_1 == '\0') {
    FUN_0105e89e(0x1f);
  }
  return;
}


// ==== FUN_0105977a @ 0105977a

undefined4 FUN_0105977a(char param_1,char param_2,undefined4 param_3)

{
  undefined4 in_D0;
  undefined4 local_c;
  
  if (param_1 == '\x01') {
    local_c = 0;
    FUN_0105d368(0,param_2 + 0xc,param_3,7);
  }
  else {
    local_c = in_D0;
    if (param_1 == '\0') {
      local_c = 0;
      FUN_0105d368(0,param_2 + 0xc,&DAT_01059778,0);
    }
  }
  return local_c;
}


// ==== FUN_010599aa @ 010599aa

undefined4 FUN_010599aa(char param_1,char param_2,undefined4 param_3)

{
  undefined4 in_D0;
  undefined4 local_c;
  
  if (param_1 == '\x01') {
    local_c = 0;
    FUN_0105d368(0x24,param_2 + 0xc,param_3,7);
  }
  else {
    local_c = in_D0;
    if (param_1 == '\0') {
      local_c = 0;
      FUN_0105d368(0x24,param_2 + 0xc,"                    ",0);
    }
  }
  return local_c;
}


// ==== FUN_01059a14 @ 01059a14

void FUN_01059a14(char param_1)

{
  if (param_1 == '\x01') {
    FUN_0105d368(0,0x1f,"Video System    REF VIDEO    CF    FIELD(Validity)    FRAME",7,0);
  }
  else if (param_1 == '\0') {
    FUN_0105e89e(0x1f);
  }
  return;
}


// ==== FUN_01059a5c @ 01059a5c

undefined4 FUN_01059a5c(char param_1,char param_2,undefined4 param_3)

{
  undefined4 in_D0;
  undefined4 local_c;
  
  if (param_1 == '\x01') {
    local_c = 0;
    FUN_0105d368(2,param_2 + 0xc,param_3,7);
  }
  else {
    local_c = in_D0;
    if (param_1 == '\0') {
      local_c = 0;
      FUN_0105d368(2,param_2 + 0xc,"      ",7);
    }
  }
  return local_c;
}


// ==== FUN_01059aca @ 01059aca

undefined4 FUN_01059aca(char param_1,char param_2,undefined4 param_3)

{
  undefined4 in_D0;
  undefined4 local_c;
  
  if (param_1 == '\x01') {
    local_c = 0;
    FUN_0105d368(0x13,param_2 + 0xc,param_3,7);
  }
  else {
    local_c = in_D0;
    if (param_1 == '\0') {
      local_c = 0;
      FUN_0105d368(0x13,param_2 + 0xc,&DAT_01059ac8,7);
    }
  }
  return local_c;
}


// ==== FUN_01059b3a @ 01059b3a

undefined4 FUN_01059b3a(char param_1,char param_2,undefined4 param_3)

{
  undefined4 in_D0;
  undefined4 local_c;
  
  if (param_1 == '\x01') {
    local_c = 0;
    FUN_0105d368(0x1c,param_2 + 0xc,param_3,7);
  }
  else {
    local_c = in_D0;
    if (param_1 == '\0') {
      local_c = 0;
      FUN_0105d368(0x1c,param_2 + 0xc,&DAT_01059b36,7);
    }
  }
  return local_c;
}


// ==== FUN_01059bac @ 01059bac

undefined4 FUN_01059bac(char param_1,char param_2,undefined4 param_3)

{
  undefined4 in_D0;
  undefined4 local_c;
  
  if (param_1 == '\x01') {
    local_c = 0;
    FUN_0105d368(0x25,param_2 + 0xc,param_3,7);
  }
  else {
    local_c = in_D0;
    if (param_1 == '\0') {
      local_c = 0;
      FUN_0105d368(0x25,param_2 + 0xc,"     ",7);
    }
  }
  return local_c;
}


// ==== FUN_01059c1e @ 01059c1e

undefined4 FUN_01059c1e(char param_1,char param_2,undefined4 param_3)

{
  undefined4 in_D0;
  undefined4 local_c;
  
  if (param_1 == '\x01') {
    local_c = 0;
    FUN_0105d368(0x36,param_2 + 0xc,param_3,7);
  }
  else {
    local_c = in_D0;
    if (param_1 == '\0') {
      local_c = 0;
      FUN_0105d368(0x36,param_2 + 0xc,"     ",7);
    }
  }
  return local_c;
}


// ==== FUN_01059c8a @ 01059c8a

void FUN_01059c8a(char param_1)

{
  if (param_1 == '\x01') {
    FUN_0105d368(0,0x1f,"Char  Parity  Stop  Baud Rate    Rsult",7,0);
    FUN_0105d368(0x37,0x1f,"Adr    W-data    R-data",7,0);
  }
  else if (param_1 == '\0') {
    FUN_0105e89e(0x1f);
  }
  return;
}


// ==== FUN_01059ea6 @ 01059ea6

void FUN_01059ea6(char param_1,char param_2,undefined4 param_3)

{
  int iVar1;
  int iVar2;
  undefined2 uVar3;
  ushort local_8;
  ushort local_6;
  
  if (param_1 == '\0') {
    for (local_6 = 0x20; local_6 < 0x28; local_6 = local_6 + 1) {
      FUN_0105e89e(local_6);
    }
    return;
  }
  if ((param_2 < '\x01') || ('\b' < param_2)) {
    if ('\b' < param_2) {
      for (local_6 = 0x20; local_6 < 0x27; local_6 = local_6 + 1) {
        iVar1 = *(int *)(&DAT_0103fa38 + (uint)local_6 * 0x140);
        iVar2 = *(int *)(&DAT_0103fa38 + (uint)local_6 * 0x140);
        for (local_8 = 0; local_8 < 0xa0; local_8 = local_8 + 2) {
          uVar3 = *(undefined2 *)(iVar2 + 0x142 + (uint)local_8 * 2);
          *(undefined2 *)(iVar1 + (uint)local_8 * 2) =
               *(undefined2 *)(iVar2 + 0x140 + (uint)local_8 * 2);
          *(undefined2 *)(iVar1 + 2 + (uint)local_8 * 2) = uVar3;
        }
      }
      FUN_0105e89e(0x27);
      FUN_0105d368(0,0x27,param_3,7,0);
    }
  }
  else {
    FUN_0105d368(0,param_2 + 0x1f,param_3,7,0);
  }
  return;
}


// ==== FUN_01059fe6 @ 01059fe6

void FUN_01059fe6(char param_1,char param_2,undefined4 param_3)

{
  if (param_1 == '\x01') {
    FUN_0105d368(0x37,param_2 + 0xc,param_3,7,0);
  }
  else if (param_1 == '\0') {
    FUN_0105e84a(0x37,param_2 + 0xc);
  }
  return;
}


// ==== FUN_0105a03a @ 0105a03a

void FUN_0105a03a(char param_1)

{
  if (param_1 == '\x01') {
    FUN_0105d368(0,0x1f,"Display Mode : ",7,0);
  }
  else {
    FUN_0105e89e(0x1f);
  }
  return;
}


// ==== FUN_0105a074 @ 0105a074

void FUN_0105a074(char param_1,undefined4 param_2)

{
  if (param_1 == '\x01') {
    FUN_0105d368(0xf,0x1f,param_2,7,0);
  }
  else {
    FUN_0105e84a(0xf,0x1f);
  }
  return;
}


// ==== FUN_0105a0b2 @ 0105a0b2

void FUN_0105a0b2(char param_1)

{
  if (param_1 == '\x01') {
    FUN_0105d368(0,0x1f,"Halftone Check",7,0);
    FUN_0105d368(7,0x21,"Normal",7,0);
    FUN_0105d368(0x1b,0x21,"Blink",7,0);
    FUN_0105d368(0x2e,0x21,"Reverse",7,0);
    FUN_0105d368(0x3f,0x21,"Reverse-Blink",7,0);
  }
  else if (param_1 == '\0') {
    FUN_0105e89e(0x1f);
    FUN_0105e89e(0x21);
  }
  return;
}


// ==== FUN_0105a178 @ 0105a178

void FUN_0105a178(char param_1)

{
  if (param_1 == '\x01') {
    FUN_0105d368(0,0x1f,"MB0 Character Generator Check",7,0);
  }
  else if (param_1 == '\0') {
    FUN_0105e89e(0x1f);
  }
  return;
}


// ==== FUN_0105a1b8 @ 0105a1b8

void FUN_0105a1b8(char param_1)

{
  if (param_1 == '\x01') {
    FUN_0105d368(0,0x1f,"Main Screen Cursor Check",7,0);
  }
  else if (param_1 == '\0') {
    FUN_0105e89e(0x1f);
  }
  return;
}


// ==== FUN_0105a1f8 @ 0105a1f8

void FUN_0105a1f8(char param_1)

{
  if (param_1 == '\x01') {
    FUN_0105d368(0,0x1e,"Slot Number  Board Name  Board ID  Version",7,0);
    FUN_0105d368(0x2e,0x1e,"CH    IDC-Version $ Status",7,0);
  }
  else if (param_1 == '\0') {
    FUN_0105e89e(0x1e);
  }
  return;
}


// ==== FUN_0105a256 @ 0105a256

void FUN_0105a256(char param_1)

{
  if (param_1 == '\x01') {
    FUN_0105d368(0,0x1e,"Slot Number  Board Name  Board ID  Version",7,0);
    FUN_0105d368(0x2e,0x1e,"CH    Version $ Status",7,0);
  }
  else if (param_1 == '\0') {
    FUN_0105e89e(0x1e);
  }
  return;
}


// ==== FUN_0105a2c2 @ 0105a2c2

void FUN_0105a2c2(char param_1)

{
  if (param_1 == '\x01') {
    FUN_0105d368(6,0x1f,"Key-in Please",7,0);
  }
  else if (param_1 == '\0') {
    FUN_0105e89e(0x1f);
  }
  return;
}


// ==== FUN_0105a30c @ 0105a30c

undefined4 FUN_0105a30c(char param_1,undefined1 *param_2)

{
  undefined4 in_D0;
  undefined1 local_a;
  undefined1 local_9;
  undefined1 local_8;
  undefined1 local_7;
  undefined1 local_6;
  undefined1 local_5;
  
  if (param_1 == '\x01') {
    FUN_0105d368(8,0x22,"Data = ",7,0);
    if (param_2[2] == '\0') {
      local_a = *param_2;
      local_9 = param_2[1];
      local_7 = 0x20;
      local_6 = 0x20;
    }
    else {
      local_a = *param_2;
      local_9 = param_2[1];
      local_7 = param_2[2];
      local_6 = param_2[3];
    }
    local_5 = 0;
    local_8 = 0x20;
    in_D0 = 0;
    FUN_0105d368(0xf,0x22,&local_a,7);
  }
  else if (param_1 == '\0') {
    FUN_0105e89e(0x22);
  }
  return in_D0;
}


// ==== FUN_0105a3c0 @ 0105a3c0

void FUN_0105a3c0(byte param_1,char param_2,char param_3,byte param_4)

{
  if (0xf < param_1) {
    return;
  }
  param_4 = param_4 & 0x3f;
  if (param_2 == '\0') {
    if (param_3 == '\0') {
      **(byte **)(&DAT_0103fa30 + (uint)param_1 * 0x10) =
           **(byte **)(&DAT_0103fa30 + (uint)param_1 * 0x10) & 0xc0;
      **(byte **)(&DAT_0103fa30 + (uint)param_1 * 0x10) =
           param_4 | **(byte **)(&DAT_0103fa30 + (uint)param_1 * 0x10);
    }
    else if (param_3 == '\x01') {
      *(byte *)(*(int *)(&DAT_0103fa30 + (uint)param_1 * 0x10) + 1) =
           *(byte *)(*(int *)(&DAT_0103fa30 + (uint)param_1 * 0x10) + 1) & 0xc0;
      *(byte *)(*(int *)(&DAT_0103fa30 + (uint)param_1 * 0x10) + 1) =
           param_4 | *(byte *)(*(int *)(&DAT_0103fa30 + (uint)param_1 * 0x10) + 1);
    }
    else if (param_3 == '\x02') {
      *(byte *)(*(int *)(&DAT_0103fa30 + (uint)param_1 * 0x10) + 2) =
           *(byte *)(*(int *)(&DAT_0103fa30 + (uint)param_1 * 0x10) + 2) & 0xc0;
      *(byte *)(*(int *)(&DAT_0103fa30 + (uint)param_1 * 0x10) + 2) =
           param_4 | *(byte *)(*(int *)(&DAT_0103fa30 + (uint)param_1 * 0x10) + 2);
    }
  }
  else if (param_2 == '\x01') {
    if (param_3 == '\0') {
      *(byte *)(*(int *)(&DAT_0103fa30 + (uint)param_1 * 0x10) + 4) =
           *(byte *)(*(int *)(&DAT_0103fa30 + (uint)param_1 * 0x10) + 4) & 0xc0;
      *(byte *)(*(int *)(&DAT_0103fa30 + (uint)param_1 * 0x10) + 4) =
           param_4 | *(byte *)(*(int *)(&DAT_0103fa30 + (uint)param_1 * 0x10) + 4);
    }
    else if (param_3 == '\x01') {
      *(byte *)(*(int *)(&DAT_0103fa30 + (uint)param_1 * 0x10) + 5) =
           *(byte *)(*(int *)(&DAT_0103fa30 + (uint)param_1 * 0x10) + 5) & 0xc0;
      *(byte *)(*(int *)(&DAT_0103fa30 + (uint)param_1 * 0x10) + 5) =
           param_4 | *(byte *)(*(int *)(&DAT_0103fa30 + (uint)param_1 * 0x10) + 5);
    }
    else if (param_3 == '\x02') {
      *(byte *)(*(int *)(&DAT_0103fa30 + (uint)param_1 * 0x10) + 6) =
           *(byte *)(*(int *)(&DAT_0103fa30 + (uint)param_1 * 0x10) + 6) & 0xc0;
      *(byte *)(*(int *)(&DAT_0103fa30 + (uint)param_1 * 0x10) + 6) =
           param_4 | *(byte *)(*(int *)(&DAT_0103fa30 + (uint)param_1 * 0x10) + 6);
    }
  }
  else if (param_2 == '\x02') {
    if (param_3 == '\0') {
      *(byte *)(*(int *)(&DAT_0103fa30 + (uint)param_1 * 0x10) + 8) =
           *(byte *)(*(int *)(&DAT_0103fa30 + (uint)param_1 * 0x10) + 8) & 0xc0;
      *(byte *)(*(int *)(&DAT_0103fa30 + (uint)param_1 * 0x10) + 8) =
           param_4 | *(byte *)(*(int *)(&DAT_0103fa30 + (uint)param_1 * 0x10) + 8);
    }
    else if (param_3 == '\x01') {
      *(byte *)(*(int *)(&DAT_0103fa30 + (uint)param_1 * 0x10) + 9) =
           *(byte *)(*(int *)(&DAT_0103fa30 + (uint)param_1 * 0x10) + 9) & 0xc0;
      *(byte *)(*(int *)(&DAT_0103fa30 + (uint)param_1 * 0x10) + 9) =
           param_4 | *(byte *)(*(int *)(&DAT_0103fa30 + (uint)param_1 * 0x10) + 9);
    }
    else if (param_3 == '\x02') {
      *(byte *)(*(int *)(&DAT_0103fa30 + (uint)param_1 * 0x10) + 10) =
           *(byte *)(*(int *)(&DAT_0103fa30 + (uint)param_1 * 0x10) + 10) & 0xc0;
      *(byte *)(*(int *)(&DAT_0103fa30 + (uint)param_1 * 0x10) + 10) =
           param_4 | *(byte *)(*(int *)(&DAT_0103fa30 + (uint)param_1 * 0x10) + 10);
    }
  }
  else if (param_2 == '\x03') {
    if (param_3 == '\0') {
      *(byte *)(*(int *)(&DAT_0103fa30 + (uint)param_1 * 0x10) + 0xc) =
           *(byte *)(*(int *)(&DAT_0103fa30 + (uint)param_1 * 0x10) + 0xc) & 0xc0;
      *(byte *)(*(int *)(&DAT_0103fa30 + (uint)param_1 * 0x10) + 0xc) =
           param_4 | *(byte *)(*(int *)(&DAT_0103fa30 + (uint)param_1 * 0x10) + 0xc);
    }
    else if (param_3 == '\x01') {
      *(byte *)(*(int *)(&DAT_0103fa30 + (uint)param_1 * 0x10) + 0xd) =
           *(byte *)(*(int *)(&DAT_0103fa30 + (uint)param_1 * 0x10) + 0xd) & 0xc0;
      *(byte *)(*(int *)(&DAT_0103fa30 + (uint)param_1 * 0x10) + 0xd) =
           param_4 | *(byte *)(*(int *)(&DAT_0103fa30 + (uint)param_1 * 0x10) + 0xd);
    }
    else if (param_3 == '\x02') {
      *(byte *)(*(int *)(&DAT_0103fa30 + (uint)param_1 * 0x10) + 0xe) =
           *(byte *)(*(int *)(&DAT_0103fa30 + (uint)param_1 * 0x10) + 0xe) & 0xc0;
      *(byte *)(*(int *)(&DAT_0103fa30 + (uint)param_1 * 0x10) + 0xe) =
           param_4 | *(byte *)(*(int *)(&DAT_0103fa30 + (uint)param_1 * 0x10) + 0xe);
    }
  }
  return;
}


// ==== FUN_0105a67a @ 0105a67a

void FUN_0105a67a(byte param_1,char param_2,byte param_3)

{
  byte *pbVar1;
  
  if (0xf < param_1) {
    return;
  }
  param_3 = param_3 & 0x3f;
  if (param_2 == '\0') {
    pbVar1 = (byte *)(DAT_0103fa2c + (uint)param_1 * 4);
    *pbVar1 = *pbVar1 & 0xc0;
    pbVar1 = (byte *)(DAT_0103fa2c + (uint)param_1 * 4);
    *pbVar1 = param_3 | *pbVar1;
  }
  else if (param_2 == '\x01') {
    pbVar1 = (byte *)(DAT_0103fa2c + 1 + (uint)param_1 * 4);
    *pbVar1 = *pbVar1 & 0xc0;
    pbVar1 = (byte *)(DAT_0103fa2c + 1 + (uint)param_1 * 4);
    *pbVar1 = param_3 | *pbVar1;
  }
  else if (param_2 == '\x02') {
    pbVar1 = (byte *)(DAT_0103fa2c + 2 + (uint)param_1 * 4);
    *pbVar1 = *pbVar1 & 0xc0;
    pbVar1 = (byte *)(DAT_0103fa2c + 2 + (uint)param_1 * 4);
    *pbVar1 = param_3 | *pbVar1;
  }
  return;
}


// ==== FUN_0105a720 @ 0105a720

void FUN_0105a720(char param_1)

{
  ushort local_6;
  
  local_6 = (ushort)(param_1 != '\0');
  *(byte *)((int)DAT_0103fa14 + 1) = *(byte *)((int)DAT_0103fa14 + 1) & 0xfe;
  *DAT_0103fa14 = local_6 | *DAT_0103fa14;
  return;
}


// ==== FUN_0105a752 @ 0105a752

void FUN_0105a752(char param_1)

{
  ushort local_6;
  
  if (param_1 == '\0') {
    local_6 = 0;
  }
  else {
    local_6 = 0x4000;
  }
  *(byte *)DAT_0103fa14 = *(byte *)DAT_0103fa14 & 0xbf;
  *DAT_0103fa14 = local_6 | *DAT_0103fa14;
  return;
}


// ==== FUN_0105a782 @ 0105a782

void FUN_0105a782(char param_1)

{
  ushort local_6;
  
  if (param_1 == '\0') {
    local_6 = 0;
  }
  else {
    local_6 = 0x8000;
  }
  *(byte *)DAT_0103fa14 = *(byte *)DAT_0103fa14 & 0x7f;
  *DAT_0103fa14 = local_6 | *DAT_0103fa14;
  return;
}


// ==== FUN_0105a7b2 @ 0105a7b2

void FUN_0105a7b2(void)

{
  if ((*DAT_0103fa10 & 0x40) == 0) {
    return;
  }
  return;
}


// ==== FUN_0105a7c6 @ 0105a7c6

void FUN_0105a7c6(ushort param_1,ushort param_2,byte param_3)

{
  uint *puVar1;
  ushort uStack_a;
  undefined2 local_8;
  ushort uStack_6;
  
  puVar1 = (uint *)((uint)param_1 * 4 + *(int *)(&DAT_0103fa38 + (uint)param_2 * 0x140));
  uStack_a = 0;
  if ((param_3 & 0x10) == 0x10) {
    uStack_a = 0x8000;
  }
  if ((param_3 & 8) == 8) {
    uStack_a = uStack_a | 0x4000;
  }
  uStack_6 = uStack_a | (ushort)(*puVar1 & 0xffff3fff);
  local_8 = (undefined2)((*puVar1 & 0xffff3fff) >> 0x10);
  *(undefined2 *)puVar1 = local_8;
  *(ushort *)((int)puVar1 + 2) = uStack_6;
  return;
}


// ==== FUN_0105a852 @ 0105a852

void FUN_0105a852(ushort param_1,ushort param_2,byte param_3)

{
  uint uVar1;
  ushort *puVar2;
  ushort local_c;
  undefined4 local_8;
  
  puVar2 = (ushort *)((uint)param_1 * 4 + *(int *)(&DAT_0103fa34 + (uint)param_2 * 0x140));
  local_8._0_1_ = (undefined1)(*puVar2 >> 8);
  local_8._1_3_ = (undefined3)*(undefined4 *)puVar2;
  local_8 = CONCAT13(local_8._0_1_,local_8._1_3_) & 0xbfffffff;
  uVar1 = local_8;
  local_c = 0;
  if ((param_3 & 8) == 8) {
    local_c = 0x4000;
  }
  local_8._0_2_ = local_c | (ushort)(local_8 >> 0x10);
  *puVar2 = local_8._0_2_;
  local_8._2_2_ = (ushort)uVar1;
  puVar2[1] = local_8._2_2_;
  return;
}


// ==== FUN_0105a8c4 @ 0105a8c4

void FUN_0105a8c4(char param_1,short param_2,undefined2 param_3)

{
  *(short *)(*(int *)((int)&DAT_0103fa28 + param_1 * 2) + -2) = param_2 * 0x50;
  *(undefined2 *)(*(int *)((int)&DAT_0103fa20 + param_1 * 2) + -2) = param_3;
  return;
}


// ==== FUN_0105a8fa @ 0105a8fa

void FUN_0105a8fa(char param_1,short param_2,undefined2 param_3)

{
  *(short *)(*(int *)((int)&DAT_0103fa24 + param_1 * 2) + -2) = param_2 * 0x50;
  *(undefined2 *)(*(int *)((int)&DAT_0103fa1c + param_1 * 2) + -2) = param_3;
  return;
}


// ==== FUN_0105a930 @ 0105a930

void FUN_0105a930(short param_1,short param_2,byte *param_3,int param_4)

{
  *DAT_0103fa18 = param_1 + param_2 * 0x50;
  *(byte *)(DAT_0103fa18 + 1) = *(byte *)(DAT_0103fa18 + 1) & 0x80;
  *(byte *)(DAT_0103fa18 + 1) = *param_3 & 0x7f | *(byte *)(DAT_0103fa18 + 1);
  *(byte *)((int)DAT_0103fa18 + 3) = *(byte *)((int)DAT_0103fa18 + 3) & 0xe0;
  *(byte *)((int)DAT_0103fa18 + 3) = param_3[1] & 0x1f | *(byte *)((int)DAT_0103fa18 + 3);
  *(byte *)((int)DAT_0103fa18 + 5) = *(byte *)((int)DAT_0103fa18 + 5) & 0xe0;
  *(byte *)((int)DAT_0103fa18 + 5) =
       *(byte *)(param_4 + 1) & 0x1f | *(byte *)((int)DAT_0103fa18 + 5);
  return;
}


// ==== FUN_0105a9c0 @ 0105a9c0

void FUN_0105a9c0(void)

{
  uint local_8;
  
  *DAT_0103fa0c = 0xffff;
  for (local_8 = 0; local_8 < 800; local_8 = local_8 + 1) {
  }
  return;
}


// ==== FUN_0105a9e6 @ 0105a9e6

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

undefined4 FUN_0105a9e6(void)

{
  int unaff_D7;
  undefined2 *puVar1;
  undefined4 uVar2;
  undefined1 uStack_14;
  undefined1 local_13;
  undefined1 local_12;
  undefined1 local_11;
  uint local_10;
  uint local_c;
  undefined4 local_8;
  
  _DAT_0103fa38 = 0xd000000;
  _DAT_0103fa34 = 0xd010000;
  _DAT_0103fa30 = 0xd01c800;
  DAT_0103fa2c = 0xd01c900;
  DAT_0103fa28 = 0xd01c980;
  DAT_0103fa24 = 0xd01c988;
  DAT_0103fa20 = 0xd01c990;
  DAT_0103fa1c = 0xd01c998;
  DAT_0103fa18 = 0xd01c9a0;
  DAT_0103fa14 = 0xd01c9c0;
  DAT_0103fa10 = 0xd01c9c8;
  DAT_0103fa0c = 0xd01cffe;
  FUN_0105a752(0);
  FUN_0105a782(0);
  FUN_0105a9c0();
  DAT_0103fa3d = 'c';
  FUN_0105a7b2();
  if (unaff_D7 == 1) {
    DAT_0103fa3d = 'm';
  }
  for (local_10 = 0; local_10 < 0xcc; local_10 = local_10 + 1) {
    for (local_c = 0; local_c < 0x50; local_c = local_c + 1) {
      puVar1 = (undefined2 *)(local_c * 4 + *(int *)(&DAT_0103fa38 + local_10 * 0x140));
      *puVar1 = 0x20;
      puVar1[1] = 0x3000;
    }
  }
  local_c = 0;
  local_8 = 0xb820ff00;
  for (local_10 = 0; local_10 < 0x99; local_10 = local_10 + 1) {
    for (local_c = 0; local_c < 0x50; local_c = local_c + 1) {
      puVar1 = (undefined2 *)(local_c * 4 + *(int *)(&DAT_0103fa34 + local_10 * 0x140));
      *puVar1 = 0xb820;
      puVar1[1] = 0xff00;
    }
  }
  FUN_0105a8c4(1,0,0x1d);
  FUN_0105a8c4(2,0,0);
  FUN_0105a8c4(3,0,0);
  FUN_0105a8c4(4,0,0);
  FUN_0105a8fa(1,0,0x1d);
  FUN_0105a8fa(2,0,0);
  FUN_0105a8fa(3,0,0);
  uVar2 = 0;
  FUN_0105a8fa(4,0);
  local_12 = 0x28;
  local_11 = 8;
  local_13 = 7;
  FUN_0105a930(0,0,&local_12,&uStack_14);
  if (DAT_0103fa3d == 'c') {
    FUN_0105ac98();
  }
  else {
    FUN_0105c06c();
  }
  FUN_0105a782(1);
  FUN_0105a752(1);
  FUN_0105a9c0();
  return uVar2;
}


// ==== FUN_0105ac98 @ 0105ac98

void FUN_0105ac98(void)

{
  FUN_0105a3c0(0,0,0,0);
  FUN_0105a3c0(0,0,1,0);
  FUN_0105a3c0(0,0,2,0);
  FUN_0105a3c0(0,1,0,0x3f);
  FUN_0105a3c0(0,1,1,0x3f);
  FUN_0105a3c0(0,1,2,0x3f);
  FUN_0105a3c0(0,2,0,0xf);
  FUN_0105a3c0(0,2,1,0xf);
  FUN_0105a3c0(0,2,2,0xf);
  FUN_0105a3c0(0,3,0,0x2f);
  FUN_0105a3c0(0,3,1,0x2f);
  FUN_0105a3c0(0,3,2,0x2f);
  FUN_0105a3c0(1,0,0,0x3f);
  FUN_0105a3c0(1,0,1,0);
  FUN_0105a3c0(1,0,2,0);
  FUN_0105a3c0(1,1,0,0x1f);
  FUN_0105a3c0(1,1,1,0);
  FUN_0105a3c0(1,1,2,0);
  FUN_0105a3c0(1,2,0,0x2f);
  FUN_0105a3c0(1,2,1,0);
  FUN_0105a3c0(1,2,2,0);
  FUN_0105a3c0(1,3,0,0xf);
  FUN_0105a3c0(1,3,1,0);
  FUN_0105a3c0(1,3,2,0);
  FUN_0105a3c0(2,0,0,0);
  FUN_0105a3c0(2,0,1,0x3f);
  FUN_0105a3c0(2,0,2,0);
  FUN_0105a3c0(2,1,0,0);
  FUN_0105a3c0(2,1,1,0x1f);
  FUN_0105a3c0(2,1,2,0);
  FUN_0105a3c0(2,2,0,0);
  FUN_0105a3c0(2,2,1,0x2f);
  FUN_0105a3c0(2,2,2,0);
  FUN_0105a3c0(2,3,0,0);
  FUN_0105a3c0(2,3,1,0xf);
  FUN_0105a3c0(2,3,2,0);
  FUN_0105a3c0(3,0,0,0x3f);
  FUN_0105a3c0(3,0,1,0x3f);
  FUN_0105a3c0(3,0,2,0);
  FUN_0105a3c0(3,1,0,0x1f);
  FUN_0105a3c0(3,1,1,0x1f);
  FUN_0105a3c0(3,1,2,0);
  FUN_0105a3c0(3,2,0,0x2f);
  FUN_0105a3c0(3,2,1,0x2f);
  FUN_0105a3c0(3,2,2,0);
  FUN_0105a3c0(3,3,0,0xf);
  FUN_0105a3c0(3,3,1,0xf);
  FUN_0105a3c0(3,3,2,0);
  FUN_0105a3c0(4,0,0,0);
  FUN_0105a3c0(4,0,1,0);
  FUN_0105a3c0(4,0,2,0x3f);
  FUN_0105a3c0(4,1,0,0);
  FUN_0105a3c0(4,1,1,0);
  FUN_0105a3c0(4,1,2,0x1f);
  FUN_0105a3c0(4,2,0,0);
  FUN_0105a3c0(4,2,1,0);
  FUN_0105a3c0(4,2,2,0x2f);
  FUN_0105a3c0(4,3,0,0);
  FUN_0105a3c0(4,3,1,0);
  FUN_0105a3c0(4,3,2,0xf);
  FUN_0105a3c0(5,0,0,0x3f);
  FUN_0105a3c0(5,0,1,0);
  FUN_0105a3c0(5,0,2,0x3f);
  FUN_0105a3c0(5,1,0,0x1f);
  FUN_0105a3c0(5,1,1,0);
  FUN_0105a3c0(5,1,2,0x1f);
  FUN_0105a3c0(5,2,0,0x2f);
  FUN_0105a3c0(5,2,1,0);
  FUN_0105a3c0(5,2,2,0x2f);
  FUN_0105a3c0(5,3,0,0xf);
  FUN_0105a3c0(5,3,1,0);
  FUN_0105a3c0(5,3,2,0xf);
  FUN_0105a3c0(6,0,0,0);
  FUN_0105a3c0(6,0,1,0x3f);
  FUN_0105a3c0(6,0,2,0x3f);
  FUN_0105a3c0(6,1,0,0);
  FUN_0105a3c0(6,1,1,0x1f);
  FUN_0105a3c0(6,1,2,0x1f);
  FUN_0105a3c0(6,2,0,0);
  FUN_0105a3c0(6,2,1,0x2f);
  FUN_0105a3c0(6,2,2,0x2f);
  FUN_0105a3c0(6,3,0,0);
  FUN_0105a3c0(6,3,1,0xf);
  FUN_0105a3c0(6,3,2,0xf);
  FUN_0105a3c0(7,0,0,0x3f);
  FUN_0105a3c0(7,0,1,0x3f);
  FUN_0105a3c0(7,0,2,0x3f);
  FUN_0105a3c0(7,1,0,0x1f);
  FUN_0105a3c0(7,1,1,0x1f);
  FUN_0105a3c0(7,1,2,0x1f);
  FUN_0105a3c0(7,2,0,0xf);
  FUN_0105a3c0(7,2,1,0xf);
  FUN_0105a3c0(7,2,2,0xf);
  FUN_0105a3c0(7,3,0,0x2f);
  FUN_0105a3c0(7,3,1,0x2f);
  FUN_0105a3c0(7,3,2,0x2f);
  FUN_0105a3c0(8,0,0,0);
  FUN_0105a3c0(8,0,1,0x1a);
  FUN_0105a3c0(8,0,2,0);
  FUN_0105a3c0(8,1,0,0);
  FUN_0105a3c0(8,1,1,0x36);
  FUN_0105a3c0(8,1,2,0);
  FUN_0105a3c0(8,2,0,0);
  FUN_0105a3c0(8,2,1,0x26);
  FUN_0105a3c0(8,2,2,0);
  FUN_0105a3c0(8,3,0,0);
  FUN_0105a3c0(8,3,1,6);
  FUN_0105a3c0(8,3,2,0);
  FUN_0105a3c0(9,0,0,0xf);
  FUN_0105a3c0(9,0,1,0xf);
  FUN_0105a3c0(9,0,2,0x2f);
  FUN_0105a3c0(9,1,0,0x1f);
  FUN_0105a3c0(9,1,1,0x1f);
  FUN_0105a3c0(9,1,2,0x3f);
  FUN_0105a3c0(9,2,0,0x17);
  FUN_0105a3c0(9,2,1,0x17);
  FUN_0105a3c0(9,2,2,0x37);
  FUN_0105a3c0(9,3,0,7);
  FUN_0105a3c0(9,3,1,7);
  FUN_0105a3c0(9,3,2,0x27);
  FUN_0105a3c0(10,0,0,0x2f);
  FUN_0105a3c0(10,0,1,0xf);
  FUN_0105a3c0(10,0,2,0);
  FUN_0105a3c0(10,1,0,0x27);
  FUN_0105a3c0(10,1,1,7);
  FUN_0105a3c0(10,1,2,0);
  FUN_0105a3c0(10,2,0,0x3f);
  FUN_0105a3c0(10,2,1,0x1f);
  FUN_0105a3c0(10,2,2,0);
  FUN_0105a3c0(10,3,0,0x37);
  FUN_0105a3c0(10,3,1,0x17);
  FUN_0105a3c0(10,3,2,0);
  FUN_0105a3c0(0xb,0,0,0x3f);
  FUN_0105a3c0(0xb,0,1,0x1f);
  FUN_0105a3c0(0xb,0,2,0x1f);
  FUN_0105a3c0(0xb,1,0,0x21);
  FUN_0105a3c0(0xb,1,1,1);
  FUN_0105a3c0(0xb,1,2,1);
  FUN_0105a3c0(0xb,2,0,0x27);
  FUN_0105a3c0(0xb,2,1,7);
  FUN_0105a3c0(0xb,2,2,7);
  FUN_0105a3c0(0xb,3,0,0x2f);
  FUN_0105a3c0(0xb,3,1,0xf);
  FUN_0105a3c0(0xb,3,2,0xf);
  FUN_0105a3c0(0xc,0,0,0xf);
  FUN_0105a3c0(0xc,0,1,0x2f);
  FUN_0105a3c0(0xc,0,2,0xf);
  FUN_0105a3c0(0xc,1,0,7);
  FUN_0105a3c0(0xc,1,1,0x27);
  FUN_0105a3c0(0xc,1,2,7);
  FUN_0105a3c0(0xc,2,0,0x1f);
  FUN_0105a3c0(0xc,2,1,0x3f);
  FUN_0105a3c0(0xc,2,2,0x1f);
  FUN_0105a3c0(0xc,3,0,0x17);
  FUN_0105a3c0(0xc,3,1,0x37);
  FUN_0105a3c0(0xc,3,2,0x17);
  FUN_0105a3c0(0xd,0,0,0x1f);
  FUN_0105a3c0(0xd,0,1,0x1f);
  FUN_0105a3c0(0xd,0,2,0x3f);
  FUN_0105a3c0(0xd,1,0,7);
  FUN_0105a3c0(0xd,1,1,7);
  FUN_0105a3c0(0xd,1,2,0x27);
  FUN_0105a3c0(0xd,2,0,0xf);
  FUN_0105a3c0(0xd,2,1,0xf);
  FUN_0105a3c0(0xd,2,2,0x2f);
  FUN_0105a3c0(0xd,3,0,0x17);
  FUN_0105a3c0(0xd,3,1,0x17);
  FUN_0105a3c0(0xd,3,2,0x37);
  FUN_0105a3c0(0xe,0,0,0x2f);
  FUN_0105a3c0(0xe,0,1,0x2f);
  FUN_0105a3c0(0xe,0,2,0);
  FUN_0105a3c0(0xe,1,0,7);
  FUN_0105a3c0(0xe,1,1,7);
  FUN_0105a3c0(0xe,1,2,0);
  FUN_0105a3c0(0xe,2,0,0xf);
  FUN_0105a3c0(0xe,2,1,0xf);
  FUN_0105a3c0(0xe,2,2,0);
  FUN_0105a3c0(0xe,3,0,0x1f);
  FUN_0105a3c0(0xe,3,1,0x1f);
  FUN_0105a3c0(0xe,3,2,0);
  FUN_0105a3c0(0xf,0,0,0x1f);
  FUN_0105a3c0(0xf,0,1,0x1f);
  FUN_0105a3c0(0xf,0,2,0x1f);
  FUN_0105a3c0(0xf,1,0,7);
  FUN_0105a3c0(0xf,1,1,7);
  FUN_0105a3c0(0xf,1,2,7);
  FUN_0105a3c0(0xf,2,0,0x17);
  FUN_0105a3c0(0xf,2,1,0x17);
  FUN_0105a3c0(0xf,2,2,0x17);
  FUN_0105a3c0(0xf,3,0,0x37);
  FUN_0105a3c0(0xf,3,1,0x37);
  FUN_0105a3c0(0xf,3,2,0x37);
  FUN_0105a67a(1,0,0x3f);
  FUN_0105a67a(1,1,0);
  FUN_0105a67a(1,2,0);
  FUN_0105a67a(2,0,0);
  FUN_0105a67a(2,1,0x3f);
  FUN_0105a67a(2,2,0);
  FUN_0105a67a(3,0,0x3f);
  FUN_0105a67a(3,1,0x3f);
  FUN_0105a67a(3,2,0);
  FUN_0105a67a(4,0,0);
  FUN_0105a67a(4,1,0);
  FUN_0105a67a(4,2,0x3f);
  FUN_0105a67a(5,0,0x3f);
  FUN_0105a67a(5,1,0);
  FUN_0105a67a(5,2,0x3f);
  FUN_0105a67a(6,0,0);
  FUN_0105a67a(6,1,0x3f);
  FUN_0105a67a(6,2,0x3f);
  FUN_0105a67a(7,0,0x3f);
  FUN_0105a67a(7,1,0x3f);
  FUN_0105a67a(7,2,0x3f);
  FUN_0105a67a(8,0,0);
  FUN_0105a67a(8,1,0x16);
  FUN_0105a67a(8,2,0);
  FUN_0105a67a(9,0,0xf);
  FUN_0105a67a(9,1,0xf);
  FUN_0105a67a(9,2,0x2f);
  FUN_0105a67a(10,0,0x2f);
  FUN_0105a67a(10,1,0xf);
  FUN_0105a67a(10,2,0);
  FUN_0105a67a(0xb,0,0x3f);
  FUN_0105a67a(0xb,1,0x1f);
  FUN_0105a67a(0xb,2,0x1f);
  FUN_0105a67a(0xc,0,0xf);
  FUN_0105a67a(0xc,1,0x2f);
  FUN_0105a67a(0xc,2,0xf);
  FUN_0105a67a(0xd,0,0x1f);
  FUN_0105a67a(0xd,1,0x1f);
  FUN_0105a67a(0xd,2,0x3f);
  FUN_0105a67a(0xe,0,0x2f);
  FUN_0105a67a(0xe,1,0x2f);
  FUN_0105a67a(0xe,2,0);
  FUN_0105a67a(0xf,0,0x1f);
  FUN_0105a67a(0xf,1,0x1f);
  FUN_0105a67a(0xf,2,0x1f);
  return;
}


// ==== FUN_0105c06c @ 0105c06c

void FUN_0105c06c(void)

{
  FUN_0105a3c0(0,0,0,0);
  FUN_0105a3c0(0,0,1,0);
  FUN_0105a3c0(0,0,2,0);
  FUN_0105a3c0(0,1,0,0);
  FUN_0105a3c0(0,1,1,0x2f);
  FUN_0105a3c0(0,1,2,0);
  FUN_0105a3c0(0,2,0,0);
  FUN_0105a3c0(0,2,1,0x3f);
  FUN_0105a3c0(0,2,2,0);
  FUN_0105a3c0(0,3,0,0);
  FUN_0105a3c0(0,3,1,0x1f);
  FUN_0105a3c0(0,3,2,0);
  FUN_0105a3c0(1,0,0,0);
  FUN_0105a3c0(1,0,1,3);
  FUN_0105a3c0(1,0,2,0);
  FUN_0105a3c0(1,1,0,0);
  FUN_0105a3c0(1,1,1,0x1f);
  FUN_0105a3c0(1,1,2,0);
  FUN_0105a3c0(1,2,0,0);
  FUN_0105a3c0(1,2,1,0x2f);
  FUN_0105a3c0(1,2,2,0);
  FUN_0105a3c0(1,3,0,0);
  FUN_0105a3c0(1,3,1,0xf);
  FUN_0105a3c0(1,3,2,0);
  FUN_0105a3c0(2,0,0,0);
  FUN_0105a3c0(2,0,1,7);
  FUN_0105a3c0(2,0,2,0);
  FUN_0105a3c0(2,1,0,0);
  FUN_0105a3c0(2,1,1,0x1f);
  FUN_0105a3c0(2,1,2,0);
  FUN_0105a3c0(2,2,0,0);
  FUN_0105a3c0(2,2,1,0x2f);
  FUN_0105a3c0(2,2,2,0);
  FUN_0105a3c0(2,3,0,0);
  FUN_0105a3c0(2,3,1,0xf);
  FUN_0105a3c0(2,3,2,0);
  FUN_0105a3c0(3,0,0,0);
  FUN_0105a3c0(3,0,1,0xb);
  FUN_0105a3c0(3,0,2,0);
  FUN_0105a3c0(3,1,0,0);
  FUN_0105a3c0(3,1,1,0x1f);
  FUN_0105a3c0(3,1,2,0);
  FUN_0105a3c0(3,2,0,0);
  FUN_0105a3c0(3,2,1,0x2f);
  FUN_0105a3c0(3,2,2,0);
  FUN_0105a3c0(3,3,0,0);
  FUN_0105a3c0(3,3,1,0xf);
  FUN_0105a3c0(3,3,2,0);
  FUN_0105a3c0(4,0,0,0);
  FUN_0105a3c0(4,0,1,0xf);
  FUN_0105a3c0(4,0,2,0);
  FUN_0105a3c0(4,1,0,0);
  FUN_0105a3c0(4,1,1,0x1f);
  FUN_0105a3c0(4,1,2,0);
  FUN_0105a3c0(4,2,0,0);
  FUN_0105a3c0(4,2,1,0x2f);
  FUN_0105a3c0(4,2,2,0);
  FUN_0105a3c0(4,3,0,0);
  FUN_0105a3c0(4,3,1,0xf);
  FUN_0105a3c0(4,3,2,0);
  FUN_0105a3c0(5,0,0,0);
  FUN_0105a3c0(5,0,1,0x13);
  FUN_0105a3c0(5,0,2,0);
  FUN_0105a3c0(5,1,0,0);
  FUN_0105a3c0(5,1,1,0x1f);
  FUN_0105a3c0(5,1,2,0);
  FUN_0105a3c0(5,2,0,0);
  FUN_0105a3c0(5,2,1,0x2f);
  FUN_0105a3c0(5,2,2,0);
  FUN_0105a3c0(5,3,0,0);
  FUN_0105a3c0(5,3,1,0xf);
  FUN_0105a3c0(5,3,2,0);
  FUN_0105a3c0(6,0,0,0);
  FUN_0105a3c0(6,0,1,0x17);
  FUN_0105a3c0(6,0,2,0);
  FUN_0105a3c0(6,1,0,0);
  FUN_0105a3c0(6,1,1,0x1f);
  FUN_0105a3c0(6,1,2,0);
  FUN_0105a3c0(6,2,0,0);
  FUN_0105a3c0(6,2,1,0x2f);
  FUN_0105a3c0(6,2,2,0);
  FUN_0105a3c0(6,3,0,0);
  FUN_0105a3c0(6,3,1,0xf);
  FUN_0105a3c0(6,3,2,0);
  FUN_0105a3c0(7,0,0,0);
  FUN_0105a3c0(7,0,1,0x3f);
  FUN_0105a3c0(7,0,2,0);
  FUN_0105a3c0(7,1,0,0);
  FUN_0105a3c0(7,1,1,0x17);
  FUN_0105a3c0(7,1,2,0);
  FUN_0105a3c0(7,2,0,0);
  FUN_0105a3c0(7,2,1,0x10);
  FUN_0105a3c0(7,2,2,0);
  FUN_0105a3c0(7,3,0,0);
  FUN_0105a3c0(7,3,1,0x2f);
  FUN_0105a3c0(7,3,2,0);
  FUN_0105a3c0(8,0,0,0);
  FUN_0105a3c0(8,0,1,0x1b);
  FUN_0105a3c0(8,0,2,0);
  FUN_0105a3c0(8,1,0,0);
  FUN_0105a3c0(8,1,1,0x1f);
  FUN_0105a3c0(8,1,2,0);
  FUN_0105a3c0(8,2,0,0);
  FUN_0105a3c0(8,2,1,0x2f);
  FUN_0105a3c0(8,2,2,0);
  FUN_0105a3c0(8,3,0,0);
  FUN_0105a3c0(8,3,1,0xf);
  FUN_0105a3c0(8,3,2,0);
  FUN_0105a3c0(9,0,0,0);
  FUN_0105a3c0(9,0,1,0x1f);
  FUN_0105a3c0(9,0,2,0);
  FUN_0105a3c0(9,1,0,0);
  FUN_0105a3c0(9,1,1,0x10);
  FUN_0105a3c0(9,1,2,0);
  FUN_0105a3c0(9,2,0,0);
  FUN_0105a3c0(9,2,1,0x3f);
  FUN_0105a3c0(9,2,2,0);
  FUN_0105a3c0(9,3,0,0);
  FUN_0105a3c0(9,3,1,0xf);
  FUN_0105a3c0(9,3,2,0);
  FUN_0105a3c0(10,0,0,0);
  FUN_0105a3c0(10,0,1,0x23);
  FUN_0105a3c0(10,0,2,0);
  FUN_0105a3c0(10,1,0,0);
  FUN_0105a3c0(10,1,1,0x1f);
  FUN_0105a3c0(10,1,2,0);
  FUN_0105a3c0(10,2,0,0);
  FUN_0105a3c0(10,2,1,0x3f);
  FUN_0105a3c0(10,2,2,0);
  FUN_0105a3c0(10,3,0,0);
  FUN_0105a3c0(10,3,1,0xf);
  FUN_0105a3c0(10,3,2,0);
  FUN_0105a3c0(0xb,0,0,0);
  FUN_0105a3c0(0xb,0,1,0x27);
  FUN_0105a3c0(0xb,0,2,0);
  FUN_0105a3c0(0xb,1,0,0);
  FUN_0105a3c0(0xb,1,1,0x1f);
  FUN_0105a3c0(0xb,1,2,0);
  FUN_0105a3c0(0xb,2,0,0);
  FUN_0105a3c0(0xb,2,1,0x13);
  FUN_0105a3c0(0xb,2,2,0);
  FUN_0105a3c0(0xb,3,0,0);
  FUN_0105a3c0(0xb,3,1,0xf);
  FUN_0105a3c0(0xb,3,2,0);
  FUN_0105a3c0(0xc,0,0,0);
  FUN_0105a3c0(0xc,0,1,0x2b);
  FUN_0105a3c0(0xc,0,2,0);
  FUN_0105a3c0(0xc,1,0,0);
  FUN_0105a3c0(0xc,1,1,0x1f);
  FUN_0105a3c0(0xc,1,2,0);
  FUN_0105a3c0(0xc,2,0,0);
  FUN_0105a3c0(0xc,2,1,0x17);
  FUN_0105a3c0(0xc,2,2,0);
  FUN_0105a3c0(0xc,3,0,0);
  FUN_0105a3c0(0xc,3,1,0xf);
  FUN_0105a3c0(0xc,3,2,0);
  FUN_0105a3c0(0xd,0,0,0);
  FUN_0105a3c0(0xd,0,1,0x2f);
  FUN_0105a3c0(0xd,0,2,0);
  FUN_0105a3c0(0xd,1,0,0);
  FUN_0105a3c0(0xd,1,1,0x1f);
  FUN_0105a3c0(0xd,1,2,0);
  FUN_0105a3c0(0xd,2,0,0);
  FUN_0105a3c0(0xd,2,1,0x17);
  FUN_0105a3c0(0xd,2,2,0);
  FUN_0105a3c0(0xd,3,0,0);
  FUN_0105a3c0(0xd,3,1,0xf);
  FUN_0105a3c0(0xd,3,2,0);
  FUN_0105a3c0(0xe,0,0,0);
  FUN_0105a3c0(0xe,0,1,0x33);
  FUN_0105a3c0(0xe,0,2,0);
  FUN_0105a3c0(0xe,1,0,0);
  FUN_0105a3c0(0xe,1,1,0x1f);
  FUN_0105a3c0(0xe,1,2,0);
  FUN_0105a3c0(0xe,2,0,0);
  FUN_0105a3c0(0xe,2,1,0x17);
  FUN_0105a3c0(0xe,2,2,0);
  FUN_0105a3c0(0xe,3,0,0);
  FUN_0105a3c0(0xe,3,1,0xf);
  FUN_0105a3c0(0xe,3,2,0);
  FUN_0105a3c0(0xf,0,0,0);
  FUN_0105a3c0(0xf,0,1,0x37);
  FUN_0105a3c0(0xf,0,2,0);
  FUN_0105a3c0(0xf,1,0,0);
  FUN_0105a3c0(0xf,1,1,0x1f);
  FUN_0105a3c0(0xf,1,2,0);
  FUN_0105a3c0(0xf,2,0,0);
  FUN_0105a3c0(0xf,2,1,0x17);
  FUN_0105a3c0(0xf,2,2,0);
  FUN_0105a3c0(0xf,3,0,0);
  FUN_0105a3c0(0xf,3,1,0xf);
  FUN_0105a3c0(0xf,3,2,0);
  FUN_0105a67a(1,0,0);
  FUN_0105a67a(1,1,3);
  FUN_0105a67a(1,2,0);
  FUN_0105a67a(2,0,0);
  FUN_0105a67a(2,1,7);
  FUN_0105a67a(2,2,0);
  FUN_0105a67a(3,0,0);
  FUN_0105a67a(3,1,0xb);
  FUN_0105a67a(3,2,0);
  FUN_0105a67a(4,0,0);
  FUN_0105a67a(4,1,0xf);
  FUN_0105a67a(4,2,0);
  FUN_0105a67a(5,0,0);
  FUN_0105a67a(5,1,0x13);
  FUN_0105a67a(5,2,0);
  FUN_0105a67a(6,0,0);
  FUN_0105a67a(6,1,0x17);
  FUN_0105a67a(6,2,0);
  FUN_0105a67a(7,0,0);
  FUN_0105a67a(7,1,0x3b);
  FUN_0105a67a(7,2,0);
  FUN_0105a67a(8,0,0);
  FUN_0105a67a(8,1,0x1b);
  FUN_0105a67a(8,2,0);
  FUN_0105a67a(9,0,0);
  FUN_0105a67a(9,1,0x1f);
  FUN_0105a67a(9,2,0);
  FUN_0105a67a(10,0,0);
  FUN_0105a67a(10,1,0x23);
  FUN_0105a67a(10,2,0);
  FUN_0105a67a(0xb,0,0);
  FUN_0105a67a(0xb,1,0x27);
  FUN_0105a67a(0xb,2,0);
  FUN_0105a67a(0xc,0,0);
  FUN_0105a67a(0xc,1,0x2b);
  FUN_0105a67a(0xc,2,0);
  FUN_0105a67a(0xd,0,0);
  FUN_0105a67a(0xd,1,0x2f);
  FUN_0105a67a(0xd,2,0);
  FUN_0105a67a(0xe,0,0);
  FUN_0105a67a(0xe,1,0x33);
  FUN_0105a67a(0xe,2,0);
  FUN_0105a67a(0xf,0,0);
  FUN_0105a67a(0xf,1,0x37);
  FUN_0105a67a(0xf,2,0);
  return;
}


// ==== FUN_0105d368 @ 0105d368

void FUN_0105d368(undefined2 param_1,undefined2 param_2,undefined4 param_3,char param_4,char param_5
                 )

{
  if (DAT_0103fa3d == 'm') {
    param_4 = '\a';
  }
  FUN_0105d3d2(param_1,param_2,param_3,(int)param_4,(int)param_5);
  return;
}


// ==== FUN_0105d3d2 @ 0105d3d2

void FUN_0105d3d2(ushort param_1,ushort param_2,char *param_3)

{
  if ((0x4f < param_1) || (0xcb < param_2)) {
    return;
  }
  if (((short)param_1 < 0x50) && (*param_3 != '\0')) {
    FUN_0105ef12();
    return;
  }
  return;
}


// ==== FUN_0105d53c @ 0105d53c

void FUN_0105d53c(ushort param_1,ushort param_2,ushort param_3,char param_4,byte param_5)

{
  uint uVar1;
  uint *puVar2;
  undefined4 local_8;
  
  if ((0x4f < param_1) || (0xcb < param_2)) {
    return;
  }
  puVar2 = (uint *)((uint)param_1 * 4 + *(int *)(&DAT_0103fa38 + (uint)param_2 * 0x140));
  local_8 = (param_3 & 0x7ff) << 0x10 | *puVar2 & 0xf8003ff0;
  if ((param_5 & 0x10) == 0x10) {
    local_8 = local_8 | 0x8000;
  }
  if ((param_5 & 8) == 8) {
    local_8 = local_8 | 0x4000;
  }
  uVar1 = local_8;
  local_8._2_2_ = (short)param_4 & 0xfU | (ushort)local_8;
  local_8._0_2_ = SUB42(uVar1,2);
  *(undefined2 *)puVar2 = local_8._0_2_;
  *(ushort *)((int)puVar2 + 2) = local_8._2_2_;
  return;
}


// ==== FUN_0105d63c @ 0105d63c

void FUN_0105d63c(undefined2 param_1,undefined2 param_2,undefined2 param_3,undefined2 param_4,
                 undefined1 param_5,char param_6)

{
  if (DAT_0103fa3d == 'm') {
    param_5 = 7;
  }
  FUN_0105d68e(param_1,param_2,param_3,param_4,param_5,(int)param_6);
  return;
}


// ==== FUN_0105d68e @ 0105d68e

void FUN_0105d68e(ushort param_1,ushort param_2,ushort param_3,ushort param_4,char param_5,
                 char param_6)

{
  ushort uVar1;
  ushort uVar2;
  uint *puVar3;
  ushort local_e;
  ushort local_8;
  ushort uStack_6;
  
  uVar2 = param_2;
  uVar1 = param_1;
  if ((((0x4f < param_1) || (0xcb < param_2)) || (0x4f < param_3)) || (0xcb < param_4)) {
    return;
  }
  if (param_3 < param_1) {
    param_1 = param_3;
    param_3 = uVar1;
  }
  if (param_4 < param_2) {
    param_2 = param_4;
    param_4 = uVar2;
  }
  if (param_1 == param_3) {
    for (local_e = param_2; local_e <= param_4; local_e = local_e + 1) {
      puVar3 = (uint *)((uint)param_1 * 4 + *(int *)(&DAT_0103fa38 + (uint)local_e * 0x140));
      uStack_6 = ((short)param_5 & 0xfU) << 4 | (ushort)(*puVar3 & 0x7ffff0f);
      local_8 = (ushort)((uint)((int)param_6 << 0x1b) >> 0x10) |
                (ushort)((*puVar3 & 0x7ffff0f) >> 0x10);
      *(ushort *)puVar3 = local_8;
      *(ushort *)((int)puVar3 + 2) = uStack_6;
    }
  }
  else {
    for (local_e = param_1; local_e <= param_3; local_e = local_e + 1) {
      puVar3 = (uint *)((uint)local_e * 4 + *(int *)(&DAT_0103fa38 + (uint)param_2 * 0x140));
      uStack_6 = ((short)param_5 & 0xfU) << 4 | (ushort)(*puVar3 & 0x7ffff0f);
      local_8 = (ushort)((uint)((int)param_6 << 0x1b) >> 0x10) |
                (ushort)((*puVar3 & 0x7ffff0f) >> 0x10);
      *(ushort *)puVar3 = local_8;
      *(ushort *)((int)puVar3 + 2) = uStack_6;
    }
  }
  return;
}


// ==== FUN_0105d83e @ 0105d83e

void FUN_0105d83e(undefined2 param_1,undefined2 param_2,undefined2 param_3,undefined2 param_4)

{
  undefined1 uStack00000017;
  
  DAT_0103fa3d = 0x6d;
  uStack00000017 = 7;
  FUN_0105d888(param_1,param_2,param_3,param_4,7);
  return;
}


// ==== FUN_0105d888 @ 0105d888

void FUN_0105d888(ushort param_1,ushort param_2,ushort param_3,ushort param_4,char param_5)

{
  ushort uVar1;
  ushort uVar2;
  
  uVar2 = param_2;
  uVar1 = param_1;
  if ((((0x4f < param_1) || (0xcb < param_2)) || (0x4f < param_3)) || (0xcb < param_4)) {
    return;
  }
  if ((param_1 == param_3) && (param_2 == param_4)) {
    return;
  }
  if (param_3 < param_1) {
    param_1 = param_3;
    param_3 = uVar1;
  }
  if (param_4 < param_2) {
    param_2 = param_4;
    param_4 = uVar2;
  }
  if (param_2 == param_4) {
    FUN_0105d68e(param_1,param_2,param_1,param_2,(int)param_5,0x1c);
    FUN_0105d68e(param_3,param_2,param_3,param_2,(int)param_5,0x1d);
    if (1 < (int)((uint)param_3 - (uint)param_1)) {
      FUN_0105d68e(param_1 + 1,param_2,param_3 - 1,param_2,(int)param_5,0x18);
    }
    return;
  }
  if (param_1 != param_3) {
    FUN_0105d68e(param_1,param_2,param_1,param_2,(int)param_5,0x1c);
    FUN_0105d68e(param_3,param_2,param_3,param_2,(int)param_5,0x1d);
    FUN_0105d68e(param_3,param_4,param_3,param_4,(int)param_5,0x1f);
    FUN_0105d68e(param_1,param_4,param_1,param_4,(int)param_5,0x1e);
    FUN_0105d68e(param_1 + 1,param_2,param_3 - 1,param_2,(int)param_5,0x18);
    FUN_0105d68e(param_1 + 1,param_4,param_3 - 1,param_4,(int)param_5,0x19);
    FUN_0105d68e(param_1,param_2 + 1,param_1,param_4 - 1,(int)param_5,0x1a);
    FUN_0105d68e(param_3,param_2 + 1,param_3,param_4 - 1,(int)param_5,0x1b);
    return;
  }
  FUN_0105d68e(param_1,param_2,param_1,param_2,(int)param_5,0x1c);
  FUN_0105d68e(param_1,param_4,param_1,param_4,(int)param_5,0x1f);
  if (1 < (int)((uint)param_4 - (uint)param_2)) {
    FUN_0105d68e(param_1,param_2 + 1,param_1,param_4 - 1,(int)param_5,0x1a);
  }
  return;
}


// ==== FUN_0105dc48 @ 0105dc48

void FUN_0105dc48(undefined2 param_1,undefined2 param_2,undefined2 param_3,undefined2 param_4,
                 char param_5)

{
  if (DAT_0103fa3d == 'm') {
    param_5 = '\0';
  }
  FUN_0105dc90(param_1,param_2,param_3,param_4,(int)param_5);
  return;
}


// ==== FUN_0105dc90 @ 0105dc90

void FUN_0105dc90(ushort param_1,ushort param_2,ushort param_3,ushort param_4,char param_5)

{
  ushort uVar1;
  ushort uVar2;
  uint *puVar3;
  undefined2 local_c;
  ushort uStack_a;
  ushort local_8;
  ushort local_6;
  
  uVar2 = param_2;
  uVar1 = param_1;
  if ((((0x4f < param_1) || (0xcb < param_2)) || (0x4f < param_3)) || (0xcb < param_4)) {
    return;
  }
  if (param_3 < param_1) {
    param_1 = param_3;
    param_3 = uVar1;
  }
  if (param_4 < param_2) {
    param_2 = param_4;
    param_4 = uVar2;
  }
  for (local_8 = param_2; local_8 <= param_4; local_8 = local_8 + 1) {
    for (local_6 = param_1; local_6 <= param_3; local_6 = local_6 + 1) {
      puVar3 = (uint *)((uint)local_6 * 4 + *(int *)(&DAT_0103fa38 + (uint)local_8 * 0x140));
      uStack_a = ((short)param_5 & 0xfU) << 8 | (ushort)(*puVar3 & 0xfffff0ff);
      local_c = (undefined2)((*puVar3 & 0xfffff0ff) >> 0x10);
      *(undefined2 *)puVar3 = local_c;
      *(ushort *)((int)puVar3 + 2) = uStack_a;
    }
  }
  return;
}


// ==== FUN_0105dd96 @ 0105dd96

void FUN_0105dd96(undefined2 param_1,undefined2 param_2,undefined4 param_3,char param_4,char param_5
                 )

{
  if (DAT_0103fa3d == 'm') {
    param_4 = '\a';
  }
  FUN_0105de00(param_1,param_2,param_3,(int)param_4,(int)param_5);
  return;
}


// ==== FUN_0105de00 @ 0105de00

void FUN_0105de00(ushort param_1,ushort param_2,char *param_3)

{
  if ((0x4f < param_1) || (0x98 < param_2)) {
    return;
  }
  if (((short)param_1 < 0x50) && (*param_3 != '\0')) {
    FUN_0105ef12();
    return;
  }
  return;
}


// ==== FUN_0105df3e @ 0105df3e

void FUN_0105df3e(ushort param_1,ushort param_2,ushort param_3,char param_4,byte param_5)

{
  uint uVar1;
  uint *puVar2;
  undefined4 local_8;
  
  if ((0x4f < param_1) || (0x98 < param_2)) {
    return;
  }
  puVar2 = (uint *)((uint)param_1 * 4 + *(int *)(&DAT_0103fa34 + (uint)param_2 * 0x140));
  local_8 = (param_3 & 0x7ff) << 0x10 | *puVar2 & 0xb800fff0;
  if ((param_5 & 8) == 8) {
    local_8 = local_8 | 0x40000000;
  }
  uVar1 = local_8;
  local_8._2_2_ = (short)param_4 & 0xfU | (ushort)local_8;
  local_8._0_2_ = SUB42(uVar1,2);
  *(undefined2 *)puVar2 = local_8._0_2_;
  *(ushort *)((int)puVar2 + 2) = local_8._2_2_;
  return;
}


// ==== FUN_0105e012 @ 0105e012

void FUN_0105e012(undefined2 param_1,undefined2 param_2,undefined2 param_3,undefined2 param_4,
                 char param_5,undefined4 param_6)

{
  if (DAT_0103fa3d == 'm') {
    param_5 = '\a';
  }
  FUN_0105e060(param_1,param_2,param_3,param_4,(int)param_5,param_6);
  return;
}


// ==== FUN_0105e060 @ 0105e060

void FUN_0105e060(ushort param_1,ushort param_2,ushort param_3,ushort param_4,char param_5,
                 ushort param_6)

{
  ushort uVar1;
  ushort uVar2;
  uint *puVar3;
  ushort local_e;
  ushort local_8;
  ushort uStack_6;
  
  uVar2 = param_2;
  uVar1 = param_1;
  if ((((0x4f < param_1) || (0x98 < param_2)) || (0x4f < param_3)) || (0x98 < param_4)) {
    return;
  }
  if (param_3 < param_1) {
    param_1 = param_3;
    param_3 = uVar1;
  }
  if (param_4 < param_2) {
    param_2 = param_4;
    param_4 = uVar2;
  }
  if (param_1 == param_3) {
    for (local_e = param_2; local_e <= param_4; local_e = local_e + 1) {
      puVar3 = (uint *)((uint)param_1 * 4 + *(int *)(&DAT_0103fa34 + (uint)local_e * 0x140));
      uStack_6 = (short)param_5 & 0xfU | (ushort)(*puVar3 & 0xb800fff0);
      local_8 = param_6 & 0x7ff | (ushort)((*puVar3 & 0xb800fff0) >> 0x10);
      *(ushort *)puVar3 = local_8;
      *(ushort *)((int)puVar3 + 2) = uStack_6;
    }
  }
  else {
    for (local_e = param_1; local_e <= param_3; local_e = local_e + 1) {
      puVar3 = (uint *)((uint)local_e * 4 + *(int *)(&DAT_0103fa34 + (uint)param_2 * 0x140));
      uStack_6 = (short)param_5 & 0xfU | (ushort)(*puVar3 & 0xb800fff0);
      local_8 = param_6 & 0x7ff | (ushort)((*puVar3 & 0xb800fff0) >> 0x10);
      *(ushort *)puVar3 = local_8;
      *(ushort *)((int)puVar3 + 2) = uStack_6;
    }
  }
  return;
}


// ==== FUN_0105e202 @ 0105e202

void FUN_0105e202(undefined2 param_1,undefined2 param_2,undefined2 param_3,undefined2 param_4,
                 char param_5)

{
  if (DAT_0103fa3d == 'm') {
    param_5 = '\a';
  }
  FUN_0105e24c(param_1,param_2,param_3,param_4,(int)param_5);
  return;
}


// ==== FUN_0105e24c @ 0105e24c

void FUN_0105e24c(ushort param_1,ushort param_2,ushort param_3,ushort param_4,char param_5)

{
  ushort uVar1;
  ushort uVar2;
  
  uVar2 = param_2;
  uVar1 = param_1;
  if ((((0x4f < param_1) || (0x98 < param_2)) || (0x4f < param_3)) || (0x98 < param_4)) {
    return;
  }
  if ((param_1 == param_3) && (param_2 == param_4)) {
    return;
  }
  if (param_3 < param_1) {
    param_1 = param_3;
    param_3 = uVar1;
  }
  if (param_4 < param_2) {
    param_2 = param_4;
    param_4 = uVar2;
  }
  if (param_2 == param_4) {
    FUN_0105e060(param_1,param_2,param_1,param_2,(int)param_5,0x102);
    FUN_0105e060(param_3,param_2,param_3,param_2,(int)param_5,0x103);
    if (1 < (int)((uint)param_3 - (uint)param_1)) {
      FUN_0105e060(param_1 + 1,param_2,param_3 - 1,param_2,(int)param_5,0x100);
    }
    return;
  }
  if (param_1 != param_3) {
    FUN_0105e060(param_1,param_2,param_1,param_2,(int)param_5,0x38c);
    FUN_0105e060(param_3,param_2,param_3,param_2,(int)param_5,0x38e);
    FUN_0105e060(param_3,param_4,param_3,param_4,(int)param_5,0xde);
    FUN_0105e060(param_1,param_4,param_1,param_4,(int)param_5,0xdf);
    FUN_0105e060(param_1 + 1,param_2,param_3 - 1,param_2,(int)param_5,0xa2);
    FUN_0105e060(param_1 + 1,param_4,param_3 - 1,param_4,(int)param_5,0x80);
    FUN_0105e060(param_1,param_2 + 1,param_1,param_4 - 1,(int)param_5,0x89);
    FUN_0105e060(param_3,param_2 + 1,param_3,param_4 - 1,(int)param_5,0x90);
    return;
  }
  FUN_0105e060(param_1,param_2,param_1,param_2,(int)param_5,0x104);
  FUN_0105e060(param_1,param_4,param_1,param_4,(int)param_5,0x105);
  if (1 < (int)((uint)param_4 - (uint)param_2)) {
    FUN_0105e060(param_1,param_2 + 1,param_1,param_4 - 1,(int)param_5,0x101);
  }
  return;
}


// ==== FUN_0105e60c @ 0105e60c

void FUN_0105e60c(undefined2 param_1,undefined2 param_2,undefined2 param_3,undefined2 param_4,
                 char param_5)

{
  if (DAT_0103fa3d == 'm') {
    param_5 = '\0';
  }
  FUN_0105e654(param_1,param_2,param_3,param_4,(int)param_5);
  return;
}


// ==== FUN_0105e654 @ 0105e654

void FUN_0105e654(ushort param_1,ushort param_2,ushort param_3,ushort param_4,char param_5)

{
  ushort uVar1;
  ushort uVar2;
  uint *puVar3;
  undefined2 local_c;
  ushort uStack_a;
  ushort local_8;
  ushort local_6;
  
  uVar2 = param_2;
  uVar1 = param_1;
  if ((((0x4f < param_1) || (0x98 < param_2)) || (0x4f < param_3)) || (0x98 < param_4)) {
    return;
  }
  if (param_3 < param_1) {
    param_1 = param_3;
    param_3 = uVar1;
  }
  if (param_4 < param_2) {
    param_2 = param_4;
    param_4 = uVar2;
  }
  for (local_8 = param_2; local_8 <= param_4; local_8 = local_8 + 1) {
    for (local_6 = param_1; local_6 <= param_3; local_6 = local_6 + 1) {
      puVar3 = (uint *)((uint)local_6 * 4 + *(int *)(&DAT_0103fa34 + (uint)local_8 * 0x140));
      uStack_a = ((short)param_5 & 0xfU) << 4 | (ushort)(*puVar3 & 0xffffff0f);
      local_c = (undefined2)((*puVar3 & 0xffffff0f) >> 0x10);
      *(undefined2 *)puVar3 = local_c;
      *(ushort *)((int)puVar3 + 2) = uStack_a;
    }
  }
  return;
}


// ==== FUN_0105e75a @ 0105e75a

void FUN_0105e75a(ushort param_1,ushort param_2)

{
  ushort uVar1;
  ushort local_a;
  ushort local_6;
  
  if ((0x4f < param_1) || (0xcb < param_2)) {
    return;
  }
  for (local_6 = 0; local_6 < 4; local_6 = local_6 + 1) {
    if (*(short *)(DAT_0103fa20 + (uint)local_6 * 2) != 0) {
      uVar1 = *(ushort *)(DAT_0103fa28 + (uint)local_6 * 2) / 0x50;
      local_a = (uVar1 + *(short *)(DAT_0103fa20 + (uint)local_6 * 2)) - 1;
      if (0xcb < local_a) {
        local_a = 0xcb;
      }
      if ((uVar1 <= param_2) && (param_2 <= local_a)) {
        FUN_0105e84a(param_1,param_2);
        while (param_2 = param_2 + 1, param_2 <= local_a) {
          FUN_0105e89e(param_2);
        }
      }
    }
  }
  return;
}


// ==== FUN_0105e84a @ 0105e84a

void FUN_0105e84a(ushort param_1,ushort param_2)

{
  if ((0x4f < param_1) || (0xcb < param_2)) {
    return;
  }
  for (; param_1 < 0x50; param_1 = param_1 + 1) {
    FUN_0105d368(param_1,param_2,&DAT_0105e848,0,0);
  }
  return;
}


// ==== FUN_0105e89e @ 0105e89e

void FUN_0105e89e(ushort param_1)

{
  ushort local_6;
  
  local_6 = 0;
  if (0xcb < param_1) {
    return;
  }
  for (; local_6 < 0x50; local_6 = local_6 + 1) {
    FUN_0105d368(local_6,param_1,&DAT_0105e89c,0,0);
  }
  return;
}


// ==== FUN_0105e8ea @ 0105e8ea

void FUN_0105e8ea(void)

{
  ushort local_6;
  
  for (local_6 = 0; local_6 < 0x3a; local_6 = local_6 + 1) {
    FUN_0105e89e(local_6);
    FUN_0105ebca(local_6);
    FUN_0105d63c(0,local_6,0x4f,local_6,7,0);
    FUN_0105e012(0,local_6,0x4f,local_6,7,0x20);
  }
  FUN_0105dc48(0,0,0x4f,0x1c,8);
  FUN_0105dc48(0,0x1d,0x4f,0x39,0);
  FUN_0105e60c(0,0,0x4f,0x39,0);
  return;
}


// ==== FUN_0105e9b2 @ 0105e9b2

void FUN_0105e9b2(void)

{
  short sVar1;
  
  sVar1 = 0;
  FUN_0105e89e(0);
  FUN_0105d63c(0,sVar1,0x4f,sVar1,8,0);
  FUN_0105ebca(0,sVar1 + 1);
  FUN_0105e012(0,0,0x4f,0,0,0x20);
  FUN_0105dc48(0,0,0x4f,0x1c,8);
  FUN_0105dc48(0,0x1d,0x4f,0xcb,0);
  FUN_0105e60c(0,0,0x4f,0x98,0);
  return;
}


// ==== FUN_0105ea86 @ 0105ea86

void FUN_0105ea86(ushort param_1,ushort param_2)

{
  ushort uVar1;
  ushort local_a;
  ushort local_6;
  
  if ((0x4f < param_1) || (0x98 < param_2)) {
    return;
  }
  for (local_6 = 0; local_6 < 4; local_6 = local_6 + 1) {
    if (*(short *)(DAT_0103fa1c + (uint)local_6 * 2) != 0) {
      uVar1 = *(ushort *)(DAT_0103fa24 + (uint)local_6 * 2) / 0x50;
      local_a = (uVar1 + *(short *)(DAT_0103fa1c + (uint)local_6 * 2)) - 1;
      if (0x98 < local_a) {
        local_a = 0x98;
      }
      if ((uVar1 <= param_2) && (param_2 <= local_a)) {
        FUN_0105eb76(param_1,param_2);
        while (param_2 = param_2 + 1, param_2 <= local_a) {
          FUN_0105ebca(param_2);
        }
      }
    }
  }
  return;
}


// ==== FUN_0105eb76 @ 0105eb76

void FUN_0105eb76(ushort param_1,ushort param_2)

{
  if ((0x4f < param_1) || (0x98 < param_2)) {
    return;
  }
  for (; param_1 < 0x50; param_1 = param_1 + 1) {
    FUN_0105dd96(param_1,param_2,&DAT_0105eb74,0,0);
  }
  return;
}


// ==== FUN_0105ebca @ 0105ebca

void FUN_0105ebca(ushort param_1)

{
  ushort local_6;
  
  local_6 = 0;
  if (0x98 < param_1) {
    return;
  }
  for (; local_6 < 0x50; local_6 = local_6 + 1) {
    FUN_0105dd96(local_6,param_1,&DAT_0105ebc8,0,0);
  }
  return;
}


// ==== FUN_0105ec16 @ 0105ec16

void FUN_0105ec16(void)

{
  ushort local_6;
  
  for (local_6 = 0; local_6 < 0x99; local_6 = local_6 + 1) {
    FUN_0105ebca(local_6);
  }
  FUN_0105e60c(0,0,0x4f,0x98,0);
  return;
}


// ==== FUN_0105ec54 @ 0105ec54

void FUN_0105ec54(char param_1,int param_2,char param_3,int param_4)

{
  char local_5;
  
  if (param_1 == '\x01') {
    for (local_5 = '\0'; local_5 < param_3; local_5 = local_5 + '\x01') {
      *(undefined1 *)(param_4 + local_5) = 0x20;
    }
  }
  else {
    for (local_5 = '\0'; local_5 < param_3; local_5 = local_5 + '\x01') {
      *(undefined1 *)(param_4 + local_5) = 0x30;
    }
  }
  *(undefined1 *)(param_4 + param_3) = 0;
  do {
    local_5 = param_3 + -1;
    if (local_5 < '\0') {
      return;
    }
    *(char *)(param_4 + local_5) = (char)(param_2 % 10);
    *(byte *)(param_4 + local_5) = *(byte *)(param_4 + local_5) | 0x30;
    param_2 = param_2 / 10;
    param_3 = local_5;
  } while (param_2 != 0);
  return;
}


// ==== FUN_0105ed0e @ 0105ed0e

int FUN_0105ed0e(int param_1,char param_2,int *param_3)

{
  int in_D0;
  int local_16;
  char local_5;
  
  *param_3 = 0;
  local_16 = in_D0;
  for (local_5 = '\0'; local_5 < param_2; local_5 = local_5 + '\x01') {
    if ((0x2f < *(byte *)(((param_1 + param_2) - (int)local_5) + -1)) &&
       (*(byte *)(((param_1 + param_2) - (int)local_5) + -1) < 0x3a)) {
      local_16 = (int)local_5;
      FUN_0105eddc();
      *param_3 = local_16 * (*(byte *)(((param_1 + param_2) - (int)local_5) + -1) & 0xf) + *param_3;
    }
  }
  for (local_5 = '\0'; (local_5 < param_2 && (*(char *)(param_1 + local_5) == ' '));
      local_5 = local_5 + '\x01') {
    if (param_2 + -1 == (int)local_5) {
      *param_3 = -1;
    }
  }
  return local_16;
}


// ==== FUN_0105eddc @ 0105eddc

void FUN_0105eddc(char param_1)

{
  char local_5;
  
  if (param_1 != '\0') {
    for (local_5 = '\x01'; local_5 <= param_1; local_5 = local_5 + '\x01') {
    }
  }
  return;
}


// ==== FUN_0105ee14 @ 0105ee14

void FUN_0105ee14(char param_1,uint param_2,char param_3,int param_4)

{
  byte local_6;
  char local_5;
  
  if (param_1 == '\x01') {
    for (local_5 = '\0'; local_5 < param_3; local_5 = local_5 + '\x01') {
      *(undefined1 *)(param_4 + local_5) = 0x20;
    }
  }
  else {
    for (local_5 = '\0'; local_5 < param_3; local_5 = local_5 + '\x01') {
      *(undefined1 *)(param_4 + local_5) = 0x30;
    }
  }
  *(undefined1 *)(param_4 + param_3) = 0;
  local_6 = 0;
  while (local_5 = param_3 + -1, -1 < local_5) {
    *(byte *)(param_4 + local_5) = (byte)(param_2 >> (local_6 & 0x3f)) & 0xf;
    if (*(byte *)(param_4 + local_5) < 10) {
      *(byte *)(param_4 + local_5) = *(byte *)(param_4 + local_5) | 0x30;
    }
    else {
      *(char *)(param_4 + local_5) = *(char *)(param_4 + local_5) + '7';
    }
    local_6 = local_6 + 4;
    param_3 = local_5;
  }
  return;
}


// ==== FUN_0105eedc @ 0105eedc

void FUN_0105eedc(undefined1 *param_1,undefined1 *param_2,uint param_3)

{
  uint uVar1;
  
  if (param_3 != 0) {
    for (uVar1 = 0; uVar1 < param_3; uVar1 = uVar1 + 1) {
      *param_1 = *param_2;
      param_2 = param_2 + 1;
      param_1 = param_1 + 1;
    }
  }
  return;
}


// ==== FUN_0105ef12 @ 0105ef12

void FUN_0105ef12(void)

{
  bool bVar1;
  ushort uVar3;
  uint uVar2;
  uint uVar4;
  uint unaff_D7;
  uint *in_A0;
  uint *puVar5;
  uint *puVar6;
  
  while( true ) {
    puVar5 = in_A0 + 1;
    uVar2 = *in_A0;
    if (uVar2 == 0) break;
    uVar4 = unaff_D7 - *puVar5;
    if (uVar4 < uVar2) {
                    /* WARNING: Could not recover jumptable at 0x0105ef2c. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      (*(code *)in_A0[uVar4 + 2])();
      return;
    }
    unaff_D7 = *puVar5 + uVar4;
    in_A0 = in_A0 + uVar2 + 2;
  }
  uVar2 = *puVar5;
  if (uVar2 != 0) {
    if (8 < uVar2) {
      puVar6 = in_A0 + 2;
      puVar5 = puVar6 + uVar2 * 2;
      do {
        uVar4 = uVar2 & 0xfffffffe;
        if (puVar6[uVar4 + 1] <= unaff_D7) {
          if (unaff_D7 <= puVar6[uVar4 + 1]) {
                    /* WARNING: Could not recover jumptable at 0x0105ef6c. Too many branches */
                    /* WARNING: Treating indirect jump as call */
            (*(code *)puVar6[uVar4])();
            return;
          }
          puVar6 = puVar6 + uVar4 + 2;
          uVar2 = uVar2 - 1;
        }
        bVar1 = -1 < (int)uVar2;
        uVar2 = uVar2 >> 1;
      } while (uVar2 != 0 && bVar1);
                    /* WARNING: Could not recover jumptable at 0x0105ef7a. Too many branches */
                    /* WARNING: Treating indirect jump as call */
      (*(code *)*puVar5)();
      return;
    }
    uVar2 = uVar2 - 1;
    do {
      if (unaff_D7 == puVar5[2]) break;
      puVar5 = puVar5 + 2;
      uVar3 = (short)uVar2 - 1;
      uVar2 = (uint)uVar3;
    } while (uVar3 != 0xffff);
  }
                    /* WARNING: Could not recover jumptable at 0x0105ef4c. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (*(code *)puVar5[1])();
  return;
}


// ==== FUN_0105ef7c @ 0105ef7c

void FUN_0105ef7c(undefined4 *param_1,undefined4 *param_2)

{
  int iVar1;
  uint in_D0;
  ushort uVar3;
  uint uVar2;
  short sVar4;
  undefined4 *puVar5;
  undefined4 *puVar6;
  
  if (((int)in_D0 < 0xb) || (((byte)param_2 & 1) != ((byte)param_1 & 1))) {
    sVar4 = (short)in_D0 + -1;
    uVar2 = in_D0 >> 0x10;
    do {
      do {
        puVar5 = (undefined4 *)((int)param_2 + 1);
        puVar6 = (undefined4 *)((int)param_1 + 1);
        *(undefined1 *)param_1 = *(undefined1 *)param_2;
        sVar4 = sVar4 + -1;
        param_2 = puVar5;
        param_1 = puVar6;
      } while (sVar4 != -1);
      uVar3 = (short)uVar2 - 1;
      uVar2 = (uint)uVar3;
    } while (uVar3 != 0xffff);
  }
  else {
    if (((uint)param_2 & 3) != 0) {
      iVar1 = 4 - ((uint)param_2 & 3);
      in_D0 = in_D0 - iVar1;
      sVar4 = (short)iVar1 + -1;
      puVar5 = param_2;
      puVar6 = param_1;
      do {
        param_2 = (undefined4 *)((int)puVar5 + 1);
        param_1 = (undefined4 *)((int)puVar6 + 1);
        *(undefined1 *)puVar6 = *(undefined1 *)puVar5;
        sVar4 = sVar4 + -1;
        puVar5 = param_2;
        puVar6 = param_1;
      } while (sVar4 != -1);
    }
    if (in_D0 >> 5 != 0) {
      uVar2 = in_D0 >> 0x15;
      sVar4 = (short)(in_D0 >> 5) + -1;
      do {
        do {
          *param_1 = *param_2;
          param_1[1] = param_2[1];
          param_1[2] = param_2[2];
          param_1[3] = param_2[3];
          param_1[4] = param_2[4];
          param_1[5] = param_2[5];
          puVar5 = param_2 + 7;
          puVar6 = param_1 + 7;
          param_1[6] = param_2[6];
          param_2 = param_2 + 8;
          param_1 = param_1 + 8;
          *puVar6 = *puVar5;
          sVar4 = sVar4 + -1;
        } while (sVar4 != -1);
        uVar3 = (short)uVar2 - 1;
        uVar2 = (uint)uVar3;
      } while (uVar3 != 0xffff);
    }
    if ((in_D0 & 0x1f) != 0) {
      sVar4 = ((ushort)in_D0 & 0x1f) - 1;
      do {
        *(undefined1 *)param_1 = *(undefined1 *)param_2;
        sVar4 = sVar4 + -1;
        param_2 = (undefined4 *)((int)param_2 + 1);
        param_1 = (undefined4 *)((int)param_1 + 1);
      } while (sVar4 != -1);
    }
  }
  return;
}


