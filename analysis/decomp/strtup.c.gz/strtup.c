// ==== asgetmap @ 80000024

void asgetmap(undefined1 param_1,undefined4 param_2,int param_3)

{
  int iVar1;
  int unaff_D7;
  char *local_5e;
  undefined1 local_5a [10];
  undefined4 local_50;
  undefined1 auStack_4c [4];
  int local_48;
  int local_44;
  int local_40;
  int local_34 [2];
  int local_2c;
  char cStack_29;
  int local_28;
  char *local_24;
  char *local_20;
  char local_1b;
  undefined *local_1a;
  short local_16;
  int *local_14;
  int *local_10;
  
  local_10 = local_34 + 0xb;
  local_14 = local_34 + 10;
  local_2c = 0;
  local_5e = (char *)(memasign + param_3 * 0x450 + 0xc);
  local_34[1] = 0;
  local_48 = 0;
  local_34[0] = 1;
  local_1a = &DAT_90000000;
  local_24 = local_5e;
  local_20 = local_5e;
  fs_open(param_1,param_2,0,auStack_4c);
  asmaperr(*local_10);
  if (-1 < unaff_D7) {
    local_16 = (short)*local_10;
    while( true ) {
      fs_read(param_1,(int)local_16,0x400,local_1a,auStack_4c);
      asmaperr(*local_10);
      if (unaff_D7 < 0) break;
      iVar1 = *local_10;
      for (local_28 = 0; (local_28 < iVar1 && (local_1b = local_1a[local_28], local_1b != '\x1a'));
          local_28 = local_28 + 1) {
        switch(local_34[0]) {
        case 0:
          asmapidl(local_1b,local_34);
          break;
        case 1:
          asmapwtn(local_1b,local_20,local_34 + 1,local_34,local_2c);
          if (unaff_D7 == 0) {
            local_48 = 0;
          }
          break;
        case 2:
          asmapnam(local_1b,local_20,local_34 + 1,local_34);
          if (unaff_D7 == 0) {
            if ((local_34[0] == 1) || (local_34[0] == 4)) {
              local_48 = -1;
            }
            else if (local_34[0] == 5) {
              local_50 = 0;
              local_5a[0] = 0;
            }
          }
          break;
        case 3:
          asmapext(local_1b,local_20,local_34 + 1,local_34);
          if (unaff_D7 == 0) {
            if (((local_34[0] == 0) || (local_34[0] == 1)) || (local_34[0] == 4)) {
              local_48 = -1;
            }
            else if (local_34[0] == 5) {
              local_50 = 0;
              local_5a[0] = 0;
            }
          }
          break;
        case 4:
          asmapcom(local_1b,local_34);
          break;
        case 5:
          asgetptp(local_1b,local_5a,&local_50,local_5e,local_34);
          if ((unaff_D7 == 0) && (local_48 = 0, local_34[0] == 6)) {
            local_50 = 0;
            local_5a[0] = 0;
          }
          break;
        case 6:
          asgetsiz(local_1b,local_5a,&local_50,local_5e,local_34);
          if ((unaff_D7 == 0) && ((local_34[0] == 1 || (local_34[0] == 4)))) {
            local_48 = -1;
          }
        }
        if (local_48 == -1) {
          local_48 = 0;
          local_44 = 0;
          local_34[1] = 0;
          for (local_40 = 0; local_40 < local_2c; local_40 = local_40 + 1) {
            strcmp(local_24 + local_40 * 0x20,local_20);
            if (unaff_D7 == 0) {
              local_44 = -1;
            }
          }
          if (local_44 == 0) {
            local_5e[0x1f] = -1;
            local_5e[0x1d] = cStack_29;
            local_2c = local_2c + 1;
            local_5e = local_24 + local_2c * 0x20;
            local_20 = local_5e;
          }
          else {
            *local_20 = '\0';
          }
        }
        if (unaff_D7 < 0) break;
      }
      if (((iVar1 < 0x400) || (unaff_D7 < 0)) || (local_1b == '\x1a')) break;
    }
    fs_clos(param_1,(int)local_16,auStack_4c);
    if ((*local_14 < 0) && (-1 < unaff_D7)) {
      asmaperr(*local_14);
    }
  }
  return;
}


// ==== asmapidl @ 80000448

void asmapidl(byte param_1,undefined4 *param_2)

{
  if (param_1 != 0xd) {
    if (param_1 < 0xe) {
      if (10 < param_1) {
        return;
      }
      if (param_1 < 9) {
        return;
      }
    }
    else if (param_1 != 0x20) {
      if (param_1 == 0x40) {
        *param_2 = 4;
        return;
      }
      return;
    }
  }
  *param_2 = 1;
  return;
}


// ==== asmapwtn @ 800004ac

void asmapwtn(byte param_1,int param_2,int *param_3,undefined4 *param_4,int param_5)

{
  if (param_1 == 0xd) {
    return;
  }
  if (param_1 < 0xe) {
    if ((param_1 < 0xb) && (8 < param_1)) {
      return;
    }
  }
  else {
    if (param_1 == 0x20) {
      return;
    }
    if (param_1 == 0x40) {
      *param_4 = 4;
      return;
    }
  }
  if (((((0x40 < param_1) && (param_1 < 0x5b)) || ((0x2f < param_1 && (param_1 < 0x3a)))) ||
      (param_1 == 0x5f)) || (((0x60 < param_1 && (param_1 < 0x7b)) || (param_1 == 0x21)))) {
    if ((0x60 < param_1) && (param_1 < 0x7b)) {
      param_1 = param_1 & 0xdf;
    }
    if (param_5 < 0x20) {
      *(byte *)(*param_3 + param_2) = param_1;
      *param_3 = *param_3 + 1;
      *param_4 = 2;
      return;
    }
  }
  *param_4 = 0;
  return;
}


// ==== asmapnam @ 800005ae

void asmapnam(byte param_1,char *param_2,int *param_3,undefined4 *param_4)

{
  switch(param_1) {
  case 9:
  case 10:
  case 0xd:
  case 0x20:
    while (*param_3 < 0xb) {
      param_2[*param_3] = ' ';
      *param_3 = *param_3 + 1;
    }
    if (*param_2 == '!') {
      *param_4 = 5;
    }
    else {
      *param_4 = 1;
    }
    break;
  default:
    if (((((0x40 < param_1) && (param_1 < 0x5b)) || ((0x2f < param_1 && (param_1 < 0x3a)))) ||
        (param_1 == 0x5f)) || ((0x60 < param_1 && (param_1 < 0x7b)))) {
      if ((0x60 < param_1) && (param_1 < 0x7b)) {
        param_1 = param_1 & 0xdf;
      }
      if (*param_3 < 8) {
        param_2[*param_3] = param_1;
        *param_3 = *param_3 + 1;
        return;
      }
    }
    *param_4 = 0;
    break;
  case 0x2e:
    while (*param_3 < 8) {
      param_2[*param_3] = ' ';
      *param_3 = *param_3 + 1;
    }
    *param_4 = 3;
    break;
  case 0x40:
    while (*param_3 < 0xb) {
      param_2[*param_3] = ' ';
      *param_3 = *param_3 + 1;
    }
    *param_4 = 4;
  }
  return;
}


// ==== asmapext @ 800007a2

void asmapext(byte param_1,char *param_2,int *param_3,undefined4 *param_4)

{
  if (param_1 == 0xd) {
LAB_8000081c:
    while (*param_3 < 0xb) {
      param_2[*param_3] = ' ';
      *param_3 = *param_3 + 1;
    }
    if (*param_2 == '!') {
      *param_4 = 5;
    }
    else {
      *param_4 = 1;
    }
  }
  else {
    if (param_1 < 0xe) {
      if ((param_1 < 0xb) && (8 < param_1)) goto LAB_8000081c;
    }
    else {
      if (param_1 == 0x20) goto LAB_8000081c;
      if (param_1 == 0x40) {
        while (*param_3 < 0xb) {
          param_2[*param_3] = ' ';
          *param_3 = *param_3 + 1;
        }
        *param_4 = 4;
        return;
      }
    }
    if (((((0x40 < param_1) && (param_1 < 0x5b)) || ((0x2f < param_1 && (param_1 < 0x3a)))) ||
        (param_1 == 0x5f)) || ((0x60 < param_1 && (param_1 < 0x7b)))) {
      if ((0x60 < param_1) && (param_1 < 0x7b)) {
        param_1 = param_1 & 0xdf;
      }
      if (*param_3 < 0xb) {
        param_2[*param_3] = param_1;
        *param_3 = *param_3 + 1;
        return;
      }
    }
    *param_4 = 0;
  }
  return;
}


// ==== asmapcom @ 80000906

void asmapcom(char param_1,undefined4 *param_2)

{
  if ((param_1 == '\n') || (param_1 == '\r')) {
    *param_2 = 1;
  }
  return;
}


// ==== asgetptp @ 80000934

void asgetptp(byte param_1,undefined4 param_2,undefined4 param_3,int param_4,undefined4 *param_5)

{
  undefined4 unaff_D7;
  
  if (param_1 == 0xd) {
LAB_8000099e:
    *param_5 = 1;
    return;
  }
  if (param_1 < 0xe) {
    if (param_1 == 9) {
LAB_8000097e:
      ashexbin(param_2,0);
      *(undefined4 *)(param_4 + 0xc) = unaff_D7;
      *param_5 = 6;
      return;
    }
    if (param_1 == 10) goto LAB_8000099e;
  }
  else {
    if (param_1 == 0x20) goto LAB_8000097e;
    if (param_1 == 0x40) {
      *param_5 = 4;
      return;
    }
  }
  getadrs(param_1,param_2,param_3,param_5);
  return;
}


// ==== asgetsiz @ 800009e0

void asgetsiz(byte param_1,undefined4 param_2,undefined4 param_3,int param_4,undefined4 *param_5)

{
  uint uVar1;
  uint unaff_D7;
  
  if (param_1 == 0xd) {
LAB_80000a1a:
    ashexbin(param_2);
    uVar1 = unaff_D7 >> 1;
    *(uint *)(param_4 + 0x10) = uVar1;
    *(uint *)(param_4 + 0x18) = unaff_D7 - uVar1;
    *(uint *)(param_4 + 0x14) = uVar1 + *(int *)(param_4 + 0xc);
    if (param_1 == 0x40) {
      *param_5 = 4;
    }
    else {
      *param_5 = 1;
    }
  }
  else {
    if (param_1 < 0xe) {
      if ((param_1 < 0xb) && (8 < param_1)) goto LAB_80000a1a;
    }
    else if ((param_1 == 0x20) || (param_1 == 0x40)) goto LAB_80000a1a;
    getadrs(param_1,param_2,param_3,param_5);
  }
  return;
}


// ==== getadrs @ 80000aae

void getadrs(byte param_1,int param_2,int *param_3,undefined4 *param_4)

{
  int local_8;
  
  local_8 = 0;
  if ((((param_1 < 0x41) || (0x46 < param_1)) && ((param_1 < 0x30 || (0x39 < param_1)))) &&
     ((param_1 < 0x61 || (0x66 < param_1)))) {
    local_8 = -4;
  }
  else {
    if ((0x60 < param_1) && (param_1 < 0x67)) {
      param_1 = param_1 & 0xdf;
    }
    if (*param_3 < 8) {
      *(byte *)(*param_3 + param_2) = param_1;
      *param_3 = *param_3 + 1;
      *(undefined1 *)(*param_3 + param_2) = 0;
    }
    else {
      local_8 = -4;
    }
  }
  if (local_8 != 0) {
    *param_4 = 0;
  }
  return;
}


// ==== asmaperr @ 80000b6a

void asmaperr(void)

{
  return;
}


// ==== ashexbin @ 80000bca

void ashexbin(int param_1)

{
  int local_a;
  
  for (local_a = 0; (local_a < 8 && (*(char *)(local_a + param_1) != '\0')); local_a = local_a + 1)
  {
  }
  return;
}


// ==== asdspall @ 80000c3c

void asdspall(int param_1)

{
  int iVar1;
  char *pcVar2;
  undefined1 auStack_14 [12];
  int local_8;
  
  prnbot();
  iVar1 = *(int *)(param_1 + 4) * 0x450 + memasign;
  for (local_8 = 0; local_8 < 0x20; local_8 = local_8 + 1) {
    pcVar2 = (char *)(local_8 * 0x20 + 0xc + iVar1);
    if (*pcVar2 != '\0') {
      slvfnam(pcVar2,auStack_14);
      switch(*(undefined1 *)(local_8 + param_1 + 0x1c)) {
      case 0:
        break;
      case 1:
        prnlod(auStack_14,local_8,1);
        break;
      case 2:
        prnlod(auStack_14,local_8,0);
        prncmp(auStack_14,local_8,0);
        break;
      case 3:
        prnlod(auStack_14,local_8,0);
        prncmp(auStack_14,local_8,1);
      }
    }
  }
  return;
}


// ==== asindsk @ 80000d54

void asindsk(undefined4 param_1)

{
  undefined1 auStack_10 [8];
  
  fs_dstat(param_1,auStack_10,0xffffffff);
  return;
}


// ==== asgetdrv @ 80000da6

void asgetdrv(void)

{
  sbpeek(0xf00a7f9);
  return;
}


// ==== dspmenu @ 80000e14

void dspmenu(int param_1)

{
  int local_8;
  
  for (local_8 = 0; local_8 < 8; local_8 = local_8 + 1) {
    prnstr(local_8 * 10 + 4,0x1b,local_8 * 2 + -0x6ffffc00,2,7,2);
    prnstr(local_8 * 10 + 9,0x1c,&DAT_9000047a,1,7,1);
    prnstr(local_8 * 10,0x1c,(uint)*(byte *)(local_8 + param_1 * 8 + -0x6ffffb9f) * 9 + -0x6ffffbf0,
           9,7,9);
  }
  return;
}


// ==== kyscan @ 80000ef0

short kyscan(void)

{
  int unaff_D7;
  undefined1 auStack_110 [4];
  short local_10c;
  undefined1 auStack_10a [256];
  short local_a;
  
  keystat(auStack_110);
  if (unaff_D7 == 0) {
    local_10c = -1;
  }
  else {
    local_a = (short)unaff_D7;
    do {
      kyreadtl(auStack_10a,(int)local_a,auStack_110);
    } while (unaff_D7 == 0);
    local_10c = *(short *)(auStack_110 + unaff_D7 * 2 + 4);
    if (local_10c == 0xd) {
      local_10c = 0x11f;
    }
  }
  return local_10c;
}


// ==== clrmenu @ 80000f82

void clrmenu(void)

{
  int local_8;
  
  for (local_8 = 0; local_8 < 8; local_8 = local_8 + 1) {
    prnstr(local_8 * 10 + 4,0x1b,s__9000047b,2,7,0);
    prnstr(local_8 * 10 + 9,0x1c,s__9000047b,1,7,0);
    prnstr(local_8 * 10,0x1c,s__9000047b,9,7,0);
    prnstr(0,0x1c,s_V1_XX_Kernel___SRMS_V1_XX___Star_9000055b + 0x140,0x50,7,1);
  }
  return;
}


// ==== getver @ 8000104e

void getver(void)

{
  return;
}


// ==== assrhobj @ 800010a0

/* WARNING: Removing unreachable block (ram,0x8000133a) */
/* WARNING: Restarted to delay deadcode elimination for space: stack */

void assrhobj(undefined4 *param_1,int param_2)

{
  char cVar1;
  int unaff_D7;
  int local_38;
  undefined1 auStack_32 [16];
  int local_22;
  short sVar2;
  int in_stack_ffffffec;
  undefined1 auStack_10 [4];
  char *local_c;
  
  param_1[2] = 0;
  param_1[3] = 0;
  local_22 = 0;
LAB_800010c4:
  while( true ) {
    while( true ) {
      while( true ) {
        local_c = (char *)(param_1[2] * 0x20 + 0xc + memasign + param_1[1] * 0x450);
        slvfnam(local_c,auStack_32);
        if (*local_c == '\0') goto LAB_800013ae;
        if (*local_c == '!') {
          local_38 = -1;
        }
        else {
          local_38 = 0;
        }
        cVar1 = *(char *)((int)param_1 + param_1[2] + 0x1c);
        if (((cVar1 != '\x03') && (cVar1 != '\x02')) || ((cVar1 == '\x03' && (param_2 == 1))))
        break;
        param_1[2] = param_1[2] + 1;
      }
      if (local_c[0x1f] != '\0') break;
      if (local_38 != -1) goto LAB_800013ae;
      prncmp(auStack_32,param_1[2],0);
      *(undefined1 *)((int)param_1 + param_1[2] + 0x1c) = 2;
      param_1[2] = param_1[2] + 1;
    }
    sVar2 = (short)((uint)unaff_D7 >> 0x10);
    if (local_22 == 0) {
      fs_mount(*param_1,auStack_10);
      if (unaff_D7 < 0) {
        srhlderr(param_1,local_c,(int)sVar2,1);
        goto LAB_800013ae;
      }
      local_22 = -1;
      in_stack_ffffffec = unaff_D7;
    }
    if ((local_38 == -1) ||
       (fs_srch(*param_1,local_c,auStack_10), in_stack_ffffffec = unaff_D7, -1 < unaff_D7)) break;
    prnlod(auStack_32,param_1[2],1);
    srhlderr(param_1,local_c,(int)sVar2,1);
    if (unaff_D7 == -0xf) {
LAB_800013ae:
      if (local_22 == -1) {
        fs_demnt(*param_1,auStack_10);
      }
      return;
    }
  }
  prnlod(auStack_32,param_1[2],0);
  if (local_38 != -1) {
    local_c[0x1c] = '\0';
    loader(0,local_c,0,0,*param_1);
    if (unaff_D7 == 0) {
      prncmp(auStack_32,param_1[2],1);
      srhlderr(param_1,local_c,(int)(short)((uint)in_stack_ffffffec >> 0x10),1);
      goto LAB_800010c4;
    }
    if (unaff_D7 < 2) {
      local_c[0x1c] = '\0';
    }
    else {
      local_c[0x1c] = (char)unaff_D7;
    }
  }
  prncmp(auStack_32,param_1[2],0);
  local_c[0x1e] = '\0';
  *(undefined1 *)((int)param_1 + param_1[2] + 0x1c) = 2;
  param_1[2] = param_1[2] + 1;
  local_c[0x1f] = '\0';
  goto LAB_800010c4;
}


// ==== srhlderr @ 800013d6

void srhlderr(int param_1,int param_2,int param_3,int param_4)

{
  int unaff_D7;
  int iVar1;
  
  if (param_4 == 0) {
    unaff_D7 = param_3;
  }
  else {
    asloderr(param_3);
  }
  if (unaff_D7 < 0) {
    if (unaff_D7 == -0xf) {
      *(undefined4 *)(param_1 + 0xc) = 0xffffffff;
      iVar1 = -0xf;
    }
    else if (unaff_D7 == -10) {
      *(undefined1 *)(*(int *)(param_1 + 8) + param_1 + 0x1c) = 1;
      iVar1 = 0;
      *(undefined4 *)(param_1 + 0xc) = 0xffffffff;
    }
    else {
      *(undefined1 *)(*(int *)(param_1 + 8) + param_1 + 0x1c) = 3;
      iVar1 = 0;
      *(undefined4 *)(param_1 + 0x10) = 0xffffffff;
    }
    if (*(int *)(param_1 + 0x14) == 0) {
      *(undefined4 *)(param_1 + 0x14) = 0xffffffff;
      asdspall(param_1);
    }
    if (iVar1 == 0) {
      *(int *)(param_1 + 8) = *(int *)(param_1 + 8) + 1;
      *(undefined1 *)(param_2 + 0x1f) = 0xff;
    }
  }
  return;
}


// ==== asallobj @ 800014b8

/* WARNING: Removing unreachable block (ram,0x8000158c) */
/* WARNING: Removing unreachable block (ram,0x80001596) */

void asallobj(uint *param_1,undefined4 param_2)

{
  uint uVar1;
  bool bVar2;
  int unaff_D7;
  int local_18;
  uint local_c;
  
  local_c = *param_1;
  uVar1 = *param_1;
  local_18 = 0;
  bVar2 = false;
  do {
    while( true ) {
      *param_1 = local_c;
      assrhobj(param_1,param_2);
      if (param_1[3] == 0) {
        return;
      }
      if (local_c == 6) {
        return;
      }
      if ((bVar2) || (unaff_D7 != 0)) break;
      local_c = (uint)(local_c == 0);
      bVar2 = true;
    }
    dspmenu(2);
    if ((unaff_D7 == -0xf) && (local_c == uVar1)) {
      prnmsg(1);
      do {
        asindsk(local_c);
        kyscan();
      } while( true );
    }
    prnmsg(2);
    dspmenu(2);
    while (asindsk(local_c), unaff_D7 != 0) {
      kyscan();
      if ((short)unaff_D7 == 0x11f) {
        local_18 = -1;
        break;
      }
      local_c = (uint)(local_c == 0);
    }
    clrmenu();
    prnmsg(0);
    if (local_18 == -1) {
      return;
    }
  } while( true );
}


// ==== asload @ 80001618

/* WARNING: Removing unreachable block (ram,0x80001844) */
/* WARNING: Removing unreachable block (ram,0x8000184e) */
/* WARNING: Removing unreachable block (ram,0x8000184c) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void asload(int *param_1,int param_2)

{
  char *__s1;
  int unaff_D7;
  int local_1c;
  int local_c;
  
  if (param_2 != 1) {
    dscint();
    prnbot();
    for (local_1c = 0; local_1c < 0x20; local_1c = local_1c + 1) {
      *(undefined1 *)((int)param_1 + local_1c + 0x1c) = 0;
    }
  }
  asgetdrv();
  *param_1 = unaff_D7;
  local_c = 0;
  param_1[1] = 0;
  do {
    if (7 < param_1[1]) {
      param_1[1] = (uint)*(byte *)(memasign + 0x268e);
      if (param_1[1] == 8) {
        param_1[1] = 0;
      }
      asorgobj(param_1[1]);
      local_c = -1;
LAB_80001740:
      if (local_c == -1) {
                    /* WARNING: Could not recover jumptable at 0x80001760. Too many branches */
                    /* WARNING: Treating indirect jump as call */
        (*(code *)(&DAT_80001764 + _DAT_80001764))();
        return;
      }
      asallobj(param_1,param_2);
      if ((-1 < unaff_D7) && (param_1[4] == 0)) {
        *(char *)(memasign + 0x268e) = (char)param_1[1] + '\x01';
      }
      return;
    }
    __s1 = (char *)(param_1[1] * 0x450 + memasign);
    if (*__s1 == '\0') {
      local_c = -1;
      goto LAB_80001740;
    }
    strcmp(__s1,(char *)param_1[0xf]);
    if (unaff_D7 == 0) goto LAB_80001740;
    param_1[1] = param_1[1] + 1;
  } while( true );
}


// ==== lodmd1 @ 800018a4

void lodmd1(undefined4 *param_1,undefined4 *param_2)

{
  undefined4 unaff_D7;
  short sVar1;
  undefined1 auStack_8 [4];
  
  fs_mount(*param_2,auStack_8,0);
  sVar1 = (short)((uint)unaff_D7 >> 0x10);
  if (sVar1 == -4) {
    *param_1 = 1;
    return;
  }
  if (sVar1 < -3) {
    if (sVar1 == -0x2e) {
LAB_800018e2:
      *param_1 = 3;
      return;
    }
  }
  else if (sVar1 == 0) goto LAB_800018e2;
  *param_1 = 2;
  return;
}


// ==== lodmd4 @ 8000191e

/* WARNING: Restarted to delay deadcode elimination for space: stack */

void lodmd4(int *param_1,undefined4 *param_2)

{
  int unaff_D7;
  undefined1 auStack_18 [4];
  short sVar1;
  
  *param_1 = 4;
  fs_srch(*param_2,param_2[0xf],auStack_18);
  sVar1 = (short)((uint)unaff_D7 >> 0x10);
  if ((unaff_D7 < 0) && (sVar1 != -0x2e)) {
    if (sVar1 == -3) {
      *param_1 = 2;
    }
    else {
      *param_1 = 2;
    }
  }
  if (*param_1 == 4) {
    asgetmap(*param_2,param_2[0xf],param_2[1]);
    if (unaff_D7 < 0) {
      if (unaff_D7 == -6) {
        *param_1 = 1;
      }
      else if (unaff_D7 == -3) {
        *param_1 = 2;
      }
      else {
        *param_1 = 1;
      }
    }
    else {
      cpybuf(param_2[0xf],param_2[1] * 0x450 + memasign,0xb);
    }
  }
  return;
}


// ==== asorgobj @ 80001a4c

void asorgobj(int param_1)

{
  char *__s2;
  int iVar1;
  short sVar2;
  short sVar3;
  int unaff_D7;
  char *pcVar4;
  char *__s1;
  short local_a;
  int local_8;
  
  iVar1 = memasign + param_1 * 0x450;
  local_a = 0;
  do {
    if (0x1f < local_a) {
      return;
    }
    __s1 = (char *)(local_a * 0x20 + 0xc + iVar1);
    if (__s1[0x1e] != -1) {
      if (*__s1 == '\0') {
        return;
      }
      local_8 = 0;
      for (sVar2 = 0; sVar2 < 8; sVar2 = sVar2 + 1) {
        if ((sVar2 != param_1) && (pcVar4 = (char *)(memasign + sVar2 * 0x450), *pcVar4 != '\0')) {
          for (sVar3 = 0; sVar3 < 0x20; sVar3 = sVar3 + 1) {
            __s2 = pcVar4 + sVar3 * 0x20 + 0xc;
            if ((*__s2 != '\0') && (strcmp(__s1,__s2), unaff_D7 == 0)) {
              __s1[0x1e] = '\0';
              local_8 = -1;
              break;
            }
          }
          if (local_8 == -1) break;
        }
      }
    }
    local_a = local_a + 1;
  } while( true );
}


// ==== asloderr @ 80001b32

void asloderr(void)

{
  return;
}


// ==== prtct @ 80001b7e

void prtct(void)

{
  return;
}


// ==== prnbot @ 80001b88

void prnbot(void)

{
  clrdsp();
  prnstr(0,0,lodbuf + 0x28,0x50,7,9);
  prnstr(0,1,lodbuf + 0x28,5,7,9);
  prnsprd(5,1,lodbuf + 0x78,0x23,7,10);
  prnstr(0x4b,1,lodbuf + 0x28,5,7,9);
  prnstr(0,2,s_V1_XX_Kernel___SRMS_V1_XX___Star_9000055b,0x50,7,9);
  prnstr(0,3,s_V1_XX_Kernel___SRMS_V1_XX___Star_9000055b + 0x50,0x50,7,9);
  prnstr(0,4,s_V1_XX_Kernel___SRMS_V1_XX___Star_9000055b + 0xa0,0x50,7,9);
  prnstr(0,5,s_V1_XX_Kernel___SRMS_V1_XX___Star_9000055b + 0xf0,0x50,7,9);
  prnstr(0,0x1c,s_V1_XX_Kernel___SRMS_V1_XX___Star_9000055b + 0x140,0x50,7,1);
  return;
}


// ==== prnlod @ 80001ce2

void prnlod(int param_1,byte param_2,int param_3)

{
  byte bVar1;
  int iVar2;
  undefined4 local_14;
  undefined4 local_10;
  char *local_c;
  char local_5;
  
  if (param_2 < 0x10) {
    local_5 = '\a';
  }
  else {
    local_5 = '-';
  }
  bVar1 = (param_2 & 0xf) + 8;
  if ((7 < bVar1) && (bVar1 < 0x19)) {
    cmdwrt(0x3c,7,0,0,0,2);
    for (iVar2 = 0; iVar2 < 0x1a; iVar2 = iVar2 + 1) {
      (&dastr)[iVar2] = 0x20;
    }
    for (iVar2 = 0; (*(char *)(iVar2 + param_1) != '\0' && (iVar2 < 0xc)); iVar2 = iVar2 + 1) {
      (&DAT_90005dc9)[iVar2] = *(undefined1 *)(iVar2 + param_1);
    }
    prnstr(local_5,bVar1,&dastr,0x1a,7,9);
    if (param_3 == 0) {
      local_c = lodbuf;
      local_10 = 0x19;
      local_14 = 7;
    }
    else {
      local_c = lodbuf + 0x1e;
      local_10 = 9;
      local_14 = 5;
    }
    prnstr(local_5 + '\x11',bVar1,local_c,local_14,7,local_10);
  }
  return;
}


// ==== prncmp @ 80001e1e

void prncmp(int param_1,byte param_2,int param_3)

{
  byte bVar1;
  int iVar2;
  undefined1 local_5;
  
  cmdwrt(0,0,0,0,0,1);
  for (iVar2 = 0; iVar2 < 0x1a; iVar2 = iVar2 + 1) {
    (&dastr)[iVar2] = 0x20;
  }
  for (iVar2 = 0; (*(char *)(iVar2 + param_1) != '\0' && (iVar2 < 0xc)); iVar2 = iVar2 + 1) {
    (&DAT_90005dc9)[iVar2] = *(undefined1 *)(iVar2 + param_1);
  }
  if (param_3 == 0) {
    for (iVar2 = 0; iVar2 < 10; iVar2 = iVar2 + 1) {
      (&DAT_90005dd9)[iVar2] = lodbuf[iVar2 + 10];
    }
  }
  else {
    for (iVar2 = 0; iVar2 < 10; iVar2 = iVar2 + 1) {
      (&DAT_90005dd9)[iVar2] = lodbuf[iVar2 + 0x14];
    }
  }
  DAT_90005de2 = 0;
  if (param_2 < 0x10) {
    local_5 = 7;
  }
  else {
    local_5 = 0x2d;
  }
  bVar1 = (param_2 & 0xf) + 8;
  if ((7 < bVar1) && (bVar1 < 0x19)) {
    cmdwrt(0x3e,9,0,0,0,2);
    cmdwrt(0x4c,local_5,bVar1,0,0,3);
    puts1(local_5,bVar1,&dastr);
    cmdwrt(0x7a,0,bVar1,0,0,3);
  }
  return;
}


// ==== clrdsp @ 80001f94

void clrdsp(void)

{
  cmdwrt(0,0,0,0,0,1);
  cmdwrt(0x60,0,0,0,0,1);
  cmdwrt(0x78,0,0,0,0,3);
  return;
}


// ==== dscint @ 80001fe0

void dscint(void)

{
  undefined4 unaff_D7;
  
  fill(&dastr,0x50,0x20);
  DAT_90005e18 = 0;
  init_dsc();
  cmdwrt(0x10,0,0,0x50,0x1d,5);
  devtrp(8,0,&mybuf);
  cpybuf(&mybuf,s_V1_XX_Kernel___SRMS_V1_XX___Star_9000055b + 0xc6,0);
  devtrp(8,1,&mybuf);
  cpybuf(&mybuf,s_V1_XX_Kernel___SRMS_V1_XX___Star_9000055b + 0x23,0);
  getver();
  DAT_900007b1 = (byte)((uint)unaff_D7 >> 8) | 0x30;
  DAT_900007b2 = (byte)unaff_D7 | 0x30;
  DAT_900007af = (byte)((uint)unaff_D7 >> 0x10) | 0x30;
  return;
}


// ==== prnmsg @ 800020e4

void prnmsg(int param_1)

{
  undefined4 local_8;
  
  if (param_1 == 0) {
    local_8 = 0;
  }
  else {
    local_8 = 8;
  }
  if ((param_1 < 4) && (msgtbl[param_1 * 0x1c] != '\0')) {
    prnstr(0x1a,0x19,msgtbl + param_1 * 0x1c,0x1b,7,local_8);
  }
  return;
}


// ==== clrmsg @ 80002150

void clrmsg(void)

{
  prnstr(0x1a,0x19,s_EXECUTION_CANCELED_9000091f + 0x1c,0x1b,7,8);
  return;
}


// ==== prnstr @ 8000217c

undefined4
prnstr(undefined1 param_1,undefined1 param_2,int param_3,ushort param_4,undefined4 param_5,
      undefined1 param_6)

{
  undefined2 extraout_D0u;
  uint uVar1;
  uint uVar2;
  char acStack_10e [262];
  ushort local_8;
  
  if (param_4 == 0) {
    for (local_8 = 0; *(char *)(param_3 + (uint)local_8) != '\0'; local_8 = local_8 + 1) {
    }
    param_4 = local_8;
  }
  uVar1 = (uint)param_4;
  cmdwrt(0x3e,param_6,0,0,0,2);
  cursor_mo(param_1,param_2);
  for (; 0 < (int)uVar1; uVar1 = uVar1 - uVar2) {
    if (uVar1 < 0x101) {
      uVar2 = uVar1;
    }
    else {
      uVar2 = 0x100;
    }
    cpybuf(param_3,acStack_10e,uVar2);
    acStack_10e[uVar2] = '\0';
    puts(acStack_10e);
  }
  cmdwrt(0x40,0,0,0,0,1);
  cmdwrt(0x7a,0,0,0,0,3);
  return CONCAT22(extraout_D0u,local_8);
}


// ==== prnsprd @ 80002294

void prnsprd(undefined1 param_1,undefined1 param_2,int param_3,ushort param_4,undefined1 param_5,
            undefined1 param_6)

{
  int iVar1;
  undefined2 local_54 [40];
  
  for (iVar1 = 0; iVar1 < (int)(uint)param_4; iVar1 = iVar1 + 1) {
    local_54[iVar1] =
         *(undefined2 *)
          (s_INSERT_System_Disks_900008e7 + (uint)*(byte *)(iVar1 + param_3) * 2 + 0x15);
  }
  prnstr(param_1,param_2,local_54,(uint)param_4 << 1,param_5,param_6);
  return;
}


// ==== startup @ 80002324

/* WARNING: Removing unreachable block (ram,0x8000241e) */

void startup(void)

{
  int unaff_D7;
  undefined1 auStack_62 [2];
  undefined1 local_60;
  short local_5a;
  undefined4 *local_54;
  undefined1 auStack_50 [16];
  int local_40;
  undefined4 local_3c;
  undefined4 local_38;
  char *local_14;
  undefined4 local_c;
  
  local_c = 0;
  spfled(1);
  sralloc(0x4000);
  memasign = unaff_D7;
  fill();
  while( true ) {
    *(undefined2 *)(memasign + 0x44e) = 0;
    local_40 = 0;
    local_14 = bootmap;
    local_3c = 0xffffffff;
    local_38 = 0;
    asload(auStack_50,local_c);
    if (((-1 < unaff_D7) && (local_40 != -1)) && (lnch_top(), unaff_D7 == 0)) break;
    prnmsg(3);
    dspmenu(1);
    do {
      kyscan();
    } while ((short)unaff_D7 != 0x118);
    local_c = 1;
    clrmenu();
    prnmsg(0);
  }
  spfledoff();
  do {
    do {
      wtmsg();
      remsg(auStack_62);
    } while (local_5a != 3);
    lnch_app();
    *local_54 = 0;
    post(local_60,0x4000000);
  } while( true );
}


// ==== resettbl @ 8000245a

void resettbl(int param_1)

{
  int iVar1;
  int iVar2;
  int iVar3;
  
  iVar1 = memasign + param_1 * 0x450;
  fill(iVar1,0x450,0);
  for (iVar2 = 0; iVar2 < 0x20; iVar2 = iVar2 + 1) {
    iVar3 = iVar2 * 0x20 + 0xc + iVar1;
    *(undefined1 *)(iVar3 + 0x1f) = 0xff;
    *(undefined1 *)(iVar3 + 0x1e) = 0;
  }
  return;
}


// ==== lnch_top @ 800024b2

void lnch_top(void)

{
  int iVar1;
  char *pcVar2;
  
  iVar1 = 0;
  while( true ) {
    pcVar2 = (char *)(iVar1 * 0x20 + memasign + (uint)*(byte *)(memasign + 0x268e) * 0x450 + -0x444)
    ;
    if (*pcVar2 == '\0') {
      return;
    }
    if (pcVar2[0x1d] == '\0') break;
    iVar1 = iVar1 + 1;
  }
  mapset(pcVar2[0x1c],0x60);
  start(1,pcVar2[0x1c],0);
  return;
}


// ==== lnch_app @ 80002554

/* WARNING: Removing unreachable block (ram,0x80002608) */

void lnch_app(void)

{
  int iVar1;
  int iVar2;
  int unaff_D7;
  char *pcVar3;
  char cVar4;
  
  iVar1 = memasign + (uint)*(byte *)(memasign + 0x268e) * 0x450 + -0x444;
  cVar4 = '\x01';
  iVar2 = 0;
  while (pcVar3 = (char *)(iVar2 * 0x20 + iVar1), *pcVar3 != '\0') {
    if (cVar4 == pcVar3[0x1d]) {
      if (((pcVar3[0x1c] != '\0') && (*pcVar3 != '!')) &&
         (cmpstr(pcVar3,"DIAG    OBJ"), unaff_D7 == 0)) {
        mapset(pcVar3[0x1c],0x60);
        start(1,pcVar3[0x1c],0);
      }
      cVar4 = cVar4 + '\x01';
      iVar2 = 0;
    }
    else {
      iVar2 = iVar2 + 1;
    }
  }
  return;
}


// ==== r_dscman @ 8000262c

void r_dscman(void)

{
  init_dsc();
  return;
}


// ==== nwawon @ 8000263a

void nwawon(void)

{
  return;
}


// ==== nwainit @ 80002642

void nwainit(void)

{
  return;
}


// ==== swainit @ 8000264a

void swainit(void)

{
  return;
}


// ==== dfcvcbtbl @ 80002652

void dfcvcbtbl(void)

{
  return;
}


// ==== swawon @ 8000265a

void swawon(undefined4 param_1,byte param_2,byte param_3)

{
  uint uVar1;
  uint uVar2;
  int unaff_D7;
  
  uVar1 = (uint)param_2;
  uVar2 = (uint)param_3;
  scroll_se(uVar1,(uVar1 - 1) + uVar2);
  if (unaff_D7 < 0) {
    scroll = 0xffffffff;
  }
  else {
    DAT_90001370 = 0;
    DAT_90001374 = uVar2 - 1;
    scroll = uVar1;
    DAT_9000136c = uVar2;
    fillvram(&DAT_90001378,0x1130,0x20);
  }
  return;
}


// ==== swawoff @ 800026be

void swawoff(void)

{
  int iVar1;
  int iVar2;
  
  if (-1 < scroll) {
    iVar1 = DAT_9000136c;
    iVar2 = scroll;
    while (iVar1 = iVar1 + -1, -1 < iVar1) {
      cursor_mo(0,iVar2);
      erase_lin();
      iVar2 = iVar2 + 1;
    }
    scroll = -1;
    scroll_se(0,0);
  }
  return;
}


// ==== swascex @ 8000270e

void swascex(char param_1,ushort param_2)

{
  if (-1 < scroll) {
    if (param_1 == '\x01') {
      DAT_90001370 = DAT_90001370 - (short)param_2;
      if (DAT_90001370 < 0) {
        DAT_90001370 = DAT_90001370 + 0x37;
      }
      DAT_90001374 = DAT_90001374 - (short)param_2;
      if (DAT_90001374 < 0) {
        DAT_90001374 = DAT_90001374 + 0x37;
      }
      while (param_2 = param_2 - 1, -1 < (int)((uint)param_2 << 0x10)) {
        scroll_do();
      }
    }
    else {
      DAT_90001370 = DAT_90001370 + (short)param_2;
      if (0x36 < DAT_90001370) {
        DAT_90001370 = DAT_90001370 + -0x37;
      }
      DAT_90001374 = DAT_90001374 + (short)param_2;
      if (0x36 < DAT_90001374) {
        DAT_90001374 = DAT_90001374 + -0x37;
      }
      while (param_2 = param_2 - 1, -1 < (int)((uint)param_2 << 0x10)) {
        scroll_up();
      }
    }
    if (DAT_90001370 < DAT_90001374) {
      xy2vram(0,scroll,DAT_9000136c * 0x50);
      cpyvram(&DAT_90001378 + DAT_90001370 * 0xa0);
      fillvram(&DAT_90001378,DAT_90001370 * 0x50,0x20);
      fillvram(DAT_90001374 * 0x140 + -0x6fffeb48,(0x36 - DAT_90001374) * 0x50,0x20);
    }
    else {
      xy2vram(0,scroll,(0x37 - DAT_90001370) * 0x50);
      cpyvram(&DAT_90001378 + DAT_90001370 * 0xa0);
      xy2vram(0,scroll - (DAT_90001370 + -0x37),(DAT_90001374 + 1) * 0x50);
      cpyvram(&DAT_90001378);
      fillvram(DAT_90001374 * 0x140 + -0x6fffeb48,((DAT_90001370 - DAT_90001374) + -1) * 0x50,0x20);
    }
  }
  return;
}


// ==== swawrite @ 800028f0

void swawrite(byte param_1,byte param_2,undefined4 param_3,byte param_4,byte *param_5)

{
  byte bVar1;
  int iVar2;
  ushort uVar3;
  uint uVar4;
  ushort *unaff_D7;
  ushort *puVar5;
  ushort *puVar6;
  ushort uStack_a;
  byte *local_8;
  
  local_8 = param_5;
  if (-1 < scroll) {
    bVar1 = param_4 & 7;
    if (bVar1 == 1) {
      uVar3 = 1;
    }
    else if (bVar1 < 2) {
      if (bVar1 != 0) {
LAB_80002956:
        reverse_s(1);
        puts1(0,0,"swawrite(): Illegal Font");
        reverse_s(0);
        do {
                    /* WARNING: Do nothing block with infinite loop */
        } while( true );
      }
      uVar3 = 0;
    }
    else {
      if (bVar1 != 2) goto LAB_80002956;
      uVar3 = 2;
    }
    if ((param_4 & 8) != 0) {
      uVar3 = uVar3 | 4;
    }
    uVar4 = (uint)(int)(short)(ushort)param_2 % 0x37;
    puVar6 = &DAT_90001378 + (uint)param_1 * 2 + uVar4 * 0xa0;
    if (*param_5 != 0) {
      do {
        if ((ushort *)0x90005837 < puVar6) {
          puVar6 = &DAT_90001378;
        }
        puVar5 = puVar6 + 1;
        *puVar6 = (ushort)*local_8 | uVar3 << 8;
        uStack_a = (ushort)((param_4 & 0x10) != 0);
        puVar6 = puVar6 + 2;
        *puVar5 = uStack_a << 0xf | 7;
        puVar5 = (ushort *)0x0;
        xy2vram(0x4f,DAT_9000136c + scroll + -1);
        if (DAT_90001370 < DAT_90001374) {
          if ((DAT_90001370 <= (int)uVar4) && ((int)uVar4 <= DAT_90001374)) {
            xy2vram(param_1,(scroll + uVar4) - DAT_90001370);
            goto LAB_80002a8e;
          }
        }
        else {
          if ((int)uVar4 < DAT_90001370) {
            if (DAT_90001374 < (int)uVar4) goto LAB_80002a92;
            iVar2 = (scroll + uVar4) - (DAT_90001370 + -0x37);
          }
          else {
            iVar2 = (scroll + uVar4) - DAT_90001370;
          }
          xy2vram(param_1,iVar2);
LAB_80002a8e:
          puVar5 = unaff_D7;
        }
LAB_80002a92:
        if (puVar5 != (ushort *)0x0) {
          *puVar5 = (ushort)*local_8 | uVar3 << 8;
          puVar5[1] = uStack_a << 0xf | 7;
        }
        local_8 = local_8 + 1;
        param_1 = param_1 + 1;
        if (0x4f < param_1) {
          param_1 = 0;
          bVar1 = (char)uVar4 + 1;
          uVar4 = (uint)bVar1;
          if (0x37 < bVar1) {
            uVar4 = (uint)(int)(short)(ushort)bVar1 % 0x37;
          }
        }
      } while (*local_8 != 0);
    }
  }
  return;
}


// ==== nwawrite @ 80002b06

void nwawrite(undefined4 param_1,undefined1 param_2,undefined1 param_3,undefined4 param_4,
             byte param_5,undefined4 param_6)

{
  undefined4 uVar1;
  
  reverse_s((param_5 & 8) != 0);
  blink_set((param_5 & 0x10) != 0);
  param_5 = param_5 & 7;
  if (param_5 == 1) {
    uVar1 = 1;
  }
  else if (param_5 < 2) {
    if (param_5 != 0) {
LAB_80002b7e:
      reverse_s(1);
      puts1(0,0,"nwawrite(): Illegal Font");
      reverse_s(0);
      do {
                    /* WARNING: Do nothing block with infinite loop */
      } while( true );
    }
    uVar1 = 0;
  }
  else {
    if (param_5 != 2) goto LAB_80002b7e;
    uVar1 = 2;
  }
  font_set(uVar1);
  puts1(param_2,param_3,param_6);
  return;
}


// ==== cmdwrt @ 80002c10

void cmdwrt(undefined1 param_1,byte param_2,undefined1 param_3)

{
  int iVar1;
  
  switch(param_1) {
  case 0:
  case 0x10:
  case 0x3c:
  case 0x5b:
  case 0x78:
  case 0x7a:
    break;
  default:
    reverse_s(1);
    puts1(0,0,"cmdwrt(): Illegal command");
    reverse_s(0);
    do {
                    /* WARNING: Do nothing block with infinite loop */
    } while( true );
  case 0x30:
switchD_80002c32_caseD_30:
    font_set(0);
    break;
  case 0x31:
switchD_80002c32_caseD_31:
    font_set(1);
    break;
  case 0x32:
switchD_80002c32_caseD_32:
    font_set(2);
    break;
  case 0x33:
switchD_80002c32_caseD_33:
    font_set(3);
    break;
  case 0x38:
    blink_set(0);
    break;
  case 0x39:
    blink_set(1);
    break;
  case 0x3a:
    reverse_s(0);
    break;
  case 0x3b:
    reverse_s(1);
    break;
  case 0x3e:
    blink_set((param_2 & 0x10) != 0);
    reverse_s((param_2 & 8) != 0);
    switch(param_2 & 7) {
    case 0:
      goto switchD_80002c32_caseD_30;
    case 1:
      goto switchD_80002c32_caseD_31;
    case 2:
      goto switchD_80002c32_caseD_32;
    case 3:
      goto switchD_80002c32_caseD_33;
    default:
      reverse_s(1);
      puts1(0,0,"cmdwrt(): Illegal font");
      reverse_s(0);
      do {
                    /* WARNING: Do nothing block with infinite loop */
      } while( true );
    }
  case 0x40:
    cursor_mo(0,0);
    break;
  case 0x42:
    cursor_ne();
    break;
  case 0x44:
    cursor_ri();
    break;
  case 0x45:
    cursor_le();
    break;
  case 0x4c:
    cursor_mo(param_2,param_3);
    break;
  case 0x5e:
    DAT_90005838 = (uint)(param_2 >> 4);
    DAT_9000583c = (uint)(param_2 & 0xf);
    cursor_de(DAT_90005840,DAT_90005838,DAT_9000583c,7);
    break;
  case 0x5f:
    if (param_2 == 0) {
      DAT_90005840 = 0;
      cursor_de(0,DAT_90005838,DAT_9000583c,7);
    }
    else {
      if (param_2 != 1) {
        reverse_s(1);
        puts1(0,0,"cmdwrt(): Illegal cursor mode");
        reverse_s(0);
        do {
                    /* WARNING: Do nothing block with infinite loop */
        } while( true );
      }
      DAT_90005840 = 1;
      cursor_de(1,DAT_90005838,DAT_9000583c,7);
    }
    break;
  case 0x60:
    iVar1 = 0;
    do {
      cursor_mo(0,iVar1);
      erase_lin();
      iVar1 = iVar1 + 1;
    } while (iVar1 < 0x1d);
    break;
  case 0x61:
    erase_lin();
  }
  return;
}


// ==== xy2vram @ 80002f4c

void xy2vram(void)

{
  return;
}


// ==== fillvram @ 8000300c

void fillvram(ushort *param_1,short param_2,byte param_3)

{
  while (param_2 = param_2 + -1, -1 < param_2) {
    *param_1 = (ushort)param_3 | DAT_900058d4 << 8;
    param_1[1] = DAT_900058c8 | DAT_900058cc << 4 | DAT_900058d0 << 8;
    param_1 = param_1 + 2;
  }
  return;
}


// ==== cpyvram @ 80003062

void cpyvram(undefined2 *param_1,undefined2 *param_2,short param_3)

{
  param_3 = param_3 << 1;
  while (param_3 = param_3 + -1, -1 < param_3) {
    *param_2 = *param_1;
    param_1 = param_1 + 1;
    param_2 = param_2 + 1;
  }
  return;
}


// ==== screen_se @ 8000308e

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void screen_se(void)

{
  _DAT_0d01c980 = (short)(DAT_900058a2 + 0xf3000000U >> 2);
  _DAT_0d01c982 = (short)(DAT_900058aa + 0xf3000000U >> 2);
  _DAT_0d01c984 = (short)(DAT_900058b2 + 0xf3000000U >> 2);
  _DAT_0d01c986 = (short)(DAT_900058ba + 0xf3000000U >> 2);
  _DAT_0d01c990 = (short)DAT_9000589e;
  _DAT_0d01c992 = (short)DAT_900058a6;
  _DAT_0d01c994 = (short)DAT_900058ae;
  _DAT_0d01c996 = (short)DAT_900058b6;
  return;
}


// ==== cursor_co @ 80003114

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void cursor_co(void)

{
  int unaff_D7;
  
  _DAT_0d01c9a2 = DAT_90005890 | DAT_9000588c << 8 | DAT_90005880 << 0xd;
  _DAT_0d01c9a4 = DAT_90005894;
  xy2vram(DAT_90005882,DAT_90005886);
  DAT_90005896 = unaff_D7;
  if (unaff_D7 != 0) {
    _DAT_0d01c9a0 = (undefined2)(unaff_D7 + 0xf3000000U >> 2);
    _DAT_0d01cffe = 1;
  }
  return;
}


// ==== cursor_de @ 80003190

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void cursor_de(undefined4 param_1,int param_2,int param_3,int param_4)

{
  switch(param_1) {
  case 0:
  case 2:
  case 3:
    if (param_2 < 0) {
      return;
    }
    if (8 < param_2) {
      return;
    }
    if (param_3 < 0) {
      return;
    }
    if (8 < param_3) {
      return;
    }
    if (param_3 < param_2) {
      return;
    }
    if (param_4 < 0) {
      return;
    }
    if (0xf < param_4) {
      return;
    }
    _DAT_9000588a = param_2;
    _DAT_9000588e = param_3;
    _DAT_90005892 = param_4;
switchD_800031b6_caseD_1:
    ram0x9000587e = param_1;
    cursor_co();
    return;
  case 1:
    goto switchD_800031b6_caseD_1;
  default:
    return;
  }
}


// ==== cursor_mo @ 80003220

void cursor_mo(int param_1,int param_2)

{
  if ((((-1 < param_1) && (param_1 < 0x50)) && (-1 < param_2)) && (param_2 < 0x1d)) {
    DAT_90005882 = param_1;
    DAT_90005886 = param_2;
    cursor_co();
  }
  return;
}


// ==== cursor_ne @ 80003270

void cursor_ne(void)

{
  DAT_90005886 = DAT_90005886 + 1;
  if (DAT_90005886 < 0x1d) {
    DAT_90005882 = 0;
  }
  else {
    DAT_90005886 = 0x1c;
  }
  cursor_co();
  return;
}


// ==== cursor_ri @ 800032a0

void cursor_ri(void)

{
  DAT_90005882 = DAT_90005882 + 1;
  if (0x4f < DAT_90005882) {
    DAT_90005886 = DAT_90005886 + 1;
    if (DAT_90005886 < 0x1d) {
      DAT_90005882 = 0;
    }
    else {
      DAT_90005882 = 0x4f;
      DAT_90005886 = 0x1c;
    }
  }
  cursor_co();
  return;
}


// ==== cursor_le @ 800032ea

void cursor_le(void)

{
  DAT_90005882 = DAT_90005882 + -1;
  if (DAT_90005882 < 0) {
    DAT_90005886 = DAT_90005886 + -1;
    if (DAT_90005886 < 0) {
      DAT_90005882 = 0;
      DAT_90005886 = 0;
    }
    else {
      DAT_90005882 = 0x4f;
    }
  }
  cursor_co();
  return;
}


// ==== scroll_se @ 8000332e

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void scroll_se(int param_1,int param_2)

{
  if ((((-1 < param_1) && (param_1 < 0x1d)) && (-1 < param_2)) &&
     ((param_2 < 0x1d && (param_1 <= param_2)))) {
    if (partition != 0) {
      if (partition == 1) {
        cpyvram(DAT_900058a2,0xd000000,DAT_9000589e * 0x50);
      }
      else {
        cpyvram(DAT_900058aa,DAT_9000589e * 0x140 + 0xd000000,DAT_900058a6 * 0x50);
      }
      partition = 0;
      DAT_9000589e = 0x1d;
      DAT_900058a2 = 0xd000000;
      DAT_900058a6 = 0;
      DAT_900058aa = 0xd000000;
      DAT_900058ae = 0;
      DAT_900058b2 = 0xd000000;
      DAT_900058b6 = 0;
      DAT_900058ba = 0xd000000;
    }
    if (param_1 < param_2) {
      param_2 = param_2 + 1;
      cpyvram(DAT_900058a2 + param_1 * 0x140,0xd002440,(param_2 - param_1) * 0x50);
      if (param_1 == 0) {
        partition = 1;
        if (param_2 < 0x1d) {
          DAT_900058a6 = 0x1d - param_2;
          DAT_900058aa = param_2 * 0x140 + 0xd000000;
          DAT_9000589e = param_2;
        }
        else {
          DAT_9000589e = 0x1d;
        }
        DAT_900058a2 = 0xd002440;
      }
      else {
        partition = 2;
        DAT_9000589e = param_1;
        DAT_900058a6 = param_2 - param_1;
        DAT_900058aa = 0xd002440;
        if (param_2 < 0x1d) {
          DAT_900058ae = 0x1d - param_2;
          DAT_900058b2 = param_2 * 0x140 + 0xd000000;
        }
      }
    }
    screen_se();
    _DAT_0d01cffe = 1;
  }
  return;
}


// ==== scroll_up @ 80003510

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void scroll_up(void)

{
  int *piVar1;
  
  if (partition != 0) {
    if (partition == 1) {
      piVar1 = &DAT_9000589e;
    }
    else {
      piVar1 = &DAT_900058a6;
    }
    if ((uint)piVar1[1] < 0xd004880) {
      piVar1[1] = piVar1[1] + 0x140;
    }
    else {
      cpyvram(piVar1[1] + 0x140,0xd002440,(*piVar1 + -1) * 0x50);
      piVar1[1] = 0xd002440;
    }
    fillvram(piVar1[1] + (*piVar1 + -1) * 0x140,0x50,0x20);
    screen_se();
    _DAT_0d01cffe = 1;
  }
  return;
}


// ==== scroll_do @ 800035d0

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void scroll_do(void)

{
  int *piVar1;
  
  if (partition != 0) {
    if (partition == 1) {
      piVar1 = &DAT_9000589e;
    }
    else {
      piVar1 = &DAT_900058a6;
    }
    if ((uint)piVar1[1] < 0xd002441) {
      cpyvram(piVar1[1],0xd0049c0,(*piVar1 + -1) * 0x50);
      piVar1[1] = 0xd004880;
    }
    else {
      piVar1[1] = piVar1[1] + -0x140;
    }
    fillvram(piVar1[1],0x50,0x20);
    screen_se();
    _DAT_0d01cffe = 1;
  }
  return;
}


// ==== reverse_s @ 80003678

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void reverse_s(int param_1)

{
  if ((param_1 == 1) || (param_1 == 0)) {
    _DAT_900058c2 = param_1;
  }
  return;
}


// ==== blink_set @ 800036a0

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void blink_set(int param_1)

{
  if ((param_1 == 1) || (param_1 == 0)) {
    _attribute = param_1;
  }
  return;
}


// ==== color_set @ 800036c8

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void color_set(int param_1,int param_2)

{
  if ((((-1 < param_1) && (param_1 < 0x10)) && (-1 < param_2)) && (param_2 < 0x10)) {
    _DAT_900058c6 = param_1;
    _DAT_900058ce = param_2;
  }
  return;
}


// ==== font_set @ 80003706

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void font_set(int param_1)

{
  if ((param_1 < 4) && (-1 < param_1)) {
    _DAT_900058d2 = param_1;
  }
  return;
}


// ==== erase_lin @ 80003730

void erase_lin(void)

{
  int unaff_D7;
  
  xy2vram(0,DAT_90005886);
  if (unaff_D7 != 0) {
    xy2vram(0,DAT_90005886,0x50,0x20);
    fillvram();
  }
  return;
}


// ==== puts1 @ 80003780

void puts1(undefined4 param_1,undefined4 param_2,char *param_3)

{
  int unaff_D7;
  
  cursor_mo(param_1,param_2);
  if (-1 < unaff_D7) {
    puts(param_3);
  }
  return;
}


// ==== puts @ 800037b6

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

int puts(char *__s)

{
  int iVar1;
  ushort uVar3;
  int iVar2;
  ushort *unaff_D7;
  ushort *puVar4;
  
  iVar1 = xy2vram(DAT_90005882,DAT_90005886);
  iVar2 = iVar1;
  puVar4 = unaff_D7;
  if (unaff_D7 != (ushort *)0x0) {
    while (iVar2 = CONCAT31((int3)((uint)iVar1 >> 8),*__s), *__s != 0) {
      uVar3 = DAT_900058d4;
      if (_DAT_900058c2 != 0) {
        uVar3 = DAT_900058d4 | 4;
      }
      *puVar4 = (ushort)(byte)*__s | uVar3 << 8;
      __s = __s + 1;
      uVar3 = DAT_900058c8 | DAT_900058cc << 4 | DAT_900058d0 << 8 | DAT_900058c0 << 0xf;
      puVar4[1] = uVar3;
      puVar4 = puVar4 + 2;
      if (((*__s != 0) && (0x4e < DAT_90005882)) && (0x1b < DAT_90005886)) {
        return CONCAT31((int3)(CONCAT22((short)((uint)iVar1 >> 0x10),uVar3) >> 8),*__s);
      }
      iVar1 = cursor_ri();
      if ((int)unaff_D7 < 0) {
        return iVar1;
      }
    }
  }
  return iVar2;
}


// ==== init_dsc @ 80003880

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void init_dsc(void)

{
  cpybuf(&Icursor,PUTS_ver + 0x3a,0x1c);
  cpybuf(&Ipartitio,&partition,0x24);
  cpybuf(&Iattribut,&attribute,0x18);
  fillvram(0xd000000,0x4000,0x20);
  screen_se();
  _DAT_0d01c9c0 = 0x8000;
  cursor_co();
  _DAT_0d01cffe = 1;
  return;
}


// ==== fs_creat @ 80003900

void fs_creat(undefined4 param_1,undefined4 param_2,undefined2 param_3,undefined4 param_4,
             undefined4 param_5)

{
  ushort unaff_D7w;
  
  whichdos(param_1);
  if (unaff_D7w == 3) {
    rq8creat(param_1,param_2,param_3,param_4,param_5);
    return;
  }
  if (unaff_D7w < 4) {
    if (unaff_D7w == 1) {
      msdcreat(param_1,param_2,param_3,param_4,param_5);
      return;
    }
    if (unaff_D7w == 2) {
      hd_creat(param_1,param_2,param_3,param_4,param_5);
      return;
    }
  }
  else if ((unaff_D7w == 0x81) || (unaff_D7w == 0x83)) {
    sducreat(param_1,param_2,param_3,param_4,param_5);
    return;
  }
  mkdoserr(param_1,0xfffffff6);
  return;
}


// ==== fs_open @ 800039c4

void fs_open(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5)

{
  ushort unaff_D7w;
  
  whichdos(param_1);
  if (unaff_D7w == 4) {
    netopen(param_1,param_2,param_3,param_4);
    return;
  }
  if (unaff_D7w < 5) {
    if (unaff_D7w == 2) {
      hd_open(param_1,param_2,param_3,param_4);
      return;
    }
    if (unaff_D7w < 3) {
      if (unaff_D7w == 1) {
        msd_open(param_1,param_2,param_3,param_4);
        return;
      }
    }
    else if (unaff_D7w == 3) {
      rq8_open(param_1,param_2,param_3,param_4);
      return;
    }
  }
  else {
    if (unaff_D7w == 0x81) {
LAB_80003a3a:
      sdu_open(param_1,param_2,param_3,param_4);
      return;
    }
    if (unaff_D7w < 0x82) {
      if (unaff_D7w == 5) {
        netnwopen(param_1,param_2,param_3,param_4,param_5);
        return;
      }
    }
    else if (unaff_D7w == 0x83) goto LAB_80003a3a;
  }
  mkdoserr(param_1,0xfffffff6);
  return;
}


// ==== fs_clos @ 80003aa8

void fs_clos(undefined4 param_1,short param_2,undefined4 param_3,undefined4 param_4)

{
  ushort unaff_D7w;
  
  whichdos(param_1);
  if (unaff_D7w == 4) {
    netclos((int)param_2,param_3);
    return;
  }
  if (unaff_D7w < 5) {
    if (unaff_D7w == 2) {
      hd_clos((int)param_2,param_3);
      return;
    }
    if (unaff_D7w < 3) {
      if (unaff_D7w == 1) {
        msd_clos((int)param_2,param_3);
        return;
      }
    }
    else if (unaff_D7w == 3) {
      rq8_clos((int)param_2,param_3);
      return;
    }
  }
  else {
    if (unaff_D7w == 0x81) {
LAB_80003b14:
      sdu_clos((int)param_2,param_3);
      return;
    }
    if (unaff_D7w < 0x82) {
      if (unaff_D7w == 5) {
        netnwclos((int)param_2,param_3,param_4);
        return;
      }
    }
    else if (unaff_D7w == 0x83) goto LAB_80003b14;
  }
  mkdoserr(param_1,0xfffffff6);
  return;
}


// ==== fs_read @ 80003b78

void fs_read(undefined4 param_1,short param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6)

{
  ushort unaff_D7w;
  
  whichdos(param_1);
  if (unaff_D7w == 4) {
    netread((int)param_2,param_3,param_4,param_5);
    return;
  }
  if (unaff_D7w < 5) {
    if (unaff_D7w == 2) {
      hd_read((int)param_2,param_3,param_4,param_5);
      return;
    }
    if (unaff_D7w < 3) {
      if (unaff_D7w == 1) {
        msd_read((int)param_2,param_3,param_4,param_5);
        return;
      }
    }
    else if (unaff_D7w == 3) {
      rq8_read((int)param_2,param_3,param_4,param_5);
      return;
    }
  }
  else {
    if (unaff_D7w == 0x81) {
LAB_80003bf6:
      sdu_read((int)param_2,param_3,param_4,param_5);
      return;
    }
    if (unaff_D7w < 0x82) {
      if (unaff_D7w == 5) {
        netnwread((int)param_2,param_3,param_4,param_5,param_6);
        return;
      }
    }
    else if (unaff_D7w == 0x83) goto LAB_80003bf6;
  }
  mkdoserr(param_1,0xfffffff6);
  return;
}


// ==== fs_write @ 80003c6e

void fs_write(undefined4 param_1,short param_2,undefined4 param_3,undefined4 param_4,
             undefined4 param_5,undefined4 param_6)

{
  ushort unaff_D7w;
  
  whichdos(param_1);
  if (unaff_D7w == 4) {
    netwrite((int)param_2,param_3,param_4,param_5);
    return;
  }
  if (unaff_D7w < 5) {
    if (unaff_D7w == 2) {
      hd_write((int)param_2,param_3,param_4,param_5);
      return;
    }
    if (unaff_D7w < 3) {
      if (unaff_D7w == 1) {
        msdwrite((int)param_2,param_3,param_4,param_5);
        return;
      }
    }
    else if (unaff_D7w == 3) {
      rq8write((int)param_2,param_3,param_4,param_5);
      return;
    }
  }
  else {
    if (unaff_D7w == 0x81) {
LAB_80003cec:
      sduwrite((int)param_2,param_3,param_4,param_5);
      return;
    }
    if (unaff_D7w < 0x82) {
      if (unaff_D7w == 5) {
        netnwwrit((int)param_2,param_3,param_4,param_5,param_6);
        return;
      }
    }
    else if (unaff_D7w == 0x83) goto LAB_80003cec;
  }
  mkdoserr(param_1,0xfffffff6);
  return;
}


// ==== fs_seek @ 80003d64

void fs_seek(undefined4 param_1,short param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5,undefined4 param_6)

{
  ushort unaff_D7w;
  
  whichdos(param_1);
  if (unaff_D7w == 4) {
    netseek((int)param_2,param_3,param_4,param_5);
    return;
  }
  if (unaff_D7w < 5) {
    if (unaff_D7w == 1) {
      msd_seek((int)param_2,param_3,param_4,param_5);
      return;
    }
    if (unaff_D7w == 2) {
      hd_seek((int)param_2,param_3,param_4,param_5);
      return;
    }
  }
  else {
    if (unaff_D7w == 0x81) {
LAB_80003dbe:
      sdu_seek((int)param_2,param_3,param_4,param_5);
      return;
    }
    if (unaff_D7w < 0x82) {
      if (unaff_D7w == 5) {
        netnwseek((int)param_2,param_3,param_4,param_5,param_6);
        return;
      }
    }
    else if (unaff_D7w == 0x83) goto LAB_80003dbe;
  }
  mkdoserr(param_1,0xfffffff6);
  return;
}


// ==== fs_delet @ 80003e36

void fs_delet(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  ushort unaff_D7w;
  
  whichdos(param_1);
  if (unaff_D7w == 3) {
    rq8delet(param_1,param_2,param_3);
    return;
  }
  if (unaff_D7w < 4) {
    if (unaff_D7w == 1) {
      msddelet(param_1,param_2,param_3);
      return;
    }
    if (unaff_D7w == 2) {
      hd_delet(param_1,param_2,param_3);
      return;
    }
  }
  else if ((unaff_D7w == 0x81) || (unaff_D7w == 0x83)) {
    sdu_delet(param_1,param_2,param_3);
    return;
  }
  mkdoserr(param_1,0xfffffff6);
  return;
}


// ==== fs_erase @ 80003ed2

void fs_erase(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  ushort unaff_D7w;
  
  whichdos(param_1);
  if (unaff_D7w == 2) {
    hd_erase(param_1,param_2,param_3);
  }
  else {
    if (unaff_D7w < 3) {
      if (unaff_D7w == 1) {
        msderase(param_1,param_2,param_3);
        return;
      }
    }
    else if ((unaff_D7w == 0x81) || (unaff_D7w == 0x83)) {
      sdu_erase(param_1,param_2,param_3);
      return;
    }
    mkdoserr(param_1,0xfffffff6);
  }
  return;
}


// ==== fs_resum @ 80003f58

void fs_resum(undefined4 param_1,undefined2 param_2,undefined4 param_3)

{
  ushort unaff_D7w;
  
  whichdos(param_1);
  if (unaff_D7w == 3) {
    rq8resum(param_1,param_2,param_3);
    return;
  }
  if (unaff_D7w < 4) {
    if (unaff_D7w == 1) {
      msdresum(param_1,param_2,param_3);
      return;
    }
    if (unaff_D7w == 2) {
      hd_resum(param_1,param_2,param_3);
      return;
    }
  }
  else if ((unaff_D7w == 0x81) || (unaff_D7w == 0x83)) {
    sduresum(param_1,param_2,param_3);
    return;
  }
  mkdoserr(param_1,0xfffffff6);
  return;
}


// ==== fs_renam @ 80004004

void fs_renam(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  ushort unaff_D7w;
  
  whichdos(param_1);
  if (unaff_D7w == 3) {
    rq8renam(param_1,param_2,param_3,param_4);
    return;
  }
  if (unaff_D7w < 4) {
    if (unaff_D7w == 1) {
      msdrenam(param_1,param_2,param_3,param_4);
      return;
    }
    if (unaff_D7w == 2) {
      hd_renam(param_1,param_2,param_3,param_4);
      return;
    }
  }
  else if ((unaff_D7w == 0x81) || (unaff_D7w == 0x83)) {
    sdurenam(param_1,param_2,param_3,param_4);
    return;
  }
  mkdoserr(param_1,0xfffffff6);
  return;
}


// ==== fs_mount @ 800040ac

void fs_mount(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  ushort unaff_D7w;
  
  whichdos(param_1);
  if (unaff_D7w == 4) {
    netmount(param_1,param_3,param_2);
    return;
  }
  if (unaff_D7w < 5) {
    if (unaff_D7w == 2) {
      hd_mount(param_1,param_2);
      return;
    }
    if (unaff_D7w < 3) {
      if (unaff_D7w == 1) {
        msdmount(param_1,param_2);
        return;
      }
    }
    else if (unaff_D7w == 3) {
      rq8mount(param_1,param_2);
      return;
    }
  }
  else {
    if (unaff_D7w == 0x81) {
LAB_80004116:
      sdumount(param_1,param_2);
      return;
    }
    if (unaff_D7w < 0x82) {
      if (unaff_D7w == 5) {
        netnwmoun(param_1,param_3,param_2,param_4);
        return;
      }
    }
    else if (unaff_D7w == 0x83) goto LAB_80004116;
  }
  mkdoserr(param_1,0xfffffff6);
  return;
}


// ==== fs_demnt @ 80004174

void fs_demnt(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  ushort unaff_D7w;
  
  whichdos(param_1);
  if (unaff_D7w == 4) {
    netdemnt(param_1,param_3,param_2);
    return;
  }
  if (unaff_D7w < 5) {
    if (unaff_D7w == 2) {
      hd_demnt(param_1,param_2);
      return;
    }
    if (unaff_D7w < 3) {
      if (unaff_D7w == 1) {
        msddemnt(param_1,param_2);
        return;
      }
    }
    else if (unaff_D7w == 3) {
      rq8demnt(param_1,param_2);
      return;
    }
  }
  else {
    if (unaff_D7w == 0x81) {
LAB_800041de:
      sdudemnt(param_1,param_2);
      return;
    }
    if (unaff_D7w < 0x82) {
      if (unaff_D7w == 5) {
        netnwdemn(param_1,param_3,param_2,param_4);
        return;
      }
    }
    else if (unaff_D7w == 0x83) goto LAB_800041de;
  }
  mkdoserr(param_1,0xfffffff6);
  return;
}


// ==== fs_info @ 8000423c

void fs_info(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  ushort unaff_D7w;
  
  whichdos(param_1);
  if (unaff_D7w == 3) {
    rq8sghdr(param_1,param_2,param_3);
  }
  else {
    if (unaff_D7w < 4) {
      if (unaff_D7w == 1) {
        msd_info(param_1,param_2,param_3);
        return;
      }
    }
    else if ((unaff_D7w == 0x81) || (unaff_D7w == 0x83)) {
      sdusghdr(param_1,param_2,param_3);
      return;
    }
    mkdoserr(param_1,0xfffffff6);
  }
  return;
}


// ==== fs_srch @ 800042c6

void fs_srch(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  ushort unaff_D7w;
  
  whichdos(param_1);
  if (unaff_D7w == 3) {
    rq8_srch(param_1,param_2,param_3);
    return;
  }
  if (unaff_D7w < 4) {
    if (unaff_D7w == 1) {
      msd_srch(param_1,param_2,param_3);
      return;
    }
    if (unaff_D7w == 2) {
      hd_srch(param_1,param_2,param_3);
      return;
    }
  }
  else if ((unaff_D7w == 0x81) || (unaff_D7w == 0x83)) {
    sdu_srch(param_1,param_2,param_3);
    return;
  }
  mkdoserr(param_1,0xfffffff6);
  return;
}


// ==== fs_dire @ 80004362

void fs_dire(undefined4 param_1,undefined2 param_2,undefined2 param_3,undefined4 param_4,
            undefined4 param_5)

{
  ushort unaff_D7w;
  
  whichdos(param_1);
  if (unaff_D7w == 3) {
    rq8_dire(param_1,param_2,param_3,param_4,param_5);
    return;
  }
  if (unaff_D7w < 4) {
    if (unaff_D7w == 1) {
      msd_dire(param_1,param_2,param_3,param_4,param_5);
      return;
    }
    if (unaff_D7w == 2) {
      hd_dire(param_1,param_2,param_3,param_4,param_5);
      return;
    }
  }
  else if ((unaff_D7w == 0x81) || (unaff_D7w == 0x83)) {
    sdu_dire(param_1,param_2,param_3,param_4,param_5);
    return;
  }
  mkdoserr(param_1,0xfffffff6);
  return;
}


// ==== fs_rxb @ 80004436

void fs_rxb(undefined4 param_1,undefined2 param_2,undefined2 param_3,undefined2 param_4,
           undefined4 param_5,undefined4 param_6)

{
  ushort unaff_D7w;
  
  whichdos(param_1);
  if (unaff_D7w == 3) {
    rq8_rxb(param_1,param_2,param_3,param_4,param_5,param_6);
    return;
  }
  if (unaff_D7w < 4) {
    if (unaff_D7w == 1) {
      msd_rxb(param_1,param_2,param_3,param_4,param_5,param_6);
      return;
    }
    if (unaff_D7w == 2) {
      hd_rxb(param_1,param_2,param_3,param_4,param_5,param_6);
      return;
    }
  }
  else if ((unaff_D7w == 0x81) || (unaff_D7w == 0x83)) {
    sdu_rxb(param_1,param_2,param_3,param_4,param_5,param_6);
    return;
  }
  mkdoserr(param_1,0xfffffff6);
  return;
}


// ==== fs_wxb @ 8000452a

void fs_wxb(undefined4 param_1,undefined2 param_2,undefined2 param_3,undefined2 param_4,
           undefined4 param_5,undefined4 param_6)

{
  ushort unaff_D7w;
  
  whichdos(param_1);
  if (unaff_D7w == 3) {
    rq8_wxb(param_1,param_2,param_3,param_4,param_5,param_6);
    return;
  }
  if (unaff_D7w < 4) {
    if (unaff_D7w == 1) {
      msd_wxb(param_1,param_2,param_3,param_4,param_5,param_6);
      return;
    }
    if (unaff_D7w == 2) {
      hd_wxb(param_1,param_2,param_3,param_4,param_5,param_6);
      return;
    }
  }
  else if ((unaff_D7w == 0x81) || (unaff_D7w == 0x83)) {
    sdu_wxb(param_1,param_2,param_3,param_4,param_5,param_6);
    return;
  }
  mkdoserr(param_1,0xfffffff6);
  return;
}


// ==== fs_remai @ 8000461e

void fs_remai(undefined4 param_1,undefined4 param_2)

{
  ushort unaff_D7w;
  
  whichdos(param_1);
  if (unaff_D7w == 3) {
    rq8remai(param_1,param_2);
    return;
  }
  if (unaff_D7w < 4) {
    if (unaff_D7w == 1) {
      msdremai(param_1,param_2);
      return;
    }
    if (unaff_D7w == 2) {
      hd_remai(param_1,param_2);
      return;
    }
  }
  else if ((unaff_D7w == 0x81) || (unaff_D7w == 0x83)) {
    sduremai(param_1,param_2);
    return;
  }
  mkdoserr(param_1,0xfffffff6);
  return;
}


// ==== fs_rema2 @ 800046ae

void fs_rema2(undefined4 param_1,undefined4 param_2)

{
  short unaff_D7w;
  
  whichdos(param_1);
  if (unaff_D7w == 2) {
    hd_rema2(param_1,param_2);
  }
  else {
    mkdoserr(param_1,0xfffffff6);
  }
  return;
}


// ==== fs_gtvol @ 800046f2

void fs_gtvol(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  ushort unaff_D7w;
  
  whichdos(param_1);
  if (unaff_D7w == 3) {
    rq8gtvol(param_1,param_2,param_3);
    return;
  }
  if (unaff_D7w < 4) {
    if (unaff_D7w == 1) {
      msdgtvol(param_1,param_2,param_3);
      return;
    }
    if (unaff_D7w == 2) {
      hd_gtvol(param_1,param_2,param_3);
      return;
    }
  }
  else if ((unaff_D7w == 0x81) || (unaff_D7w == 0x83)) {
    sdugtvol(param_1,param_2,param_3);
    return;
  }
  mkdoserr(param_1,0xfffffff6);
  return;
}


// ==== fs_ptvol @ 8000478e

void fs_ptvol(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  ushort unaff_D7w;
  
  whichdos(param_1);
  if (unaff_D7w == 3) {
    rq8ptvol(param_1,param_2,param_3);
    return;
  }
  if (unaff_D7w < 4) {
    if (unaff_D7w == 1) {
      msdptvol(param_1,param_2,param_3);
      return;
    }
    if (unaff_D7w == 2) {
      hd_ptvol(param_1,param_2,param_3);
      return;
    }
  }
  else if ((unaff_D7w == 0x81) || (unaff_D7w == 0x83)) {
    sduptvol(param_1,param_2,param_3);
    return;
  }
  mkdoserr(param_1,0xfffffff6);
  return;
}


// ==== fs_kind @ 8000482a

void fs_kind(undefined4 param_1,undefined4 param_2)

{
  ushort unaff_D7w;
  
  whichdos(param_1);
  if (unaff_D7w == 3) {
    rq8_kind(param_1,param_2);
    return;
  }
  if (unaff_D7w < 4) {
    if (unaff_D7w == 1) {
      msd_kind(param_1,param_2);
      return;
    }
    if (unaff_D7w == 2) {
      hd_kind(param_1,param_2);
      return;
    }
  }
  else if ((unaff_D7w == 0x81) || (unaff_D7w == 0x83)) {
    sdu_kind(param_1,param_2);
    return;
  }
  mkdoserr(param_1,0xfffffff6);
  return;
}


// ==== fs_init @ 800048ba

void fs_init(undefined4 param_1,undefined1 param_2,undefined1 param_3,undefined4 param_4,
            undefined4 param_5)

{
  ushort unaff_D7w;
  
  whichdos(param_1);
  if (unaff_D7w == 3) {
    rq8_init(param_1,param_2,param_3,param_4,param_5);
    return;
  }
  if (unaff_D7w < 4) {
    if (unaff_D7w == 1) {
      msd_init(param_1,param_2,param_3,param_4,param_5);
      return;
    }
    if (unaff_D7w == 2) {
      hd_init(param_1,param_2,param_3,param_4,param_5);
      return;
    }
  }
  else if ((unaff_D7w == 0x81) || (unaff_D7w == 0x83)) {
    sdu_init(param_1,param_2,param_3,param_4,param_5);
    return;
  }
  mkdoserr(param_1,0xfffffff6);
  return;
}


// ==== fs_pack @ 8000498e

void fs_pack(undefined4 param_1,undefined4 param_2)

{
  ushort unaff_D7w;
  
  whichdos(param_1);
  if (unaff_D7w == 3) {
    rq8_pack(param_1,param_2);
    return;
  }
  if (unaff_D7w < 4) {
    if (unaff_D7w == 1) {
      msd_pack(param_1,param_2);
      return;
    }
    if (unaff_D7w == 2) {
      hd_pack(param_1,param_2);
      return;
    }
  }
  else if ((unaff_D7w == 0x81) || (unaff_D7w == 0x83)) {
    sdu_pack(param_1,param_2);
    return;
  }
  mkdoserr(param_1,0xfffffff6);
  return;
}


// ==== fs_volcp @ 80004a1e

/* WARNING: Removing unreachable block (ram,0x80004a4c) */
/* WARNING: Removing unreachable block (ram,0x80004a52) */
/* WARNING: Removing unreachable block (ram,0x80004a58) */
/* WARNING: Removing unreachable block (ram,0x80004a5e) */
/* WARNING: Removing unreachable block (ram,0x80004a64) */
/* WARNING: Removing unreachable block (ram,0x80004a6a) */
/* WARNING: Removing unreachable block (ram,0x80004a70) */
/* WARNING: Removing unreachable block (ram,0x80004a76) */
/* WARNING: Removing unreachable block (ram,0x80004a7c) */

void fs_volcp(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  ushort unaff_D7w;
  
  whichdos(param_1);
  whichdos(param_2);
  if (unaff_D7w == 3) {
    rq8volcp(param_1,param_2,param_3);
    return;
  }
  if (unaff_D7w < 4) {
    if (unaff_D7w == 1) {
      msdvolcp(param_1,param_2,param_3);
      return;
    }
    if (unaff_D7w == 2) {
      hd_volcp(param_1,param_2,param_3);
      return;
    }
  }
  else if ((unaff_D7w == 0x81) || (unaff_D7w == 0x83)) {
    sduvolcp(param_1,param_2,param_3);
    return;
  }
  mkdoserr(param_1,0xfffffff6);
  return;
}


// ==== fs_dstat @ 80004b08

void fs_dstat(undefined4 param_1,undefined4 param_2)

{
  ushort unaff_D7w;
  
  whichdos(param_1);
  if (unaff_D7w == 3) {
    rq8dstat(param_1,param_2);
    return;
  }
  if (unaff_D7w < 4) {
    if (unaff_D7w == 1) {
      msddstat(param_1,param_2);
      return;
    }
    if (unaff_D7w == 2) {
      hd_dstat(param_1,param_2);
      return;
    }
  }
  else if ((unaff_D7w == 0x81) || (unaff_D7w == 0x83)) {
    sdudstat(param_1,param_2);
    return;
  }
  mkdoserr(param_1,0xfffffff6);
  return;
}


// ==== fs_fcpy @ 80004b98

/* WARNING: Removing unreachable block (ram,0x80004bcc) */
/* WARNING: Removing unreachable block (ram,0x80004c34) */
/* WARNING: Removing unreachable block (ram,0x80004c40) */
/* WARNING: Removing unreachable block (ram,0x80004c48) */
/* WARNING: Removing unreachable block (ram,0x80004bd2) */
/* WARNING: Removing unreachable block (ram,0x80004bd8) */
/* WARNING: Removing unreachable block (ram,0x80004bde) */
/* WARNING: Removing unreachable block (ram,0x80004be4) */
/* WARNING: Removing unreachable block (ram,0x80004bea) */
/* WARNING: Removing unreachable block (ram,0x80004bf0) */
/* WARNING: Removing unreachable block (ram,0x80004bf6) */
/* WARNING: Removing unreachable block (ram,0x80004bfc) */
/* WARNING: Removing unreachable block (ram,0x80004c02) */
/* WARNING: Removing unreachable block (ram,0x80004c08) */
/* WARNING: Removing unreachable block (ram,0x80004c0e) */
/* WARNING: Removing unreachable block (ram,0x80004c16) */
/* WARNING: Removing unreachable block (ram,0x80004c1e) */
/* WARNING: Removing unreachable block (ram,0x80004c3a) */
/* WARNING: Removing unreachable block (ram,0x80004c50) */

void fs_fcpy(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            undefined4 param_5)

{
  ushort unaff_D7w;
  
  whichdos(param_1);
  whichdos(param_3);
  if (unaff_D7w == 3) {
    rq8_fcpy(param_1,param_2,param_3,param_4,param_5);
    return;
  }
  if (unaff_D7w < 4) {
    if (unaff_D7w == 1) {
      msd_fcpy(param_1,param_2,param_3,param_4,param_5);
      return;
    }
    if (unaff_D7w == 2) {
      hd_fcpy(param_1,param_2,param_3,param_4,param_5);
      return;
    }
  }
  else if ((unaff_D7w == 0x81) || (unaff_D7w == 0x83)) {
    sdu_fcpy(param_1,param_2,param_3,param_4,param_5);
    return;
  }
  mkdoserr(param_1,0xfffffff6);
  return;
}


// ==== fs_dcnfg @ 80004cfc

void fs_dcnfg(undefined4 param_1,undefined4 param_2)

{
  ushort unaff_D7w;
  
  whichdos(param_1);
  if (unaff_D7w == 3) {
    rq8dcnfg(param_1,param_2);
  }
  else if (unaff_D7w < 4) {
    if (unaff_D7w == 1) {
      msddcnfg(param_1,param_2);
    }
    else {
      if (unaff_D7w != 2) {
        return;
      }
      hd_dcnfg(param_1,param_2);
    }
  }
  else {
    if ((unaff_D7w != 0x81) && (unaff_D7w != 0x83)) {
      return;
    }
    sdudcnfg(param_1,param_2);
  }
  dosstt();
  return;
}


// ==== fs_rdsct @ 80004db0

void fs_rdsct(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
             undefined4 param_5,undefined4 param_6,undefined4 param_7)

{
  ushort unaff_D7w;
  
  whichdos(param_1);
  if (unaff_D7w == 3) {
    rq8rdsct(param_1,param_2,param_3,param_4,param_5,param_6,param_7);
  }
  else if (unaff_D7w < 4) {
    if (unaff_D7w == 1) {
      msdrdsct(param_1,param_2,param_3,param_4,param_5,param_6,param_7);
    }
    else {
      if (unaff_D7w != 2) {
        return;
      }
      hd_rdsct(param_1,param_2,param_3,param_4,param_5,param_6,param_7);
    }
  }
  else {
    if ((unaff_D7w != 0x81) && (unaff_D7w != 0x83)) {
      return;
    }
    sdurdsct(param_1,param_2,param_3,param_4,param_5,param_6,param_7);
  }
  dosstt();
  return;
}


// ==== fs_wrsct @ 80004e88

void fs_wrsct(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
             undefined4 param_5,undefined4 param_6,undefined4 param_7)

{
  ushort unaff_D7w;
  
  whichdos(param_1);
  if (unaff_D7w == 3) {
    rq8wrsct(param_1,param_2,param_3,param_4,param_5,param_6,param_7);
  }
  else if (unaff_D7w < 4) {
    if (unaff_D7w == 1) {
      msdwrsct(param_1,param_2,param_3,param_4,param_5,param_6,param_7);
    }
    else {
      if (unaff_D7w != 2) {
        return;
      }
      hd_wrsct(param_1,param_2,param_3,param_4,param_5,param_6,param_7);
    }
  }
  else {
    if ((unaff_D7w != 0x81) && (unaff_D7w != 0x83)) {
      return;
    }
    sduwrsct(param_1,param_2,param_3,param_4,param_5,param_6,param_7);
  }
  dosstt();
  return;
}


// ==== fs_mkdir @ 80004f60

void fs_mkdir(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  short unaff_D7w;
  
  whichdos(param_1);
  if (unaff_D7w == 2) {
    hd_mkdir(param_1,param_2,param_3);
  }
  else {
    mkdoserr(param_1,0xfffffff6);
  }
  return;
}


// ==== fs_rmdir @ 80004fa8

void fs_rmdir(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  short unaff_D7w;
  
  whichdos(param_1);
  if (unaff_D7w == 2) {
    hd_rmdir(param_1,param_2,param_3);
  }
  else {
    mkdoserr(param_1,0xfffffff6);
  }
  return;
}


// ==== fs_chdir @ 80004ff0

void fs_chdir(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  short unaff_D7w;
  
  whichdos(param_1);
  if (unaff_D7w == 2) {
    hd_chdir(param_1,param_2,param_3);
  }
  else {
    mkdoserr(param_1,0xfffffff6);
  }
  return;
}


// ==== fs_pwd @ 80005038

void fs_pwd(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  short unaff_D7w;
  
  whichdos(param_1);
  if (unaff_D7w == 2) {
    hd_pwd(param_1,param_2,param_3);
  }
  else {
    mkdoserr(param_1,0xfffffff6);
  }
  return;
}


// ==== fs_dird @ 80005080

void fs_dird(undefined4 param_1,undefined2 param_2,undefined2 param_3,undefined4 param_4,
            undefined4 param_5)

{
  short unaff_D7w;
  
  whichdos(param_1);
  if (unaff_D7w == 2) {
    hd_dird(param_1,param_2,param_3,param_4,param_5);
  }
  else {
    mkdoserr(param_1,0xfffffff6);
  }
  return;
}


// ==== chk_id @ 800050e0

void chk_id(uint param_1,uint param_2,ushort *param_3,ushort *param_4,undefined4 param_5)

{
  int unaff_D7;
  short sVar1;
  undefined1 auStack_38 [6];
  ushort local_32;
  undefined1 auStack_1e [6];
  ushort local_18;
  
  whichdos(param_1);
  sVar1 = (short)unaff_D7;
  whichdos(param_2);
  if (sVar1 == 0x83) {
    sdusghdr(param_1,auStack_1e,param_5);
  }
  else if (sVar1 == 3) {
    rq8sghdr(param_1,auStack_1e,param_5);
  }
  else {
    mkdoserr(param_1 & 0xff,0xfffffff6);
  }
  chk_doser();
  if (-1 < unaff_D7) {
    *param_3 = local_18;
  }
  chk_doser();
  if (-1 < unaff_D7) {
    if (sVar1 == 0x83) {
      sdusghdr(param_2,auStack_38,param_5);
    }
    else if (sVar1 == 3) {
      rq8sghdr(param_2,auStack_38,param_5);
    }
    else {
      mkdoserr(param_2 & 0xff,0xfffffff6);
    }
    chk_doser();
    if ((-1 < unaff_D7) && (*param_4 = local_32, *param_4 < *param_3)) {
      mkdoserr(param_2 & 0xff,0xffffffe9);
    }
  }
  return;
}


// ==== diffread @ 800051fa

void diffread(uint param_1,undefined4 param_2,uint param_3,undefined4 param_4,undefined4 param_5)

{
  uint uVar1;
  uint uVar2;
  undefined *puVar3;
  undefined4 uVar4;
  int iVar5;
  undefined *unaff_D7;
  int unaff_A4;
  undefined1 auStack_10 [4];
  short sVar6;
  
  whichdos(param_1);
  uVar2 = (uint)unaff_D7 & 0xffff;
  whichdos(param_3);
  if (uVar2 == 3) {
    iVar5 = 1;
LAB_80005260:
    uVar2 = (uint)unaff_D7 & 0xffff;
    if (uVar2 == 3) {
      unaff_A4 = 1;
    }
    else {
      uVar1 = param_3;
      if (uVar2 < 4) {
        if (uVar2 == 1) {
          unaff_A4 = 2;
        }
        else {
          if (uVar2 != 2) goto LAB_800052a8;
          iVar5 = 3;
        }
      }
      else {
        if ((uVar2 != 0x81) && (uVar2 != 0x83)) goto LAB_800052a8;
        unaff_A4 = 0;
      }
    }
    (*(code *)(&open_func)[iVar5])(param_1,param_2,0,param_5);
    chk_doser();
    if (-1 < (int)unaff_D7) {
      sVar6 = (short)unaff_D7;
      (*(code *)(&rema_func)[unaff_A4])(param_3,param_5);
      (*(code *)(&crea_func)[unaff_A4])(param_3,param_4);
      chk_doser();
      if (-1 < (int)unaff_D7) {
        malloc(0x1400);
        if (unaff_D7 == (undefined *)0x0) {
          uVar4 = 0x200;
          puVar3 = &fsvolbuf;
        }
        else {
          uVar4 = 0x1400;
          puVar3 = unaff_D7;
        }
        do {
          (*(code *)(&read_func)[iVar5])((int)sVar6,uVar4,puVar3,param_5);
          chk_doser();
          if ((int)unaff_D7 < 0) {
            if ((short)((uint)unaff_D7 >> 0x10) == -0xc) {
              mkdoserr(param_3 & 0xff,0);
            }
            break;
          }
          (*(code *)(&writ_func)[unaff_A4])((int)sVar6,unaff_D7,puVar3,param_5);
          chk_doser();
        } while (-1 < (int)unaff_D7);
        (*(code *)(&clos_func)[iVar5])((int)sVar6,param_5);
        (*(code *)(&clos_func)[unaff_A4])((int)sVar6,param_5);
        if (-1 < (int)unaff_D7) {
          cpybuf(auStack_10 + 8,auStack_10 + 4,4);
        }
        freefs(puVar3);
      }
    }
  }
  else {
    uVar1 = param_1;
    if (uVar2 < 4) {
      if (uVar2 == 1) {
        iVar5 = 2;
      }
      else {
        if (uVar2 != 2) goto LAB_800052a8;
        iVar5 = 3;
      }
      goto LAB_80005260;
    }
    if ((uVar2 == 0x81) || (uVar2 == 0x83)) {
      iVar5 = 0;
      goto LAB_80005260;
    }
LAB_800052a8:
    mkdoserr(uVar1 & 0xff,0xfffffff6);
  }
  return;
}


// ==== dif_fcpy @ 80005432

/* WARNING: Removing unreachable block (ram,0x8000548e) */
/* WARNING: Removing unreachable block (ram,0x800054b6) */
/* WARNING: Removing unreachable block (ram,0x800054e6) */

void dif_fcpy(uint param_1,undefined4 param_2,uint param_3,undefined4 param_4,undefined4 param_5)

{
  if (param_3 == param_1) {
    mkdoserr(param_3 & 0xff,0xfffffff6);
  }
  else {
    whichdos(param_1);
    whichdos(param_3);
    diffread(param_1,param_2,param_3,param_4,param_5);
    chk_doser();
  }
  return;
}


// ==== chk_doser @ 8000551a

undefined4 chk_doser(int param_1)

{
  undefined4 uVar1;
  
  if (param_1 < 0) {
    uVar1 = 0xffffffff;
  }
  else {
    uVar1 = 0;
  }
  return uVar1;
}


// ==== dif_comwr @ 80005534

void dif_comwr(short param_1,ushort param_2,undefined4 param_3,undefined4 param_4,undefined4 param_5
              ,undefined4 param_6,undefined4 param_7)

{
  ushort uVar1;
  int unaff_D7;
  short sVar2;
  
  whichdos(param_3);
  sVar2 = (short)unaff_D7;
  whichdos(param_5);
  if (sVar2 == 0x83) {
    sdu_srch(param_3,param_4,param_7);
  }
  else {
    rq8_srch(param_3,param_4,param_7);
  }
  chk_doser();
  if (-1 < unaff_D7) {
    fill(&fsvolbuf,param_2,0);
    uVar1 = param_2;
    if (0x28 < param_2) {
      uVar1 = 0x28;
    }
    fill(&fsvolbuf,uVar1,0x20);
    if (param_1 != 0) {
      if (sVar2 == 0x83) {
        sdu_rxb(param_3);
      }
      else {
        rq8_rxb(param_3);
      }
    }
  }
  chk_doser();
  if (-1 < unaff_D7) {
    if (sVar2 == 0x83) {
      sdu_srch(param_5,param_6,param_7);
    }
    else {
      rq8_srch(param_5,param_6,param_7);
    }
  }
  chk_doser();
  if ((-1 < unaff_D7) && (param_2 != 0)) {
    if (sVar2 == 0x83) {
      sdu_wxb(param_5);
    }
    else {
      rq8_wxb(param_5);
    }
  }
  return;
}


// ==== difvolcp @ 800056b8

/* WARNING: Removing unreachable block (ram,0x8000586a) */
/* WARNING: Removing unreachable block (ram,0x80005870) */
/* WARNING: Removing unreachable block (ram,0x80005876) */
/* WARNING: Removing unreachable block (ram,0x8000589e) */
/* WARNING: Removing unreachable block (ram,0x800058b8) */
/* WARNING: Removing unreachable block (ram,0x800058d8) */
/* WARNING: Removing unreachable block (ram,0x800058dc) */
/* WARNING: Removing unreachable block (ram,0x8000591e) */
/* WARNING: Removing unreachable block (ram,0x80005910) */
/* WARNING: Removing unreachable block (ram,0x80005920) */
/* WARNING: Removing unreachable block (ram,0x8000592a) */
/* WARNING: Removing unreachable block (ram,0x80005934) */
/* WARNING: Removing unreachable block (ram,0x80005942) */
/* WARNING: Removing unreachable block (ram,0x80005944) */
/* WARNING: Removing unreachable block (ram,0x8000598a) */
/* WARNING: Removing unreachable block (ram,0x80005992) */
/* WARNING: Removing unreachable block (ram,0x800059da) */
/* WARNING: Removing unreachable block (ram,0x800059e0) */
/* WARNING: Removing unreachable block (ram,0x800059ea) */
/* WARNING: Removing unreachable block (ram,0x800059ee) */
/* WARNING: Removing unreachable block (ram,0x800059f8) */
/* WARNING: Removing unreachable block (ram,0x80005a00) */
/* WARNING: Removing unreachable block (ram,0x80005a0a) */
/* WARNING: Removing unreachable block (ram,0x80005a12) */
/* WARNING: Removing unreachable block (ram,0x80005a1c) */
/* WARNING: Removing unreachable block (ram,0x80005a4c) */
/* WARNING: Removing unreachable block (ram,0x80005a42) */
/* WARNING: Removing unreachable block (ram,0x80005882) */
/* WARNING: Recovered jumptable eliminated as dead code */

void difvolcp(uint param_1,uint param_2,undefined4 param_3)

{
  ushort unaff_D7w;
  
  whichdos(param_1);
  whichdos(param_2);
  if (unaff_D7w == 3) {
    rq8dcnfg(param_1,param_3);
  }
  else if (unaff_D7w < 4) {
    if (unaff_D7w != 1) goto LAB_80005780;
    msddcnfg(param_1,param_3);
  }
  else {
    if ((unaff_D7w != 0x81) && (unaff_D7w != 0x83)) {
LAB_80005780:
      param_1 = param_1 & 0xff;
      goto LAB_80005a56;
    }
    sdudcnfg(param_1,param_3);
  }
  if (unaff_D7w == 3) {
    rq8dcnfg(param_2,param_3);
LAB_80005890:
    param_1 = param_1 & 0xff;
  }
  else {
    if (unaff_D7w < 4) {
      if (unaff_D7w == 1) {
        msddcnfg(param_2,param_3);
        goto LAB_80005890;
      }
    }
    else if ((unaff_D7w == 0x81) || (unaff_D7w == 0x83)) {
      sdudcnfg(param_2,param_3);
      goto LAB_80005890;
    }
    param_1 = param_2 & 0xff;
  }
LAB_80005a56:
  mkdoserr(param_1,0xfffffff6);
  return;
}


// ==== freefs @ 80005a68

void freefs(undefined *param_1)

{
  if (param_1 != &fsvolbuf) {
    mfree(param_1);
  }
  return;
}


// ==== moffsub @ 80005a84

void moffsub(undefined4 param_1,undefined4 param_2)

{
  ushort unaff_D7w;
  
  whichdos(param_1);
  if (unaff_D7w == 3) {
    rq8demnt(param_1,param_2);
  }
  else if (unaff_D7w < 4) {
    if (unaff_D7w == 1) {
      msddemnt(param_1,param_2);
    }
  }
  else if ((unaff_D7w == 0x81) || (unaff_D7w == 0x83)) {
    sdudemnt(param_1,param_2);
  }
  return;
}


// ==== dif_echk @ 80005af0

uint dif_echk(undefined1 param_1,uint param_2,char param_3)

{
  byte bVar1;
  uint uVar2;
  int iVar3;
  
  iVar3 = 0;
  if (param_2 == 0) {
    uVar2 = mkdoserr(param_1,0);
  }
  else {
    uVar2 = param_2 & 0x7c000000;
    if (uVar2 == 0) {
      if (param_3 == '\0') {
        if ((param_2 & 0x8989) != 0) {
          uVar2 = param_2 & 0x8900;
          do {
            if ((param_2 & 1 << (uVar2 & 0x1f)) != 0) {
              switch(uVar2 & 0xff) {
              case 0:
              case 8:
                iVar3 = -8;
                break;
              case 3:
              case 0xb:
                iVar3 = -5;
                break;
              case 7:
              case 0xf:
                iVar3 = -4;
                break;
              case 0x12:
                iVar3 = -0x2d;
              }
              if (iVar3 != 0) {
                return uVar2;
              }
            }
            bVar1 = (char)uVar2 + 1;
            uVar2 = CONCAT31((int3)(uVar2 >> 8),bVar1);
            if (0x1f < bVar1) {
              return uVar2;
            }
          } while( true );
        }
      }
      else if ((param_2 & 0x8989) != 0) {
        uVar2 = param_2 & 0x8900;
        do {
          if ((param_2 & 1 << (uVar2 & 0x1f)) != 0) {
            switch(uVar2 & 0xff) {
            case 0:
            case 8:
              iVar3 = -8;
              break;
            case 3:
            case 0xb:
              iVar3 = -5;
              break;
            case 6:
            case 0xe:
              iVar3 = -0x2e;
              break;
            case 7:
            case 0xf:
              iVar3 = -4;
              break;
            case 0x12:
              iVar3 = -0x2d;
            }
            if (iVar3 != 0) {
              return uVar2;
            }
          }
          bVar1 = (char)uVar2 + 1;
          uVar2 = CONCAT31((int3)(uVar2 >> 8),bVar1);
          if (0xf < bVar1) {
            return uVar2;
          }
        } while( true );
      }
      uVar2 = param_2 & 0x8989;
    }
  }
  return uVar2;
}


// ==== fcpytohd @ 80005c18

void fcpytohd(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
             undefined4 param_5)

{
  uint unaff_D4;
  uint unaff_D7;
  short sVar1;
  
  whichdos(param_1);
  sVar1 = (short)unaff_D7;
  if ((unaff_D7 & 0xffff) == 1) {
    msd_open(param_1,param_2,0,param_5);
  }
  else {
    if ((unaff_D7 & 0xffff) != 0x81) goto LAB_80005c72;
    sdu_open(param_1,param_2,0,param_5);
  }
  unaff_D4 = unaff_D7;
LAB_80005c72:
  dosstt(unaff_D4);
  if (-1 < (int)unaff_D7) {
    hd_creat(param_3,param_4,0x800,1,param_5);
    dosstt();
    if (unaff_D7 == 0xffffffff) {
      hd_open(param_3,param_4,1,param_5);
      dosstt();
    }
    else if (-1 < (int)unaff_D7) {
      hd_cpxb(param_1,param_2,param_3,param_4,unaff_D7 & 0xffff,param_5);
      hdfcpsub((int)sVar1,(int)sVar1,unaff_D7 & 0xffff,param_5);
      dosstt();
      hd_clos((int)sVar1,param_5);
      dosstt();
    }
    if ((unaff_D7 & 0xffff) == 1) {
      msd_clos((int)sVar1,param_5);
    }
    else if ((unaff_D7 & 0xffff) == 0x81) {
      sdu_clos((int)sVar1,param_5);
    }
  }
  return;
}


// ==== hdfcpsub @ 80005d8c

void hdfcpsub(short param_1,short param_2,short param_3,undefined4 param_4)

{
  undefined1 *puVar1;
  undefined1 *unaff_D4;
  uint __size;
  undefined1 *unaff_D7;
  undefined1 auStack_204 [512];
  
  __size = 0x1000;
  do {
    malloc(__size);
    if (unaff_D7 != (undefined1 *)0x0) break;
    __size = (int)__size >> 1;
  } while (0x200 < __size);
  puVar1 = unaff_D7;
  if (unaff_D7 == (undefined1 *)0x0) {
    puVar1 = auStack_204;
  }
  do {
    if (param_3 == 1) {
      msd_read((int)param_1,__size,puVar1,param_4);
LAB_80005e18:
      unaff_D4 = unaff_D7;
    }
    else if (param_3 == 0x81) {
      sdu_read((int)param_1,__size,puVar1,param_4);
      goto LAB_80005e18;
    }
    dosstt(unaff_D4);
    if ((int)unaff_D7 < 1) break;
    hd_write((int)param_2);
    dosstt();
    unaff_D4 = unaff_D7;
  } while (-1 < (int)unaff_D7);
  if (unaff_D7 != (undefined1 *)0x0) {
    mfree(puVar1);
  }
  return;
}


// ==== hd_cpxb @ 80005e6c

void hd_cpxb(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
            short param_5,undefined4 param_6)

{
  uint unaff_D3;
  uint unaff_D7;
  undefined1 auStack_2c [40];
  
  if (param_5 == 1) {
    msd_srch(param_1,param_2,param_6);
LAB_80005eba:
    unaff_D3 = unaff_D7;
  }
  else if (param_5 == 0x81) {
    sdu_srch(param_1,param_2,param_6);
    goto LAB_80005eba;
  }
  dosstt(unaff_D3);
  if ((int)unaff_D7 < 1) {
    return;
  }
  if (param_5 == 1) {
    msd_rxb(param_1,unaff_D7 & 0xffff,unaff_D7 & 0xffff,0x28,auStack_2c,param_6);
  }
  else {
    if (param_5 != 0x81) goto LAB_80005f1c;
    sdu_rxb(param_1,unaff_D7 & 0xffff,unaff_D7 & 0xffff,0x28,auStack_2c,param_6);
  }
  unaff_D3 = unaff_D7;
LAB_80005f1c:
  dosstt(unaff_D3);
  if (-1 < (int)unaff_D7) {
    hd_srch(param_3,param_4,param_6);
    dosstt();
    if (-1 < (int)unaff_D7) {
      hd_wxb(param_3,unaff_D7 & 0xffff,unaff_D7 & 0xffff,0x28,auStack_2c,param_6);
    }
  }
  return;
}


// ==== hdsreq @ 80005f70

void hdsreq(int param_1,undefined4 *param_2)

{
  undefined4 unaff_D7;
  undefined4 local_8;
  
  *(char *)(param_1 + 3) = *(char *)(param_1 + 3) + -6;
  *(char *)(param_1 + 4) = *(char *)(param_1 + 4) + -6;
  *(undefined4 **)(param_1 + 0x28) = &local_8;
  mailnwai(0x2c,9,param_1,0x10);
  *param_2 = unaff_D7;
  dosstt(local_8);
  return;
}


// ==== hd_creat @ 80005fcc

void hd_creat(undefined1 param_1,undefined4 param_2,undefined4 param_3,undefined2 param_4,
             undefined4 param_5)

{
  undefined1 auStack_30 [2];
  undefined1 local_2e;
  undefined1 local_2d;
  undefined1 auStack_2b [23];
  undefined2 local_14;
  undefined4 local_10;
  
  local_2e = 0x13;
  local_2d = param_1;
  putfnam(param_2,auStack_2b);
  local_10 = param_3;
  local_14 = param_4;
  hdsreq(auStack_30,param_5);
  return;
}


// ==== hd_open @ 80006010

void hd_open(undefined1 param_1,undefined4 param_2,undefined2 param_3,undefined4 param_4)

{
  undefined1 auStack_30 [2];
  undefined1 local_2e;
  undefined1 local_2d;
  undefined1 auStack_2b [23];
  undefined2 local_14;
  
  local_2e = 0x11;
  local_2d = param_1;
  putfnam(param_2,auStack_2b);
  local_14 = param_3;
  hdsreq(auStack_30,param_4);
  return;
}


// ==== hd_clos @ 8000604e

void hd_clos(undefined2 param_1,undefined4 param_2)

{
  undefined2 local_30;
  undefined1 local_2e;
  
  local_2e = 0x12;
  local_30 = param_1;
  hdsreq(&local_30,param_2);
  return;
}


// ==== hd_read @ 80006072

void hd_read(undefined2 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  undefined2 local_30;
  undefined1 local_2e;
  undefined4 local_10;
  undefined4 local_c;
  
  local_2e = 0x21;
  local_30 = param_1;
  local_10 = param_2;
  local_c = param_3;
  hdsreq(&local_30,param_4);
  return;
}


// ==== hd_write @ 800060a2

void hd_write(undefined2 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  undefined2 local_30;
  undefined1 local_2e;
  undefined4 local_10;
  undefined4 local_c;
  
  local_2e = 0x22;
  local_30 = param_1;
  local_10 = param_2;
  local_c = param_3;
  hdsreq(&local_30,param_4);
  return;
}


// ==== hd_seek @ 800060d2

void hd_seek(undefined2 param_1,undefined2 param_2,undefined4 param_3,undefined4 param_4)

{
  undefined2 local_30;
  undefined1 local_2e;
  undefined2 local_14;
  undefined4 local_10;
  
  local_2e = 0x23;
  local_30 = param_1;
  local_10 = param_3;
  local_14 = param_2;
  hdsreq(&local_30,param_4);
  return;
}


// ==== hd_erase @ 80006102

void hd_erase(undefined1 param_1,undefined4 param_2,undefined4 param_3)

{
  undefined1 auStack_30 [2];
  undefined1 local_2e;
  undefined1 local_2d;
  undefined1 auStack_2b [39];
  
  local_2e = 0x15;
  local_2d = param_1;
  putfnam(param_2,auStack_2b);
  hdsreq(auStack_30,param_3);
  return;
}


// ==== hd_renam @ 8000613a

void hd_renam(undefined1 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  undefined1 auStack_30 [2];
  undefined1 local_2e;
  undefined1 local_2d;
  undefined1 auStack_2b [11];
  undefined1 auStack_20 [28];
  
  local_2e = 0x14;
  local_2d = param_1;
  putfnam(param_2,auStack_2b);
  putfnam(param_3,auStack_20);
  hdsreq(auStack_30,param_4);
  return;
}


// ==== hd_mount @ 80006182

void hd_mount(undefined1 param_1,undefined4 param_2)

{
  undefined1 auStack_30 [2];
  undefined1 local_2e;
  undefined1 local_2d;
  
  local_2e = 1;
  local_2d = param_1;
  hdsreq(auStack_30,param_2);
  return;
}


// ==== hd_demnt @ 800061a4

void hd_demnt(undefined1 param_1,undefined4 param_2)

{
  undefined1 auStack_30 [2];
  undefined1 local_2e;
  undefined1 local_2d;
  
  local_2e = 4;
  local_2d = param_1;
  hdsreq(auStack_30,param_2);
  return;
}


// ==== hd_info @ 800061c6

void hd_info(undefined1 param_1,undefined4 param_2,undefined4 param_3)

{
  undefined1 auStack_30 [2];
  undefined1 local_2e;
  undefined1 local_2d;
  undefined4 local_c;
  
  local_2e = 2;
  local_2d = param_1;
  local_c = param_2;
  hdsreq(auStack_30,param_3);
  return;
}


// ==== hd_srch @ 800061ee

void hd_srch(undefined1 param_1,undefined4 param_2,undefined4 param_3)

{
  undefined1 auStack_30 [2];
  undefined1 local_2e;
  undefined1 local_2d;
  undefined1 auStack_2b [39];
  
  local_2e = 8;
  local_2d = param_1;
  putfnam(param_2,auStack_2b);
  hdsreq(auStack_30,param_3);
  return;
}


// ==== hd_remai @ 80006226

void hd_remai(undefined1 param_1,undefined4 param_2)

{
  undefined1 auStack_30 [2];
  undefined1 local_2e;
  undefined1 local_2d;
  
  local_2e = 0x3a;
  local_2d = param_1;
  hdsreq(auStack_30,param_2);
  return;
}


// ==== hd_rema2 @ 80006248

void hd_rema2(undefined1 param_1,undefined4 param_2)

{
  undefined1 auStack_30 [2];
  undefined1 local_2e;
  undefined1 local_2d;
  
  local_2e = 0x3b;
  local_2d = param_1;
  hdsreq(auStack_30,param_2);
  return;
}


// ==== hd_gtvol @ 8000626a

void hd_gtvol(undefined1 param_1,undefined4 param_2,undefined4 param_3)

{
  undefined1 auStack_30 [2];
  undefined1 local_2e;
  undefined1 local_2d;
  undefined4 local_c;
  
  local_2e = 0xb;
  local_2d = param_1;
  local_c = param_2;
  hdsreq(auStack_30,param_3);
  return;
}


// ==== hd_ptvol @ 80006292

void hd_ptvol(undefined1 param_1,undefined4 param_2,undefined4 param_3)

{
  undefined1 auStack_30 [2];
  undefined1 local_2e;
  undefined1 local_2d;
  undefined4 local_c;
  
  local_2e = 0xc;
  local_2d = param_1;
  local_c = param_2;
  hdsreq(auStack_30,param_3);
  return;
}


// ==== hd_kind @ 800062ba

void hd_kind(undefined1 param_1,undefined4 param_2)

{
  undefined1 auStack_30 [2];
  undefined1 local_2e;
  undefined1 local_2d;
  
  local_2e = 3;
  local_2d = param_1;
  hdsreq(auStack_30,param_2);
  return;
}


// ==== hd_init @ 800062dc

void hd_init(undefined1 param_1,byte param_2,byte param_3,undefined4 param_4,undefined4 param_5)

{
  undefined1 auStack_30 [2];
  undefined1 local_2e;
  undefined1 local_2d;
  ushort local_14;
  ushort local_12;
  undefined4 local_c;
  
  local_2e = 0x30;
  local_2d = param_1;
  local_14 = (ushort)param_2;
  local_12 = (ushort)param_3;
  local_c = param_4;
  hdsreq(auStack_30,param_5);
  return;
}


// ==== hd_volcp @ 8000631c

void hd_volcp(undefined1 param_1,undefined1 param_2,undefined4 param_3)

{
  undefined1 auStack_30 [2];
  undefined1 local_2e;
  undefined1 local_2d;
  undefined1 local_2c;
  
  local_2e = 0x31;
  local_2d = param_1;
  local_2c = param_2;
  hdsreq(auStack_30,param_3);
  return;
}


// ==== hd_dstat @ 80006344

void hd_dstat(undefined1 param_1,undefined4 param_2)

{
  undefined1 auStack_30 [2];
  undefined1 local_2e;
  undefined1 local_2d;
  
  local_2e = 0xf;
  local_2d = param_1;
  hdsreq(auStack_30,param_2);
  return;
}


// ==== hd_fcpy @ 80006366

void hd_fcpy(undefined1 param_1,undefined4 param_2,undefined1 param_3,undefined4 param_4,
            undefined4 param_5)

{
  undefined1 auStack_30 [2];
  undefined1 local_2e;
  undefined1 local_2d;
  undefined1 local_2c;
  undefined1 auStack_2b [11];
  undefined1 auStack_20 [28];
  
  local_2e = 0x32;
  local_2d = param_1;
  putfnam(param_2,auStack_2b);
  local_2c = param_3;
  putfnam(param_4,auStack_20);
  hdsreq(auStack_30,param_5);
  return;
}


// ==== hd_delet @ 800063b4

void hd_delet(undefined1 param_1,undefined4 param_2,undefined4 param_3)

{
  undefined1 auStack_30 [2];
  undefined1 local_2e;
  undefined1 local_2d;
  undefined1 auStack_2b [39];
  
  local_2e = 0xd;
  local_2d = param_1;
  putfnam(param_2,auStack_2b);
  hdsreq(auStack_30,param_3);
  return;
}


// ==== hd_resum @ 800063ec

void hd_resum(undefined1 param_1,undefined2 param_2,undefined4 param_3)

{
  undefined1 auStack_30 [2];
  undefined1 local_2e;
  undefined1 local_2d;
  undefined2 local_14;
  
  local_2e = 0xe;
  local_2d = param_1;
  local_14 = param_2;
  hdsreq(auStack_30,param_3);
  return;
}


// ==== hd_pack @ 80006416

void hd_pack(undefined1 param_1,undefined4 param_2)

{
  undefined1 auStack_30 [2];
  undefined1 local_2e;
  undefined1 local_2d;
  
  local_2e = 0x18;
  local_2d = param_1;
  hdsreq(auStack_30,param_2);
  return;
}


// ==== hd_rxb @ 80006438

void hd_rxb(undefined1 param_1,undefined2 param_2,undefined2 param_3,undefined4 param_4,
           undefined4 param_5,undefined4 param_6)

{
  undefined1 auStack_30 [2];
  undefined1 local_2e;
  undefined1 local_2d;
  undefined2 local_14;
  undefined2 local_12;
  undefined4 local_10;
  undefined4 local_c;
  
  local_2e = 0x19;
  local_2d = param_1;
  local_14 = param_2;
  local_12 = param_3;
  local_10 = param_4;
  local_c = param_5;
  hdsreq(auStack_30,param_6);
  return;
}


// ==== hd_wxb @ 80006476

void hd_wxb(undefined1 param_1,undefined2 param_2,undefined2 param_3,undefined4 param_4,
           undefined4 param_5,undefined4 param_6)

{
  undefined1 auStack_30 [2];
  undefined1 local_2e;
  undefined1 local_2d;
  undefined2 local_14;
  undefined2 local_12;
  undefined4 local_10;
  undefined4 local_c;
  
  local_2e = 0x1a;
  local_2d = param_1;
  local_14 = param_2;
  local_12 = param_3;
  local_10 = param_4;
  local_c = param_5;
  hdsreq(auStack_30,param_6);
  return;
}


// ==== hd_mkdir @ 800064b4

void hd_mkdir(undefined1 param_1,undefined4 param_2,undefined4 param_3)

{
  undefined1 auStack_30 [2];
  undefined1 local_2e;
  undefined1 local_2d;
  undefined4 local_c;
  
  local_2e = 0x43;
  local_2d = param_1;
  local_c = param_2;
  hdsreq(auStack_30,param_3);
  return;
}


// ==== hd_rmdir @ 800064dc

void hd_rmdir(undefined1 param_1,undefined4 param_2,undefined4 param_3)

{
  undefined1 auStack_30 [2];
  undefined1 local_2e;
  undefined1 local_2d;
  undefined4 local_c;
  
  local_2e = 0x44;
  local_2d = param_1;
  local_c = param_2;
  hdsreq(auStack_30,param_3);
  return;
}


// ==== hd_chdir @ 80006504

void hd_chdir(undefined1 param_1,undefined4 param_2,undefined4 param_3)

{
  undefined1 auStack_30 [2];
  undefined1 local_2e;
  undefined1 local_2d;
  undefined4 local_c;
  
  local_2e = 0x45;
  local_2d = param_1;
  local_c = param_2;
  hdsreq(auStack_30,param_3);
  return;
}


// ==== hd_pwd @ 8000652c

void hd_pwd(undefined1 param_1,undefined4 param_2,undefined4 param_3)

{
  undefined1 auStack_30 [2];
  undefined1 local_2e;
  undefined1 local_2d;
  undefined4 local_c;
  
  local_2e = 0x46;
  local_2d = param_1;
  local_c = param_2;
  hdsreq(auStack_30,param_3);
  return;
}


// ==== hd_dird @ 80006554

void hd_dird(undefined1 param_1,undefined2 param_2,undefined2 param_3,undefined4 param_4,
            undefined4 param_5)

{
  undefined1 auStack_30 [2];
  undefined1 local_2e;
  undefined1 local_2d;
  undefined2 local_14;
  undefined2 local_12;
  undefined4 local_c;
  
  local_2e = 0x47;
  local_2d = param_1;
  local_14 = param_2;
  local_12 = param_3;
  local_c = param_4;
  hdsreq(auStack_30,param_5);
  return;
}


// ==== hd_dire @ 8000658c

void hd_dire(undefined1 param_1,undefined2 param_2,undefined2 param_3,undefined4 param_4,
            undefined4 param_5)

{
  undefined1 auStack_30 [2];
  undefined1 local_2e;
  undefined1 local_2d;
  undefined2 local_14;
  undefined2 local_12;
  undefined4 local_c;
  
  local_2e = 9;
  local_2d = param_1;
  local_14 = param_2;
  local_12 = param_3;
  local_c = param_4;
  hdsreq(auStack_30,param_5);
  return;
}


// ==== hd_dcnfg @ 800065c4

void hd_dcnfg(undefined1 param_1,undefined4 param_2)

{
  undefined1 auStack_30 [2];
  undefined1 local_2e;
  undefined1 local_2d;
  
  local_2e = 0x40;
  local_2d = param_1;
  hdsreq(auStack_30,param_2);
  return;
}


// ==== hd_rdsct @ 800065e6

void hd_rdsct(undefined1 param_1,undefined2 param_2,undefined2 param_3,undefined2 param_4,
             undefined4 param_5,undefined4 param_6,undefined4 param_7)

{
  undefined2 local_30;
  undefined1 local_2e;
  undefined1 local_2d;
  undefined2 local_14;
  undefined2 local_12;
  undefined4 local_10;
  undefined4 local_c;
  
  local_2e = 0x41;
  local_2d = param_1;
  local_30 = param_2;
  local_14 = param_3;
  local_12 = param_4;
  local_10 = param_5;
  local_c = param_6;
  hdsreq(&local_30,param_7);
  return;
}


// ==== hd_wrsct @ 80006626

void hd_wrsct(undefined1 param_1,undefined2 param_2,undefined2 param_3,undefined2 param_4,
             undefined4 param_5,undefined4 param_6,undefined4 param_7)

{
  undefined2 local_30;
  undefined1 local_2e;
  undefined1 local_2d;
  undefined2 local_14;
  undefined2 local_12;
  undefined4 local_10;
  undefined4 local_c;
  
  local_2e = 0x42;
  local_2d = param_1;
  local_30 = param_2;
  local_14 = param_3;
  local_12 = param_4;
  local_10 = param_5;
  local_c = param_6;
  hdsreq(&local_30,param_7);
  return;
}


// ==== keystat @ 80006668

void keystat(undefined4 param_1)

{
  undefined1 auStack_16 [4];
  undefined1 auStack_12 [8];
  undefined1 *local_a;
  undefined1 local_6;
  
  local_6 = 0;
  local_a = auStack_16;
  kcdsmsg(auStack_12,param_1);
  return;
}


// ==== kyreadhd @ 8000668c

void kyreadhd(undefined4 param_1,short param_2,undefined4 param_3)

{
  undefined1 local_16 [4];
  int local_12;
  undefined4 local_e;
  undefined1 *local_a;
  undefined1 local_6;
  
  local_6 = 1;
  local_e = param_1;
  local_a = local_16;
  local_12 = (int)param_2;
  kcdsmsg(&local_12,param_3);
  return;
}


// ==== kyreadtl @ 800066cc

void kyreadtl(undefined4 param_1,short param_2,undefined4 param_3)

{
  undefined1 auStack_16 [4];
  int local_12;
  undefined4 local_e;
  undefined1 *local_a;
  undefined1 local_6;
  
  local_6 = 2;
  local_e = param_1;
  local_a = auStack_16;
  local_12 = (int)param_2;
  kcdsmsg(&local_12,param_3);
  return;
}


// ==== setdial @ 80006700

void setdial(short param_1,short param_2,undefined4 param_3)

{
  undefined1 auStack_16 [4];
  uint local_12 [2];
  undefined4 local_a;
  undefined1 local_6;
  
  local_6 = 4;
  local_a = param_3;
  if (param_1 == 0) {
    if (param_2 < 0) {
      local_12[0] = 0;
    }
    else {
      local_12[0] = 1;
    }
  }
  else if (param_1 == 1) {
    local_12[0] = 0x104;
  }
  else if (param_1 == 2) {
    if (param_2 < 0) {
      local_12[0] = 2;
    }
    else {
      local_12[0] = 3;
    }
  }
  else {
    local_12[0] = 0x105;
  }
  local_12[0] = local_12[0] | (int)param_2 << 0x10;
  kcdsmsg(local_12,auStack_16);
  return;
}


// ==== kbdrgrw @ 8000676e

void kbdrgrw(int param_1,int param_2,char param_3,undefined4 param_4)

{
  undefined1 auStack_16 [4];
  uint local_12 [2];
  undefined1 *local_a;
  undefined1 local_6;
  
  local_6 = 8;
  local_a = auStack_16;
  if (param_1 == 0x77) {
    local_12[0] = (int)param_3 | 0x770000U | param_2 << 8;
  }
  else {
    local_12[0] = param_2 << 8 | 0x720000;
  }
  kcdsmsg(local_12,param_4);
  return;
}


// ==== kreptyp @ 800067c0

void kreptyp(int param_1,undefined4 param_2,uint param_3,undefined4 param_4)

{
  undefined1 auStack_16 [4];
  uint local_12;
  undefined4 local_e;
  undefined1 *local_a;
  undefined1 local_6;
  
  if (((int)param_3 < 0x41) && (0 < (int)param_3)) {
    local_6 = 9;
    local_a = auStack_16;
    local_e = param_2;
    local_12 = param_3 | param_1 << 0x10;
    kcdsmsg(&local_12,param_4);
  }
  return;
}


// ==== kbdvol @ 8000680a

void kbdvol(undefined4 param_1,undefined4 param_2)

{
  undefined1 auStack_16 [4];
  undefined4 local_12 [2];
  undefined1 *local_a;
  undefined1 local_6;
  
  local_6 = 0x14;
  local_a = auStack_16;
  local_12[0] = param_1;
  kcdsmsg(local_12,param_2);
  return;
}


// ==== kbdvolblk @ 80006834

void kbdvolblk(undefined4 param_1,undefined4 param_2)

{
  undefined1 auStack_16 [4];
  undefined4 local_12 [2];
  undefined1 *local_a;
  undefined1 local_6;
  
  local_6 = 0x15;
  local_a = auStack_16;
  local_12[0] = param_1;
  kcdsmsg(local_12,param_2);
  return;
}


// ==== kcdsmsg @ 8000685e

void kcdsmsg(undefined4 param_1,uint *param_2)

{
  uint unaff_D7;
  
  dsemsg(0xe,0x81,param_1);
  *param_2 = *param_2 & 0xfffffffe;
  do {
    wait((void *)0x0);
    unaff_D7 = *param_2 | unaff_D7;
    *param_2 = unaff_D7;
  } while ((unaff_D7 & 1) == 0);
  return;
}


// ==== mailnwai @ 800068b4

uint mailnwai(undefined2 param_1,undefined4 param_2,undefined4 param_3,uint param_4)

{
  uint uVar1;
  uint unaff_D7;
  
  uVar1 = 0;
  semsg(param_1,param_2,param_3);
  do {
    wait((void *)0x0);
    uVar1 = unaff_D7 | uVar1;
  } while ((param_4 & uVar1) == 0);
  return param_4 & uVar1;
}


// ==== alloc_wai @ 80006900

void alloc_wai(uint *param_1)

{
  uint unaff_D7;
  
  *param_1 = *param_1 & 0xfffffdff;
  do {
    wait((void *)0x0);
    unaff_D7 = *param_1 | unaff_D7;
    *param_1 = unaff_D7;
  } while ((*param_1 & 0x200) == 0);
  *param_1 = *param_1 & 0xfffffdff;
  return;
}


// ==== alloc_com @ 8000693c

void alloc_com(undefined4 param_1,undefined4 param_2,undefined4 *param_3)

{
  undefined4 local_18;
  undefined1 local_14 [4];
  undefined4 local_10;
  undefined4 local_c;
  undefined1 *local_8;
  
  local_10 = param_1;
  local_c = param_2;
  local_8 = local_14;
  semsg(0xc,10,&local_10);
  local_18 = 0;
  if (param_3 == (undefined4 *)0x0) {
    param_3 = &local_18;
  }
  alloc_wai(param_3);
  return;
}


// ==== malloc @ 80006992

void * malloc(size_t __size)

{
  void *pvVar1;
  
  pvVar1 = (void *)alloc_com(0,__size,0);
  return pvVar1;
}


// ==== mfree @ 800069a8

void mfree(undefined4 param_1)

{
  alloc_com(1,param_1,0);
  return;
}


// ==== sralloc @ 800069c0

void sralloc(undefined4 param_1)

{
  alloc_com(2,param_1,0);
  return;
}


// ==== srfree @ 800069d8

void srfree(undefined4 param_1)

{
  alloc_com(3,param_1,0);
  return;
}


// ==== shdalloc @ 800069f0

void shdalloc(undefined4 param_1)

{
  alloc_com(4,param_1,0);
  return;
}


// ==== shdfree @ 80006a08

void shdfree(undefined4 param_1)

{
  alloc_com(5,param_1,0);
  return;
}


// ==== pbmalloc @ 80006a20

void pbmalloc(undefined4 param_1,undefined4 param_2)

{
  alloc_com(0,param_1,param_2);
  return;
}


// ==== pbmfree @ 80006a38

void pbmfree(undefined4 param_1,undefined4 param_2)

{
  alloc_com(1,param_1,param_2);
  return;
}


// ==== pbsralloc @ 80006a52

void pbsralloc(undefined4 param_1,undefined4 param_2)

{
  alloc_com(2,param_1,param_2);
  return;
}


// ==== pbsrfree @ 80006a6c

void pbsrfree(undefined4 param_1,undefined4 param_2)

{
  alloc_com(3,param_1,param_2);
  return;
}


// ==== pbshdallo @ 80006a86

void pbshdallo(undefined4 param_1,undefined4 param_2)

{
  alloc_com(4,param_1,param_2);
  return;
}


// ==== pbshdfree @ 80006aa0

void pbshdfree(undefined4 param_1,undefined4 param_2)

{
  alloc_com(5,param_1,param_2);
  return;
}


// ==== inidelid @ 80006abc

void inidelid(void)

{
  return;
}


// ==== nxtdelid @ 80006ac6

void nxtdelid(void)

{
  return;
}


// ==== mkhidnam @ 80006ae6

char mkhidnam(char param_1,char *param_2,char *param_3)

{
  char cVar1;
  int iVar2;
  char *pcVar3;
  char *pcVar4;
  char *pcVar5;
  
  if (param_2[7] == '@') {
    cVar1 = '@';
  }
  else {
    iVar2 = 0;
    pcVar4 = param_3;
    do {
      pcVar3 = pcVar4;
      pcVar5 = param_2;
      if (*param_2 == '.') break;
      pcVar5 = param_2 + 1;
      pcVar3 = pcVar4 + 1;
      *pcVar4 = *param_2;
      iVar2 = iVar2 + 1;
      pcVar4 = pcVar3;
      param_2 = pcVar5;
    } while (iVar2 < 6);
    for (; iVar2 < 6; iVar2 = iVar2 + 1) {
      *pcVar3 = '_';
      pcVar3 = pcVar3 + 1;
    }
    param_3[6] = param_1;
    param_3[7] = '@';
    for (; ((iVar2 < 8 && (*pcVar5 != '\0')) && (*pcVar5 != '.')); pcVar5 = pcVar5 + 1) {
      iVar2 = iVar2 + 1;
    }
    if (*pcVar5 == '.') {
      pcVar5 = pcVar5 + 1;
    }
    iVar2 = 0;
    pcVar4 = param_3 + 8;
    do {
      cVar1 = *pcVar5;
      pcVar3 = pcVar4;
      if (cVar1 == '\0') break;
      cVar1 = *pcVar5;
      pcVar3 = pcVar4 + 1;
      *pcVar4 = cVar1;
      iVar2 = iVar2 + 1;
      pcVar4 = pcVar3;
      pcVar5 = pcVar5 + 1;
    } while (iVar2 < 3);
    for (; iVar2 < 3; iVar2 = iVar2 + 1) {
      *pcVar3 = ' ';
      pcVar3 = pcVar3 + 1;
    }
  }
  return cVar1;
}


// ==== nxhidnam @ 80006b96

void nxhidnam(char param_1,int param_2)

{
  char unaff_D7b;
  
  inidelid();
  if ((unaff_D7b <= param_1) && (param_1 <= maxdelID)) {
    *(char *)(param_2 + 6) = param_1;
  }
  return;
}


// ==== isusedid @ 80006bd0

void isusedid(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  undefined1 auStack_12 [14];
  
  slvfnam(param_3,auStack_12);
  msdrenam(param_1,param_2,auStack_12,param_4);
  dosstt();
  return;
}


// ==== msddelet @ 80006c24

void msddelet(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  int unaff_D7;
  char cVar1;
  undefined1 auStack_10 [12];
  
  inidelid();
  cVar1 = (char)unaff_D7;
  mkhidnam((int)cVar1,param_2,auStack_10);
  if (-1 < unaff_D7) {
    do {
      isusedid(param_1,param_2,auStack_10,param_3);
      if (unaff_D7 < 1) goto LAB_80006c9e;
      nxtdelid((int)cVar1);
      if (cVar1 < '\x01') break;
      nxhidnam((int)cVar1,auStack_10);
    } while (0 < unaff_D7);
    unaff_D7 = -0x21;
  }
LAB_80006c9e:
  mkdoserr(param_1,unaff_D7);
  return;
}


// ==== msdresum @ 80006cb2

void msdresum(undefined4 param_1,undefined2 param_2,undefined4 param_3)

{
  uint uVar1;
  uint unaff_D7;
  uint in_stack_ffffffae;
  undefined1 auStack_4e [32];
  undefined1 auStack_2e [14];
  undefined1 auStack_20 [14];
  undefined1 auStack_12 [14];
  
  whichdos(param_1);
  msd_dire(param_1,param_2,param_2,auStack_4e,param_3);
  dosstt();
  if (-1 < (int)unaff_D7) {
    if (unaff_D7 == 0) {
      unaff_D7 = 0xfffffffd;
    }
    else {
      isdelfil(unaff_D7 & 0xffff,auStack_4e);
      if (unaff_D7 == 0) {
        unaff_D7 = 0xffffffd0;
      }
      else {
        msdrsmsb(unaff_D7 & 0xffff,auStack_4e,auStack_12,auStack_2e,auStack_20);
        msdrenam(param_1,auStack_12,auStack_20,param_3);
        dosstt();
        if (-1 < (int)unaff_D7) {
          msd_srch(param_1,auStack_2e,param_3);
          dosstt();
          uVar1 = unaff_D7;
          if (unaff_D7 == 0xfffffffd) {
            uVar1 = 0;
          }
          else if (0 < (int)unaff_D7) {
            msdrenam(param_1,auStack_2e,auStack_12,param_3);
            doserr();
            in_stack_ffffffae = unaff_D7;
          }
          if (-1 < (int)uVar1) {
            msdrenam(param_1,auStack_20,auStack_2e,param_3);
            dosstt();
            uVar1 = unaff_D7;
          }
          unaff_D7 = uVar1;
          if (-1 < (int)uVar1) {
            unaff_D7 = in_stack_ffffffae;
          }
        }
      }
    }
  }
  mkdoserr(param_1,unaff_D7);
  return;
}


// ==== msdrsmsb @ 80006df4

void msdrsmsb(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
             undefined4 param_5)

{
  undefined1 auStack_28 [12];
  undefined1 auStack_1c [6];
  undefined1 local_16;
  undefined1 auStack_10 [12];
  
  dirtofnm(param_1,param_2,auStack_10);
  cpybuf(auStack_10,auStack_1c,0xb);
  cpybuf(auStack_10,auStack_28,0xb);
  local_16 = 0x5f;
  undelfnm(auStack_28);
  slvfnam(auStack_10,param_3);
  slvfnam(auStack_1c,param_5);
  slvfnam(auStack_28,param_4);
  return;
}


// ==== msd_pack @ 80006e6c

void msd_pack(undefined4 param_1,undefined4 param_2)

{
  uint unaff_D7;
  short sVar1;
  undefined1 auStack_3e [14];
  undefined1 auStack_30 [12];
  undefined1 auStack_24 [32];
  
  sVar1 = 1;
  whichdos(param_1);
  do {
    while( true ) {
      msd_dire(param_1,sVar1,sVar1,auStack_24,param_2);
      dosstt();
      if ((int)unaff_D7 < 1) goto LAB_80006f0c;
      isdelfil(unaff_D7 & 0xffff,auStack_24);
      if (unaff_D7 != 0) break;
      sVar1 = sVar1 + 1;
    }
    dirtofnm(unaff_D7 & 0xffff,auStack_24,auStack_30);
    slvfnam(auStack_30,auStack_3e);
    msderase(param_1,auStack_3e,param_2);
    dosstt();
  } while (-1 < (int)unaff_D7);
LAB_80006f0c:
  mkdoserr(param_1);
  return;
}


// ==== msd_rxb @ 80006f24

void msd_rxb(undefined4 param_1,ushort param_2,ushort param_3,uint param_4,int param_5,
            undefined4 param_6)

{
  uint uVar1;
  ushort uVar2;
  uint unaff_D7;
  ushort uVar3;
  
  if (param_4 < 0x28) {
    uVar2 = (ushort)param_4;
  }
  else {
    uVar2 = 0x28;
  }
  uVar3 = 0;
  uVar1 = 0;
  for (; param_2 <= param_3; param_2 = param_2 + 1) {
    msd_1rxb(param_1,param_2,(uint)uVar2,param_5,param_6);
    dosstt();
    uVar1 = unaff_D7;
    if ((int)unaff_D7 < 1) break;
    param_5 = (uint)uVar2 + param_5;
    uVar3 = uVar3 + 1;
  }
  if (uVar3 == 0) {
    if (-1 < (int)uVar1) {
      uVar1 = 0xffffffcf;
    }
  }
  else if ((-1 < (int)uVar1) || (uVar1 == 0xfffffffd)) {
    uVar1 = (uint)uVar3;
  }
  mkdoserr(param_1,uVar1);
  return;
}


// ==== msd_1rxb @ 80006fcc

void msd_1rxb(undefined4 param_1,undefined2 param_2,undefined4 param_3,undefined1 *param_4,
             undefined4 param_5)

{
  int unaff_D7;
  undefined1 auStack_3e [32];
  undefined1 auStack_1e [8];
  undefined1 auStack_16 [4];
  undefined1 auStack_12 [14];
  
  msd_dire(param_1,param_2,param_2,auStack_3e,param_5);
  dosstt();
  if (-1 < unaff_D7) {
    if (unaff_D7 == 0) {
      unaff_D7 = -3;
    }
    else {
      dirtofnm(1,auStack_3e,auStack_1e);
      slvfnam(auStack_1e,auStack_12);
      msd_open(param_1,auStack_12,0,param_5);
      dosstt();
      if (-1 < unaff_D7) {
        cmpbuf(&DAT_80006fc0,auStack_16,3);
        if (unaff_D7 == 0) {
          cmpbuf(&DAT_80006fc4,auStack_16,3);
          cmpbuf(&DAT_80006fc8,auStack_16,3);
          *param_4 = 0x20;
        }
        else {
          *param_4 = 1;
        }
        dosstt();
        msd_xxb((int)(short)unaff_D7,param_4,param_3,param_5);
        msd_clos((int)(short)unaff_D7,param_5);
      }
    }
  }
  mkdoserr(param_1,unaff_D7);
  return;
}


// ==== msd_xxb @ 800070f6

void msd_xxb(short param_1,char *param_2,int param_3,undefined4 param_4)

{
  int iVar1;
  byte bVar2;
  int unaff_D5;
  int unaff_D7;
  byte *unaff_A3;
  char *pcVar3;
  bool bVar4;
  
  bVar4 = *param_2 == '\x01';
  if (bVar4) {
    *param_2 = ' ';
  }
  bVar2 = 0;
  do {
    msd_read((int)param_1,0x400,&DAT_900059c0,param_4);
    dosstt();
    if (unaff_D7 < 1) break;
    unaff_A3 = &DAT_900059c0;
    unaff_D5 = 0;
    if (0 < unaff_D7) {
      do {
        if (bVar4) {
          bVar2 = *unaff_A3;
        }
        else {
          bVar2 = *unaff_A3 & 0x7f;
        }
        unaff_A3 = unaff_A3 + 1;
      } while ((bVar2 != 0x40) && (unaff_D5 = unaff_D5 + 1, unaff_D5 < unaff_D7));
    }
  } while (bVar2 != 0x40);
  if (bVar2 == 0x40) {
    if (unaff_D7 - unaff_D5 < param_3) {
      iVar1 = unaff_D7 - unaff_D5;
    }
    else {
      iVar1 = param_3;
    }
    msd_xxx(unaff_A3,param_2,iVar1,0,bVar4);
    if (iVar1 < param_3) {
      msd_read((int)param_1,0x400,&DAT_900059c0,param_4);
      dosstt();
      if (0 < unaff_D7) {
        iVar1 = unaff_D7;
        if (param_3 - unaff_D5 <= unaff_D7) {
          iVar1 = param_3 - unaff_D5;
        }
        msd_xxx(&DAT_900059c0,param_2 + unaff_D7,iVar1);
      }
    }
    pcVar3 = param_2 + unaff_D7;
    if (((bVar4) && (unaff_D7 != 0x28)) &&
       ((unaff_D7 < 1 || ((*pcVar3 != '\r' && (*pcVar3 != '\n')))))) {
      unaff_D7 = 0;
      pcVar3 = param_2;
    }
    for (; unaff_D7 < param_3; unaff_D7 = unaff_D7 + 1) {
      *pcVar3 = ' ';
      pcVar3 = pcVar3 + 1;
    }
  }
  return;
}


// ==== msd_xxx @ 80007252

void msd_xxx(byte *param_1,byte *param_2,int param_3,int param_4,int param_5)

{
  do {
    if (param_3 <= param_4) {
      return;
    }
    if (param_5 == 0) {
      if ((*param_1 & 0x7f) < 0x20) {
        return;
      }
    }
    else if ((*param_1 < 0x20) || (0x7e < *param_1)) {
      *param_2 = *param_1;
      return;
    }
    *param_2 = *param_1;
    param_4 = param_4 + 1;
    param_1 = param_1 + 1;
    param_2 = param_2 + 1;
  } while( true );
}


// ==== msd_wxb @ 800072c8

void msd_wxb(undefined4 param_1)

{
  mkdoserr(param_1,0xfffffff6);
  return;
}


// ==== msdreq @ 800072e0

void msdreq(int param_1,undefined4 *param_2)

{
  undefined4 unaff_D7;
  undefined1 local_8 [4];
  
  *(undefined1 **)(param_1 + 0x28) = local_8;
  mailnwai(0x2c,4,param_1,0x80);
  *param_2 = unaff_D7;
  return;
}


// ==== msdrdsct @ 80007312

void msdrdsct(undefined1 param_1,undefined2 param_2,undefined2 param_3,undefined2 param_4,
             undefined4 param_5,undefined4 param_6,undefined4 param_7)

{
  undefined2 local_30;
  undefined1 local_2e;
  undefined1 local_2d;
  undefined2 local_14;
  undefined2 local_12;
  undefined4 local_10;
  undefined4 local_c;
  
  local_2e = 0x40;
  local_2d = param_1;
  local_30 = param_2;
  local_14 = param_3;
  local_12 = param_4;
  local_10 = param_5;
  local_c = param_6;
  msdreq(&local_30,param_7);
  return;
}


// ==== msdwrsct @ 8000735a

void msdwrsct(undefined1 param_1,undefined2 param_2,undefined2 param_3,undefined2 param_4,
             undefined4 param_5,undefined4 param_6,undefined4 param_7)

{
  undefined2 local_30;
  undefined1 local_2e;
  undefined1 local_2d;
  undefined2 local_14;
  undefined2 local_12;
  undefined4 local_10;
  undefined4 local_c;
  
  local_2e = 0x41;
  local_2d = param_1;
  local_30 = param_2;
  local_14 = param_3;
  local_12 = param_4;
  local_10 = param_5;
  local_c = param_6;
  msdreq(&local_30,param_7);
  return;
}


// ==== msddcnfg @ 800073a2

void msddcnfg(undefined1 param_1,undefined4 param_2)

{
  undefined1 auStack_30 [2];
  undefined1 local_2e;
  undefined1 local_2d;
  
  local_2e = 0x42;
  local_2d = param_1;
  msdreq(auStack_30,param_2);
  return;
}


// ==== msdcreat @ 800073c8

void msdcreat(undefined1 param_1,undefined4 param_2,ushort param_3,undefined2 param_4,
             undefined4 param_5)

{
  undefined1 auStack_30 [2];
  undefined1 local_2e;
  undefined1 local_2d;
  undefined1 auStack_2b [23];
  undefined2 local_14;
  uint local_10;
  
  local_2e = 0x13;
  local_2d = param_1;
  putfnam(param_2,auStack_2b);
  local_10 = (uint)param_3;
  local_14 = param_4;
  msdreq(auStack_30,param_5);
  return;
}


// ==== msd_open @ 8000741a

void msd_open(undefined1 param_1,undefined4 param_2,undefined2 param_3,undefined4 param_4)

{
  undefined1 auStack_30 [2];
  undefined1 local_2e;
  undefined1 local_2d;
  undefined1 auStack_2b [23];
  undefined2 local_14;
  
  local_2e = 0x11;
  local_2d = param_1;
  putfnam(param_2,auStack_2b);
  local_14 = param_3;
  msdreq(auStack_30,param_4);
  return;
}


// ==== msd_clos @ 8000745c

void msd_clos(undefined2 param_1,undefined4 param_2)

{
  undefined2 local_30;
  undefined1 local_2e;
  
  local_2e = 0x12;
  local_30 = param_1;
  msdreq(&local_30,param_2);
  return;
}


// ==== msd_read @ 80007480

void msd_read(undefined2 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  undefined2 local_30;
  undefined1 local_2e;
  undefined4 local_10;
  undefined4 local_c;
  
  local_2e = 0x21;
  local_30 = param_1;
  local_10 = param_2;
  local_c = param_3;
  msdreq(&local_30,param_4);
  return;
}


// ==== msdwrite @ 800074b0

void msdwrite(undefined2 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  undefined2 local_30;
  undefined1 local_2e;
  undefined4 local_10;
  undefined4 local_c;
  
  local_2e = 0x22;
  local_30 = param_1;
  local_10 = param_2;
  local_c = param_3;
  msdreq(&local_30,param_4);
  return;
}


// ==== msd_seek @ 800074e0

void msd_seek(undefined2 param_1,undefined2 param_2,undefined4 param_3,undefined4 param_4)

{
  undefined2 local_30;
  undefined1 local_2e;
  undefined2 local_14;
  undefined4 local_10;
  
  local_2e = 0x23;
  local_30 = param_1;
  local_10 = param_3;
  local_14 = param_2;
  msdreq(&local_30,param_4);
  return;
}


// ==== msderase @ 80007512

void msderase(undefined1 param_1,undefined4 param_2,undefined4 param_3)

{
  undefined1 auStack_30 [2];
  undefined1 local_2e;
  undefined1 local_2d;
  undefined1 auStack_2b [39];
  
  local_2e = 0x15;
  local_2d = param_1;
  putfnam(param_2,auStack_2b);
  msdreq(auStack_30,param_3);
  return;
}


// ==== msdrenam @ 8000754c

void msdrenam(undefined1 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  undefined1 auStack_30 [2];
  undefined1 local_2e;
  undefined1 local_2d;
  undefined1 auStack_2b [11];
  undefined1 auStack_20 [28];
  
  local_2e = 0x14;
  local_2d = param_1;
  putfnam(param_2,auStack_2b);
  putfnam(param_3,auStack_20);
  msdreq(auStack_30,param_4);
  return;
}


// ==== msdmount @ 80007596

void msdmount(undefined1 param_1,undefined4 param_2)

{
  undefined1 auStack_30 [2];
  undefined1 local_2e;
  undefined1 local_2d;
  
  local_2e = 1;
  local_2d = param_1;
  msdreq(auStack_30,param_2);
  return;
}


// ==== msddemnt @ 800075bc

void msddemnt(undefined1 param_1,undefined4 param_2)

{
  undefined1 auStack_30 [2];
  undefined1 local_2e;
  undefined1 local_2d;
  
  local_2e = 4;
  local_2d = param_1;
  msdreq(auStack_30,param_2);
  return;
}


// ==== msd_info @ 800075e2

void msd_info(undefined1 param_1,undefined4 param_2,undefined4 param_3)

{
  undefined1 auStack_30 [2];
  undefined1 local_2e;
  undefined1 local_2d;
  undefined4 local_c;
  
  local_2e = 2;
  local_2d = param_1;
  local_c = param_2;
  msdreq(auStack_30,param_3);
  return;
}


// ==== msd_srch @ 8000760e

void msd_srch(undefined1 param_1,undefined4 param_2,undefined4 param_3)

{
  undefined1 auStack_30 [2];
  undefined1 local_2e;
  undefined1 local_2d;
  undefined1 auStack_2b [39];
  
  local_2e = 8;
  local_2d = param_1;
  putfnam(param_2,auStack_2b);
  msdreq(auStack_30,param_3);
  return;
}


// ==== msd_dire @ 80007648

void msd_dire(undefined1 param_1,undefined2 param_2,undefined2 param_3,undefined4 param_4,
             undefined4 param_5)

{
  undefined1 auStack_30 [2];
  undefined1 local_2e;
  undefined1 local_2d;
  undefined2 local_14;
  undefined2 local_12;
  undefined4 local_c;
  
  local_2e = 9;
  local_2d = param_1;
  local_14 = param_2;
  local_12 = param_3;
  local_c = param_4;
  msdreq(auStack_30,param_5);
  return;
}


// ==== msdremai @ 80007684

void msdremai(undefined1 param_1,undefined4 param_2)

{
  undefined1 auStack_30 [2];
  undefined1 local_2e;
  undefined1 local_2d;
  
  local_2e = 10;
  local_2d = param_1;
  msdreq(auStack_30,param_2);
  return;
}


// ==== msdgtvol @ 800076aa

void msdgtvol(undefined1 param_1,undefined4 param_2,undefined4 param_3)

{
  undefined1 auStack_30 [2];
  undefined1 local_2e;
  undefined1 local_2d;
  undefined4 local_c;
  
  local_2e = 0xb;
  local_2d = param_1;
  local_c = param_2;
  msdreq(auStack_30,param_3);
  return;
}


// ==== msdptvol @ 800076d6

void msdptvol(undefined1 param_1,undefined4 param_2,undefined4 param_3)

{
  undefined1 auStack_30 [2];
  undefined1 local_2e;
  undefined1 local_2d;
  undefined4 local_c;
  
  local_2e = 0xc;
  local_2d = param_1;
  local_c = param_2;
  msdreq(auStack_30,param_3);
  return;
}


// ==== msd_kind @ 80007702

void msd_kind(undefined1 param_1,undefined4 param_2)

{
  undefined1 auStack_30 [2];
  undefined1 local_2e;
  undefined1 local_2d;
  
  local_2e = 3;
  local_2d = param_1;
  msdreq(auStack_30,param_2);
  return;
}


// ==== msd_init @ 80007728

void msd_init(undefined1 param_1,byte param_2,byte param_3,undefined4 param_4,undefined4 param_5)

{
  undefined1 auStack_30 [2];
  undefined1 local_2e;
  undefined1 local_2d;
  ushort local_14;
  ushort local_12;
  undefined4 local_c;
  
  local_2e = 0x30;
  local_2d = param_1;
  local_14 = (ushort)param_2;
  local_12 = (ushort)param_3;
  local_c = param_4;
  msdreq(auStack_30,param_5);
  return;
}


// ==== msdvolcp @ 8000776c

void msdvolcp(undefined1 param_1,undefined1 param_2,undefined4 param_3)

{
  undefined1 auStack_30 [2];
  undefined1 local_2e;
  undefined1 local_2d;
  undefined1 local_2c;
  
  local_2e = 0x31;
  local_2d = param_1;
  local_2c = param_2;
  msdreq(auStack_30,param_3);
  return;
}


// ==== msddstat @ 8000779a

void msddstat(undefined1 param_1,undefined4 param_2)

{
  undefined1 auStack_30 [2];
  undefined1 local_2e;
  undefined1 local_2d;
  
  local_2e = 0xf;
  local_2d = param_1;
  msdreq(auStack_30,param_2);
  return;
}


// ==== msd_fcpy @ 800077c0

void msd_fcpy(undefined1 param_1,undefined4 param_2,undefined1 param_3,undefined4 param_4,
             undefined4 param_5)

{
  undefined1 auStack_30 [2];
  undefined1 local_2e;
  undefined1 local_2d;
  undefined1 local_2c;
  undefined1 auStack_2b [11];
  undefined1 auStack_20 [28];
  
  local_2e = 0x32;
  local_2d = param_1;
  putfnam(param_2,auStack_2b);
  local_2c = param_3;
  putfnam(param_4,auStack_20);
  msdreq(auStack_30,param_5);
  return;
}


// ==== sdu_clos @ 80007814

void sdu_clos(undefined2 param_1,undefined4 *param_2)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36 [36];
  undefined2 local_12;
  undefined4 local_c;
  undefined1 *local_8;
  
  local_c = 0;
  local_36[0] = 3;
  local_12 = param_1;
  local_8 = local_3a;
  mailnwai(0x32,6,local_36,0x4000000);
  *param_2 = unaff_D7;
  return;
}


// ==== sdu_read @ 80007858

void sdu_read(undefined2 param_1,undefined4 param_2,undefined4 param_3,undefined4 *param_4)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36 [32];
  undefined4 local_16;
  undefined2 local_12;
  undefined4 local_c;
  undefined1 *local_8;
  
  local_36[0] = 4;
  local_12 = param_1;
  local_16 = param_2;
  local_c = param_3;
  local_8 = local_3a;
  mailnwai(0x32,6,local_36,0x4000000);
  *param_4 = unaff_D7;
  return;
}


// ==== sduwrite @ 800078a4

void sduwrite(undefined2 param_1,undefined4 param_2,undefined4 param_3,undefined4 *param_4)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36 [32];
  undefined4 local_16;
  undefined2 local_12;
  undefined4 local_10;
  undefined4 local_c;
  undefined1 *local_8;
  
  local_36[0] = 5;
  local_12 = param_1;
  local_16 = param_2;
  local_c = param_3;
  local_10 = 0x80;
  local_8 = local_3a;
  mailnwai(0x32,6,local_36,0x4000000);
  *param_4 = unaff_D7;
  return;
}


// ==== sducreat @ 800078f8

void sducreat(undefined4 param_1,undefined4 param_2,ushort param_3,undefined4 param_4,
             undefined4 *param_5)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36;
  undefined1 local_35;
  undefined1 local_34;
  undefined1 auStack_32 [28];
  uint local_16;
  undefined4 local_c;
  undefined1 *local_8;
  
  local_c = 0;
  local_36 = 1;
  local_35 = (undefined1)((uint)param_1 >> 0x10);
  local_34 = (undefined1)param_1;
  cpyast(param_2,auStack_32);
  local_16 = (uint)param_3;
  local_8 = local_3a;
  mailnwai(0x32,6,&local_36,0x4000000);
  *param_5 = unaff_D7;
  return;
}


// ==== sdu_open @ 8000796a

void sdu_open(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 *param_4)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36;
  undefined1 local_35;
  undefined1 local_34;
  undefined1 auStack_32 [38];
  undefined4 local_c;
  undefined1 *local_8;
  
  local_c = 0;
  local_36 = 2;
  local_35 = (undefined1)((uint)param_1 >> 0x10);
  local_34 = (undefined1)param_1;
  cpyast(param_2,auStack_32);
  local_8 = local_3a;
  mailnwai(0x32,6,&local_36,0x4000000);
  *param_4 = unaff_D7;
  return;
}


// ==== sdu_delet @ 800079cc

void sdu_delet(undefined4 param_1,undefined4 param_2,undefined4 *param_3)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36;
  undefined1 local_35;
  undefined1 local_34;
  undefined1 auStack_32 [38];
  undefined4 local_c;
  undefined1 *local_8;
  
  local_c = 0;
  local_36 = 6;
  local_35 = (undefined1)((uint)param_1 >> 0x10);
  local_34 = (undefined1)param_1;
  cpyast(param_2,auStack_32);
  local_8 = local_3a;
  mailnwai(0x32,6,&local_36,0x4000000);
  *param_3 = unaff_D7;
  return;
}


// ==== sdu_erase @ 80007a2e

void sdu_erase(undefined4 param_1,undefined4 param_2,undefined4 *param_3)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36;
  undefined1 local_35;
  undefined1 local_34;
  undefined1 auStack_32 [38];
  undefined4 local_c;
  undefined1 *local_8;
  
  local_c = 0;
  local_36 = 0x1c;
  local_35 = (undefined1)((uint)param_1 >> 0x10);
  local_34 = (undefined1)param_1;
  cpyast(param_2,auStack_32);
  local_8 = local_3a;
  mailnwai(0x32,6,&local_36,0x4000000);
  *param_3 = unaff_D7;
  return;
}


// ==== sduresum @ 80007a90

void sduresum(undefined4 param_1,undefined2 param_2,undefined4 *param_3)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36;
  undefined1 local_35;
  undefined1 local_34;
  undefined2 local_1a;
  undefined4 local_c;
  undefined1 *local_8;
  
  local_c = 0;
  local_36 = 7;
  local_35 = (undefined1)((uint)param_1 >> 0x10);
  local_34 = (undefined1)param_1;
  local_1a = param_2;
  local_8 = local_3a;
  mailnwai(0x32,6,&local_36,0x4000000);
  *param_3 = unaff_D7;
  return;
}


// ==== sdurenam @ 80007ae6

void sdurenam(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 *param_4)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36;
  undefined1 local_35;
  undefined1 local_34;
  undefined1 auStack_32 [12];
  undefined1 auStack_26 [26];
  undefined4 local_c;
  undefined1 *local_8;
  
  local_c = 0;
  local_36 = 8;
  local_35 = (undefined1)((uint)param_1 >> 0x10);
  local_34 = (undefined1)param_1;
  cpyast(param_2,auStack_32);
  cpyast(param_3,auStack_26);
  local_8 = local_3a;
  mailnwai(0x32,6,&local_36,0x4000000);
  *param_4 = unaff_D7;
  return;
}


// ==== sdumount @ 80007b58

void sdumount(undefined4 param_1,undefined4 *param_2)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36;
  undefined1 local_35;
  undefined1 local_34;
  undefined4 local_c;
  undefined1 *local_8;
  
  local_c = 0;
  local_36 = 9;
  local_35 = (undefined1)((uint)param_1 >> 0x10);
  local_34 = (undefined1)param_1;
  local_8 = local_3a;
  mailnwai(0x32,6,&local_36,0x4000000);
  *param_2 = unaff_D7;
  return;
}


// ==== sdudemnt @ 80007ba6

void sdudemnt(undefined4 param_1,undefined4 *param_2)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36;
  undefined1 local_35;
  undefined1 local_34;
  undefined4 local_c;
  undefined1 *local_8;
  
  local_c = 0;
  local_36 = 10;
  local_35 = (undefined1)((uint)param_1 >> 0x10);
  local_34 = (undefined1)param_1;
  local_8 = local_3a;
  mailnwai(0x32,6,&local_36,0x4000000);
  *param_2 = unaff_D7;
  return;
}


// ==== sdusghdr @ 80007bf4

void sdusghdr(undefined4 param_1,undefined4 param_2,undefined4 *param_3)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36;
  undefined1 local_35;
  undefined1 local_34;
  undefined4 local_c;
  undefined1 *local_8;
  
  local_36 = 0xb;
  local_35 = (undefined1)((uint)param_1 >> 0x10);
  local_34 = (undefined1)param_1;
  local_c = param_2;
  local_8 = local_3a;
  mailnwai(0x32,6,&local_36,0x4000000);
  *param_3 = unaff_D7;
  return;
}


// ==== sdu_srch @ 80007c44

void sdu_srch(undefined4 param_1,undefined4 param_2,undefined4 *param_3)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36;
  undefined1 local_35;
  undefined1 local_34;
  undefined1 auStack_32 [38];
  undefined4 local_c;
  undefined1 *local_8;
  
  local_c = 0;
  local_36 = 0xc;
  local_35 = (undefined1)((uint)param_1 >> 0x10);
  local_34 = (undefined1)param_1;
  cpyast(param_2,auStack_32);
  local_8 = local_3a;
  mailnwai(0x32,6,&local_36,0x4000000);
  *param_3 = unaff_D7;
  return;
}


// ==== sdu_dire @ 80007ca6

void sdu_dire(undefined4 param_1,undefined2 param_2,undefined2 param_3,undefined4 param_4,
             undefined4 *param_5)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36;
  undefined1 local_35;
  undefined1 local_34;
  undefined2 local_1a;
  undefined2 local_18;
  undefined4 local_c;
  undefined1 *local_8;
  
  local_36 = 0xd;
  local_35 = (undefined1)((uint)param_1 >> 0x10);
  local_34 = (undefined1)param_1;
  local_1a = param_2;
  local_18 = param_3;
  local_c = param_4;
  local_8 = local_3a;
  mailnwai(0x32,6,&local_36,0x4000000);
  *param_5 = unaff_D7;
  return;
}


// ==== sdu_rxb @ 80007d0c

void sdu_rxb(undefined4 param_1,undefined2 param_2,undefined2 param_3,ushort param_4,
            undefined4 param_5,undefined4 *param_6)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36;
  undefined1 local_35;
  undefined1 local_34;
  undefined2 local_1a;
  undefined2 local_18;
  uint local_16;
  undefined4 local_c;
  undefined1 *local_8;
  
  local_36 = 0xe;
  local_35 = (undefined1)((uint)param_1 >> 0x10);
  local_34 = (undefined1)param_1;
  local_1a = param_2;
  local_18 = param_3;
  local_16 = (uint)param_4;
  local_c = param_5;
  local_8 = local_3a;
  mailnwai(0x32,6,&local_36,0x4000000);
  *param_6 = unaff_D7;
  return;
}


// ==== sdu_wxb @ 80007d82

void sdu_wxb(undefined4 param_1,undefined2 param_2,undefined2 param_3,ushort param_4,
            undefined4 param_5,undefined4 *param_6)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36;
  undefined1 local_35;
  undefined1 local_34;
  undefined2 local_1a;
  undefined2 local_18;
  uint local_16;
  undefined4 local_c;
  undefined1 *local_8;
  
  local_36 = 0xf;
  local_35 = (undefined1)((uint)param_1 >> 0x10);
  local_34 = (undefined1)param_1;
  local_1a = param_2;
  local_18 = param_3;
  local_16 = (uint)param_4;
  local_c = param_5;
  local_8 = local_3a;
  mailnwai(0x32,6,&local_36,0x4000000);
  *param_6 = unaff_D7;
  return;
}


// ==== sduremai @ 80007df8

void sduremai(undefined4 param_1,undefined4 *param_2)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36;
  undefined1 local_35;
  undefined1 local_34;
  undefined4 local_c;
  undefined1 *local_8;
  
  local_c = 0;
  local_36 = 0x10;
  local_35 = (undefined1)((uint)param_1 >> 0x10);
  local_34 = (undefined1)param_1;
  local_8 = local_3a;
  mailnwai(0x32,6,&local_36,0x4000000);
  *param_2 = unaff_D7;
  return;
}


// ==== sdugtvol @ 80007e46

void sdugtvol(undefined4 param_1,undefined4 param_2,undefined4 *param_3)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36;
  undefined1 local_35;
  undefined1 local_34;
  undefined4 local_c;
  undefined1 *local_8;
  
  local_36 = 0x11;
  local_35 = (undefined1)((uint)param_1 >> 0x10);
  local_34 = (undefined1)param_1;
  local_c = param_2;
  local_8 = local_3a;
  mailnwai(0x32,6,&local_36,0x4000000);
  *param_3 = unaff_D7;
  return;
}


// ==== sduptvol @ 80007e96

void sduptvol(undefined4 param_1,undefined4 param_2,undefined4 *param_3)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36;
  undefined1 local_35;
  undefined1 local_34;
  undefined4 local_c;
  undefined1 *local_8;
  
  local_36 = 0x12;
  local_35 = (undefined1)((uint)param_1 >> 0x10);
  local_34 = (undefined1)param_1;
  local_c = param_2;
  local_8 = local_3a;
  mailnwai(0x32,6,&local_36,0x4000000);
  *param_3 = unaff_D7;
  return;
}


// ==== sdu_kind @ 80007ee6

void sdu_kind(undefined4 param_1,undefined4 *param_2)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36;
  undefined1 local_35;
  undefined1 local_34;
  undefined4 local_c;
  undefined1 *local_8;
  
  local_c = 0;
  local_36 = 0x13;
  local_35 = (undefined1)((uint)param_1 >> 0x10);
  local_34 = (undefined1)param_1;
  local_8 = local_3a;
  mailnwai(0x32,6,&local_36,0x4000000);
  *param_2 = unaff_D7;
  return;
}


// ==== sdu_init @ 80007f34

void sdu_init(undefined4 param_1,char param_2,byte param_3,undefined4 param_4,undefined4 *param_5)

{
  byte bVar1;
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36;
  undefined1 local_35;
  char local_34;
  uint local_10;
  undefined4 local_c;
  undefined1 *local_8;
  
  local_34 = (char)param_1;
  bVar1 = 0;
  local_36 = 0x14;
  local_35 = (undefined1)((uint)param_1 >> 0x10);
  if (param_2 == '\0') {
    bVar1 = 0x80;
  }
  if ((local_34 == '\b') || (local_34 == '\t')) {
    if (param_2 == '\x02') {
      bVar1 = bVar1 | 8;
    }
    else {
      bVar1 = bVar1 | 4;
    }
  }
  if (((local_34 == '\f') || (local_34 == '\r')) && ((param_3 & 3) != 3)) {
    bVar1 = bVar1 | 1;
  }
  local_10 = (uint)bVar1;
  local_c = param_4;
  local_8 = local_3a;
  mailnwai(0x32,6,&local_36,0x4000000);
  *param_5 = unaff_D7;
  return;
}


// ==== sdu_pack @ 80007fde

void sdu_pack(undefined4 param_1,undefined4 *param_2)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36;
  undefined1 local_35;
  undefined1 local_34;
  undefined4 local_c;
  undefined1 *local_8;
  
  local_c = 0;
  local_36 = 0x15;
  local_35 = (undefined1)((uint)param_1 >> 0x10);
  local_34 = (undefined1)param_1;
  local_8 = local_3a;
  mailnwai(0x32,6,&local_36,0x4000000);
  *param_2 = unaff_D7;
  return;
}


// ==== sdu_seek @ 8000802c

void sdu_seek(undefined2 param_1,byte param_2,undefined4 param_3,undefined4 *param_4)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36 [32];
  undefined4 local_16;
  undefined2 local_12;
  uint local_10;
  undefined4 local_c;
  undefined1 *local_8;
  
  local_c = 0;
  local_36[0] = 0x16;
  local_12 = param_1;
  local_10 = (uint)param_2;
  local_16 = param_3;
  local_8 = local_3a;
  mailnwai(0x32,6,local_36,0x4000000);
  *param_4 = unaff_D7;
  return;
}


// ==== sduvolcp @ 80008082

void sduvolcp(undefined4 param_1,undefined1 param_2,undefined4 *param_3)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36;
  undefined1 local_35;
  undefined1 local_34;
  undefined1 local_33;
  undefined4 local_10;
  undefined4 local_c;
  undefined1 *local_8;
  
  local_c = 0;
  local_36 = 0x17;
  local_35 = (undefined1)((uint)param_1 >> 0x10);
  local_34 = (undefined1)param_1;
  local_33 = param_2;
  local_10 = 0x80;
  local_8 = local_3a;
  mailnwai(0x32,6,&local_36,0x4000000);
  *param_3 = unaff_D7;
  return;
}


// ==== sdudstat @ 800080e0

void sdudstat(undefined4 param_1,undefined4 *param_2)

{
  int unaff_D7;
  undefined1 auStack_3c [2];
  undefined1 local_36;
  undefined1 local_35;
  undefined1 local_34;
  undefined4 local_c;
  undefined1 *local_8;
  
  sduckdrv(param_1);
  if (unaff_D7 == 0) {
    local_c = 0;
    local_36 = 0x18;
    local_35 = (undefined1)((uint)param_1 >> 0x10);
    local_34 = (undefined1)param_1;
    local_8 = auStack_3c + 2;
    mailnwai(0x32,6,&local_36,0x4000000);
    *param_2 = 0;
  }
  return;
}


// ==== sdu_fcpy @ 8000815a

void sdu_fcpy(undefined4 param_1,undefined4 param_2,undefined1 param_3,undefined4 param_4,
             undefined4 *param_5)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36;
  undefined1 local_35;
  undefined1 local_34;
  undefined1 local_33;
  undefined1 auStack_32 [12];
  undefined1 auStack_26 [22];
  undefined4 local_10;
  undefined4 local_c;
  undefined1 *local_8;
  
  local_c = 0;
  local_36 = 0x19;
  local_35 = (undefined1)((uint)param_1 >> 0x10);
  local_34 = (undefined1)param_1;
  local_33 = param_3;
  cpybuf(param_2,auStack_32,0xc);
  cpybuf(param_4,auStack_26,0xc);
  local_10 = 0x80;
  local_8 = local_3a;
  mailnwai(0x32,6,&local_36,0x4000000);
  *param_5 = unaff_D7;
  return;
}


// ==== sdurdsct @ 800081e4

void sdurdsct(undefined4 param_1,undefined2 param_2,undefined2 param_3,undefined2 param_4,
             undefined4 param_5,undefined4 param_6,undefined4 *param_7)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36;
  undefined1 local_35;
  undefined1 local_34;
  undefined2 local_1a;
  undefined2 local_18;
  undefined4 local_16;
  undefined2 local_12;
  undefined4 local_c;
  undefined1 *local_8;
  
  local_36 = 0x1a;
  local_35 = (undefined1)((uint)param_1 >> 0x10);
  local_34 = (undefined1)param_1;
  local_12 = param_2;
  local_1a = param_3;
  local_18 = param_4;
  local_c = param_6;
  local_16 = param_5;
  local_8 = local_3a;
  mailnwai(0x32,6,&local_36,0x4000000);
  *param_7 = unaff_D7;
  return;
}


// ==== sduwrsct @ 80008252

void sduwrsct(undefined4 param_1,undefined2 param_2,undefined2 param_3,undefined2 param_4,
             undefined4 param_5,undefined4 param_6,undefined4 *param_7)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36;
  undefined1 local_35;
  undefined1 local_34;
  undefined2 local_1a;
  undefined2 local_18;
  undefined4 local_16;
  undefined2 local_12;
  undefined4 local_c;
  undefined1 *local_8;
  
  local_36 = 0x1b;
  local_35 = (undefined1)((uint)param_1 >> 0x10);
  local_34 = (undefined1)param_1;
  local_12 = param_2;
  local_1a = param_3;
  local_18 = param_4;
  local_c = param_6;
  local_16 = param_5;
  local_8 = local_3a;
  mailnwai(0x32,6,&local_36,0x4000000);
  *param_7 = unaff_D7;
  return;
}


// ==== sdudcnfg @ 800082c0

void sdudcnfg(undefined4 param_1,undefined4 *param_2)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36;
  undefined1 local_35;
  undefined1 local_34;
  undefined4 local_c;
  undefined1 *local_8;
  
  local_c = 0;
  local_36 = 0x1d;
  local_35 = (undefined1)((uint)param_1 >> 0x10);
  local_34 = (undefined1)param_1;
  local_8 = local_3a;
  mailnwai(0x32,6,&local_36,0x4000000);
  *param_2 = unaff_D7;
  return;
}


// ==== sduckdrv @ 8000830e

void sduckdrv(undefined1 param_1)

{
  switch(param_1) {
  case 8:
  case 9:
  case 0xc:
  case 0xd:
    break;
  default:
  }
  return;
}


// ==== spfled @ 80008348

void spfled(undefined4 param_1)

{
  devtrp(9,param_1);
  return;
}


// ==== spfledoff @ 8000835e

void spfledoff(void)

{
  devtrp(10);
  return;
}


// ==== rq8creat @ 80008370

void rq8creat(undefined1 param_1,undefined4 param_2,ushort param_3,undefined4 param_4,
             undefined4 *param_5)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36 [2];
  undefined1 local_34;
  undefined1 auStack_32 [28];
  uint local_16;
  undefined1 *local_8;
  
  local_36[0] = 1;
  local_34 = param_1;
  cpyast(param_2,auStack_32);
  local_16 = (uint)param_3;
  local_8 = local_3a;
  mailnwai(0x32,5,local_36,0x4000000);
  *param_5 = unaff_D7;
  return;
}


// ==== rq8_open @ 800083d4

void rq8_open(undefined1 param_1,undefined4 param_2,undefined4 param_3,undefined4 *param_4)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36 [2];
  undefined1 local_34;
  undefined1 auStack_32 [42];
  undefined1 *local_8;
  
  local_36[0] = 2;
  local_34 = param_1;
  local_8 = local_3a;
  cpyast(param_2,auStack_32);
  mailnwai(0x32,5,local_36,0x4000000);
  *param_4 = unaff_D7;
  return;
}


// ==== rq8_clos @ 80008428

void rq8_clos(undefined2 param_1,undefined4 *param_2)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36 [36];
  undefined2 local_12;
  undefined1 *local_8;
  
  local_36[0] = 3;
  local_12 = param_1;
  local_8 = local_3a;
  mailnwai(0x32,5,local_36,0x4000000);
  *param_2 = unaff_D7;
  return;
}


// ==== rq8_read @ 80008468

void rq8_read(undefined2 param_1,undefined4 param_2,undefined4 param_3,undefined4 *param_4)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36 [32];
  undefined4 local_16;
  undefined2 local_12;
  undefined4 local_c;
  undefined1 *local_8;
  
  local_36[0] = 4;
  local_12 = param_1;
  local_16 = param_2;
  local_c = param_3;
  local_8 = local_3a;
  mailnwai(0x32,5,local_36,0x4000000);
  *param_4 = unaff_D7;
  return;
}


// ==== rq8write @ 800084b4

void rq8write(undefined2 param_1,undefined4 param_2,undefined4 param_3,undefined4 *param_4)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36 [32];
  undefined4 local_16;
  undefined2 local_12;
  undefined4 local_c;
  undefined1 *local_8;
  
  local_36[0] = 5;
  local_12 = param_1;
  local_16 = param_2;
  local_c = param_3;
  local_8 = local_3a;
  mailnwai(0x32,5,local_36,0x4000000);
  *param_4 = unaff_D7;
  return;
}


// ==== rq8delet @ 80008500

void rq8delet(undefined1 param_1,undefined4 param_2,undefined4 *param_3)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36 [2];
  undefined1 local_34;
  undefined1 auStack_32 [42];
  undefined1 *local_8;
  
  local_36[0] = 6;
  local_34 = param_1;
  cpyast(param_2,auStack_32);
  local_8 = local_3a;
  mailnwai(0x32,5,local_36,0x4000000);
  *param_3 = unaff_D7;
  return;
}


// ==== rq8resum @ 80008554

void rq8resum(undefined1 param_1,undefined2 param_2,undefined4 *param_3)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36 [2];
  undefined1 local_34;
  undefined2 local_1a;
  undefined1 *local_8;
  
  local_36[0] = 7;
  local_34 = param_1;
  local_1a = param_2;
  local_8 = local_3a;
  mailnwai(0x32,5,local_36,0x4000000);
  *param_3 = unaff_D7;
  return;
}


// ==== rq8renam @ 8000859c

void rq8renam(undefined1 param_1,undefined4 param_2,undefined4 param_3,undefined4 *param_4)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36 [2];
  undefined1 local_34;
  undefined1 auStack_32 [12];
  undefined1 auStack_26 [30];
  undefined1 *local_8;
  
  local_36[0] = 8;
  local_34 = param_1;
  cpyast(param_2,auStack_32);
  cpyast(param_3,auStack_26);
  local_8 = local_3a;
  mailnwai(0x32,5,local_36,0x4000000);
  *param_4 = unaff_D7;
  return;
}


// ==== rq8mount @ 80008600

void rq8mount(undefined1 param_1,undefined4 *param_2)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36 [2];
  undefined1 local_34;
  undefined1 *local_8;
  
  local_36[0] = 9;
  local_34 = param_1;
  local_8 = local_3a;
  mailnwai(0x32,5,local_36,0x4000000);
  *param_2 = unaff_D7;
  return;
}


// ==== rq8demnt @ 80008640

void rq8demnt(undefined1 param_1,undefined4 *param_2)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36 [2];
  undefined1 local_34;
  undefined1 *local_8;
  
  local_36[0] = 10;
  local_34 = param_1;
  local_8 = local_3a;
  mailnwai(0x32,5,local_36,0x4000000);
  *param_2 = unaff_D7;
  return;
}


// ==== rq8sghdr @ 80008680

void rq8sghdr(undefined1 param_1,undefined4 param_2,undefined4 *param_3)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36 [2];
  undefined1 local_34;
  undefined4 local_c;
  undefined1 *local_8;
  
  local_36[0] = 0xb;
  local_34 = param_1;
  local_c = param_2;
  local_8 = local_3a;
  mailnwai(0x32,5,local_36,0x4000000);
  *param_3 = unaff_D7;
  return;
}


// ==== rq8_srch @ 800086c6

void rq8_srch(undefined1 param_1,undefined4 param_2,undefined4 *param_3)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36 [2];
  undefined1 local_34;
  undefined1 auStack_32 [42];
  undefined1 *local_8;
  
  local_36[0] = 0xc;
  local_34 = param_1;
  cpyast(param_2,auStack_32);
  local_8 = local_3a;
  mailnwai(0x32,5,local_36,0x4000000);
  *param_3 = unaff_D7;
  return;
}


// ==== rq8_dire @ 8000871a

void rq8_dire(undefined1 param_1,undefined2 param_2,undefined2 param_3,undefined4 param_4,
             undefined4 *param_5)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36 [2];
  undefined1 local_34;
  undefined2 local_1a;
  undefined2 local_18;
  undefined4 local_c;
  undefined1 *local_8;
  
  local_36[0] = 0xd;
  local_34 = param_1;
  local_1a = param_2;
  local_18 = param_3;
  local_c = param_4;
  local_8 = local_3a;
  mailnwai(0x32,5,local_36,0x4000000);
  *param_5 = unaff_D7;
  return;
}


// ==== rq8_rxb @ 80008770

void rq8_rxb(undefined1 param_1,undefined2 param_2,undefined2 param_3,ushort param_4,
            undefined4 param_5,undefined4 *param_6)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36 [2];
  undefined1 local_34;
  undefined2 local_1a;
  undefined2 local_18;
  uint local_16;
  undefined4 local_c;
  undefined1 *local_8;
  
  local_36[0] = 0xe;
  local_34 = param_1;
  local_1a = param_2;
  local_18 = param_3;
  local_16 = (uint)param_4;
  local_c = param_5;
  local_8 = local_3a;
  mailnwai(0x32,5,local_36,0x4000000);
  *param_6 = unaff_D7;
  return;
}


// ==== rq8_wxb @ 800087d8

void rq8_wxb(undefined1 param_1,undefined2 param_2,undefined2 param_3,ushort param_4,
            undefined4 param_5,undefined4 *param_6)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36 [2];
  undefined1 local_34;
  undefined2 local_1a;
  undefined2 local_18;
  uint local_16;
  undefined4 local_c;
  undefined1 *local_8;
  
  local_36[0] = 0xf;
  local_34 = param_1;
  local_1a = param_2;
  local_18 = param_3;
  local_16 = (uint)param_4;
  local_c = param_5;
  local_8 = local_3a;
  mailnwai(0x32,5,local_36,0x4000000);
  *param_6 = unaff_D7;
  return;
}


// ==== rq8remai @ 80008840

void rq8remai(undefined1 param_1,undefined4 *param_2)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36 [2];
  undefined1 local_34;
  undefined1 *local_8;
  
  local_36[0] = 0x10;
  local_34 = param_1;
  local_8 = local_3a;
  mailnwai(0x32,5,local_36,0x4000000);
  *param_2 = unaff_D7;
  return;
}


// ==== rq8gtvol @ 80008880

void rq8gtvol(undefined1 param_1,undefined4 param_2,undefined4 *param_3)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36 [2];
  undefined1 local_34;
  undefined4 local_c;
  undefined1 *local_8;
  
  local_36[0] = 0x11;
  local_34 = param_1;
  local_c = param_2;
  local_8 = local_3a;
  mailnwai(0x32,5,local_36,0x4000000);
  *param_3 = unaff_D7;
  return;
}


// ==== rq8ptvol @ 800088c6

void rq8ptvol(undefined1 param_1,undefined4 param_2,undefined4 *param_3)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36 [2];
  undefined1 local_34;
  undefined4 local_c;
  undefined1 *local_8;
  
  local_36[0] = 0x12;
  local_34 = param_1;
  local_c = param_2;
  local_8 = local_3a;
  mailnwai(0x32,5,local_36,0x4000000);
  *param_3 = unaff_D7;
  return;
}


// ==== rq8_kind @ 8000890c

void rq8_kind(undefined1 param_1,undefined4 *param_2)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36 [2];
  undefined1 local_34;
  undefined1 *local_8;
  
  local_36[0] = 0x13;
  local_34 = param_1;
  local_8 = local_3a;
  mailnwai(0x32,5,local_36,0x4000000);
  *param_2 = unaff_D7;
  return;
}


// ==== rq8_init @ 8000894c

void rq8_init(undefined1 param_1,char param_2,byte param_3,undefined4 param_4,undefined4 *param_5)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36 [2];
  undefined1 local_34;
  short local_1a;
  uint local_16;
  undefined4 local_c;
  undefined1 *local_8;
  
  local_36[0] = 0x14;
  local_34 = param_1;
  local_1a = (short)param_2;
  local_16 = (uint)param_3;
  local_c = param_4;
  local_8 = local_3a;
  mailnwai(0x32,5,local_36,0x4000000);
  *param_5 = unaff_D7;
  return;
}


// ==== rq8_pack @ 800089a8

void rq8_pack(undefined1 param_1,undefined4 *param_2)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36 [2];
  undefined1 local_34;
  undefined1 *local_8;
  
  local_36[0] = 0x15;
  local_34 = param_1;
  local_8 = local_3a;
  mailnwai(0x32,5,local_36,0x4000000);
  *param_2 = unaff_D7;
  return;
}


// ==== rq8_fcpy @ 800089e8

void rq8_fcpy(undefined1 param_1,undefined4 param_2,undefined1 param_3,undefined4 param_4,
             undefined4 *param_5)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36 [2];
  undefined1 local_34;
  undefined1 local_33;
  undefined1 auStack_32 [12];
  undefined1 auStack_26 [30];
  undefined1 *local_8;
  
  local_36[0] = 0x19;
  local_34 = param_1;
  cpyast(param_2,auStack_32);
  local_33 = param_3;
  cpyast(param_4,auStack_26);
  local_8 = local_3a;
  mailnwai(0x32,5,local_36,0x4000000);
  *param_5 = unaff_D7;
  return;
}


// ==== rq8volcp @ 80008a54

void rq8volcp(undefined1 param_1,undefined1 param_2,undefined4 *param_3)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36 [2];
  undefined1 local_34;
  undefined1 local_33;
  undefined1 *local_8;
  
  local_36[0] = 0x17;
  local_34 = param_1;
  local_33 = param_2;
  local_8 = local_3a;
  mailnwai(0x32,5,local_36,0x4000000);
  *param_3 = unaff_D7;
  return;
}


// ==== rq8dstat @ 80008a9c

void rq8dstat(undefined1 param_1,undefined4 *param_2)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36 [2];
  undefined1 local_34;
  undefined1 *local_8;
  
  local_36[0] = 0x18;
  local_34 = param_1;
  local_8 = local_3a;
  mailnwai(0x32,5,local_36,0x4000000);
  *param_2 = unaff_D7;
  return;
}


// ==== rq8rdsct @ 80008adc

void rq8rdsct(undefined1 param_1,undefined2 param_2,undefined2 param_3,undefined2 param_4,
             undefined4 param_5,undefined4 param_6,undefined4 *param_7)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36 [2];
  undefined1 local_34;
  undefined2 local_1a;
  undefined2 local_18;
  undefined4 local_16;
  undefined2 local_12;
  undefined4 local_c;
  undefined1 *local_8;
  
  local_36[0] = 0x1a;
  local_34 = param_1;
  local_12 = param_2;
  local_1a = param_3;
  local_18 = param_4;
  local_c = param_6;
  local_16 = param_5;
  local_8 = local_3a;
  mailnwai(0x32,5,local_36,0x4000000);
  *param_7 = unaff_D7;
  return;
}


// ==== rq8wrsct @ 80008b40

void rq8wrsct(undefined1 param_1,undefined2 param_2,undefined2 param_3,undefined2 param_4,
             undefined4 param_5,undefined4 param_6,undefined4 *param_7)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36 [2];
  undefined1 local_34;
  undefined2 local_1a;
  undefined2 local_18;
  undefined4 local_16;
  undefined2 local_12;
  undefined4 local_c;
  undefined1 *local_8;
  
  local_36[0] = 0x1b;
  local_34 = param_1;
  local_12 = param_2;
  local_1a = param_3;
  local_18 = param_4;
  local_c = param_6;
  local_16 = param_5;
  local_8 = local_3a;
  mailnwai(0x32,5,local_36,0x4000000);
  *param_7 = unaff_D7;
  return;
}


// ==== rq8dcnfg @ 80008ba4

void rq8dcnfg(undefined1 param_1,undefined4 *param_2)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36 [2];
  undefined1 local_34;
  undefined1 *local_8;
  
  local_36[0] = 0x1d;
  local_34 = param_1;
  local_8 = local_3a;
  mailnwai(0x32,5,local_36,0x4000000);
  *param_2 = unaff_D7;
  return;
}


// ==== dirtofnm @ 80008be4

void dirtofnm(ushort param_1,int param_2,int param_3)

{
  undefined1 auStack_8 [4];
  
  if ((param_1 == 3) || (((3 < param_1 && (param_1 != 0x81)) && (param_1 == 0x83)))) {
    rad50toa(*(undefined2 *)(param_2 + 2),param_3);
    rad50toa(*(undefined2 *)(param_2 + 4));
    fill();
    rad50toa(*(undefined2 *)(param_2 + 6),auStack_8);
    cpydata(auStack_8,param_3 + 8,3);
  }
  else {
    cpybuf(param_2,param_3,0xb);
  }
  isdelfil(param_1,param_2);
  return;
}


// ==== mkdoserr @ 80008cb4

uint mkdoserr(undefined1 param_1,uint param_2)

{
  undefined4 in_D0;
  
  if ((int)param_2 < 0) {
    param_2 = CONCAT31((int3)((uint)in_D0 >> 8),param_1) & 0xffff | param_2 << 0x10;
  }
  return param_2;
}


// ==== dosstt @ 80008cd2

int dosstt(int param_1)

{
  int iVar1;
  
  iVar1 = param_1 >> 0x10;
  if (-1 < param_1) {
    iVar1 = param_1;
  }
  return iVar1;
}


// ==== doserr @ 80008ce8

void doserr(void)

{
  return;
}


// ==== errdrive @ 80008cf6

void errdrive(void)

{
  return;
}


// ==== isdelfil @ 80008d04

undefined4 isdelfil(ushort param_1,ushort *param_2)

{
  if (param_1 == 3) {
LAB_80008d38:
    if ((*param_2 & 0x200) == 0) {
      return 0;
    }
  }
  else {
    if (param_1 < 4) {
      if ((param_1 != 1) && (param_1 == 2)) {
        if (*(char *)((int)param_2 + 0xb) < '\0') {
          return 1;
        }
        return 0;
      }
    }
    else if ((param_1 != 0x81) && (param_1 == 0x83)) goto LAB_80008d38;
    if (*(char *)((int)param_2 + 7) != '@') {
      return 0;
    }
  }
  return 1;
}


// ==== putfnam @ 80008d64

char putfnam(char *param_1,char *param_2)

{
  char cVar1;
  int iVar2;
  char *pcVar3;
  char *pcVar4;
  char *pcVar5;
  
  iVar2 = 0;
  pcVar4 = param_2;
  do {
    pcVar3 = pcVar4;
    pcVar5 = param_1;
    if ((*param_1 == '.') || (*param_1 == '\0')) break;
    pcVar5 = param_1 + 1;
    pcVar3 = pcVar4 + 1;
    *pcVar4 = *param_1;
    iVar2 = iVar2 + 1;
    pcVar4 = pcVar3;
    param_1 = pcVar5;
  } while (iVar2 < 8);
  for (; iVar2 < 8; iVar2 = iVar2 + 1) {
    *pcVar3 = ' ';
    pcVar3 = pcVar3 + 1;
  }
  if (*pcVar5 == '.') {
    pcVar5 = pcVar5 + 1;
  }
  iVar2 = 0;
  pcVar4 = param_2 + 8;
  do {
    cVar1 = *pcVar5;
    pcVar3 = pcVar4;
    if (cVar1 == '\0') break;
    cVar1 = *pcVar5;
    pcVar3 = pcVar4 + 1;
    *pcVar4 = cVar1;
    iVar2 = iVar2 + 1;
    pcVar4 = pcVar3;
    pcVar5 = pcVar5 + 1;
  } while (iVar2 < 3);
  for (; iVar2 < 3; iVar2 = iVar2 + 1) {
    *pcVar3 = ' ';
    pcVar3 = pcVar3 + 1;
  }
  return cVar1;
}


// ==== slvfnam @ 80008dcc

void slvfnam(char *param_1,char *param_2)

{
  ushort uVar1;
  char *pcVar2;
  char *pcVar3;
  char *pcVar4;
  
  uVar1 = 0;
  pcVar2 = param_1;
  do {
    pcVar3 = param_2;
    if (*pcVar2 == ' ') break;
    pcVar3 = param_2 + 1;
    *param_2 = *pcVar2;
    uVar1 = uVar1 + 1;
    pcVar2 = pcVar2 + 1;
    param_2 = pcVar3;
  } while (uVar1 < 8);
  *pcVar3 = '.';
  uVar1 = 0;
  pcVar2 = param_1 + 8;
  pcVar3 = pcVar3 + 1;
  do {
    pcVar4 = pcVar3;
    if (*pcVar2 == ' ') break;
    pcVar4 = pcVar3 + 1;
    *pcVar3 = *pcVar2;
    uVar1 = uVar1 + 1;
    pcVar2 = pcVar2 + 1;
    pcVar3 = pcVar4;
  } while (uVar1 < 3);
  *pcVar4 = '\0';
  return;
}


// ==== undelfnm @ 80008e18

void undelfnm(int param_1)

{
  int iVar1;
  char *pcVar2;
  
  pcVar2 = (char *)(param_1 + 6);
  iVar1 = 0;
  do {
    pcVar2 = pcVar2 + -1;
    if (*pcVar2 != '_') break;
    *pcVar2 = ' ';
    iVar1 = iVar1 + 1;
  } while (iVar1 < 5);
  *(undefined1 *)(param_1 + 6) = 0x20;
  *(undefined1 *)(param_1 + 7) = 0x20;
  return;
}


// ==== whichdos @ 80008e4c

undefined4 whichdos(ushort param_1)

{
  undefined4 uVar1;
  
  if ((param_1 < 4) || (5 < param_1)) {
    if ((param_1 < 6) || (7 < param_1)) {
      if ((param_1 < 8) || (9 < param_1)) {
        if ((param_1 < 0xc) || (0xd < param_1)) {
          if (param_1 == 0x10) {
            uVar1 = 4;
          }
          else if (param_1 == 0x11) {
            uVar1 = 5;
          }
          else {
            uVar1 = 1;
          }
        }
        else {
          uVar1 = 0x83;
        }
      }
      else {
        uVar1 = 0x81;
      }
    }
    else {
      uVar1 = 2;
    }
  }
  else {
    uVar1 = 3;
  }
  return uVar1;
}


// ==== cpydata @ 80008eb8

void cpydata(undefined1 *param_1,undefined1 *param_2,int param_3)

{
  int iVar1;
  
  iVar1 = 0;
  if (0 < param_3) {
    do {
      *param_2 = *param_1;
      iVar1 = iVar1 + 1;
      param_1 = param_1 + 1;
      param_2 = param_2 + 1;
    } while (iVar1 < param_3);
  }
  return;
}


// ==== cpydataba @ 80008edc

void cpydataba(int param_1,int param_2,int param_3)

{
  int iVar1;
  undefined1 *puVar2;
  undefined1 *puVar3;
  
  puVar3 = (undefined1 *)(param_3 + param_2);
  puVar2 = (undefined1 *)(param_3 + param_1);
  iVar1 = 0;
  if (0 < param_3) {
    do {
      puVar3 = puVar3 + -1;
      puVar2 = puVar2 + -1;
      *puVar3 = *puVar2;
      iVar1 = iVar1 + 1;
    } while (iVar1 < param_3);
  }
  return;
}


// ==== rad50toa @ 80008f0c

undefined4 rad50toa(ushort param_1,char *param_2)

{
  char cVar1;
  undefined3 uVar2;
  undefined4 uVar3;
  char cVar4;
  char local_8 [4];
  
  local_8[0] = (char)((param_1 / 0x28) / 0x28);
  local_8[1] = (char)((param_1 / 0x28) % 0x28);
  local_8[2] = (char)(param_1 % 0x28);
  cVar4 = '\0';
  do {
    uVar2 = (undefined3)((uint)(int)cVar4 >> 8);
    uVar3 = CONCAT31(uVar2,local_8[cVar4]);
    if (local_8[cVar4] == '\0') {
      *param_2 = ' ';
    }
    else if ((local_8[cVar4] < '\x01') || ('\x1a' < local_8[cVar4])) {
      uVar3 = CONCAT31((int3)((uint)(int)cVar4 >> 8),local_8[cVar4]);
      if (local_8[cVar4] == '\x1b') {
        *param_2 = '$';
      }
      else {
        uVar2 = (undefined3)((uint)(int)cVar4 >> 8);
        uVar3 = CONCAT31(uVar2,local_8[cVar4]);
        if (local_8[cVar4] == '\x1c') {
          *param_2 = '.';
        }
        else {
          cVar1 = local_8[cVar4];
          if ((cVar1 < '\x1e') || (cVar1 = local_8[cVar4], '\'' < cVar1)) {
            uVar3 = CONCAT31(uVar2,cVar1);
            *param_2 = '\x1d';
          }
          else {
            uVar3 = CONCAT31(uVar2,local_8[cVar4] + '\x12');
            *param_2 = local_8[cVar4] + '\x12';
          }
        }
      }
    }
    else {
      uVar3 = CONCAT31(uVar2,local_8[cVar4] + '@');
      *param_2 = local_8[cVar4] + '@';
    }
    param_2 = param_2 + 1;
    cVar4 = cVar4 + '\x01';
  } while (cVar4 < '\x03');
  *param_2 = '\0';
  return uVar3;
}


// ==== loader @ 80008fec

void loader(undefined1 param_1,undefined4 param_2,undefined1 param_3,undefined1 param_4,
           undefined1 param_5)

{
  uint unaff_D7;
  undefined1 local_1e [2];
  undefined1 local_1c;
  undefined1 local_1b;
  undefined1 local_1a;
  undefined1 local_19;
  undefined1 auStack_18 [16];
  undefined1 *local_8;
  
  local_1c = param_1;
  local_1b = param_3;
  local_1a = param_4;
  local_19 = param_5;
  cpybuf(param_2,auStack_18,0);
  local_8 = local_1e;
  semsg(0x18,0xd,&local_1c);
  do {
    wait((void *)0x0);
  } while ((unaff_D7 & 0x4000000) == 0);
  return;
}


// ==== cpybuf @ 80009060

uint cpybuf(uint *param_1,uint *param_2,int param_3)

{
  uint uVar1;
  ushort uVar2;
  short sVar3;
  uint *puVar4;
  uint *puVar5;
  uint *puVar6;
  uint *puVar7;
  
  if (param_3 == 0) {
    if (*(char *)param_1 == '\0') {
      return 0;
    }
    do {
      puVar4 = (uint *)((int)param_1 + 1);
      *(undefined1 *)param_2 = *(undefined1 *)param_1;
      param_1 = puVar4;
      param_2 = (uint *)((int)param_2 + 1);
    } while (*(char *)puVar4 != '\0');
    return 0;
  }
  uVar1 = (uint)param_2 & 3 | ((uint)param_1 & 3) << 4;
  puVar4 = param_1;
  puVar6 = param_2;
  switch(uVar1) {
  case 0:
    for (; 0x1f < param_3; param_3 = param_3 + -0x20) {
      *param_2 = *param_1;
      param_2[1] = param_1[1];
      param_2[2] = param_1[2];
      param_2[3] = param_1[3];
      param_2[4] = param_1[4];
      param_2[5] = param_1[5];
      param_2[6] = param_1[6];
      param_2[7] = param_1[7];
      param_2 = param_2 + 8;
      param_1 = param_1 + 8;
    }
    for (; 0xf < param_3; param_3 = param_3 + -0x10) {
      *param_2 = *param_1;
      param_2[1] = param_1[1];
      param_2[2] = param_1[2];
      param_2[3] = param_1[3];
      param_2 = param_2 + 4;
      param_1 = param_1 + 4;
    }
    for (; 3 < param_3; param_3 = param_3 + -4) {
      uVar1 = *param_1;
      *param_2 = uVar1;
      param_1 = param_1 + 1;
      param_2 = param_2 + 1;
    }
    if ((param_3 != 0) && (param_3 = param_3 + -1, param_3 != -1)) {
      do {
        do {
          puVar4 = (uint *)((int)param_1 + 1);
          uVar1 = (uint)*(byte *)param_1;
          puVar6 = (uint *)((int)param_2 + 1);
          *(byte *)param_2 = *(byte *)param_1;
          uVar2 = (ushort)((uint)param_3 >> 0x10);
          sVar3 = (short)param_3 + -1;
          param_3 = CONCAT22(uVar2,sVar3);
          param_1 = puVar4;
          param_2 = puVar6;
        } while (sVar3 != -1);
        param_3 = (uint)uVar2 * 0x10000 + -1;
      } while (uVar2 != 0);
    }
    break;
  case 1:
  case 3:
  case 0x10:
  case 0x12:
  case 0x21:
  case 0x23:
  case 0x30:
  case 0x32:
    param_3 = param_3 + -1;
    if (param_3 != -1) {
      do {
        do {
          puVar4 = (uint *)((int)param_1 + 1);
          uVar1 = (uint)*(byte *)param_1;
          puVar6 = (uint *)((int)param_2 + 1);
          *(byte *)param_2 = *(byte *)param_1;
          uVar2 = (ushort)((uint)param_3 >> 0x10);
          sVar3 = (short)param_3 + -1;
          param_3 = CONCAT22(uVar2,sVar3);
          param_1 = puVar4;
          param_2 = puVar6;
        } while (sVar3 != -1);
        param_3 = (uint)uVar2 * 0x10000 + -1;
      } while (uVar2 != 0);
    }
    break;
  case 2:
  case 0x20:
  case 0x22:
    for (; 0xf < param_3; param_3 = param_3 + -0x10) {
      *(ushort *)puVar6 = *(ushort *)puVar4;
      *(ushort *)((int)puVar6 + 2) = (ushort)*puVar4;
      *(ushort *)(puVar6 + 1) = *(ushort *)(puVar4 + 1);
      *(ushort *)((int)puVar6 + 6) = *(ushort *)((int)puVar4 + 6);
      *(ushort *)(puVar6 + 2) = *(ushort *)(puVar4 + 2);
      *(ushort *)((int)puVar6 + 10) = *(ushort *)((int)puVar4 + 10);
      *(ushort *)(puVar6 + 3) = *(ushort *)(puVar4 + 3);
      *(ushort *)((int)puVar6 + 0xe) = *(ushort *)((int)puVar4 + 0xe);
      puVar6 = puVar6 + 4;
      puVar4 = puVar4 + 4;
    }
    for (; 7 < param_3; param_3 = param_3 + -8) {
      *(ushort *)puVar6 = *(ushort *)puVar4;
      *(ushort *)((int)puVar6 + 2) = (ushort)*puVar4;
      *(ushort *)(puVar6 + 1) = *(ushort *)(puVar4 + 1);
      *(ushort *)((int)puVar6 + 6) = *(ushort *)((int)puVar4 + 6);
      puVar6 = puVar6 + 2;
      puVar4 = puVar4 + 2;
    }
    for (; 1 < param_3; param_3 = param_3 + -2) {
      uVar1 = (uint)*(ushort *)puVar4;
      *(ushort *)puVar6 = *(ushort *)puVar4;
      puVar4 = (uint *)((int)puVar4 + 2);
      puVar6 = (uint *)((int)puVar6 + 2);
    }
    goto LAB_800092a2;
  case 0x11:
  case 0x13:
  case 0x31:
    puVar4 = (uint *)((int)param_1 + 1);
    uVar1 = (uint)*(byte *)param_1;
    puVar6 = (uint *)((int)param_2 + 1);
    *(byte *)param_2 = *(byte *)param_1;
    for (param_3 = param_3 + -1; 0xf < param_3; param_3 = param_3 + -0x10) {
      *(ushort *)puVar6 = *(ushort *)puVar4;
      *(ushort *)((int)puVar6 + 2) = (ushort)*puVar4;
      *(ushort *)(puVar6 + 1) = *(ushort *)(puVar4 + 1);
      *(ushort *)((int)puVar6 + 6) = *(ushort *)((int)puVar4 + 6);
      *(ushort *)(puVar6 + 2) = *(ushort *)(puVar4 + 2);
      *(ushort *)((int)puVar6 + 10) = *(ushort *)((int)puVar4 + 10);
      *(ushort *)(puVar6 + 3) = *(ushort *)(puVar4 + 3);
      *(ushort *)((int)puVar6 + 0xe) = *(ushort *)((int)puVar4 + 0xe);
      puVar6 = puVar6 + 4;
      puVar4 = puVar4 + 4;
    }
    for (; 7 < param_3; param_3 = param_3 + -8) {
      *(ushort *)puVar6 = *(ushort *)puVar4;
      *(ushort *)((int)puVar6 + 2) = (ushort)*puVar4;
      *(ushort *)(puVar6 + 1) = *(ushort *)(puVar4 + 1);
      *(ushort *)((int)puVar6 + 6) = *(ushort *)((int)puVar4 + 6);
      puVar6 = puVar6 + 2;
      puVar4 = puVar4 + 2;
    }
    for (; 1 < param_3; param_3 = param_3 + -2) {
      uVar1 = (uint)*(ushort *)puVar4;
      *(ushort *)puVar6 = *(ushort *)puVar4;
      puVar4 = (uint *)((int)puVar4 + 2);
      puVar6 = (uint *)((int)puVar6 + 2);
    }
LAB_800092a2:
    if (param_3 != 0) {
      uVar1 = (uint)*(byte *)puVar4;
      *(byte *)puVar6 = *(byte *)puVar4;
    }
    break;
  case 0x33:
    puVar4 = (uint *)((int)param_1 + 1);
    uVar1 = (uint)*(byte *)param_1;
    puVar6 = (uint *)((int)param_2 + 1);
    *(byte *)param_2 = *(byte *)param_1;
    for (param_3 = param_3 + -1; 0x1f < param_3; param_3 = param_3 + -0x20) {
      *puVar6 = *puVar4;
      puVar6[1] = puVar4[1];
      puVar6[2] = puVar4[2];
      puVar6[3] = puVar4[3];
      puVar6[4] = puVar4[4];
      puVar6[5] = puVar4[5];
      puVar6[6] = puVar4[6];
      puVar6[7] = puVar4[7];
      puVar6 = puVar6 + 8;
      puVar4 = puVar4 + 8;
    }
    for (; 0xf < param_3; param_3 = param_3 + -0x10) {
      *puVar6 = *puVar4;
      puVar6[1] = puVar4[1];
      puVar6[2] = puVar4[2];
      puVar6[3] = puVar4[3];
      puVar6 = puVar6 + 4;
      puVar4 = puVar4 + 4;
    }
    for (; 3 < param_3; param_3 = param_3 + -4) {
      uVar1 = *puVar4;
      *puVar6 = uVar1;
      puVar4 = puVar4 + 1;
      puVar6 = puVar6 + 1;
    }
    if ((param_3 != 0) && (param_3 = param_3 + -1, param_3 != -1)) {
      do {
        do {
          puVar5 = (uint *)((int)puVar4 + 1);
          uVar1 = (uint)*(byte *)puVar4;
          puVar7 = (uint *)((int)puVar6 + 1);
          *(byte *)puVar6 = *(byte *)puVar4;
          uVar2 = (ushort)((uint)param_3 >> 0x10);
          sVar3 = (short)param_3 + -1;
          param_3 = CONCAT22(uVar2,sVar3);
          puVar4 = puVar5;
          puVar6 = puVar7;
        } while (sVar3 != -1);
        param_3 = (uint)uVar2 * 0x10000 + -1;
      } while (uVar2 != 0);
    }
  }
  return uVar1;
}


// ==== fill @ 8000934c

uint fill(uint *param_1,int param_2,undefined1 param_3)

{
  uint uVar1;
  
  uVar1 = (uint)param_1 & 3;
  if (uVar1 != 0) {
    for (; (param_2 != 0 && (uVar1 = (uint)param_1 & 3, uVar1 != 0));
        param_1 = (uint *)((int)param_1 + 1)) {
      *(undefined1 *)param_1 = param_3;
      param_2 = param_2 + -1;
    }
  }
  if (3 < param_2) {
    uVar1 = CONCAT13(param_3,CONCAT12(param_3,CONCAT11(param_3,param_3)));
    for (; 0x1f < param_2; param_2 = param_2 + -0x20) {
      *param_1 = uVar1;
      param_1[1] = uVar1;
      param_1[2] = uVar1;
      param_1[3] = uVar1;
      param_1[4] = uVar1;
      param_1[5] = uVar1;
      param_1[6] = uVar1;
      param_1[7] = uVar1;
      param_1 = param_1 + 8;
    }
    for (; 0xf < param_2; param_2 = param_2 + -0x10) {
      *param_1 = uVar1;
      param_1[1] = uVar1;
      param_1[2] = uVar1;
      param_1[3] = uVar1;
      param_1 = param_1 + 4;
    }
    for (; 3 < param_2; param_2 = param_2 + -4) {
      *param_1 = uVar1;
      param_1 = param_1 + 1;
    }
  }
  for (; param_2 != 0; param_2 = param_2 + -1) {
    *(undefined1 *)param_1 = param_3;
    param_1 = (uint *)((int)param_1 + 1);
  }
  return uVar1;
}


// ==== cpyast @ 80009408

void cpyast(char *param_1,char *param_2)

{
  char cVar1;
  
  do {
    cVar1 = *param_1;
    *param_2 = cVar1;
    param_2 = param_2 + 1;
    param_1 = param_1 + 1;
  } while (cVar1 != '\0');
  return;
}


// ==== cmpbuf @ 80009428

void cmpbuf(char *param_1,char *param_2,int param_3)

{
  while( true ) {
    if (param_3 == 0) {
      return;
    }
    if (*param_2 != *param_1) break;
    param_3 = param_3 + -1;
    param_1 = param_1 + 1;
    param_2 = param_2 + 1;
  }
  return;
}


// ==== cmpstr @ 80009450

char cmpstr(char *param_1,char *param_2)

{
  char cVar1;
  char cVar2;
  
  do {
    if (*param_1 == '\0') {
      return '\0';
    }
    cVar1 = *param_2;
    cVar2 = *param_1;
    param_1 = param_1 + 1;
    param_2 = param_2 + 1;
  } while (cVar1 == cVar2);
  return cVar1;
}


// ==== strcmp @ 80009474

int strcmp(char *__s1,char *__s2)

{
  int in_D0;
  
  while( true ) {
    if (*__s2 != *__s1) {
      return (uint)(byte)*__s2;
    }
    in_D0 = CONCAT31((int3)((uint)in_D0 >> 8),*__s1);
    if (*__s1 == 0) break;
    __s1 = __s1 + 1;
    __s2 = __s2 + 1;
  }
  return in_D0;
}


// ==== dsemsg @ 800094a8

void dsemsg(void)

{
  com1();
  return;
}


// ==== mapset @ 800094b0

void mapset(void)

{
  com1();
  return;
}


// ==== post @ 800094b8

void post(void)

{
  com1();
  return;
}


// ==== remsg @ 800094c0

void remsg(void)

{
  com1();
  return;
}


// ==== sbpeek @ 800094c8

void sbpeek(void)

{
  com1();
  return;
}


// ==== semsg @ 800094d0

void semsg(void)

{
  com1();
  return;
}


// ==== start @ 800094d8

void start(void)

{
  com1();
  return;
}


// ==== wait @ 800094e0

__pid_t wait(void *__stat_loc)

{
  __pid_t _Var1;
  
  _Var1 = com1();
  return _Var1;
}


// ==== wtmsg @ 800094e8

void wtmsg(void)

{
  com1();
  return;
}


// ==== devtrp @ 800094f0

void devtrp(void)

{
  com2();
  return;
}


// ==== com1 @ 800094f8

void com1(void)

{
  __m68k_trap(1);
  return;
}


// ==== com2 @ 80009500

void com2(void)

{
  __m68k_trap(2);
  return;
}


// ==== netsreq @ 80009508

void netsreq(int param_1,uint *param_2)

{
  uint unaff_D7;
  undefined1 local_8 [4];
  
  *(undefined1 **)(param_1 + 4) = local_8;
  mailnwai(0x18,7,param_1,0x8000000);
  *param_2 = *param_2 | unaff_D7;
  *param_2 = *param_2 & 0xf7ffffff;
  return;
}


// ==== netopen @ 80009550

void netopen(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  undefined4 local_1c [2];
  undefined4 local_14;
  undefined4 local_10;
  
  local_1c[0] = 3;
  local_14 = param_2;
  local_10 = param_3;
  netsreq(local_1c,param_4);
  return;
}


// ==== netclos @ 80009578

void netclos(short param_1,undefined4 param_2)

{
  undefined4 local_1c [2];
  int local_14;
  
  local_1c[0] = 6;
  local_14 = (int)param_1;
  netsreq(local_1c,param_2);
  return;
}


// ==== netread @ 8000959e

void netread(short param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  undefined4 local_1c [2];
  int local_14;
  undefined4 local_10;
  undefined4 local_c;
  
  local_1c[0] = 4;
  local_14 = (int)param_1;
  local_10 = param_2;
  local_c = param_3;
  netsreq(local_1c,param_4);
  return;
}


// ==== netwrite @ 800095d0

void netwrite(short param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  undefined4 local_1c [2];
  int local_14;
  undefined4 local_10;
  undefined4 local_c;
  
  local_1c[0] = 5;
  local_14 = (int)param_1;
  local_10 = param_2;
  local_c = param_3;
  netsreq(local_1c,param_4);
  return;
}


// ==== netseek @ 80009602

void netseek(short param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  undefined4 local_1c [2];
  int local_14;
  undefined4 local_10;
  undefined4 local_c;
  
  local_1c[0] = 7;
  local_14 = (int)param_1;
  local_10 = param_2;
  local_c = param_3;
  netsreq(local_1c,param_4);
  return;
}


// ==== netmount @ 80009634

void netmount(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  undefined4 local_1c [2];
  undefined4 local_14;
  
  local_1c[0] = 1;
  local_14 = param_2;
  netsreq(local_1c,param_3);
  return;
}


// ==== netdemnt @ 80009656

void netdemnt(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  undefined4 local_1c [2];
  undefined4 local_14;
  
  local_1c[0] = 2;
  local_14 = param_2;
  netsreq(local_1c,param_3);
  return;
}


// ==== netfstest @ 80009678

void netfstest(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
              undefined4 param_5)

{
  undefined4 local_1c [2];
  undefined4 local_14;
  undefined4 local_10;
  undefined4 local_c;
  undefined4 local_8;
  
  local_1c[0] = 9;
  local_10 = param_2;
  local_c = param_3;
  local_8 = param_4;
  local_14 = param_1;
  netsreq(local_1c,param_5);
  return;
}


// ==== netfrtest @ 800096ac

void netfrtest(undefined4 param_1,undefined4 param_2)

{
  undefined4 local_1c [5];
  undefined4 local_8;
  
  local_1c[0] = 10;
  local_8 = param_1;
  netsreq(local_1c,param_2);
  return;
}


// ==== netutime @ 800096ce

void netutime(undefined4 param_1,uint *param_2)

{
  uint unaff_D7;
  undefined4 local_1c;
  undefined4 local_18;
  
  local_1c = 8;
  local_18 = param_1;
  mailnwai(0x18,7,&local_1c,0x8000000);
  *param_2 = *param_2 | unaff_D7;
  return;
}


// ==== netnwopen @ 8000970a

void netnwopen(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
              undefined4 param_5)

{
  undefined4 local_1c;
  undefined4 local_18;
  undefined4 local_14;
  undefined4 local_10;
  
  local_1c = 3;
  local_14 = param_2;
  local_10 = param_3;
  local_18 = param_5;
  semsg(0x18,7,&local_1c);
  return;
}


// ==== netnwclos @ 8000973c

void netnwclos(short param_1,undefined4 param_2,undefined4 param_3)

{
  undefined4 local_1c;
  undefined4 local_18;
  int local_14;
  
  local_1c = 6;
  local_14 = (int)param_1;
  local_18 = param_3;
  semsg(0x18,7,&local_1c);
  return;
}


// ==== netnwread @ 8000976c

void netnwread(short param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
              undefined4 param_5)

{
  undefined4 local_1c;
  undefined4 local_18;
  int local_14;
  undefined4 local_10;
  undefined4 local_c;
  
  local_1c = 4;
  local_14 = (int)param_1;
  local_10 = param_2;
  local_c = param_3;
  local_18 = param_5;
  semsg(0x18,7,&local_1c);
  return;
}


// ==== netnwwrit @ 800097a8

void netnwwrit(short param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
              undefined4 param_5)

{
  undefined4 local_1c;
  undefined4 local_18;
  int local_14;
  undefined4 local_10;
  undefined4 local_c;
  
  local_1c = 5;
  local_14 = (int)param_1;
  local_10 = param_2;
  local_c = param_3;
  local_18 = param_5;
  semsg(0x18,7,&local_1c);
  return;
}


// ==== netnwseek @ 800097e4

void netnwseek(short param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
              undefined4 param_5)

{
  undefined4 local_1c;
  undefined4 local_18;
  int local_14;
  undefined4 local_10;
  undefined4 local_c;
  
  local_1c = 7;
  local_14 = (int)param_1;
  local_10 = param_2;
  local_c = param_3;
  local_18 = param_5;
  semsg(0x18,7,&local_1c);
  return;
}


// ==== netnwmoun @ 80009820

void netnwmoun(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  undefined4 local_1c;
  undefined4 local_18;
  undefined4 local_14;
  
  local_1c = 1;
  local_14 = param_2;
  local_18 = param_4;
  semsg(0x18,7,&local_1c);
  return;
}


// ==== netnwdemn @ 8000984c

void netnwdemn(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  undefined4 local_1c;
  undefined4 local_18;
  undefined4 local_14;
  
  local_1c = 2;
  local_14 = param_2;
  local_18 = param_4;
  semsg(0x18,7,&local_1c);
  return;
}


