// ==== FUN_80000024 @ 80000024

void FUN_80000024(undefined4 param_1)

{
  undefined4 unaff_D7;
  undefined1 auStack_8 [4];
  
  FUN_80000756(param_1,auStack_8);
  DAT_9000d9f0 = unaff_D7;
  return;
}


// ==== FUN_8000006c @ 8000006c

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_8000006c(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  int unaff_D7;
  int local_2e;
  uint local_e;
  
  FUN_8000050c(param_1,param_3,&DAT_900100e8);
  _DAT_900100ec = unaff_D7;
  if (-1 < unaff_D7) {
    FUN_80000532(param_1);
    if (-1 < unaff_D7) {
      FUN_8000050c(param_2,param_4,&DAT_900100e8);
      DAT_9000d9f0 = unaff_D7;
      if (unaff_D7 < 0) {
        local_2e = 0;
      }
      else {
        FUN_80000532(param_2);
        FUN_800003d4(param_2,param_4,&DAT_900100e8);
        FUN_800006d8(param_2,&DAT_900100e8);
      }
      FUN_8000060e(param_2,&DAT_900100e8);
      if (-1 < unaff_D7) {
        if ((uint)(local_2e + unaff_D7) < local_e) {
          _DAT_900100ec = CONCAT22(0xfff5,(short)unaff_D7);
          _DAT_900100ec = CONCAT31(_DAT_900100ec,(char)param_2);
        }
        else {
          _DAT_900100ec = 0;
        }
      }
    }
  }
  return;
}


// ==== FUN_80000174 @ 80000174

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_80000174(uint param_1,undefined4 param_2)

{
  uint uVar1;
  short sVar2;
  int unaff_D7;
  undefined1 auStack_2c [40];
  
  if ((param_1 == 8) || (param_1 == 9)) {
    sVar2 = (short)((uint)unaff_D7 >> 0x10);
    if (_DAT_90000060 == 0) {
      uVar1 = param_1 | DAT_90000064 << 0x10;
      FUN_80010f28(uVar1,0,0,0,auStack_2c,param_2);
      if ((sVar2 == -4) || (-1 < unaff_D7)) {
        FUN_80010b28(uVar1,param_2);
        if (-1 < unaff_D7) {
          return;
        }
        _DAT_90000060 = -1;
      }
    }
    for (DAT_90000064 = 0; DAT_90000064 < 0x1c; DAT_90000064 = DAT_90000064 + 1) {
      uVar1 = param_1 | DAT_90000064 << 0x10;
      if (DAT_90000064 == 0) {
        FUN_80010f28(uVar1,0,0,0,auStack_2c,param_2);
      }
      FUN_80010b28(uVar1,param_2);
      if (((sVar2 != -0x3f) && (sVar2 != -0x3e)) && (sVar2 != -0x40)) {
        if (unaff_D7 < 0) {
          return;
        }
        _DAT_90000060 = 0;
        return;
      }
    }
  }
  else {
    FUN_80010b28(param_1,param_2);
  }
  return;
}


// ==== FUN_80000294 @ 80000294

void FUN_80000294(uint param_1,undefined4 param_2)

{
  FUN_80010c08(param_1 | DAT_90000064 << 0x10,param_2);
  return;
}


// ==== FUN_800002b6 @ 800002b6

void FUN_800002b6(uint param_1,undefined4 param_2,undefined2 param_3,undefined4 param_4,
                 undefined4 param_5)

{
  FUN_80010264(param_1 | DAT_90000064 << 0x10,param_2,param_3,param_4,param_5);
  return;
}


// ==== FUN_800002ea @ 800002ea

void FUN_800002ea(uint param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  FUN_80010328(param_1 | DAT_90000064 << 0x10,param_2,param_3,param_4);
  return;
}


// ==== FUN_80000314 @ 80000314

void FUN_80000314(uint param_1,short param_2,undefined4 param_3)

{
  FUN_80010428(param_1 | DAT_90000064 << 0x10,(int)param_2,param_3);
  return;
}


// ==== FUN_8000033e @ 8000033e

void FUN_8000033e(uint param_1,short param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5)

{
  FUN_80010512(param_1 | DAT_90000064 << 0x10,(int)param_2,param_3,param_4,param_5);
  return;
}


// ==== FUN_80000370 @ 80000370

void FUN_80000370(uint param_1,short param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5)

{
  FUN_8001065e(param_1 | DAT_90000064 << 0x10,(int)param_2,param_3,param_4,param_5);
  return;
}


// ==== FUN_800003a2 @ 800003a2

void FUN_800003a2(uint param_1,short param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5)

{
  FUN_800107aa(param_1 | DAT_90000064 << 0x10,(int)param_2,param_3,param_4,param_5);
  return;
}


// ==== FUN_800003d4 @ 800003d4

void FUN_800003d4(uint param_1,undefined4 param_2,undefined4 param_3)

{
  undefined1 auStack_10 [12];
  
  FUN_8000040e(param_2,auStack_10);
  FUN_8001087c(param_1 | DAT_90000064 << 0x10,auStack_10,param_3);
  return;
}


// ==== FUN_8000040e @ 8000040e

void FUN_8000040e(int param_1,int param_2)

{
  bool bVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  
  bVar1 = false;
  iVar2 = 0;
  iVar3 = 0;
  do {
    if (*(char *)(param_1 + iVar2) == ' ') {
      bVar1 = true;
    }
    if (!bVar1) {
      *(undefined1 *)(param_2 + iVar3) = *(undefined1 *)(param_1 + iVar2);
      iVar3 = iVar3 + 1;
    }
    iVar2 = iVar2 + 1;
  } while (iVar2 < 8);
  *(undefined1 *)(param_2 + iVar3) = 0x2e;
  iVar3 = iVar3 + 1;
  iVar4 = 0;
  do {
    if (*(char *)(param_1 + iVar2) == ' ') break;
    *(undefined1 *)(param_2 + iVar3) = *(undefined1 *)(param_1 + iVar2);
    iVar3 = iVar3 + 1;
    iVar2 = iVar2 + 1;
    iVar4 = iVar4 + 1;
  } while (iVar4 < 3);
  *(undefined1 *)(param_2 + iVar3) = 0;
  return;
}


// ==== FUN_8000046a @ 8000046a

void FUN_8000046a(uint param_1,undefined4 param_2,undefined4 param_3)

{
  FUN_80010932(param_1 | DAT_90000064 << 0x10,param_2,param_3);
  return;
}


// ==== FUN_80000490 @ 80000490

void FUN_80000490(uint param_1,undefined2 param_2,undefined4 param_3)

{
  FUN_800109b8(param_1 | DAT_90000064 << 0x10,param_2,param_3);
  return;
}


// ==== FUN_800004bc @ 800004bc

void FUN_800004bc(uint param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  FUN_80010a64(param_1 | DAT_90000064 << 0x10,param_2,param_3,param_4);
  return;
}


// ==== FUN_800004e6 @ 800004e6

void FUN_800004e6(uint param_1,undefined4 param_2,undefined4 param_3)

{
  FUN_80010ce4(param_1 | DAT_90000064 << 0x10,param_2,param_3);
  return;
}


// ==== FUN_8000050c @ 8000050c

void FUN_8000050c(uint param_1,undefined4 param_2,undefined4 param_3)

{
  FUN_80010d6e(param_1 | DAT_90000064 << 0x10,param_2,param_3);
  return;
}


// ==== FUN_80000532 @ 80000532

void FUN_80000532(uint param_1,undefined2 param_2,undefined2 param_3,undefined4 param_4,
                 undefined4 param_5)

{
  FUN_80010e24(param_1 | DAT_90000064 << 0x10,param_2,param_3,param_4,param_5);
  return;
}


// ==== FUN_8000057a @ 8000057a

void FUN_8000057a(uint param_1,undefined2 param_2,undefined2 param_3,undefined2 param_4,
                 undefined4 param_5,undefined4 param_6)

{
  FUN_80010f28(param_1 | DAT_90000064 << 0x10,param_2,param_3,param_4,param_5,param_6);
  return;
}


// ==== FUN_800005c4 @ 800005c4

void FUN_800005c4(uint param_1,undefined2 param_2,undefined2 param_3,undefined2 param_4,
                 undefined4 param_5,undefined4 param_6)

{
  FUN_80011054(param_1 | DAT_90000064 << 0x10,param_2,param_3,param_4,param_5,param_6);
  return;
}


// ==== FUN_8000060e @ 8000060e

void FUN_8000060e(uint param_1,undefined4 param_2)

{
  FUN_80011148(param_1 | DAT_90000064 << 0x10,param_2);
  return;
}


// ==== FUN_80000630 @ 80000630

void FUN_80000630(uint param_1,undefined4 param_2,undefined4 param_3)

{
  FUN_8001121c(param_1 | DAT_90000064 << 0x10,param_2,param_3);
  return;
}


// ==== FUN_80000656 @ 80000656

void FUN_80000656(uint param_1,undefined4 param_2,undefined4 param_3)

{
  FUN_800112b8(param_1 | DAT_90000064 << 0x10,param_2,param_3);
  return;
}


// ==== FUN_8000067c @ 8000067c

void FUN_8000067c(uint param_1,undefined4 param_2)

{
  FUN_80011354(param_1 | DAT_90000064 << 0x10,param_2);
  return;
}


// ==== FUN_8000069e @ 8000069e

void FUN_8000069e(uint param_1,undefined1 param_2,undefined1 param_3,undefined4 param_4,
                 undefined4 param_5)

{
  FUN_800113e4(param_1 | DAT_90000064 << 0x10,param_2,param_3,param_4,param_5);
  return;
}


// ==== FUN_800006d8 @ 800006d8

void FUN_800006d8(uint param_1,undefined4 param_2)

{
  FUN_800114b8(param_1 | DAT_90000064 << 0x10,param_2);
  return;
}


// ==== FUN_800006fa @ 800006fa

void FUN_800006fa(uint param_1,uint param_2,undefined4 param_3)

{
  FUN_80011548(param_1 | DAT_90000064 << 0x10,param_2 | DAT_90000064 << 0x10,param_3);
  return;
}


// ==== FUN_80000724 @ 80000724

void FUN_80000724(uint param_1,undefined4 param_2,uint param_3,undefined4 param_4,undefined4 param_5
                 )

{
  FUN_800116c2(param_1 | DAT_90000064 << 0x10,param_2,param_3 | DAT_90000064 << 0x10,param_4,param_5
              );
  return;
}


// ==== FUN_80000756 @ 80000756

void FUN_80000756(uint param_1,undefined4 param_2)

{
  FUN_80011632(param_1 | DAT_90000064 << 0x10,param_2);
  return;
}


// ==== FUN_80000778 @ 80000778

void FUN_80000778(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  FUN_80011c7a(param_1,param_2,param_3);
  return;
}


// ==== FUN_80000792 @ 80000792

void FUN_80000792(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  FUN_80011b48(param_1,param_2,param_3);
  return;
}


// ==== FUN_800007ac @ 800007ac

void FUN_800007ac(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  FUN_80011c14(param_1,param_2,param_3);
  return;
}


// ==== FUN_800007c6 @ 800007c6

void FUN_800007c6(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  FUN_80011bae(param_1,param_2,param_3);
  return;
}


// ==== FUN_800007e0 @ 800007e0

void FUN_800007e0(undefined4 param_1,undefined2 param_2,undefined2 param_3,undefined4 param_4,
                 undefined4 param_5)

{
  FUN_80011ce0(param_1,param_2,param_3,param_4,param_5);
  return;
}


// ==== FUN_8000080e @ 8000080e

uint FUN_8000080e(void)

{
  uint in_D0;
  uint uVar1;
  
  if (DAT_90000068 == 0) {
    uVar1 = 0;
    DAT_90000068 = 1;
  }
  else if (DAT_90000068 == 1) {
    uVar1 = in_D0 & 0xffff | 0xffc80000;
    DAT_90000068 = 2;
  }
  else if (DAT_90000068 == 2) {
    uVar1 = in_D0 & 0xffff | 0xffc70000;
    DAT_90000068 = 3;
  }
  else {
    uVar1 = in_D0 & 0xffff | 0xfff80000;
    DAT_90000068 = 0;
  }
  return uVar1;
}


// ==== FUN_8000086c @ 8000086c

uint FUN_8000086c(void)

{
  uint in_D0;
  uint uVar1;
  
  if (DAT_9000006a == 0) {
    uVar1 = 0;
    DAT_9000006a = 1;
  }
  else if (DAT_9000006a == 1) {
    uVar1 = in_D0 & 0xffff | 0xffc80000;
    DAT_9000006a = 2;
  }
  else {
    uVar1 = in_D0 & 0xffff | 0xfff80000;
    DAT_9000006a = 0;
  }
  return uVar1;
}


// ==== FUN_800008b0 @ 800008b0

uint FUN_800008b0(void)

{
  uint in_D0;
  uint uVar1;
  
  if (DAT_9000006c == 0) {
    uVar1 = 0;
    DAT_9000006c = 1;
  }
  else if (DAT_9000006c == 1) {
    uVar1 = in_D0 & 0xffff | 0xffcb0000;
    DAT_9000006c = 2;
  }
  else if (DAT_9000006c == 2) {
    uVar1 = in_D0 & 0xffff | 0xffca0000;
    DAT_9000006c = 3;
  }
  else if (DAT_9000006c == 3) {
    uVar1 = in_D0 & 0xffff | 0xffc90000;
    DAT_9000006c = 4;
  }
  else {
    uVar1 = in_D0 & 0xffff | 0xfff80000;
    DAT_9000006c = 0;
  }
  return uVar1;
}


// ==== FUN_80000928 @ 80000928

void FUN_80000928(void)

{
  int iVar1;
  short sVar2;
  short sVar3;
  byte bVar4;
  short sVar5;
  short sVar6;
  int in_stack_00000010;
  
  if (DAT_9000006e == 0) {
    sVar5 = 0x400;
    DAT_9000006e = 0;
  }
  else if (DAT_9000006e == 1) {
    sVar5 = 0x14;
    DAT_9000006e = 2;
  }
  else {
    if (DAT_9000006e != 2) {
      DAT_9000006e = 0;
      return;
    }
    sVar5 = 0xc;
    DAT_9000006e = 3;
  }
  bVar4 = 0x41;
  sVar3 = 6;
  sVar2 = 0;
  if (sVar5 != 0) {
    do {
      sVar6 = 0;
      do {
        *(undefined1 *)(in_stack_00000010 + sVar2 * 0x20 + (int)sVar6) = 0x20;
        sVar6 = sVar6 + 1;
      } while (sVar6 < 8);
      sVar6 = 0;
      if (0 < sVar3) {
        do {
          *(byte *)(in_stack_00000010 + sVar2 * 0x20 + (int)sVar6) = bVar4;
          sVar6 = sVar6 + 1;
        } while (sVar6 < sVar3);
      }
      if (sVar5 + -1 == (int)sVar2) {
        iVar1 = sVar2 * 0x20;
        *(undefined1 *)(in_stack_00000010 + iVar1) = 0x44;
        *(undefined1 *)(in_stack_00000010 + 1 + iVar1) = 0x49;
        *(undefined1 *)(in_stack_00000010 + 2 + iVar1) = 0x52;
        *(undefined1 *)(in_stack_00000010 + 3 + iVar1) = 0x45;
        *(undefined1 *)(in_stack_00000010 + 4 + iVar1) = 0x31;
        *(undefined1 *)(in_stack_00000010 + 5 + iVar1) = 0x30;
        *(undefined1 *)(in_stack_00000010 + 6 + iVar1) = 0x32;
        *(undefined1 *)(in_stack_00000010 + 7 + iVar1) = 0x34;
      }
      iVar1 = sVar2 * 0x20;
      *(undefined1 *)(in_stack_00000010 + 8 + iVar1) = 0x53;
      *(undefined1 *)(in_stack_00000010 + 9 + iVar1) = 0x59;
      *(undefined1 *)(in_stack_00000010 + 10 + iVar1) = 0x53;
      *(undefined1 *)(in_stack_00000010 + 0xb + iVar1) = 0x20;
      bVar4 = bVar4 + 1;
      if (0x5a < bVar4) {
        bVar4 = 0x41;
        sVar3 = sVar3 + 1;
        if (8 < sVar3) {
          sVar3 = 1;
        }
      }
      sVar2 = sVar2 + 1;
    } while (sVar2 < sVar5);
  }
  return;
}


// ==== FUN_80000a5a @ 80000a5a

void FUN_80000a5a(void)

{
  int iVar1;
  short sVar2;
  short sVar3;
  byte bVar4;
  short sVar5;
  short sVar6;
  int in_stack_00000010;
  
  if (DAT_90000070 == 0) {
    sVar5 = 0x80;
    DAT_90000070 = 0;
  }
  else if (DAT_90000070 == 1) {
    sVar5 = 0x14;
    DAT_90000070 = 2;
  }
  else {
    if (DAT_90000070 != 2) {
      DAT_90000070 = 0;
      return;
    }
    sVar5 = 0xc;
    DAT_90000070 = 3;
  }
  bVar4 = 0x41;
  sVar3 = 6;
  sVar2 = 0;
  if (sVar5 != 0) {
    do {
      sVar6 = 0;
      do {
        *(undefined1 *)(in_stack_00000010 + sVar2 * 0x20 + (int)sVar6) = 0x20;
        sVar6 = sVar6 + 1;
      } while (sVar6 < 8);
      sVar6 = 0;
      if (0 < sVar3) {
        do {
          *(byte *)(in_stack_00000010 + sVar2 * 0x20 + (int)sVar6) = bVar4;
          sVar6 = sVar6 + 1;
        } while (sVar6 < sVar3);
      }
      if (sVar5 + -1 == (int)sVar2) {
        iVar1 = sVar2 * 0x20;
        *(undefined1 *)(in_stack_00000010 + iVar1) = 0x44;
        *(undefined1 *)(in_stack_00000010 + 1 + iVar1) = 0x49;
        *(undefined1 *)(in_stack_00000010 + 2 + iVar1) = 0x52;
        *(undefined1 *)(in_stack_00000010 + 3 + iVar1) = 0x44;
        *(undefined1 *)(in_stack_00000010 + 4 + iVar1) = 0x20;
        *(undefined1 *)(in_stack_00000010 + 5 + iVar1) = 0x31;
        *(undefined1 *)(in_stack_00000010 + 6 + iVar1) = 0x32;
        *(undefined1 *)(in_stack_00000010 + 7 + iVar1) = 0x38;
      }
      iVar1 = sVar2 * 0x20;
      *(undefined1 *)(in_stack_00000010 + 8 + iVar1) = 0x44;
      *(undefined1 *)(in_stack_00000010 + 9 + iVar1) = 0x49;
      *(undefined1 *)(in_stack_00000010 + 10 + iVar1) = 0x52;
      *(undefined1 *)(in_stack_00000010 + 0xb + iVar1) = 0x20;
      bVar4 = bVar4 + 1;
      if (0x5a < bVar4) {
        bVar4 = 0x41;
        sVar3 = sVar3 + 1;
        if (8 < sVar3) {
          sVar3 = 2;
        }
      }
      sVar2 = sVar2 + 1;
    } while (sVar2 < sVar5);
  }
  return;
}


// ==== FUN_80000b8c @ 80000b8c

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

uint FUN_80000b8c(undefined4 param_1,undefined1 *param_2)

{
  uint in_D0;
  
  if (_DAT_90000074 == 0) {
    _DAT_90000074 = 1;
    return in_D0 & 0xffff | 0xfff80000;
  }
  _DAT_90000074 = 2;
  if (DAT_90000072 == 0) {
    *param_2 = 0x2f;
    param_2[1] = 0x41;
    param_2[2] = 0x2f;
    param_2[3] = 0x42;
    param_2[4] = 0x20;
    param_2[5] = 0x20;
    param_2[6] = 0;
  }
  else if (DAT_90000072 == 1) {
    *param_2 = 0x2f;
    param_2[1] = 0x41;
    param_2[2] = 0x41;
    param_2[3] = 0x2f;
    param_2[4] = 0x42;
    param_2[5] = 0x42;
    param_2[6] = 0;
  }
  else if (DAT_90000072 == 2) {
    *param_2 = 0x2f;
    param_2[1] = 0x54;
    param_2[2] = 0x53;
    param_2[3] = 0x44;
    param_2[4] = 0x2f;
    param_2[5] = 0x59;
    param_2[6] = 0;
  }
  else {
    if (DAT_90000072 == 3) {
      *param_2 = 0x2f;
      param_2[1] = 0x59;
      param_2[2] = 0x4f;
      param_2[3] = 0x4b;
      param_2[4] = 0x4f;
      param_2[5] = 0x48;
      param_2[6] = 0x41;
    }
    else {
      if (DAT_90000072 == 4) {
        *param_2 = 0x2f;
        param_2[1] = 0x5a;
        param_2[2] = 0x5a;
        param_2[3] = 0x52;
        param_2[4] = 0x31;
        param_2[5] = 0x31;
        param_2[6] = 0;
        goto LAB_80000cee;
      }
      if (DAT_90000072 != 5) goto LAB_80000cf4;
      *param_2 = 0x2f;
      param_2[1] = 0x46;
      param_2[2] = 0x5a;
      param_2[3] = 0x2f;
      param_2[4] = 0x47;
      param_2[5] = 0x53;
      param_2[6] = 0x58;
    }
    param_2[7] = 0;
  }
LAB_80000cee:
  DAT_90000072 = DAT_90000072 + 1;
LAB_80000cf4:
  if (5 < DAT_90000072) {
    DAT_90000072 = 0;
  }
  return 0;
}


// ==== FUN_80000d0c @ 80000d0c

void FUN_80000d0c(undefined4 param_1,int param_2,uint param_3)

{
  int iVar1;
  uint uVar2;
  int iVar3;
  
  uVar2 = 0;
  if (param_3 != 0) {
    do {
      iVar3 = uVar2 * 0x20 + param_2;
      if (*(char *)(iVar3 + 7) == '@') {
        iVar1 = 5;
        do {
          if (*(char *)(iVar3 + iVar1) != '_') break;
          *(undefined1 *)(iVar3 + iVar1) = 0x20;
          iVar1 = iVar1 + -1;
        } while (0 < iVar1);
      }
      uVar2 = uVar2 + 1;
    } while (uVar2 < param_3);
  }
  return;
}


// ==== FUN_80000d72 @ 80000d72

void FUN_80000d72(char *param_1)

{
  int iVar1;
  
  if (*param_1 == '*') {
    iVar1 = 5;
    do {
      if (param_1[iVar1 + 3] != '_') {
        return;
      }
      param_1[iVar1 + 3] = ' ';
      iVar1 = iVar1 + -1;
    } while (0 < iVar1);
  }
  return;
}


// ==== FUN_80000d9e @ 80000d9e

void FUN_80000d9e(int param_1)

{
  int iVar1;
  
  iVar1 = 5;
  do {
    if (*(char *)(param_1 + iVar1) != '_') {
      return;
    }
    *(undefined1 *)(param_1 + iVar1) = 0x20;
    iVar1 = iVar1 + -1;
  } while (0 < iVar1);
  return;
}


// ==== FUN_80000dc0 @ 80000dc0

void FUN_80000dc0(void)

{
  return;
}


// ==== FUN_80000e00 @ 80000e00

/* WARNING: This function may have set the stack pointer */

void FUN_80000e00(undefined1 *param_1,undefined1 *param_2,int param_3,undefined1 *param_4,
                 undefined1 *param_5,int param_6,undefined4 param_7)

{
  undefined1 *puVar1;
  
  FUN_800162c4(0x1000080,param_7);
  __m68k_trap(0);
  puVar1 = param_2;
  do {
    *puVar1 = *param_1;
    param_3 = param_3 + -1;
    param_1 = param_1 + 1;
    puVar1 = puVar1 + 1;
  } while (param_3 != 0);
  do {
    *param_5 = *param_4;
    param_6 = param_6 + -1;
    param_4 = param_4 + 1;
    param_5 = param_5 + 1;
  } while (param_6 != 0);
                    /* WARNING: Could not recover jumptable at 0x80000e50. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (*(code *)(param_2 + 0x22))();
  return;
}


// ==== FUN_80000e54 @ 80000e54

/* WARNING: Restarted to delay deadcode elimination for space: stack */

void FUN_80000e54(void)

{
  int unaff_D7;
  int local_36;
  short sVar1;
  short sVar2;
  undefined1 auStack_24 [4];
  int local_20;
  undefined4 local_1c;
  undefined4 local_10;
  
  local_36 = 0;
  do {
    FUN_80000174(local_36,&DAT_900100e8);
    sVar1 = (short)((uint)unaff_D7 >> 0x10);
    if (unaff_D7 < 0) {
      if (local_36 == 1) {
        FUN_80007fa2((int)sVar1,1);
        return;
      }
    }
    else {
      FUN_800002ea(local_36,s_DIAG_SYS_900000b8,0,&DAT_900100e8);
      if (-1 < unaff_D7) {
        sVar2 = (short)unaff_D7;
        while (FUN_8000033e(local_36,(int)sVar2,0x1c,auStack_24,&DAT_900100e8), -1 < unaff_D7) {
          FUN_8001379e(local_20);
          FUN_8001379e(local_20 + 0x100);
          FUN_80015e48(0x80000e34);
          FUN_8001379e(local_1c);
          FUN_80001084(local_36,(int)sVar2,unaff_D7 + 0x100,local_20);
          FUN_8001626c(0x15);
          FUN_8001627c(0x15);
          FUN_8001626c(0x16);
          FUN_8001627c(0x16);
          FUN_8001626c(0x12);
          FUN_8001627c(0x12);
          FUN_8001626c(0x13);
          FUN_8001627c(0x13);
          FUN_8001626c(0x11);
          FUN_8001627c(0x11);
          FUN_8001626c(0x14);
          FUN_8001627c(0x14);
          FUN_800162e4();
          FUN_800162dc();
          FUN_80000e00(unaff_D7 + 0x100,local_10,local_20);
        }
        FUN_80007fa2((int)sVar1,local_36);
        FUN_80000314(local_36,(int)sVar2,&DAT_900100e8);
        FUN_80000294(local_36,&DAT_900100e8);
        return;
      }
      FUN_80000294(local_36,&DAT_900100e8);
      if (local_36 == 1) {
        FUN_80007fa2((int)sVar1,1);
        return;
      }
    }
    local_36 = 1;
  } while( true );
}


// ==== FUN_80001084 @ 80001084

void FUN_80001084(undefined4 param_1,short param_2,int param_3,int param_4,int param_5,int param_6)

{
  uint unaff_D7;
  ushort in_stack_fffffffa;
  uint uVar1;
  
  if (param_5 == param_4 + param_3) {
    param_4 = param_6 + param_4;
    param_6 = 0;
  }
  uVar1 = (uint)in_stack_fffffffa;
  if (param_4 != 0) {
    FUN_8000033e(param_1,(int)param_2,param_4,param_3,&DAT_900100e8);
    uVar1 = unaff_D7;
  }
  if ((-1 < (int)uVar1) && (param_6 != 0)) {
    FUN_8000033e(param_1,(int)param_2,param_6,param_5,&DAT_900100e8);
    uVar1 = unaff_D7;
  }
  if ((int)uVar1 < 0) {
    FUN_80007fa2((int)(short)(uVar1 >> 0x10),param_1);
  }
  return;
}


// ==== FUN_80001128 @ 80001128

void FUN_80001128(void)

{
  uint uVar1;
  bool bVar2;
  uint unaff_D7;
  undefined4 uVar3;
  
  FUN_800162e4();
  FUN_8001628c();
  FUN_80016274(&DAT_9000014c);
  FUN_800162e4();
  FUN_8001628c();
  FUN_80016274(&DAT_900002b4);
  FUN_800162e4();
  FUN_8001628c();
  FUN_80016274(&DAT_900002e4);
  FUN_800162e4();
  FUN_8001628c();
  FUN_80016274(&DAT_90000290);
  do {
    FUN_800162cc(0,0);
    FUN_8000dd8e();
    do {
      bVar2 = true;
      FUN_800099f6();
      FUN_80007fa2(0);
      uVar1 = unaff_D7 & 0xffff;
      if (uVar1 == 0x119) {
        FUN_800012d2(&DAT_900000c4);
        if (unaff_D7 != 1) {
          return;
        }
        uVar3 = 0x15;
LAB_800012b0:
        FUN_80016294(uVar3,0x20000000);
      }
      else {
        if (uVar1 < 0x11a) {
          if (uVar1 == 0xd) {
LAB_8000127e:
            if (DAT_900000c4 == 1) {
              FUN_800137b4(DAT_9000131a);
              FUN_800137b4(DAT_9000131e);
              DAT_900000c4 = 0;
            }
            uVar3 = 0x10;
          }
          else {
            if (uVar1 != 0x118) goto LAB_800012ba;
            FUN_800012d2(&DAT_900000c4);
            if (unaff_D7 != 1) {
              return;
            }
            uVar3 = 0x14;
          }
          goto LAB_800012b0;
        }
        if (uVar1 == 0x11b) {
          FUN_800012d2(&DAT_900000c4);
          if (unaff_D7 != 1) {
            return;
          }
          uVar3 = 0x18;
          goto LAB_800012b0;
        }
        if (uVar1 < 0x11c) {
          if (uVar1 == 0x11a) {
            FUN_800012d2(&DAT_900000c4);
            if (unaff_D7 != 1) {
              return;
            }
            uVar3 = 0x16;
            goto LAB_800012b0;
          }
        }
        else if (uVar1 == 0x11f) goto LAB_8000127e;
LAB_800012ba:
        bVar2 = false;
      }
    } while (!bVar2);
  } while( true );
}


// ==== FUN_800012d2 @ 800012d2

void FUN_800012d2(short *param_1)

{
  int unaff_D7;
  undefined4 *puVar1;
  undefined4 local_c;
  
  if (*param_1 == 0) {
    local_c = 0x9000;
    FUN_8001379e();
    puVar1 = (undefined4 *)((int)register0x0000003c + -8);
    DAT_9000131a = unaff_D7;
    if (unaff_D7 != 0) {
      local_c = 0x9000;
      FUN_8001379e();
      DAT_9000131e = unaff_D7;
      if (unaff_D7 != 0) {
        *param_1 = 1;
        return;
      }
      local_c = DAT_9000131a;
      FUN_800137b4();
      puVar1 = &local_c;
    }
    *(undefined4 *)((int)puVar1 + -4) = 0x20000000;
    *(undefined4 *)((int)puVar1 + -8) = 0x10;
    *(undefined4 *)((int)puVar1 + -0xc) = 0x80001328;
    FUN_80016294();
  }
  return;
}


// ==== FUN_800014a8 @ 800014a8

ushort FUN_800014a8(void)

{
  ushort unaff_D7w;
  
  FUN_800099f6();
  if (((unaff_D7w != 0x11f) && (unaff_D7w != 0xd)) && ((unaff_D7w < 0x118 || (0x11e < unaff_D7w))))
  {
    unaff_D7w = 0;
  }
  return unaff_D7w;
}


// ==== FUN_800014dc @ 800014dc

ushort FUN_800014dc(void)

{
  ushort unaff_D7w;
  
  FUN_800099f6();
  if (((unaff_D7w != 0x11f) && (unaff_D7w != 0xd)) && ((unaff_D7w < 0x118 || (0x11b < unaff_D7w))))
  {
    unaff_D7w = 0;
  }
  return unaff_D7w;
}


// ==== FUN_80001516 @ 80001516

void FUN_80001516(void)

{
  FUN_80007fa2(0xd,DAT_900081cc);
  FUN_80007c28(&DAT_80001510,8);
  FUN_80001916(DAT_900081cc);
  return;
}


// ==== FUN_8000154a @ 8000154a

void FUN_8000154a(void)

{
  FUN_80007fa2(0xf,DAT_900081cc);
  FUN_80007c28(&DAT_80001510,8);
  FUN_80001916(DAT_900081cc);
  return;
}


// ==== FUN_8000157e @ 8000157e

void FUN_8000157e(void)

{
  FUN_80007fa2(0xe,DAT_9000c29c);
  FUN_80007c28(&DAT_80001510,8);
  FUN_80001916(DAT_9000c29c);
  return;
}


// ==== FUN_800015b2 @ 800015b2

void FUN_800015b2(void)

{
  FUN_80007fa2(0x10,DAT_9000c29c);
  FUN_80007c28(&DAT_80001510,8);
  FUN_80001916(DAT_9000c29c);
  return;
}


// ==== FUN_800015e6 @ 800015e6

void FUN_800015e6(void)

{
  FUN_8000826a(0x19);
  FUN_80007fa2(0x15);
  return;
}


// ==== FUN_80001606 @ 80001606

void FUN_80001606(void)

{
  int unaff_D7;
  
  FUN_80007bd2();
  FUN_800081e0(0x11);
  FUN_8000826a(6);
  FUN_80007c28(&DAT_80001604,0);
  FUN_800017ea(6);
  FUN_80007c28(&DAT_80001510,8);
  do {
    FUN_800014dc();
  } while (unaff_D7 == 0);
  if ((unaff_D7 != 0x11f) && (unaff_D7 != 0xd)) {
    FUN_800017c2(unaff_D7 + -0x118,5);
    DAT_900081cc = unaff_D7;
  }
  return;
}


// ==== FUN_80001692 @ 80001692

void FUN_80001692(void)

{
  int unaff_D7;
  
  FUN_80007bd2();
  FUN_800081e0(0x11);
  FUN_8000826a(7);
  FUN_80007c28(&DAT_80001604,0);
  FUN_800017ea(DAT_900081cc);
  FUN_80007c28(&DAT_80001510,8);
  do {
    FUN_800014dc();
  } while (unaff_D7 == 0);
  if ((unaff_D7 != 0x11f) && (unaff_D7 != 0xd)) {
    FUN_800017c2(unaff_D7 + -0x118,DAT_900081cc);
    DAT_9000c29c = unaff_D7;
  }
  return;
}


// ==== FUN_8000171e @ 8000171e

void FUN_8000171e(int param_1)

{
  short unaff_D7w;
  
  FUN_80007bd2();
  FUN_800081e0(0x11);
  DAT_9000c86c = DAT_900081cc;
  DAT_9000c870 = DAT_9000c29c;
  FUN_80016238(&DAT_9000c8a2,DAT_900129a4 + param_1 * 0x774 + 0x766);
  FUN_8000826a(0x18);
  FUN_80007c28(&DAT_80001604,0);
  FUN_80007c28(&DAT_80001510,8);
  while( true ) {
    FUN_800099f6();
    if (unaff_D7w == 0x11f) {
      return;
    }
    if (unaff_D7w == 0xd) break;
    if (unaff_D7w == 10) {
      return;
    }
  }
  return;
}


// ==== FUN_800017c2 @ 800017c2

void FUN_800017c2(void)

{
  return;
}


// ==== FUN_800017ea @ 800017ea

void FUN_800017ea(int param_1)

{
  short sVar1;
  short sVar2;
  
  FUN_80007c28(&DAT_80001604,0);
  sVar2 = 0;
  sVar1 = 0;
  do {
    if (param_1 != (&DAT_900000c8)[sVar1 * 2]) {
      sVar2 = sVar2 + 1;
      FUN_80007c28((&PTR_s_A_MFD__900000cc)[sVar1 * 2],(int)sVar2);
    }
    sVar1 = sVar1 + 1;
  } while (sVar1 < 5);
  return;
}


// ==== FUN_8000183c @ 8000183c

void FUN_8000183c(void)

{
  int iVar1;
  int iVar2;
  int unaff_D7;
  
  FUN_80007bd2();
  FUN_80007c28(&DAT_80001604,0);
  iVar2 = 1;
  do {
    iVar1 = DAT_900129a4 + iVar2 * 0x774 + -0xe;
    FUN_80007c28(iVar1,iVar2);
    FUN_80015d14(iVar1,&DAT_90006340 + (iVar2 + -1) * 10,10);
    iVar2 = iVar2 + 1;
  } while (iVar2 < 8);
  FUN_80007c28(&DAT_80001510,8);
  FUN_800081e0(0x11);
  FUN_8000826a(5);
  do {
    do {
      FUN_800014a8();
    } while (unaff_D7 == 0);
  } while (((unaff_D7 != 0x11f) && (unaff_D7 != 0xd)) &&
          (*(short *)(DAT_900129a4 + (unaff_D7 + -0x118) * 0x774) == 0));
  return;
}


// ==== FUN_80001916 @ 80001916

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_80001916(undefined4 param_1)

{
  uint unaff_D7;
  bool bVar1;
  
  bVar1 = (int)_DAT_900100ec < 0;
  do {
    FUN_80000024(param_1);
    if ((unaff_D7 == 0) ||
       ((bVar1 && (FUN_80000174(param_1,&DAT_9000d9ec), _DAT_900100ec = unaff_D7, -1 < (int)unaff_D7
                  )))) {
      return;
    }
    FUN_80009a4a();
    if ((unaff_D7 & 0xffff) == 0x11f) {
      return;
    }
  } while ((unaff_D7 & 0xffff) != 0xd);
  return;
}


// ==== FUN_8000198a @ 8000198a

void FUN_8000198a(void)

{
  undefined4 uVar1;
  
  if (DAT_900000f0 == 1) {
    uVar1 = 0x14;
  }
  else {
    uVar1 = 0xe;
  }
  FUN_8000f46a(1,uVar1,8,7,0,(&PTR_s__YOUR_BZE_910X_IS_VERSION_2_0___A_900000f4)[DAT_900000f0 * 3]);
  FUN_8000f46a(1,0x19,10,7,0,(&PTR_s_WHEN_INSTALLING_A_BZE_96XX__900000f8)[DAT_900000f0 * 3]);
  if (DAT_900000f0 == 1) {
    uVar1 = 0x11;
  }
  else {
    uVar1 = 0x14;
  }
  FUN_8000f46a(1,uVar1,0xc,7,0,(&PTR_s_PLEASE_USE_V3_0___ABOVE_OF_BZE_9_900000fc)[DAT_900000f0 * 3])
  ;
  return;
}


// ==== FUN_80001a38 @ 80001a38

void FUN_80001a38(void)

{
  FUN_80016134(&DAT_900012c8,0x50,0x20);
  DAT_90001317 = 0;
  FUN_8000f46a(1,0,8,7,0,&DAT_900012c8);
  FUN_8000f46a(1,0,10,7,0,&DAT_900012c8);
  FUN_8000f46a(1,0,0xc,7,0,&DAT_900012c8);
  return;
}


// ==== FUN_80001ad0 @ 80001ad0

void FUN_80001ad0(void)

{
  int unaff_D7;
  
  FUN_80007bd2();
  FUN_800081e0(0x11);
  FUN_80016134(&DAT_900012c8,0x3d,0x20);
  DAT_90001305 = 0;
  FUN_8000f46a(1,0x13,0x17,7,0,&DAT_900012c8);
  FUN_8000f46a(1,0x13,0x17,7,0,PTR_s_SELECT_YOUR_BZE9102__or_9101__VE_90000124);
  FUN_80007c28(&DAT_80001604,0);
  FUN_80007c28("2.0&ABOVE",1);
  FUN_80007c28("BELOW 2.0",2);
  FUN_80007c28("BZE-9103",3);
  FUN_80007c28(&DAT_80001510,8);
  while( true ) {
    do {
      FUN_800014dc();
    } while (unaff_D7 == 0);
    if (unaff_D7 == 0x11f) {
      return;
    }
    if (unaff_D7 == 0xd) {
      return;
    }
    if (unaff_D7 == 0x118) break;
    if (unaff_D7 == 0x119) {
      DAT_900000f0 = 1;
      return;
    }
    if (unaff_D7 == 0x11a) {
      DAT_900000f0 = 2;
      return;
    }
  }
  DAT_900000f0 = 2;
  return;
}


// ==== FUN_80001bd8 @ 80001bd8

void FUN_80001bd8(undefined4 *param_1,undefined4 *param_2,short param_3)

{
  if (((param_3 < 4) || (((uint)param_1 & 1) != 0)) || (((uint)param_2 & 1) != 0)) {
LAB_80001c12:
    FUN_80015e48(param_1,param_2,(int)param_3);
  }
  else {
    for (; param_3 != 0; param_3 = param_3 + -4) {
      if (param_3 < 4) goto LAB_80001c12;
      *param_2 = *param_1;
      param_1 = param_1 + 1;
      param_2 = param_2 + 1;
    }
  }
  return;
}


// ==== FUN_80001c24 @ 80001c24

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

int FUN_80001c24(short param_1)

{
  short sVar1;
  undefined2 extraout_D0u;
  int iVar2;
  int unaff_D7;
  
  iVar2 = _DAT_900100ec;
  DAT_900100ec = (short)((uint)unaff_D7 >> 0x10);
  sVar1 = DAT_900100ec;
  _DAT_900100ec = iVar2;
  if (DAT_9000c298 == '\0') {
    FUN_800002ea(DAT_9000c86c,&DAT_9000c874,0,&DAT_900100e8);
    if (unaff_D7 < 0) {
      _DAT_900100ec = unaff_D7;
      return CONCAT22(extraout_D0u,sVar1);
    }
    _DAT_900100ee = (short)unaff_D7;
    DAT_900100f8 = _DAT_900100ee;
    DAT_9000c298 = '\x01';
    FUN_8000033e(DAT_9000c86c,(int)_DAT_900100ee,0x9000,DAT_9000131a,&DAT_900100e8);
    DAT_9000d9e8 = 0;
    DAT_9000c260 = unaff_D7;
    _DAT_900100ec = unaff_D7;
  }
  if (DAT_9000d9e8 == DAT_9000c260) {
    FUN_80015e48(DAT_9000131a + 0x8ffc,DAT_9000131a,4);
    FUN_8000033e(DAT_9000c86c,(int)DAT_900100f8,0x8ffc,DAT_9000131a + 4,&DAT_900100e8);
    DAT_9000d9e8 = 4;
    if (sVar1 == -0xc) {
      DAT_9000c260 = unaff_D7;
      _DAT_900100ec = unaff_D7;
      iVar2 = FUN_80000314(DAT_9000c86c,(int)DAT_900100f8,&DAT_900100e8);
      return iVar2;
    }
    DAT_9000c260 = unaff_D7 + 4;
    _DAT_900100ec = unaff_D7;
  }
  iVar2 = DAT_9000d9e8;
  if (0 < param_1) {
    DAT_9000d9e8 = DAT_9000d9e8 + 1;
  }
  if (param_1 < 0) {
    DAT_9000d9e8 = DAT_9000d9e8 + -1;
  }
  return iVar2;
}


// ==== FUN_80001f10 @ 80001f10

void FUN_80001f10(void)

{
  int iVar1;
  int unaff_D4;
  int unaff_D5;
  int unaff_D7;
  undefined4 uVar2;
  
  FUN_80007fa2(0);
  iVar1 = -1;
  do {
    switch(iVar1) {
    case 0:
      FUN_80001606();
      unaff_D4 = unaff_D7;
      break;
    case 1:
      FUN_80008700(0x18);
      FUN_800029d6();
      FUN_80002d2e();
      if (unaff_D7 < 0) {
        if (unaff_D7 == -1) {
          uVar2 = 0xd;
        }
        else {
          uVar2 = 1;
        }
        FUN_80007fa2(uVar2,DAT_900081cc);
        iVar1 = -1;
      }
      else {
        FUN_8000183c();
        unaff_D4 = unaff_D7;
        unaff_D5 = unaff_D7;
      }
      break;
    case 2:
      FUN_80001692();
      unaff_D4 = unaff_D7;
      break;
    case 3:
      FUN_8000171e(unaff_D5);
      unaff_D4 = unaff_D7;
      if (unaff_D7 == 10) {
        FUN_800024de(unaff_D5);
      }
      break;
    case -1:
      FUN_80001a38();
      FUN_80001ad0();
      unaff_D4 = unaff_D7;
      if (unaff_D7 == 0) {
        FUN_8000198a();
      }
    }
    if (unaff_D4 == 0x20) {
LAB_80002004:
      iVar1 = -3;
    }
    else if (unaff_D4 < 0x21) {
      if (unaff_D4 == 0xd) {
        if (iVar1 == 0) goto LAB_80002004;
        iVar1 = -2;
      }
    }
    else if (unaff_D4 == 0x11f) {
      iVar1 = iVar1 + -2;
    }
    if (iVar1 == 3) {
      iVar1 = -3;
    }
    iVar1 = iVar1 + 1;
    if (iVar1 < -1) {
      if (unaff_D4 != 0x20) {
        FUN_80007fa2(0);
      }
      FUN_80001a38();
      return;
    }
  } while( true );
}


// ==== FUN_80002038 @ 80002038

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_80002038(int param_1,int param_2)

{
  int unaff_D7;
  int iVar1;
  int iVar2;
  
  iVar2 = param_1 * 0x1e + 4;
  iVar1 = iVar2 + DAT_900129a4 + param_2 * 0x774;
  FUN_8000006c(DAT_900081cc,DAT_9000c29c,iVar1,iVar1 + 0xe);
  if (-1 < _DAT_900100ec) {
    iVar2 = iVar2 + DAT_900129a4 + param_2 * 0x774;
    FUN_80000724(DAT_900081cc,iVar2,DAT_9000c29c,iVar2 + 0xe,&DAT_9000d9ec);
    _DAT_900100ec = unaff_D7;
  }
  return;
}


// ==== FUN_800020bc @ 800020bc

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_800020bc(void)

{
  undefined4 unaff_D7;
  
  FUN_800006fa(DAT_900081cc,DAT_9000c29c,&DAT_9000d9ec);
  _DAT_900100ec = unaff_D7;
  return;
}


// ==== FUN_800020e2 @ 800020e2

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_800020e2(int param_1,int param_2)

{
  int unaff_D7;
  
  FUN_800003d4(DAT_9000c29c,DAT_900129a4 + param_2 * 0x774 + 0x12 + param_1 * 0x1e,&DAT_9000d9ec);
  if (-1 < unaff_D7) {
    FUN_800006d8(DAT_9000c29c,&DAT_9000d9ec);
  }
  _DAT_900100ec = unaff_D7;
  return;
}


// ==== FUN_80002156 @ 80002156

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_80002156(void)

{
  undefined4 unaff_D7;
  
  if (DAT_9000c29c != 6) {
    FUN_80000294(DAT_900081cc,&DAT_9000d9ec);
    FUN_8000069e(DAT_9000c29c,0,3,"           ",&DAT_9000d9ec);
    _DAT_900100ec = unaff_D7;
    FUN_80000174(DAT_900081cc,&DAT_9000d9ec);
    DAT_90006874 = unaff_D7;
  }
  return;
}


// ==== FUN_800021b6 @ 800021b6

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_800021b6(void)

{
  undefined4 unaff_D7;
  
  if (DAT_9000c29c != 6) {
    FUN_80000294(DAT_900081cc,&DAT_9000d9ec);
    FUN_80000294(DAT_9000c29c,&DAT_9000d9ec);
    FUN_8000069e(DAT_9000c29c,1,3,"           ",&DAT_9000d9ec);
    _DAT_900100ec = unaff_D7;
    FUN_80000174(DAT_900081cc,&DAT_9000d9ec);
    DAT_90006874 = unaff_D7;
    FUN_80000174(DAT_9000c29c,&DAT_9000d9ec);
    _DAT_9000db10 = unaff_D7;
  }
  return;
}


// ==== FUN_80002248 @ 80002248

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_80002248(void)

{
  undefined4 unaff_D7;
  
  if (DAT_9000c29c != 6) {
    FUN_80000294(DAT_900081cc,&DAT_9000d9ec);
    FUN_80000294(DAT_9000c29c,&DAT_9000d9ec);
    FUN_8000069e(DAT_9000c29c,2,3,"           ",&DAT_9000d9ec);
    _DAT_900100ec = unaff_D7;
    FUN_80000174(DAT_900081cc,&DAT_9000d9ec);
    DAT_90006874 = unaff_D7;
    FUN_80000174(DAT_9000c29c,&DAT_9000d9ec);
    _DAT_9000db10 = unaff_D7;
  }
  return;
}


// ==== FUN_800022da @ 800022da

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_800022da(void)

{
  int unaff_D7;
  
  FUN_80000024(DAT_9000c29c);
  if (unaff_D7 == 0) {
    FUN_80000294(DAT_9000c29c,&DAT_9000d9ec);
    FUN_80000174(DAT_9000c29c,&DAT_9000d9ec);
    _DAT_9000db10 = 0;
  }
  if (-1 < _DAT_9000db10) {
    if (unaff_D7 != 1) {
      return;
    }
    _DAT_9000db10 = CONCAT22(0xff00,DAT_9000db10_2);
  }
  _DAT_900100ec = _DAT_9000db10;
  return;
}


// ==== FUN_8000234a @ 8000234a

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_8000234a(void)

{
  int unaff_D7;
  
  FUN_80000024(DAT_900081cc);
  if (unaff_D7 == 0) {
    FUN_80000294(DAT_900081cc,&DAT_9000d9ec);
    FUN_80000174(DAT_900081cc,&DAT_9000d9ec);
    DAT_90006874 = 0;
  }
  if (-1 < DAT_90006874) {
    if (unaff_D7 != 1) {
      return;
    }
    DAT_90006874 = CONCAT22(0xff00,DAT_90006874._2_2_);
  }
  _DAT_900100ec = DAT_90006874;
  return;
}


// ==== FUN_800023ba @ 800023ba

void FUN_800023ba(int param_1,int param_2)

{
  int iVar1;
  int unaff_D7;
  
  if (((DAT_9000db10 == -4) &&
      (((DAT_9000c29c == 8 || (DAT_9000c29c == 9)) &&
       (iVar1 = param_2 * 0x774 + DAT_900129a4 + 4 + param_1 * 0x1e,
       *(char *)(iVar1 + 0x1c) != '\x05')))) && (*(char *)(iVar1 + 0x1c) != '\x06')) {
    return;
  }
  switch(*(undefined1 *)(param_2 * 0x774 + DAT_900129a4 + 0x20 + param_1 * 0x1e)) {
  case 1:
    FUN_8000234a();
    if (unaff_D7 == 0) {
      FUN_800022da();
      FUN_80002038(param_1,param_2);
    }
    break;
  case 2:
    FUN_8000234a();
    if (unaff_D7 == 0) {
      FUN_800022da();
      FUN_800020bc();
    }
    break;
  case 3:
    FUN_800022da();
    if (unaff_D7 != 0) {
      return;
    }
    FUN_800020e2(param_1,param_2);
    goto LAB_800024b4;
  case 4:
    FUN_800022da();
    if (unaff_D7 != 0) {
      return;
    }
    FUN_80002156();
LAB_800024b4:
    if (DAT_900100ec == -3) {
      DAT_900100ec = 0;
    }
    break;
  case 5:
    FUN_800021b6();
    break;
  case 6:
    FUN_80002248();
  }
  return;
}


// ==== FUN_800024de @ 800024de

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_800024de(int param_1)

{
  int iVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  uint unaff_D7;
  short sVar5;
  int local_e;
  int local_a;
  undefined1 local_6;
  undefined1 local_5;
  
  iVar3 = DAT_900129a4;
  _DAT_900100ec = 0;
  iVar2 = 0;
  if (0 < *(short *)(DAT_900129a4 + param_1 * 0x774)) {
    iVar1 = DAT_900129a4 + param_1 * 0x774;
    do {
      *(undefined1 *)(iVar1 + 0x21 + iVar2 * 0x1e) = 0;
      iVar2 = iVar2 + 1;
    } while (iVar2 < *(short *)(iVar3 + param_1 * 0x774));
  }
  iVar2 = param_1 * 0x774;
  do {
    sVar5 = 0;
    uVar4 = 0;
    FUN_80007fa2(0);
    FUN_8000826a(0);
    FUN_80007c28(&DAT_800024dc,0);
    FUN_80000174(DAT_9000c29c,&DAT_9000d9ec);
    local_6 = 0x2f;
    local_5 = 0;
    if ((-1 < (int)unaff_D7) && (DAT_9000c29c == 6)) {
      FUN_800007ac(6,&local_6,&DAT_9000d9ec);
    }
    _DAT_9000db10 = unaff_D7;
    if ((-1 < (int)unaff_D7) &&
       ((FUN_80000024(DAT_9000c29c), unaff_D7 == 2 || (FUN_80000024(DAT_9000c29c), unaff_D7 == 1))))
    {
      _DAT_900100ec = CONCAT22(0xff00,_DAT_900100ee);
      _DAT_900100ec = CONCAT31(_DAT_900100ec,(undefined1)DAT_9000c29c);
    }
    if (((DAT_9000db10 == -4) && (DAT_9000c29c != 8)) && (DAT_9000c29c != 9)) {
      _DAT_900100ec = CONCAT22(0xff00,_DAT_900100ee);
      _DAT_900100ec = CONCAT31(_DAT_900100ec,(undefined1)DAT_9000c29c);
    }
    FUN_80000174(DAT_900081cc,&DAT_9000d9ec);
    if (((int)_DAT_9000db10 < 0) && (DAT_9000c29c == 6)) {
      _DAT_900100ec = CONCAT22(0xff00,_DAT_900100ee);
    }
    DAT_90006874 = unaff_D7;
    for (iVar3 = 0; iVar3 < *(short *)(DAT_900129a4 + iVar2); iVar3 = iVar3 + 1) {
      if (*(char *)(iVar2 + DAT_900129a4 + 0x21 + iVar3 * 0x1e) == '\0') {
        if (DAT_900100ec != -0x100) {
          FUN_800023ba(iVar3,param_1);
        }
        if (DAT_900100ec == -0xc) {
          _DAT_900100ec = _DAT_900100ec & 0xffff;
        }
        if ((int)_DAT_900100ec < 0) {
          if (sVar5 == 0) {
            DAT_9000c25c = _DAT_900100ec & 0xff;
            local_e = param_1;
            sVar5 = DAT_900100ec;
            local_a = iVar3;
          }
        }
        else {
          iVar1 = iVar2 + DAT_900129a4 + 4 + iVar3 * 0x1e;
          if ((*(char *)(iVar1 + 0x1c) == '\x01') || (*(char *)(iVar1 + 0x1c) == '\x02')) {
            *(undefined1 *)(iVar2 + DAT_900129a4 + 0x21 + iVar3 * 0x1e) = 1;
          }
        }
        FUN_80009a4a();
        uVar4 = unaff_D7 & 0xffff;
        if (uVar4 == 0x20) break;
      }
    }
    if ((uVar4 == 0x20) || (sVar5 == 0)) {
LAB_80002760:
      FUN_80000294(DAT_900081cc,&DAT_9000d9ec);
      FUN_80000294(DAT_9000c29c,&DAT_9000d9ec);
      FUN_8000826a(0x19);
      if (uVar4 != 0x20) {
        FUN_80007fa2(0);
      }
      return;
    }
    FUN_8000295c(local_a,local_e);
    FUN_80000294(DAT_900081cc,&DAT_9000d9ec);
    FUN_80000294(DAT_9000c29c,&DAT_9000d9ec);
    uVar4 = unaff_D7;
    if ((unaff_D7 != 0) || (sVar5 == 0)) goto LAB_80002760;
  } while( true );
}


// ==== FUN_800027aa @ 800027aa

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_800027aa(undefined4 param_1,int param_2)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  int iVar4;
  int iVar5;
  int unaff_D7;
  bool bVar6;
  
  if (DAT_9000c25c == DAT_900081cc) {
    if ((DAT_9000c29c == 0) || (DAT_9000c29c == 1)) {
      FUN_80000294(DAT_9000c29c,&DAT_9000d9ec);
    }
    iVar4 = DAT_900129a4;
    iVar5 = 0;
    if (0 < *(short *)(DAT_900129a4 + param_2 * 0x774)) {
      iVar1 = DAT_900129a4 + param_2 * 0x774;
      do {
        iVar2 = iVar1 + 4 + iVar5 * 0x1e;
        if (*(char *)(iVar2 + 0x1c) != '\x01') {
          *(undefined1 *)(iVar2 + 0x1d) = 1;
        }
        iVar5 = iVar5 + 1;
      } while (iVar5 < *(short *)(iVar4 + param_2 * 0x774));
    }
    _DAT_900100ec = DAT_90006874;
    uVar3 = _DAT_900100ec;
    DAT_900100ec = (short)((uint)DAT_90006874 >> 0x10);
    bVar6 = DAT_900100ec != -4;
    _DAT_900100ec = uVar3;
    if ((bVar6) && (FUN_80000024(DAT_900081cc), unaff_D7 != 1)) {
      FUN_8000154a();
      return;
    }
    FUN_80001516();
  }
  else {
    FUN_80002888(param_1,param_2);
  }
  return;
}


// ==== FUN_80002888 @ 80002888

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_80002888(undefined4 param_1,int param_2)

{
  int iVar1;
  int iVar2;
  undefined4 uVar3;
  int iVar4;
  int iVar5;
  int unaff_D7;
  bool bVar6;
  
  if ((DAT_900081cc == 0) || (DAT_900081cc == 1)) {
    FUN_80000294(DAT_900081cc,&DAT_9000d9ec);
  }
  iVar4 = DAT_900129a4;
  if (DAT_9000c29c == 6) {
    FUN_800015e6();
  }
  else {
    iVar5 = 0;
    if (0 < *(short *)(DAT_900129a4 + param_2 * 0x774)) {
      iVar1 = DAT_900129a4 + param_2 * 0x774;
      do {
        iVar2 = iVar1 + 4 + iVar5 * 0x1e;
        if (*(char *)(iVar2 + 0x1c) != '\x01') {
          *(undefined1 *)(iVar2 + 0x1d) = 0;
        }
        iVar5 = iVar5 + 1;
      } while (iVar5 < *(short *)(iVar4 + param_2 * 0x774));
    }
    _DAT_900100ec = _DAT_9000db10;
    uVar3 = _DAT_900100ec;
    DAT_900100ec = (short)((uint)_DAT_9000db10 >> 0x10);
    bVar6 = DAT_900100ec == -4;
    _DAT_900100ec = uVar3;
    if ((bVar6) || (FUN_80000024(DAT_9000c29c), unaff_D7 == 1)) {
      FUN_8000157e();
    }
    else {
      FUN_800015b2();
    }
  }
  return;
}


// ==== FUN_8000295c @ 8000295c

void FUN_8000295c(int param_1,int param_2)

{
  FUN_8000826a(0x19);
  switch(*(undefined1 *)(param_2 * 0x774 + DAT_900129a4 + 0x20 + param_1 * 0x1e)) {
  case 1:
  case 2:
    FUN_800027aa(param_1,param_2);
    break;
  case 3:
  case 4:
  case 5:
  case 6:
    FUN_80002888(param_1,param_2);
  }
  return;
}


// ==== FUN_800029d6 @ 800029d6

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_800029d6(void)

{
  _DAT_9000c8b0 = 0;
  _DAT_900129a8 = 0;
  DAT_9000c6f0 = 0;
  DAT_900081d0 = 0;
  DAT_90011954 = 0;
  DAT_900101d0 = 0;
  DAT_9000c6ec = 0;
  FUN_80016134(&DAT_900129ac,0xb,0);
  FUN_80016134(&DAT_900081d4,0x342c,0);
  return;
}


// ==== FUN_80002a30 @ 80002a30

void FUN_80002a30(byte *param_1)

{
  byte bVar1;
  short sVar2;
  byte *pbVar3;
  byte *pbVar4;
  byte abStack_12 [11];
  undefined1 local_7;
  
  FUN_80016134(abStack_12,0xd,0x20);
  sVar2 = 0;
  pbVar4 = param_1;
  do {
    if (*pbVar4 == 0) break;
    pbVar3 = pbVar4;
    if (*pbVar4 == 0x2e) {
      sVar2 = 8;
      pbVar3 = pbVar4 + 1;
    }
    pbVar4 = pbVar3 + 1;
    bVar1 = *pbVar3;
    if ((0x60 < bVar1) && (bVar1 < 0x7b)) {
      bVar1 = bVar1 - 0x20;
    }
    abStack_12[sVar2] = bVar1;
    sVar2 = sVar2 + 1;
  } while (sVar2 < 0xb);
  local_7 = 0;
  FUN_80016238(param_1,abStack_12);
  return;
}


// ==== FUN_80002a9e @ 80002a9e

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_80002a9e(short param_1)

{
  int iVar1;
  short *psVar2;
  undefined1 *puVar3;
  
  param_1 = param_1 + -1;
  if (param_1 != -1) {
    FUN_80002a30(&DAT_90010100);
    FUN_80002a30(&DAT_9000b600);
    iVar1 = param_1 * 0x774;
    if ((*(short *)(DAT_900129a4 + iVar1) != 0x3f) && (*(short *)(DAT_900129a4 + 2 + iVar1) < 2)) {
      if (DAT_90010100 == '*') {
        if (DAT_9000b600 == '*') {
          psVar2 = (short *)(iVar1 + DAT_900129a4);
          *(undefined1 *)(psVar2 + *psVar2 * 0xf + 0x10) = 2;
          *psVar2 = *psVar2 + 1;
        }
      }
      else if (DAT_90010100 == ' ') {
        if (_DAT_900129a8 == 0) {
          if (DAT_9000b600 == '*') {
            if (DAT_9000b601 == '2') {
              psVar2 = (short *)(param_1 * 0x774 + DAT_900129a4);
              *(undefined1 *)(psVar2 + *psVar2 * 0xf + 0x10) = 6;
              *psVar2 = *psVar2 + 1;
            }
            else {
              psVar2 = (short *)(param_1 * 0x774 + DAT_900129a4);
              *(undefined1 *)(psVar2 + *psVar2 * 0xf + 0x10) = 5;
              *psVar2 = *psVar2 + 1;
            }
            goto LAB_80002cfc;
          }
        }
        else if (DAT_9000b600 == '*') {
          psVar2 = (short *)(param_1 * 0x774 + DAT_900129a4);
          *(undefined1 *)(psVar2 + *psVar2 * 0xf + 0x10) = 4;
          *psVar2 = *psVar2 + 1;
          goto LAB_80002cfc;
        }
        if (DAT_9000b600 != ' ') {
          iVar1 = param_1 * 0x774;
          FUN_80016238(DAT_900129a4 + iVar1 + 0x12 + *(short *)(DAT_900129a4 + iVar1) * 0x1e,
                       &DAT_9000b600);
          psVar2 = (short *)(iVar1 + DAT_900129a4);
          *(undefined1 *)(psVar2 + *psVar2 * 0xf + 0x10) = 3;
          *psVar2 = *psVar2 + 1;
        }
      }
      else {
        if ((DAT_9000b600 == '*') || (DAT_9000b600 == ' ')) {
          if (DAT_9000b600 != ' ') goto LAB_80002cfc;
          iVar1 = param_1 * 0x774;
          FUN_80016238(DAT_900129a4 + iVar1 + 4 + *(short *)(DAT_900129a4 + iVar1) * 0x1e,
                       &DAT_90010100);
          puVar3 = &DAT_90010100;
        }
        else {
          iVar1 = param_1 * 0x774;
          FUN_80016238(DAT_900129a4 + iVar1 + 4 + *(short *)(DAT_900129a4 + iVar1) * 0x1e,
                       &DAT_90010100);
          puVar3 = &DAT_9000b600;
        }
        FUN_80016238(DAT_900129a4 + iVar1 + 0x12 + *(short *)(DAT_900129a4 + iVar1) * 0x1e,puVar3);
        psVar2 = (short *)(iVar1 + DAT_900129a4);
        *(undefined1 *)(psVar2 + *psVar2 * 0xf + 0x10) = 1;
        *psVar2 = *psVar2 + 1;
      }
    }
  }
LAB_80002cfc:
  _DAT_900129a8 = 0;
  FUN_80016134(&DAT_90010100,0xe,0);
  FUN_80016134(&DAT_9000b600,0xe,0);
  return;
}


// ==== FUN_80002d2e @ 80002d2e

/* WARNING: Removing unreachable block (ram,0x80002e40) */
/* WARNING: Removing unreachable block (ram,0x80002e46) */
/* WARNING: Removing unreachable block (ram,0x80002dac) */
/* WARNING: Removing unreachable block (ram,0x80002dc6) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_80002d2e(void)

{
  int unaff_D7;
  short sVar1;
  
  FUN_80003048(0);
  sVar1 = (short)unaff_D7;
  if (-1 < sVar1) {
LAB_80002e9e:
    if (sVar1 != -2) {
      FUN_80003048(1);
      if ((DAT_90011954 == '\0') && (FUN_80002eb2((int)sVar1), unaff_D7 != 0)) {
        FUN_80003048(1);
      }
      if (DAT_90011954 != '\0') goto code_r0x80002d88;
      goto LAB_80002de4;
    }
  }
  return;
code_r0x80002d88:
  FUN_80002eea((int)sVar1);
  if (unaff_D7 == 0) {
    FUN_80003048(1);
LAB_80002de4:
    if (sVar1 == 0x3e) {
      FUN_80002f44(&DAT_9000b600);
      FUN_80002a9e(0);
    }
    else if (sVar1 < 0x3f) {
      if (sVar1 == 0x23) {
        _DAT_900129a8 = 0;
        FUN_80016134(&DAT_90010100,0xe,0);
        FUN_80016134(&DAT_9000b600,0xe,0);
        FUN_80003048(1);
      }
    }
    else if (sVar1 == 0x3f) {
      _DAT_900129a8 = 1;
      FUN_80002f44(&DAT_90010100);
    }
  }
  goto LAB_80002e9e;
}


// ==== FUN_80002eb2 @ 80002eb2

void FUN_80002eb2(short param_1)

{
  if (((param_1 == 0x2f) || (param_1 == 0x22)) || (param_1 == 0x27)) {
    DAT_9000c6ec = (undefined1)param_1;
    DAT_900101d0 = 0;
    DAT_90011954 = 1;
  }
  return;
}


// ==== FUN_80002eea @ 80002eea

void FUN_80002eea(ushort param_1)

{
  if (DAT_9000c6ec == param_1) {
    (&DAT_900129ac)[DAT_900101d0] = 0;
    DAT_90011954 = 0;
  }
  else if (DAT_900101d0 < 10) {
    (&DAT_900129ac)[DAT_900101d0] = (char)param_1;
    DAT_900101d0 = DAT_900101d0 + 1;
  }
  return;
}


// ==== FUN_80002f44 @ 80002f44

/* WARNING: Removing unreachable block (ram,0x80002f9c) */

void FUN_80002f44(int param_1)

{
  int unaff_D7;
  short sVar1;
  
  sVar1 = 0;
  FUN_80016134(param_1,0xd,0);
  do {
    FUN_80003048(1);
    FUN_80002fea((int)(short)unaff_D7);
    if (unaff_D7 == 0) {
      do {
        FUN_80002fea(0);
        FUN_80003008(0);
        *(undefined1 *)(param_1 + sVar1) = 0;
        sVar1 = sVar1 + 1;
        FUN_80003048(1);
      } while (sVar1 != 0xd);
      *(undefined1 *)(param_1 + 0xd) = 0;
      return;
    }
  } while ((short)unaff_D7 != -2);
  return;
}


// ==== FUN_80002fea @ 80002fea

void FUN_80002fea(void)

{
  return;
}


// ==== FUN_80003008 @ 80003008

void FUN_80003008(short param_1)

{
  if ((((param_1 == 0x23) || (param_1 == 0x3f)) || (param_1 == 0x3e)) ||
     (((param_1 == 0x2f || (param_1 == 0x22)) || (param_1 == 0x27)))) {
    FUN_80003048(0xffffffff);
  }
  return;
}


// ==== FUN_80003048 @ 80003048

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_80003048(short param_1)

{
  int unaff_D7;
  
  if (_DAT_9000c8b0 == 0) {
    FUN_80000174(DAT_900081cc,&DAT_9000d9ec);
    if (unaff_D7 < 0) {
      _DAT_900100ec = unaff_D7;
      return;
    }
    FUN_800002ea(DAT_900081cc,(&PTR_s_INS91A_REF_90000118)[DAT_900000f0],0,&DAT_9000d9ec);
    if (unaff_D7 < 0) {
      if (DAT_900000f0 == 2) {
        DAT_900000f0 = 0;
        FUN_800002ea(DAT_900081cc,PTR_s_INS91A_REF_90000118,0,&DAT_9000d9ec);
      }
      if (unaff_D7 < 0) {
        _DAT_900100ec = unaff_D7;
        FUN_80000294(DAT_900081cc,&DAT_9000d9ec);
        return;
      }
    }
    _DAT_900100ee = (short)unaff_D7;
    DAT_9000c804 = _DAT_900100ee;
    _DAT_9000c8b0 = 1;
    FUN_8000033e(DAT_900081cc,(int)_DAT_900100ee,10,&DAT_90006860,&DAT_9000d9ec);
    DAT_900081d0 = 0;
    DAT_9000c6f0 = unaff_D7;
    _DAT_900100ec = unaff_D7;
  }
  if (DAT_900081d0 == DAT_9000c6f0) {
    FUN_80015e48(&DAT_90006866,&DAT_90006860,4);
    FUN_8000033e(DAT_900081cc,(int)DAT_9000c804,6,&DAT_90006864,&DAT_9000d9ec);
    DAT_900081d0 = 4;
    if (unaff_D7 < 1) {
      DAT_9000c6f0 = unaff_D7;
      _DAT_900100ec = unaff_D7;
      FUN_80000314(DAT_900081cc,(int)DAT_9000c804,&DAT_9000d9ec);
      FUN_80000294(DAT_900081cc,&DAT_9000d9ec);
      return;
    }
    DAT_9000c6f0 = unaff_D7 + 4;
    _DAT_900100ec = unaff_D7;
  }
  if (0 < param_1) {
    DAT_900081d0 = DAT_900081d0 + 1;
  }
  if (param_1 < 0) {
    DAT_900081d0 = DAT_900081d0 + -1;
  }
  return;
}


// ==== FUN_8000323c @ 8000323c

void FUN_8000323c(ushort param_1)

{
  uint uVar1;
  short sVar2;
  short sVar3;
  char *pcVar4;
  char *pcVar5;
  
  sVar3 = 0;
  if ((short)param_1 < 0) {
    param_1 = -param_1;
    sVar3 = -1;
  }
  uVar1 = (uint)param_1;
  pcVar4 = &DAT_9000c808;
  if (param_1 == 0) {
    DAT_9000c808 = 0x30;
    pcVar4 = &DAT_9000c809;
  }
  while (sVar2 = (short)uVar1, sVar2 != 0) {
    *pcVar4 = (char)((int)sVar2 % 10) + '0';
    pcVar4 = pcVar4 + 1;
    uVar1 = (int)sVar2 / 10 & 0xffff;
  }
  pcVar5 = pcVar4;
  if (sVar3 != 0) {
    pcVar5 = pcVar4 + 1;
    *pcVar4 = '-';
  }
  for (; (int)(pcVar5 + 0x6fff37f8) < 6; pcVar5 = pcVar5 + 1) {
    *pcVar5 = ' ';
  }
  *pcVar5 = '\0';
  FUN_800032ae(&DAT_9000c808);
  return;
}


// ==== FUN_800032ae @ 800032ae

void FUN_800032ae(int param_1)

{
  undefined1 uVar1;
  short sVar2;
  int iVar3;
  short sVar4;
  short unaff_D7w;
  int iVar5;
  
  sVar4 = 0;
  FUN_80016254(param_1);
  sVar2 = unaff_D7w + -1;
  if (0 < sVar2) {
    do {
      iVar5 = (int)sVar4;
      iVar3 = sVar2 - iVar5;
      uVar1 = *(undefined1 *)(param_1 + iVar3);
      *(undefined1 *)(param_1 + iVar3) = *(undefined1 *)(iVar5 + param_1);
      *(undefined1 *)(iVar5 + param_1) = uVar1;
      sVar4 = sVar4 + 1;
    } while (0 < -(sVar4 * 2 - (int)sVar2));
  }
  return;
}


// ==== FUN_80003308 @ 80003308

void FUN_80003308(uint param_1)

{
  byte bVar1;
  char cVar2;
  char *pcVar3;
  
  pcVar3 = &DAT_9000c808;
  if (param_1 == 0) {
    pcVar3 = &DAT_9000c809;
    DAT_9000c808 = 0x30;
  }
  for (; param_1 != 0; param_1 = param_1 >> 4) {
    bVar1 = (byte)param_1 & 0xf;
    if (bVar1 < 10) {
      cVar2 = bVar1 + 0x30;
    }
    else {
      cVar2 = bVar1 + 0x37;
    }
    *pcVar3 = cVar2;
    pcVar3 = pcVar3 + 1;
  }
  for (; (int)(pcVar3 + 0x6fff37f8) < 8; pcVar3 = pcVar3 + 1) {
    *pcVar3 = '0';
  }
  *pcVar3 = '\0';
  FUN_800032ae(&DAT_9000c808);
  return;
}


// ==== FUN_80003368 @ 80003368

void FUN_80003368(uint param_1)

{
  char *pcVar1;
  
  pcVar1 = &DAT_9000c808;
  if (param_1 == 0) {
    DAT_9000c808 = 0x30;
    pcVar1 = &DAT_9000c809;
  }
  for (; param_1 != 0; param_1 = param_1 / 10) {
    *pcVar1 = (char)(param_1 % 10) + '0';
    pcVar1 = pcVar1 + 1;
  }
  for (; (int)(pcVar1 + 0x6fff37f8) < 8; pcVar1 = pcVar1 + 1) {
    *pcVar1 = ' ';
  }
  *pcVar1 = '\0';
  FUN_800032ae(&DAT_9000c808);
  return;
}


// ==== FUN_800033bc @ 800033bc

void FUN_800033bc(void)

{
  do {
    FUN_800162cc(0,0x50);
    FUN_80015154(0);
  } while( true );
}


// ==== FUN_800033e0 @ 800033e0

void FUN_800033e0(byte *param_1,byte *param_2,int param_3)

{
  ushort uVar1;
  short sVar2;
  
  param_3 = param_3 + -1;
  if (param_3 != -1) {
    do {
      if ((*param_1 < 0x20) || (0x7f < *param_1)) {
        *param_2 = 0x5e;
        param_2[1] = (*param_1 & 0x7f) + 0x40;
        param_2 = param_2 + 1;
      }
      else {
        *param_2 = *param_1;
      }
      param_1 = param_1 + 1;
      param_2 = param_2 + 1;
      uVar1 = (ushort)((uint)param_3 >> 0x10);
      sVar2 = (short)param_3 + -1;
      param_3 = CONCAT22(uVar1,sVar2);
    } while ((sVar2 != -1) || (param_3 = (uint)uVar1 * 0x10000 + -1, uVar1 != 0));
  }
  *param_2 = 0;
  return;
}


// ==== ENTRY @ 80003434

void ENTRY(void)

{
  bool bVar1;
  ushort uVar2;
  undefined2 unaff_D7w;
  undefined4 uVar3;
  
  FUN_800079b4();
  FUN_8000364e();
  do {
    FUN_8000dcca();
    FUN_8000efae();
    do {
      bVar1 = true;
      if (DAT_90001364 == 1) {
        FUN_8000353e();
      }
      FUN_800099f6();
      FUN_80007fa2(0);
      switch(unaff_D7w) {
      case 0x118:
        DAT_90001364 = 0;
        FUN_80003610();
        uVar3 = 0x12;
        break;
      case 0x119:
        DAT_90001364 = 0;
        FUN_80003610();
        uVar3 = 0x11;
        break;
      case 0x11a:
        DAT_90001364 = 0;
        FUN_80003610();
        uVar3 = 0x13;
        break;
      case 0x11b:
        DAT_90001364 = 0;
        FUN_80003610();
        FUN_80003bf6();
        goto LAB_800034fc;
      default:
        bVar1 = false;
        goto LAB_800034fc;
      }
      FUN_80016294(uVar3,0x20000000);
LAB_800034fc:
    } while (!bVar1);
    FUN_800162cc(0,0);
    uVar2 = 0;
    do {
      FUN_80008700(uVar2 + 4);
      uVar2 = uVar2 + 1;
    } while (uVar2 < 0x10);
  } while( true );
}


// ==== FUN_8000353e @ 8000353e

void FUN_8000353e(void)

{
  FUN_8000f46a(1,0x28,0x18,7,0,&DAT_8000353a);
  FUN_8000f46a(1,0x30,0x18,7,0,&DAT_8000353c);
  FUN_8000f46a(1,0x29,0x18,7,0,&DAT_90007124);
  FUN_8000f574(0x4c,DAT_90011960 + 0x29,0x18,0,0,3);
  FUN_8000f574(0x5f,0,0,0,0,2);
  FUN_8000f574(0x5b,0,0,0,0,1);
  FUN_8000f574(0x5e,0x88,0,0,0,2);
  return;
}


// ==== FUN_80003610 @ 80003610

void FUN_80003610(void)

{
  FUN_8000f46a(1,0x28,0x18,7,0,"         ");
  FUN_8000f574(0x5f,1,0,0,0,2);
  return;
}


// ==== FUN_8000364e @ 8000364e

void FUN_8000364e(void)

{
  FUN_800162e4();
  FUN_8001628c();
  FUN_80016274(&DAT_90000128);
  FUN_800162e4();
  FUN_8001628c();
  FUN_80016274(&DAT_90001368);
  FUN_800162e4();
  FUN_8001628c();
  FUN_80016274(&DAT_90000308);
  FUN_800162e4();
  FUN_8001628c();
  FUN_80016274(&DAT_9000032c);
  return;
}


// ==== FUN_800036b8 @ 800036b8

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_800036b8(void)

{
  bool bVar1;
  bool bVar2;
  short sVar3;
  int iVar4;
  int iVar5;
  int iVar6;
  int unaff_D7;
  short unaff_A3w;
  int unaff_A4;
  
LAB_800036c6:
  iVar6 = 0;
  do {
    FUN_8000ebe4(iVar6);
    do {
      iVar5 = 0;
      bVar1 = false;
      if (iVar6 == 0) {
        FUN_80007fa2(0);
        unaff_A3w = 0x11a;
      }
      else if (iVar6 != 1) {
        FUN_800099f6();
        unaff_A3w = (short)unaff_D7;
        FUN_80007fa2(0);
        if ((unaff_A3w == 0x11f) || (unaff_A3w == 0xd)) {
          if (iVar6 == 0) {
            return;
          }
          FUN_80000294(DAT_9000c86c,&DAT_900100e8);
          if (unaff_A3w == 0xd) {
            return;
          }
          goto LAB_800036c6;
        }
      }
      iVar4 = _DAT_900100ec;
      DAT_900100ec = (short)((uint)unaff_D7 >> 0x10);
      sVar3 = DAT_900100ec;
      _DAT_900100ec = iVar4;
      if (iVar6 == 0) {
        FUN_800038f0(unaff_A3w);
        if (unaff_D7 < 0) {
          return;
        }
        DAT_9000c86c = unaff_D7;
        FUN_80000174();
        if (sVar3 == 0) {
          _DAT_900100ec = unaff_D7;
          FUN_8000b01a(unaff_D7 == 6);
          DAT_90006cd4 = 0;
          FUN_8000a284(1);
          if (-1 < unaff_D7) {
            FUN_8000880a();
            FUN_8000a1f6();
          }
          if ((DAT_900100f4 != 0) && (-1 < unaff_D7)) {
            FUN_80008f4a();
          }
          if ((DAT_900100f4 != 0) && (-1 < unaff_D7)) {
            FUN_80007eb0(1);
          }
          if (unaff_D7 < 0) {
            FUN_80000294(DAT_9000c86c,&DAT_900100e8);
            goto LAB_80003824;
          }
          iVar6 = 1;
        }
        else {
          _DAT_900100ec = unaff_D7;
          FUN_80007fa2((int)sVar3);
LAB_80003824:
          bVar1 = true;
        }
        iVar5 = unaff_D7;
        unaff_A4 = unaff_D7;
        bVar2 = false;
        if (bVar1) {
          return;
        }
      }
      else {
        bVar2 = bVar1;
        if (iVar6 == 1) {
          FUN_8000a530(0x28,1);
          FUN_80008700(0x18);
          if (-1 < unaff_D7) {
            iVar6 = 0;
            goto LAB_80003864;
          }
          FUN_80000294(DAT_9000c86c,&DAT_900100e8);
          iVar5 = unaff_D7;
          bVar2 = true;
        }
      }
      if (iVar5 == -5) {
        return;
      }
      if (iVar5 == -6) {
        return;
      }
    } while (bVar2);
  } while( true );
  while (iVar6 = iVar6 + 1, iVar6 < 0x50) {
LAB_80003864:
    if ((&DAT_90010118)[iVar6] == ' ') break;
  }
  (&DAT_90010118)[iVar6] = 0;
  FUN_800007ac(DAT_9000c86c,&DAT_90010118,&DAT_900100e8);
  _DAT_900100ec = unaff_D7;
  if (sVar3 != 0) {
    FUN_80007fa2((int)sVar3,unaff_A4);
  }
  FUN_80000294(DAT_9000c86c,&DAT_900100e8);
  return;
}


// ==== FUN_800038f0 @ 800038f0

void FUN_800038f0(void)

{
  return;
}


// ==== FUN_8000390e @ 8000390e

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_8000390e(void)

{
  bool bVar1;
  bool bVar2;
  short sVar3;
  uint uVar4;
  int iVar5;
  uint uVar6;
  uint uVar7;
  uint unaff_D7;
  ushort unaff_A5w;
  
LAB_8000391e:
  uVar7 = 0;
  do {
    FUN_8000edfe(uVar7);
    do {
      uVar6 = 0;
      bVar1 = false;
      if (uVar7 == 0) {
        FUN_80007fa2(0);
        unaff_A5w = 0x11a;
      }
      else if (uVar7 != 1) {
        FUN_800099f6();
        unaff_A5w = (ushort)unaff_D7;
        FUN_80007fa2(0);
        if ((unaff_A5w == 0x11f) || (unaff_A5w == 0xd)) {
          if (uVar7 == 0) {
            return;
          }
          FUN_80000294(DAT_9000c86c,&DAT_900100e8);
          if (unaff_A5w == 0xd) {
            return;
          }
          goto LAB_8000391e;
        }
      }
      uVar4 = _DAT_900100ec;
      if (uVar7 == 1) {
        FUN_8000a530(0x28,1);
        if ((unaff_D7 == 0xfffffffb) || (unaff_D7 == 0xfffffffa)) {
          FUN_80000294(DAT_9000c86c,&DAT_900100e8);
        }
        FUN_80007fa2(0);
        if (-1 < (int)unaff_D7) {
          uVar7 = 2;
          FUN_80007eb0(0);
        }
        if (unaff_D7 == 0xfffffffb) {
          return;
        }
        uVar6 = unaff_D7;
        bVar2 = -1 >= (int)unaff_D7;
        if (unaff_D7 == 0xfffffffa) {
          return;
        }
      }
      else {
        DAT_900100ec = (short)(unaff_D7 >> 0x10);
        sVar3 = DAT_900100ec;
        _DAT_900100ec = uVar4;
        bVar2 = bVar1;
        if (uVar7 < 2) {
          if (uVar7 == 0) {
            FUN_800038f0(unaff_A5w);
            if ((int)unaff_D7 < 0) {
              return;
            }
            DAT_9000c86c = unaff_D7;
            FUN_80000174();
            if (sVar3 == 0) {
              _DAT_900100ec = unaff_D7;
              FUN_8000b01a(unaff_D7 == 6);
              DAT_90006cd4 = 0;
              FUN_8000a284(1);
              if (-1 < (int)unaff_D7) {
                FUN_8000880a();
                FUN_8000a1f6();
              }
              if ((DAT_900100f4 != 0) && (-1 < (int)unaff_D7)) {
                FUN_80008f4a();
              }
              if ((DAT_900100f4 != 0) && (-1 < (int)unaff_D7)) {
                FUN_80007eb0(1);
              }
              if ((int)unaff_D7 < 0) {
                FUN_80000294(DAT_9000c86c,&DAT_900100e8);
                goto LAB_80003a96;
              }
              uVar7 = 1;
            }
            else {
              _DAT_900100ec = unaff_D7;
              FUN_80007fa2((int)sVar3);
LAB_80003a96:
              bVar1 = true;
            }
            uVar6 = unaff_D7;
            bVar2 = false;
            if (bVar1) {
              return;
            }
          }
        }
        else if (uVar7 == 2) {
          if (unaff_A5w == 0x121) {
            uVar7 = 1;
          }
          else {
            if (unaff_A5w < 0x122) {
              if (unaff_A5w == 10) {
LAB_80003b32:
                FUN_80007c28(&DAT_8000390c,0);
                iVar5 = 0;
                goto LAB_80003b4a;
              }
            }
            else if (unaff_A5w == 0x122) goto LAB_80003b32;
            FUN_8000aacc(unaff_A5w,0);
            uVar6 = unaff_D7;
            bVar2 = true;
          }
        }
      }
      if (uVar6 == 0xfffffffb) {
        uVar7 = 0;
        bVar2 = false;
      }
      else if (uVar6 == 0xfffffffa) {
        return;
      }
    } while (bVar2);
  } while( true );
  while (iVar5 = iVar5 + 1, iVar5 < 0x50) {
LAB_80003b4a:
    if ((&DAT_90010118)[iVar5] == ' ') break;
  }
  (&DAT_90010118)[iVar5] = 0;
  FUN_800007c6(DAT_9000c86c,&DAT_90010118,&DAT_900100e8);
  _DAT_900100ec = unaff_D7;
  if (sVar3 != 0) {
    FUN_80007fa2((int)sVar3,unaff_D7 & 0xff);
  }
  FUN_80000294(DAT_9000c86c,&DAT_900100e8);
  return;
}


// ==== FUN_80003bf6 @ 80003bf6

void FUN_80003bf6(void)

{
  FUN_800081e0(0x12);
  FUN_80007c28(&DAT_80003bf4,0);
  FUN_8000826a(0);
  FUN_80000e54();
  FUN_80016294(0x10,0x20000000);
  return;
}


// ==== FUN_80003c36 @ 80003c36

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_80003c36(void)

{
  bool bVar1;
  bool bVar2;
  short sVar3;
  uint uVar4;
  int iVar5;
  uint uVar6;
  uint uVar7;
  uint unaff_D7;
  ushort unaff_A5w;
  
LAB_80003c46:
  uVar7 = 0;
  do {
    FUN_8000ecce(uVar7);
    do {
      uVar6 = 0;
      bVar1 = false;
      if (uVar7 == 0) {
        FUN_80007fa2(0);
        unaff_A5w = 0x11a;
      }
      else if (uVar7 != 1) {
        FUN_800099f6();
        unaff_A5w = (ushort)unaff_D7;
        FUN_80007fa2(0);
        if ((unaff_A5w == 0x11f) || (unaff_A5w == 0xd)) {
          if (uVar7 == 0) {
            return;
          }
          FUN_80000294(DAT_9000c86c,&DAT_900100e8);
          if (unaff_A5w == 0xd) {
            return;
          }
          goto LAB_80003c46;
        }
      }
      uVar4 = _DAT_900100ec;
      if (uVar7 == 1) {
        FUN_8000a530(0x28,0);
        if ((unaff_D7 == 0xfffffffb) || (unaff_D7 == 0xfffffffa)) {
          FUN_80000294(DAT_9000c86c,&DAT_900100e8);
        }
        FUN_80007fa2(0);
        if (-1 < (int)unaff_D7) {
          uVar7 = 2;
          FUN_80007eb0(0);
        }
        if (unaff_D7 == 0xfffffffb) {
          return;
        }
        uVar6 = unaff_D7;
        bVar2 = -1 >= (int)unaff_D7;
        if (unaff_D7 == 0xfffffffa) {
          return;
        }
      }
      else {
        DAT_900100ec = (short)(unaff_D7 >> 0x10);
        sVar3 = DAT_900100ec;
        _DAT_900100ec = uVar4;
        bVar2 = bVar1;
        if (uVar7 < 2) {
          if (uVar7 == 0) {
            FUN_800038f0(unaff_A5w);
            if ((int)unaff_D7 < 0) {
              return;
            }
            DAT_9000c86c = unaff_D7;
            FUN_80000174();
            if (sVar3 == 0) {
              _DAT_900100ec = unaff_D7;
              FUN_8000b01a(unaff_D7 == 6);
              DAT_90006cd4 = 0;
              FUN_8000a284(1);
              if (-1 < (int)unaff_D7) {
                FUN_8000880a();
                FUN_8000a1f6();
              }
              if ((DAT_900100f4 != 0) && (-1 < (int)unaff_D7)) {
                FUN_80008f4a();
              }
              if ((DAT_900100f4 != 0) && (-1 < (int)unaff_D7)) {
                FUN_80007eb0(1);
              }
              if ((int)unaff_D7 < 0) {
                FUN_80000294(DAT_9000c86c,&DAT_900100e8);
                goto LAB_80003dbe;
              }
              uVar7 = 1;
            }
            else {
              _DAT_900100ec = unaff_D7;
              FUN_80007fa2((int)sVar3);
LAB_80003dbe:
              bVar1 = true;
            }
            uVar6 = unaff_D7;
            bVar2 = false;
            if (bVar1) {
              return;
            }
          }
        }
        else if (uVar7 == 2) {
          if (unaff_A5w == 0x121) {
            uVar7 = 1;
          }
          else {
            if (unaff_A5w < 0x122) {
              if (unaff_A5w == 10) {
LAB_80003e58:
                FUN_80007c28(&DAT_80003c34,0);
                iVar5 = 0;
                goto LAB_80003e70;
              }
            }
            else if (unaff_A5w == 0x122) goto LAB_80003e58;
            FUN_8000aacc(unaff_A5w,0);
            uVar6 = unaff_D7;
            bVar2 = true;
          }
        }
      }
      if (uVar6 == 0xfffffffb) {
        uVar7 = 0;
        bVar2 = false;
      }
      else if (uVar6 == 0xfffffffa) {
        return;
      }
    } while (bVar2);
  } while( true );
  while (iVar5 = iVar5 + 1, iVar5 < 0x50) {
LAB_80003e70:
    if ((&DAT_90010118)[iVar5] == ' ') break;
  }
  (&DAT_90010118)[iVar5] = 0;
  FUN_80000792(DAT_9000c86c,&DAT_90010118,&DAT_900100e8);
  _DAT_900100ec = unaff_D7;
  if (sVar3 != 0) {
    FUN_80007fa2((int)sVar3,unaff_D7 & 0xff);
  }
  FUN_80000294(DAT_9000c86c,&DAT_900100e8);
  return;
}


// ==== FUN_80003f22 @ 80003f22

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_80003f22(void)

{
  bool bVar1;
  uint uVar2;
  short sVar3;
  uint uVar4;
  uint unaff_D7;
  int iVar5;
  int iVar6;
  undefined4 uVar7;
  short local_1c;
  int local_16;
  ushort local_12;
  undefined1 auStack_10 [8];
  undefined1 auStack_8 [4];
  
  FUN_80016134(auStack_10,0xb,0x20);
  local_16 = 0;
  local_1c = 0;
  do {
    FUN_8000e396(local_16);
    do {
      uVar4 = 0;
      bVar1 = true;
      if ((local_16 != 3) && (local_16 != 5)) {
        FUN_800099f6();
        local_12 = (ushort)unaff_D7;
        FUN_80007fa2(0);
        if ((local_12 == 0x11f) || (local_12 == 0xd)) {
          if (0 < local_16) {
            FUN_80000294(DAT_9000c86c,&DAT_900100e8);
          }
          if ((2 < local_16) && (DAT_9000c86c != DAT_9000c870)) {
            FUN_80000294(DAT_9000c870,&DAT_900100e8);
          }
          if (local_16 == 0) {
            return;
          }
          if (local_12 == 0xd) {
            return;
          }
          local_16 = 0;
          break;
        }
      }
      uVar2 = _DAT_900100ec;
      DAT_900100ec = (short)(unaff_D7 >> 0x10);
      sVar3 = DAT_900100ec;
      _DAT_900100ec = uVar2;
      iVar5 = local_16;
      switch(local_16) {
      case 0:
        FUN_80005430(local_12);
        uVar4 = unaff_D7;
        if ((int)unaff_D7 < 0) {
LAB_800043a2:
          bVar1 = false;
        }
        else {
          FUN_80007c28(&DAT_80003f1c,0);
          FUN_8000826a(0x19);
          DAT_9000c86c = unaff_D7;
          FUN_80000174();
          if (sVar3 != 0) {
            iVar6 = (int)sVar3;
            _DAT_900100ec = unaff_D7;
            goto LAB_80004148;
          }
          _DAT_900100ec = unaff_D7;
          FUN_8000996c(unaff_D7 == 6);
          DAT_90006cd4 = 0;
          FUN_80009082(1);
          if (-1 < (int)unaff_D7) {
            FUN_8000880a();
            if ((-1 < (int)unaff_D7) && (unaff_D7 == 6)) {
              FUN_8000a1f6();
            }
            if ((DAT_900100f4 != 0) && (-1 < (int)unaff_D7)) {
              FUN_80008f4a();
            }
          }
          if ((int)unaff_D7 < 0) {
            FUN_80000294();
          }
          else {
            iVar5 = local_16 + 1;
            if (DAT_900100f4 != 0) {
              uVar7 = 1;
              goto LAB_8000415a;
            }
          }
        }
        break;
      case 1:
        local_1c = 0;
        FUN_800089a4(local_12,1);
        uVar4 = unaff_D7;
        if ((int)unaff_D7 < 0) goto LAB_800043a2;
        if (DAT_9000c86c == 6) {
          if (-1 < *(char *)(DAT_9000131a + 0xb + unaff_D7 * 0x20)) {
LAB_80004154:
            uVar7 = 0;
LAB_8000415a:
            local_16 = local_16 + 1;
            FUN_80007eb0(uVar7);
            uVar4 = unaff_D7;
            iVar5 = local_16;
            break;
          }
        }
        else if (DAT_9000c87b != '@') goto LAB_80004154;
        iVar6 = 5;
LAB_80004148:
        FUN_80007fa2(iVar6);
        uVar4 = unaff_D7;
        break;
      case 2:
        FUN_80005430(local_12);
        uVar4 = unaff_D7;
        if ((int)unaff_D7 < 0) goto LAB_8000437a;
        FUN_80007c28(&DAT_80003f1c,0);
        FUN_8000826a(0x19);
        DAT_9000c870 = unaff_D7;
        if ((DAT_9000c86c == unaff_D7) || (FUN_80000174(), _DAT_900100ec = unaff_D7, sVar3 == 0)) {
LAB_80004342:
          iVar5 = local_16 + 1;
        }
        else {
LAB_8000432c:
          _DAT_900100ec = unaff_D7;
          FUN_80007fa2((int)sVar3);
          uVar4 = 0xfffffffb;
        }
        break;
      case 3:
        FUN_80007c28(&DAT_80003f1c,0);
        FUN_80007c28(&DAT_80003f1d,8);
        FUN_80009b00(&DAT_9000c874,&DAT_9000c880,6);
        FUN_80007fa2(0);
        uVar4 = unaff_D7;
        if (-1 < (int)unaff_D7) {
          if (DAT_9000c86c == DAT_9000c870) {
            for (iVar5 = 0; ((&DAT_9000c874)[iVar5] == (&DAT_9000c880)[iVar5] && (iVar5 < 8));
                iVar5 = iVar5 + 1) {
            }
            if (iVar5 == 8) {
              FUN_80007fa2(4,DAT_9000c86c);
              local_16 = 1;
              iVar5 = local_16;
              break;
            }
          }
          FUN_80015e48(&DAT_9000c874,auStack_10,6);
          FUN_80015e48(&DAT_9000c87c,auStack_8,3);
          FUN_8000050c(DAT_9000c870,&DAT_9000c880,&DAT_900100e8);
          _DAT_900100ec = unaff_D7;
          iVar5 = local_16 + 1;
          if (sVar3 == 0) {
            FUN_80007fa2(3,0);
            local_1c = _DAT_900100ee;
          }
        }
        break;
      case 4:
        if (local_12 != 0x121) {
          if (local_12 < 0x122) {
            if (local_12 == 10) {
LAB_800042e2:
              FUN_80007d86(0);
              FUN_80007c28(&DAT_80003f1c,0);
              if (local_1c != 0) {
                FUN_800003d4(DAT_9000c870,&DAT_9000c880,&DAT_900100e8);
                if (sVar3 != 0) goto LAB_8000432c;
                local_1c = 0;
                _DAT_900100ec = unaff_D7;
              }
              goto LAB_80004342;
            }
          }
          else if (local_12 == 0x122) goto LAB_800042e2;
LAB_8000437a:
          if ((local_12 == 0x164) || (local_12 == 0x166)) {
            FUN_800089a4(local_12,1);
            uVar4 = unaff_D7;
          }
          goto LAB_800043a2;
        }
        FUN_80000294(DAT_9000c86c,&DAT_900100e8);
        if (DAT_9000c86c != DAT_9000c870) {
          FUN_80000294(DAT_9000c870,&DAT_900100e8);
        }
        local_16 = 0;
        iVar5 = local_16;
        break;
      case 5:
        FUN_80007c28(&DAT_80003f1c,0);
        FUN_800044e0(DAT_9000c86c,DAT_9000c870,&DAT_9000c874,&DAT_9000c880);
        if ((int)_DAT_900100ec < 0) {
          FUN_8000826a(0x19);
          iVar5 = -0xb;
          uVar4 = DAT_9000c870;
        }
        else {
          FUN_80000724(DAT_9000c86c,&DAT_9000c874,DAT_9000c870,&DAT_9000c880,&DAT_900100e8);
          _DAT_900100ec = unaff_D7;
          if ((sVar3 == 0) || (sVar3 == -0xc)) goto LAB_8000449e;
          DAT_900100ef = (char)unaff_D7;
          if (((DAT_900100ef == '\b') || (DAT_900100ef == '\t')) && (sVar3 == -2)) {
            sVar3 = -0xb;
          }
          FUN_8000826a(0x19);
          uVar4 = _DAT_900100ec & 0xff;
          iVar5 = (int)sVar3;
        }
        FUN_80007fa2(iVar5,uVar4);
        goto LAB_8000449e;
      }
      local_16 = iVar5;
      if (uVar4 == 0xfffffffb) {
        FUN_80000294(DAT_9000c86c,&DAT_900100e8);
        if (DAT_9000c86c != DAT_9000c870) {
          FUN_80000294(DAT_9000c870,&DAT_900100e8);
        }
        local_16 = 0;
      }
      else if (uVar4 == 0xfffffffa) {
LAB_8000449e:
        FUN_80000294(DAT_9000c86c,&DAT_900100e8);
        if (DAT_9000c86c != DAT_9000c870) {
          FUN_80000294(DAT_9000c870,&DAT_900100e8);
        }
        return;
      }
    } while (!bVar1);
  } while( true );
}


// ==== FUN_800044e0 @ 800044e0

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */
/* WARNING: Restarted to delay deadcode elimination for space: ram */

void FUN_800044e0(int param_1,undefined4 param_2,undefined4 param_3)

{
  int iVar1;
  int iVar2;
  uint uVar3;
  uint unaff_D7;
  undefined1 auStack_44 [32];
  undefined1 auStack_24 [32];
  
  iVar2 = DAT_9000131a;
  FUN_8000050c(param_1,param_3,&DAT_900100e8);
  _DAT_900100ec = unaff_D7;
  if (-1 < (int)unaff_D7) {
    if ((param_1 == 6) || (param_1 == 7)) {
      FUN_80000532(param_1,unaff_D7,unaff_D7,auStack_44,&DAT_900100e8);
      uVar3 = 0;
      do {
        iVar1 = uVar3 * 0x20;
        if ((((DAT_9000c874 == *(char *)(iVar2 + iVar1)) &&
             (DAT_9000c875 == *(char *)(iVar2 + 1 + iVar1))) &&
            (DAT_9000c876 == *(char *)(iVar2 + 2 + iVar1))) &&
           (((DAT_9000c877 == *(char *)(iVar2 + 3 + iVar1) &&
             (DAT_9000c878 == *(char *)(iVar2 + 4 + iVar1))) &&
            ((DAT_9000c879 == *(char *)(iVar2 + 5 + iVar1) &&
             ((DAT_9000c87a == *(char *)(iVar2 + 6 + iVar1) &&
              (DAT_9000c87b == *(char *)(iVar2 + 7 + iVar1))))))))) break;
        uVar3 = uVar3 + 1;
      } while (uVar3 < 0x400);
      uVar3 = *(uint *)(iVar2 + 0xc + uVar3 * 0x20);
    }
    else {
      FUN_80000532(param_1,unaff_D7,unaff_D7,auStack_24,&DAT_900100e8);
      uVar3 = 0;
      do {
        iVar1 = uVar3 * 0x20;
        if (((((DAT_9000c874 == *(char *)(iVar2 + iVar1)) &&
              (DAT_9000c875 == *(char *)(iVar2 + 1 + iVar1))) &&
             (DAT_9000c876 == *(char *)(iVar2 + 2 + iVar1))) &&
            ((DAT_9000c877 == *(char *)(iVar2 + 3 + iVar1) &&
             (DAT_9000c878 == *(char *)(iVar2 + 4 + iVar1))))) &&
           ((DAT_9000c879 == *(char *)(iVar2 + 5 + iVar1) &&
            ((DAT_9000c87a == *(char *)(iVar2 + 6 + iVar1) &&
             (DAT_9000c87b == *(char *)(iVar2 + 7 + iVar1))))))) break;
        uVar3 = uVar3 + 1;
      } while (uVar3 < 0x400);
      uVar3 = *(uint *)(iVar2 + 0x16 + uVar3 * 0x20);
    }
    if (-1 < (int)unaff_D7) {
      FUN_8000060e(param_2,&DAT_900100e8);
      if (-1 < (int)unaff_D7) {
        if (unaff_D7 < uVar3) {
          _DAT_900100ec = CONCAT22(0xfff5,(short)unaff_D7);
          _DAT_900100ec = CONCAT31(_DAT_900100ec,(char)param_2);
        }
        else {
          _DAT_900100ec = 0;
        }
      }
    }
  }
  return;
}


// ==== FUN_80004696 @ 80004696

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_80004696(void)

{
  uint uVar1;
  bool bVar2;
  short sVar3;
  uint uVar4;
  uint unaff_D7;
  short sVar5;
  int iVar6;
  int iVar7;
  undefined4 uVar8;
  int local_8;
  
  iVar6 = 0;
  local_8 = 0;
  do {
    FUN_8000e594(iVar6,local_8);
    iVar7 = iVar6;
    do {
      uVar4 = 0;
      bVar2 = true;
      FUN_800099f6();
      sVar5 = (short)unaff_D7;
      FUN_80007fa2(0);
      uVar1 = _DAT_900100ec;
      if ((sVar5 == 0x11f) || (sVar5 == 0xd)) {
        if (0 < iVar7) {
          FUN_80000294(DAT_9000c86c,&DAT_900100e8);
        }
        if (iVar7 == 0) {
          return;
        }
        if (sVar5 == 0xd) {
          return;
        }
        iVar6 = 0;
        break;
      }
      iVar6 = iVar7;
      if (iVar7 == 1) {
        local_8 = 0;
        if (sVar5 == 0x118) {
          local_8 = 1;
          goto LAB_8000487a;
        }
        FUN_800089a4(unaff_D7 & 0xffff,1);
        uVar4 = unaff_D7;
        if ((int)unaff_D7 < 0) goto LAB_8000494c;
        if (DAT_9000c86c == 6) {
          if (*(char *)(DAT_9000131a + 0xb + unaff_D7 * 0x20) < '\0') {
LAB_80004866:
            FUN_80007fa2(5,DAT_9000c86c);
            bVar2 = false;
            goto LAB_8000494e;
          }
        }
        else if (DAT_9000c87b == '@') goto LAB_80004866;
LAB_8000487a:
        uVar8 = 0;
LAB_8000487e:
        FUN_80007eb0(uVar8);
        iVar6 = iVar7 + 1;
      }
      else {
        DAT_900100ec = (short)(unaff_D7 >> 0x10);
        sVar3 = DAT_900100ec;
        _DAT_900100ec = uVar1;
        if (iVar7 < 2) {
          if (iVar7 == 0) {
            FUN_80005430();
            uVar4 = unaff_D7;
            if ((int)unaff_D7 < 0) {
LAB_8000494c:
              bVar2 = false;
            }
            else {
              FUN_80007c28(&DAT_80004694,0);
              FUN_8000826a(0x19);
              DAT_9000c86c = unaff_D7;
              FUN_80000174();
              if (sVar3 == 0) {
                _DAT_900100ec = unaff_D7;
                FUN_8000996c(unaff_D7 == 6);
                DAT_90006cd4 = 0;
                FUN_80009082(1);
                if (-1 < (int)unaff_D7) {
                  FUN_8000880a();
                  if ((-1 < (int)unaff_D7) && (unaff_D7 == 6)) {
                    FUN_8000a1f6();
                  }
                  if ((DAT_900100f4 != 0) && (-1 < (int)unaff_D7)) {
                    FUN_80008f4a();
                  }
                }
                if ((int)unaff_D7 < 0) {
                  FUN_80000294(DAT_9000c86c,&DAT_900100e8);
                }
                else {
                  iVar6 = 1;
                  if (DAT_900100f4 != 0) {
                    uVar8 = 1;
                    goto LAB_8000487e;
                  }
                }
              }
              else {
                _DAT_900100ec = unaff_D7;
                FUN_80007fa2((int)sVar3);
              }
            }
          }
        }
        else if (iVar7 == 2) {
          uVar1 = unaff_D7 & 0xffff;
          if (uVar1 != 0x121) {
            if (uVar1 < 0x122) {
              if (uVar1 == 10) {
LAB_800048ac:
                FUN_80007d86(0);
                FUN_80007c28(&DAT_80004694,0);
                FUN_8000826a(0);
                if (local_8 == 1) {
                  FUN_80004974();
                }
                else {
                  FUN_800003d4(DAT_9000c86c,&DAT_9000c874,&DAT_900100e8);
                  _DAT_900100ec = unaff_D7;
                  if (sVar3 != 0) {
                    FUN_80007fa2((int)sVar3,unaff_D7 & 0xff);
                  }
                }
                FUN_80000294(DAT_9000c86c,&DAT_900100e8);
                return;
              }
            }
            else if (uVar1 == 0x122) goto LAB_800048ac;
            if ((sVar5 == 0x164) || (sVar5 == 0x166)) {
              FUN_800089a4();
              uVar4 = unaff_D7;
            }
            goto LAB_8000494c;
          }
          iVar6 = 1;
        }
      }
LAB_8000494e:
      if (uVar4 == 0xfffffffb) {
        iVar6 = 0;
      }
      else if (uVar4 == 0xfffffffa) {
        return;
      }
      iVar7 = iVar6;
    } while (!bVar2);
  } while( true );
}


// ==== FUN_80004974 @ 80004974

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_80004974(void)

{
  int iVar1;
  int iVar2;
  uint unaff_D7;
  int iVar3;
  int local_8;
  
  iVar3 = 0;
  local_8 = 0;
  do {
    FUN_80000532(DAT_9000c86c,local_8 + 1,iVar3 + 0x80,DAT_9000131a,&DAT_900100e8);
    iVar1 = DAT_9000131a;
    DAT_900100ec = (short)(unaff_D7 >> 0x10);
    _DAT_900100ec = unaff_D7;
    if (DAT_900100ec != 0) {
      iVar3 = (int)DAT_900100ec;
      FUN_80007fa2(iVar3,unaff_D7 & 0xff);
      return;
    }
    if ((int)unaff_D7 < 1) {
      return;
    }
    iVar2 = 0;
    if (0 < (int)unaff_D7) {
      do {
        if (DAT_9000c86c == 6) {
          if (-1 < *(char *)(iVar1 + 0xb + iVar2 * 0x20)) {
LAB_800049f0:
            FUN_800003d4(DAT_9000c86c,iVar1 + iVar2 * 0x20,&DAT_900100e8);
          }
        }
        else if (*(char *)(iVar1 + 7 + iVar2 * 0x20) != '@') goto LAB_800049f0;
        iVar2 = iVar2 + 1;
      } while (iVar2 < (int)unaff_D7);
    }
    local_8 = local_8 + 0x80;
    iVar3 = iVar3 + 0x80;
    if (0x3ff < iVar3) {
      return;
    }
  } while( true );
}


// ==== FUN_80004ce2 @ 80004ce2

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

uint FUN_80004ce2(int param_1)

{
  byte bVar1;
  uint uVar2;
  int iVar3;
  int iVar4;
  uint uVar5;
  int iVar6;
  uint unaff_D7;
  short sVar7;
  
  iVar3 = DAT_9000131e;
  FUN_8000f022();
  FUN_8000efae();
  FUN_800162cc(0,0x10);
  DAT_900100fc = 0;
  DAT_90006cd4 = 0;
  FUN_8000efbe(1,4,0x10);
  FUN_8000996c(param_1 == 6);
  FUN_8000826a(0x19);
  FUN_80007c28(&DAT_80004a54,1);
  FUN_80007c28(&DAT_80004a54,2);
  uVar2 = FUN_80007d86(0);
  uVar5 = 10;
  do {
    do {
      while( true ) {
        sVar7 = (short)unaff_D7;
        if ((DAT_90006cd4 != 0) &&
           (uVar2 = CONCAT22((short)(uVar2 >> 0x10),DAT_900100fc) & 0xffff000f,
           (DAT_900100fc & 0xf) == 0)) {
          uVar2 = FUN_800099f6();
          uVar5 = unaff_D7 & 0xffff;
        }
        if (uVar5 == 0xd) {
          return uVar2;
        }
        if (uVar5 < 0xe) break;
        if (uVar5 == 0x11f) {
          return uVar2;
        }
      }
    } while (uVar5 != 10);
    iVar6 = 0;
    do {
      if (DAT_900100f4 <= DAT_900100fc) break;
      FUN_8000939a(DAT_900100fc,DAT_9000131e,1,param_1 == 6);
      uVar2 = _DAT_900100ec;
      if (param_1 != 6) {
        FUN_80016134(&DAT_900012c8,0x50,0);
        FUN_8000057a(param_1,DAT_900100fc + 1,DAT_900100fc + 1,0x28,&DAT_900012c8,&DAT_900100e8);
        DAT_900100ec = (short)(unaff_D7 >> 0x10);
        _DAT_900100ec = unaff_D7;
        if (DAT_900100ec == 0) {
          bVar1 = DAT_900012c8;
          for (iVar4 = 0; ((0x1f < bVar1 && ((&DAT_900012c8)[iVar4] < 0x7f)) && (iVar4 < 0x28));
              iVar4 = iVar4 + 1) {
            *(byte *)(iVar3 + 0x28 + iVar4) = (&DAT_900012c8)[iVar4];
            bVar1 = (&DAT_900012c9)[iVar4];
          }
          *(undefined1 *)(iVar3 + 0x28 + iVar4) = 0;
          uVar2 = _DAT_900100ec;
        }
        else {
          uVar2 = unaff_D7;
          if ((DAT_900100ec != -0x31) && (uVar2 = unaff_D7, DAT_900100ec != -3)) {
            iVar3 = (int)DAT_900100ec;
            uVar2 = FUN_80007fa2(iVar3,param_1);
            return uVar2;
          }
        }
      }
      _DAT_900100ec = uVar2;
      FUN_80000d72(DAT_9000131e);
      FUN_8000f254(0,DAT_900100fc % 0x37,7,0,DAT_9000131e);
      if (0xf < DAT_900100fc) {
        FUN_8000f072(2,1);
      }
      uVar2 = FUN_80009a4a();
      if ((sVar7 == 0xe3) || (sVar7 == 0x20)) {
        while( true ) {
          if (sVar7 == 0x20) {
            return uVar2;
          }
          uVar2 = FUN_80009a4a();
          if (sVar7 == 0xe3) break;
          if (sVar7 == 0xd) {
            return uVar2;
          }
          if (sVar7 == 0x11f) {
            return uVar2;
          }
        }
      }
      uVar5 = unaff_D7 & 0xffff;
      iVar6 = iVar6 + 1;
      DAT_900100fc = DAT_900100fc + 1;
    } while (iVar6 < 0x10);
    DAT_90006cd4 = DAT_90006cd4 + 1;
    if (DAT_900100f4 <= DAT_900100fc) {
      return uVar2;
    }
  } while( true );
}


// ==== FUN_80005430 @ 80005430

void FUN_80005430(undefined2 param_1)

{
  switch(param_1) {
  case 0x118:
    break;
  case 0x119:
    break;
  case 0x11a:
    break;
  case 0x11b:
    break;
  case 0x11c:
  }
  return;
}


// ==== FUN_80005476 @ 80005476

/* WARNING: Removing unreachable block (ram,0x80005738) */
/* WARNING: Removing unreachable block (ram,0x80005742) */
/* WARNING: Removing unreachable block (ram,0x800054cc) */
/* WARNING: Removing unreachable block (ram,0x800054e0) */
/* WARNING: Removing unreachable block (ram,0x800054ec) */

void FUN_80005476(void)

{
  short unaff_D7w;
  
  FUN_8000e200(0,0);
  FUN_800099f6();
  FUN_80007fa2(0);
  if ((unaff_D7w == 0x11f) || (unaff_D7w == 0xd)) {
    FUN_80008700(0x15);
    return;
  }
                    /* WARNING: Could not recover jumptable at 0x800054fc. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (*(code *)((int)&switchD_800054fc::switchdataD_80005500 +
            (int)(short)switchD_800054fc::switchdataD_80005500))();
  return;
}


// ==== FUN_80005750 @ 80005750

void FUN_80005750(void)

{
  return;
}


// ==== FUN_80005758 @ 80005758

void FUN_80005758(int param_1,int param_2)

{
  ushort uVar1;
  int iVar2;
  int unaff_D7;
  undefined1 local_5;
  
  FUN_80016134(param_1,param_2,0x20);
  for (; 0 < param_2; param_2 = param_2 - iVar2) {
    FUN_80001c24(1);
    uVar1 = (ushort)unaff_D7 & 0xff7f;
    if (((uVar1 == 0xff00) || (uVar1 == 0x1a)) || ((short)uVar1 < 0)) break;
    if ((uVar1 == 0xd) || (uVar1 == 10)) {
      iVar2 = param_2 % 0x50;
    }
    else {
      local_5 = (undefined1)uVar1;
      FUN_800033e0(&local_5,param_1,1);
      *(undefined1 *)(param_1 + unaff_D7) = 0x20;
      iVar2 = unaff_D7;
    }
    param_1 = iVar2 + param_1;
  }
  if (0 < param_2 + 2) {
    FUN_80016134(param_1,param_2 + 2,0);
  }
  return;
}


// ==== FUN_800057fe @ 800057fe

/* WARNING: Removing unreachable block (ram,0x800059b8) */
/* WARNING: Removing unreachable block (ram,0x800059c0) */
/* WARNING: Removing unreachable block (ram,0x800059ba) */

void FUN_800057fe(undefined4 param_1)

{
  char cVar1;
  int iVar2;
  short unaff_D7w;
  char *pcVar3;
  undefined4 uVar4;
  char local_507;
  char local_506;
  char local_505 [1279];
  char local_6;
  
  DAT_9000c298 = 0;
  DAT_900100f8 = 0;
  DAT_9000d9e8 = 0;
  DAT_9000c260 = 0;
  FUN_8000e200(0,1);
  FUN_8000fc92(4,0x13);
  FUN_8000f46a(0,0,0,7,0,&DAT_80005474);
  FUN_80005758(&local_506,0x500);
  if (((unaff_D7w == -0x100) || (unaff_D7w == 0x1a)) || (-1 < unaff_D7w)) {
    local_507 = local_6;
    local_6 = '\0';
    FUN_800100e4(0,4,&local_506);
    if (unaff_D7w != -0x100) {
      while (unaff_D7w != 0x1a) {
        local_506 = local_507;
        if (local_507 == '\0') {
          uVar4 = 0x500;
          pcVar3 = &local_506;
        }
        else {
          uVar4 = 0x4ff;
          pcVar3 = local_505;
        }
        FUN_80005758(pcVar3,uVar4);
        if (((unaff_D7w != -0x100) && (unaff_D7w != 0x1a)) && (unaff_D7w < 0)) {
          FUN_80007fa2((int)unaff_D7w,param_1);
          FUN_8000fc92(0,0);
          return;
        }
        local_507 = local_6;
        local_6 = '\0';
        do {
          FUN_80009a4a();
          if (unaff_D7w == 0x11f) {
            FUN_8000fc92(0,0);
            FUN_80000314(param_1,(int)DAT_900100f8,&DAT_900100e8);
            return;
          }
          if ((unaff_D7w == 0xd) || (unaff_D7w == 0x20)) goto LAB_800059dc;
        } while (unaff_D7w != 10);
        iVar2 = 0;
        pcVar3 = &local_506;
        cVar1 = local_506;
        while (cVar1 != '\0') {
          if (iVar2 == 0) {
            FUN_8000fe74();
          }
          cVar1 = pcVar3[1];
          pcVar3[1] = '\0';
          FUN_800100e4(iVar2,0x13,pcVar3);
          pcVar3[1] = cVar1;
          iVar2 = iVar2 + 1;
          if (0x4f < iVar2) {
            iVar2 = 0;
          }
          FUN_80009a4a();
          pcVar3 = pcVar3 + 1;
          cVar1 = *pcVar3;
        }
      }
    }
LAB_800059dc:
    FUN_8000fc92(0,0);
    FUN_80000314(param_1,(int)DAT_900100f8,&DAT_900100e8);
  }
  else {
    FUN_80007fa2((int)unaff_D7w,param_1);
    FUN_8000fc92(0,0);
  }
  return;
}


// ==== FUN_80005a0e @ 80005a0e

/* WARNING: Removing unreachable block (ram,0x80005de6) */
/* WARNING: Removing unreachable block (ram,0x80005e04) */
/* WARNING: Removing unreachable block (ram,0x80005dec) */
/* WARNING: Removing unreachable block (ram,0x80005df2) */
/* WARNING: Removing unreachable block (ram,0x80005e16) */
/* WARNING: Removing unreachable block (ram,0x80005e20) */
/* WARNING: Removing unreachable block (ram,0x80005a92) */
/* WARNING: Removing unreachable block (ram,0x80005aa8) */
/* WARNING: Removing unreachable block (ram,0x80005ab2) */

void FUN_80005a0e(void)

{
  short unaff_D7w;
  undefined1 auStack_10 [12];
  
  FUN_80016134(auStack_10,0xb,0x20);
  FUN_8000e4a0(0,0xffffffff);
  FUN_800099f6();
  FUN_80007fa2(0);
  if ((unaff_D7w == 0x11f) || (unaff_D7w == 0xd)) {
    FUN_80008700(0x15);
    return;
  }
                    /* WARNING: Could not recover jumptable at 0x80005ac2. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (*(code *)((int)&switchD_80005ac2::switchdataD_80005ac6 +
            (int)(short)switchD_80005ac2::switchdataD_80005ac6))();
  return;
}


// ==== FUN_80005e32 @ 80005e32

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_80005e32(void)

{
  uint uVar1;
  bool bVar2;
  short sVar3;
  short sVar4;
  uint uVar5;
  uint unaff_D7;
  uint uVar6;
  undefined4 uVar7;
  undefined1 auStack_10 [8];
  undefined1 auStack_8 [4];
  
  FUN_80016134(auStack_10,0xb,0x20);
  uVar6 = 0;
  do {
    FUN_8000e68c(uVar6);
    do {
      uVar5 = 0;
      bVar2 = true;
      FUN_800099f6();
      sVar4 = (short)unaff_D7;
      FUN_80007fa2(0);
      uVar1 = _DAT_900100ec;
      if ((sVar4 == 0x11f) || (sVar4 == 0xd)) {
        if (uVar6 == 0) {
          return;
        }
        FUN_80000294(DAT_9000c86c,&DAT_900100e8);
        if (sVar4 == 0xd) {
          return;
        }
        uVar6 = 0;
        break;
      }
      DAT_900100ec = (short)(unaff_D7 >> 0x10);
      sVar3 = DAT_900100ec;
      _DAT_900100ec = uVar1;
      if (uVar6 == 1) {
        FUN_800089a4(unaff_D7 & 0xffff,1);
        uVar5 = unaff_D7;
        if ((int)unaff_D7 < 0) {
LAB_8000613a:
          bVar2 = false;
        }
        else {
          if (DAT_9000c86c == 6) {
            if (*(char *)(DAT_9000131a + 0xb + unaff_D7 * 0x20) < '\0') {
LAB_80006018:
              FUN_80015e48(&DAT_9000c874,auStack_10,6);
              FUN_80015e48(&DAT_9000c87c,auStack_8,3);
              FUN_8000050c(DAT_9000c86c,auStack_10,&DAT_900100e8);
              _DAT_900100ec = unaff_D7;
              if (sVar3 == 0) {
                FUN_80007fa2(3,DAT_9000c86c);
              }
              uVar6 = 2;
              uVar7 = 0;
LAB_80006074:
              FUN_80007eb0(uVar7);
              uVar5 = unaff_D7;
              goto LAB_8000613e;
            }
          }
          else if (DAT_9000c87b == '@') goto LAB_80006018;
          FUN_80007fa2(6,DAT_9000c86c);
          bVar2 = false;
        }
      }
      else if (uVar6 < 2) {
        if (uVar6 == 0) {
          FUN_80005430(unaff_D7 & 0xffff);
          uVar5 = unaff_D7;
          if ((int)unaff_D7 < 0) goto LAB_8000613a;
          FUN_80007c28(&DAT_80005e30,0);
          FUN_8000826a(0x19);
          DAT_9000c86c = unaff_D7;
          FUN_80000174();
          if (sVar3 == 0) {
            _DAT_900100ec = unaff_D7;
            FUN_8000996c(unaff_D7 == 6);
            DAT_90006cd4 = 0;
            FUN_80009082(1);
            if (-1 < (int)unaff_D7) {
              FUN_8000880a();
              if ((-1 < (int)unaff_D7) && (unaff_D7 == 6)) {
                FUN_8000a1f6();
              }
              if ((DAT_900100f4 != 0) && (-1 < (int)unaff_D7)) {
                FUN_80008f4a();
              }
            }
            if ((int)unaff_D7 < 0) {
              FUN_80000294(DAT_9000c86c,&DAT_900100e8);
            }
            else {
              uVar6 = 1;
            }
            if (DAT_900100f4 != 0) {
              uVar7 = 1;
              goto LAB_80006074;
            }
          }
          else {
            _DAT_900100ec = unaff_D7;
            FUN_80007fa2((int)sVar3);
          }
        }
      }
      else if (uVar6 == 2) {
        uVar1 = unaff_D7 & 0xffff;
        if (uVar1 != 0x121) {
          if (uVar1 < 0x122) {
            if (uVar1 == 10) {
LAB_800060a0:
              FUN_80007d86(0);
              FUN_8000826a(0);
              FUN_80007c28(&DAT_80005e30,0);
              FUN_80000490(DAT_9000c86c,DAT_900100fc + 1,&DAT_900100e8);
              _DAT_900100ec = unaff_D7;
              FUN_80000294(DAT_9000c86c,&DAT_900100e8);
              if (-1 < (int)_DAT_900100ec) {
                return;
              }
              sVar4 = DAT_900100ec;
              if (DAT_900100ec == -3) {
                sVar4 = 6;
              }
              FUN_80007fa2((int)sVar4,_DAT_900100ec & 0xff);
              return;
            }
          }
          else if (uVar1 == 0x122) goto LAB_800060a0;
          if ((sVar4 == 0x164) || (sVar4 == 0x166)) {
            FUN_800089a4(unaff_D7 & 0xffff,1);
            uVar5 = unaff_D7;
          }
          goto LAB_8000613a;
        }
        uVar6 = 1;
      }
LAB_8000613e:
      if (uVar5 == 0xfffffffb) {
        uVar6 = 0;
      }
      else if (uVar5 == 0xfffffffa) {
        return;
      }
    } while (!bVar2);
  } while( true );
}


// ==== FUN_80006168 @ 80006168

void FUN_80006168(void)

{
  uint uVar1;
  bool bVar2;
  bool bVar3;
  uint uVar4;
  uint unaff_D7;
  bool bVar5;
  
  bVar5 = true;
  do {
    FUN_800162cc(0,0);
    do {
      FUN_8000e120(bVar5);
      do {
        bVar2 = true;
        bVar5 = false;
        FUN_800099f6();
        FUN_80007fa2(0);
        if (((short)unaff_D7 == 0x11f) || ((short)unaff_D7 == 0xd)) {
          bVar3 = true;
          FUN_80008700(3);
          FUN_80008700(0x15);
          FUN_80008700(0x14);
          FUN_8000f022();
          FUN_8000efae();
          FUN_80016294(0x12,0x20000000);
          break;
        }
        bVar3 = false;
        uVar1 = unaff_D7 & 0xffff;
        uVar4 = unaff_D7;
        if (uVar1 == 0x119) {
          FUN_80003c36();
        }
        else if (uVar1 < 0x11a) {
          if (uVar1 == 0x118) {
            FUN_800036b8();
          }
          else {
LAB_8000622c:
            bVar2 = false;
            uVar4 = 0;
          }
        }
        else {
          if (uVar1 != 0x11a) goto LAB_8000622c;
          FUN_8000390e();
        }
        bVar5 = uVar4 != 0xffffffff;
      } while (!bVar2);
    } while (!bVar3);
  } while( true );
}


// ==== FUN_8000625c @ 8000625c

void FUN_8000625c(void)

{
  bool bVar1;
  bool bVar2;
  uint unaff_D5;
  uint unaff_D7;
  bool bVar3;
  
  bVar3 = true;
  do {
    FUN_800162cc(0,0);
    do {
      FUN_8000df3e(bVar3);
      do {
        bVar1 = true;
        bVar3 = false;
        FUN_800099f6();
        FUN_80007fa2(0);
        if (((short)unaff_D7 == 0x11f) || ((short)unaff_D7 == 0xd)) {
          bVar2 = true;
          FUN_80008700(3);
          FUN_80008700(0x15);
          FUN_80008700(0x14);
          FUN_8000f022();
          FUN_8000efae();
          FUN_80016294(0x12,0x20000000);
          break;
        }
        bVar2 = false;
        switch(unaff_D7 & 0xffff) {
        case 0x118:
          FUN_80005476();
          unaff_D5 = unaff_D7;
          break;
        case 0x119:
          FUN_80003f22();
          FUN_8000a1d0();
          unaff_D5 = unaff_D7;
          break;
        case 0x11a:
          FUN_80005a0e();
          unaff_D5 = unaff_D7;
          break;
        case 0x11b:
          FUN_80004696();
          unaff_D5 = unaff_D7;
          break;
        case 0x11c:
          FUN_80005e32();
          unaff_D5 = unaff_D7;
          break;
        default:
          bVar1 = false;
        }
        bVar3 = unaff_D5 != 0xffffffff;
      } while (!bVar1);
    } while (!bVar2);
  } while( true );
}


// ==== FUN_80006368 @ 80006368

void FUN_80006368(void)

{
  bool bVar1;
  uint unaff_D5;
  uint unaff_D7;
  bool bVar2;
  
  do {
    FUN_800162cc(0,0);
    do {
      bVar1 = true;
      FUN_8000e02a();
      do {
        FUN_800099f6();
        FUN_80007fa2(0);
        if (((short)unaff_D7 == 0x11f) || ((short)unaff_D7 == 0xd)) {
          FUN_80008700(0x14);
          FUN_80016294(0x12,0x20000000);
          bVar2 = true;
          break;
        }
        switch(unaff_D7 & 0xffff) {
        case 0x118:
          FUN_800073a2();
          break;
        case 0x119:
          FUN_800076fa();
          break;
        case 0x11a:
          FUN_8000644a();
          break;
        case 0x11b:
          FUN_800067ee();
          break;
        default:
          bVar1 = false;
          goto LAB_80006412;
        }
        FUN_8000a1d0();
        unaff_D5 = unaff_D7;
LAB_80006412:
        bVar2 = unaff_D5 == 0xffffffff;
      } while (!bVar1);
    } while (!bVar2);
  } while( true );
}


// ==== FUN_8000644a @ 8000644a

/* WARNING: Removing unreachable block (ram,0x800067c2) */
/* WARNING: Removing unreachable block (ram,0x800067d0) */
/* WARNING: Removing unreachable block (ram,0x800067c8) */
/* WARNING: Removing unreachable block (ram,0x800067ce) */
/* WARNING: Removing unreachable block (ram,0x800067d2) */
/* WARNING: Removing unreachable block (ram,0x800067dc) */
/* WARNING: Removing unreachable block (ram,0x8000649c) */
/* WARNING: Removing unreachable block (ram,0x800064b4) */
/* WARNING: Removing unreachable block (ram,0x800064bc) */

void FUN_8000644a(void)

{
  short unaff_D7w;
  
  FUN_8000ea38(0);
  FUN_800099f6();
  FUN_80007fa2(0);
  if ((unaff_D7w == 0x11f) || (unaff_D7w == 0xd)) {
    return;
  }
                    /* WARNING: Could not recover jumptable at 0x800064ca. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (*(code *)((int)&switchD_800064ca::switchdataD_800064ce +
            (int)(short)switchD_800064ca::switchdataD_800064ce))();
  return;
}


// ==== FUN_800067ee @ 800067ee

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_800067ee(void)

{
  uint uVar1;
  bool bVar2;
  int iVar3;
  uint uVar4;
  uint unaff_D7;
  short sVar5;
  int iVar6;
  
LAB_800067fc:
  iVar6 = 0;
  do {
    FUN_8000eb3a(iVar6);
    do {
      uVar4 = 0;
      bVar2 = true;
      FUN_800099f6();
      sVar5 = (short)unaff_D7;
      FUN_80007fa2(0);
      if ((sVar5 == 0x11f) || (sVar5 == 0xd)) {
        if (iVar6 == 0) {
          return;
        }
        FUN_80000294(DAT_9000c86c,&DAT_900100e8);
        if (sVar5 == 0xd) {
          return;
        }
        goto LAB_800067fc;
      }
      if (iVar6 == 0) {
        FUN_80005430(unaff_D7 & 0xffff);
        uVar4 = unaff_D7;
        if ((int)unaff_D7 < 0) {
          iVar6 = 0;
LAB_800069c2:
          bVar2 = false;
        }
        else {
          FUN_80007c28(&DAT_800067ec,0);
          FUN_8000826a(0x19);
          DAT_9000c86c = unaff_D7;
          FUN_80000174();
          DAT_900100ec = (short)(unaff_D7 >> 0x10);
          if (DAT_900100ec == 0) {
            _DAT_900100ec = unaff_D7;
            FUN_8000996c(unaff_D7 == 6);
            DAT_90006cd4 = 0;
            FUN_80009082(1);
            if ((-1 < (int)unaff_D7) && (FUN_8000880a(), unaff_D7 == 6)) {
              FUN_8000a1f6();
            }
            if ((int)unaff_D7 < 0) {
              FUN_80000294();
            }
            else {
              iVar6 = 1;
            }
          }
          else {
            iVar3 = (int)DAT_900100ec;
            _DAT_900100ec = unaff_D7;
            FUN_80007fa2(iVar3);
          }
        }
      }
      else if (iVar6 == 1) {
        FUN_800089a4(unaff_D7 & 0xffff,0);
        uVar1 = unaff_D7 & 0xffff;
        if (uVar1 != 0x121) {
          if (uVar1 < 0x122) {
            if (uVar1 == 10) {
LAB_8000695a:
              FUN_80007d86(0);
              FUN_8000826a(0);
              FUN_800006d8(DAT_9000c86c,&DAT_900100e8);
              _DAT_900100ec = unaff_D7;
              FUN_80000294(DAT_9000c86c,&DAT_900100e8);
              if (DAT_900100ec == 0) {
                return;
              }
              FUN_80007fa2((int)DAT_900100ec,_DAT_900100ec & 0xff);
              return;
            }
          }
          else if (uVar1 == 0x122) goto LAB_8000695a;
          goto LAB_800069c2;
        }
        FUN_80000294(DAT_9000c86c,&DAT_900100e8);
        iVar6 = 0;
      }
      if (uVar4 == 0xfffffffb) {
        iVar6 = 0;
      }
      else if (uVar4 == 0xfffffffa) {
        return;
      }
    } while (!bVar2);
  } while( true );
}


// ==== FUN_800069ec @ 800069ec

/* WARNING: Removing unreachable block (ram,0x80006caa) */
/* WARNING: Removing unreachable block (ram,0x80006cb2) */
/* WARNING: Removing unreachable block (ram,0x80006cb8) */
/* WARNING: Removing unreachable block (ram,0x80006cc8) */
/* WARNING: Restarted to delay deadcode elimination for space: stack */

void FUN_800069ec(undefined4 param_1,undefined4 param_2,char param_3)

{
  bool bVar1;
  undefined4 uVar2;
  undefined4 uVar3;
  int unaff_D7;
  int iVar4;
  undefined4 unaff_A5;
  int local_28;
  short sVar5;
  undefined1 local_14 [4];
  int local_10;
  undefined4 local_c;
  undefined4 local_8;
  
  DAT_90000364 = 0;
  bVar1 = false;
  FUN_80006d7a(param_3,&local_8,&local_c,&local_10,local_14);
  FUN_8000e200(0,2);
  FUN_8000e200(0,2);
  if (param_3 == '\0') {
    FUN_8000826a(0);
    FUN_8000b398(0,&DAT_900100e8,local_8,local_c);
    FUN_8000b29a(0);
    if (unaff_D7 == 0) {
      FUN_80007fa2(0x11,param_1);
    }
  }
  FUN_8000f022();
  FUN_8000efae();
  FUN_8000efbe(1,4,0x10);
  iVar4 = 0;
  if (param_3 == '\0') {
    FUN_80007322(param_1,0,local_8,local_c);
    iVar4 = unaff_D7;
  }
  if ((iVar4 == 0) && (FUN_8001379e(local_10 * 10 + 0x400), unaff_D7 != 0)) {
    if (param_3 == '\0') {
      FUN_8000700e(param_1,param_2);
    }
    FUN_800002ea(param_1,param_2,0,&DAT_900100e8);
    sVar5 = (short)((uint)unaff_D7 >> 0x10);
    if (unaff_D7 < 0) {
      FUN_80007fa2((int)sVar5,param_1);
      FUN_800137b4();
    }
    else {
      do {
        FUN_8000033e(param_1,(int)(short)unaff_D7,local_10 * 10);
        if (unaff_D7 < 0) {
          if (sVar5 != -0xc) {
            FUN_80007fa2((int)sVar5,param_1);
          }
          break;
        }
        FUN_80006d20();
        iVar4 = unaff_D7;
        if (unaff_D7 == 0) {
          if ((bVar1) || (bVar1 = true, param_3 == '\0')) {
            uVar2 = 0xffffffff;
            uVar3 = 0xffffffff;
          }
          else {
            uVar2 = local_8;
            uVar3 = local_c;
          }
          FUN_80006e0c();
          if (local_28 != 0) {
            FUN_8000b0a4(&DAT_90006386,local_28,param_3,&DAT_900100e8,uVar2,uVar3);
            switch(param_3) {
            case '\0':
              unaff_A5 = 0x11;
              break;
            case '\x01':
              unaff_A5 = 0x14;
              break;
            case '\x02':
              unaff_A5 = 0x12;
              break;
            case '\x03':
              unaff_A5 = 0x13;
            }
            FUN_80007fa2(unaff_A5,param_1);
            iVar4 = -5;
          }
        }
      } while (iVar4 == 0);
      FUN_80000314(param_1,(int)(short)unaff_D7,&DAT_900100e8);
      FUN_800137b4();
    }
  }
  return;
}


// ==== FUN_80006d20 @ 80006d20

void FUN_80006d20(void)

{
  bool bVar1;
  int iVar2;
  ushort unaff_D7w;
  
  iVar2 = 0;
  bVar1 = false;
  do {
    FUN_80009a4a();
    if (unaff_D7w == 0x20) {
      iVar2 = -7;
    }
    else if (unaff_D7w < 0x21) {
      if (unaff_D7w == 0xd) {
        iVar2 = -6;
      }
    }
    else if (unaff_D7w == 0xe3) {
      bVar1 = (bool)(bVar1 ^ 1);
    }
    else if (unaff_D7w == 0x11f) {
      iVar2 = -5;
    }
  } while ((bVar1) && (iVar2 == 0));
  return;
}


// ==== FUN_80006d7a @ 80006d7a

void FUN_80006d7a(undefined1 param_1,uint *param_2,uint *param_3,undefined4 *param_4,
                 undefined4 *param_5)

{
  byte *pbVar1;
  
  switch(param_1) {
  case 0:
    pbVar1 = &DAT_9000eb5c;
    break;
  case 1:
    pbVar1 = &DAT_9000db3c;
    break;
  case 2:
    pbVar1 = &DAT_9000db48;
    break;
  case 3:
    pbVar1 = &DAT_9000db4b;
    break;
  default:
    goto switchD_80006d98_default;
  }
  *param_3 = (uint)*pbVar1;
  *param_2 = (uint)pbVar1[1];
  if ((pbVar1[2] & 1) == 0) {
    *param_4 = 0x84;
  }
  else {
    *param_4 = 0x50;
  }
  if ((pbVar1[2] & 2) == 0) {
    *param_5 = 0;
  }
  else {
    *param_5 = 1;
  }
switchD_80006d98_default:
  return;
}


// ==== FUN_80006e0c @ 80006e0c

void FUN_80006e0c(int param_1,int param_2,int param_3,int *param_4,int *param_5,int param_6,
                 int param_7,int *param_8)

{
  char cVar1;
  int iVar2;
  int iVar3;
  
  iVar3 = 0;
  iVar2 = 0;
  do {
    if (param_7 <= *param_5) {
      iVar3 = -1;
LAB_80006e92:
      if (iVar3 != -1) {
        iVar2 = iVar2 + 1;
      }
      if ((param_3 == 1) && (*param_4 = *param_4 + 1, *param_4 == 0x42)) {
        *param_4 = 0;
        *(undefined1 *)(param_2 + iVar2) = 0xc;
        iVar2 = iVar2 + 1;
      }
      *param_8 = iVar2;
      return;
    }
    if (param_6 <= iVar2) {
      if (param_6 == 0x84) {
        iVar2 = iVar2 + -1;
      }
      else {
        *(undefined1 *)(param_2 + iVar2) = 10;
        iVar2 = iVar2 + 1;
        *(undefined1 *)(param_2 + iVar2) = 0xd;
      }
      goto LAB_80006e92;
    }
    cVar1 = *(char *)(param_1 + *param_5);
    *(char *)(param_2 + iVar2) = cVar1;
    if ((cVar1 == '\n') || (cVar1 == '\r')) {
      *param_5 = *param_5 + 1;
      cVar1 = *(char *)(param_1 + *param_5);
      if ((cVar1 == '\n') || (cVar1 == '\r')) {
        *param_5 = *param_5 + 1;
        iVar2 = iVar2 + 1;
        *(char *)(param_2 + iVar2) = cVar1;
      }
      goto LAB_80006e92;
    }
    iVar2 = iVar2 + 1;
    *param_5 = *param_5 + 1;
  } while( true );
}


// ==== FUN_80006ec6 @ 80006ec6

void FUN_80006ec6(int param_1,int param_2,int *param_3,int *param_4)

{
  bool bVar1;
  int iVar2;
  int iVar3;
  int iVar4;
  int unaff_D7;
  
  bVar1 = false;
  FUN_8001379e(param_2 << 1);
  iVar2 = 0;
  iVar4 = 0;
  if (0 < param_2) {
    do {
      if ((*(char *)(param_1 + iVar2) == '\n') || (*(char *)(param_1 + iVar2) == '\r')) {
        bVar1 = true;
        break;
      }
      FUN_800033e0(param_1 + iVar2,unaff_D7 + iVar4,1);
      iVar4 = unaff_D7 + iVar4;
      iVar2 = iVar2 + 1;
    } while (iVar2 < param_2);
  }
  *(undefined1 *)(unaff_D7 + iVar4) = 0;
  iVar2 = 0;
  do {
    if (*param_4 + iVar4 < 0x51) {
      iVar3 = iVar4;
    }
    else {
      iVar3 = 0x50 - *param_4;
    }
    iVar4 = iVar4 - iVar3;
    FUN_80016134(&DAT_9000640c,0x50,0x20);
    FUN_80015e48(unaff_D7 + iVar2,&DAT_9000640c,iVar3);
    iVar2 = iVar3 + iVar2;
    (&DAT_9000645c)[-*param_4] = 0;
    FUN_8000f254(*param_4,*param_3,7,0,&DAT_9000640c);
    *param_4 = iVar3;
    if ((iVar4 != 0) || (bVar1)) {
      if ((0xf < *param_3) || (DAT_90000364 == 1)) {
        DAT_90000364 = 1;
        FUN_8000f072(2,1);
      }
      *param_3 = *param_3 + 1;
      *param_4 = 0;
      if (*param_3 == 0x37) {
        *param_3 = 0;
      }
    }
  } while (iVar4 != 0);
  FUN_800137b4(unaff_D7);
  return;
}


// ==== FUN_8000700e @ 8000700e

/* WARNING: Restarted to delay deadcode elimination for space: stack */

void FUN_8000700e(int param_1,int param_2,int param_3,undefined4 param_4,undefined4 param_5)

{
  undefined4 uVar1;
  int unaff_D7;
  int iVar2;
  int iVar3;
  short sVar4;
  undefined1 local_4c;
  undefined1 local_4b;
  undefined1 local_4a;
  undefined1 local_48;
  undefined1 local_47;
  undefined1 local_46;
  undefined4 local_38;
  undefined4 local_e;
  
  FUN_8000050c(param_1,param_2,&DAT_900100e8);
  sVar4 = (short)((uint)unaff_D7 >> 0x10);
  if (-1 < unaff_D7) {
    if ((param_1 == 6) || (param_1 == 7)) {
      FUN_80000532(param_1);
      uVar1 = local_38;
    }
    else {
      FUN_80000532(param_1);
      uVar1 = local_e;
    }
    if (-1 < unaff_D7) {
      FUN_80007288(param_2,param_3,8);
      *(undefined1 *)(unaff_D7 + param_3) = 0x2e;
      FUN_80007288(param_2 + 8,unaff_D7 + 1 + param_3,3);
      iVar2 = unaff_D7 + unaff_D7 + 1;
      *(undefined1 *)(iVar2 + param_3) = 0x20;
      iVar2 = iVar2 + 1;
      FUN_8000873a(uVar1,iVar2 + param_3,0);
      iVar2 = unaff_D7 + -1 + iVar2;
      FUN_80015e48("BYTES",iVar2 + param_3,5);
      *(undefined1 *)(iVar2 + 5 + param_3) = 0x20;
      FUN_8001629c(&local_4c);
      FUN_800072b8(local_4c,iVar2 + 6 + param_3);
      iVar2 = unaff_D7 + iVar2 + 6;
      *(undefined1 *)(iVar2 + param_3) = 0x2f;
      iVar2 = iVar2 + 1;
      FUN_800072b8(local_4b,iVar2 + param_3);
      iVar2 = unaff_D7 + iVar2;
      *(undefined1 *)(iVar2 + param_3) = 0x2f;
      iVar2 = iVar2 + 1;
      FUN_800072b8(local_4a,iVar2 + param_3);
      iVar2 = unaff_D7 + iVar2;
      *(undefined1 *)(iVar2 + param_3) = 0x20;
      iVar2 = iVar2 + 1;
      FUN_800072b8(local_48,iVar2 + param_3);
      iVar2 = unaff_D7 + iVar2;
      *(undefined1 *)(iVar2 + param_3) = 0x3a;
      iVar2 = iVar2 + 1;
      FUN_800072b8(local_47,iVar2 + param_3);
      iVar2 = unaff_D7 + iVar2;
      *(undefined1 *)(iVar2 + param_3) = 0x3a;
      iVar2 = iVar2 + 1;
      FUN_800072b8(local_46,iVar2 + param_3);
      iVar2 = unaff_D7 + iVar2;
      *(undefined1 *)(iVar2 + param_3) = 0xd;
      *(undefined1 *)(iVar2 + 1 + param_3) = 10;
      iVar3 = iVar2 + 2;
      FUN_8000057a(param_1);
      if (unaff_D7 < 0) {
        if (sVar4 != -0x31) goto LAB_800071f4;
      }
      else {
        FUN_80015e48("COMMENT ",iVar3 + param_3,8);
        *(undefined1 *)(iVar2 + 0x32 + param_3) = 0xd;
        *(undefined1 *)(iVar2 + 0x33 + param_3) = 10;
        iVar3 = iVar2 + 0x34;
      }
      FUN_80007300(&DAT_90010170,iVar3 + param_3);
      iVar3 = unaff_D7 + iVar3;
      *(undefined1 *)(iVar3 + param_3) = 0xd;
      *(undefined1 *)(iVar3 + 1 + param_3) = 10;
      *(undefined1 *)(iVar3 + 2 + param_3) = 0xd;
      *(undefined1 *)(iVar3 + 3 + param_3) = 10;
      FUN_8000b0a4(param_3,iVar3 + 4,0,&DAT_900100e8,param_4,param_5);
      return;
    }
  }
LAB_800071f4:
  FUN_80007fa2((int)sVar4,param_1);
  return;
}


// ==== FUN_80007288 @ 80007288

void FUN_80007288(int param_1,int param_2,int param_3)

{
  int iVar1;
  
  iVar1 = 0;
  if (0 < param_3) {
    do {
      if (*(char *)(param_1 + iVar1) == ' ') {
        return;
      }
      *(char *)(param_2 + iVar1) = *(char *)(param_1 + iVar1);
      iVar1 = iVar1 + 1;
    } while (iVar1 < param_3);
  }
  return;
}


// ==== FUN_800072b8 @ 800072b8

void FUN_800072b8(byte param_1,byte *param_2)

{
  byte bVar1;
  
  bVar1 = (char)((uint)(int)(short)(ushort)param_1 % 10) +
          (char)((uint)(int)(short)(ushort)param_1 / 10 << 4);
  *param_2 = bVar1 >> 4 | 0x30;
  param_2[1] = bVar1 & 0xf | 0x30;
  return;
}


// ==== FUN_80007300 @ 80007300

void FUN_80007300(int param_1,int param_2)

{
  int iVar1;
  
  for (iVar1 = 0; *(char *)(param_1 + iVar1) != '\0'; iVar1 = iVar1 + 1) {
    *(char *)(param_2 + iVar1) = *(char *)(param_1 + iVar1);
  }
  return;
}


// ==== FUN_80007322 @ 80007322

void FUN_80007322(undefined4 param_1,undefined1 param_2,undefined4 param_3,undefined4 param_4)

{
  undefined4 unaff_D4;
  int unaff_D7;
  
  FUN_8000b0a4(&DAT_90000368,4,param_2,&DAT_900100e8,param_3,param_4);
  if (unaff_D7 == 0) {
    switch(param_2) {
    case 0:
      unaff_D4 = 0x11;
      break;
    case 1:
      unaff_D4 = 0x14;
      break;
    case 2:
      unaff_D4 = 0x12;
      break;
    case 3:
      unaff_D4 = 0x13;
    }
    FUN_80007fa2(unaff_D4,param_1);
  }
  return;
}


// ==== FUN_800073a2 @ 800073a2

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_800073a2(void)

{
  uint uVar1;
  bool bVar2;
  short sVar3;
  uint uVar4;
  uint unaff_D7;
  short sVar5;
  int iVar6;
  undefined4 local_10;
  
  local_10 = 0;
LAB_800073b6:
  iVar6 = 0;
  do {
    FUN_8000e77c(iVar6,&DAT_9000c86c,local_10);
    do {
      uVar4 = 0;
      bVar2 = true;
      FUN_800099f6();
      sVar5 = (short)unaff_D7;
      FUN_80007fa2(0);
      uVar1 = _DAT_900100ec;
      if ((sVar5 == 0x11f) || (sVar5 == 0xd)) {
        if (iVar6 != 0) {
          FUN_80000294(DAT_9000c86c,&DAT_900100e8);
        }
        if (1 < iVar6) {
          FUN_80000294(DAT_9000c870,&DAT_900100e8);
        }
        if (iVar6 == 0) {
          return;
        }
        if (sVar5 == 0xd) {
          return;
        }
        goto LAB_800073b6;
      }
      DAT_900100ec = (short)(unaff_D7 >> 0x10);
      sVar3 = DAT_900100ec;
      _DAT_900100ec = uVar1;
      if (iVar6 == 1) {
        local_10 = 1;
        if ((sVar5 == 0x164) || (sVar5 == 0x166)) {
          FUN_800089a4();
          bVar2 = false;
        }
        else {
          FUN_80005430();
          if ((int)unaff_D7 < 0) {
LAB_80007560:
            bVar2 = false;
            uVar4 = unaff_D7;
          }
          else {
            uVar4 = unaff_D7;
            if ((unaff_D7 != DAT_9000c86c) && (unaff_D7 != 6)) {
              FUN_8000826a(0);
              FUN_80007c28(&DAT_8000739c,0);
              FUN_80007c28(&DAT_8000739d,8);
              DAT_9000c870 = unaff_D7;
              FUN_8000826a(0x19);
              FUN_80000174();
              _DAT_900100ec = unaff_D7;
              if (sVar3 == 0) {
LAB_800075e2:
                iVar6 = iVar6 + 1;
                uVar4 = unaff_D7;
              }
              else {
                local_10 = 0;
                FUN_80007fa2((int)sVar3);
              }
            }
          }
        }
      }
      else if (iVar6 < 2) {
        if (iVar6 == 0) {
          local_10 = 0;
          FUN_80005430();
          if (((int)unaff_D7 < 0) || (unaff_D7 == 6)) goto LAB_80007560;
          FUN_80007c28(&DAT_8000739c,0);
          FUN_8000826a(0x19);
          DAT_9000c86c = unaff_D7;
          FUN_80000174();
          if (sVar3 == 0) {
            _DAT_900100ec = unaff_D7;
            FUN_8000996c(unaff_D7 == 6);
            DAT_90006cd4 = 0;
            FUN_80009082(1);
            if ((-1 < (int)unaff_D7) && (FUN_8000880a(), unaff_D7 == 6)) {
              FUN_8000a1f6();
            }
            if (-1 < (int)unaff_D7) goto LAB_800075e2;
            FUN_80000294();
            uVar4 = unaff_D7;
          }
          else {
            _DAT_900100ec = unaff_D7;
            FUN_80007fa2((int)sVar3);
            uVar4 = unaff_D7;
          }
        }
      }
      else if (iVar6 == 2) {
        uVar1 = unaff_D7 & 0xffff;
        if (uVar1 == 0x121) {
          FUN_80000294(DAT_9000c86c,&DAT_900100e8);
          FUN_80000294(DAT_9000c870,&DAT_900100e8);
          iVar6 = 0;
        }
        else {
          if (uVar1 < 0x122) {
            if (uVar1 == 10) {
LAB_8000760a:
              FUN_80007d86(0);
              FUN_80007c28(&DAT_8000739c,0);
              FUN_8000826a(0);
              FUN_800006fa(DAT_9000c86c,DAT_9000c870,&DAT_900100e8);
              _DAT_900100ec = unaff_D7;
              FUN_80000294(DAT_9000c86c,&DAT_900100e8);
              FUN_80000294(DAT_9000c870,&DAT_900100e8);
              if (DAT_900100ec == 0) {
                return;
              }
              FUN_80007fa2((int)DAT_900100ec,_DAT_900100ec & 0xff);
              return;
            }
          }
          else if (uVar1 == 0x122) goto LAB_8000760a;
          bVar2 = false;
          FUN_800089a4(unaff_D7 & 0xffff,0);
        }
      }
      if (uVar4 == 0xfffffffb) {
        iVar6 = 0;
      }
      else if (uVar4 == 0xfffffffa) {
        return;
      }
    } while (!bVar2);
  } while( true );
}


// ==== FUN_800076fa @ 800076fa

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_800076fa(void)

{
  bool bVar1;
  short sVar2;
  uint uVar3;
  uint uVar4;
  int iVar5;
  uint unaff_D7;
  ushort unaff_A4w;
  
LAB_80007708:
  iVar5 = 0;
  do {
    FUN_8000e95c(iVar5);
    do {
      uVar4 = 0;
      bVar1 = true;
      if (iVar5 != 1) {
        FUN_800099f6();
        unaff_A4w = (ushort)unaff_D7;
        FUN_80007fa2(0);
        if ((unaff_A4w == 0x11f) || (unaff_A4w == 0xd)) {
          if (iVar5 == 0) {
            return;
          }
          FUN_80000294(DAT_9000c86c,&DAT_900100e8);
          if (unaff_A4w == 0xd) {
            return;
          }
          goto LAB_80007708;
        }
      }
      uVar3 = _DAT_900100ec;
      DAT_900100ec = (short)(unaff_D7 >> 0x10);
      sVar2 = DAT_900100ec;
      _DAT_900100ec = uVar3;
      if (iVar5 == 1) {
        FUN_80007c28(&DAT_800076f4,0);
        FUN_80000630(DAT_9000c86c,&DAT_9000c88c,&DAT_900100e8);
        if (sVar2 == 0) {
          _DAT_900100ec = unaff_D7;
          FUN_80007c28(&DAT_800076f5,8);
          FUN_80009b00(&DAT_9000c88c,&DAT_9000c897,0xb);
          FUN_80008700(0x18);
joined_r0x800078da:
          if ((int)unaff_D7 < 0) {
            FUN_80000294();
            uVar4 = unaff_D7;
          }
          else {
            iVar5 = iVar5 + 1;
            uVar4 = unaff_D7;
          }
        }
        else {
          _DAT_900100ec = unaff_D7;
          FUN_80007fa2((int)sVar2,unaff_D7 & 0xff);
          FUN_80000294(DAT_9000c86c,&DAT_900100e8);
          iVar5 = 0;
        }
      }
      else if (iVar5 < 2) {
        if (iVar5 == 0) {
          FUN_80005430(unaff_A4w);
          uVar4 = unaff_D7;
          if ((int)unaff_D7 < 0) {
LAB_80007988:
            bVar1 = false;
          }
          else {
            FUN_80007c28(&DAT_800076f4,0);
            FUN_8000826a(0x19);
            DAT_9000c86c = unaff_D7;
            FUN_80000174();
            if (sVar2 == 0) {
              _DAT_900100ec = unaff_D7;
              FUN_8000996c(unaff_D7 == 6);
              DAT_90006cd4 = 0;
              FUN_80009082(1);
              if ((-1 < (int)unaff_D7) && (FUN_8000880a(), unaff_D7 == 6)) {
                FUN_8000a1f6();
              }
              goto joined_r0x800078da;
            }
            _DAT_900100ec = unaff_D7;
            FUN_80007fa2((int)sVar2);
          }
        }
      }
      else if (iVar5 == 2) {
        FUN_800089a4(unaff_A4w,0);
        if (unaff_A4w != 0x121) {
          if (unaff_A4w < 0x122) {
            if (unaff_A4w == 10) {
LAB_8000792c:
              FUN_80007d86(0);
              FUN_8000826a(0);
              FUN_80000656(DAT_9000c86c,&DAT_9000c897,&DAT_900100e8);
              _DAT_900100ec = unaff_D7;
              FUN_80000294(DAT_9000c86c,&DAT_900100e8);
              if (DAT_900100ec == 0) {
                return;
              }
              FUN_80007fa2((int)DAT_900100ec,_DAT_900100ec & 0xff);
              return;
            }
          }
          else if (unaff_A4w == 0x122) goto LAB_8000792c;
          goto LAB_80007988;
        }
        iVar5 = 1;
      }
      if (uVar4 == 0xfffffffb) {
        iVar5 = 0;
      }
      else if (uVar4 == 0xfffffffa) {
        return;
      }
    } while (!bVar1);
  } while( true );
}


// ==== FUN_800079b4 @ 800079b4

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_800079b4(void)

{
  char cVar1;
  byte bVar2;
  undefined4 unaff_D7;
  undefined2 local_e;
  undefined2 local_c;
  undefined2 local_a;
  undefined2 local_8;
  undefined2 local_6;
  
  _DAT_90000060 = 0xffffffff;
  _DAT_900129a0 = 0x90011990;
  FUN_8000a192();
  _DAT_900071c8 = unaff_D7;
  FUN_80007ab4();
  FUN_8000ef90();
  local_8 = 0;
  local_6 = 0;
  local_a = 0x50;
  local_c = 0x1d;
  local_e = 0;
  FUN_8000efa6(1,1,&local_6,&local_8,&local_a,&local_c,&local_e);
  FUN_8000ef9e(1);
  FUN_8000f574(0x10,0,0,0x50,0x1c,5);
  FUN_8000efae();
  bVar2 = 0;
  cVar1 = s_V1_32_90001a84[0];
  while (cVar1 != '\0') {
    bVar2 = bVar2 + 1;
    cVar1 = s_V1_32_90001a84[bVar2];
  }
  FUN_80015e48(s_V1_32_90001a84,s_BVE_9100_SYSTEM_MAINTENANCE_PROG_90000370 + 0x34,bVar2);
  FUN_80016134(&DAT_9000c874,0xb,0x20);
  FUN_80016134(&DAT_9000c880,0xb,0x20);
  return;
}


// ==== FUN_80007ab4 @ 80007ab4

void FUN_80007ab4(void)

{
  undefined1 local_14;
  undefined1 local_13;
  undefined1 local_12;
  undefined1 local_11;
  undefined1 local_10;
  undefined1 local_f;
  undefined1 local_e;
  undefined1 local_d;
  undefined1 local_c;
  undefined1 local_b;
  undefined1 local_a;
  undefined1 local_9;
  undefined1 local_8;
  undefined1 local_7;
  undefined1 local_6;
  undefined1 local_5;
  
  local_14 = 10;
  local_13 = 10;
  local_12 = 10;
  local_11 = 10;
  local_10 = 10;
  local_f = 10;
  local_e = 10;
  local_d = 10;
  local_c = 10;
  local_b = 10;
  local_a = 10;
  local_9 = 10;
  local_8 = 10;
  local_7 = 10;
  local_6 = 10;
  local_5 = 10;
  FUN_8000efb6(&local_14);
  return;
}


// ==== FUN_80007b28 @ 80007b28

void FUN_80007b28(byte param_1)

{
  FUN_8000f022();
  FUN_80008700(0);
  FUN_80008700(3);
  FUN_80008700(0x15);
  FUN_8000f46a(1,0,0,7,0,s_BVE_9100_SYSTEM_MAINTENANCE_PROG_90000370 + (uint)param_1 * 0x50);
  return;
}


// ==== FUN_80007bd2 @ 80007bd2

void FUN_80007bd2(void)

{
  FUN_80016134(&DAT_900012c8,0x4f,0x20);
  FUN_80015e48("    F1        F2        F3        F4        F5        F6        F7        F8",
               &DAT_900012c8,0x4f);
  DAT_90001317 = 0;
  FUN_8000f46a(1,0,0x1b,7,2,&DAT_900012c8);
  return;
}


// ==== FUN_80007c28 @ 80007c28

/* WARNING: Restarted to delay deadcode elimination for space: stack */

void FUN_80007c28(undefined *param_1,byte param_2)

{
  char cVar1;
  byte bVar2;
  byte bVar3;
  int iVar4;
  undefined1 local_1c;
  char acStack_1b [9];
  undefined1 local_12;
  char acStack_10 [12];
  
  if (param_2 != 0) {
    if (param_1 < (undefined *)0x101) {
      param_1 = (&PTR_DAT_90000170)[(int)param_1];
    }
    iVar4 = 0;
    do {
      cVar1 = param_1[iVar4];
      acStack_10[iVar4] = cVar1;
      if (cVar1 == '\0') break;
      iVar4 = iVar4 + 1;
    } while (iVar4 < 10);
    acStack_10[iVar4] = '\0';
  }
  if (param_2 < 9) {
    bVar3 = param_2;
    do {
      if (param_2 == 0) {
        bVar3 = bVar3 + 1;
      }
      FUN_80016134(&local_1c,0xb,0x20);
      if (bVar3 == 1) {
        local_1c = 0x9b;
      }
      else {
        local_1c = 0x9a;
      }
      local_12 = 0;
      if (param_2 != 0) {
        bVar2 = 0;
        cVar1 = acStack_10[0];
        while ((cVar1 != '\0' && (bVar2 < 9))) {
          bVar2 = bVar2 + 1;
          cVar1 = acStack_10[bVar2];
        }
        iVar4 = -(uint)bVar2 + 9;
        if (iVar4 < 0) {
          iVar4 = -(uint)bVar2 + 10;
        }
        bVar2 = 0;
        cVar1 = acStack_10[0];
        while ((cVar1 != '\0' && (bVar2 < 9))) {
          acStack_1b[(uint)bVar2 + (iVar4 >> 1 & 0xffU)] = acStack_10[bVar2];
          bVar2 = bVar2 + 1;
          cVar1 = acStack_10[bVar2];
        }
      }
      FUN_8000f46a(1,(bVar3 - 1) * '\n',0x1c,7,9,&local_1c);
    } while ((param_2 == 0) && (bVar3 != 8));
  }
  return;
}


// ==== FUN_80007d86 @ 80007d86

void FUN_80007d86(int param_1)

{
  if (param_1 == 1) {
    FUN_80015e48("SHIFT+  : PREV PAGE",&DAT_900012c8,0x14);
    DAT_900012ce = 0xca;
    FUN_8000f46a(1,0x3c,0x19,7,0,&DAT_900012c8);
    FUN_80016134(&DAT_900012c8,0x15,0x20);
    FUN_80015e48("SHIFT+  : NEXT PAGE",&DAT_900012c8,0x14);
    DAT_900012ce = 0xcb;
    FUN_8000f46a(1,0x3c,0x1a,7,0,&DAT_900012c8);
  }
  else if (param_1 == 0) {
    FUN_80016134(&DAT_900012c8,0x14,0x20);
    DAT_900012dc = 0;
    FUN_8000f46a(1,0x3c,0x19,7,0,&DAT_900012c8);
    FUN_8000f46a(1,0x3c,0x1a,7,0,&DAT_900012c8);
  }
  return;
}


// ==== FUN_80007eb0 @ 80007eb0

void FUN_80007eb0(int param_1)

{
  FUN_80016134(&DAT_900012c8,0x14,0x20);
  if (param_1 == 1) {
    FUN_80015e48("  : CURSOR UP",&DAT_900012c8,0xe);
    DAT_900012c8 = 0xca;
    FUN_8000f46a(1,0x28,0x19,7,0,&DAT_900012c8);
    FUN_80015e48("  : CURSOR DOWN",&DAT_900012c8,0x10);
    DAT_900012c8 = 0xcb;
    FUN_8000f46a(1,0x28,0x1a,7,0,&DAT_900012c8);
  }
  else if (param_1 == 0) {
    DAT_900012d7 = 0;
    FUN_8000f46a(1,0x28,0x19,7,0,&DAT_900012c8);
    FUN_8000f46a(1,0x28,0x1a,7,0,&DAT_900012c8);
  }
  return;
}


// ==== FUN_80007fa2 @ 80007fa2

void FUN_80007fa2(short param_1,char param_2)

{
  undefined4 uVar1;
  undefined *puVar2;
  int iVar3;
  
  FUN_80016134(&DAT_900012c8,0x50,0x20);
  switch(param_1) {
  case 0x11:
  case 0x12:
  case 0x13:
  case 0x14:
    break;
  case -0x44:
  case -0x40:
  case -0x3f:
  case -0x3e:
  case -0x3d:
  case -0x3c:
  case -7:
  case -4:
    param_1 = 1;
    break;
  default:
    if (-1 < param_1) break;
  case -0x41:
  case -0x34:
  case -0x31:
  case -0x30:
  case -0x2d:
  case -0x2b:
  case -10:
  case -9:
  case -8:
  case -6:
  case -5:
  case -3:
  case -2:
  case -1:
    param_1 = 2;
    break;
  case -0x39:
    param_1 = 0x19;
    break;
  case -0x38:
    param_1 = 0x16;
    break;
  case -0x37:
    param_1 = 0x17;
    break;
  case -0x36:
    param_1 = 8;
    break;
  case -0x35:
    param_1 = 0x18;
    break;
  case -0x2e:
    param_1 = 0xc;
    break;
  case -0x2c:
  case -0x22:
  case -0x18:
  case -0xb:
    param_1 = 0xb;
    break;
  case -0x17:
    param_1 = 10;
    break;
  case -0xc:
  case 0:
    param_1 = 0;
  }
  if (param_1 < 0x1e) {
    iVar3 = 0;
    if (s__90000e18[param_1 * 0x28] != '\0') {
      do {
        iVar3 = iVar3 + 1;
      } while (s__90000e18[iVar3 + param_1 * 0x28] != '\0');
    }
    FUN_80015e48(s__90000e18 + param_1 * 0x28,&DAT_900012c8,iVar3 + 1);
    if ((param_1 == 1) || ((param_1 < 0x11 && (10 < param_1)))) {
      iVar3 = 0;
      if (s__90000e18[param_1 * 0x28] != ')') {
        do {
          iVar3 = iVar3 + 1;
        } while (s__90000e18[iVar3 + param_1 * 0x28] != ')');
      }
      if ((char)(param_2 + 'A') == 'G') {
        uVar1 = 2;
        puVar2 = &DAT_80007f9a;
      }
      else {
        uVar1 = 3;
        puVar2 = &DAT_80007f9d;
      }
      FUN_8000a12e(&DAT_900012c8 + iVar3,puVar2,uVar1);
      (&DAT_900012c6)[iVar3] = param_2 + 'A';
    }
    FUN_8000f46a(1,0,0x18,3,0,&DAT_900012c8);
  }
  return;
}


// ==== FUN_800081e0 @ 800081e0

void FUN_800081e0(int param_1)

{
  FUN_80016134(&DAT_900012c8,0x14,0x20);
  DAT_900012db = 0;
  FUN_8000f46a(1,0,0x17,7,0,&DAT_900012c8);
  if ((param_1 < 0x20) && (param_1 != 0)) {
    FUN_8000f46a(1,0,0x17,7,0,param_1 * 0xe + -0x6ffffab0);
  }
  return;
}


// ==== FUN_8000826a @ 8000826a

void FUN_8000826a(int param_1)

{
  char cVar1;
  byte bVar2;
  char cVar3;
  char cVar4;
  int iVar5;
  uint uVar6;
  undefined1 uVar7;
  undefined1 *puVar8;
  byte *pbVar9;
  undefined1 *puVar10;
  byte local_c;
  byte local_b [7];
  
  if (0x1d < param_1) {
    return;
  }
  cVar3 = (char)DAT_9000c86c + 'A';
  cVar4 = (char)DAT_9000c870 + 'A';
  FUN_80016134(&DAT_900012c8,0x3d,0x20);
  DAT_90001305 = 0;
  FUN_8000f46a(1,0x13,0x17,7,0,&DAT_900012c8);
  FUN_80015e48(s_IN_PROGRESS_90000710 + param_1 * 0x3c,&DAT_900012c8,0x3c);
  switch(param_1) {
  case 0x10:
    DAT_900012da = cVar3;
    break;
  case 0x11:
    DAT_900012d4 = cVar3;
    break;
  case 0x12:
    DAT_900012cd = cVar3;
    DAT_900012d3 = cVar4;
    break;
  case 0x13:
    bVar2 = DAT_9000c888;
    for (uVar6 = 0; (0x20 < bVar2 && (uVar6 < 3)); uVar6 = uVar6 + 1) {
      bVar2 = (&DAT_9000c889)[uVar6];
    }
    FUN_8000a12e(&DAT_900012d7,&DAT_9000c888,uVar6);
    bVar2 = DAT_9000c880;
    for (uVar6 = 0; (0x20 < bVar2 && (uVar6 < 6)); uVar6 = uVar6 + 1) {
      bVar2 = (&DAT_9000c881)[uVar6];
    }
    FUN_8000a12e(&DAT_900012d6,&DAT_9000c880,uVar6);
    bVar2 = DAT_9000c87c;
    for (uVar6 = 0; (0x20 < bVar2 && (uVar6 < 3)); uVar6 = uVar6 + 1) {
      bVar2 = (&DAT_9000c87d)[uVar6];
    }
    DAT_900012d4 = cVar4;
    FUN_8000a12e(&DAT_900012d0,&DAT_9000c87c,uVar6);
    bVar2 = DAT_9000c874;
    for (uVar6 = 0; (0x20 < bVar2 && (uVar6 < 6)); uVar6 = uVar6 + 1) {
      bVar2 = (&DAT_9000c875)[uVar6];
    }
    pbVar9 = &DAT_9000c874;
    puVar8 = &DAT_900012cf;
    goto LAB_800085e0;
  case 0x14:
    uVar6 = 0;
    do {
      if ((byte)(&DAT_9000c897)[uVar6] < 0x21) break;
      uVar6 = uVar6 + 1;
    } while (uVar6 < 0xb);
    DAT_900012db = cVar3;
    FUN_8000a12e(&DAT_900012d3,&DAT_9000c897,uVar6);
    uVar6 = 0;
    do {
      uVar6 = uVar6 + 1;
    } while (uVar6 < 0xb);
    puVar10 = &DAT_9000c88c;
    puVar8 = &DAT_900012cf;
    goto LAB_80008656;
  case 0x15:
    bVar2 = DAT_9000c888;
    for (uVar6 = 0; (0x20 < bVar2 && (uVar6 < 3)); uVar6 = uVar6 + 1) {
      bVar2 = (&DAT_9000c889)[uVar6];
    }
    FUN_8000a12e(&DAT_900012d9,&DAT_9000c888,uVar6);
    bVar2 = DAT_9000c880;
    for (uVar6 = 0; (0x20 < bVar2 && (uVar6 < 6)); uVar6 = uVar6 + 1) {
      bVar2 = (&DAT_9000c881)[uVar6];
    }
    FUN_8000a12e(&DAT_900012d8,&DAT_9000c880,uVar6);
    bVar2 = DAT_9000c87c;
    for (uVar6 = 0; (0x20 < bVar2 && (uVar6 < 3)); uVar6 = uVar6 + 1) {
      bVar2 = (&DAT_9000c87d)[uVar6];
    }
    DAT_900012d6 = cVar3;
    FUN_8000a12e(&DAT_900012d2,&DAT_9000c87c,uVar6);
    bVar2 = DAT_9000c874;
    for (uVar6 = 0; (0x20 < bVar2 && (uVar6 < 6)); uVar6 = uVar6 + 1) {
      bVar2 = (&DAT_9000c875)[uVar6];
    }
    pbVar9 = &DAT_9000c874;
    goto LAB_800085da;
  case 0x16:
    bVar2 = DAT_9000c87c;
    for (uVar6 = 0; (0x20 < bVar2 && (uVar6 < 3)); uVar6 = uVar6 + 1) {
      bVar2 = (&DAT_9000c87d)[uVar6];
    }
    FUN_8000a12e(&DAT_900012d2,&DAT_9000c87c,uVar6);
    bVar2 = DAT_9000c874;
    for (uVar6 = 0; (0x20 < bVar2 && (uVar6 < 6)); uVar6 = uVar6 + 1) {
      bVar2 = (&DAT_9000c875)[uVar6];
    }
    pbVar9 = &DAT_9000c874;
    goto LAB_800085da;
  case 0x17:
    bVar2 = DAT_9000c87c;
    for (uVar6 = 0; (0x20 < bVar2 && (uVar6 < 3)); uVar6 = uVar6 + 1) {
      bVar2 = (&DAT_9000c87d)[uVar6];
    }
    FUN_8000a12e(&DAT_900012d2,&DAT_9000c87c,uVar6);
    FUN_80015e48(&DAT_9000c874,&local_c,6);
    local_b[5] = 0;
    if ((cVar3 != '\x06') && (cVar3 != '\a')) {
      FUN_80000d9e(&local_c);
    }
    for (uVar6 = 0; (0x20 < local_c && (uVar6 < 6)); uVar6 = uVar6 + 1) {
      local_c = local_b[uVar6];
    }
    pbVar9 = &local_c;
LAB_800085da:
    puVar8 = &DAT_900012d1;
LAB_800085e0:
    FUN_8000a12e(puVar8,pbVar9,uVar6);
    puVar8[-2] = cVar3;
    break;
  case 0x18:
    cVar1 = DAT_9000c8a2;
    for (uVar6 = 0; (cVar1 != '\0' && (uVar6 < 9)); uVar6 = uVar6 + 1) {
      cVar1 = (&DAT_9000c8a3)[uVar6];
    }
    puVar10 = &DAT_9000c8a2;
    puVar8 = &DAT_900012d0;
    DAT_900012d7 = cVar3;
    DAT_900012e3 = cVar4;
    goto LAB_80008656;
  case 0x1b:
    bVar2 = DAT_90010118;
    for (uVar6 = 0; (0x20 < bVar2 && (uVar6 < 0x28)); uVar6 = uVar6 + 1) {
      bVar2 = (&DAT_90010119)[uVar6];
    }
    puVar10 = &DAT_90010118;
    puVar8 = &DAT_900012d1;
LAB_80008656:
    FUN_8000a12e(puVar8,puVar10,uVar6);
    break;
  case 0x1c:
    DAT_900012ce = cVar3;
  }
  if (param_1 == 0) {
    uVar7 = 0x10;
  }
  else {
    uVar7 = 0;
  }
  FUN_8000f46a(1,0x13,0x17,7,uVar7,&DAT_900012c8);
  iVar5 = 0;
  cVar3 = DAT_900012c8;
  while (cVar3 != '\0') {
    cVar3 = (&DAT_900012c9)[iVar5];
    iVar5 = iVar5 + 1;
  }
  if (((&DAT_900012c7)[iVar5] == 'K') && ((&DAT_900012c6)[iVar5] == 'O')) {
    FUN_8000f46a(1,(char)iVar5 + '\x14',0x17,7,0x10,&DAT_80008268);
  }
  return;
}


// ==== FUN_80008700 @ 80008700

void FUN_80008700(undefined4 param_1)

{
  FUN_8000f574(0x4c,0,param_1,0,0,3);
  FUN_8000f574(0x61,0,0,0,0,1);
  return;
}


// ==== FUN_8000873a @ 8000873a

void FUN_8000873a(uint param_1,undefined1 *param_2,int param_3)

{
  uint uVar1;
  byte local_5;
  
  *param_2 = 0;
  if (param_3 == 0) {
    if (param_1 != 0) {
      do {
        uVar1 = param_1 % 10;
        param_1 = param_1 / 10;
        local_5 = (byte)uVar1 | 0x30;
        FUN_8000a12e(param_2,&local_5,1);
      } while (param_1 != 0);
    }
  }
  else {
    uVar1 = 0;
    do {
      local_5 = (byte)(param_1 >> (uVar1 & 0x3f)) & 0xf;
      if (local_5 < 10) {
        local_5 = local_5 | 0x30;
      }
      else {
        local_5 = local_5 - 9 | 0x40;
      }
      FUN_8000a12e(param_2,&local_5,1);
      uVar1 = uVar1 + 1;
    } while ((int)uVar1 < 8);
  }
  return;
}


// ==== FUN_8000880a @ 8000880a

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_8000880a(undefined4 param_1)

{
  char cVar1;
  int iVar2;
  uint uVar3;
  uint unaff_D7;
  byte local_5;
  
  FUN_80016134(&DAT_900012c8,0x50,0);
  FUN_8000060e(param_1,&DAT_900100e8);
  DAT_900100ec = (short)(unaff_D7 >> 0x10);
  _DAT_900100ec = unaff_D7;
  if (((int)unaff_D7 < 0) || (FUN_80000630(param_1,&DAT_9000c88c,&DAT_900100e8), (int)unaff_D7 < 0))
  {
    iVar2 = (int)DAT_900100ec;
    FUN_80007fa2(iVar2,unaff_D7 & 0xff);
  }
  else {
    FUN_80015e48("DRIVE  : VOL. NAME = \"           \"   BYTES FREE",&DAT_900012c8,0x2f);
    do {
      uVar3 = unaff_D7 % 10;
      unaff_D7 = unaff_D7 / 10;
      local_5 = (byte)uVar3 | 0x30;
      FUN_8000a12e(&DAT_900012ec,&local_5,1);
    } while (unaff_D7 != 0);
    iVar2 = 0;
    cVar1 = DAT_9000c88c;
    while (cVar1 != '\0') {
      (&DAT_900012de)[iVar2] = (&DAT_9000c88c)[iVar2];
      cVar1 = (&DAT_9000c88d)[iVar2];
      iVar2 = iVar2 + 1;
    }
    DAT_900012ce = (char)param_1 + 'A';
    FUN_80016134(&DAT_90010170,0x50,0);
    FUN_80015e48(&DAT_900012c8,&DAT_90010170,0x50);
    uVar3 = 0;
    do {
      if ((&DAT_900012c8)[uVar3] == ':') break;
      uVar3 = uVar3 + 1;
    } while (uVar3 < 0x50);
    iVar2 = 0;
    for (uVar3 = uVar3 + 2; uVar3 < 0x50; uVar3 = uVar3 + 1) {
      if ((&DAT_900012c8)[uVar3] == '.') {
        uVar3 = uVar3 + 1;
      }
      (&DAT_90010170)[iVar2] = (&DAT_900012c8)[uVar3];
      iVar2 = iVar2 + 1;
    }
    FUN_8000f46a(1,0xf,0x15,7,0,&DAT_900012c8);
  }
  return;
}


// ==== FUN_800089a4 @ 800089a4

void FUN_800089a4(ushort param_1,int param_2)

{
  uint uVar1;
  ushort uVar2;
  ushort uVar3;
  int iVar4;
  
  if (param_1 == 0x124) {
    if (param_2 == 0) {
      return;
    }
    if (DAT_900100f4 == 0) {
      return;
    }
    if (DAT_900100fc < DAT_900101c4) {
      return;
    }
    if ((0x10 < DAT_90006cc8) || (DAT_900100fc != 0)) {
      if (DAT_900100fc != 0) {
        if (DAT_900101c4 == DAT_900100fc) {
          FUN_8000939a(DAT_900100fc - 1,DAT_9000131e,1,DAT_9000c86c == 6);
          FUN_80000d72(DAT_9000131e);
          FUN_8000f254(0,(int)(DAT_900100fc - 1) % 0x37,7,0,DAT_9000131e);
          DAT_900101c4 = DAT_900101c4 - 1;
          FUN_8000f072(1,1);
        }
        DAT_900100fc = DAT_900100fc - 1;
      }
      goto LAB_80008e86;
    }
LAB_80008e06:
    DAT_900100fc = DAT_900100f4 - 1;
  }
  else {
    if (param_1 < 0x125) {
      if (param_1 == 0xd) {
        return;
      }
      if (0xd < param_1) {
        return;
      }
      if (param_1 != 10) {
        return;
      }
      if (DAT_900100f4 == 0) {
        return;
      }
      if (DAT_900100fc < DAT_900101c4) {
        return;
      }
      iVar4 = ((uint)DAT_900100fc % 0x480) * 0x20 + DAT_9000131a;
      FUN_80015e48(iVar4,&DAT_9000c874,0xb);
      FUN_80015e48(iVar4 + 8,&DAT_9000c888,3);
      return;
    }
    if (param_1 == 0x164) {
      if ((0x10 < DAT_90006cc8) && (DAT_900101c4 != 0)) {
        if (DAT_900101c4 < 0x10) {
          uVar3 = DAT_900101c4;
        }
        else {
          uVar3 = 0x10;
        }
        uVar1 = 0;
        if (uVar3 != 0) {
          do {
            FUN_8000939a((uint)DAT_900101c4 - (uVar1 + 1),DAT_9000131e,1,DAT_9000c86c == 6);
            FUN_80000d72(DAT_9000131e);
            FUN_8000f254(0,(int)((uint)DAT_900101c4 - (uVar1 + 1)) % 0x37,7,0,DAT_9000131e);
            uVar2 = (short)uVar1 + 1;
            uVar1 = (uint)uVar2;
          } while (uVar2 < uVar3);
        }
        FUN_8000f072(1,uVar1);
        DAT_900101c4 = DAT_900101c4 - (short)uVar1;
        if (DAT_900100f4 != 0) {
          if (DAT_900100fc < DAT_900101c4) goto LAB_80008e86;
          if (((int)(DAT_900100f4 - 1) < (int)(uint)DAT_900101c4) ||
             (DAT_900101c4 + 0x10 < (uint)DAT_900100f4)) {
            DAT_900100fc = DAT_900101c4 + 0xf;
            goto LAB_80008e86;
          }
          goto LAB_80008e06;
        }
      }
    }
    else if (param_1 < 0x165) {
      if (param_1 != 0x126) {
        return;
      }
      if (param_2 == 0) {
        return;
      }
      if (DAT_900100f4 == 0) {
        return;
      }
      if (DAT_900100fc < DAT_900101c4) {
        return;
      }
      if ((0x10 < DAT_90006cc8) || (DAT_900100f4 - 1 != (uint)DAT_900100fc)) {
        if ((int)(uint)DAT_900100fc < (int)(DAT_900100f4 - 1)) {
          if (DAT_900101c4 + 0xf == (uint)DAT_900100fc) {
            FUN_8000939a(DAT_900100fc + 1,DAT_9000131e,1,DAT_9000c86c == 6);
            FUN_80000d72(DAT_9000131e);
            FUN_8000f254(0,(DAT_900100fc + 1) % 0x37,7,0,DAT_9000131e);
            FUN_8000f072(2,1);
            DAT_900101c4 = DAT_900101c4 + 1;
          }
          DAT_900100fc = DAT_900100fc + 1;
        }
        goto LAB_80008e86;
      }
    }
    else {
      if (param_1 != 0x166) {
        return;
      }
      if (0x10 < DAT_90006cc8) {
        if (DAT_900101c4 + 0x10 < (uint)DAT_90006cc8) {
          if ((int)((DAT_90006cc8 - 0x10) - (uint)DAT_900101c4) < 0x10) {
            uVar3 = DAT_90006cc8 - (DAT_900101c4 + 0x10);
          }
          else {
            uVar3 = 0x10;
          }
          uVar2 = 0;
          if (uVar3 != 0) {
            do {
              FUN_8000939a(DAT_900101c4 + 0x10 + (uint)uVar2,DAT_9000131e,1,DAT_9000c86c == 6);
              FUN_80000d72(DAT_9000131e);
              FUN_8000f254(0,(DAT_900101c4 + 0x10 + (uint)uVar2) % 0x37,7,0,DAT_9000131e);
              uVar2 = uVar2 + 1;
            } while (uVar2 < uVar3);
          }
          FUN_8000f072(2,uVar2);
          DAT_900100fc = uVar2 + DAT_900101c4;
          DAT_900101c4 = DAT_900100fc;
          if (DAT_900100f4 != 0) {
            if ((int)(uint)DAT_900100fc <= (int)(DAT_900100f4 - 1)) goto LAB_80008e86;
            goto LAB_80008e06;
          }
          goto LAB_80008dfc;
        }
      }
      if (DAT_900100f4 != 0) goto LAB_80008e06;
    }
LAB_80008dfc:
    DAT_900100fc = 0;
  }
LAB_80008e86:
  if (param_2 == 1) {
    if (DAT_900100f4 == 0) {
      DAT_9000da04 = 0;
    }
    else if (DAT_900100fc < DAT_900101c4) {
      FUN_80008f4a(DAT_9000c86c,DAT_9000da04,0);
      FUN_80008f4a(DAT_9000c86c,DAT_900100fc,0);
    }
    else if (DAT_9000da04 == DAT_900100fc) {
      if (DAT_9000da04 == DAT_900100fc) {
        FUN_80008f4a(DAT_9000c86c,DAT_900100fc,1);
      }
    }
    else {
      FUN_80008f4a(DAT_9000c86c,DAT_9000da04,0);
      FUN_80008f4a(DAT_9000c86c,DAT_900100fc,1);
      DAT_9000da04 = DAT_900100fc;
    }
  }
  return;
}


// ==== FUN_80008f4a @ 80008f4a

void FUN_80008f4a(int param_1,ushort param_2,int param_3)

{
  undefined4 uVar1;
  int iVar2;
  undefined4 uVar3;
  undefined1 auStack_e [8];
  undefined1 local_6;
  
  uVar1 = 0;
  iVar2 = (uint)param_2 * 0x20 + DAT_9000131a;
  FUN_80016134(auStack_e,8,0x20);
  local_6 = 0;
  FUN_8000f254(3,(uint)param_2 % 0x37,7,0,auStack_e);
  if (param_1 == 6) {
    if ((((*(char *)(iVar2 + 8) == 'D') && (*(char *)(iVar2 + 9) == 'I')) &&
        (*(char *)(iVar2 + 10) == 'R')) || (0x3fff < *(short *)(iVar2 + 0x18))) {
      uVar3 = 8;
    }
    else {
      uVar3 = 6;
    }
    FUN_80015e48(iVar2,auStack_e,uVar3);
    if (*(char *)(iVar2 + 0xb) < '\0') {
      FUN_80000d9e(auStack_e);
    }
  }
  else if (*(char *)(iVar2 + 7) == '@') {
    FUN_80015e48(iVar2,auStack_e,6);
    FUN_80000d9e(auStack_e);
  }
  else {
    FUN_80015e48(iVar2,auStack_e,8);
  }
  if (param_3 == 1) {
    uVar1 = 8;
  }
  FUN_8000f254(3,(uint)param_2 % 0x37,7,uVar1,auStack_e);
  return;
}


// ==== FUN_80009082 @ 80009082

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_80009082(int param_1)

{
  short sVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  int unaff_D7;
  int iVar5;
  uint local_8;
  
  iVar2 = DAT_9000131e;
  iVar5 = DAT_9000131e + 0x42f;
  if (param_1 == 1) {
    if (DAT_90006cd4 == 0) {
      DAT_900100f0 = 0;
      DAT_900101c4 = 0;
      _DAT_9001016c = 0;
      DAT_900100f4 = 0;
      DAT_900100fc = 0;
      DAT_90006cc8 = 0;
      _DAT_9000db34 = 0;
      _DAT_9000db50 = 0;
      DAT_9000da04 = 0;
      _DAT_9000da0c = 0;
      FUN_8000f022();
      FUN_8000efae();
      FUN_8000efbe(1,4,0x10);
    }
    FUN_80016134(DAT_9000131e,0x9000,0);
    FUN_80016134(DAT_9000131a,0x9000,0);
    FUN_80000532(DAT_9000c86c,(uint)DAT_900100f0 % 0x480 + 1,0x480,DAT_9000131a + (uint)DAT_900100f0
                 ,&DAT_900100e8);
    DAT_900100ec = (short)((uint)unaff_D7 >> 0x10);
    _DAT_900100ec = unaff_D7;
    if (DAT_900100ec == 0) {
      _DAT_900100ee = (short)unaff_D7;
      sVar1 = _DAT_900100ee;
      DAT_900100f4 = DAT_900100f4 + _DAT_900100ee;
      if (DAT_9000c86c == 6) {
        FUN_800007e0(6,1,0x80,DAT_9000131a + (uint)DAT_900100f4 * 0x20,&DAT_900100e8);
        DAT_90006cc8 = DAT_900100f4 + _DAT_900100ee + DAT_90006cc8;
      }
      else {
        DAT_90006cc8 = DAT_900100f4;
      }
      if (0x10 < DAT_90006cc8) {
        FUN_80007d86(1);
      }
      FUN_8000939a(DAT_900100f0,DAT_9000131e,0x10,DAT_9000c86c == 6);
      uVar4 = 0;
      if (0 < unaff_D7) {
        do {
          FUN_80000d72(DAT_9000131e + uVar4 * 0x51);
          local_8 = (uint)DAT_900100f0;
          FUN_8000f254(0,(int)(uVar4 + local_8) % 0x37 & 0xff,7,0,DAT_9000131e + uVar4 * 0x51);
          uVar4 = uVar4 + 1;
        } while ((int)uVar4 < unaff_D7);
      }
      FUN_80016134(iVar5,0x50,0x20);
      *(undefined1 *)(iVar2 + 0x47f) = 0;
      while( true ) {
        uVar3 = uVar4;
        if ((int)uVar4 < 0) {
          uVar3 = uVar4 + 0xf;
        }
        if ((uVar3 & 0xfffffff0) == uVar4) break;
        FUN_8000f254(0,(int)(uVar4 + DAT_900100f0) % 0x37 & 0xff,7,0,iVar5);
        uVar4 = uVar4 + 1;
      }
      DAT_900100f0 = sVar1 + DAT_900100f0;
      if (0 < unaff_D7) {
        DAT_90006cd4 = DAT_90006cd4 + 1;
      }
    }
    else {
      iVar2 = (int)DAT_900100ec;
      FUN_80007fa2(iVar2,DAT_9000c86c);
    }
  }
  else if (DAT_90006cd4 != 0) {
    FUN_8000939a(DAT_900101c4,DAT_9000131e,0x20,DAT_9000c86c == 6);
    iVar2 = 0;
    if (0 < unaff_D7) {
      do {
        FUN_8000f254(0,(int)(iVar2 + (uint)DAT_900101c4) % 0x37 & 0xff,7,0,
                     DAT_9000131e + iVar2 * 0x51);
        iVar2 = iVar2 + 1;
      } while (iVar2 < unaff_D7);
    }
    DAT_90006cd4 = DAT_90006cd4 + -1;
  }
  return;
}


// ==== FUN_8000939a @ 8000939a

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_8000939a(ushort param_1,undefined1 *param_2,ushort param_3,int param_4)

{
  uint uVar1;
  char cVar2;
  short sVar3;
  int iVar4;
  int iVar5;
  int unaff_D7;
  char *pcVar6;
  undefined1 *puVar7;
  undefined4 uVar8;
  ushort local_14;
  undefined1 auStack_e [10];
  
  pcVar6 = (char *)(DAT_9000131a + (uint)param_1 * 0x20);
  if (param_4 == 0) {
    local_14 = 0;
    if (param_3 != 0) {
LAB_80009710:
      if ((local_14 < 0x480) && (*pcVar6 != '\0')) {
        FUN_80016134(param_2,0x51,0x20);
        param_2[0x50] = 0;
        if (pcVar6[7] == '@') {
          param_2[1] = pcVar6[6];
          *param_2 = 0x2a;
          iVar4 = 0;
          do {
            if (pcVar6[iVar4] == '_') goto joined_r0x80009758;
            param_2[iVar4 + 3] = pcVar6[iVar4];
            iVar4 = iVar4 + 1;
          } while (iVar4 < 6);
          goto LAB_80009778;
        }
        FUN_80015e48(pcVar6,param_2 + 3,8);
        goto LAB_8000979a;
      }
    }
  }
  else {
    local_14 = 0;
    if (param_3 != 0) {
      do {
        if (0x47f < local_14) {
          return;
        }
        if (*pcVar6 == '\0') {
          return;
        }
        sVar3 = local_14 + param_1 + 1;
        FUN_80016134(param_2,0x51,0x20);
        param_2[0x50] = 0;
        if (pcVar6[0xb] < '\0') {
          *param_2 = 0x2a;
        }
        if ((((pcVar6[8] == 'D') && (pcVar6[9] == 'I')) && (pcVar6[10] == 'R')) ||
           (0x3fff < *(short *)(pcVar6 + 0x18))) {
          FUN_80015e48(pcVar6,param_2 + 3,8);
          param_2[0xc] = 0x3c;
          param_2[0xd] = 0x44;
          param_2[0xe] = 0x49;
          param_2[0xf] = 0x52;
          param_2[0x10] = 0x3e;
        }
        else {
          uVar1 = *(uint *)(pcVar6 + 0xc);
          if (uVar1 < 1000000) {
            iVar4 = 6;
          }
          else if (uVar1 < 10000000) {
            iVar4 = 7;
          }
          else {
            iVar4 = 8;
          }
          FUN_8000873a(uVar1,auStack_e,0);
          for (iVar5 = unaff_D7 + -1; iVar5 < 6; iVar5 = iVar5 + 1) {
            FUN_8000a12e(auStack_e,&DAT_80009398,1);
          }
          if (iVar4 == 6) {
            uVar8 = 6;
            puVar7 = param_2 + 0x12;
          }
          else if (iVar4 == 7) {
            uVar8 = 7;
            puVar7 = param_2 + 0x11;
          }
          else {
            uVar8 = 8;
            puVar7 = param_2 + 0x10;
          }
          FUN_80015e48(auStack_e,puVar7,uVar8);
          FUN_80015e48(pcVar6,param_2 + 3,6);
          FUN_80015e48(pcVar6 + 8,param_2 + 0xc,3);
        }
        param_2[0x19] = (byte)((uint)(int)(short)(ushort)(byte)pcVar6[0x10] / 10) | 0x30;
        param_2[0x1a] = (byte)((uint)(int)(short)(ushort)(byte)pcVar6[0x10] % 10) | 0x30;
        param_2[0x1b] = 0x2f;
        param_2[0x1c] = (byte)((uint)(int)(short)(ushort)(byte)pcVar6[0x11] / 10) | 0x30;
        param_2[0x1d] = (byte)((uint)(int)(short)(ushort)(byte)pcVar6[0x11] % 10) | 0x30;
        param_2[0x1e] = 0x2f;
        param_2[0x1f] = (byte)((uint)(int)(short)(ushort)(byte)pcVar6[0x12] / 10) | 0x30;
        param_2[0x20] = (byte)((uint)(int)(short)(ushort)(byte)pcVar6[0x12] % 10) | 0x30;
        param_2[0x22] = (byte)((uint)(int)(short)(ushort)(byte)pcVar6[0x14] / 10) | 0x30;
        param_2[0x23] = (byte)((uint)(int)(short)(ushort)(byte)pcVar6[0x14] % 10) | 0x30;
        param_2[0x24] = 0x3a;
        param_2[0x25] = (byte)((uint)(int)(short)(ushort)(byte)pcVar6[0x15] / 10) | 0x30;
        param_2[0x26] = (byte)((uint)(int)(short)(ushort)(byte)pcVar6[0x15] % 10) | 0x30;
        if ((((pcVar6[8] != 'D') || (pcVar6[9] != 'I')) || (pcVar6[10] != 'R')) &&
           (*(short *)(pcVar6 + 0x18) < 0x4000)) {
          FUN_80016134(&DAT_900012c8,0x50,0);
          FUN_8000057a(DAT_9000c86c,sVar3,sVar3,0x28,&DAT_900012c8,&DAT_900100e8);
          DAT_900100ec = (short)((uint)unaff_D7 >> 0x10);
          iVar4 = unaff_D7;
          if (((DAT_900100ec != 0) && (iVar4 = unaff_D7, DAT_900100ec != -0x31)) &&
             (iVar4 = unaff_D7, DAT_900100ec != -3)) {
            iVar4 = (int)DAT_900100ec;
            _DAT_900100ec = unaff_D7;
            FUN_80007fa2(iVar4,DAT_9000c86c);
            iVar4 = _DAT_900100ec;
          }
          _DAT_900100ec = iVar4;
          cVar2 = DAT_900012c8;
          for (iVar4 = 0; (cVar2 != '\0' && (iVar4 < 0x28)); iVar4 = iVar4 + 1) {
            param_2[iVar4 + 0x28] = (&DAT_900012c8)[iVar4];
            cVar2 = (&DAT_900012c9)[iVar4];
          }
          for (; iVar4 < 0x28; iVar4 = iVar4 + 1) {
            param_2[iVar4 + 0x28] = 0x20;
          }
        }
        local_14 = local_14 + 1;
        pcVar6 = pcVar6 + 0x20;
        param_2 = param_2 + 0x51;
      } while (local_14 < param_3);
    }
  }
  return;
joined_r0x80009758:
  for (; iVar4 < 6; iVar4 = iVar4 + 1) {
    param_2[iVar4 + 3] = 0x20;
  }
LAB_80009778:
  param_2[9] = 0x20;
  param_2[10] = 0x20;
LAB_8000979a:
  FUN_80015e48(pcVar6 + 8,param_2 + 0xc,3);
  if (*(uint *)(pcVar6 + 0x16) < 1000000) {
    iVar4 = 6;
  }
  else {
    iVar4 = 7;
  }
  FUN_8000873a(*(uint *)(pcVar6 + 0x16),auStack_e,0);
  for (iVar5 = unaff_D7 + -1; iVar5 < 6; iVar5 = iVar5 + 1) {
    FUN_8000a12e(auStack_e,&DAT_80009398,1);
  }
  if (iVar4 == 6) {
    uVar8 = 6;
    puVar7 = param_2 + 0x12;
  }
  else {
    uVar8 = 7;
    puVar7 = param_2 + 0x11;
  }
  FUN_80015e48(auStack_e,puVar7,uVar8);
  param_2[0x19] = (byte)((uint)(int)(short)(ushort)(byte)pcVar6[0xc] / 10) | 0x30;
  param_2[0x1a] = (byte)((uint)(int)(short)(ushort)(byte)pcVar6[0xc] % 10) | 0x30;
  param_2[0x1b] = 0x2f;
  param_2[0x1c] = (byte)((uint)(int)(short)(ushort)(byte)pcVar6[0xd] / 10) | 0x30;
  param_2[0x1d] = (byte)((uint)(int)(short)(ushort)(byte)pcVar6[0xd] % 10) | 0x30;
  param_2[0x1e] = 0x2f;
  param_2[0x1f] = (byte)((uint)(int)(short)(ushort)(byte)pcVar6[0xe] / 10) | 0x30;
  param_2[0x20] = (byte)((uint)(int)(short)(ushort)(byte)pcVar6[0xe] % 10) | 0x30;
  param_2[0x22] = (byte)((uint)(int)(short)(ushort)(byte)pcVar6[0x10] / 10) | 0x30;
  param_2[0x23] = (byte)((uint)(int)(short)(ushort)(byte)pcVar6[0x10] % 10) | 0x30;
  param_2[0x24] = 0x3a;
  param_2[0x25] = (byte)((uint)(int)(short)(ushort)(byte)pcVar6[0x11] / 10) | 0x30;
  param_2[0x26] = (byte)((uint)(int)(short)(ushort)(byte)pcVar6[0x11] % 10) | 0x30;
  local_14 = local_14 + 1;
  pcVar6 = pcVar6 + 0x20;
  param_2 = param_2 + 0x51;
  if (param_3 <= local_14) {
    return;
  }
  goto LAB_80009710;
}


// ==== FUN_8000996c @ 8000996c

void FUN_8000996c(int param_1)

{
  FUN_80016134(&DAT_900012c8,0x50,0);
  FUN_80015e48("DEL   NAME  TYPE   BYTES YY MM DD  TIME               COMMENT",&DAT_900012c8,0x3d);
  if (param_1 == 0) {
    FUN_80016134(&DAT_900012fe,7,0x20);
  }
  else {
    FUN_80015e48("COMMENT",&DAT_900012fe,7);
  }
  FUN_8000f46a(1,0,3,7,0,&DAT_900012c8);
  return;
}


// ==== FUN_800099f6 @ 800099f6

void FUN_800099f6(void)

{
  int unaff_D7;
  undefined2 local_6;
  
  do {
    FUN_80013474(&DAT_900100e8);
  } while (unaff_D7 == 0);
  do {
    FUN_800134d8(&local_6,1,&DAT_900100e8);
  } while (unaff_D7 == 0);
  FUN_80009aaa(local_6);
  return;
}


// ==== FUN_80009a4a @ 80009a4a

undefined4 FUN_80009a4a(void)

{
  undefined2 extraout_D0u;
  undefined2 extraout_D0u_00;
  undefined4 uVar1;
  int unaff_D7;
  undefined1 auStack_8 [4];
  
  FUN_80013474(auStack_8);
  if (unaff_D7 == 0) {
    uVar1 = CONCAT22(extraout_D0u,0xffff);
  }
  else {
    do {
      FUN_800134d8(&DAT_9000da10,(int)(short)unaff_D7,auStack_8);
    } while (unaff_D7 == 0);
    FUN_80009aaa(*(undefined2 *)(&DAT_9000da0e + unaff_D7 * 2));
    uVar1 = CONCAT22(extraout_D0u_00,(short)unaff_D7);
  }
  return uVar1;
}


// ==== FUN_80009aaa @ 80009aaa

short FUN_80009aaa(short param_1)

{
  int unaff_D7;
  
  FUN_8000a192();
  if (unaff_D7 == 2) {
    if (param_1 == 0x123) {
      return 0x163;
    }
    if (param_1 == 0x163) {
      return 0x123;
    }
  }
  return param_1;
}


// ==== FUN_80009b00 @ 80009b00

void FUN_80009b00(char *param_1,int param_2,int param_3)

{
  char cVar1;
  bool bVar2;
  int iVar3;
  uint uVar4;
  uint unaff_D7;
  int iVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  char local_57;
  undefined1 auStack_56 [82];
  
  bVar2 = false;
  FUN_80016134(&DAT_900012c8,0xb,0x20);
  iVar5 = 0;
  cVar1 = *param_1;
  while ((cVar1 != '\0' && (iVar5 < param_3))) {
    iVar5 = iVar5 + 1;
    cVar1 = param_1[iVar5];
  }
  FUN_80015e48(param_1,&DAT_900012c8,iVar5);
  (&DAT_900012c8)[param_3] = 0;
  FUN_8000f46a(1,0x28,0x18,7,0,&DAT_80009aee);
  FUN_8000f46a(1,(char)param_3 + ')',0x18,7,0,&DAT_80009af0);
  FUN_8000f46a(1,0x29,0x18,7,0,&DAT_900012c8);
  FUN_8000f574(0x4c,0x29,0x18,0,0,3);
  FUN_8000f574(0x5f,0,0,0,0,2);
  FUN_8000f574(0x5b,0,0,0,0,1);
  FUN_8000f574(0x5e,0x88,0,0,0,2);
  iVar5 = 0;
  do {
    FUN_800099f6();
    uVar4 = unaff_D7 & 0xffff;
    if (uVar4 == 0x11f) {
      FUN_8000f574(0x5f,1,0,0,0,2);
      bVar2 = true;
    }
    else if (uVar4 < 0x120) {
      if (uVar4 == 0xd) {
        FUN_8000f574(0x5f,1,0,0,0,2);
        bVar2 = true;
      }
      else if (uVar4 < 0xe) {
        if (uVar4 != 10) {
LAB_80009ef6:
          FUN_80015e48(&DAT_900012c8,auStack_56,0x52);
          if (((short)unaff_D7 == 0x124) || ((short)unaff_D7 == 0x126)) {
            uVar4 = 0;
          }
          else {
            FUN_800089a4(unaff_D7 & 0xffff,param_3 == 6);
            uVar4 = unaff_D7;
          }
          FUN_80015e48(auStack_56,&DAT_900012c8,0x52);
          if ((int)uVar4 < 0) {
            FUN_8000a0d0(unaff_D7 & 0xffff);
            local_57 = (char)unaff_D7;
            if (local_57 == '\x01') {
              FUN_8000f574(0x5f,1,0,0,0,2);
              bVar2 = true;
              goto LAB_8000a09c;
            }
            if (local_57 != '\x02') {
              FUN_8000a12e(&DAT_900012c8 + iVar5,&local_57,1);
              (&DAT_900012c8)[param_3] = 0;
              FUN_8000f46a(1,0x29,0x18,7,0,&DAT_900012c8);
              if (iVar5 < param_3 + -1) {
                iVar5 = iVar5 + 1;
              }
              uVar8 = 3;
              uVar7 = 0x18;
              iVar3 = iVar5 + 0x29;
              uVar6 = 0x4c;
              goto LAB_8000a092;
            }
          }
          FUN_8000f574(0x5f,1,0,0,0,2);
          FUN_8000f46a(1,0x29,0x18,7,0,&DAT_900012c8);
          FUN_8000f574(0x4c,iVar5 + 0x29,0x18,0,0,3);
          FUN_8000f574(0x5f,0,0,0,0,2);
          FUN_8000f574(0x5b,0,0,0,0,1);
          uVar7 = 0x88;
          uVar6 = 0x5e;
          goto LAB_8000a02c;
        }
        iVar5 = 0;
        iVar3 = 0;
        if (0 < param_3) {
          do {
            if ((((byte)(&DAT_900012c8)[iVar5] < 0x61) || (0x7a < (byte)(&DAT_900012c8)[iVar5])) &&
               (((byte)(&DAT_900012c8)[iVar5] < 0x41 || (0x5a < (byte)(&DAT_900012c8)[iVar5])))) {
              if (((0x2f < (byte)(&DAT_900012c8)[iVar5]) && ((byte)(&DAT_900012c8)[iVar5] < 0x3a))
                 || ((&DAT_900012c8)[iVar5] == '_')) {
                *(undefined1 *)(param_2 + iVar3) = (&DAT_900012c8)[iVar5];
                goto LAB_80009d42;
              }
            }
            else {
              *(byte *)(param_2 + iVar3) = (&DAT_900012c8)[iVar5] & 0x1f | 0x40;
LAB_80009d42:
              iVar3 = iVar3 + 1;
            }
            iVar5 = iVar5 + 1;
          } while (iVar5 < param_3);
        }
        for (; iVar3 < param_3; iVar3 = iVar3 + 1) {
          *(undefined1 *)(param_2 + iVar3) = 0x20;
        }
        FUN_8000f574(0x5f,1,0,0,0,2);
        bVar2 = true;
      }
      else {
        if (uVar4 != 0x5e) goto LAB_80009ef6;
        if (iVar5 != 0) {
          if (param_3 - iVar5 != 0) {
            FUN_80015e48(&DAT_900012c8 + iVar5,&DAT_900012c7 + iVar5,param_3 - iVar5);
          }
          (&DAT_900012c7)[param_3] = 0x20;
          FUN_8000f46a(1,0x29,0x18,7,0,&DAT_900012c8);
          FUN_8000f574(0x4c,iVar5 + 0x29,0x18,0,0,3);
          goto LAB_80009e00;
        }
      }
    }
    else if (uVar4 == 0x125) {
LAB_80009e00:
      if (iVar5 < 1) goto LAB_8000a09c;
      iVar5 = iVar5 + -1;
      uVar8 = 1;
      uVar7 = 0;
      iVar3 = 0;
      uVar6 = 0x45;
LAB_8000a092:
      FUN_8000f574(uVar6,iVar3,uVar7,0,0,uVar8);
    }
    else {
      if (uVar4 < 0x126) {
        if (uVar4 != 0x123) goto LAB_80009ef6;
      }
      else {
        if (uVar4 == 0x127) {
          if (iVar5 < param_3 + -1) {
            iVar5 = iVar5 + 1;
            uVar8 = 1;
            uVar7 = 0;
            iVar3 = 0;
            uVar6 = 0x44;
            goto LAB_8000a092;
          }
          goto LAB_8000a09c;
        }
        if (uVar4 != 0x1a3) goto LAB_80009ef6;
        FUN_80016134(&DAT_900012c8 + iVar5,param_3 - iVar5,0x20);
      }
      cVar1 = (&DAT_900012c9)[iVar5];
      iVar3 = iVar5;
      while (cVar1 != '\0') {
        (&DAT_900012c8)[iVar3] = (&DAT_900012c9)[iVar3];
        cVar1 = (&DAT_900012ca)[iVar3];
        iVar3 = iVar3 + 1;
      }
      (&DAT_900012c8)[iVar3] = 0x20;
      (&DAT_900012c8)[param_3] = 0;
      FUN_8000f574(0x5f,1,0,0,0,2);
      FUN_8000f46a(1,0x29,0x18,7,0,&DAT_900012c8);
      FUN_8000f574(0x4c,(char)iVar5 + ')',0x18,0,0,3);
      uVar7 = 0;
      uVar6 = 0x5f;
LAB_8000a02c:
      FUN_8000f574(uVar6,uVar7,0,0,0,2);
    }
LAB_8000a09c:
    if (bVar2) {
      FUN_8000f46a(1,0x28,0x18,7,0,"             ");
      return;
    }
  } while( true );
}


// ==== FUN_8000a0d0 @ 8000a0d0

void FUN_8000a0d0(void)

{
  return;
}


// ==== FUN_8000a12e @ 8000a12e

void FUN_8000a12e(char *param_1,undefined4 param_2,int param_3)

{
  char cVar1;
  int iVar2;
  undefined1 auStack_54 [80];
  
  iVar2 = 0;
  cVar1 = *param_1;
  while (cVar1 != '\0') {
    iVar2 = iVar2 + 1;
    cVar1 = param_1[iVar2];
  }
  if ((uint)(param_3 + iVar2) < 0x50) {
    FUN_80015e48(param_1,auStack_54,iVar2 + 1);
    FUN_80015e48(param_2,param_1,param_3);
    FUN_80015e48(auStack_54,param_1 + param_3,iVar2 + 1);
  }
  return;
}


// ==== FUN_8000a192 @ 8000a192

void FUN_8000a192(void)

{
  int iVar1;
  int unaff_D7;
  
  for (iVar1 = 0; (FUN_8001357a(0x72,0x5a), unaff_D7 < 0 && (iVar1 != 0x20)); iVar1 = iVar1 + 1) {
  }
  return;
}


// ==== FUN_8000a1d0 @ 8000a1d0

void FUN_8000a1d0(void)

{
  int iVar1;
  short unaff_D7w;
  
  iVar1 = 0;
  do {
    FUN_80009a4a();
    if (unaff_D7w == -1) {
      return;
    }
    iVar1 = iVar1 + 1;
  } while (iVar1 < 0x100);
  return;
}


// ==== FUN_8000a1f6 @ 8000a1f6

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_8000a1f6(undefined4 param_1)

{
  int iVar1;
  int unaff_D7;
  undefined1 auStack_8 [4];
  
  FUN_80000778(param_1,&DAT_90010118,auStack_8);
  DAT_900100ec = (short)((uint)unaff_D7 >> 0x10);
  _DAT_900100ec = unaff_D7;
  if (unaff_D7 < 0) {
    iVar1 = (int)DAT_900100ec;
    FUN_80007fa2(iVar1,param_1);
  }
  else {
    FUN_80016134(&DAT_900012c8,0x50,0);
    FUN_80015e48(&DAT_90010118,&DAT_900012c8,0x50);
    FUN_8000f46a(1,0x11,0x14,7,0,&DAT_900012c8);
  }
  return;
}


// ==== FUN_8000a284 @ 8000a284

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_8000a284(int param_1)

{
  short sVar1;
  int iVar2;
  uint uVar3;
  uint uVar4;
  int unaff_D7;
  int iVar5;
  uint local_8;
  
  iVar2 = DAT_9000131e;
  iVar5 = DAT_9000131e + 0x42f;
  if (param_1 == 1) {
    if (DAT_90006cd4 == 0) {
      DAT_900100f0 = 0;
      DAT_900101c4 = 0;
      _DAT_9001016c = 0;
      DAT_900100f4 = 0;
      DAT_900100fc = 0;
      DAT_90006cc8 = 0;
      _DAT_9000db34 = 0;
      _DAT_9000db50 = 0;
      DAT_9000da04 = 0;
      _DAT_9000da0c = 0;
      FUN_8000f022();
      FUN_8000efae();
      FUN_8000efbe(1,4,0x10);
    }
    FUN_80016134(DAT_9000131e,0x9000,0);
    FUN_80016134(DAT_9000131a,0x9000,0);
    FUN_800007e0(DAT_9000c86c,1,0x80,DAT_9000131a + (uint)DAT_900100f0,&DAT_900100e8);
    DAT_900100ec = (short)((uint)unaff_D7 >> 0x10);
    _DAT_900100ec = unaff_D7;
    if (DAT_900100ec == 0) {
      _DAT_900100ee = (short)unaff_D7;
      sVar1 = _DAT_900100ee;
      DAT_900100f4 = DAT_900100f4 + _DAT_900100ee;
      if (0x10 < DAT_900100f4) {
        FUN_80007d86(1);
      }
      DAT_90006cc8 = DAT_900100f4;
      FUN_8000939a(DAT_900100f0,DAT_9000131e,0x10,DAT_9000c86c == 6);
      uVar4 = 0;
      if (0 < unaff_D7) {
        do {
          FUN_80000d72(DAT_9000131e + uVar4 * 0x51);
          local_8 = (uint)DAT_900100f0;
          FUN_8000f254(0,(int)(uVar4 + local_8) % 0x37 & 0xff,7,0,DAT_9000131e + uVar4 * 0x51);
          uVar4 = uVar4 + 1;
        } while ((int)uVar4 < unaff_D7);
      }
      FUN_80016134(iVar5,0x50,0x20);
      *(undefined1 *)(iVar2 + 0x47f) = 0;
      while( true ) {
        uVar3 = uVar4;
        if ((int)uVar4 < 0) {
          uVar3 = uVar4 + 0xf;
        }
        if ((uVar3 & 0xfffffff0) == uVar4) break;
        FUN_8000f254(0,(int)(uVar4 + DAT_900100f0) % 0x37 & 0xff,7,0,iVar5);
        uVar4 = uVar4 + 1;
      }
      DAT_900100f0 = sVar1 + DAT_900100f0;
      if (0 < unaff_D7) {
        DAT_90006cd4 = DAT_90006cd4 + 1;
      }
    }
    else {
      iVar2 = (int)DAT_900100ec;
      FUN_80007fa2(iVar2,DAT_9000c86c);
    }
  }
  else if (DAT_90006cd4 != 0) {
    FUN_8000939a(DAT_900101c4,DAT_9000131e,0x20,DAT_9000c86c == 6);
    iVar2 = 0;
    if (0 < unaff_D7) {
      do {
        FUN_8000f254(0,(int)(iVar2 + (uint)DAT_900101c4) % 0x37 & 0xff,7,0,
                     DAT_9000131e + iVar2 * 0x51);
        iVar2 = iVar2 + 1;
      } while (iVar2 < unaff_D7);
    }
    DAT_90006cd4 = DAT_90006cd4 + -1;
  }
  return;
}


// ==== FUN_8000a530 @ 8000a530

void FUN_8000a530(int param_1,int param_2)

{
  char cVar1;
  int iVar2;
  int iVar3;
  uint uVar4;
  uint unaff_D7;
  int iVar5;
  undefined4 uVar6;
  undefined4 uVar7;
  undefined4 uVar8;
  char local_57;
  undefined1 auStack_56 [82];
  
  FUN_80016134(&DAT_900012c8,0x52,0x20);
  (&DAT_900012c8)[param_1] = 0;
  FUN_8000f46a(1,0x18,0x18,7,0,&DAT_80009aee);
  FUN_8000f46a(1,(char)param_1 + '\x19',0x18,7,0,&DAT_80009af0);
  FUN_8000f46a(1,0x19,0x18,7,0,&DAT_900012c8);
  FUN_8000f574(0x4c,0x19,0x18,0,0,3);
  FUN_8000f574(0x5f,0,0,0,0,2);
  FUN_8000f574(0x5b,0,0,0,0,1);
  FUN_8000f574(0x5e,0x88,0,0,0,2);
  iVar5 = 0;
LAB_8000a61c:
  while( true ) {
    FUN_800099f6();
    uVar4 = unaff_D7 & 0xffff;
    if (uVar4 == 0x11f) {
      FUN_8000f574(0x5f,1,0,0,0,2);
      return;
    }
    if (uVar4 < 0x120) break;
    if (uVar4 == 0x125) {
LAB_8000a82a:
      if (0 < iVar5) {
        iVar5 = iVar5 + -1;
        uVar8 = 1;
        uVar7 = 0;
        iVar2 = 0;
        uVar6 = 0x45;
        goto LAB_8000aab4;
      }
    }
    else {
      if (uVar4 < 0x126) {
        if (uVar4 != 0x123) goto LAB_8000a93a;
LAB_8000a888:
        cVar1 = (&DAT_900012c9)[iVar5];
        iVar2 = iVar5;
        while (cVar1 != '\0') {
          (&DAT_900012c8)[iVar2] = (&DAT_900012c9)[iVar2];
          cVar1 = (&DAT_900012ca)[iVar2];
          iVar2 = iVar2 + 1;
        }
        (&DAT_900012c8)[iVar2] = 0x20;
        (&DAT_900012c8)[param_1] = 0;
        FUN_8000f574(0x5f,1,0,0,0,2);
        FUN_8000f46a(1,0x19,0x18,7,0,&DAT_900012c8);
        FUN_8000f574(0x4c,(char)iVar5 + '\x19',0x18,0,0,3);
        uVar7 = 0;
        uVar6 = 0x5f;
        goto LAB_8000aa42;
      }
      if (uVar4 != 0x127) {
        if (uVar4 == 0x1a3) {
          FUN_80016134(&DAT_900012c8 + iVar5,param_1 - iVar5,0x20);
          goto LAB_8000a888;
        }
        goto LAB_8000a93a;
      }
      if (iVar5 < param_1 + -1) {
        iVar5 = iVar5 + 1;
        uVar8 = 1;
        uVar7 = 0;
        iVar2 = 0;
        uVar6 = 0x44;
LAB_8000aab4:
        FUN_8000f574(uVar6,iVar2,uVar7,0,0,uVar8);
      }
    }
  }
  if (uVar4 == 0xd) {
    FUN_8000f574(0x5f,1,0,0,0,2);
    return;
  }
  if (uVar4 < 0xe) {
    if (uVar4 != 10) goto LAB_8000a93a;
    uVar4 = 0;
    if ((iVar5 == 0) && (param_2 == 1)) {
      FUN_8000aacc();
      uVar4 = unaff_D7;
    }
    iVar2 = 0;
    iVar3 = 0;
    if (0 < param_1) {
      do {
        if ((((byte)(&DAT_900012c8)[iVar2] < 0x61) || (0x7a < (byte)(&DAT_900012c8)[iVar2])) &&
           (((byte)(&DAT_900012c8)[iVar2] < 0x41 || (0x5a < (byte)(&DAT_900012c8)[iVar2])))) {
          if ((&DAT_900012c8)[iVar2] != ' ') {
            (&DAT_90010118)[iVar3] = (&DAT_900012c8)[iVar2];
            goto LAB_8000a752;
          }
        }
        else {
          (&DAT_90010118)[iVar3] = (&DAT_900012c8)[iVar2] & 0x1f | 0x40;
LAB_8000a752:
          iVar3 = iVar3 + 1;
        }
        iVar2 = iVar2 + 1;
      } while (iVar2 < param_1);
    }
    for (; iVar3 < param_1; iVar3 = iVar3 + 1) {
      (&DAT_90010118)[iVar3] = 0x20;
    }
    (&DAT_90010118)[param_1] = 0;
    if ((-1 < (int)uVar4) && (DAT_90010118 != ' ')) {
      FUN_8000f574(0x5f,1,0,0,0,2);
      return;
    }
  }
  else {
    if (uVar4 == 0x5e) {
      if (iVar5 != 0) {
        if (param_1 - iVar5 != 0) {
          FUN_80015e48(&DAT_900012c8 + iVar5,&DAT_900012c7 + iVar5,param_1 - iVar5);
        }
        (&DAT_900012c7)[param_1] = 0x20;
        FUN_8000f46a(1,0x19,0x18,7,0,&DAT_900012c8);
        FUN_8000f574(0x4c,iVar5 + 0x19,0x18,0,0,3);
        goto LAB_8000a82a;
      }
      goto LAB_8000a61c;
    }
LAB_8000a93a:
    FUN_80015e48(&DAT_900012c8,auStack_56,0x52);
    FUN_8000aacc();
    FUN_80015e48(auStack_56,&DAT_900012c8,0x52);
    if ((int)unaff_D7 < 0) {
      FUN_8000afae();
      local_57 = (char)unaff_D7;
      if (local_57 == '\x01') {
        FUN_8000f574(0x5f,1,0,0,0,2);
        return;
      }
      if (local_57 != '\x02') {
        FUN_8000a12e(&DAT_900012c8 + iVar5,&local_57,1);
        (&DAT_900012c8)[param_1] = 0;
        FUN_8000f46a(1,0x19,0x18,7,0,&DAT_900012c8);
        if (iVar5 < param_1 + -1) {
          iVar5 = iVar5 + 1;
        }
        uVar8 = 3;
        uVar7 = 0x18;
        iVar2 = iVar5 + 0x19;
        uVar6 = 0x4c;
        goto LAB_8000aab4;
      }
    }
  }
  FUN_8000f574(0x5f,1,0,0,0,2);
  FUN_8000f46a(1,0x19,0x18,7,0,&DAT_900012c8);
  FUN_8000f574(0x4c,iVar5 + 0x19,0x18,0,0,3);
  FUN_8000f574(0x5f,0,0,0,0,2);
  FUN_8000f574(0x5b,0,0,0,0,1);
  uVar7 = 0x88;
  uVar6 = 0x5e;
LAB_8000aa42:
  FUN_8000f574(uVar6,uVar7,0,0,0,2);
  goto LAB_8000a61c;
}


// ==== FUN_8000aacc @ 8000aacc

void FUN_8000aacc(ushort param_1,int param_2)

{
  uint uVar1;
  ushort uVar2;
  ushort uVar3;
  int iVar4;
  
  if (param_1 == 0x124) {
    if (DAT_900100f4 == 0) {
      return;
    }
    if (param_2 == 0) {
      return;
    }
    if ((0x10 < DAT_900100f4) || (DAT_900100fc != 0)) {
      if (DAT_900100fc != 0) {
        if (DAT_900101c4 == DAT_900100fc) {
          FUN_8000939a(DAT_900100fc - 1,DAT_9000131e,1,DAT_9000c86c == 6);
          FUN_80000d72(DAT_9000131e);
          FUN_8000f254(0,(int)(DAT_900100fc - 1) % 0x37,7,0,DAT_9000131e);
          DAT_900101c4 = DAT_900101c4 - 1;
          FUN_8000f072(1,1);
        }
        DAT_900100fc = DAT_900100fc - 1;
      }
      goto LAB_8000af52;
    }
LAB_8000aeb8:
    DAT_900100fc = DAT_900100f4 - 1;
  }
  else {
    if (param_1 < 0x125) {
      if (param_1 == 0xd) {
        return;
      }
      if (0xd < param_1) {
        return;
      }
      if (param_1 != 10) {
        return;
      }
      if (DAT_900100f4 == 0) {
        return;
      }
      iVar4 = ((uint)DAT_900100fc % 0x480) * 0x20 + DAT_9000131a;
      FUN_80015e48(iVar4,&DAT_9000c874,0xb);
      FUN_80015e48(iVar4 + 8,&DAT_9000c888,3);
      FUN_80016134(&DAT_900012c8,0x50,0x20);
      DAT_90001318 = 0;
      FUN_80015e48(iVar4,&DAT_900012c8,8);
      return;
    }
    if (param_1 == 0x164) {
      if (DAT_900100f4 == 0) {
        return;
      }
      if ((0x10 < DAT_900100f4) && (DAT_900101c4 != 0)) {
        if (DAT_900101c4 < 0x10) {
          uVar3 = DAT_900101c4;
        }
        else {
          uVar3 = 0x10;
        }
        uVar1 = 0;
        if (uVar3 != 0) {
          do {
            FUN_8000939a((uint)DAT_900101c4 - (uVar1 + 1),DAT_9000131e,1,DAT_9000c86c == 6);
            FUN_80000d72(DAT_9000131e);
            FUN_8000f254(0,(int)((uint)DAT_900101c4 - (uVar1 + 1)) % 0x37,7,0,DAT_9000131e);
            uVar2 = (short)uVar1 + 1;
            uVar1 = (uint)uVar2;
          } while (uVar2 < uVar3);
        }
        FUN_8000f072(1,uVar1);
        DAT_900101c4 = DAT_900101c4 - (short)uVar1;
        DAT_900100fc = DAT_900101c4 + 0xf;
        goto LAB_8000af52;
      }
    }
    else {
      if (0x164 < param_1) {
        if (param_1 != 0x166) {
          return;
        }
        if (DAT_900100f4 == 0) {
          return;
        }
        if (0x10 < DAT_900100f4) {
          if (DAT_900101c4 + 0x10 < (uint)DAT_900100f4) {
            if ((int)((DAT_900100f4 - 0x10) - (uint)DAT_900101c4) < 0x10) {
              uVar3 = DAT_900100f4 - (DAT_900101c4 + 0x10);
            }
            else {
              uVar3 = 0x10;
            }
            uVar2 = 0;
            if (uVar3 != 0) {
              do {
                FUN_8000939a(DAT_900101c4 + 0x10 + (uint)uVar2,DAT_9000131e,1,DAT_9000c86c == 6);
                FUN_80000d72(DAT_9000131e);
                FUN_8000f254(0,(DAT_900101c4 + 0x10 + (uint)uVar2) % 0x37,7,0,DAT_9000131e);
                uVar2 = uVar2 + 1;
              } while (uVar2 < uVar3);
            }
            FUN_8000f072(2,uVar2);
            DAT_900100fc = DAT_900101c4 + uVar2;
            DAT_900101c4 = DAT_900100fc;
            goto LAB_8000af52;
          }
        }
        goto LAB_8000aeb8;
      }
      if (param_1 != 0x126) {
        return;
      }
      if (DAT_900100f4 == 0) {
        return;
      }
      if (param_2 == 0) {
        return;
      }
      if ((0x10 < DAT_900100f4) || (DAT_900100f4 - 1 != (uint)DAT_900100fc)) {
        if ((int)(uint)DAT_900100fc < (int)(DAT_900100f4 - 1)) {
          if (DAT_900101c4 + 0xf == (uint)DAT_900100fc) {
            FUN_8000939a(DAT_900100fc + 1,DAT_9000131e,1,DAT_9000c86c == 6);
            FUN_80000d72(DAT_9000131e);
            FUN_8000f254(0,(DAT_900100fc + 1) % 0x37,7,0,DAT_9000131e);
            FUN_8000f072(2,1);
            DAT_900101c4 = DAT_900101c4 + 1;
          }
          DAT_900100fc = DAT_900100fc + 1;
        }
        goto LAB_8000af52;
      }
    }
    DAT_900100fc = 0;
  }
LAB_8000af52:
  if (DAT_900100f4 == 0) {
    DAT_9000da04 = 0;
  }
  else if (DAT_9000da04 != DAT_900100fc) {
    FUN_80008f4a(DAT_9000c86c,DAT_9000da04,0);
    FUN_80008f4a(DAT_9000c86c,DAT_900100fc,1);
    DAT_9000da04 = DAT_900100fc;
  }
  return;
}


// ==== FUN_8000afae @ 8000afae

void FUN_8000afae(void)

{
  return;
}


// ==== FUN_8000b01a @ 8000b01a

void FUN_8000b01a(int param_1)

{
  FUN_80016134(&DAT_900012c8,0x50,0);
  FUN_80015e48(s_DEL_NAME_TYPE_YY_MM_DD_TIME_COMM_90001324,&DAT_900012c8,0x3d);
  if (param_1 == 0) {
    FUN_80016134(&DAT_900012fe,7,0x20);
  }
  else {
    FUN_80015e48("COMMENT",&DAT_900012fe,7);
  }
  FUN_8000f46a(1,0,3,7,0,&DAT_900012c8);
  return;
}


// ==== FUN_8000b0a4 @ 8000b0a4

void FUN_8000b0a4(undefined4 param_1,undefined4 param_2,undefined1 param_3,undefined4 param_4,
                 undefined4 param_5,undefined4 param_6)

{
  undefined1 unaff_D7b;
  
  FUN_8000b354(param_3,param_4,param_5,param_6);
  FUN_8000b0de(param_1,param_2,unaff_D7b);
  return;
}


// ==== FUN_8000b0de @ 8000b0de

void FUN_8000b0de(undefined4 param_1,int param_2,char param_3,uint *param_4,int param_5,int param_6)

{
  uint uVar1;
  uint unaff_D7;
  char local_97;
  char local_96 [2];
  undefined2 local_94;
  undefined1 auStack_92 [134];
  char *local_c;
  undefined2 local_8;
  short local_6;
  
  uVar1 = 0;
  if (-1 < param_2) {
    if (param_2 < 1) {
      FUN_8000b204(param_1);
      param_2 = (int)(short)unaff_D7;
      if (param_2 == 0) {
        return;
      }
    }
    else if (0x85 < param_2) {
      param_2 = 0x86;
    }
    local_96[0] = param_3;
    if (param_5 == -1) {
      local_8 = 0xffff;
    }
    else {
      local_8 = (undefined2)param_5;
    }
    if (param_6 == -1) {
      local_6 = -1;
    }
    else {
      local_6 = ((short)param_6 + -1) * 0x10;
    }
    local_94 = (undefined2)param_2;
    FUN_80015e48(param_1,auStack_92,param_2);
    if (param_3 == '\x14') {
      FUN_8000b1e8(auStack_92,param_2);
    }
    local_c = &local_97;
    FUN_800162b4(0x92,8,local_96);
    do {
      FUN_800162cc(0,1000);
      uVar1 = unaff_D7 | uVar1;
    } while ((uVar1 & 0x40000004) == 0);
    if (param_4 != (uint *)0x0) {
      *param_4 = uVar1 & 0xbffffffb;
    }
  }
  return;
}


// ==== FUN_8000b1e8 @ 8000b1e8

void FUN_8000b1e8(byte *param_1,short param_2)

{
  for (; 0 < param_2; param_2 = param_2 + -1) {
    *param_1 = *param_1 & 0x7f;
    param_1 = param_1 + 1;
  }
  return;
}


// ==== FUN_8000b204 @ 8000b204

void FUN_8000b204(char *param_1)

{
  char cVar1;
  short sVar2;
  
  cVar1 = *param_1;
  for (sVar2 = 0; (cVar1 != '\0' && (sVar2 < 0x87)); sVar2 = sVar2 + 1) {
    param_1 = param_1 + 1;
    cVar1 = *param_1;
  }
  return;
}


// ==== FUN_8000b22c @ 8000b22c

void FUN_8000b22c(undefined1 param_1,undefined1 param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5)

{
  undefined1 unaff_D7b;
  
  FUN_8000b354(param_2,param_3,param_4,param_5);
  FUN_8000b29a(param_1,unaff_D7b);
  return;
}


// ==== FUN_8000b26e @ 8000b26e

void FUN_8000b26e(undefined1 param_1,undefined4 param_2)

{
  undefined1 unaff_D7b;
  
  FUN_8000b398(param_1,param_2);
  FUN_8000b29a(0,unaff_D7b);
  return;
}


// ==== FUN_8000b29a @ 8000b29a

undefined4 FUN_8000b29a(undefined1 param_1,undefined1 param_2,uint *param_3,int param_4,int param_5)

{
  undefined4 uVar1;
  uint uVar2;
  uint unaff_D7;
  char local_97;
  undefined1 local_96 [2];
  undefined2 local_94;
  undefined1 local_92;
  char *local_c;
  undefined2 local_8;
  short local_6;
  
  uVar2 = 0;
  local_96[0] = param_2;
  local_94 = 1;
  local_92 = param_1;
  local_c = &local_97;
  if (param_4 == -1) {
    local_8 = 0xffff;
  }
  else {
    local_8 = (undefined2)param_4;
  }
  if (param_5 == -1) {
    local_6 = -1;
  }
  else {
    local_6 = ((short)param_5 + -1) * 0x10;
  }
  FUN_800162b4(0x92,8,local_96);
  do {
    FUN_800162cc(0,1000);
    uVar2 = unaff_D7 | uVar2;
  } while ((uVar2 & 0x40000004) == 0);
  if (param_3 != (uint *)0x0) {
    *param_3 = uVar2 & 0xbffffffb;
  }
  if (((uVar2 & 0x40000000) == 0) && (local_97 != '\0')) {
    uVar1 = 1;
  }
  else {
    uVar1 = 0;
  }
  return uVar1;
}


// ==== FUN_8000b354 @ 8000b354

undefined1 FUN_8000b354(char param_1)

{
  undefined1 uVar1;
  
  if (param_1 == '\x01') {
    uVar1 = 0x11;
  }
  else if (param_1 == '\x02') {
    uVar1 = 0x12;
  }
  else if (param_1 == '\x03') {
    uVar1 = 0x10;
  }
  else if (param_1 == '\x04') {
    uVar1 = 0x13;
  }
  else {
    uVar1 = 0x14;
  }
  return uVar1;
}


// ==== FUN_8000b398 @ 8000b398

undefined1 FUN_8000b398(char param_1)

{
  undefined1 uVar1;
  
  if (param_1 == '\x01') {
    uVar1 = 0x21;
  }
  else if (param_1 == '\x02') {
    uVar1 = 0x22;
  }
  else if (param_1 == '\x03') {
    uVar1 = 0x20;
  }
  else if (param_1 == '\x04') {
    uVar1 = 0x23;
  }
  else {
    uVar1 = 0x24;
  }
  return uVar1;
}


// ==== FUN_8000b3dc @ 8000b3dc

void FUN_8000b3dc(void)

{
  return;
}


// ==== FUN_8000b3e4 @ 8000b3e4

void FUN_8000b3e4(void)

{
  return;
}


// ==== FUN_8000b3ec @ 8000b3ec

void FUN_8000b3ec(void)

{
  return;
}


// ==== FUN_8000b3f4 @ 8000b3f4

void FUN_8000b3f4(int param_1,int param_2)

{
  char cVar1;
  undefined4 uVar2;
  
  if (param_2 >> 8 == 0) {
    uVar2 = 0xf004000;
  }
  else {
    uVar2 = 0xf003000;
  }
  cVar1 = (char)param_2;
  if (param_1 != 2) {
    if (param_1 < 3) {
      if (param_1 == 1) {
        FUN_8000b49a(uVar2,(int)cVar1);
        return;
      }
    }
    else if (param_1 == 3) {
      FUN_8000b4d0(uVar2,(int)cVar1);
      return;
    }
  }
  FUN_8000b462(uVar2,(int)cVar1);
  return;
}


// ==== FUN_8000b462 @ 8000b462

void FUN_8000b462(int param_1,byte param_2)

{
  byte unaff_D7b;
  
  FUN_800162a4(param_1 + 1);
  FUN_800162ac(param_1 + 1,~param_2 & unaff_D7b);
  return;
}


// ==== FUN_8000b49a @ 8000b49a

void FUN_8000b49a(int param_1,byte param_2)

{
  byte unaff_D7b;
  
  FUN_800162a4(param_1 + 1);
  FUN_800162ac(param_1 + 1,param_2 | unaff_D7b);
  return;
}


// ==== FUN_8000b4d0 @ 8000b4d0

void FUN_8000b4d0(int param_1,byte param_2)

{
  byte unaff_D7b;
  
  FUN_800162a4(param_1 + 1);
  FUN_800162ac(param_1 + 1,param_2 & unaff_D7b);
  return;
}


// ==== FUN_8000b506 @ 8000b506

byte FUN_8000b506(void)

{
  return DAT_0f006000 & 0xf;
}


// ==== FUN_8000b51c @ 8000b51c

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_8000b51c(void)

{
  DAT_9000eb5c = 6;
  DAT_9000eb5d = 5;
  DAT_9000eb5e = 1;
  DAT_9000db48 = 6;
  DAT_9000db49 = 5;
  DAT_9000db4a = 1;
  DAT_9000db4b = 6;
  DAT_9000db4c = 5;
  DAT_9000db4d = 1;
  DAT_9000db3c = 6;
  DAT_9000db3d = 5;
  DAT_9000db3e = 1;
  DAT_9000db3f = 6;
  DAT_9000db40 = 5;
  DAT_9000db41 = 1;
  _DAT_9000143e = 1;
  return;
}


// ==== FUN_8000b5f4 @ 8000b5f4

void FUN_8000b5f4(void)

{
  FUN_80007b28(2);
  FUN_80007bd2();
  FUN_80007c28(0,0);
  FUN_80007c28(0x3d,1);
  FUN_80007c28(0x3e,2);
  FUN_80007c28(0x3f,3);
  FUN_80007c28(1,8);
  FUN_8000826a(1);
  FUN_8000f46a(1,0,6,7,0,"1 RS232C INTERFACE 1 (PRINTER)");
  FUN_8000f46a(1,0,8,7,0,"2 RS232C INTERFACE 2 (SMC,PTP/R)");
  FUN_8000f46a(1,0,10,7,0,"3 RS232C INTERFACE 3 (TTY,AUX)");
  return;
}


// ==== FUN_8000b868 @ 8000b868

void FUN_8000b868(int param_1)

{
  FUN_8000f46a(1,0xe,5,7,0,"RE PROGRAM");
  FUN_8000f46a(1,0,6,7,0,"DATA-1     H\"");
  FUN_8000f46a(1,0xf,6,7,0,&DAT_8000b6bf);
  FUN_8000f46a(1,0,8,7,0,"DATA-2     H\"");
  FUN_8000f46a(1,0xf,8,7,0,&DAT_8000b6bf);
  FUN_8000f46a(1,0,10,7,0,"DATA-3     H\"");
  FUN_8000f46a(1,0xf,10,7,0,&DAT_8000b6bf);
  if (param_1 == 1) {
    FUN_8000f46a(1,0x28,6,7,0,"BAUD RATE (1-7:300-19.2K)");
    FUN_8000f46a(1,0x28,8,7,0,"S-2/1 P-E/O P-E/D D-8/7 B4-B1:(1/0)");
    FUN_8000f46a(1,0x28,10,7,0,"FF-E/D CHR-80/132 B2-B1:(1/0)");
  }
  if (param_1 == 2) {
    FUN_8000f46a(1,0x28,6,7,0,"SMC BAUD RATE (1-7:300-19.2K)");
    FUN_8000f46a(1,0x28,0xc,7,0,"PT  BAUD RATE (1-7:300-19.2K)");
  }
  if (param_1 == 3) {
    FUN_8000f46a(1,0x28,6,7,0,"TTY BAUD RATE (1-7:300-19.2K)");
    FUN_8000f46a(1,0x28,0xc,7,0,"AUX BAUD RATE (1-7:300-19.2K)");
  }
  if ((param_1 == 2) || (param_1 == 3)) {
    FUN_8000f46a(1,0,0xc,7,0,"DATA-4     H\"");
    FUN_8000f46a(1,0xf,0xc,7,0,&DAT_8000b6bf);
    FUN_8000f46a(1,0,0xe,7,0,"DATA-5     H\"");
    FUN_8000f46a(1,0xf,0xe,7,0,&DAT_8000b6bf);
    FUN_8000f46a(1,0,0x10,7,0,"DATA-6     H\"");
    FUN_8000f46a(1,0xf,0x10,7,0,&DAT_8000b6bf);
    FUN_8000f46a(1,0x28,8,7,0," :  S-2/1 P-E/O P-E/D D-8/7 B4-B1:(1/0)");
    FUN_8000f46a(1,0x28,10,7,0," :  FF-E/D CHR-80/132 B2-B1:(1/0)");
    FUN_8000f46a(1,0x28,0xe,7,0," :  S-2/1 P-E/D D-8/7 B4-B1:(1/0)");
    FUN_8000f46a(1,0x28,0x10,7,0," :  FF-ED CHR-80/132 B2-B1:(1/0)");
  }
  return;
}


// ==== FUN_8000bb4a @ 8000bb4a

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_8000bb4a(void)

{
  int iVar1;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  undefined1 local_6;
  undefined1 local_5;
  
  local_5 = 0;
  if (_DAT_9000138c == 0) {
    iVar3 = DAT_900013b0 * 2 + 0x15;
    iVar2 = DAT_90001398 * 2 + 6;
    iVar1 = DAT_90001398 * 0x14;
    local_6 = (&DAT_9000c714)[DAT_900013b0 + iVar1];
    if ((&DAT_9000c714)[DAT_900013b0 + iVar1] == (&DAT_9000c78c)[DAT_900013b0 + iVar1]) {
      uVar4 = 0;
      goto LAB_8000bc00;
    }
  }
  else {
    iVar3 = DAT_900013ac + 0xd;
    iVar2 = DAT_90001398 * 2 + 6;
    iVar1 = DAT_90001398 * 5;
    local_6 = (&DAT_9000db14)[DAT_900013ac + iVar1];
    if ((&DAT_9000db14)[DAT_900013ac + iVar1] == (&DAT_9000c6f4)[DAT_900013ac + iVar1]) {
      uVar4 = 0;
      goto LAB_8000bc00;
    }
  }
  uVar4 = 0x10;
LAB_8000bc00:
  FUN_8000f46a(1,iVar3,iVar2,7,uVar4,&local_6);
  return;
}


// ==== FUN_8000bc1a @ 8000bc1a

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_8000bc1a(void)

{
  int iVar1;
  undefined1 local_6;
  undefined1 local_5;
  
  local_5 = 0;
  if (_DAT_9000138c == 0) {
    local_6 = (&DAT_9000c714)[DAT_900013b0 + DAT_90001398 * 0x14];
    iVar1 = DAT_900013b0 * 2 + 0x15;
  }
  else {
    iVar1 = DAT_900013ac + 0xd;
    local_6 = (&DAT_9000db14)[DAT_900013ac + DAT_90001398 * 5];
  }
  FUN_8000f46a(1,iVar1,DAT_90001398 * 2 + 6,7,8,&local_6);
  return;
}


// ==== FUN_8000bcc2 @ 8000bcc2

void FUN_8000bcc2(int param_1)

{
  char cVar1;
  undefined4 unaff_D4;
  int unaff_D5;
  byte unaff_D7b;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  char local_2e [22];
  char acStack_18 [20];
  
  iVar2 = 0;
  iVar3 = 0;
  (&DAT_900100dc)[param_1 * 2] = 0;
  if ((&DAT_9000c6f4)[param_1 * 5] != '\0') {
    do {
      cVar1 = (&DAT_9000c6f4)[iVar2 + param_1 * 5];
      acStack_18[iVar3] = cVar1;
      iVar3 = iVar3 + 1;
      FUN_8000be18(iVar2,cVar1);
      (&DAT_900100dc)[param_1 * 2] = unaff_D7b | (&DAT_900100dc)[param_1 * 2];
      iVar2 = iVar2 + 1;
    } while ((&DAT_9000c6f4)[iVar2 + param_1 * 5] != '\0');
  }
  acStack_18[iVar3] = '\0';
  iVar2 = 0;
  iVar3 = 0;
  (&DAT_900100dd)[param_1 * 2] = 0;
  if ((&DAT_9000db14)[param_1 * 5] != '\0') {
    do {
      cVar1 = (&DAT_9000db14)[iVar2 + param_1 * 5];
      local_2e[iVar3 + 2] = cVar1;
      iVar3 = iVar3 + 1;
      FUN_8000be18(iVar2,cVar1);
      (&DAT_900100dd)[param_1 * 2] = unaff_D7b | (&DAT_900100dd)[param_1 * 2];
      iVar2 = iVar2 + 1;
    } while ((&DAT_9000db14)[iVar2 + param_1 * 5] != '\0');
  }
  local_2e[iVar3 + 2] = '\0';
  switch(param_1) {
  case 0:
    unaff_D5 = 0xd;
    unaff_D4 = 6;
    break;
  case 1:
    unaff_D5 = 0xd;
    unaff_D4 = 8;
    break;
  case 2:
    unaff_D5 = 0xd;
    unaff_D4 = 10;
    break;
  case 3:
    unaff_D5 = 0xd;
    unaff_D4 = 0xc;
    break;
  case 4:
    unaff_D5 = 0xd;
    unaff_D4 = 0xe;
    break;
  case 5:
    unaff_D5 = 0xd;
    unaff_D4 = 0x10;
  }
  if (local_2e[2] != '\0') {
    iVar2 = 0;
    do {
      local_2e[0] = local_2e[iVar2 + 2];
      local_2e[1] = 0;
      if (acStack_18[iVar2] == local_2e[iVar2 + 2]) {
        uVar4 = 0;
      }
      else {
        uVar4 = 0x10;
      }
      FUN_8000f46a(1,iVar2 + unaff_D5,unaff_D4,7,uVar4,local_2e);
      iVar3 = iVar2 + 3;
      iVar2 = iVar2 + 1;
    } while (local_2e[iVar3] != '\0');
  }
  return;
}


// ==== FUN_8000be18 @ 8000be18

char FUN_8000be18(int param_1,undefined1 param_2)

{
  char unaff_D7b;
  
  FUN_8000be3c(param_2);
  if (param_1 == 0) {
    unaff_D7b = unaff_D7b << 4;
  }
  return unaff_D7b;
}


// ==== FUN_8000be3c @ 8000be3c

byte FUN_8000be3c(byte param_1)

{
  if (param_1 < 0x41) {
    param_1 = param_1 & 0xf;
  }
  else {
    param_1 = (param_1 & 0xf) + 9;
  }
  return param_1;
}


// ==== FUN_8000be60 @ 8000be60

void FUN_8000be60(int param_1)

{
  byte bVar1;
  undefined4 unaff_D4;
  int unaff_D5;
  int iVar2;
  int iVar3;
  undefined4 uVar4;
  byte local_2e [22];
  byte abStack_18 [20];
  
  iVar3 = 0;
  iVar2 = 0;
  (&DAT_900100dc)[param_1 * 2] = 0;
  if ((&DAT_9000c78c)[param_1 * 0x14] != '\0') {
    do {
      bVar1 = (&DAT_9000c78c)[iVar3 + param_1 * 0x14];
      abStack_18[iVar2] = bVar1;
      abStack_18[iVar2 + 1] = 0x20;
      iVar2 = iVar2 + 2;
      (&DAT_900100dc)[param_1 * 2] =
           (byte)((bVar1 & 0xffffff01) << (7U - iVar3 & 0x3f)) | (&DAT_900100dc)[param_1 * 2];
      iVar3 = iVar3 + 1;
    } while ((&DAT_9000c78c)[iVar3 + param_1 * 0x14] != '\0');
  }
  abStack_18[iVar2] = 0;
  iVar3 = 0;
  iVar2 = 0;
  (&DAT_900100dd)[param_1 * 2] = 0;
  if ((&DAT_9000c714)[param_1 * 0x14] != '\0') {
    do {
      bVar1 = (&DAT_9000c714)[iVar3 + param_1 * 0x14];
      local_2e[iVar2 + 2] = bVar1;
      local_2e[iVar2 + 3] = 0x20;
      iVar2 = iVar2 + 2;
      (&DAT_900100dd)[param_1 * 2] =
           (byte)((bVar1 & 0xffffff01) << (7U - iVar3 & 0x3f)) | (&DAT_900100dd)[param_1 * 2];
      iVar3 = iVar3 + 1;
    } while ((&DAT_9000c714)[iVar3 + param_1 * 0x14] != '\0');
  }
  local_2e[iVar2 + 2] = 0;
  switch(param_1) {
  case 0:
    unaff_D5 = 0x15;
    unaff_D4 = 6;
    break;
  case 1:
    unaff_D5 = 0x15;
    unaff_D4 = 8;
    break;
  case 2:
    unaff_D5 = 0x15;
    unaff_D4 = 10;
    break;
  case 3:
    unaff_D5 = 0x15;
    unaff_D4 = 0xc;
    break;
  case 4:
    unaff_D5 = 0x15;
    unaff_D4 = 0xe;
    break;
  case 5:
    unaff_D5 = 0x15;
    unaff_D4 = 0x10;
  }
  if (local_2e[2] != '\0') {
    iVar2 = 0;
    do {
      local_2e[0] = local_2e[iVar2 + 2];
      local_2e[1] = 0;
      if (abStack_18[iVar2] == local_2e[iVar2 + 2]) {
        uVar4 = 0;
      }
      else {
        uVar4 = 0x10;
      }
      FUN_8000f46a(1,iVar2 + unaff_D5,unaff_D4,7,uVar4,local_2e);
      iVar3 = iVar2 + 3;
      iVar2 = iVar2 + 1;
    } while (local_2e[iVar3] != 0);
  }
  return;
}


// ==== FUN_8000c024 @ 8000c024

void FUN_8000c024(void)

{
  FUN_80007b28(0);
  FUN_80007bd2();
  FUN_80007c28(0,0);
  FUN_80007c28(0x40,1);
  FUN_80007c28(0x41,2);
  FUN_80007c28(0x42,3);
  FUN_80007c28(0x32,4);
  FUN_80007c28(0x43,8);
  FUN_8000826a(1);
  FUN_8000f46a(1,0x11,6,7,0,"   CALENDER TIMER PRESET");
  FUN_8000f46a(1,0x11,8,7,0,"1  YEAR   =");
  FUN_8000f46a(1,0x11,10,7,0,"2  MONTH  =");
  FUN_8000f46a(1,0x11,0xc,7,0,"3  DAY    =");
  FUN_8000f46a(1,0x11,0xe,7,0,"4  TIME   =");
  return;
}


// ==== FUN_8000c126 @ 8000c126

void FUN_8000c126(void)

{
  undefined *puVar1;
  undefined1 auStack_a [6];
  
  FUN_8001629c(&DAT_90006ccc);
  if (DAT_90006ccc < 0x50) {
    puVar1 = &DAT_8000c11c;
  }
  else {
    puVar1 = &DAT_8000c11f;
  }
  FUN_8000f46a(1,0x41,6,7,0,puVar1);
  FUN_8000dc2e(DAT_90006ccc,auStack_a,2);
  FUN_8000f46a(1,0x43,6,7,0,auStack_a);
  FUN_8000f46a(1,0x45,6,7,0,&DAT_8000c122);
  FUN_8000dc2e(DAT_90006ccd,auStack_a,2);
  FUN_8000f46a(1,0x46,6,7,0,auStack_a);
  FUN_8000f46a(1,0x48,6,7,0,&DAT_8000c122);
  FUN_8000dc2e(DAT_90006cce,auStack_a,2);
  FUN_8000f46a(1,0x49,6,7,0,auStack_a);
  FUN_8000dc2e(DAT_90006cd0,auStack_a,2);
  FUN_8000f46a(1,0x46,7,7,0,auStack_a);
  FUN_8000f46a(1,0x48,7,7,0,&DAT_8000c124);
  FUN_8000dc2e(DAT_90006cd1,auStack_a,2);
  FUN_8000f46a(1,0x49,7,7,0,auStack_a);
  FUN_8000f46a(1,0x4b,7,7,0,&DAT_8000c124);
  FUN_8000dc2e(DAT_90006cd2,auStack_a,2);
  FUN_8000f46a(1,0x4c,7,7,0,auStack_a);
  return;
}


// ==== FUN_8000c2f6 @ 8000c2f6

void FUN_8000c2f6(void)

{
  undefined1 local_6;
  undefined1 local_5;
  
  local_5 = 0;
  local_6 = (&DAT_9000c264)[DAT_9000140c + DAT_900013f8 * 7];
  FUN_8000f46a(1,DAT_9000140c + *(int *)(&DAT_90001410 + DAT_900013f8 * 4),
               *(undefined4 *)(&DAT_90001420 + DAT_900013f8 * 4),7,0,&local_6);
  return;
}


// ==== FUN_8000c352 @ 8000c352

void FUN_8000c352(void)

{
  undefined1 local_6;
  undefined1 local_5;
  
  local_5 = 0;
  local_6 = (&DAT_9000c264)[DAT_9000140c + DAT_900013f8 * 7];
  FUN_8000f46a(1,DAT_9000140c + *(int *)(&DAT_90001410 + DAT_900013f8 * 4),
               *(undefined4 *)(&DAT_90001420 + DAT_900013f8 * 4),7,8,&local_6);
  return;
}


// ==== FUN_8000c3b0 @ 8000c3b0

void FUN_8000c3b0(int param_1)

{
  FUN_8000f46a(1,*(undefined4 *)(&DAT_90001410 + param_1 * 4),
               *(undefined4 *)(&DAT_90001420 + param_1 * 4),7,0,&DAT_9000c264 + param_1 * 7);
  return;
}


// ==== FUN_8000c500 @ 8000c500

void FUN_8000c500(void)

{
  int iVar1;
  ushort unaff_D7w;
  
  iVar1 = 5;
  do {
    FUN_80008700(iVar1);
    iVar1 = iVar1 + 1;
  } while (iVar1 < 0x14);
  FUN_80007bd2();
  FUN_80007c28(0,0);
  FUN_80007c28(0x35,1);
  FUN_80007c28(1,8);
  FUN_800081e0(0xe);
  FUN_8000826a(0xe);
  do {
    while( true ) {
      FUN_800099f6();
      if (unaff_D7w == 0x118) {
        FUN_8000b51c();
        return;
      }
      if (0x118 < unaff_D7w) break;
      if (unaff_D7w == 0xd) {
        return;
      }
    }
  } while (unaff_D7w != 0x11f);
  return;
}


// ==== FUN_8000c596 @ 8000c596

void FUN_8000c596(void)

{
  int iVar1;
  uint uVar2;
  uint unaff_D7;
  
  do {
    iVar1 = 5;
    do {
      FUN_80008700(iVar1);
      iVar1 = iVar1 + 1;
    } while (iVar1 < 0x14);
    FUN_8000b5f4();
    do {
      while( true ) {
        FUN_800099f6();
        uVar2 = unaff_D7 & 0xffff;
        if (uVar2 == 0x119) {
          FUN_8000ca30();
          goto joined_r0x8000c608;
        }
        if (uVar2 < 0x11a) break;
        if (uVar2 == 0x11a) {
          FUN_8000ce36();
          goto joined_r0x8000c608;
        }
        if (uVar2 == 0x11f) {
          return;
        }
      }
      if (uVar2 == 0xd) {
        return;
      }
    } while (uVar2 != 0x118);
    FUN_8000c62a();
joined_r0x8000c608:
    if (unaff_D7 == 0xfffffffa) {
      return;
    }
  } while( true );
}


// ==== FUN_8000c62a @ 8000c62a

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_8000c62a(void)

{
  int iVar1;
  ushort unaff_D7w;
  char cVar2;
  int iVar3;
  int iVar4;
  bool bVar5;
  undefined4 uVar6;
  
  iVar4 = 5;
  do {
    FUN_80008700(iVar4);
    iVar4 = iVar4 + 1;
  } while (iVar4 < 0x14);
  FUN_80007b28(3);
  FUN_80007bd2();
  FUN_8000d23c(1);
  FUN_800081e0(0xf);
  FUN_8000826a(1);
  FUN_8000b868(1);
  iVar4 = 0;
  do {
    (&DAT_9000da08)[iVar4] = (&DAT_9000eb5c)[iVar4];
    iVar4 = iVar4 + 1;
  } while (iVar4 < 3);
  iVar4 = 0;
  do {
    FUN_8000d4fc((&DAT_9000da08)[iVar4],&DAT_9000c6f4 + iVar4 * 5);
    iVar4 = iVar4 + 1;
  } while (iVar4 < 3);
  iVar4 = 0;
  do {
    iVar3 = 0;
    if ((&DAT_9000c6f4)[iVar4 * 5] != '\0') {
      iVar1 = iVar4 * 5;
      do {
        (&DAT_9000db14)[iVar3 + iVar1] = (&DAT_9000c6f4)[iVar3 + iVar1];
        iVar3 = iVar3 + 1;
      } while ((&DAT_9000c6f4)[iVar3 + iVar1] != '\0');
    }
    iVar4 = iVar4 + 1;
  } while (iVar4 < 3);
  iVar4 = 0;
  do {
    FUN_8000d48e((&DAT_9000da08)[iVar4],&DAT_9000c78c + iVar4 * 0x14);
    iVar4 = iVar4 + 1;
  } while (iVar4 < 3);
  iVar4 = 0;
  do {
    iVar3 = 0;
    if ((&DAT_9000c78c)[iVar4 * 0x14] != '\0') {
      iVar1 = iVar4 * 0x14;
      do {
        (&DAT_9000c714)[iVar3 + iVar1] = (&DAT_9000c78c)[iVar3 + iVar1];
        iVar3 = iVar3 + 1;
      } while ((&DAT_9000c78c)[iVar3 + iVar1] != '\0');
    }
    iVar4 = iVar4 + 1;
  } while (iVar4 < 3);
  iVar4 = 0;
  do {
    FUN_8000bcc2(iVar4);
    iVar4 = iVar4 + 1;
  } while (iVar4 < 3);
  iVar4 = 0;
  do {
    FUN_8000be60(iVar4);
    iVar4 = iVar4 + 1;
  } while (iVar4 < 3);
  _DAT_9000138c = 1;
  DAT_90001398 = 0;
LAB_8000c7be:
  FUN_8000bc1a();
  FUN_800099f6();
  FUN_8000dc62(unaff_D7w);
  if (unaff_D7w == 0x11f) {
    FUN_80008700(5);
    return;
  }
  if (unaff_D7w < 0x120) {
    if (unaff_D7w < 0x3a) {
      if (0x2f < unaff_D7w) goto LAB_8000c856;
      if (unaff_D7w == 0xd) {
        iVar4 = 0;
        do {
          (&DAT_9000eb5c)[iVar4] = (&DAT_9000da08)[iVar4];
          iVar4 = iVar4 + 1;
        } while (iVar4 < 3);
        return;
      }
    }
    else if (0x40 < unaff_D7w) {
      if (0x46 < unaff_D7w) {
        if (unaff_D7w == 0x11e) {
          bVar5 = _DAT_9000138c == 0;
          if (bVar5) {
            FUN_8000bb4a();
            _DAT_9000138c = 1;
            FUN_800081e0(0xf);
          }
          else {
            FUN_8000bb4a();
            _DAT_9000138c = 0;
            FUN_800081e0(0x10);
          }
          FUN_8000d23c(bVar5);
          DAT_900013ac = 0;
          DAT_900013b0 = 0;
        }
        goto LAB_8000c7be;
      }
LAB_8000c856:
      FUN_8000a0d0();
      cVar2 = (char)unaff_D7w;
      if (_DAT_9000138c == 0) {
        if ((cVar2 != '0') && (cVar2 != '1')) goto LAB_8000c7be;
        (&DAT_9000c714)[DAT_900013b0 + DAT_90001398 * 0x14] = cVar2;
        FUN_8000d4c4(&DAT_9000c714 + DAT_90001398 * 0x14);
        (&DAT_9000da08)[DAT_90001398] = cVar2;
        FUN_8000d4fc(cVar2,&DAT_9000db14 + DAT_90001398 * 5);
      }
      else {
        (&DAT_9000db14)[DAT_900013ac + DAT_90001398 * 5] = cVar2;
        FUN_8000d546(&DAT_9000db14 + DAT_90001398 * 5);
        (&DAT_9000da08)[DAT_90001398] = cVar2;
        FUN_8000d48e(cVar2,&DAT_9000c714 + DAT_90001398 * 0x14);
      }
      FUN_8000bcc2(DAT_90001398);
      FUN_8000be60(DAT_90001398);
      FUN_8000d30e(1,2);
    }
    goto LAB_8000c7be;
  }
  if (unaff_D7w == 0x126) {
    uVar6 = 3;
  }
  else if (unaff_D7w < 0x127) {
    if (unaff_D7w == 0x124) {
      uVar6 = 2;
    }
    else {
      if (unaff_D7w != 0x125) goto LAB_8000c7be;
      uVar6 = 0;
    }
  }
  else {
    if (unaff_D7w != 0x127) {
      if ((unaff_D7w < 0x13a) && (0x12f < unaff_D7w)) goto LAB_8000c856;
      goto LAB_8000c7be;
    }
    uVar6 = 1;
  }
  FUN_8000d30e(uVar6,2);
  goto LAB_8000c7be;
}


// ==== FUN_8000ca30 @ 8000ca30

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_8000ca30(void)

{
  int iVar1;
  ushort unaff_D7w;
  char cVar2;
  int iVar3;
  int iVar4;
  bool bVar5;
  undefined4 uVar6;
  
  iVar4 = 5;
  do {
    FUN_80008700(iVar4);
    iVar4 = iVar4 + 1;
  } while (iVar4 < 0x14);
  FUN_80007b28(4);
  FUN_80007bd2();
  FUN_8000d23c(1);
  FUN_800081e0(0xf);
  FUN_8000826a(1);
  FUN_8000b868(2);
  iVar4 = 0;
  do {
    (&DAT_9000d9f4)[iVar4] = (&DAT_9000db48)[iVar4];
    iVar4 = iVar4 + 1;
  } while (iVar4 < 6);
  iVar4 = 0;
  do {
    FUN_8000d4fc((&DAT_9000d9f4)[iVar4],&DAT_9000c6f4 + iVar4 * 5);
    iVar4 = iVar4 + 1;
  } while (iVar4 < 6);
  iVar4 = 0;
  do {
    iVar3 = 0;
    if ((&DAT_9000c6f4)[iVar4 * 5] != '\0') {
      iVar1 = iVar4 * 5;
      do {
        (&DAT_9000db14)[iVar3 + iVar1] = (&DAT_9000c6f4)[iVar3 + iVar1];
        iVar3 = iVar3 + 1;
      } while ((&DAT_9000c6f4)[iVar3 + iVar1] != '\0');
    }
    iVar4 = iVar4 + 1;
  } while (iVar4 < 6);
  iVar4 = 0;
  do {
    FUN_8000d48e((&DAT_9000d9f4)[iVar4],&DAT_9000c78c + iVar4 * 0x14);
    iVar4 = iVar4 + 1;
  } while (iVar4 < 6);
  iVar4 = 0;
  do {
    iVar3 = 0;
    if ((&DAT_9000c78c)[iVar4 * 0x14] != '\0') {
      iVar1 = iVar4 * 0x14;
      do {
        (&DAT_9000c714)[iVar3 + iVar1] = (&DAT_9000c78c)[iVar3 + iVar1];
        iVar3 = iVar3 + 1;
      } while ((&DAT_9000c78c)[iVar3 + iVar1] != '\0');
    }
    iVar4 = iVar4 + 1;
  } while (iVar4 < 6);
  iVar4 = 0;
  do {
    FUN_8000bcc2(iVar4);
    iVar4 = iVar4 + 1;
  } while (iVar4 < 6);
  iVar4 = 0;
  do {
    FUN_8000be60(iVar4);
    iVar4 = iVar4 + 1;
  } while (iVar4 < 6);
  _DAT_9000138c = 1;
  DAT_90001398 = 0;
LAB_8000cbc4:
  FUN_8000bc1a();
  FUN_800099f6();
  FUN_8000dc62(unaff_D7w);
  if (unaff_D7w == 0x11f) {
    FUN_80008700(5);
    return;
  }
  if (unaff_D7w < 0x120) {
    if (unaff_D7w < 0x3a) {
      if (0x2f < unaff_D7w) goto LAB_8000cc5c;
      if (unaff_D7w == 0xd) {
        iVar4 = 0;
        do {
          (&DAT_9000db48)[iVar4] = (&DAT_9000d9f4)[iVar4];
          iVar4 = iVar4 + 1;
        } while (iVar4 < 6);
        return;
      }
    }
    else if (0x40 < unaff_D7w) {
      if (0x46 < unaff_D7w) {
        if (unaff_D7w == 0x11e) {
          bVar5 = _DAT_9000138c == 0;
          if (bVar5) {
            FUN_8000bb4a();
            _DAT_9000138c = 1;
            FUN_800081e0(0xf);
          }
          else {
            FUN_8000bb4a();
            _DAT_9000138c = 0;
            FUN_800081e0(0x10);
          }
          FUN_8000d23c(bVar5);
          DAT_900013ac = 0;
          DAT_900013b0 = 0;
        }
        goto LAB_8000cbc4;
      }
LAB_8000cc5c:
      FUN_8000a0d0();
      cVar2 = (char)unaff_D7w;
      if (_DAT_9000138c == 0) {
        if ((cVar2 != '0') && (cVar2 != '1')) goto LAB_8000cbc4;
        (&DAT_9000c714)[DAT_900013b0 + DAT_90001398 * 0x14] = cVar2;
        FUN_8000d4c4(&DAT_9000c714 + DAT_90001398 * 0x14);
        (&DAT_9000d9f4)[DAT_90001398] = cVar2;
        FUN_8000d4fc(cVar2,&DAT_9000db14 + DAT_90001398 * 5);
      }
      else {
        (&DAT_9000db14)[DAT_900013ac + DAT_90001398 * 5] = cVar2;
        FUN_8000d546(&DAT_9000db14 + DAT_90001398 * 5);
        (&DAT_9000d9f4)[DAT_90001398] = cVar2;
        FUN_8000d48e(cVar2,&DAT_9000c714 + DAT_90001398 * 0x14);
      }
      FUN_8000bcc2(DAT_90001398);
      FUN_8000be60(DAT_90001398);
      FUN_8000d30e(1,5);
    }
    goto LAB_8000cbc4;
  }
  if (unaff_D7w == 0x126) {
    uVar6 = 3;
  }
  else if (unaff_D7w < 0x127) {
    if (unaff_D7w == 0x124) {
      uVar6 = 2;
    }
    else {
      if (unaff_D7w != 0x125) goto LAB_8000cbc4;
      uVar6 = 0;
    }
  }
  else {
    if (unaff_D7w != 0x127) {
      if ((unaff_D7w < 0x13a) && (0x12f < unaff_D7w)) goto LAB_8000cc5c;
      goto LAB_8000cbc4;
    }
    uVar6 = 1;
  }
  FUN_8000d30e(uVar6,5);
  goto LAB_8000cbc4;
}


// ==== FUN_8000ce36 @ 8000ce36

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_8000ce36(void)

{
  int iVar1;
  ushort unaff_D7w;
  char cVar2;
  int iVar3;
  int iVar4;
  bool bVar5;
  undefined4 uVar6;
  
  iVar4 = 5;
  do {
    FUN_80008700(iVar4);
    iVar4 = iVar4 + 1;
  } while (iVar4 < 0x14);
  FUN_80007b28(5);
  FUN_80007bd2();
  FUN_8000d23c(1);
  FUN_800081e0(0xf);
  FUN_8000826a(1);
  FUN_8000b868(3);
  iVar4 = 0;
  do {
    (&DAT_9000d9fc)[iVar4] = (&DAT_9000db3c)[iVar4];
    iVar4 = iVar4 + 1;
  } while (iVar4 < 6);
  iVar4 = 0;
  do {
    FUN_8000d4fc((&DAT_9000d9fc)[iVar4],&DAT_9000c6f4 + iVar4 * 5);
    iVar4 = iVar4 + 1;
  } while (iVar4 < 6);
  iVar4 = 0;
  do {
    iVar3 = 0;
    if ((&DAT_9000c6f4)[iVar4 * 5] != '\0') {
      iVar1 = iVar4 * 5;
      do {
        (&DAT_9000db14)[iVar3 + iVar1] = (&DAT_9000c6f4)[iVar3 + iVar1];
        iVar3 = iVar3 + 1;
      } while ((&DAT_9000c6f4)[iVar3 + iVar1] != '\0');
    }
    iVar4 = iVar4 + 1;
  } while (iVar4 < 6);
  iVar4 = 0;
  do {
    FUN_8000d48e((&DAT_9000d9fc)[iVar4],&DAT_9000c78c + iVar4 * 0x14);
    iVar4 = iVar4 + 1;
  } while (iVar4 < 6);
  iVar4 = 0;
  do {
    iVar3 = 0;
    if ((&DAT_9000c78c)[iVar4 * 0x14] != '\0') {
      iVar1 = iVar4 * 0x14;
      do {
        (&DAT_9000c714)[iVar3 + iVar1] = (&DAT_9000c78c)[iVar3 + iVar1];
        iVar3 = iVar3 + 1;
      } while ((&DAT_9000c78c)[iVar3 + iVar1] != '\0');
    }
    iVar4 = iVar4 + 1;
  } while (iVar4 < 6);
  iVar4 = 0;
  do {
    FUN_8000bcc2(iVar4);
    iVar4 = iVar4 + 1;
  } while (iVar4 < 6);
  iVar4 = 0;
  do {
    FUN_8000be60(iVar4);
    iVar4 = iVar4 + 1;
  } while (iVar4 < 6);
  _DAT_9000138c = 1;
  DAT_90001398 = 0;
LAB_8000cfca:
  FUN_8000bc1a();
  FUN_800099f6();
  FUN_8000dc62(unaff_D7w);
  if (unaff_D7w == 0x11f) {
    FUN_80008700(5);
    return;
  }
  if (unaff_D7w < 0x120) {
    if (unaff_D7w < 0x3a) {
      if (0x2f < unaff_D7w) goto LAB_8000d062;
      if (unaff_D7w == 0xd) {
        iVar4 = 0;
        do {
          (&DAT_9000db3c)[iVar4] = (&DAT_9000d9fc)[iVar4];
          iVar4 = iVar4 + 1;
        } while (iVar4 < 6);
        return;
      }
    }
    else if (0x40 < unaff_D7w) {
      if (0x46 < unaff_D7w) {
        if (unaff_D7w == 0x11e) {
          bVar5 = _DAT_9000138c == 0;
          if (bVar5) {
            FUN_8000bb4a();
            _DAT_9000138c = 1;
            FUN_800081e0(0xf);
          }
          else {
            FUN_8000bb4a();
            _DAT_9000138c = 0;
            FUN_800081e0(0x10);
          }
          FUN_8000d23c(bVar5);
          DAT_900013ac = 0;
          DAT_900013b0 = 0;
        }
        goto LAB_8000cfca;
      }
LAB_8000d062:
      FUN_8000a0d0();
      cVar2 = (char)unaff_D7w;
      if (_DAT_9000138c == 0) {
        if ((cVar2 != '0') && (cVar2 != '1')) goto LAB_8000cfca;
        (&DAT_9000c714)[DAT_900013b0 + DAT_90001398 * 0x14] = cVar2;
        FUN_8000d4c4(&DAT_9000c714 + DAT_90001398 * 0x14);
        (&DAT_9000d9fc)[DAT_90001398] = cVar2;
        FUN_8000d4fc(cVar2,&DAT_9000db14 + DAT_90001398 * 5);
      }
      else {
        (&DAT_9000db14)[DAT_900013ac + DAT_90001398 * 5] = cVar2;
        FUN_8000d546(&DAT_9000db14 + DAT_90001398 * 5);
        (&DAT_9000d9fc)[DAT_90001398] = cVar2;
        FUN_8000d48e(cVar2,&DAT_9000c714 + DAT_90001398 * 0x14);
      }
      FUN_8000bcc2(DAT_90001398);
      FUN_8000be60(DAT_90001398);
      FUN_8000d30e(1,5);
    }
    goto LAB_8000cfca;
  }
  if (unaff_D7w == 0x126) {
    uVar6 = 3;
  }
  else if (unaff_D7w < 0x127) {
    if (unaff_D7w == 0x124) {
      uVar6 = 2;
    }
    else {
      if (unaff_D7w != 0x125) goto LAB_8000cfca;
      uVar6 = 0;
    }
  }
  else {
    if (unaff_D7w != 0x127) {
      if ((unaff_D7w < 0x13a) && (0x12f < unaff_D7w)) goto LAB_8000d062;
      goto LAB_8000cfca;
    }
    uVar6 = 1;
  }
  FUN_8000d30e(uVar6,5);
  goto LAB_8000cfca;
}


// ==== FUN_8000d23c @ 8000d23c

void FUN_8000d23c(int param_1)

{
  undefined4 *puVar1;
  undefined4 uStack_18;
  undefined4 uStack_14;
  undefined4 local_10;
  undefined4 local_c;
  
  if (param_1 == 0) {
    local_c = 0;
    local_10 = 0;
    uStack_14 = 0x8000d254;
    FUN_80007c28();
    uStack_14 = 7;
    uStack_18 = 0x36;
    FUN_80007c28();
    puVar1 = &uStack_18;
  }
  else {
    local_c = 0;
    local_10 = 0;
    uStack_14 = 0x8000d26c;
    FUN_80007c28();
    uStack_14 = 1;
    uStack_18 = 0x37;
    FUN_80007c28();
    FUN_80007c28(0x38,2);
    FUN_80007c28(0x39,3);
    local_c = 4;
    local_10 = 0x3a;
    uStack_14 = 0x8000d298;
    FUN_80007c28();
    uStack_14 = 5;
    uStack_18 = 0x3b;
    FUN_80007c28();
    FUN_80007c28(0x3c,6);
    FUN_80007c28(0x36,7);
    puVar1 = (undefined4 *)((int)register0x0000003c + -8);
  }
  *(undefined4 *)((int)puVar1 + -4) = 8;
  *(undefined4 *)((int)puVar1 + -8) = 1;
  *(undefined4 *)((int)puVar1 + -0xc) = 0x8000d2c4;
  FUN_80007c28();
  return;
}


// ==== FUN_8000d2cc @ 8000d2cc

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_8000d2cc(undefined4 param_1,undefined4 param_2)

{
  FUN_8000bb4a();
  if (_DAT_9000138c == 0) {
    DAT_900013b0 = param_2;
  }
  else {
    DAT_900013ac = param_2;
  }
  DAT_90001398 = param_1;
  return;
}


// ==== FUN_8000d30e @ 8000d30e

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_8000d30e(int param_1,int param_2)

{
  FUN_8000bb4a();
  if (_DAT_9000138c != 0) {
    if (param_1 == 0) {
      if (DAT_90001398 == 0) {
        if (DAT_900013ac != 0) goto LAB_8000d40a;
      }
      else if (DAT_900013ac == 0) {
        DAT_90001398 = DAT_90001398 + -1;
        DAT_900013ac = 1;
      }
      else {
LAB_8000d40a:
        DAT_900013ac = DAT_900013ac + -1;
      }
    }
    if (param_1 == 1) {
      if (DAT_90001398 < param_2) {
        if (0 < (int)DAT_900013ac) {
          DAT_90001398 = DAT_90001398 + 1;
          DAT_900013ac = 0;
          goto LAB_8000d442;
        }
      }
      else if (DAT_900013ac == 1) goto LAB_8000d442;
      DAT_900013ac = DAT_900013ac + 1;
    }
LAB_8000d442:
    if ((param_1 == 2) && (DAT_90001398 != 0)) {
      DAT_90001398 = DAT_90001398 + -1;
    }
    if ((param_1 == 3) && (DAT_90001398 < param_2)) {
      DAT_90001398 = DAT_90001398 + 1;
    }
    if (DAT_900013ac == 1) {
      DAT_900013b0 = 4;
      return;
    }
    DAT_900013b0 = 0;
    return;
  }
  if (param_1 == 0) {
    if (DAT_90001398 == 0) {
      if (DAT_900013b0 != 0) goto LAB_8000d35a;
    }
    else if (DAT_900013b0 == 0) {
      DAT_90001398 = DAT_90001398 + -1;
      DAT_900013b0 = 7;
    }
    else {
LAB_8000d35a:
      DAT_900013b0 = DAT_900013b0 + -1;
    }
  }
  if (param_1 == 1) {
    if (DAT_90001398 < param_2) {
      if (6 < DAT_900013b0) {
        DAT_90001398 = DAT_90001398 + 1;
        DAT_900013b0 = 0;
        goto LAB_8000d396;
      }
    }
    else if (DAT_900013b0 == 7) goto LAB_8000d396;
    DAT_900013b0 = DAT_900013b0 + 1;
  }
LAB_8000d396:
  if ((param_1 == 2) && (DAT_90001398 != 0)) {
    DAT_90001398 = DAT_90001398 + -1;
  }
  if ((param_1 == 3) && (DAT_90001398 < param_2)) {
    DAT_90001398 = DAT_90001398 + 1;
  }
  DAT_900013ac = (uint)(3 < DAT_900013b0);
  return;
}


// ==== FUN_8000d48e @ 8000d48e

void FUN_8000d48e(int param_1,int param_2)

{
  uint uVar1;
  int iVar2;
  
  uVar1 = 7;
  iVar2 = 0;
  do {
    *(byte *)(param_2 + iVar2) = (byte)(param_1 >> (uVar1 & 0x3f)) & 1 | 0x30;
    *(undefined1 *)(param_2 + 8) = 0;
    uVar1 = uVar1 - 1;
    iVar2 = iVar2 + 1;
  } while (-1 < (int)uVar1);
  return;
}


// ==== FUN_8000d4c4 @ 8000d4c4

int FUN_8000d4c4(int param_1)

{
  uint uVar1;
  byte *pbVar2;
  uint uVar3;
  int iVar4;
  
  uVar3 = 7;
  iVar4 = 0;
  do {
    pbVar2 = (byte *)(param_1 + iVar4);
    uVar1 = uVar3 & 0x3f;
    uVar3 = uVar3 - 1;
    iVar4 = iVar4 + 1;
  } while (-1 < (int)uVar3);
  return (*pbVar2 & 0xffffff01) << uVar1;
}


// ==== FUN_8000d4fc @ 8000d4fc

void FUN_8000d4fc(uint param_1,byte *param_2)

{
  uint uVar1;
  byte bVar2;
  byte bVar3;
  
  bVar2 = (byte)(param_1 & 0xf);
  if ((param_1 & 0xf) < 10) {
    bVar3 = 0x30;
  }
  else {
    bVar2 = bVar2 - 9;
    bVar3 = 0x40;
  }
  param_2[1] = bVar3 | bVar2;
  uVar1 = (int)param_1 >> 4 & 0xf;
  bVar2 = (byte)uVar1;
  if (uVar1 < 10) {
    bVar3 = 0x30;
  }
  else {
    bVar2 = bVar2 - 9;
    bVar3 = 0x40;
  }
  *param_2 = bVar3 | bVar2;
  param_2[2] = 0;
  return;
}


// ==== FUN_8000d546 @ 8000d546

void FUN_8000d546(char *param_1)

{
  char cVar1;
  
  cVar1 = *param_1;
  while (cVar1 != '\0') {
    switch(*param_1) {
    case '1':
      break;
    case '2':
      break;
    case '3':
      break;
    case '4':
      break;
    case '5':
      break;
    case '6':
      break;
    case '7':
      break;
    case '8':
      break;
    case '9':
      break;
    default:
      break;
    case 'A':
      break;
    case 'B':
      break;
    case 'C':
      break;
    case 'D':
      break;
    case 'E':
      break;
    case 'F':
    }
    param_1 = param_1 + 1;
    cVar1 = *param_1;
  }
  return;
}


// ==== FUN_8000d620 @ 8000d620

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_8000d620(void)

{
  int iVar1;
  uint uVar2;
  uint unaff_D7;
  undefined4 uVar3;
  
  iVar1 = 5;
  do {
    FUN_80008700(iVar1);
    iVar1 = iVar1 + 1;
  } while (iVar1 < 0x14);
  FUN_8000c024();
  _DAT_9000143e = 1;
  FUN_8000d826();
  iVar1 = 0;
  do {
    FUN_8000c3b0(iVar1);
    iVar1 = iVar1 + 1;
  } while (iVar1 < 4);
LAB_8000d664:
  FUN_8000c352();
  while (FUN_80009a4a(), (short)unaff_D7 == -1) {
    FUN_8000c126();
  }
  uVar2 = unaff_D7 & 0xffff;
  if (uVar2 == 0x11b) {
    iVar1 = 3;
  }
  else {
    if (0x11b < uVar2) {
      if (uVar2 == 0x126) {
        uVar3 = 3;
      }
      else if (uVar2 < 0x127) {
        if (uVar2 == 0x124) {
          uVar3 = 2;
        }
        else {
          if (uVar2 < 0x125) {
            if (uVar2 == 0x11f) {
              FUN_8000d922();
              FUN_8000db8a(DAT_9000db38,DAT_9000db44,DAT_90012998,DAT_90010110,DAT_9001195c,
                           DAT_90011950);
              if (unaff_D7 == 0) {
                _DAT_9000143e = 1;
                FUN_80007fa2(0);
                FUN_8000d9d6();
              }
              else {
                FUN_80007fa2(7);
              }
              iVar1 = DAT_900013f8;
              goto LAB_8000d812;
            }
            goto LAB_8000d664;
          }
          if (uVar2 != 0x125) goto LAB_8000d664;
          uVar3 = 0;
        }
      }
      else {
        if (uVar2 != 0x127) {
          if ((uVar2 < 0x13a) && (0x12f < uVar2)) goto LAB_8000d716;
          goto LAB_8000d664;
        }
        uVar3 = 1;
      }
      FUN_8000da5c(uVar3);
      goto LAB_8000d664;
    }
    if (uVar2 < 0x3a) {
      if (uVar2 < 0x30) {
        if (uVar2 == 0xd) {
          return;
        }
      }
      else {
LAB_8000d716:
        (&DAT_9000c264)[DAT_9000140c + DAT_900013f8 * 7] = (char)unaff_D7;
        FUN_8000c3b0(DAT_900013f8);
        if (DAT_9000140c < *(int *)(&DAT_900013fc + DAT_900013f8 * 4)) {
          FUN_8000da5c(1);
        }
        FUN_80007fa2(0);
      }
      goto LAB_8000d664;
    }
    if (uVar2 == 0x119) {
      iVar1 = 1;
    }
    else {
      if (0x119 < uVar2) {
        if (uVar2 == 0x11a) {
          iVar1 = 2;
          goto LAB_8000d812;
        }
        goto LAB_8000d664;
      }
      if (uVar2 != 0x118) goto LAB_8000d664;
      iVar1 = 0;
    }
  }
LAB_8000d812:
  FUN_8000da3e(iVar1,0);
  goto LAB_8000d664;
}


// ==== FUN_8000d826 @ 8000d826

void FUN_8000d826(void)

{
  FUN_8001629c(&DAT_90006ccc);
  FUN_8000dc2e(DAT_90006ccc,&DAT_9000c266,2);
  if (DAT_90006ccc < 0x50) {
    DAT_9000c264 = 0x32;
    DAT_9000c265 = 0x30;
  }
  else {
    DAT_9000c264 = 0x31;
    DAT_9000c265 = 0x39;
  }
  FUN_8000dc2e(DAT_90006ccd,&DAT_9000c26b,2);
  FUN_8000dc2e(DAT_90006cce,&DAT_9000c272,2);
  FUN_8000dc2e(DAT_90006cd0,&DAT_9000c280,2);
  FUN_8000dc2e(DAT_90006cd1,&DAT_9000c287,2);
  FUN_8000dc2e(DAT_90006cd2,&DAT_9000c28e,2);
  DAT_9000c279 = DAT_9000c280;
  DAT_9000c27a = DAT_9000c281;
  DAT_9000c27b = DAT_9000c287;
  DAT_9000c27c = DAT_9000c288;
  DAT_9000c27d = DAT_9000c28e;
  DAT_9000c27e = DAT_9000c28f;
  DAT_9000c27f = 0;
  return;
}


// ==== FUN_8000d922 @ 8000d922

void FUN_8000d922(void)

{
  undefined4 unaff_D7;
  
  FUN_8000d546(&DAT_9000c264,1);
  DAT_9000db38 = unaff_D7;
  FUN_8000d546(&DAT_9000c26b,1);
  DAT_9000db44 = unaff_D7;
  FUN_8000d546(&DAT_9000c272,1);
  DAT_9000c280 = DAT_9000c279;
  DAT_9000c281 = DAT_9000c27a;
  DAT_9000c282 = 0;
  DAT_9000c287 = DAT_9000c27b;
  DAT_9000c288 = DAT_9000c27c;
  DAT_9000c289 = 0;
  DAT_9000c28e = DAT_9000c27d;
  DAT_9000c28f = DAT_9000c27e;
  DAT_9000c290 = 0;
  DAT_90012998 = unaff_D7;
  FUN_8000d546(&DAT_9000c280,1);
  DAT_90010110 = unaff_D7;
  FUN_8000d546(&DAT_9000c287,1);
  DAT_9001195c = unaff_D7;
  FUN_8000d546(&DAT_9000c28e,1);
  DAT_90011950 = unaff_D7;
  return;
}


// ==== FUN_8000d9d6 @ 8000d9d6

void FUN_8000d9d6(void)

{
  if (DAT_9000db38 < 2000) {
    DAT_90006ccc = (char)DAT_9000db38 + -0x6c;
  }
  else {
    DAT_90006ccc = (char)DAT_9000db38 + '0';
  }
  DAT_90006ccd = (undefined1)DAT_9000db44;
  DAT_90006cce = (undefined1)DAT_90012998;
  DAT_90006cd0 = (undefined1)DAT_90010110;
  DAT_90006cd1 = (undefined1)DAT_9001195c;
  DAT_90006cd2 = (undefined1)DAT_90011950;
  FUN_800162bc(&DAT_90006ccc);
  return;
}


// ==== FUN_8000da3e @ 8000da3e

void FUN_8000da3e(undefined4 param_1,undefined4 param_2)

{
  FUN_8000c2f6();
  DAT_900013f8 = param_1;
  DAT_9000140c = param_2;
  return;
}


// ==== FUN_8000da5c @ 8000da5c

void FUN_8000da5c(int param_1)

{
  FUN_8000c2f6();
  if (param_1 == 0) {
    if (DAT_900013f8 == 0) {
      if (0 < DAT_9000140c) {
LAB_8000daa2:
        DAT_9000140c = DAT_9000140c + -1;
      }
    }
    else if ((DAT_900013f8 < 4) && (0 < DAT_900013f8)) {
      if (DAT_9000140c != 0) goto LAB_8000daa2;
      DAT_900013f8 = DAT_900013f8 + -1;
      DAT_9000140c = 0;
    }
  }
  if ((param_1 == 1) && (-1 < DAT_900013f8)) {
    if (DAT_900013f8 < 3) {
      if (*(int *)(&DAT_900013fc + DAT_900013f8 * 4) <= DAT_9000140c) {
        DAT_900013f8 = DAT_900013f8 + 1;
        DAT_9000140c = 0;
        goto LAB_8000db08;
      }
    }
    else if ((DAT_900013f8 != 3) || (iRam90001408 <= DAT_9000140c)) goto LAB_8000db08;
    DAT_9000140c = DAT_9000140c + 1;
  }
LAB_8000db08:
  if ((((param_1 == 2) && (DAT_900013f8 < 4)) && (0 < DAT_900013f8)) &&
     (DAT_900013f8 = DAT_900013f8 + -1, *(int *)(&DAT_900013fc + DAT_900013f8 * 4) < DAT_9000140c))
  {
    DAT_9000140c = *(int *)(&DAT_900013fc + DAT_900013f8 * 4);
  }
  if (((param_1 == 3) && (DAT_900013f8 < 3)) &&
     ((-1 < DAT_900013f8 &&
      (DAT_900013f8 = DAT_900013f8 + 1, *(int *)(&DAT_900013fc + DAT_900013f8 * 4) < DAT_9000140c)))
     ) {
    DAT_9000140c = *(int *)(&DAT_900013fc + DAT_900013f8 * 4);
  }
  return;
}


// ==== FUN_8000db8a @ 8000db8a

void FUN_8000db8a(void)

{
  return;
}


// ==== FUN_8000dc2e @ 8000dc2e

void FUN_8000dc2e(int param_1,int param_2,int param_3)

{
  int iVar1;
  
  *(undefined1 *)(param_2 + param_3) = 0;
  while (param_3 = param_3 + -1, -1 < param_3) {
    iVar1 = param_1 % 10;
    param_1 = param_1 / 10;
    *(byte *)(param_2 + param_3) = (byte)iVar1 | 0x30;
  }
  return;
}


// ==== FUN_8000dc5a @ 8000dc5a

void FUN_8000dc5a(void)

{
  return;
}


// ==== FUN_8000dc62 @ 8000dc62

void FUN_8000dc62(undefined2 param_1)

{
  switch(param_1) {
  case 0x118:
    break;
  case 0x119:
    break;
  case 0x11a:
    break;
  case 0x11b:
    break;
  case 0x11c:
    break;
  case 0x11d:
  }
  return;
}


// ==== FUN_8000dcca @ 8000dcca

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_8000dcca(void)

{
  FUN_80007b28(0);
  FUN_80008700(3);
  FUN_80008700(0x15);
  FUN_80007eb0(0);
  FUN_80007d86(0);
  FUN_80007bd2();
  FUN_80007c28(&DAT_8000dcac,0);
  FUN_80007c28(&DAT_8000dcad,1);
  FUN_80007c28("INSTALL",2);
  FUN_80007c28("SETUP",3);
  FUN_80007c28("DIAGNOSIS",4);
  FUN_800081e0(0);
  FUN_8000826a(1);
  _DAT_900002dc = 1;
  return;
}


// ==== FUN_8000dd8e @ 8000dd8e

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_8000dd8e(void)

{
  FUN_80007b28(1);
  FUN_80008700(3);
  FUN_80008700(0x15);
  FUN_80007bd2();
  FUN_80007c28(&DAT_8000dcac,0);
  FUN_80007c28("FILES",1);
  FUN_80007c28("HNDL FILE",2);
  FUN_80007c28("HNDL VOL",3);
  FUN_80007c28("HNDL DIR",4);
  FUN_80007c28(&DAT_8000dd88,8);
  FUN_800081e0(0);
  FUN_8000826a(1);
  FUN_8000efae();
  _DAT_900002dc = 1;
  return;
}


// ==== FUN_8000df3e @ 8000df3e

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_8000df3e(int param_1)

{
  FUN_80008700(0x14);
  FUN_80007d86(0);
  FUN_80007eb0(0);
  FUN_800081e0(2);
  FUN_8000826a(1);
  FUN_80007c28(&DAT_8000dcac,0);
  FUN_80007c28("PRINT F",1);
  FUN_80007c28("COPY FILE",2);
  FUN_80007c28("REN FILE",3);
  FUN_80007c28("DEL FILE",4);
  FUN_80007c28("RESUME F",5);
  FUN_80007c28(&DAT_8000dd88,8);
  if (param_1 == 1) {
    FUN_80008700(3);
    FUN_80008700(0x15);
    FUN_8000f022();
    FUN_8000efae();
  }
  _DAT_900002dc = 1;
  return;
}


// ==== FUN_8000e02a @ 8000e02a

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_8000e02a(void)

{
  FUN_80007d86(0);
  FUN_80007eb0(0);
  FUN_800081e0(8);
  FUN_8000826a(1);
  FUN_80007c28(&DAT_8000dcac,0);
  FUN_80007c28("COPY VOL",1);
  FUN_80007c28("REN VOL",2);
  FUN_80007c28("INIT VOL",3);
  FUN_80007c28(&DAT_8000e024,4);
  FUN_80007c28(&DAT_8000dd88,8);
  FUN_80008700(3);
  FUN_80008700(0x15);
  FUN_80008700(0x14);
  FUN_8000f022();
  FUN_8000efae();
  _DAT_900002dc = 1;
  return;
}


// ==== FUN_8000e120 @ 8000e120

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_8000e120(int param_1)

{
  FUN_80007d86(0);
  FUN_80007eb0(0);
  FUN_80008700(0x14);
  FUN_8000f46a(1,0x18,0x18,7,0,"                                          ");
  FUN_800081e0(0x13);
  FUN_8000826a(1);
  FUN_80007c28(&DAT_8000dcac,0);
  FUN_80007c28("CHG DIR",1);
  FUN_80007c28("MAKE DIR",2);
  FUN_80007c28("DEL DIR",3);
  FUN_80007c28(&DAT_8000dd88,8);
  if (param_1 == 1) {
    FUN_80008700(3);
    FUN_80008700(0x15);
    FUN_8000f022();
    FUN_8000efae();
  }
  _DAT_900002dc = 1;
  return;
}


// ==== FUN_8000e200 @ 8000e200

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_8000e200(undefined4 param_1,int param_2)

{
  char **ppcVar1;
  undefined **ppuVar2;
  undefined **ppuVar3;
  char *pcStack_24;
  undefined4 local_20;
  undefined *local_1c;
  undefined *local_18;
  undefined *local_14;
  undefined *local_10;
  undefined4 uStack_c;
  
  if (param_2 == 1) {
    uStack_c = 3;
    local_10 = (undefined *)0x8000e236;
    FUN_80008700();
    local_10 = (undefined *)0x15;
    local_14 = (undefined *)0x8000e23c;
    FUN_80008700();
    local_14 = (undefined *)0x19;
    local_18 = (undefined *)0x8000e246;
    FUN_8000826a();
    local_18 = (undefined *)0x0;
    local_1c = (undefined *)0x8000e24e;
    FUN_80007eb0();
    local_1c = (undefined *)0x0;
    local_20 = 0x8000e256;
    FUN_80007d86();
    local_20 = 0;
    pcStack_24 = "";
    FUN_80007c28();
    FUN_80007c28(&DAT_8000dd88,8);
    ppcVar1 = (char **)((int)register0x0000003c + -8);
LAB_8000e2d2:
    *(undefined4 *)((int)ppcVar1 + -4) = 0x8000e2d8;
    FUN_8000f022();
    *(undefined4 *)((int)ppcVar1 + -4) = 0x8000e2de;
    FUN_8000efae();
    _DAT_900002dc = 1;
    return;
  }
  if (param_2 < 2) {
    if (param_2 != 0) {
      _DAT_900002dc = 1;
      return;
    }
    switch(param_1) {
    case 0:
      uStack_c = 3;
      local_10 = (undefined *)0x8000e29c;
      FUN_80008700();
      local_10 = (undefined *)0x15;
      local_14 = (undefined *)0x8000e2a2;
      FUN_80008700();
      local_14 = (undefined *)0x14;
      local_18 = (undefined *)0x8000e2a8;
      FUN_80008700();
      local_18 = (undefined *)0x0;
      local_1c = (undefined *)0x8000e2b0;
      FUN_80007d86();
      local_1c = (undefined *)0x0;
      local_20 = 0x8000e2b8;
      FUN_80007eb0();
      local_20 = 3;
      pcStack_24 = "Hx";
      FUN_800081e0();
      pcStack_24 = (char *)0x2;
      FUN_8000826a();
      FUN_8000ef2e();
      ppcVar1 = &pcStack_24;
      goto LAB_8000e2d2;
    case 1:
      uStack_c = 4;
      local_10 = (undefined *)0x8000e2ec;
      FUN_8000826a();
      ppuVar2 = (undefined **)&uStack_c;
      goto LAB_8000e36a;
    case 2:
    case 3:
      uStack_c = 3;
      local_10 = (undefined *)0x8000e2f8;
      FUN_8000826a();
      local_10 = (undefined *)0x0;
      local_14 = &DAT_8000dcac;
      local_18 = (undefined *)0x8000e308;
      FUN_80007c28();
      local_18 = (undefined *)0x1;
      local_1c = &DAT_8000de32;
      local_20 = 0x8000e314;
      FUN_80007c28();
      local_20 = 2;
      pcStack_24 = "PRINTER";
      FUN_80007c28();
      FUN_80007c28(&DAT_8000e1f4,3);
      uStack_c = 4;
      local_10 = &DAT_8000e1f8;
      local_14 = (undefined *)0x8000e33c;
      FUN_80007c28();
      local_14 = (undefined *)0x5;
      ppuVar3 = &local_18;
      local_18 = &DAT_8000e1fc;
      break;
    default:
      goto switchD_8000e284_default;
    }
  }
  else {
    if (param_2 != 2) {
      _DAT_900002dc = 1;
      return;
    }
    uStack_c = 3;
    local_10 = (undefined *)0x8000e354;
    FUN_80008700();
    local_10 = (undefined *)0x15;
    local_14 = (undefined *)0x8000e35a;
    FUN_80008700();
    local_14 = (undefined *)0x0;
    local_18 = (undefined *)0x8000e362;
    FUN_80007eb0();
    local_18 = (undefined *)0x0;
    local_1c = (undefined *)0x8000e36a;
    FUN_80007d86();
    ppuVar2 = &local_18;
LAB_8000e36a:
    *(undefined4 *)((int)ppuVar2 + -4) = 0;
    ppuVar3 = (undefined **)((int)ppuVar2 + -8);
    *(undefined **)((int)ppuVar2 + -8) = &DAT_8000dcac;
  }
  *(undefined4 *)((int)ppuVar3 + -4) = 0x8000e37a;
  FUN_80007c28();
  *(undefined4 *)((int)ppuVar3 + -4) = 8;
  *(undefined **)((int)ppuVar3 + -8) = &DAT_8000dd88;
  *(undefined4 *)((int)ppuVar3 + -0xc) = 0x8000e386;
  FUN_80007c28();
switchD_8000e284_default:
  _DAT_900002dc = 1;
  return;
}


// ==== FUN_8000e396 @ 8000e396

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_8000e396(int param_1)

{
  undefined4 uVar1;
  
  switch(param_1) {
  case 0:
    FUN_80008700(3);
    FUN_80008700(0x15);
    FUN_80008700(0x14);
    FUN_80007d86(0);
    FUN_80007eb0(0);
    FUN_800081e0(4);
    FUN_8000826a(6);
    FUN_8000ef2e();
    FUN_8000f022();
    FUN_8000efae();
    break;
  case 1:
  case 3:
    if (param_1 == 1) {
      uVar1 = 4;
    }
    else {
      uVar1 = 10;
    }
    FUN_8000826a(uVar1);
    FUN_80007c28(&DAT_8000dcac,0);
    FUN_80007c28(&DAT_8000dd88,8);
    break;
  case 2:
    FUN_8000826a(7);
    FUN_8000ef2e();
    break;
  case 4:
    _DAT_900002dc = 1;
    FUN_8000826a(0x13);
    _DAT_900002dc = 0;
    FUN_80007c28(&DAT_8000dd88,8);
    break;
  case 5:
    FUN_80007d86(0);
    FUN_8000826a(0);
  }
  _DAT_900002dc = 1;
  return;
}


// ==== FUN_8000e4a0 @ 8000e4a0

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_8000e4a0(int param_1,int param_2)

{
  undefined4 uVar1;
  
  switch(param_1) {
  case 0:
    FUN_8000f022();
    FUN_80007d86(0);
    FUN_80007eb0(0);
    FUN_80008700(3);
    FUN_80008700(0x15);
    FUN_80008700(0x14);
    FUN_800081e0(5);
    FUN_8000826a(2);
    FUN_8000ef2e();
    FUN_8000efae();
    break;
  case 1:
  case 2:
    if (param_1 == 1) {
      uVar1 = 4;
    }
    else {
      uVar1 = 0xb;
    }
    FUN_8000826a(uVar1);
    FUN_80007c28(&DAT_8000dcac,0);
    FUN_80007c28(&DAT_8000dd88,8);
    break;
  case 3:
    if (param_2 < 0) {
      FUN_80007fa2(0);
    }
    _DAT_900002dc = 1;
    FUN_8000826a(0x15);
    _DAT_900002dc = 0;
    FUN_80007c28(&DAT_8000dd88,8);
  }
  _DAT_900002dc = 1;
  return;
}


// ==== FUN_8000e594 @ 8000e594

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_8000e594(int param_1,int param_2)

{
  undefined **ppuVar1;
  undefined *puStack_1c;
  undefined4 uStack_18;
  undefined *puStack_14;
  undefined *local_10;
  undefined4 local_c;
  
  if (param_1 == 1) {
    local_c = 4;
    local_10 = (undefined *)0x8000e612;
    FUN_8000826a();
    local_10 = (undefined *)0x0;
    puStack_14 = &DAT_8000dcac;
    uStack_18 = 0x8000e622;
    FUN_80007c28();
    uStack_18 = 1;
    ppuVar1 = &puStack_1c;
    puStack_1c = &DAT_8000e590;
  }
  else {
    if (param_1 < 2) {
      if (param_1 == 0) {
        local_c = 0x8000e5be;
        FUN_8000f022();
        local_c = 0;
        local_10 = (undefined *)0x8000e5c6;
        FUN_80007d86();
        local_10 = (undefined *)0x0;
        puStack_14 = (undefined *)0x8000e5ce;
        FUN_80007eb0();
        puStack_14 = (undefined *)0x3;
        uStack_18 = 0x8000e5da;
        FUN_80008700();
        uStack_18 = 0x15;
        puStack_1c = (undefined *)0x8000e5e0;
        FUN_80008700();
        puStack_1c = (undefined *)0x14;
        FUN_80008700();
        FUN_800081e0(6);
        FUN_8000826a(2);
        FUN_8000ef2e();
        FUN_8000efae();
        _DAT_900002dc = 1;
        return;
      }
      _DAT_900002dc = 1;
      return;
    }
    if (param_1 != 2) {
      _DAT_900002dc = 1;
      return;
    }
    local_c = 0x18;
    local_10 = (undefined *)0x8000e638;
    FUN_80008700();
    _DAT_900002dc = 1;
    if (param_2 == 1) {
      local_c = 0x1c;
    }
    else {
      local_c = 0x16;
    }
    local_10 = (undefined *)0x8000e658;
    FUN_8000826a();
    _DAT_900002dc = 0;
    local_c = 0;
    ppuVar1 = &local_10;
    local_10 = &DAT_8000dcac;
  }
  *(undefined4 *)((int)ppuVar1 + -4) = 0x8000e670;
  FUN_80007c28();
  *(undefined4 *)((int)ppuVar1 + -4) = 8;
  *(undefined **)((int)ppuVar1 + -8) = &DAT_8000dd88;
  *(undefined4 *)((int)ppuVar1 + -0xc) = 0x8000e67c;
  FUN_80007c28();
  _DAT_900002dc = 1;
  return;
}


// ==== FUN_8000e68c @ 8000e68c

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_8000e68c(int param_1)

{
  if (param_1 == 1) {
    FUN_8000826a(4);
    FUN_80007c28(&DAT_8000dcac,0);
    FUN_80007c28(&DAT_8000dd88,8);
  }
  else if (param_1 < 2) {
    if (param_1 == 0) {
      FUN_8000f022();
      FUN_80007d86(0);
      FUN_80007eb0(0);
      FUN_80008700(3);
      FUN_80008700(0x15);
      FUN_80008700(0x14);
      FUN_800081e0(7);
      FUN_8000826a(2);
      FUN_8000ef2e();
      FUN_8000efae();
    }
  }
  else if (param_1 == 2) {
    _DAT_900002dc = 1;
    FUN_8000826a(0x17);
    _DAT_900002dc = 0;
    FUN_80007c28(&DAT_8000dd88,8);
  }
  _DAT_900002dc = 1;
  return;
}


// ==== FUN_8000e77c @ 8000e77c

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_8000e77c(int param_1,undefined4 *param_2,int param_3)

{
  char **ppcVar1;
  char *pcStack_20;
  undefined *puStack_1c;
  char *pcStack_18;
  undefined *puStack_14;
  char *local_10;
  undefined4 local_c;
  
  if (param_1 == 1) {
    if (param_3 == 1) {
      _DAT_900002dc = 1;
      return;
    }
    local_c = 7;
    local_10 = (char *)0x8000e81c;
    FUN_8000826a();
    local_10 = (char *)0x8000e822;
    FUN_80007bd2();
    local_10 = (char *)0x0;
    puStack_14 = &DAT_8000dcac;
    pcStack_18 = "Hx";
    FUN_80007c28();
    pcStack_18 = (char *)0x8;
    puStack_1c = &DAT_8000dd88;
    pcStack_20 = (char *)0x8000e83e;
    FUN_80007c28();
    switch(*param_2) {
    case 0:
      local_c = 2;
      local_10 = "B(MFD)";
      puStack_14 = (undefined *)0x8000e87e;
      FUN_80007c28();
      puStack_14 = (undefined *)0x4;
      pcStack_18 = "I(MFD)";
      puStack_1c = (undefined *)0x8000e88a;
      FUN_80007c28();
      puStack_1c = (undefined *)0x5;
      ppcVar1 = &pcStack_20;
      pcStack_20 = "J(MFD)";
      break;
    case 1:
      local_c = 1;
      local_10 = "A(MFD)";
      puStack_14 = (undefined *)0x8000e8aa;
      FUN_80007c28();
      puStack_14 = (undefined *)0x4;
      pcStack_18 = "I(MFD)";
      puStack_1c = (undefined *)0x8000e8b6;
      FUN_80007c28();
      puStack_1c = (undefined *)0x5;
      ppcVar1 = &pcStack_20;
      pcStack_20 = "J(MFD)";
      break;
    default:
      goto switchD_8000e854_caseD_2;
    case 8:
      local_c = 1;
      local_10 = "A(MFD)";
      puStack_14 = (undefined *)0x8000e8d6;
      FUN_80007c28();
      puStack_14 = (undefined *)0x2;
      pcStack_18 = "B(MFD)";
      puStack_1c = (undefined *)0x8000e8e2;
      FUN_80007c28();
      puStack_1c = (undefined *)0x5;
      ppcVar1 = &pcStack_20;
      pcStack_20 = "J(MFD)";
      break;
    case 9:
      local_c = 1;
      local_10 = "A(MFD)";
      puStack_14 = (undefined *)0x8000e900;
      FUN_80007c28();
      puStack_14 = (undefined *)0x2;
      pcStack_18 = "B(MFD)";
      puStack_1c = (undefined *)0x8000e90c;
      FUN_80007c28();
      puStack_1c = (undefined *)0x4;
      ppcVar1 = &pcStack_20;
      pcStack_20 = "I(MFD)";
    }
  }
  else {
    if (param_1 < 2) {
      if (param_1 == 0) {
        local_c = 0x8000e7a8;
        FUN_8000f022();
        local_c = 0;
        local_10 = (char *)0x8000e7b0;
        FUN_80007d86();
        local_10 = (char *)0x0;
        puStack_14 = (undefined *)0x8000e7b8;
        FUN_80007eb0();
        puStack_14 = (undefined *)0x9;
        pcStack_18 = "Hx";
        FUN_800081e0();
        pcStack_18 = (char *)0x3;
        puStack_1c = (undefined *)0x8000e7ce;
        FUN_80008700();
        puStack_1c = (undefined *)0x15;
        pcStack_20 = "Hx";
        FUN_80008700();
        pcStack_20 = (char *)0x14;
        FUN_80008700();
        FUN_8000826a(6);
        FUN_8000ef2e();
        FUN_80007c28(&DAT_8000dcac,3);
        local_c = 0x8000e804;
        FUN_8000efae();
        _DAT_900002dc = 1;
        return;
      }
      _DAT_900002dc = 1;
      return;
    }
    if (param_1 != 2) {
      _DAT_900002dc = 1;
      return;
    }
    _DAT_900002dc = 1;
    local_c = 0x12;
    local_10 = (char *)0x8000e92a;
    FUN_8000826a();
    _DAT_900002dc = 0;
    local_10 = (char *)0x0;
    puStack_14 = &DAT_8000dcac;
    pcStack_18 = "Hx";
    FUN_80007c28();
    pcStack_18 = (char *)0x8;
    ppcVar1 = &puStack_1c;
    puStack_1c = &DAT_8000dd88;
  }
  *(undefined4 *)((int)ppcVar1 + -4) = 0x8000e94c;
  FUN_80007c28();
switchD_8000e854_caseD_2:
  _DAT_900002dc = 1;
  return;
}


// ==== FUN_8000e95c @ 8000e95c

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_8000e95c(int param_1)

{
  if (param_1 == 1) {
    FUN_8000826a(9);
    FUN_80007c28(&DAT_8000dcac,0);
    FUN_80007c28(&DAT_8000dd88,8);
  }
  else if (param_1 < 2) {
    if (param_1 == 0) {
      FUN_8000f022();
      FUN_80007d86(0);
      FUN_80007eb0(0);
      FUN_80008700(3);
      FUN_80008700(0x15);
      FUN_80008700(0x14);
      FUN_800081e0(10);
      FUN_8000826a(2);
      FUN_8000ef2e();
      FUN_8000efae();
    }
  }
  else if (param_1 == 2) {
    _DAT_900002dc = 1;
    FUN_8000826a(0x14);
    _DAT_900002dc = 0;
    FUN_80007c28(&DAT_8000dd88,8);
  }
  _DAT_900002dc = 1;
  return;
}


// ==== FUN_8000ea38 @ 8000ea38

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_8000ea38(undefined4 param_1)

{
  undefined **ppuVar1;
  undefined *puStack_1c;
  undefined4 uStack_18;
  undefined *puStack_14;
  undefined4 local_10;
  undefined4 uStack_c;
  
  switch(param_1) {
  case 0:
    uStack_c = 3;
    local_10 = 0x8000ea6e;
    FUN_80008700();
    local_10 = 0x15;
    puStack_14 = (undefined *)0x8000ea74;
    FUN_80008700();
    puStack_14 = (undefined *)0xb;
    uStack_18 = 0x8000ea7e;
    FUN_800081e0();
    uStack_18 = 2;
    puStack_1c = (undefined *)0x8000ea88;
    FUN_8000826a();
    puStack_1c = (undefined *)0x8000ea8e;
    FUN_8000ef2e();
    break;
  case 1:
    uStack_c = 9;
    local_10 = 0x8000ea9c;
    FUN_8000826a();
    goto LAB_8000eb0e;
  case 2:
    _DAT_900002dc = 1;
    uStack_c = 0xd;
    local_10 = 0x8000eab0;
    FUN_8000826a();
    _DAT_900002dc = 0;
    local_10 = 8;
    puStack_14 = &DAT_8000dd88;
    uStack_18 = 0x8000eac6;
    FUN_80007c28();
    break;
  case 3:
    if (DAT_9000c86c == 6) {
      _DAT_900002dc = 1;
      return;
    }
    uStack_c = 8;
    local_10 = 0x8000ead8;
    FUN_8000826a();
    local_10 = 1;
    puStack_14 = &DAT_8000ea30;
    uStack_18 = 0x8000eaea;
    FUN_80007c28();
    uStack_18 = 2;
    ppuVar1 = &puStack_1c;
    puStack_1c = &DAT_8000ea34;
    goto LAB_8000eb1c;
  case 4:
    _DAT_900002dc = 1;
    uStack_c = 0x10;
    local_10 = 0x8000eb08;
    FUN_8000826a();
    _DAT_900002dc = 0;
LAB_8000eb0e:
    local_10 = 0;
    ppuVar1 = &puStack_14;
    puStack_14 = &DAT_8000dcac;
LAB_8000eb1c:
    *(undefined4 *)((int)ppuVar1 + -4) = 0x8000eb1e;
    FUN_80007c28();
    *(undefined4 *)((int)ppuVar1 + -4) = 8;
    *(undefined **)((int)ppuVar1 + -8) = &DAT_8000dd88;
    *(undefined4 *)((int)ppuVar1 + -0xc) = 0x8000eb2a;
    FUN_80007c28();
  }
  _DAT_900002dc = 1;
  return;
}


// ==== FUN_8000eb3a @ 8000eb3a

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_8000eb3a(int param_1)

{
  if (param_1 == 0) {
    FUN_8000f022();
    FUN_80007d86(0);
    FUN_80007eb0(0);
    FUN_80008700(3);
    FUN_80008700(0x15);
    FUN_80008700(0x14);
    FUN_800081e0(0xc);
    FUN_8000826a(2);
    FUN_8000ef2e();
    FUN_8000efae();
  }
  else if (param_1 == 1) {
    _DAT_900002dc = 1;
    FUN_8000826a(0x11);
    _DAT_900002dc = 0;
    FUN_80007c28(&DAT_8000dcac,0);
    FUN_80007c28(&DAT_8000dd88,8);
  }
  _DAT_900002dc = 1;
  return;
}


// ==== FUN_8000ebe4 @ 8000ebe4

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_8000ebe4(int param_1)

{
  if (param_1 == 0) {
    FUN_8000826a(0x19);
    FUN_8000f022();
    FUN_80007d86(0);
    FUN_80007eb0(0);
    FUN_80008700(3);
    FUN_80008700(0x15);
    FUN_80008700(0x14);
    FUN_80008700(0x18);
    FUN_800081e0(0x14);
    FUN_80007c28(&DAT_8000dcac,0);
    FUN_8000efae();
  }
  else if (param_1 == 1) {
    FUN_80007eb0(0);
    FUN_80007d86(0);
    if ((DAT_900100f4 != 0) && (FUN_80007eb0(1), 0x10 < DAT_900100f4)) {
      FUN_80007d86(1);
    }
    FUN_8000826a(0x1a);
    FUN_80007c28(&DAT_8000dcac,0);
    FUN_80007c28(&DAT_8000dd88,8);
  }
  _DAT_900002dc = 1;
  return;
}


// ==== FUN_8000ecce @ 8000ecce

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_8000ecce(int param_1)

{
  if (param_1 == 1) {
    FUN_80007eb0(0);
    FUN_80007d86(0);
    if ((DAT_900100f4 != 0) && (FUN_80007eb0(1), 0x10 < DAT_900100f4)) {
      FUN_80007d86(1);
    }
    FUN_8000826a(0x1a);
    FUN_80007c28(&DAT_8000dcac,0);
    FUN_80007c28(&DAT_8000dd88,8);
  }
  else if (param_1 < 2) {
    if (param_1 == 0) {
      FUN_8000826a(0x19);
      FUN_8000f022();
      FUN_80007d86(0);
      FUN_80007eb0(0);
      FUN_80008700(3);
      FUN_80008700(0x15);
      FUN_80008700(0x14);
      FUN_80008700(0x18);
      FUN_800081e0(0x15);
      FUN_80007c28(&DAT_8000dcac,0);
      FUN_8000efae();
    }
  }
  else if (param_1 == 2) {
    FUN_80008700(0x18);
    _DAT_900002dc = 1;
    FUN_8000826a(0x1b);
    _DAT_900002dc = 0;
    FUN_80007c28(&DAT_8000dd88,8);
  }
  _DAT_900002dc = 1;
  return;
}


// ==== FUN_8000edfe @ 8000edfe

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_8000edfe(int param_1)

{
  if (param_1 == 1) {
    FUN_80007eb0(0);
    FUN_80007d86(0);
    if ((DAT_900100f4 != 0) && (FUN_80007eb0(1), 0x10 < DAT_900100f4)) {
      FUN_80007d86(1);
    }
    FUN_8000826a(0x1a);
    FUN_80007c28(&DAT_8000dcac,0);
    FUN_80007c28(&DAT_8000dd88,8);
  }
  else if (param_1 < 2) {
    if (param_1 == 0) {
      FUN_8000826a(0x19);
      FUN_8000f022();
      FUN_80007d86(0);
      FUN_80007eb0(0);
      FUN_80008700(3);
      FUN_80008700(0x15);
      FUN_80008700(0x14);
      FUN_80008700(0x18);
      FUN_800081e0(0x16);
      FUN_80007c28(&DAT_8000dcac,0);
      FUN_8000efae();
    }
  }
  else if (param_1 == 2) {
    FUN_80008700(0x18);
    _DAT_900002dc = 1;
    FUN_8000826a(0x1b);
    _DAT_900002dc = 0;
    FUN_80007c28(&DAT_8000dd88,8);
  }
  _DAT_900002dc = 1;
  return;
}


// ==== FUN_8000ef2e @ 8000ef2e

void FUN_8000ef2e(void)

{
  FUN_80007bd2();
  FUN_80007c28(0,0);
  FUN_80007c28(0x11,1);
  FUN_80007c28(0x12,2);
  FUN_80007c28(0x15,3);
  FUN_80007c28(0x13,4);
  FUN_80007c28(0x14,5);
  FUN_80007c28(1,8);
  return;
}


// ==== FUN_8000ef90 @ 8000ef90

void FUN_8000ef90(void)

{
  FUN_800101e4();
  return;
}


// ==== FUN_8000ef9e @ 8000ef9e

void FUN_8000ef9e(void)

{
  return;
}


// ==== FUN_8000efa6 @ 8000efa6

void FUN_8000efa6(void)

{
  return;
}


// ==== FUN_8000efae @ 8000efae

void FUN_8000efae(void)

{
  return;
}


// ==== FUN_8000efb6 @ 8000efb6

void FUN_8000efb6(void)

{
  return;
}


// ==== FUN_8000efbe @ 8000efbe

void FUN_8000efbe(undefined4 param_1,byte param_2,byte param_3)

{
  uint uVar1;
  uint uVar2;
  int unaff_D7;
  
  uVar1 = (uint)param_2;
  uVar2 = (uint)param_3;
  FUN_8000fc92(uVar1,(uVar1 - 1) + uVar2);
  if (unaff_D7 < 0) {
    DAT_90001acc = 0xffffffff;
  }
  else {
    DAT_90001ad4 = 0;
    DAT_90001ad8 = uVar2 - 1;
    DAT_90001acc = uVar1;
    DAT_90001ad0 = uVar2;
    FUN_8000f970(&DAT_90001adc,0x1130,0x20);
  }
  return;
}


// ==== FUN_8000f022 @ 8000f022

void FUN_8000f022(void)

{
  int iVar1;
  int iVar2;
  
  if (-1 < DAT_90001acc) {
    iVar1 = DAT_90001ad0;
    iVar2 = DAT_90001acc;
    while (iVar1 = iVar1 + -1, -1 < iVar1) {
      FUN_8000fb84(0,iVar2);
      FUN_80010094();
      iVar2 = iVar2 + 1;
    }
    DAT_90001acc = -1;
    FUN_8000fc92(0,0);
  }
  return;
}


// ==== FUN_8000f072 @ 8000f072

void FUN_8000f072(char param_1,ushort param_2)

{
  if (-1 < DAT_90001acc) {
    if (param_1 == '\x01') {
      DAT_90001ad4 = DAT_90001ad4 - (short)param_2;
      if (DAT_90001ad4 < 0) {
        DAT_90001ad4 = DAT_90001ad4 + 0x37;
      }
      DAT_90001ad8 = DAT_90001ad8 - (short)param_2;
      if (DAT_90001ad8 < 0) {
        DAT_90001ad8 = DAT_90001ad8 + 0x37;
      }
      while (param_2 = param_2 - 1, -1 < (int)((uint)param_2 << 0x10)) {
        FUN_8000ff34();
      }
    }
    else {
      DAT_90001ad4 = DAT_90001ad4 + (short)param_2;
      if (0x36 < DAT_90001ad4) {
        DAT_90001ad4 = DAT_90001ad4 + -0x37;
      }
      DAT_90001ad8 = DAT_90001ad8 + (short)param_2;
      if (0x36 < DAT_90001ad8) {
        DAT_90001ad8 = DAT_90001ad8 + -0x37;
      }
      while (param_2 = param_2 - 1, -1 < (int)((uint)param_2 << 0x10)) {
        FUN_8000fe74();
      }
    }
    if (DAT_90001ad4 < DAT_90001ad8) {
      FUN_8000f8b0(0,DAT_90001acc,DAT_90001ad0 * 0x50);
      FUN_8000f9c6(&DAT_90001adc + DAT_90001ad4 * 0xa0);
      FUN_8000f970(&DAT_90001adc,DAT_90001ad4 * 0x50,0x20);
      FUN_8000f970(DAT_90001ad8 * 0x140 + -0x6fffe3e4,(0x36 - DAT_90001ad8) * 0x50,0x20);
    }
    else {
      FUN_8000f8b0(0,DAT_90001acc,(0x37 - DAT_90001ad4) * 0x50);
      FUN_8000f9c6(&DAT_90001adc + DAT_90001ad4 * 0xa0);
      FUN_8000f8b0(0,DAT_90001acc - (DAT_90001ad4 + -0x37),(DAT_90001ad8 + 1) * 0x50);
      FUN_8000f9c6(&DAT_90001adc);
      FUN_8000f970(DAT_90001ad8 * 0x140 + -0x6fffe3e4,((DAT_90001ad4 - DAT_90001ad8) + -1) * 0x50,
                   0x20);
    }
  }
  return;
}


// ==== FUN_8000f254 @ 8000f254

void FUN_8000f254(byte param_1,byte param_2,undefined4 param_3,byte param_4,byte *param_5)

{
  byte bVar1;
  int iVar2;
  ushort uVar3;
  uint uVar4;
  ushort *unaff_D7;
  ushort *puVar5;
  ushort *puVar6;
  ushort uStack_a;
  byte *local_8;
  
  local_8 = param_5;
  if (-1 < DAT_90001acc) {
    bVar1 = param_4 & 7;
    if (bVar1 == 1) {
      uVar3 = 1;
    }
    else if (bVar1 < 2) {
      if (bVar1 != 0) {
LAB_8000f2ba:
        FUN_8000ffdc(1);
        FUN_800100e4(0,0,"swawrite(): Illegal Font");
        FUN_8000ffdc(0);
        do {
                    /* WARNING: Do nothing block with infinite loop */
        } while( true );
      }
      uVar3 = 0;
    }
    else {
      if (bVar1 != 2) goto LAB_8000f2ba;
      uVar3 = 2;
    }
    if ((param_4 & 8) != 0) {
      uVar3 = uVar3 | 4;
    }
    uVar4 = (uint)(int)(short)(ushort)param_2 % 0x37;
    puVar6 = &DAT_90001adc + (uint)param_1 * 2 + uVar4 * 0xa0;
    if (*param_5 != 0) {
      do {
        if ((ushort *)0x90005f9b < puVar6) {
          puVar6 = &DAT_90001adc;
        }
        puVar5 = puVar6 + 1;
        *puVar6 = (ushort)*local_8 | uVar3 << 8;
        uStack_a = (ushort)((param_4 & 0x10) != 0);
        puVar6 = puVar6 + 2;
        *puVar5 = uStack_a << 0xf | 7;
        puVar5 = (ushort *)0x0;
        FUN_8000f8b0(0x4f,DAT_90001ad0 + DAT_90001acc + -1);
        if (DAT_90001ad4 < DAT_90001ad8) {
          if ((DAT_90001ad4 <= (int)uVar4) && ((int)uVar4 <= DAT_90001ad8)) {
            FUN_8000f8b0(param_1,(DAT_90001acc + uVar4) - DAT_90001ad4);
            goto LAB_8000f3f2;
          }
        }
        else {
          if ((int)uVar4 < DAT_90001ad4) {
            if (DAT_90001ad8 < (int)uVar4) goto LAB_8000f3f6;
            iVar2 = (DAT_90001acc + uVar4) - (DAT_90001ad4 + -0x37);
          }
          else {
            iVar2 = (DAT_90001acc + uVar4) - DAT_90001ad4;
          }
          FUN_8000f8b0(param_1,iVar2);
LAB_8000f3f2:
          puVar5 = unaff_D7;
        }
LAB_8000f3f6:
        if (puVar5 != (ushort *)0x0) {
          *puVar5 = (ushort)*local_8 | uVar3 << 8;
          puVar5[1] = uStack_a << 0xf | 7;
        }
        local_8 = local_8 + 1;
        param_1 = param_1 + 1;
        if (0x4f < param_1) {
          param_1 = 0;
          bVar1 = (char)uVar4 + 1;
          uVar4 = (uint)bVar1;
          if (0x37 < bVar1) {
            uVar4 = (uint)(int)(short)(ushort)bVar1 % 0x37;
          }
        }
      } while (*local_8 != 0);
    }
  }
  return;
}


// ==== FUN_8000f46a @ 8000f46a

void FUN_8000f46a(undefined4 param_1,undefined1 param_2,undefined1 param_3,undefined4 param_4,
                 byte param_5,undefined4 param_6)

{
  undefined4 uVar1;
  
  FUN_8000ffdc((param_5 & 8) != 0);
  FUN_80010004((param_5 & 0x10) != 0);
  param_5 = param_5 & 7;
  if (param_5 == 1) {
    uVar1 = 1;
  }
  else if (param_5 < 2) {
    if (param_5 != 0) {
LAB_8000f4e2:
      FUN_8000ffdc(1);
      FUN_800100e4(0,0,"nwawrite(): Illegal Font");
      FUN_8000ffdc(0);
      do {
                    /* WARNING: Do nothing block with infinite loop */
      } while( true );
    }
    uVar1 = 0;
  }
  else {
    if (param_5 != 2) goto LAB_8000f4e2;
    uVar1 = 2;
  }
  FUN_8001006a(uVar1);
  FUN_800100e4(param_2,param_3,param_6);
  return;
}


// ==== FUN_8000f574 @ 8000f574

void FUN_8000f574(undefined1 param_1,byte param_2,undefined1 param_3)

{
  int iVar1;
  
  switch(param_1) {
  case 0:
  case 0x10:
  case 0x3c:
  case 0x5b:
  case 0x78:
  case 0x7a:
    break;
  default:
    FUN_8000ffdc(1);
    FUN_800100e4(0,0,"cmdwrt(): Illegal command");
    FUN_8000ffdc(0);
    do {
                    /* WARNING: Do nothing block with infinite loop */
    } while( true );
  case 0x30:
switchD_8000f596_caseD_30:
    FUN_8001006a(0);
    break;
  case 0x31:
switchD_8000f596_caseD_31:
    FUN_8001006a(1);
    break;
  case 0x32:
switchD_8000f596_caseD_32:
    FUN_8001006a(2);
    break;
  case 0x33:
switchD_8000f596_caseD_33:
    FUN_8001006a(3);
    break;
  case 0x38:
    FUN_80010004(0);
    break;
  case 0x39:
    FUN_80010004(1);
    break;
  case 0x3a:
    FUN_8000ffdc(0);
    break;
  case 0x3b:
    FUN_8000ffdc(1);
    break;
  case 0x3e:
    FUN_80010004((param_2 & 0x10) != 0);
    FUN_8000ffdc((param_2 & 8) != 0);
    switch(param_2 & 7) {
    case 0:
      goto switchD_8000f596_caseD_30;
    case 1:
      goto switchD_8000f596_caseD_31;
    case 2:
      goto switchD_8000f596_caseD_32;
    case 3:
      goto switchD_8000f596_caseD_33;
    default:
      FUN_8000ffdc(1);
      FUN_800100e4(0,0,"cmdwrt(): Illegal font");
      FUN_8000ffdc(0);
      do {
                    /* WARNING: Do nothing block with infinite loop */
      } while( true );
    }
  case 0x40:
    FUN_8000fb84(0,0);
    break;
  case 0x42:
    FUN_8000fbd4();
    break;
  case 0x44:
    FUN_8000fc04();
    break;
  case 0x45:
    FUN_8000fc4e();
    break;
  case 0x4c:
    FUN_8000fb84(param_2,param_3);
    break;
  case 0x5e:
    DAT_90005f9c = (uint)(param_2 >> 4);
    DAT_90005fa0 = (uint)(param_2 & 0xf);
    FUN_8000faf4(DAT_90005fa4,DAT_90005f9c,DAT_90005fa0,7);
    break;
  case 0x5f:
    if (param_2 == 0) {
      DAT_90005fa4 = 0;
      FUN_8000faf4(0,DAT_90005f9c,DAT_90005fa0,7);
    }
    else {
      if (param_2 != 1) {
        FUN_8000ffdc(1);
        FUN_800100e4(0,0,"cmdwrt(): Illegal cursor mode");
        FUN_8000ffdc(0);
        do {
                    /* WARNING: Do nothing block with infinite loop */
        } while( true );
      }
      DAT_90005fa4 = 1;
      FUN_8000faf4(1,DAT_90005f9c,DAT_90005fa0,7);
    }
    break;
  case 0x60:
    iVar1 = 0;
    do {
      FUN_8000fb84(0,iVar1);
      FUN_80010094();
      iVar1 = iVar1 + 1;
    } while (iVar1 < 0x1d);
    break;
  case 0x61:
    FUN_80010094();
  }
  return;
}


// ==== FUN_8000f8b0 @ 8000f8b0

void FUN_8000f8b0(void)

{
  return;
}


// ==== FUN_8000f970 @ 8000f970

void FUN_8000f970(ushort *param_1,short param_2,byte param_3)

{
  while (param_2 = param_2 + -1, -1 < param_2) {
    *param_1 = (ushort)param_3 | DAT_90006038 << 8;
    param_1[1] = DAT_9000602c | DAT_90006030 << 4 | DAT_90006034 << 8;
    param_1 = param_1 + 2;
  }
  return;
}


// ==== FUN_8000f9c6 @ 8000f9c6

void FUN_8000f9c6(undefined2 *param_1,undefined2 *param_2,short param_3)

{
  param_3 = param_3 << 1;
  while (param_3 = param_3 + -1, -1 < param_3) {
    *param_2 = *param_1;
    param_1 = param_1 + 1;
    param_2 = param_2 + 1;
  }
  return;
}


// ==== FUN_8000f9f2 @ 8000f9f2

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_8000f9f2(void)

{
  _DAT_0d01c980 = (short)(DAT_90006006 + 0xf3000000U >> 2);
  _DAT_0d01c982 = (short)(DAT_9000600e + 0xf3000000U >> 2);
  _DAT_0d01c984 = (short)(DAT_90006016 + 0xf3000000U >> 2);
  _DAT_0d01c986 = (short)(DAT_9000601e + 0xf3000000U >> 2);
  _DAT_0d01c990 = (short)DAT_90006002;
  _DAT_0d01c992 = (short)DAT_9000600a;
  _DAT_0d01c994 = (short)DAT_90006012;
  _DAT_0d01c996 = (short)DAT_9000601a;
  return;
}


// ==== FUN_8000fa78 @ 8000fa78

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_8000fa78(void)

{
  int unaff_D7;
  
  _DAT_0d01c9a2 = DAT_90005ff4 | DAT_90005ff0 << 8 | DAT_90005fe4 << 0xd;
  _DAT_0d01c9a4 = DAT_90005ff8;
  FUN_8000f8b0(DAT_90005fe6,DAT_90005fea);
  DAT_90005ffa = unaff_D7;
  if (unaff_D7 != 0) {
    _DAT_0d01c9a0 = (undefined2)(unaff_D7 + 0xf3000000U >> 2);
    _DAT_0d01cffe = 1;
  }
  return;
}


// ==== FUN_8000faf4 @ 8000faf4

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_8000faf4(undefined4 param_1,int param_2,int param_3,int param_4)

{
  switch(param_1) {
  case 0:
  case 2:
  case 3:
    if (param_2 < 0) {
      return;
    }
    if (8 < param_2) {
      return;
    }
    if (param_3 < 0) {
      return;
    }
    if (8 < param_3) {
      return;
    }
    if (param_3 < param_2) {
      return;
    }
    if (param_4 < 0) {
      return;
    }
    if (0xf < param_4) {
      return;
    }
    _DAT_90005fee = param_2;
    _DAT_90005ff2 = param_3;
    _DAT_90005ff6 = param_4;
switchD_8000fb1a_caseD_1:
    ram0x90005fe2 = param_1;
    FUN_8000fa78();
    return;
  case 1:
    goto switchD_8000fb1a_caseD_1;
  default:
    return;
  }
}


// ==== FUN_8000fb84 @ 8000fb84

void FUN_8000fb84(int param_1,int param_2)

{
  if ((((-1 < param_1) && (param_1 < 0x50)) && (-1 < param_2)) && (param_2 < 0x1d)) {
    DAT_90005fe6 = param_1;
    DAT_90005fea = param_2;
    FUN_8000fa78();
  }
  return;
}


// ==== FUN_8000fbd4 @ 8000fbd4

void FUN_8000fbd4(void)

{
  DAT_90005fea = DAT_90005fea + 1;
  if (DAT_90005fea < 0x1d) {
    DAT_90005fe6 = 0;
  }
  else {
    DAT_90005fea = 0x1c;
  }
  FUN_8000fa78();
  return;
}


// ==== FUN_8000fc04 @ 8000fc04

void FUN_8000fc04(void)

{
  DAT_90005fe6 = DAT_90005fe6 + 1;
  if (0x4f < DAT_90005fe6) {
    DAT_90005fea = DAT_90005fea + 1;
    if (DAT_90005fea < 0x1d) {
      DAT_90005fe6 = 0;
    }
    else {
      DAT_90005fe6 = 0x4f;
      DAT_90005fea = 0x1c;
    }
  }
  FUN_8000fa78();
  return;
}


// ==== FUN_8000fc4e @ 8000fc4e

void FUN_8000fc4e(void)

{
  DAT_90005fe6 = DAT_90005fe6 + -1;
  if (DAT_90005fe6 < 0) {
    DAT_90005fea = DAT_90005fea + -1;
    if (DAT_90005fea < 0) {
      DAT_90005fe6 = 0;
      DAT_90005fea = 0;
    }
    else {
      DAT_90005fe6 = 0x4f;
    }
  }
  FUN_8000fa78();
  return;
}


// ==== FUN_8000fc92 @ 8000fc92

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_8000fc92(int param_1,int param_2)

{
  if ((((-1 < param_1) && (param_1 < 0x1d)) && (-1 < param_2)) &&
     ((param_2 < 0x1d && (param_1 <= param_2)))) {
    if (DAT_90005ffe != 0) {
      if (DAT_90005ffe == 1) {
        FUN_8000f9c6(DAT_90006006,0xd000000,DAT_90006002 * 0x50);
      }
      else {
        FUN_8000f9c6(DAT_9000600e,DAT_90006002 * 0x140 + 0xd000000,DAT_9000600a * 0x50);
      }
      DAT_90005ffe = 0;
      DAT_90006002 = 0x1d;
      DAT_90006006 = 0xd000000;
      DAT_9000600a = 0;
      DAT_9000600e = 0xd000000;
      DAT_90006012 = 0;
      DAT_90006016 = 0xd000000;
      DAT_9000601a = 0;
      DAT_9000601e = 0xd000000;
    }
    if (param_1 < param_2) {
      param_2 = param_2 + 1;
      FUN_8000f9c6(DAT_90006006 + param_1 * 0x140,0xd002440,(param_2 - param_1) * 0x50);
      if (param_1 == 0) {
        DAT_90005ffe = 1;
        if (param_2 < 0x1d) {
          DAT_9000600a = 0x1d - param_2;
          DAT_9000600e = param_2 * 0x140 + 0xd000000;
          DAT_90006002 = param_2;
        }
        else {
          DAT_90006002 = 0x1d;
        }
        DAT_90006006 = 0xd002440;
      }
      else {
        DAT_90005ffe = 2;
        DAT_90006002 = param_1;
        DAT_9000600a = param_2 - param_1;
        DAT_9000600e = 0xd002440;
        if (param_2 < 0x1d) {
          DAT_90006012 = 0x1d - param_2;
          DAT_90006016 = param_2 * 0x140 + 0xd000000;
        }
      }
    }
    FUN_8000f9f2();
    _DAT_0d01cffe = 1;
  }
  return;
}


// ==== FUN_8000fe74 @ 8000fe74

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_8000fe74(void)

{
  int *piVar1;
  
  if (DAT_90005ffe != 0) {
    if (DAT_90005ffe == 1) {
      piVar1 = &DAT_90006002;
    }
    else {
      piVar1 = &DAT_9000600a;
    }
    if ((uint)piVar1[1] < 0xd004880) {
      piVar1[1] = piVar1[1] + 0x140;
    }
    else {
      FUN_8000f9c6(piVar1[1] + 0x140,0xd002440,(*piVar1 + -1) * 0x50);
      piVar1[1] = 0xd002440;
    }
    FUN_8000f970(piVar1[1] + (*piVar1 + -1) * 0x140,0x50,0x20);
    FUN_8000f9f2();
    _DAT_0d01cffe = 1;
  }
  return;
}


// ==== FUN_8000ff34 @ 8000ff34

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_8000ff34(void)

{
  int *piVar1;
  
  if (DAT_90005ffe != 0) {
    if (DAT_90005ffe == 1) {
      piVar1 = &DAT_90006002;
    }
    else {
      piVar1 = &DAT_9000600a;
    }
    if ((uint)piVar1[1] < 0xd002441) {
      FUN_8000f9c6(piVar1[1],0xd0049c0,(*piVar1 + -1) * 0x50);
      piVar1[1] = 0xd004880;
    }
    else {
      piVar1[1] = piVar1[1] + -0x140;
    }
    FUN_8000f970(piVar1[1],0x50,0x20);
    FUN_8000f9f2();
    _DAT_0d01cffe = 1;
  }
  return;
}


// ==== FUN_8000ffdc @ 8000ffdc

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_8000ffdc(int param_1)

{
  if ((param_1 == 1) || (param_1 == 0)) {
    _DAT_90006026 = param_1;
  }
  return;
}


// ==== FUN_80010004 @ 80010004

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_80010004(int param_1)

{
  if ((param_1 == 1) || (param_1 == 0)) {
    _DAT_90006022 = param_1;
  }
  return;
}


// ==== FUN_8001002c @ 8001002c

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_8001002c(int param_1,int param_2)

{
  if ((((-1 < param_1) && (param_1 < 0x10)) && (-1 < param_2)) && (param_2 < 0x10)) {
    _DAT_9000602a = param_1;
    _DAT_90006032 = param_2;
  }
  return;
}


// ==== FUN_8001006a @ 8001006a

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_8001006a(int param_1)

{
  if ((param_1 < 4) && (-1 < param_1)) {
    _DAT_90006036 = param_1;
  }
  return;
}


// ==== FUN_80010094 @ 80010094

void FUN_80010094(void)

{
  int unaff_D7;
  
  FUN_8000f8b0(0,DAT_90005fea);
  if (unaff_D7 != 0) {
    FUN_8000f8b0(0,DAT_90005fea,0x50,0x20);
    FUN_8000f970();
  }
  return;
}


// ==== FUN_800100e4 @ 800100e4

void FUN_800100e4(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  int unaff_D7;
  
  FUN_8000fb84(param_1,param_2);
  if (-1 < unaff_D7) {
    FUN_8001011a(param_3);
  }
  return;
}


// ==== FUN_8001011a @ 8001011a

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_8001011a(byte *param_1)

{
  ushort uVar1;
  ushort *unaff_D7;
  ushort *puVar2;
  
  FUN_8000f8b0(DAT_90005fe6,DAT_90005fea);
  puVar2 = unaff_D7;
  if (unaff_D7 != (ushort *)0x0) {
    while (*param_1 != 0) {
      uVar1 = DAT_90006038;
      if (_DAT_90006026 != 0) {
        uVar1 = DAT_90006038 | 4;
      }
      *puVar2 = (ushort)*param_1 | uVar1 << 8;
      param_1 = param_1 + 1;
      puVar2[1] = DAT_9000602c | DAT_90006030 << 4 | DAT_90006034 << 8 | DAT_90006024 << 0xf;
      puVar2 = puVar2 + 2;
      if (((*param_1 != 0) && (0x4e < DAT_90005fe6)) && (0x1b < DAT_90005fea)) {
        return;
      }
      FUN_8000fc04();
      if ((int)unaff_D7 < 0) {
        return;
      }
    }
  }
  return;
}


// ==== FUN_800101e4 @ 800101e4

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_800101e4(void)

{
  FUN_80015e48(&DAT_9000603a,s______Header__puts_c_v_1_7_92_07__90005fa8 + 0x3a,0x1c);
  FUN_80015e48(&DAT_90006056,&DAT_90005ffe,0x24);
  FUN_80015e48(&DAT_9000607a,&DAT_90006022,0x18);
  FUN_8000f970(0xd000000,0x4000,0x20);
  FUN_8000f9f2();
  _DAT_0d01c9c0 = 0x8000;
  FUN_8000fa78();
  _DAT_0d01cffe = 1;
  return;
}


// ==== FUN_80010264 @ 80010264

void FUN_80010264(undefined4 param_1,undefined4 param_2,undefined2 param_3,undefined4 param_4,
                 undefined4 param_5)

{
  ushort unaff_D7w;
  
  FUN_80015ca0(param_1);
  if (unaff_D7w == 3) {
    FUN_8001517c(param_1,param_2,param_3,param_4,param_5);
    return;
  }
  if (unaff_D7w < 4) {
    if (unaff_D7w == 1) {
      FUN_800141d4(param_1,param_2,param_3,param_4,param_5);
      return;
    }
    if (unaff_D7w == 2) {
      FUN_80012dd8(param_1,param_2,param_3,param_4,param_5);
      return;
    }
  }
  else if ((unaff_D7w == 0x81) || (unaff_D7w == 0x83)) {
    FUN_80014704(param_1,param_2,param_3,param_4,param_5);
    return;
  }
  FUN_80015afc(param_1,0xfffffff6);
  return;
}


// ==== FUN_80010328 @ 80010328

void FUN_80010328(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5,undefined4 param_6)

{
  ushort unaff_D7w;
  
  FUN_80015ca0(param_1);
  if (unaff_D7w == 4) {
    FUN_80016344(param_1,param_2,param_3,param_4);
  }
  else {
    if (unaff_D7w < 5) {
      if (unaff_D7w == 2) {
        FUN_80012e1c(param_1,param_2,param_3,param_4);
        return;
      }
      if (unaff_D7w < 3) {
        if (unaff_D7w == 1) {
          FUN_80014226(param_1,param_2,param_3,param_4);
          return;
        }
      }
      else if (unaff_D7w == 3) {
        FUN_800151e0(param_1,param_2,param_3,param_4);
        return;
      }
    }
    else {
      if (unaff_D7w == 6) {
        FUN_800167a6(param_6,param_2,param_3,param_4);
        return;
      }
      if (unaff_D7w < 7) {
        if (unaff_D7w == 5) {
          FUN_800164fe(param_1,param_2,param_3,param_4,param_5);
          return;
        }
      }
      else if ((unaff_D7w == 0x81) || (unaff_D7w == 0x83)) {
        FUN_80014776(param_1,param_2,param_3,param_4);
        return;
      }
    }
    FUN_80015afc(param_1,0xfffffff6);
  }
  return;
}


// ==== FUN_80010428 @ 80010428

void FUN_80010428(undefined4 param_1,short param_2,undefined4 param_3,undefined4 param_4)

{
  ushort unaff_D7w;
  
  FUN_80015ca0(param_1);
  if (unaff_D7w == 4) {
    FUN_8001636c((int)param_2,param_3);
  }
  else {
    if (unaff_D7w < 5) {
      if (unaff_D7w == 2) {
        FUN_80012e5a((int)param_2,param_3);
        return;
      }
      if (unaff_D7w < 3) {
        if (unaff_D7w == 1) {
          FUN_80014268((int)param_2,param_3);
          return;
        }
      }
      else if (unaff_D7w == 3) {
        FUN_80015234((int)param_2,param_3);
        return;
      }
    }
    else {
      if (unaff_D7w == 6) {
        FUN_800167d6((int)param_2,param_3);
        return;
      }
      if (unaff_D7w < 7) {
        if (unaff_D7w == 5) {
          FUN_80016530((int)param_2,param_3,param_4);
          return;
        }
      }
      else if ((unaff_D7w == 0x81) || (unaff_D7w == 0x83)) {
        FUN_80014620((int)param_2,param_3);
        return;
      }
    }
    FUN_80015afc(param_1,0xfffffff6);
  }
  return;
}


// ==== FUN_80010512 @ 80010512

void FUN_80010512(undefined4 param_1,short param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5,undefined4 param_6)

{
  int iVar1;
  uint uVar2;
  uint unaff_D7;
  
  FUN_80015ca0(param_1);
  uVar2 = unaff_D7 & 0xffff;
  if (uVar2 == 4) {
    FUN_80016392((int)param_2,param_3,param_4,param_5);
  }
  else {
    if (uVar2 < 5) {
      if (uVar2 == 2) {
        FUN_80012e7e((int)param_2,param_3,param_4,param_5);
        return;
      }
      if (uVar2 < 3) {
        if (uVar2 == 1) {
          FUN_8001428c((int)param_2,param_3,param_4,param_5);
          return;
        }
      }
      else if (uVar2 == 3) {
        FUN_80015274((int)param_2,param_3,param_4,param_5);
        return;
      }
    }
    else {
      if (uVar2 == 6) {
        iVar1 = (short)DAT_90006194 * 0x10;
        *(int *)(&DAT_90006094 + iVar1) = (int)param_2;
        *(undefined4 *)(&DAT_90006098 + iVar1) = param_3;
        *(undefined4 *)(&DAT_9000609c + iVar1) = param_4;
        *(undefined4 *)(&DAT_900060a0 + iVar1) = 0;
        FUN_80016804((int)param_2,param_3,param_4,param_5);
        *(uint *)(&DAT_900060a0 + iVar1) = unaff_D7;
        DAT_90006194 = DAT_90006194 + 1 & 0xf;
        return;
      }
      if (uVar2 < 7) {
        if (uVar2 == 5) {
          FUN_80016560((int)param_2,param_3,param_4,param_5,param_6);
          return;
        }
      }
      else if ((uVar2 == 0x81) || (uVar2 == 0x83)) {
        FUN_80014664((int)param_2,param_3,param_4,param_5);
        return;
      }
    }
    FUN_80015afc(param_1,0xfffffff6);
  }
  return;
}


// ==== FUN_8001065e @ 8001065e

void FUN_8001065e(undefined4 param_1,short param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5,undefined4 param_6)

{
  int iVar1;
  uint uVar2;
  uint unaff_D7;
  
  FUN_80015ca0(param_1);
  uVar2 = unaff_D7 & 0xffff;
  if (uVar2 == 4) {
    FUN_800163c4((int)param_2,param_3,param_4,param_5);
  }
  else {
    if (uVar2 < 5) {
      if (uVar2 == 2) {
        FUN_80012eae((int)param_2,param_3,param_4,param_5);
        return;
      }
      if (uVar2 < 3) {
        if (uVar2 == 1) {
          FUN_800142bc((int)param_2,param_3,param_4,param_5);
          return;
        }
      }
      else if (uVar2 == 3) {
        FUN_800152c0((int)param_2,param_3,param_4,param_5);
        return;
      }
    }
    else {
      if (uVar2 == 6) {
        iVar1 = (short)DAT_90006296 * 0x10;
        *(int *)(&DAT_90006196 + iVar1) = (int)param_2;
        *(undefined4 *)(&DAT_9000619a + iVar1) = param_3;
        *(undefined4 *)(&DAT_9000619e + iVar1) = param_4;
        *(undefined4 *)(&DAT_900061a2 + iVar1) = 0;
        FUN_80016892((int)param_2,param_3,param_4,param_5);
        *(uint *)(&DAT_900061a2 + iVar1) = unaff_D7;
        DAT_90006296 = DAT_90006296 + 1 & 0xf;
        return;
      }
      if (uVar2 < 7) {
        if (uVar2 == 5) {
          FUN_8001659c((int)param_2,param_3,param_4,param_5,param_6);
          return;
        }
      }
      else if ((uVar2 == 0x81) || (uVar2 == 0x83)) {
        FUN_800146b0((int)param_2,param_3,param_4,param_5);
        return;
      }
    }
    FUN_80015afc(param_1,0xfffffff6);
  }
  return;
}


// ==== FUN_800107aa @ 800107aa

void FUN_800107aa(undefined4 param_1,short param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5,undefined4 param_6)

{
  ushort unaff_D7w;
  
  FUN_80015ca0(param_1);
  if (unaff_D7w == 4) {
    FUN_800163f6((int)param_2,param_3,param_4,param_5);
    return;
  }
  if (unaff_D7w < 5) {
    if (unaff_D7w == 1) {
      FUN_800142ec((int)param_2,param_3,param_4,param_5);
      return;
    }
    if (unaff_D7w == 2) {
      FUN_80012ede((int)param_2,param_3,param_4,param_5);
      return;
    }
  }
  else {
    if (unaff_D7w == 0x81) {
LAB_80010804:
      FUN_80014e38((int)param_2,param_3,param_4,param_5);
      return;
    }
    if (unaff_D7w < 0x82) {
      if (unaff_D7w == 5) {
        FUN_800165d8((int)param_2,param_3,param_4,param_5,param_6);
        return;
      }
    }
    else if (unaff_D7w == 0x83) goto LAB_80010804;
  }
  FUN_80015afc(param_1,0xfffffff6);
  return;
}


// ==== FUN_8001087c @ 8001087c

void FUN_8001087c(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  ushort unaff_D7w;
  
  FUN_80015ca0(param_1);
  if (unaff_D7w == 3) {
    FUN_8001530c(param_1,param_2,param_3);
    return;
  }
  if (unaff_D7w < 4) {
    if (unaff_D7w == 1) {
      FUN_80013a30(param_1,param_2,param_3);
      return;
    }
    if (unaff_D7w == 2) {
      FUN_800131c0(param_1,param_2,param_3);
      return;
    }
  }
  else {
    if (unaff_D7w == 0x81) {
LAB_800108ee:
      FUN_800147d8(param_1,param_2,param_3);
      return;
    }
    if (unaff_D7w < 0x82) {
      if (unaff_D7w == 6) {
        FUN_800169ba(param_4,param_2,param_3);
        return;
      }
    }
    else if (unaff_D7w == 0x83) goto LAB_800108ee;
  }
  FUN_80015afc(param_1,0xfffffff6);
  return;
}


// ==== FUN_80010932 @ 80010932

void FUN_80010932(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  ushort unaff_D7w;
  
  FUN_80015ca0(param_1);
  if (unaff_D7w == 2) {
    FUN_80012f0e(param_1,param_2,param_3);
  }
  else {
    if (unaff_D7w < 3) {
      if (unaff_D7w == 1) {
        FUN_8001431e(param_1,param_2,param_3);
        return;
      }
    }
    else if ((unaff_D7w == 0x81) || (unaff_D7w == 0x83)) {
      FUN_8001483a(param_1,param_2,param_3);
      return;
    }
    FUN_80015afc(param_1,0xfffffff6);
  }
  return;
}


// ==== FUN_800109b8 @ 800109b8

void FUN_800109b8(undefined4 param_1,undefined2 param_2,undefined4 param_3)

{
  ushort unaff_D7w;
  
  FUN_80015ca0(param_1);
  if (unaff_D7w == 3) {
    FUN_80015360(param_1,param_2,param_3);
    return;
  }
  if (unaff_D7w < 4) {
    if (unaff_D7w == 1) {
      FUN_80013abe(param_1,param_2,param_3);
      return;
    }
    if (unaff_D7w == 2) {
      FUN_800131f8(param_1,param_2,param_3);
      return;
    }
  }
  else if ((unaff_D7w == 0x81) || (unaff_D7w == 0x83)) {
    FUN_8001489c(param_1,param_2,param_3);
    return;
  }
  FUN_80015afc(param_1,0xfffffff6);
  return;
}


// ==== FUN_80010a64 @ 80010a64

void FUN_80010a64(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5)

{
  ushort unaff_D7w;
  
  FUN_80015ca0(param_1);
  if (unaff_D7w == 3) {
    FUN_800153a8(param_1,param_2,param_3,param_4);
    return;
  }
  if (unaff_D7w < 4) {
    if (unaff_D7w == 1) {
      FUN_80014358(param_1,param_2,param_3,param_4);
      return;
    }
    if (unaff_D7w == 2) {
      FUN_80012f46(param_1,param_2,param_3,param_4);
      return;
    }
  }
  else {
    if (unaff_D7w == 0x81) {
LAB_80010ade:
      FUN_800148f2(param_1,param_2,param_3,param_4);
      return;
    }
    if (unaff_D7w < 0x82) {
      if (unaff_D7w == 6) {
        FUN_800169e2(param_5,param_2,param_3,param_4);
        return;
      }
    }
    else if (unaff_D7w == 0x83) goto LAB_80010ade;
  }
  FUN_80015afc(param_1,0xfffffff6);
  return;
}


// ==== FUN_80010b28 @ 80010b28

void FUN_80010b28(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  ushort unaff_D7w;
  
  FUN_80015ca0(param_1);
  if (unaff_D7w == 4) {
    FUN_80016428(param_1,param_3,param_2);
  }
  else {
    if (unaff_D7w < 5) {
      if (unaff_D7w == 2) {
        FUN_80012f8e(param_1,param_2);
        return;
      }
      if (unaff_D7w < 3) {
        if (unaff_D7w == 1) {
          FUN_800143a2(param_1,param_2);
          return;
        }
      }
      else if (unaff_D7w == 3) {
        FUN_8001540c(param_1,param_2);
        return;
      }
    }
    else {
      if (unaff_D7w == 6) {
        FUN_80016734(0,param_3,param_2);
        return;
      }
      if (unaff_D7w < 7) {
        if (unaff_D7w == 5) {
          FUN_80016614(param_1,param_3,param_2,param_4);
          return;
        }
      }
      else if ((unaff_D7w == 0x81) || (unaff_D7w == 0x83)) {
        FUN_80014964(param_1,param_2);
        return;
      }
    }
    FUN_80015afc(param_1,0xfffffff6);
  }
  return;
}


// ==== FUN_80010c08 @ 80010c08

void FUN_80010c08(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  ushort unaff_D7w;
  
  FUN_80015ca0(param_1);
  if (unaff_D7w == 4) {
    FUN_8001644a(param_1,param_3,param_2);
  }
  else {
    if (unaff_D7w < 5) {
      if (unaff_D7w == 2) {
        FUN_80012fb0(param_1,param_2);
        return;
      }
      if (unaff_D7w < 3) {
        if (unaff_D7w == 1) {
          FUN_800143c8(param_1,param_2);
          return;
        }
      }
      else if (unaff_D7w == 3) {
        FUN_8001544c(param_1,param_2);
        return;
      }
    }
    else {
      if (unaff_D7w == 6) {
        FUN_80016778(param_3,param_2);
        return;
      }
      if (unaff_D7w < 7) {
        if (unaff_D7w == 5) {
          FUN_80016640(param_1,param_3,param_2,param_4);
          return;
        }
      }
      else if ((unaff_D7w == 0x81) || (unaff_D7w == 0x83)) {
        FUN_800149b2(param_1,param_2);
        return;
      }
    }
    FUN_80015afc(param_1,0xfffffff6);
  }
  return;
}


// ==== FUN_80010ce4 @ 80010ce4

void FUN_80010ce4(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  ushort unaff_D7w;
  
  FUN_80015ca0(param_1);
  if (unaff_D7w == 3) {
    FUN_8001548c(param_1,param_2,param_3);
  }
  else {
    if (unaff_D7w < 4) {
      if (unaff_D7w == 1) {
        FUN_800143ee(param_1,param_2,param_3);
        return;
      }
    }
    else if ((unaff_D7w == 0x81) || (unaff_D7w == 0x83)) {
      FUN_80014a00(param_1,param_2,param_3);
      return;
    }
    FUN_80015afc(param_1,0xfffffff6);
  }
  return;
}


// ==== FUN_80010d6e @ 80010d6e

void FUN_80010d6e(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  ushort unaff_D7w;
  
  FUN_80015ca0(param_1);
  if (unaff_D7w == 3) {
    FUN_800154d2(param_1,param_2,param_3);
    return;
  }
  if (unaff_D7w < 4) {
    if (unaff_D7w == 1) {
      FUN_8001441a(param_1,param_2,param_3);
      return;
    }
    if (unaff_D7w == 2) {
      FUN_80012ffa(param_1,param_2,param_3);
      return;
    }
  }
  else {
    if (unaff_D7w == 0x81) {
LAB_80010de0:
      FUN_80014a50(param_1,param_2,param_3);
      return;
    }
    if (unaff_D7w < 0x82) {
      if (unaff_D7w == 6) {
        FUN_80016ab8(param_4,param_2,param_3);
        return;
      }
    }
    else if (unaff_D7w == 0x83) goto LAB_80010de0;
  }
  FUN_80015afc(param_1,0xfffffff6);
  return;
}


// ==== FUN_80010e24 @ 80010e24

void FUN_80010e24(undefined4 param_1,undefined2 param_2,undefined2 param_3,undefined4 param_4,
                 undefined4 param_5,undefined4 param_6)

{
  ushort unaff_D7w;
  
  FUN_80015ca0(param_1);
  if (unaff_D7w == 3) {
    FUN_80015526(param_1,param_2,param_3,param_4,param_5);
    return;
  }
  if (unaff_D7w < 4) {
    if (unaff_D7w == 1) {
      FUN_80014454(param_1,param_2,param_3,param_4,param_5);
      return;
    }
    if (unaff_D7w == 2) {
      FUN_80013398(param_1,param_2,param_3,param_4,param_5);
      return;
    }
  }
  else {
    if (unaff_D7w == 0x81) {
LAB_80010ec0:
      FUN_80014ab2(param_1,param_2,param_3,param_4,param_5);
      return;
    }
    if (unaff_D7w < 0x82) {
      if (unaff_D7w == 6) {
        FUN_8001690a(param_6,param_4,param_2,param_3,0,param_5);
        return;
      }
    }
    else if (unaff_D7w == 0x83) goto LAB_80010ec0;
  }
  FUN_80015afc(param_1,0xfffffff6);
  return;
}


// ==== FUN_80010f28 @ 80010f28

void FUN_80010f28(undefined4 param_1,ushort param_2,undefined2 param_3,undefined2 param_4,
                 undefined4 param_5,undefined4 param_6,undefined4 param_7)

{
  ushort unaff_D7w;
  
  FUN_80015ca0(param_1);
  if (unaff_D7w == 3) {
    FUN_8001557c(param_1,param_2,param_3,param_4,param_5,param_6);
    return;
  }
  if (unaff_D7w < 4) {
    if (unaff_D7w == 1) {
      FUN_80013d30(param_1,param_2,param_3,param_4,param_5,param_6);
      return;
    }
    if (unaff_D7w == 2) {
      FUN_80013244(param_1,param_2,param_3,param_4,param_5,param_6);
      return;
    }
  }
  else {
    if (unaff_D7w == 0x81) {
LAB_80010fda:
      FUN_80014b18(param_1,param_2,param_3,param_4,param_5,param_6);
      return;
    }
    if (unaff_D7w < 0x82) {
      if (unaff_D7w == 6) {
        FUN_80016ab0(param_7,param_5,param_4,param_2 - 1,param_3,param_6);
        return;
      }
    }
    else if (unaff_D7w == 0x83) goto LAB_80010fda;
  }
  FUN_80015afc(param_1,0xfffffff6);
  return;
}


// ==== FUN_80011054 @ 80011054

void FUN_80011054(undefined4 param_1,undefined2 param_2,undefined2 param_3,undefined2 param_4,
                 undefined4 param_5,undefined4 param_6)

{
  ushort unaff_D7w;
  
  FUN_80015ca0(param_1);
  if (unaff_D7w == 3) {
    FUN_800155e4(param_1,param_2,param_3,param_4,param_5,param_6);
    return;
  }
  if (unaff_D7w < 4) {
    if (unaff_D7w == 1) {
      FUN_800140d4(param_1,param_2,param_3,param_4,param_5,param_6);
      return;
    }
    if (unaff_D7w == 2) {
      FUN_80013282(param_1,param_2,param_3,param_4,param_5,param_6);
      return;
    }
  }
  else if ((unaff_D7w == 0x81) || (unaff_D7w == 0x83)) {
    FUN_80014b8e(param_1,param_2,param_3,param_4,param_5,param_6);
    return;
  }
  FUN_80015afc(param_1,0xfffffff6);
  return;
}


// ==== FUN_80011148 @ 80011148

void FUN_80011148(undefined4 param_1,undefined4 param_2)

{
  ushort unaff_D7w;
  
  FUN_80015ca0(param_1);
  if (unaff_D7w == 3) {
    FUN_8001564c(param_1,param_2);
    return;
  }
  if (unaff_D7w < 4) {
    if (unaff_D7w == 1) {
      FUN_80014490(param_1,param_2);
      return;
    }
    if (unaff_D7w == 2) {
      FUN_80013032(param_1,param_2);
      return;
    }
  }
  else if ((unaff_D7w == 0x81) || (unaff_D7w == 0x83)) {
    FUN_80014c04(param_1,param_2);
    return;
  }
  FUN_80015afc(param_1,0xfffffff6);
  return;
}


// ==== FUN_800111d8 @ 800111d8

void FUN_800111d8(undefined4 param_1,undefined4 param_2)

{
  short unaff_D7w;
  
  FUN_80015ca0(param_1);
  if (unaff_D7w == 2) {
    FUN_80013054(param_1,param_2);
  }
  else {
    FUN_80015afc(param_1,0xfffffff6);
  }
  return;
}


// ==== FUN_8001121c @ 8001121c

void FUN_8001121c(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  ushort unaff_D7w;
  
  FUN_80015ca0(param_1);
  if (unaff_D7w == 3) {
    FUN_8001568c(param_1,param_2,param_3);
    return;
  }
  if (unaff_D7w < 4) {
    if (unaff_D7w == 1) {
      FUN_800144b6(param_1,param_2,param_3);
      return;
    }
    if (unaff_D7w == 2) {
      FUN_80013076(param_1,param_2,param_3);
      return;
    }
  }
  else if ((unaff_D7w == 0x81) || (unaff_D7w == 0x83)) {
    FUN_80014c52(param_1,param_2,param_3);
    return;
  }
  FUN_80015afc(param_1,0xfffffff6);
  return;
}


// ==== FUN_800112b8 @ 800112b8

void FUN_800112b8(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  ushort unaff_D7w;
  
  FUN_80015ca0(param_1);
  if (unaff_D7w == 3) {
    FUN_800156d2(param_1,param_2,param_3);
    return;
  }
  if (unaff_D7w < 4) {
    if (unaff_D7w == 1) {
      FUN_800144e2(param_1,param_2,param_3);
      return;
    }
    if (unaff_D7w == 2) {
      FUN_8001309e(param_1,param_2,param_3);
      return;
    }
  }
  else if ((unaff_D7w == 0x81) || (unaff_D7w == 0x83)) {
    FUN_80014ca2(param_1,param_2,param_3);
    return;
  }
  FUN_80015afc(param_1,0xfffffff6);
  return;
}


// ==== FUN_80011354 @ 80011354

void FUN_80011354(undefined4 param_1,undefined4 param_2)

{
  ushort unaff_D7w;
  
  FUN_80015ca0(param_1);
  if (unaff_D7w == 3) {
    FUN_80015718(param_1,param_2);
    return;
  }
  if (unaff_D7w < 4) {
    if (unaff_D7w == 1) {
      FUN_8001450e(param_1,param_2);
      return;
    }
    if (unaff_D7w == 2) {
      FUN_800130c6(param_1,param_2);
      return;
    }
  }
  else if ((unaff_D7w == 0x81) || (unaff_D7w == 0x83)) {
    FUN_80014cf2(param_1,param_2);
    return;
  }
  FUN_80015afc(param_1,0xfffffff6);
  return;
}


// ==== FUN_800113e4 @ 800113e4

void FUN_800113e4(undefined4 param_1,undefined1 param_2,undefined1 param_3,undefined4 param_4,
                 undefined4 param_5)

{
  ushort unaff_D7w;
  
  FUN_80015ca0(param_1);
  if (unaff_D7w == 3) {
    FUN_80015758(param_1,param_2,param_3,param_4,param_5);
    return;
  }
  if (unaff_D7w < 4) {
    if (unaff_D7w == 1) {
      FUN_80014534(param_1,param_2,param_3,param_4,param_5);
      return;
    }
    if (unaff_D7w == 2) {
      FUN_800130e8(param_1,param_2,param_3,param_4,param_5);
      return;
    }
  }
  else if ((unaff_D7w == 0x81) || (unaff_D7w == 0x83)) {
    FUN_80014d40(param_1,param_2,param_3,param_4,param_5);
    return;
  }
  FUN_80015afc(param_1,0xfffffff6);
  return;
}


// ==== FUN_800114b8 @ 800114b8

void FUN_800114b8(undefined4 param_1,undefined4 param_2)

{
  ushort unaff_D7w;
  
  FUN_80015ca0(param_1);
  if (unaff_D7w == 3) {
    FUN_800157b4(param_1,param_2);
    return;
  }
  if (unaff_D7w < 4) {
    if (unaff_D7w == 1) {
      FUN_80013c78(param_1,param_2);
      return;
    }
    if (unaff_D7w == 2) {
      FUN_80013222(param_1,param_2);
      return;
    }
  }
  else if ((unaff_D7w == 0x81) || (unaff_D7w == 0x83)) {
    FUN_80014dea(param_1,param_2);
    return;
  }
  FUN_80015afc(param_1,0xfffffff6);
  return;
}


// ==== FUN_80011548 @ 80011548

/* WARNING: Removing unreachable block (ram,0x80011576) */
/* WARNING: Removing unreachable block (ram,0x8001157c) */
/* WARNING: Removing unreachable block (ram,0x80011582) */
/* WARNING: Removing unreachable block (ram,0x80011588) */
/* WARNING: Removing unreachable block (ram,0x8001158e) */
/* WARNING: Removing unreachable block (ram,0x80011594) */
/* WARNING: Removing unreachable block (ram,0x8001159a) */
/* WARNING: Removing unreachable block (ram,0x800115a0) */
/* WARNING: Removing unreachable block (ram,0x800115a6) */

void FUN_80011548(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  ushort unaff_D7w;
  
  FUN_80015ca0(param_1);
  FUN_80015ca0(param_2);
  if (unaff_D7w == 3) {
    FUN_80015860(param_1,param_2,param_3);
    return;
  }
  if (unaff_D7w < 4) {
    if (unaff_D7w == 1) {
      FUN_80014578(param_1,param_2,param_3);
      return;
    }
    if (unaff_D7w == 2) {
      FUN_80013128(param_1,param_2,param_3);
      return;
    }
  }
  else if ((unaff_D7w == 0x81) || (unaff_D7w == 0x83)) {
    FUN_80014e8e(param_1,param_2,param_3);
    return;
  }
  FUN_80015afc(param_1,0xfffffff6);
  return;
}


// ==== FUN_80011632 @ 80011632

void FUN_80011632(undefined4 param_1,undefined4 param_2)

{
  ushort unaff_D7w;
  
  FUN_80015ca0(param_1);
  if (unaff_D7w == 3) {
    FUN_800158a8(param_1,param_2);
    return;
  }
  if (unaff_D7w < 4) {
    if (unaff_D7w == 1) {
      FUN_800145a6(param_1,param_2);
      return;
    }
    if (unaff_D7w == 2) {
      FUN_80013150(param_1,param_2);
      return;
    }
  }
  else if ((unaff_D7w == 0x81) || (unaff_D7w == 0x83)) {
    FUN_80014eec(param_1,param_2);
    return;
  }
  FUN_80015afc(param_1,0xfffffff6);
  return;
}


// ==== FUN_800116c2 @ 800116c2

/* WARNING: Removing unreachable block (ram,0x80011722) */
/* WARNING: Removing unreachable block (ram,0x80011728) */
/* WARNING: Removing unreachable block (ram,0x8001172e) */
/* WARNING: Removing unreachable block (ram,0x80011734) */
/* WARNING: Removing unreachable block (ram,0x8001173a) */
/* WARNING: Removing unreachable block (ram,0x80011740) */
/* WARNING: Removing unreachable block (ram,0x80011746) */
/* WARNING: Removing unreachable block (ram,0x8001174c) */
/* WARNING: Removing unreachable block (ram,0x80011752) */
/* WARNING: Removing unreachable block (ram,0x80011758) */
/* WARNING: Removing unreachable block (ram,0x8001175e) */
/* WARNING: Removing unreachable block (ram,0x80011764) */
/* WARNING: Removing unreachable block (ram,0x8001176a) */
/* WARNING: Removing unreachable block (ram,0x80011772) */
/* WARNING: Removing unreachable block (ram,0x8001177a) */
/* WARNING: Removing unreachable block (ram,0x80011796) */
/* WARNING: Removing unreachable block (ram,0x8001179c) */
/* WARNING: Removing unreachable block (ram,0x800117a2) */
/* WARNING: Removing unreachable block (ram,0x800117a8) */
/* WARNING: Removing unreachable block (ram,0x800117ae) */
/* WARNING: Removing unreachable block (ram,0x800117b4) */
/* WARNING: Removing unreachable block (ram,0x800117ba) */
/* WARNING: Removing unreachable block (ram,0x800117c0) */
/* WARNING: Removing unreachable block (ram,0x800117c6) */
/* WARNING: Removing unreachable block (ram,0x800117cc) */
/* WARNING: Removing unreachable block (ram,0x800117d2) */
/* WARNING: Removing unreachable block (ram,0x800117d8) */
/* WARNING: Removing unreachable block (ram,0x800117de) */
/* WARNING: Removing unreachable block (ram,0x800117e4) */
/* WARNING: Removing unreachable block (ram,0x800117ec) */

void FUN_800116c2(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5,undefined4 param_6)

{
  uint uVar1;
  uint unaff_D7;
  
  FUN_80015ca0(param_1);
  FUN_80015ca0(param_3);
  FUN_80016254(param_2);
  if ((unaff_D7 == 0) || (FUN_80016254(param_4), unaff_D7 == 0)) {
    FUN_80015afc(param_1,0xfffffff6);
    return;
  }
  uVar1 = unaff_D7 & 0xffff;
  if (uVar1 == 3) {
    FUN_800157f4(param_1,param_2,param_3,param_4,param_5);
    return;
  }
  if (uVar1 < 4) {
    if (uVar1 == 1) {
      FUN_800145cc(param_1,param_2,param_3,param_4,param_5);
      return;
    }
    if (uVar1 == 2) {
      FUN_80013172(param_1,param_2,param_3,param_4,param_5);
      return;
    }
  }
  else {
    if (uVar1 == 0x81) {
LAB_8001186a:
      FUN_80014f66(param_1,param_2,param_3,param_4,param_5);
      return;
    }
    if (uVar1 < 0x82) {
      if (uVar1 == 6) {
        FUN_80016b46(param_6,param_2,param_4,param_5);
        return;
      }
    }
    else if (uVar1 == 0x83) goto LAB_8001186a;
  }
  FUN_80015afc(param_1,0xfffffff6);
  return;
}


// ==== FUN_800118c6 @ 800118c6

void FUN_800118c6(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  FUN_80016b46(param_1,param_2,param_3,param_4);
  return;
}


// ==== FUN_800118e4 @ 800118e4

void FUN_800118e4(undefined4 param_1,undefined4 param_2)

{
  ushort unaff_D7w;
  
  FUN_80015ca0(param_1);
  if (unaff_D7w == 3) {
    FUN_800159b0(param_1,param_2);
  }
  else if (unaff_D7w < 4) {
    if (unaff_D7w == 1) {
      FUN_800141ae(param_1,param_2);
    }
    else {
      if (unaff_D7w != 2) {
        return;
      }
      FUN_800133d0(param_1,param_2);
    }
  }
  else {
    if ((unaff_D7w != 0x81) && (unaff_D7w != 0x83)) {
      return;
    }
    FUN_800150cc(param_1,param_2);
  }
  FUN_80015b1a();
  return;
}


// ==== FUN_80011998 @ 80011998

void FUN_80011998(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5,undefined4 param_6,undefined4 param_7)

{
  ushort unaff_D7w;
  
  FUN_80015ca0(param_1);
  if (unaff_D7w == 3) {
    FUN_800158e8(param_1,param_2,param_3,param_4,param_5,param_6,param_7);
  }
  else if (unaff_D7w < 4) {
    if (unaff_D7w == 1) {
      FUN_8001411e(param_1,param_2,param_3,param_4,param_5,param_6,param_7);
    }
    else {
      if (unaff_D7w != 2) {
        return;
      }
      FUN_800133f2(param_1,param_2,param_3,param_4,param_5,param_6,param_7);
    }
  }
  else {
    if ((unaff_D7w != 0x81) && (unaff_D7w != 0x83)) {
      return;
    }
    FUN_80014ff0(param_1,param_2,param_3,param_4,param_5,param_6,param_7);
  }
  FUN_80015b1a();
  return;
}


// ==== FUN_80011a70 @ 80011a70

void FUN_80011a70(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5,undefined4 param_6,undefined4 param_7)

{
  ushort unaff_D7w;
  
  FUN_80015ca0(param_1);
  if (unaff_D7w == 3) {
    FUN_8001594c(param_1,param_2,param_3,param_4,param_5,param_6,param_7);
  }
  else if (unaff_D7w < 4) {
    if (unaff_D7w == 1) {
      FUN_80014166(param_1,param_2,param_3,param_4,param_5,param_6,param_7);
    }
    else {
      if (unaff_D7w != 2) {
        return;
      }
      FUN_80013432(param_1,param_2,param_3,param_4,param_5,param_6,param_7);
    }
  }
  else {
    if ((unaff_D7w != 0x81) && (unaff_D7w != 0x83)) {
      return;
    }
    FUN_8001505e(param_1,param_2,param_3,param_4,param_5,param_6,param_7);
  }
  FUN_80015b1a();
  return;
}


// ==== FUN_80011b48 @ 80011b48

void FUN_80011b48(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  short unaff_D7w;
  
  FUN_80015ca0(param_1);
  if (unaff_D7w == 2) {
    FUN_800132c0(param_1,param_2,param_3);
  }
  else if (unaff_D7w == 6) {
    FUN_80016a10(param_4,param_2,param_3);
  }
  else {
    FUN_80015afc(param_1,0xfffffff6);
  }
  return;
}


// ==== FUN_80011bae @ 80011bae

void FUN_80011bae(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  short unaff_D7w;
  
  FUN_80015ca0(param_1);
  if (unaff_D7w == 2) {
    FUN_800132e8(param_1,param_2,param_3);
  }
  else if (unaff_D7w == 6) {
    FUN_80016a38(param_4,param_2,param_3);
  }
  else {
    FUN_80015afc(param_1,0xfffffff6);
  }
  return;
}


// ==== FUN_80011c14 @ 80011c14

void FUN_80011c14(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  short unaff_D7w;
  
  FUN_80015ca0(param_1);
  if (unaff_D7w == 2) {
    FUN_80013310(param_1,param_2,param_3);
  }
  else if (unaff_D7w == 6) {
    FUN_80016a60(param_4,param_2,param_3);
  }
  else {
    FUN_80015afc(param_1,0xfffffff6);
  }
  return;
}


// ==== FUN_80011c7a @ 80011c7a

void FUN_80011c7a(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  short unaff_D7w;
  
  FUN_80015ca0(param_1);
  if (unaff_D7w == 2) {
    FUN_80013338(param_1,param_2,param_3);
  }
  else if (unaff_D7w == 6) {
    FUN_80016a88(param_4,param_2,param_3);
  }
  else {
    FUN_80015afc(param_1,0xfffffff6);
  }
  return;
}


// ==== FUN_80011ce0 @ 80011ce0

void FUN_80011ce0(undefined4 param_1,undefined2 param_2,undefined2 param_3,undefined4 param_4,
                 undefined4 param_5,undefined4 param_6)

{
  short unaff_D7w;
  
  FUN_80015ca0(param_1);
  if (unaff_D7w == 2) {
    FUN_80013360(param_1,param_2,param_3,param_4,param_5);
  }
  else if (unaff_D7w == 6) {
    FUN_8001690a(param_6,param_4,param_2,param_3,0x80000000,param_5);
  }
  else {
    FUN_80015afc(param_1,0xfffffff6);
  }
  return;
}


// ==== FUN_80011d6c @ 80011d6c

void FUN_80011d6c(uint param_1,uint param_2,ushort *param_3,ushort *param_4,undefined4 param_5)

{
  int unaff_D7;
  short sVar1;
  undefined1 auStack_38 [6];
  ushort local_32;
  undefined1 auStack_1e [6];
  ushort local_18;
  
  FUN_80015ca0(param_1);
  sVar1 = (short)unaff_D7;
  FUN_80015ca0(param_2);
  if (sVar1 == 0x83) {
    FUN_80014a00(param_1,auStack_1e,param_5);
  }
  else if (sVar1 == 3) {
    FUN_8001548c(param_1,auStack_1e,param_5);
  }
  else {
    FUN_80015afc(param_1 & 0xff,0xfffffff6);
  }
  FUN_80012228();
  if (-1 < unaff_D7) {
    *param_3 = local_18;
  }
  FUN_80012228();
  if (-1 < unaff_D7) {
    if (sVar1 == 0x83) {
      FUN_80014a00(param_2,auStack_38,param_5);
    }
    else if (sVar1 == 3) {
      FUN_8001548c(param_2,auStack_38,param_5);
    }
    else {
      FUN_80015afc(param_2 & 0xff,0xfffffff6);
    }
    FUN_80012228();
    if ((-1 < unaff_D7) && (*param_4 = local_32, *param_4 < *param_3)) {
      FUN_80015afc(param_2 & 0xff,0xffffffe9);
    }
  }
  return;
}


// ==== FUN_80011e86 @ 80011e86

void FUN_80011e86(uint param_1,undefined4 param_2,uint param_3,undefined4 param_4,undefined4 param_5
                 ,uint param_6)

{
  uint uVar1;
  uint uVar2;
  undefined *puVar3;
  int iVar4;
  undefined4 uVar5;
  undefined *unaff_D7;
  int iVar6;
  undefined1 local_10 [4];
  short sVar7;
  
  FUN_80015ca0(param_1);
  uVar2 = (uint)unaff_D7 & 0xffff;
  FUN_80015ca0(param_3);
  if (uVar2 == 3) {
    iVar6 = 1;
  }
  else {
    uVar1 = param_1;
    if (uVar2 < 4) {
      if (uVar2 == 1) {
        iVar6 = 2;
      }
      else {
        if (uVar2 != 2) goto LAB_80011f5e;
        iVar6 = 3;
      }
    }
    else {
      if (uVar2 != 0x81) {
        if (uVar2 < 0x82) {
          if (uVar2 != 6) goto LAB_80011f5e;
          iVar6 = 4;
          param_1 = param_6;
          goto LAB_80011f08;
        }
        if (uVar2 != 0x83) goto LAB_80011f5e;
      }
      iVar6 = 0;
    }
  }
LAB_80011f08:
  uVar2 = (uint)unaff_D7 & 0xffff;
  if (uVar2 == 3) {
    iVar4 = 1;
  }
  else {
    uVar1 = param_3;
    if (uVar2 < 4) {
      if (uVar2 == 1) {
        iVar4 = 2;
      }
      else {
        if (uVar2 != 2) goto LAB_80011f5e;
        iVar4 = 3;
      }
    }
    else {
      if (uVar2 != 0x81) {
        if (uVar2 < 0x82) {
          if (uVar2 == 6) {
            iVar4 = 4;
            param_3 = param_6;
            goto LAB_80011f6a;
          }
LAB_80011f5e:
          FUN_80015afc(uVar1 & 0xff,0xfffffff6);
          return;
        }
        if (uVar2 != 0x83) goto LAB_80011f5e;
      }
      iVar4 = 0;
    }
  }
LAB_80011f6a:
  (*(code *)(&PTR_FUN_90006298)[iVar6])(param_1,param_2,0,param_5);
  FUN_80012228();
  if (-1 < (int)unaff_D7) {
    sVar7 = (short)unaff_D7;
    if (iVar4 == 4) {
      (*(code *)PTR_FUN_900062a8)(param_3,param_4,1,param_5);
    }
    else {
      (*(code *)(&PTR_FUN_900062fc)[iVar4])(param_3,param_5);
      (*(code *)(&PTR_FUN_900062ac)[iVar4])(param_3,param_4);
    }
    FUN_80012228(unaff_D7);
    if ((int)unaff_D7 < 0) {
      (*(code *)(&PTR_FUN_900062e8)[iVar6])((int)sVar7,param_5);
    }
    else {
      FUN_8001379e(0x1400);
      if (unaff_D7 == (undefined *)0x0) {
        uVar5 = 0x200;
        puVar3 = &DAT_900101d4;
      }
      else {
        uVar5 = 0x1400;
        puVar3 = unaff_D7;
      }
      do {
        (*(code *)(&PTR_FUN_900062c0)[iVar6])((int)sVar7,uVar5,puVar3,param_5);
        FUN_80012228();
        if ((int)unaff_D7 < 0) {
          if (((short)((uint)unaff_D7 >> 0x10) == -0xc) || (unaff_D7 == (undefined *)0xffffff13)) {
            FUN_80015afc(param_3 & 0xff,0);
          }
          break;
        }
        (*(code *)(&PTR_FUN_900062d4)[iVar4])((int)sVar7,unaff_D7,puVar3,param_5);
        FUN_80012228();
      } while (-1 < (int)unaff_D7);
      (*(code *)(&PTR_FUN_900062e8)[iVar6])((int)sVar7,param_5);
      (*(code *)(&PTR_FUN_900062e8)[iVar4])((int)sVar7,param_5);
      if (-1 < (int)unaff_D7) {
        FUN_80015e48(local_10 + 8,local_10 + 4,4);
      }
      FUN_80012774(puVar3);
    }
  }
  return;
}


// ==== FUN_8001213c @ 8001213c

/* WARNING: Removing unreachable block (ram,0x80012198) */
/* WARNING: Removing unreachable block (ram,0x800121c0) */
/* WARNING: Removing unreachable block (ram,0x800121f4) */

void FUN_8001213c(uint param_1,undefined4 param_2,uint param_3,undefined4 param_4,undefined4 param_5
                 ,undefined4 param_6)

{
  if (param_3 == param_1) {
    FUN_80015afc(param_3 & 0xff,0xfffffff6);
  }
  else {
    FUN_80015ca0(param_1);
    FUN_80015ca0(param_3);
    FUN_80011e86(param_1,param_2,param_3,param_4,param_5,param_6);
    FUN_80012228();
  }
  return;
}


// ==== FUN_80012228 @ 80012228

undefined4 FUN_80012228(int param_1)

{
  undefined4 uVar1;
  
  if (param_1 < 0) {
    uVar1 = 0xffffffff;
  }
  else {
    uVar1 = 0;
  }
  return uVar1;
}


// ==== FUN_80012242 @ 80012242

void FUN_80012242(short param_1,ushort param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5,undefined4 param_6,undefined4 param_7)

{
  ushort uVar1;
  int unaff_D7;
  short sVar2;
  
  FUN_80015ca0(param_3);
  sVar2 = (short)unaff_D7;
  FUN_80015ca0(param_5);
  if (sVar2 == 0x83) {
    FUN_80014a50(param_3,param_4,param_7);
  }
  else {
    FUN_800154d2(param_3,param_4,param_7);
  }
  FUN_80012228();
  if (-1 < unaff_D7) {
    FUN_80016134(&DAT_900101d4,param_2,0);
    uVar1 = param_2;
    if (0x28 < param_2) {
      uVar1 = 0x28;
    }
    FUN_80016134(&DAT_900101d4,uVar1,0x20);
    if (param_1 != 0) {
      if (sVar2 == 0x83) {
        FUN_80014b18(param_3);
      }
      else {
        FUN_8001557c(param_3);
      }
    }
  }
  FUN_80012228();
  if (-1 < unaff_D7) {
    if (sVar2 == 0x83) {
      FUN_80014a50(param_5,param_6,param_7);
    }
    else {
      FUN_800154d2(param_5,param_6,param_7);
    }
  }
  FUN_80012228();
  if ((-1 < unaff_D7) && (param_2 != 0)) {
    if (sVar2 == 0x83) {
      FUN_80014b8e(param_5);
    }
    else {
      FUN_800155e4(param_5);
    }
  }
  return;
}


// ==== FUN_800123c4 @ 800123c4

/* WARNING: Removing unreachable block (ram,0x80012576) */
/* WARNING: Removing unreachable block (ram,0x8001257c) */
/* WARNING: Removing unreachable block (ram,0x80012582) */
/* WARNING: Removing unreachable block (ram,0x800125aa) */
/* WARNING: Removing unreachable block (ram,0x800125c4) */
/* WARNING: Removing unreachable block (ram,0x800125e4) */
/* WARNING: Removing unreachable block (ram,0x800125e8) */
/* WARNING: Removing unreachable block (ram,0x8001262a) */
/* WARNING: Removing unreachable block (ram,0x8001261c) */
/* WARNING: Removing unreachable block (ram,0x8001262c) */
/* WARNING: Removing unreachable block (ram,0x80012636) */
/* WARNING: Removing unreachable block (ram,0x80012640) */
/* WARNING: Removing unreachable block (ram,0x8001264e) */
/* WARNING: Removing unreachable block (ram,0x80012650) */
/* WARNING: Removing unreachable block (ram,0x80012696) */
/* WARNING: Removing unreachable block (ram,0x8001269e) */
/* WARNING: Removing unreachable block (ram,0x800126e6) */
/* WARNING: Removing unreachable block (ram,0x800126ec) */
/* WARNING: Removing unreachable block (ram,0x800126f6) */
/* WARNING: Removing unreachable block (ram,0x800126fa) */
/* WARNING: Removing unreachable block (ram,0x80012704) */
/* WARNING: Removing unreachable block (ram,0x8001270c) */
/* WARNING: Removing unreachable block (ram,0x80012716) */
/* WARNING: Removing unreachable block (ram,0x8001271e) */
/* WARNING: Removing unreachable block (ram,0x80012728) */
/* WARNING: Removing unreachable block (ram,0x80012758) */
/* WARNING: Removing unreachable block (ram,0x8001274e) */
/* WARNING: Removing unreachable block (ram,0x8001258e) */
/* WARNING: Recovered jumptable eliminated as dead code */

void FUN_800123c4(uint param_1,uint param_2,undefined4 param_3)

{
  ushort unaff_D7w;
  
  FUN_80015ca0(param_1);
  FUN_80015ca0(param_2);
  if (unaff_D7w == 3) {
    FUN_800159b0(param_1,param_3);
  }
  else if (unaff_D7w < 4) {
    if (unaff_D7w != 1) goto LAB_8001248c;
    FUN_800141ae(param_1,param_3);
  }
  else {
    if ((unaff_D7w != 0x81) && (unaff_D7w != 0x83)) {
LAB_8001248c:
      param_1 = param_1 & 0xff;
      goto LAB_80012762;
    }
    FUN_800150cc(param_1,param_3);
  }
  if (unaff_D7w == 3) {
    FUN_800159b0(param_2,param_3);
LAB_8001259c:
    param_1 = param_1 & 0xff;
  }
  else {
    if (unaff_D7w < 4) {
      if (unaff_D7w == 1) {
        FUN_800141ae(param_2,param_3);
        goto LAB_8001259c;
      }
    }
    else if ((unaff_D7w == 0x81) || (unaff_D7w == 0x83)) {
      FUN_800150cc(param_2,param_3);
      goto LAB_8001259c;
    }
    param_1 = param_2 & 0xff;
  }
LAB_80012762:
  FUN_80015afc(param_1,0xfffffff6);
  return;
}


// ==== FUN_80012774 @ 80012774

void FUN_80012774(undefined *param_1)

{
  if (param_1 != &DAT_900101d4) {
    FUN_800137b4(param_1);
  }
  return;
}


// ==== FUN_80012790 @ 80012790

void FUN_80012790(undefined4 param_1,undefined4 param_2)

{
  ushort unaff_D7w;
  
  FUN_80015ca0(param_1);
  if (unaff_D7w == 3) {
    FUN_8001544c(param_1,param_2);
  }
  else if (unaff_D7w < 4) {
    if (unaff_D7w == 1) {
      FUN_800143c8(param_1,param_2);
    }
  }
  else if ((unaff_D7w == 0x81) || (unaff_D7w == 0x83)) {
    FUN_800149b2(param_1,param_2);
  }
  return;
}


// ==== FUN_800127fc @ 800127fc

uint FUN_800127fc(undefined1 param_1,uint param_2,char param_3)

{
  byte bVar1;
  uint uVar2;
  int iVar3;
  
  iVar3 = 0;
  if (param_2 == 0) {
    uVar2 = FUN_80015afc(param_1,0);
  }
  else {
    uVar2 = param_2 & 0x7c000000;
    if (uVar2 == 0) {
      if (param_3 == '\0') {
        if ((param_2 & 0x8989) != 0) {
          uVar2 = param_2 & 0x8900;
          do {
            if ((param_2 & 1 << (uVar2 & 0x1f)) != 0) {
              switch(uVar2 & 0xff) {
              case 0:
              case 8:
                iVar3 = -8;
                break;
              case 3:
              case 0xb:
                iVar3 = -5;
                break;
              case 7:
              case 0xf:
                iVar3 = -4;
                break;
              case 0x12:
                iVar3 = -0x2d;
              }
              if (iVar3 != 0) {
                return uVar2;
              }
            }
            bVar1 = (char)uVar2 + 1;
            uVar2 = CONCAT31((int3)(uVar2 >> 8),bVar1);
            if (0x1f < bVar1) {
              return uVar2;
            }
          } while( true );
        }
      }
      else if ((param_2 & 0x8989) != 0) {
        uVar2 = param_2 & 0x8900;
        do {
          if ((param_2 & 1 << (uVar2 & 0x1f)) != 0) {
            switch(uVar2 & 0xff) {
            case 0:
            case 8:
              iVar3 = -8;
              break;
            case 3:
            case 0xb:
              iVar3 = -5;
              break;
            case 6:
            case 0xe:
              iVar3 = -0x2e;
              break;
            case 7:
            case 0xf:
              iVar3 = -4;
              break;
            case 0x12:
              iVar3 = -0x2d;
            }
            if (iVar3 != 0) {
              return uVar2;
            }
          }
          bVar1 = (char)uVar2 + 1;
          uVar2 = CONCAT31((int3)(uVar2 >> 8),bVar1);
          if (0xf < bVar1) {
            return uVar2;
          }
        } while( true );
      }
      uVar2 = param_2 & 0x8989;
    }
  }
  return uVar2;
}


// ==== FUN_80012924 @ 80012924

void FUN_80012924(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5,undefined4 param_6)

{
  uint uVar1;
  uint unaff_D5;
  uint unaff_D7;
  short sVar2;
  
  FUN_80015ca0(param_1);
  sVar2 = (short)unaff_D7;
  uVar1 = unaff_D7 & 0xffff;
  if (uVar1 == 6) {
    FUN_800167a6(param_6,param_2,0,param_5);
  }
  else if (uVar1 < 7) {
    if (uVar1 != 1) goto LAB_800129a2;
    FUN_80014226(param_1,param_2,0,param_5);
  }
  else {
    if (uVar1 != 0x81) goto LAB_800129a2;
    FUN_80014776(param_1,param_2,0,param_5);
  }
  unaff_D5 = unaff_D7;
LAB_800129a2:
  FUN_80015b1a(unaff_D5);
  if (-1 < (int)unaff_D7) {
    FUN_80015ca0(param_3);
    if (sVar2 == 6) {
      FUN_800167a6(param_6,param_4,1,param_5);
    }
    else {
      FUN_80012dd8(param_3,param_4,0x800,1,param_5);
      FUN_80015b1a();
      if (unaff_D7 == 0xffffffff) {
        FUN_80012e1c(param_3,param_4,1,param_5);
      }
    }
    FUN_80015b1a();
    if ((-1 < (int)unaff_D7) && (-1 < (int)unaff_D7)) {
      if (sVar2 == 6) {
        FUN_80012b5a(6,6,unaff_D7 & 0xffff,unaff_D7 & 0xffff,param_5);
        FUN_80015b1a();
        FUN_800167d6(6,param_5);
      }
      else {
        if (sVar2 != 6) {
          FUN_80012c78(param_1,param_2,param_3,param_4,unaff_D7 & 0xffff,param_5);
        }
        FUN_80012b5a((int)sVar2,(int)sVar2,unaff_D7 & 0xffff,unaff_D7 & 0xffff,param_5);
        FUN_80015b1a();
        FUN_80012e5a((int)sVar2,param_5);
      }
      FUN_80015b1a();
    }
    uVar1 = unaff_D7 & 0xffff;
    if (uVar1 == 6) {
      FUN_800167d6(param_6,param_5);
    }
    else if (uVar1 < 7) {
      if (uVar1 == 1) {
        FUN_80014268((int)sVar2,param_5);
      }
    }
    else if (uVar1 == 0x81) {
      FUN_80014620((int)sVar2,param_5);
    }
  }
  return;
}


// ==== FUN_80012b5a @ 80012b5a

void FUN_80012b5a(short param_1,short param_2,ushort param_3,short param_4,undefined4 param_5)

{
  undefined1 *puVar1;
  undefined1 *unaff_D4;
  undefined1 *unaff_D7;
  uint uVar2;
  int iVar3;
  undefined1 auStack_204 [512];
  
  uVar2 = 0x1000;
  do {
    FUN_8001379e(uVar2);
    if (unaff_D7 != (undefined1 *)0x0) break;
    uVar2 = (int)uVar2 >> 1;
  } while (0x200 < uVar2);
  puVar1 = unaff_D7;
  if (unaff_D7 == (undefined1 *)0x0) {
    puVar1 = auStack_204;
  }
  iVar3 = (int)param_1;
  do {
    if (param_3 == 6) {
      FUN_80016804(iVar3,uVar2,puVar1,param_5);
LAB_80012c04:
      unaff_D4 = unaff_D7;
    }
    else if (param_3 < 7) {
      if (param_3 == 1) {
        FUN_8001428c(iVar3,uVar2,puVar1,param_5);
        goto LAB_80012c04;
      }
    }
    else if (param_3 == 0x81) {
      FUN_80014664(iVar3,uVar2,puVar1,param_5);
      goto LAB_80012c04;
    }
    FUN_80015b1a(unaff_D4);
    if ((int)unaff_D7 < 1) break;
    if (param_4 == 6) {
      FUN_80016892((int)param_2);
    }
    else {
      FUN_80012eae((int)param_2);
    }
    FUN_80015b1a();
    unaff_D4 = unaff_D7;
  } while (-1 < (int)unaff_D7);
  if (unaff_D7 != (undefined1 *)0x0) {
    FUN_800137b4(puVar1);
  }
  return;
}


// ==== FUN_80012c78 @ 80012c78

void FUN_80012c78(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                 short param_5,undefined4 param_6)

{
  uint unaff_D3;
  uint unaff_D7;
  undefined1 auStack_2c [40];
  
  if (param_5 == 1) {
    FUN_8001441a(param_1,param_2,param_6);
LAB_80012cc6:
    unaff_D3 = unaff_D7;
  }
  else if (param_5 == 0x81) {
    FUN_80014a50(param_1,param_2,param_6);
    goto LAB_80012cc6;
  }
  FUN_80015b1a(unaff_D3);
  if ((int)unaff_D7 < 1) {
    return;
  }
  if (param_5 == 1) {
    FUN_80013d30(param_1,unaff_D7 & 0xffff,unaff_D7 & 0xffff,0x28,auStack_2c,param_6);
  }
  else {
    if (param_5 != 0x81) goto LAB_80012d28;
    FUN_80014b18(param_1,unaff_D7 & 0xffff,unaff_D7 & 0xffff,0x28,auStack_2c,param_6);
  }
  unaff_D3 = unaff_D7;
LAB_80012d28:
  FUN_80015b1a(unaff_D3);
  if (-1 < (int)unaff_D7) {
    FUN_80012ffa(param_3,param_4,param_6);
    FUN_80015b1a();
    if (-1 < (int)unaff_D7) {
      FUN_80013282(param_3,unaff_D7 & 0xffff,unaff_D7 & 0xffff,0x28,auStack_2c,param_6);
    }
  }
  return;
}


// ==== FUN_80012d7c @ 80012d7c

void FUN_80012d7c(int param_1,undefined4 *param_2)

{
  undefined4 unaff_D7;
  undefined4 local_8;
  
  *(char *)(param_1 + 3) = *(char *)(param_1 + 3) + -6;
  *(char *)(param_1 + 4) = *(char *)(param_1 + 4) + -6;
  *(undefined4 **)(param_1 + 0x28) = &local_8;
  FUN_800136c0(0x2c,9,param_1,0x10);
  *param_2 = unaff_D7;
  FUN_80015b1a(local_8);
  return;
}


// ==== FUN_80012dd8 @ 80012dd8

void FUN_80012dd8(undefined1 param_1,undefined4 param_2,undefined4 param_3,undefined2 param_4,
                 undefined4 param_5)

{
  undefined1 auStack_30 [2];
  undefined1 local_2e;
  undefined1 local_2d;
  undefined1 auStack_2b [23];
  undefined2 local_14;
  undefined4 local_10;
  
  local_2e = 0x13;
  local_2d = param_1;
  FUN_80015bac(param_2,auStack_2b);
  local_10 = param_3;
  local_14 = param_4;
  FUN_80012d7c(auStack_30,param_5);
  return;
}


// ==== FUN_80012e1c @ 80012e1c

void FUN_80012e1c(undefined1 param_1,undefined4 param_2,undefined2 param_3,undefined4 param_4)

{
  undefined1 auStack_30 [2];
  undefined1 local_2e;
  undefined1 local_2d;
  undefined1 auStack_2b [23];
  undefined2 local_14;
  
  local_2e = 0x11;
  local_2d = param_1;
  FUN_80015bac(param_2,auStack_2b);
  local_14 = param_3;
  FUN_80012d7c(auStack_30,param_4);
  return;
}


// ==== FUN_80012e5a @ 80012e5a

void FUN_80012e5a(undefined2 param_1,undefined4 param_2)

{
  undefined2 local_30;
  undefined1 local_2e;
  
  local_2e = 0x12;
  local_30 = param_1;
  FUN_80012d7c(&local_30,param_2);
  return;
}


// ==== FUN_80012e7e @ 80012e7e

void FUN_80012e7e(undefined2 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  undefined2 local_30;
  undefined1 local_2e;
  undefined4 local_10;
  undefined4 local_c;
  
  local_2e = 0x21;
  local_30 = param_1;
  local_10 = param_2;
  local_c = param_3;
  FUN_80012d7c(&local_30,param_4);
  return;
}


// ==== FUN_80012eae @ 80012eae

void FUN_80012eae(undefined2 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  undefined2 local_30;
  undefined1 local_2e;
  undefined4 local_10;
  undefined4 local_c;
  
  local_2e = 0x22;
  local_30 = param_1;
  local_10 = param_2;
  local_c = param_3;
  FUN_80012d7c(&local_30,param_4);
  return;
}


// ==== FUN_80012ede @ 80012ede

void FUN_80012ede(undefined2 param_1,undefined2 param_2,undefined4 param_3,undefined4 param_4)

{
  undefined2 local_30;
  undefined1 local_2e;
  undefined2 local_14;
  undefined4 local_10;
  
  local_2e = 0x23;
  local_30 = param_1;
  local_10 = param_3;
  local_14 = param_2;
  FUN_80012d7c(&local_30,param_4);
  return;
}


// ==== FUN_80012f0e @ 80012f0e

void FUN_80012f0e(undefined1 param_1,undefined4 param_2,undefined4 param_3)

{
  undefined1 auStack_30 [2];
  undefined1 local_2e;
  undefined1 local_2d;
  undefined1 auStack_2b [39];
  
  local_2e = 0x15;
  local_2d = param_1;
  FUN_80015bac(param_2,auStack_2b);
  FUN_80012d7c(auStack_30,param_3);
  return;
}


// ==== FUN_80012f46 @ 80012f46

void FUN_80012f46(undefined1 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  undefined1 auStack_30 [2];
  undefined1 local_2e;
  undefined1 local_2d;
  undefined1 auStack_2b [11];
  undefined1 auStack_20 [28];
  
  local_2e = 0x14;
  local_2d = param_1;
  FUN_80015bac(param_2,auStack_2b);
  FUN_80015bac(param_3,auStack_20);
  FUN_80012d7c(auStack_30,param_4);
  return;
}


// ==== FUN_80012f8e @ 80012f8e

void FUN_80012f8e(undefined1 param_1,undefined4 param_2)

{
  undefined1 auStack_30 [2];
  undefined1 local_2e;
  undefined1 local_2d;
  
  local_2e = 1;
  local_2d = param_1;
  FUN_80012d7c(auStack_30,param_2);
  return;
}


// ==== FUN_80012fb0 @ 80012fb0

void FUN_80012fb0(undefined1 param_1,undefined4 param_2)

{
  undefined1 auStack_30 [2];
  undefined1 local_2e;
  undefined1 local_2d;
  
  local_2e = 4;
  local_2d = param_1;
  FUN_80012d7c(auStack_30,param_2);
  return;
}


// ==== FUN_80012fd2 @ 80012fd2

void FUN_80012fd2(undefined1 param_1,undefined4 param_2,undefined4 param_3)

{
  undefined1 auStack_30 [2];
  undefined1 local_2e;
  undefined1 local_2d;
  undefined4 local_c;
  
  local_2e = 2;
  local_2d = param_1;
  local_c = param_2;
  FUN_80012d7c(auStack_30,param_3);
  return;
}


// ==== FUN_80012ffa @ 80012ffa

void FUN_80012ffa(undefined1 param_1,undefined4 param_2,undefined4 param_3)

{
  undefined1 auStack_30 [2];
  undefined1 local_2e;
  undefined1 local_2d;
  undefined1 auStack_2b [39];
  
  local_2e = 8;
  local_2d = param_1;
  FUN_80015bac(param_2,auStack_2b);
  FUN_80012d7c(auStack_30,param_3);
  return;
}


// ==== FUN_80013032 @ 80013032

void FUN_80013032(undefined1 param_1,undefined4 param_2)

{
  undefined1 auStack_30 [2];
  undefined1 local_2e;
  undefined1 local_2d;
  
  local_2e = 0x3a;
  local_2d = param_1;
  FUN_80012d7c(auStack_30,param_2);
  return;
}


// ==== FUN_80013054 @ 80013054

void FUN_80013054(undefined1 param_1,undefined4 param_2)

{
  undefined1 auStack_30 [2];
  undefined1 local_2e;
  undefined1 local_2d;
  
  local_2e = 0x3b;
  local_2d = param_1;
  FUN_80012d7c(auStack_30,param_2);
  return;
}


// ==== FUN_80013076 @ 80013076

void FUN_80013076(undefined1 param_1,undefined4 param_2,undefined4 param_3)

{
  undefined1 auStack_30 [2];
  undefined1 local_2e;
  undefined1 local_2d;
  undefined4 local_c;
  
  local_2e = 0xb;
  local_2d = param_1;
  local_c = param_2;
  FUN_80012d7c(auStack_30,param_3);
  return;
}


// ==== FUN_8001309e @ 8001309e

void FUN_8001309e(undefined1 param_1,undefined4 param_2,undefined4 param_3)

{
  undefined1 auStack_30 [2];
  undefined1 local_2e;
  undefined1 local_2d;
  undefined4 local_c;
  
  local_2e = 0xc;
  local_2d = param_1;
  local_c = param_2;
  FUN_80012d7c(auStack_30,param_3);
  return;
}


// ==== FUN_800130c6 @ 800130c6

void FUN_800130c6(undefined1 param_1,undefined4 param_2)

{
  undefined1 auStack_30 [2];
  undefined1 local_2e;
  undefined1 local_2d;
  
  local_2e = 3;
  local_2d = param_1;
  FUN_80012d7c(auStack_30,param_2);
  return;
}


// ==== FUN_800130e8 @ 800130e8

void FUN_800130e8(undefined1 param_1,byte param_2,byte param_3,undefined4 param_4,undefined4 param_5
                 )

{
  undefined1 auStack_30 [2];
  undefined1 local_2e;
  undefined1 local_2d;
  ushort local_14;
  ushort local_12;
  undefined4 local_c;
  
  local_2e = 0x30;
  local_2d = param_1;
  local_14 = (ushort)param_2;
  local_12 = (ushort)param_3;
  local_c = param_4;
  FUN_80012d7c(auStack_30,param_5);
  return;
}


// ==== FUN_80013128 @ 80013128

void FUN_80013128(undefined1 param_1,undefined1 param_2,undefined4 param_3)

{
  undefined1 auStack_30 [2];
  undefined1 local_2e;
  undefined1 local_2d;
  undefined1 local_2c;
  
  local_2e = 0x31;
  local_2d = param_1;
  local_2c = param_2;
  FUN_80012d7c(auStack_30,param_3);
  return;
}


// ==== FUN_80013150 @ 80013150

void FUN_80013150(undefined1 param_1,undefined4 param_2)

{
  undefined1 auStack_30 [2];
  undefined1 local_2e;
  undefined1 local_2d;
  
  local_2e = 0xf;
  local_2d = param_1;
  FUN_80012d7c(auStack_30,param_2);
  return;
}


// ==== FUN_80013172 @ 80013172

void FUN_80013172(undefined1 param_1,undefined4 param_2,undefined1 param_3,undefined4 param_4,
                 undefined4 param_5)

{
  undefined1 auStack_30 [2];
  undefined1 local_2e;
  undefined1 local_2d;
  undefined1 local_2c;
  undefined1 auStack_2b [11];
  undefined1 auStack_20 [28];
  
  local_2e = 0x32;
  local_2d = param_1;
  FUN_80015bac(param_2,auStack_2b);
  local_2c = param_3;
  FUN_80015bac(param_4,auStack_20);
  FUN_80012d7c(auStack_30,param_5);
  return;
}


// ==== FUN_800131c0 @ 800131c0

void FUN_800131c0(undefined1 param_1,undefined4 param_2,undefined4 param_3)

{
  undefined1 auStack_30 [2];
  undefined1 local_2e;
  undefined1 local_2d;
  undefined1 auStack_2b [39];
  
  local_2e = 0xd;
  local_2d = param_1;
  FUN_80015bac(param_2,auStack_2b);
  FUN_80012d7c(auStack_30,param_3);
  return;
}


// ==== FUN_800131f8 @ 800131f8

void FUN_800131f8(undefined1 param_1,undefined2 param_2,undefined4 param_3)

{
  undefined1 auStack_30 [2];
  undefined1 local_2e;
  undefined1 local_2d;
  undefined2 local_14;
  
  local_2e = 0xe;
  local_2d = param_1;
  local_14 = param_2;
  FUN_80012d7c(auStack_30,param_3);
  return;
}


// ==== FUN_80013222 @ 80013222

void FUN_80013222(undefined1 param_1,undefined4 param_2)

{
  undefined1 auStack_30 [2];
  undefined1 local_2e;
  undefined1 local_2d;
  
  local_2e = 0x18;
  local_2d = param_1;
  FUN_80012d7c(auStack_30,param_2);
  return;
}


// ==== FUN_80013244 @ 80013244

void FUN_80013244(undefined1 param_1,undefined2 param_2,undefined2 param_3,undefined4 param_4,
                 undefined4 param_5,undefined4 param_6)

{
  undefined1 auStack_30 [2];
  undefined1 local_2e;
  undefined1 local_2d;
  undefined2 local_14;
  undefined2 local_12;
  undefined4 local_10;
  undefined4 local_c;
  
  local_2e = 0x19;
  local_2d = param_1;
  local_14 = param_2;
  local_12 = param_3;
  local_10 = param_4;
  local_c = param_5;
  FUN_80012d7c(auStack_30,param_6);
  return;
}


// ==== FUN_80013282 @ 80013282

void FUN_80013282(undefined1 param_1,undefined2 param_2,undefined2 param_3,undefined4 param_4,
                 undefined4 param_5,undefined4 param_6)

{
  undefined1 auStack_30 [2];
  undefined1 local_2e;
  undefined1 local_2d;
  undefined2 local_14;
  undefined2 local_12;
  undefined4 local_10;
  undefined4 local_c;
  
  local_2e = 0x1a;
  local_2d = param_1;
  local_14 = param_2;
  local_12 = param_3;
  local_10 = param_4;
  local_c = param_5;
  FUN_80012d7c(auStack_30,param_6);
  return;
}


// ==== FUN_800132c0 @ 800132c0

void FUN_800132c0(undefined1 param_1,undefined4 param_2,undefined4 param_3)

{
  undefined1 auStack_30 [2];
  undefined1 local_2e;
  undefined1 local_2d;
  undefined4 local_c;
  
  local_2e = 0x43;
  local_2d = param_1;
  local_c = param_2;
  FUN_80012d7c(auStack_30,param_3);
  return;
}


// ==== FUN_800132e8 @ 800132e8

void FUN_800132e8(undefined1 param_1,undefined4 param_2,undefined4 param_3)

{
  undefined1 auStack_30 [2];
  undefined1 local_2e;
  undefined1 local_2d;
  undefined4 local_c;
  
  local_2e = 0x44;
  local_2d = param_1;
  local_c = param_2;
  FUN_80012d7c(auStack_30,param_3);
  return;
}


// ==== FUN_80013310 @ 80013310

void FUN_80013310(undefined1 param_1,undefined4 param_2,undefined4 param_3)

{
  undefined1 auStack_30 [2];
  undefined1 local_2e;
  undefined1 local_2d;
  undefined4 local_c;
  
  local_2e = 0x45;
  local_2d = param_1;
  local_c = param_2;
  FUN_80012d7c(auStack_30,param_3);
  return;
}


// ==== FUN_80013338 @ 80013338

void FUN_80013338(undefined1 param_1,undefined4 param_2,undefined4 param_3)

{
  undefined1 auStack_30 [2];
  undefined1 local_2e;
  undefined1 local_2d;
  undefined4 local_c;
  
  local_2e = 0x46;
  local_2d = param_1;
  local_c = param_2;
  FUN_80012d7c(auStack_30,param_3);
  return;
}


// ==== FUN_80013360 @ 80013360

void FUN_80013360(undefined1 param_1,undefined2 param_2,undefined2 param_3,undefined4 param_4,
                 undefined4 param_5)

{
  undefined1 auStack_30 [2];
  undefined1 local_2e;
  undefined1 local_2d;
  undefined2 local_14;
  undefined2 local_12;
  undefined4 local_c;
  
  local_2e = 0x47;
  local_2d = param_1;
  local_14 = param_2;
  local_12 = param_3;
  local_c = param_4;
  FUN_80012d7c(auStack_30,param_5);
  return;
}


// ==== FUN_80013398 @ 80013398

void FUN_80013398(undefined1 param_1,undefined2 param_2,undefined2 param_3,undefined4 param_4,
                 undefined4 param_5)

{
  undefined1 auStack_30 [2];
  undefined1 local_2e;
  undefined1 local_2d;
  undefined2 local_14;
  undefined2 local_12;
  undefined4 local_c;
  
  local_2e = 9;
  local_2d = param_1;
  local_14 = param_2;
  local_12 = param_3;
  local_c = param_4;
  FUN_80012d7c(auStack_30,param_5);
  return;
}


// ==== FUN_800133d0 @ 800133d0

void FUN_800133d0(undefined1 param_1,undefined4 param_2)

{
  undefined1 auStack_30 [2];
  undefined1 local_2e;
  undefined1 local_2d;
  
  local_2e = 0x40;
  local_2d = param_1;
  FUN_80012d7c(auStack_30,param_2);
  return;
}


// ==== FUN_800133f2 @ 800133f2

void FUN_800133f2(undefined1 param_1,undefined2 param_2,undefined2 param_3,undefined2 param_4,
                 undefined4 param_5,undefined4 param_6,undefined4 param_7)

{
  undefined2 local_30;
  undefined1 local_2e;
  undefined1 local_2d;
  undefined2 local_14;
  undefined2 local_12;
  undefined4 local_10;
  undefined4 local_c;
  
  local_2e = 0x41;
  local_2d = param_1;
  local_30 = param_2;
  local_14 = param_3;
  local_12 = param_4;
  local_10 = param_5;
  local_c = param_6;
  FUN_80012d7c(&local_30,param_7);
  return;
}


// ==== FUN_80013432 @ 80013432

void FUN_80013432(undefined1 param_1,undefined2 param_2,undefined2 param_3,undefined2 param_4,
                 undefined4 param_5,undefined4 param_6,undefined4 param_7)

{
  undefined2 local_30;
  undefined1 local_2e;
  undefined1 local_2d;
  undefined2 local_14;
  undefined2 local_12;
  undefined4 local_10;
  undefined4 local_c;
  
  local_2e = 0x42;
  local_2d = param_1;
  local_30 = param_2;
  local_14 = param_3;
  local_12 = param_4;
  local_10 = param_5;
  local_c = param_6;
  FUN_80012d7c(&local_30,param_7);
  return;
}


// ==== FUN_80013474 @ 80013474

void FUN_80013474(undefined4 param_1)

{
  undefined1 auStack_16 [4];
  undefined1 auStack_12 [8];
  undefined1 *local_a;
  undefined1 local_6;
  
  local_6 = 0;
  local_a = auStack_16;
  FUN_8001366a(auStack_12,param_1);
  return;
}


// ==== FUN_80013498 @ 80013498

void FUN_80013498(undefined4 param_1,short param_2,undefined4 param_3)

{
  undefined1 local_16 [4];
  int local_12;
  undefined4 local_e;
  undefined1 *local_a;
  undefined1 local_6;
  
  local_6 = 1;
  local_e = param_1;
  local_a = local_16;
  local_12 = (int)param_2;
  FUN_8001366a(&local_12,param_3);
  return;
}


// ==== FUN_800134d8 @ 800134d8

void FUN_800134d8(undefined4 param_1,short param_2,undefined4 param_3)

{
  undefined1 auStack_16 [4];
  int local_12;
  undefined4 local_e;
  undefined1 *local_a;
  undefined1 local_6;
  
  local_6 = 2;
  local_e = param_1;
  local_a = auStack_16;
  local_12 = (int)param_2;
  FUN_8001366a(&local_12,param_3);
  return;
}


// ==== FUN_8001350c @ 8001350c

void FUN_8001350c(short param_1,short param_2,undefined4 param_3)

{
  undefined1 auStack_16 [4];
  uint local_12 [2];
  undefined4 local_a;
  undefined1 local_6;
  
  local_6 = 4;
  local_a = param_3;
  if (param_1 == 0) {
    if (param_2 < 0) {
      local_12[0] = 0;
    }
    else {
      local_12[0] = 1;
    }
  }
  else if (param_1 == 1) {
    local_12[0] = 0x104;
  }
  else if (param_1 == 2) {
    if (param_2 < 0) {
      local_12[0] = 2;
    }
    else {
      local_12[0] = 3;
    }
  }
  else {
    local_12[0] = 0x105;
  }
  local_12[0] = local_12[0] | (int)param_2 << 0x10;
  FUN_8001366a(local_12,auStack_16);
  return;
}


// ==== FUN_8001357a @ 8001357a

void FUN_8001357a(int param_1,int param_2,char param_3,undefined4 param_4)

{
  undefined1 auStack_16 [4];
  uint local_12 [2];
  undefined1 *local_a;
  undefined1 local_6;
  
  local_6 = 8;
  local_a = auStack_16;
  if (param_1 == 0x77) {
    local_12[0] = (int)param_3 | 0x770000U | param_2 << 8;
  }
  else {
    local_12[0] = param_2 << 8 | 0x720000;
  }
  FUN_8001366a(local_12,param_4);
  return;
}


// ==== FUN_800135cc @ 800135cc

void FUN_800135cc(int param_1,undefined4 param_2,uint param_3,undefined4 param_4)

{
  undefined1 auStack_16 [4];
  uint local_12;
  undefined4 local_e;
  undefined1 *local_a;
  undefined1 local_6;
  
  if (((int)param_3 < 0x41) && (0 < (int)param_3)) {
    local_6 = 9;
    local_a = auStack_16;
    local_e = param_2;
    local_12 = param_3 | param_1 << 0x10;
    FUN_8001366a(&local_12,param_4);
  }
  return;
}


// ==== FUN_80013616 @ 80013616

void FUN_80013616(undefined4 param_1,undefined4 param_2)

{
  undefined1 auStack_16 [4];
  undefined4 local_12 [2];
  undefined1 *local_a;
  undefined1 local_6;
  
  local_6 = 0x14;
  local_a = auStack_16;
  local_12[0] = param_1;
  FUN_8001366a(local_12,param_2);
  return;
}


// ==== FUN_80013640 @ 80013640

void FUN_80013640(undefined4 param_1,undefined4 param_2)

{
  undefined1 auStack_16 [4];
  undefined4 local_12 [2];
  undefined1 *local_a;
  undefined1 local_6;
  
  local_6 = 0x15;
  local_a = auStack_16;
  local_12[0] = param_1;
  FUN_8001366a(local_12,param_2);
  return;
}


// ==== FUN_8001366a @ 8001366a

void FUN_8001366a(undefined4 param_1,uint *param_2)

{
  uint unaff_D7;
  
  FUN_80016284(0xe,0x81,param_1);
  *param_2 = *param_2 & 0xfffffffe;
  do {
    FUN_800162cc(0,0);
    unaff_D7 = *param_2 | unaff_D7;
    *param_2 = unaff_D7;
  } while ((unaff_D7 & 1) == 0);
  return;
}


// ==== FUN_800136c0 @ 800136c0

uint FUN_800136c0(undefined2 param_1,undefined4 param_2,undefined4 param_3,uint param_4)

{
  uint uVar1;
  uint unaff_D7;
  
  uVar1 = 0;
  FUN_800162b4(param_1,param_2,param_3);
  do {
    FUN_800162cc(0,0);
    uVar1 = unaff_D7 | uVar1;
  } while ((param_4 & uVar1) == 0);
  return param_4 & uVar1;
}


// ==== FUN_8001370c @ 8001370c

void FUN_8001370c(uint *param_1)

{
  uint unaff_D7;
  
  *param_1 = *param_1 & 0xfffffdff;
  do {
    FUN_800162cc(0,0);
    unaff_D7 = *param_1 | unaff_D7;
    *param_1 = unaff_D7;
  } while ((*param_1 & 0x200) == 0);
  *param_1 = *param_1 & 0xfffffdff;
  return;
}


// ==== FUN_80013748 @ 80013748

void FUN_80013748(undefined4 param_1,undefined4 param_2,undefined4 *param_3)

{
  undefined4 local_18;
  undefined1 local_14 [4];
  undefined4 local_10;
  undefined4 local_c;
  undefined1 *local_8;
  
  local_10 = param_1;
  local_c = param_2;
  local_8 = local_14;
  FUN_800162b4(0xc,10,&local_10);
  local_18 = 0;
  if (param_3 == (undefined4 *)0x0) {
    param_3 = &local_18;
  }
  FUN_8001370c(param_3);
  return;
}


// ==== FUN_8001379e @ 8001379e

void FUN_8001379e(undefined4 param_1)

{
  FUN_80013748(0,param_1,0);
  return;
}


// ==== FUN_800137b4 @ 800137b4

void FUN_800137b4(undefined4 param_1)

{
  FUN_80013748(1,param_1,0);
  return;
}


// ==== FUN_800137cc @ 800137cc

void FUN_800137cc(undefined4 param_1)

{
  FUN_80013748(2,param_1,0);
  return;
}


// ==== FUN_800137e4 @ 800137e4

void FUN_800137e4(undefined4 param_1)

{
  FUN_80013748(3,param_1,0);
  return;
}


// ==== FUN_800137fc @ 800137fc

void FUN_800137fc(undefined4 param_1)

{
  FUN_80013748(4,param_1,0);
  return;
}


// ==== FUN_80013814 @ 80013814

void FUN_80013814(undefined4 param_1)

{
  FUN_80013748(5,param_1,0);
  return;
}


// ==== FUN_8001382c @ 8001382c

void FUN_8001382c(undefined4 param_1,undefined4 param_2)

{
  FUN_80013748(0,param_1,param_2);
  return;
}


// ==== FUN_80013844 @ 80013844

void FUN_80013844(undefined4 param_1,undefined4 param_2)

{
  FUN_80013748(1,param_1,param_2);
  return;
}


// ==== FUN_8001385e @ 8001385e

void FUN_8001385e(undefined4 param_1,undefined4 param_2)

{
  FUN_80013748(2,param_1,param_2);
  return;
}


// ==== FUN_80013878 @ 80013878

void FUN_80013878(undefined4 param_1,undefined4 param_2)

{
  FUN_80013748(3,param_1,param_2);
  return;
}


// ==== FUN_80013892 @ 80013892

void FUN_80013892(undefined4 param_1,undefined4 param_2)

{
  FUN_80013748(4,param_1,param_2);
  return;
}


// ==== FUN_800138ac @ 800138ac

void FUN_800138ac(undefined4 param_1,undefined4 param_2)

{
  FUN_80013748(5,param_1,param_2);
  return;
}


// ==== FUN_800138c8 @ 800138c8

void FUN_800138c8(void)

{
  return;
}


// ==== FUN_800138d2 @ 800138d2

void FUN_800138d2(void)

{
  return;
}


// ==== FUN_800138f2 @ 800138f2

char FUN_800138f2(char param_1,char *param_2,char *param_3)

{
  char cVar1;
  int iVar2;
  char *pcVar3;
  char *pcVar4;
  char *pcVar5;
  
  if (param_2[7] == '@') {
    cVar1 = '@';
  }
  else {
    iVar2 = 0;
    pcVar4 = param_3;
    do {
      pcVar3 = pcVar4;
      pcVar5 = param_2;
      if (*param_2 == '.') break;
      pcVar5 = param_2 + 1;
      pcVar3 = pcVar4 + 1;
      *pcVar4 = *param_2;
      iVar2 = iVar2 + 1;
      pcVar4 = pcVar3;
      param_2 = pcVar5;
    } while (iVar2 < 6);
    for (; iVar2 < 6; iVar2 = iVar2 + 1) {
      *pcVar3 = '_';
      pcVar3 = pcVar3 + 1;
    }
    param_3[6] = param_1;
    param_3[7] = '@';
    for (; ((iVar2 < 8 && (*pcVar5 != '\0')) && (*pcVar5 != '.')); pcVar5 = pcVar5 + 1) {
      iVar2 = iVar2 + 1;
    }
    if (*pcVar5 == '.') {
      pcVar5 = pcVar5 + 1;
    }
    iVar2 = 0;
    pcVar4 = param_3 + 8;
    do {
      cVar1 = *pcVar5;
      pcVar3 = pcVar4;
      if (cVar1 == '\0') break;
      cVar1 = *pcVar5;
      pcVar3 = pcVar4 + 1;
      *pcVar4 = cVar1;
      iVar2 = iVar2 + 1;
      pcVar4 = pcVar3;
      pcVar5 = pcVar5 + 1;
    } while (iVar2 < 3);
    for (; iVar2 < 3; iVar2 = iVar2 + 1) {
      *pcVar3 = ' ';
      pcVar3 = pcVar3 + 1;
    }
  }
  return cVar1;
}


// ==== FUN_800139a2 @ 800139a2

void FUN_800139a2(char param_1,int param_2)

{
  char unaff_D7b;
  
  FUN_800138c8();
  if ((unaff_D7b <= param_1) && (param_1 <= DAT_90006338)) {
    *(char *)(param_2 + 6) = param_1;
  }
  return;
}


// ==== FUN_800139dc @ 800139dc

void FUN_800139dc(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  undefined1 auStack_12 [14];
  
  FUN_80015c14(param_3,auStack_12);
  FUN_80014358(param_1,param_2,auStack_12,param_4);
  FUN_80015b1a();
  return;
}


// ==== FUN_80013a30 @ 80013a30

void FUN_80013a30(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  int unaff_D7;
  char cVar1;
  undefined1 auStack_10 [12];
  
  FUN_800138c8();
  cVar1 = (char)unaff_D7;
  FUN_800138f2((int)cVar1,param_2,auStack_10);
  if (-1 < unaff_D7) {
    do {
      FUN_800139dc(param_1,param_2,auStack_10,param_3);
      if (unaff_D7 < 1) goto LAB_80013aaa;
      FUN_800138d2((int)cVar1);
      if (cVar1 < '\x01') break;
      FUN_800139a2((int)cVar1,auStack_10);
    } while (0 < unaff_D7);
    unaff_D7 = -0x21;
  }
LAB_80013aaa:
  FUN_80015afc(param_1,unaff_D7);
  return;
}


// ==== FUN_80013abe @ 80013abe

void FUN_80013abe(undefined4 param_1,undefined2 param_2,undefined4 param_3)

{
  uint uVar1;
  uint unaff_D7;
  uint in_stack_ffffffae;
  undefined1 auStack_4e [32];
  undefined1 auStack_2e [14];
  undefined1 auStack_20 [14];
  undefined1 auStack_12 [14];
  
  FUN_80015ca0(param_1);
  FUN_80014454(param_1,param_2,param_2,auStack_4e,param_3);
  FUN_80015b1a();
  if (-1 < (int)unaff_D7) {
    if (unaff_D7 == 0) {
      unaff_D7 = 0xfffffffd;
    }
    else {
      FUN_80015b4c(unaff_D7 & 0xffff,auStack_4e);
      if (unaff_D7 == 0) {
        unaff_D7 = 0xffffffd0;
      }
      else {
        FUN_80013c00(unaff_D7 & 0xffff,auStack_4e,auStack_12,auStack_2e,auStack_20);
        FUN_80014358(param_1,auStack_12,auStack_20,param_3);
        FUN_80015b1a();
        if (-1 < (int)unaff_D7) {
          FUN_8001441a(param_1,auStack_2e,param_3);
          FUN_80015b1a();
          uVar1 = unaff_D7;
          if (unaff_D7 == 0xfffffffd) {
            uVar1 = 0;
          }
          else if (0 < (int)unaff_D7) {
            FUN_80014358(param_1,auStack_2e,auStack_12,param_3);
            FUN_80015b30();
            in_stack_ffffffae = unaff_D7;
          }
          if (-1 < (int)uVar1) {
            FUN_80014358(param_1,auStack_20,auStack_2e,param_3);
            FUN_80015b1a();
            uVar1 = unaff_D7;
          }
          unaff_D7 = uVar1;
          if (-1 < (int)uVar1) {
            unaff_D7 = in_stack_ffffffae;
          }
        }
      }
    }
  }
  FUN_80015afc(param_1,unaff_D7);
  return;
}


// ==== FUN_80013c00 @ 80013c00

void FUN_80013c00(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5)

{
  undefined1 auStack_28 [12];
  undefined1 auStack_1c [6];
  undefined1 local_16;
  undefined1 auStack_10 [12];
  
  FUN_800159f0(param_1,param_2,auStack_10);
  FUN_80015e48(auStack_10,auStack_1c,0xb);
  FUN_80015e48(auStack_10,auStack_28,0xb);
  local_16 = 0x5f;
  FUN_80015c6c(auStack_28);
  FUN_80015c14(auStack_10,param_3);
  FUN_80015c14(auStack_1c,param_5);
  FUN_80015c14(auStack_28,param_4);
  return;
}


// ==== FUN_80013c78 @ 80013c78

void FUN_80013c78(undefined4 param_1,undefined4 param_2)

{
  uint unaff_D7;
  short sVar1;
  undefined1 auStack_3e [14];
  undefined1 auStack_30 [12];
  undefined1 auStack_24 [32];
  
  sVar1 = 1;
  FUN_80015ca0(param_1);
  do {
    while( true ) {
      FUN_80014454(param_1,sVar1,sVar1,auStack_24,param_2);
      FUN_80015b1a();
      if ((int)unaff_D7 < 1) goto LAB_80013d18;
      FUN_80015b4c(unaff_D7 & 0xffff,auStack_24);
      if (unaff_D7 != 0) break;
      sVar1 = sVar1 + 1;
    }
    FUN_800159f0(unaff_D7 & 0xffff,auStack_24,auStack_30);
    FUN_80015c14(auStack_30,auStack_3e);
    FUN_8001431e(param_1,auStack_3e,param_2);
    FUN_80015b1a();
  } while (-1 < (int)unaff_D7);
LAB_80013d18:
  FUN_80015afc(param_1);
  return;
}


// ==== FUN_80013d30 @ 80013d30

void FUN_80013d30(undefined4 param_1,ushort param_2,ushort param_3,uint param_4,int param_5,
                 undefined4 param_6)

{
  uint uVar1;
  ushort uVar2;
  uint unaff_D7;
  ushort uVar3;
  
  if (param_4 < 0x28) {
    uVar2 = (ushort)param_4;
  }
  else {
    uVar2 = 0x28;
  }
  uVar3 = 0;
  uVar1 = 0;
  for (; param_2 <= param_3; param_2 = param_2 + 1) {
    FUN_80013dd8(param_1,param_2,(uint)uVar2,param_5,param_6);
    FUN_80015b1a();
    uVar1 = unaff_D7;
    if ((int)unaff_D7 < 1) break;
    param_5 = (uint)uVar2 + param_5;
    uVar3 = uVar3 + 1;
  }
  if (uVar3 == 0) {
    if (-1 < (int)uVar1) {
      uVar1 = 0xffffffcf;
    }
  }
  else if ((-1 < (int)uVar1) || (uVar1 == 0xfffffffd)) {
    uVar1 = (uint)uVar3;
  }
  FUN_80015afc(param_1,uVar1);
  return;
}


// ==== FUN_80013dd8 @ 80013dd8

void FUN_80013dd8(undefined4 param_1,undefined2 param_2,undefined4 param_3,undefined1 *param_4,
                 undefined4 param_5)

{
  int unaff_D7;
  undefined1 auStack_3e [32];
  undefined1 auStack_1e [8];
  undefined1 auStack_16 [4];
  undefined1 auStack_12 [14];
  
  FUN_80014454(param_1,param_2,param_2,auStack_3e,param_5);
  FUN_80015b1a();
  if (-1 < unaff_D7) {
    if (unaff_D7 == 0) {
      unaff_D7 = -3;
    }
    else {
      FUN_800159f0(1,auStack_3e,auStack_1e);
      FUN_80015c14(auStack_1e,auStack_12);
      FUN_80014226(param_1,auStack_12,0,param_5);
      FUN_80015b1a();
      if (-1 < unaff_D7) {
        FUN_80016210(&DAT_80013dcc,auStack_16,3);
        if (unaff_D7 == 0) {
          FUN_80016210(&DAT_80013dd0,auStack_16,3);
          FUN_80016210(&DAT_80013dd4,auStack_16,3);
          *param_4 = 0x20;
        }
        else {
          *param_4 = 1;
        }
        FUN_80015b1a();
        FUN_80013f02((int)(short)unaff_D7,param_4,param_3,param_5);
        FUN_80014268((int)(short)unaff_D7,param_5);
      }
    }
  }
  FUN_80015afc(param_1,unaff_D7);
  return;
}


// ==== FUN_80013f02 @ 80013f02

void FUN_80013f02(short param_1,char *param_2,int param_3,undefined4 param_4)

{
  int iVar1;
  byte bVar2;
  int unaff_D5;
  int unaff_D7;
  byte *unaff_A3;
  char *pcVar3;
  bool bVar4;
  
  bVar4 = *param_2 == '\x01';
  if (bVar4) {
    *param_2 = ' ';
  }
  bVar2 = 0;
  do {
    FUN_8001428c((int)param_1,0x400,&DAT_9000645e,param_4);
    FUN_80015b1a();
    if (unaff_D7 < 1) break;
    unaff_A3 = &DAT_9000645e;
    unaff_D5 = 0;
    if (0 < unaff_D7) {
      do {
        if (bVar4) {
          bVar2 = *unaff_A3;
        }
        else {
          bVar2 = *unaff_A3 & 0x7f;
        }
        unaff_A3 = unaff_A3 + 1;
      } while ((bVar2 != 0x40) && (unaff_D5 = unaff_D5 + 1, unaff_D5 < unaff_D7));
    }
  } while (bVar2 != 0x40);
  if (bVar2 == 0x40) {
    if (unaff_D7 - unaff_D5 < param_3) {
      iVar1 = unaff_D7 - unaff_D5;
    }
    else {
      iVar1 = param_3;
    }
    FUN_8001405e(unaff_A3,param_2,iVar1,0,bVar4);
    if (iVar1 < param_3) {
      FUN_8001428c((int)param_1,0x400,&DAT_9000645e,param_4);
      FUN_80015b1a();
      if (0 < unaff_D7) {
        iVar1 = unaff_D7;
        if (param_3 - unaff_D5 <= unaff_D7) {
          iVar1 = param_3 - unaff_D5;
        }
        FUN_8001405e(&DAT_9000645e,param_2 + unaff_D7,iVar1);
      }
    }
    pcVar3 = param_2 + unaff_D7;
    if (((bVar4) && (unaff_D7 != 0x28)) &&
       ((unaff_D7 < 1 || ((*pcVar3 != '\r' && (*pcVar3 != '\n')))))) {
      unaff_D7 = 0;
      pcVar3 = param_2;
    }
    for (; unaff_D7 < param_3; unaff_D7 = unaff_D7 + 1) {
      *pcVar3 = ' ';
      pcVar3 = pcVar3 + 1;
    }
  }
  return;
}


// ==== FUN_8001405e @ 8001405e

void FUN_8001405e(byte *param_1,byte *param_2,int param_3,int param_4,int param_5)

{
  do {
    if (param_3 <= param_4) {
      return;
    }
    if (param_5 == 0) {
      if ((*param_1 & 0x7f) < 0x20) {
        return;
      }
    }
    else if ((*param_1 < 0x20) || (0x7e < *param_1)) {
      *param_2 = *param_1;
      return;
    }
    *param_2 = *param_1;
    param_4 = param_4 + 1;
    param_1 = param_1 + 1;
    param_2 = param_2 + 1;
  } while( true );
}


// ==== FUN_800140d4 @ 800140d4

void FUN_800140d4(undefined4 param_1)

{
  FUN_80015afc(param_1,0xfffffff6);
  return;
}


// ==== FUN_800140ec @ 800140ec

void FUN_800140ec(int param_1,undefined4 *param_2)

{
  undefined4 unaff_D7;
  undefined1 local_8 [4];
  
  *(undefined1 **)(param_1 + 0x28) = local_8;
  FUN_800136c0(0x2c,4,param_1,0x80);
  *param_2 = unaff_D7;
  return;
}


// ==== FUN_8001411e @ 8001411e

void FUN_8001411e(undefined1 param_1,undefined2 param_2,undefined2 param_3,undefined2 param_4,
                 undefined4 param_5,undefined4 param_6,undefined4 param_7)

{
  undefined2 local_30;
  undefined1 local_2e;
  undefined1 local_2d;
  undefined2 local_14;
  undefined2 local_12;
  undefined4 local_10;
  undefined4 local_c;
  
  local_2e = 0x40;
  local_2d = param_1;
  local_30 = param_2;
  local_14 = param_3;
  local_12 = param_4;
  local_10 = param_5;
  local_c = param_6;
  FUN_800140ec(&local_30,param_7);
  return;
}


// ==== FUN_80014166 @ 80014166

void FUN_80014166(undefined1 param_1,undefined2 param_2,undefined2 param_3,undefined2 param_4,
                 undefined4 param_5,undefined4 param_6,undefined4 param_7)

{
  undefined2 local_30;
  undefined1 local_2e;
  undefined1 local_2d;
  undefined2 local_14;
  undefined2 local_12;
  undefined4 local_10;
  undefined4 local_c;
  
  local_2e = 0x41;
  local_2d = param_1;
  local_30 = param_2;
  local_14 = param_3;
  local_12 = param_4;
  local_10 = param_5;
  local_c = param_6;
  FUN_800140ec(&local_30,param_7);
  return;
}


// ==== FUN_800141ae @ 800141ae

void FUN_800141ae(undefined1 param_1,undefined4 param_2)

{
  undefined1 auStack_30 [2];
  undefined1 local_2e;
  undefined1 local_2d;
  
  local_2e = 0x42;
  local_2d = param_1;
  FUN_800140ec(auStack_30,param_2);
  return;
}


// ==== FUN_800141d4 @ 800141d4

void FUN_800141d4(undefined1 param_1,undefined4 param_2,ushort param_3,undefined2 param_4,
                 undefined4 param_5)

{
  undefined1 auStack_30 [2];
  undefined1 local_2e;
  undefined1 local_2d;
  undefined1 auStack_2b [23];
  undefined2 local_14;
  uint local_10;
  
  local_2e = 0x13;
  local_2d = param_1;
  FUN_80015bac(param_2,auStack_2b);
  local_10 = (uint)param_3;
  local_14 = param_4;
  FUN_800140ec(auStack_30,param_5);
  return;
}


// ==== FUN_80014226 @ 80014226

void FUN_80014226(undefined1 param_1,undefined4 param_2,undefined2 param_3,undefined4 param_4)

{
  undefined1 auStack_30 [2];
  undefined1 local_2e;
  undefined1 local_2d;
  undefined1 auStack_2b [23];
  undefined2 local_14;
  
  local_2e = 0x11;
  local_2d = param_1;
  FUN_80015bac(param_2,auStack_2b);
  local_14 = param_3;
  FUN_800140ec(auStack_30,param_4);
  return;
}


// ==== FUN_80014268 @ 80014268

void FUN_80014268(undefined2 param_1,undefined4 param_2)

{
  undefined2 local_30;
  undefined1 local_2e;
  
  local_2e = 0x12;
  local_30 = param_1;
  FUN_800140ec(&local_30,param_2);
  return;
}


// ==== FUN_8001428c @ 8001428c

void FUN_8001428c(undefined2 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  undefined2 local_30;
  undefined1 local_2e;
  undefined4 local_10;
  undefined4 local_c;
  
  local_2e = 0x21;
  local_30 = param_1;
  local_10 = param_2;
  local_c = param_3;
  FUN_800140ec(&local_30,param_4);
  return;
}


// ==== FUN_800142bc @ 800142bc

void FUN_800142bc(undefined2 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  undefined2 local_30;
  undefined1 local_2e;
  undefined4 local_10;
  undefined4 local_c;
  
  local_2e = 0x22;
  local_30 = param_1;
  local_10 = param_2;
  local_c = param_3;
  FUN_800140ec(&local_30,param_4);
  return;
}


// ==== FUN_800142ec @ 800142ec

void FUN_800142ec(undefined2 param_1,undefined2 param_2,undefined4 param_3,undefined4 param_4)

{
  undefined2 local_30;
  undefined1 local_2e;
  undefined2 local_14;
  undefined4 local_10;
  
  local_2e = 0x23;
  local_30 = param_1;
  local_10 = param_3;
  local_14 = param_2;
  FUN_800140ec(&local_30,param_4);
  return;
}


// ==== FUN_8001431e @ 8001431e

void FUN_8001431e(undefined1 param_1,undefined4 param_2,undefined4 param_3)

{
  undefined1 auStack_30 [2];
  undefined1 local_2e;
  undefined1 local_2d;
  undefined1 auStack_2b [39];
  
  local_2e = 0x15;
  local_2d = param_1;
  FUN_80015bac(param_2,auStack_2b);
  FUN_800140ec(auStack_30,param_3);
  return;
}


// ==== FUN_80014358 @ 80014358

void FUN_80014358(undefined1 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  undefined1 auStack_30 [2];
  undefined1 local_2e;
  undefined1 local_2d;
  undefined1 auStack_2b [11];
  undefined1 auStack_20 [28];
  
  local_2e = 0x14;
  local_2d = param_1;
  FUN_80015bac(param_2,auStack_2b);
  FUN_80015bac(param_3,auStack_20);
  FUN_800140ec(auStack_30,param_4);
  return;
}


// ==== FUN_800143a2 @ 800143a2

void FUN_800143a2(undefined1 param_1,undefined4 param_2)

{
  undefined1 auStack_30 [2];
  undefined1 local_2e;
  undefined1 local_2d;
  
  local_2e = 1;
  local_2d = param_1;
  FUN_800140ec(auStack_30,param_2);
  return;
}


// ==== FUN_800143c8 @ 800143c8

void FUN_800143c8(undefined1 param_1,undefined4 param_2)

{
  undefined1 auStack_30 [2];
  undefined1 local_2e;
  undefined1 local_2d;
  
  local_2e = 4;
  local_2d = param_1;
  FUN_800140ec(auStack_30,param_2);
  return;
}


// ==== FUN_800143ee @ 800143ee

void FUN_800143ee(undefined1 param_1,undefined4 param_2,undefined4 param_3)

{
  undefined1 auStack_30 [2];
  undefined1 local_2e;
  undefined1 local_2d;
  undefined4 local_c;
  
  local_2e = 2;
  local_2d = param_1;
  local_c = param_2;
  FUN_800140ec(auStack_30,param_3);
  return;
}


// ==== FUN_8001441a @ 8001441a

void FUN_8001441a(undefined1 param_1,undefined4 param_2,undefined4 param_3)

{
  undefined1 auStack_30 [2];
  undefined1 local_2e;
  undefined1 local_2d;
  undefined1 auStack_2b [39];
  
  local_2e = 8;
  local_2d = param_1;
  FUN_80015bac(param_2,auStack_2b);
  FUN_800140ec(auStack_30,param_3);
  return;
}


// ==== FUN_80014454 @ 80014454

void FUN_80014454(undefined1 param_1,undefined2 param_2,undefined2 param_3,undefined4 param_4,
                 undefined4 param_5)

{
  undefined1 auStack_30 [2];
  undefined1 local_2e;
  undefined1 local_2d;
  undefined2 local_14;
  undefined2 local_12;
  undefined4 local_c;
  
  local_2e = 9;
  local_2d = param_1;
  local_14 = param_2;
  local_12 = param_3;
  local_c = param_4;
  FUN_800140ec(auStack_30,param_5);
  return;
}


// ==== FUN_80014490 @ 80014490

void FUN_80014490(undefined1 param_1,undefined4 param_2)

{
  undefined1 auStack_30 [2];
  undefined1 local_2e;
  undefined1 local_2d;
  
  local_2e = 10;
  local_2d = param_1;
  FUN_800140ec(auStack_30,param_2);
  return;
}


// ==== FUN_800144b6 @ 800144b6

void FUN_800144b6(undefined1 param_1,undefined4 param_2,undefined4 param_3)

{
  undefined1 auStack_30 [2];
  undefined1 local_2e;
  undefined1 local_2d;
  undefined4 local_c;
  
  local_2e = 0xb;
  local_2d = param_1;
  local_c = param_2;
  FUN_800140ec(auStack_30,param_3);
  return;
}


// ==== FUN_800144e2 @ 800144e2

void FUN_800144e2(undefined1 param_1,undefined4 param_2,undefined4 param_3)

{
  undefined1 auStack_30 [2];
  undefined1 local_2e;
  undefined1 local_2d;
  undefined4 local_c;
  
  local_2e = 0xc;
  local_2d = param_1;
  local_c = param_2;
  FUN_800140ec(auStack_30,param_3);
  return;
}


// ==== FUN_8001450e @ 8001450e

void FUN_8001450e(undefined1 param_1,undefined4 param_2)

{
  undefined1 auStack_30 [2];
  undefined1 local_2e;
  undefined1 local_2d;
  
  local_2e = 3;
  local_2d = param_1;
  FUN_800140ec(auStack_30,param_2);
  return;
}


// ==== FUN_80014534 @ 80014534

void FUN_80014534(undefined1 param_1,byte param_2,byte param_3,undefined4 param_4,undefined4 param_5
                 )

{
  undefined1 auStack_30 [2];
  undefined1 local_2e;
  undefined1 local_2d;
  ushort local_14;
  ushort local_12;
  undefined4 local_c;
  
  local_2e = 0x30;
  local_2d = param_1;
  local_14 = (ushort)param_2;
  local_12 = (ushort)param_3;
  local_c = param_4;
  FUN_800140ec(auStack_30,param_5);
  return;
}


// ==== FUN_80014578 @ 80014578

void FUN_80014578(undefined1 param_1,undefined1 param_2,undefined4 param_3)

{
  undefined1 auStack_30 [2];
  undefined1 local_2e;
  undefined1 local_2d;
  undefined1 local_2c;
  
  local_2e = 0x31;
  local_2d = param_1;
  local_2c = param_2;
  FUN_800140ec(auStack_30,param_3);
  return;
}


// ==== FUN_800145a6 @ 800145a6

void FUN_800145a6(undefined1 param_1,undefined4 param_2)

{
  undefined1 auStack_30 [2];
  undefined1 local_2e;
  undefined1 local_2d;
  
  local_2e = 0xf;
  local_2d = param_1;
  FUN_800140ec(auStack_30,param_2);
  return;
}


// ==== FUN_800145cc @ 800145cc

void FUN_800145cc(undefined1 param_1,undefined4 param_2,undefined1 param_3,undefined4 param_4,
                 undefined4 param_5)

{
  undefined1 auStack_30 [2];
  undefined1 local_2e;
  undefined1 local_2d;
  undefined1 local_2c;
  undefined1 auStack_2b [11];
  undefined1 auStack_20 [28];
  
  local_2e = 0x32;
  local_2d = param_1;
  FUN_80015bac(param_2,auStack_2b);
  local_2c = param_3;
  FUN_80015bac(param_4,auStack_20);
  FUN_800140ec(auStack_30,param_5);
  return;
}


// ==== FUN_80014620 @ 80014620

void FUN_80014620(undefined2 param_1,undefined4 *param_2)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36 [36];
  undefined2 local_12;
  undefined4 local_c;
  undefined1 *local_8;
  
  local_c = 0;
  local_36[0] = 3;
  local_12 = param_1;
  local_8 = local_3a;
  FUN_800136c0(0x32,6,local_36,0x4000000);
  *param_2 = unaff_D7;
  return;
}


// ==== FUN_80014664 @ 80014664

void FUN_80014664(undefined2 param_1,undefined4 param_2,undefined4 param_3,undefined4 *param_4)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36 [32];
  undefined4 local_16;
  undefined2 local_12;
  undefined4 local_c;
  undefined1 *local_8;
  
  local_36[0] = 4;
  local_12 = param_1;
  local_16 = param_2;
  local_c = param_3;
  local_8 = local_3a;
  FUN_800136c0(0x32,6,local_36,0x4000000);
  *param_4 = unaff_D7;
  return;
}


// ==== FUN_800146b0 @ 800146b0

void FUN_800146b0(undefined2 param_1,undefined4 param_2,undefined4 param_3,undefined4 *param_4)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36 [32];
  undefined4 local_16;
  undefined2 local_12;
  undefined4 local_10;
  undefined4 local_c;
  undefined1 *local_8;
  
  local_36[0] = 5;
  local_12 = param_1;
  local_16 = param_2;
  local_c = param_3;
  local_10 = 0x80;
  local_8 = local_3a;
  FUN_800136c0(0x32,6,local_36,0x4000000);
  *param_4 = unaff_D7;
  return;
}


// ==== FUN_80014704 @ 80014704

void FUN_80014704(undefined4 param_1,undefined4 param_2,ushort param_3,undefined4 param_4,
                 undefined4 *param_5)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36;
  undefined1 local_35;
  undefined1 local_34;
  undefined1 auStack_32 [28];
  uint local_16;
  undefined4 local_c;
  undefined1 *local_8;
  
  local_c = 0;
  local_36 = 1;
  local_35 = (undefined1)((uint)param_1 >> 0x10);
  local_34 = (undefined1)param_1;
  FUN_800161f0(param_2,auStack_32);
  local_16 = (uint)param_3;
  local_8 = local_3a;
  FUN_800136c0(0x32,6,&local_36,0x4000000);
  *param_5 = unaff_D7;
  return;
}


// ==== FUN_80014776 @ 80014776

void FUN_80014776(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 *param_4)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36;
  undefined1 local_35;
  undefined1 local_34;
  undefined1 auStack_32 [38];
  undefined4 local_c;
  undefined1 *local_8;
  
  local_c = 0;
  local_36 = 2;
  local_35 = (undefined1)((uint)param_1 >> 0x10);
  local_34 = (undefined1)param_1;
  FUN_800161f0(param_2,auStack_32);
  local_8 = local_3a;
  FUN_800136c0(0x32,6,&local_36,0x4000000);
  *param_4 = unaff_D7;
  return;
}


// ==== FUN_800147d8 @ 800147d8

void FUN_800147d8(undefined4 param_1,undefined4 param_2,undefined4 *param_3)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36;
  undefined1 local_35;
  undefined1 local_34;
  undefined1 auStack_32 [38];
  undefined4 local_c;
  undefined1 *local_8;
  
  local_c = 0;
  local_36 = 6;
  local_35 = (undefined1)((uint)param_1 >> 0x10);
  local_34 = (undefined1)param_1;
  FUN_800161f0(param_2,auStack_32);
  local_8 = local_3a;
  FUN_800136c0(0x32,6,&local_36,0x4000000);
  *param_3 = unaff_D7;
  return;
}


// ==== FUN_8001483a @ 8001483a

void FUN_8001483a(undefined4 param_1,undefined4 param_2,undefined4 *param_3)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36;
  undefined1 local_35;
  undefined1 local_34;
  undefined1 auStack_32 [38];
  undefined4 local_c;
  undefined1 *local_8;
  
  local_c = 0;
  local_36 = 0x1c;
  local_35 = (undefined1)((uint)param_1 >> 0x10);
  local_34 = (undefined1)param_1;
  FUN_800161f0(param_2,auStack_32);
  local_8 = local_3a;
  FUN_800136c0(0x32,6,&local_36,0x4000000);
  *param_3 = unaff_D7;
  return;
}


// ==== FUN_8001489c @ 8001489c

void FUN_8001489c(undefined4 param_1,undefined2 param_2,undefined4 *param_3)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36;
  undefined1 local_35;
  undefined1 local_34;
  undefined2 local_1a;
  undefined4 local_c;
  undefined1 *local_8;
  
  local_c = 0;
  local_36 = 7;
  local_35 = (undefined1)((uint)param_1 >> 0x10);
  local_34 = (undefined1)param_1;
  local_1a = param_2;
  local_8 = local_3a;
  FUN_800136c0(0x32,6,&local_36,0x4000000);
  *param_3 = unaff_D7;
  return;
}


// ==== FUN_800148f2 @ 800148f2

void FUN_800148f2(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 *param_4)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36;
  undefined1 local_35;
  undefined1 local_34;
  undefined1 auStack_32 [12];
  undefined1 auStack_26 [26];
  undefined4 local_c;
  undefined1 *local_8;
  
  local_c = 0;
  local_36 = 8;
  local_35 = (undefined1)((uint)param_1 >> 0x10);
  local_34 = (undefined1)param_1;
  FUN_800161f0(param_2,auStack_32);
  FUN_800161f0(param_3,auStack_26);
  local_8 = local_3a;
  FUN_800136c0(0x32,6,&local_36,0x4000000);
  *param_4 = unaff_D7;
  return;
}


// ==== FUN_80014964 @ 80014964

void FUN_80014964(undefined4 param_1,undefined4 *param_2)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36;
  undefined1 local_35;
  undefined1 local_34;
  undefined4 local_c;
  undefined1 *local_8;
  
  local_c = 0;
  local_36 = 9;
  local_35 = (undefined1)((uint)param_1 >> 0x10);
  local_34 = (undefined1)param_1;
  local_8 = local_3a;
  FUN_800136c0(0x32,6,&local_36,0x4000000);
  *param_2 = unaff_D7;
  return;
}


// ==== FUN_800149b2 @ 800149b2

void FUN_800149b2(undefined4 param_1,undefined4 *param_2)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36;
  undefined1 local_35;
  undefined1 local_34;
  undefined4 local_c;
  undefined1 *local_8;
  
  local_c = 0;
  local_36 = 10;
  local_35 = (undefined1)((uint)param_1 >> 0x10);
  local_34 = (undefined1)param_1;
  local_8 = local_3a;
  FUN_800136c0(0x32,6,&local_36,0x4000000);
  *param_2 = unaff_D7;
  return;
}


// ==== FUN_80014a00 @ 80014a00

void FUN_80014a00(undefined4 param_1,undefined4 param_2,undefined4 *param_3)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36;
  undefined1 local_35;
  undefined1 local_34;
  undefined4 local_c;
  undefined1 *local_8;
  
  local_36 = 0xb;
  local_35 = (undefined1)((uint)param_1 >> 0x10);
  local_34 = (undefined1)param_1;
  local_c = param_2;
  local_8 = local_3a;
  FUN_800136c0(0x32,6,&local_36,0x4000000);
  *param_3 = unaff_D7;
  return;
}


// ==== FUN_80014a50 @ 80014a50

void FUN_80014a50(undefined4 param_1,undefined4 param_2,undefined4 *param_3)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36;
  undefined1 local_35;
  undefined1 local_34;
  undefined1 auStack_32 [38];
  undefined4 local_c;
  undefined1 *local_8;
  
  local_c = 0;
  local_36 = 0xc;
  local_35 = (undefined1)((uint)param_1 >> 0x10);
  local_34 = (undefined1)param_1;
  FUN_800161f0(param_2,auStack_32);
  local_8 = local_3a;
  FUN_800136c0(0x32,6,&local_36,0x4000000);
  *param_3 = unaff_D7;
  return;
}


// ==== FUN_80014ab2 @ 80014ab2

void FUN_80014ab2(undefined4 param_1,undefined2 param_2,undefined2 param_3,undefined4 param_4,
                 undefined4 *param_5)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36;
  undefined1 local_35;
  undefined1 local_34;
  undefined2 local_1a;
  undefined2 local_18;
  undefined4 local_c;
  undefined1 *local_8;
  
  local_36 = 0xd;
  local_35 = (undefined1)((uint)param_1 >> 0x10);
  local_34 = (undefined1)param_1;
  local_1a = param_2;
  local_18 = param_3;
  local_c = param_4;
  local_8 = local_3a;
  FUN_800136c0(0x32,6,&local_36,0x4000000);
  *param_5 = unaff_D7;
  return;
}


// ==== FUN_80014b18 @ 80014b18

void FUN_80014b18(undefined4 param_1,undefined2 param_2,undefined2 param_3,ushort param_4,
                 undefined4 param_5,undefined4 *param_6)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36;
  undefined1 local_35;
  undefined1 local_34;
  undefined2 local_1a;
  undefined2 local_18;
  uint local_16;
  undefined4 local_c;
  undefined1 *local_8;
  
  local_36 = 0xe;
  local_35 = (undefined1)((uint)param_1 >> 0x10);
  local_34 = (undefined1)param_1;
  local_1a = param_2;
  local_18 = param_3;
  local_16 = (uint)param_4;
  local_c = param_5;
  local_8 = local_3a;
  FUN_800136c0(0x32,6,&local_36,0x4000000);
  *param_6 = unaff_D7;
  return;
}


// ==== FUN_80014b8e @ 80014b8e

void FUN_80014b8e(undefined4 param_1,undefined2 param_2,undefined2 param_3,ushort param_4,
                 undefined4 param_5,undefined4 *param_6)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36;
  undefined1 local_35;
  undefined1 local_34;
  undefined2 local_1a;
  undefined2 local_18;
  uint local_16;
  undefined4 local_c;
  undefined1 *local_8;
  
  local_36 = 0xf;
  local_35 = (undefined1)((uint)param_1 >> 0x10);
  local_34 = (undefined1)param_1;
  local_1a = param_2;
  local_18 = param_3;
  local_16 = (uint)param_4;
  local_c = param_5;
  local_8 = local_3a;
  FUN_800136c0(0x32,6,&local_36,0x4000000);
  *param_6 = unaff_D7;
  return;
}


// ==== FUN_80014c04 @ 80014c04

void FUN_80014c04(undefined4 param_1,undefined4 *param_2)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36;
  undefined1 local_35;
  undefined1 local_34;
  undefined4 local_c;
  undefined1 *local_8;
  
  local_c = 0;
  local_36 = 0x10;
  local_35 = (undefined1)((uint)param_1 >> 0x10);
  local_34 = (undefined1)param_1;
  local_8 = local_3a;
  FUN_800136c0(0x32,6,&local_36,0x4000000);
  *param_2 = unaff_D7;
  return;
}


// ==== FUN_80014c52 @ 80014c52

void FUN_80014c52(undefined4 param_1,undefined4 param_2,undefined4 *param_3)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36;
  undefined1 local_35;
  undefined1 local_34;
  undefined4 local_c;
  undefined1 *local_8;
  
  local_36 = 0x11;
  local_35 = (undefined1)((uint)param_1 >> 0x10);
  local_34 = (undefined1)param_1;
  local_c = param_2;
  local_8 = local_3a;
  FUN_800136c0(0x32,6,&local_36,0x4000000);
  *param_3 = unaff_D7;
  return;
}


// ==== FUN_80014ca2 @ 80014ca2

void FUN_80014ca2(undefined4 param_1,undefined4 param_2,undefined4 *param_3)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36;
  undefined1 local_35;
  undefined1 local_34;
  undefined4 local_c;
  undefined1 *local_8;
  
  local_36 = 0x12;
  local_35 = (undefined1)((uint)param_1 >> 0x10);
  local_34 = (undefined1)param_1;
  local_c = param_2;
  local_8 = local_3a;
  FUN_800136c0(0x32,6,&local_36,0x4000000);
  *param_3 = unaff_D7;
  return;
}


// ==== FUN_80014cf2 @ 80014cf2

void FUN_80014cf2(undefined4 param_1,undefined4 *param_2)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36;
  undefined1 local_35;
  undefined1 local_34;
  undefined4 local_c;
  undefined1 *local_8;
  
  local_c = 0;
  local_36 = 0x13;
  local_35 = (undefined1)((uint)param_1 >> 0x10);
  local_34 = (undefined1)param_1;
  local_8 = local_3a;
  FUN_800136c0(0x32,6,&local_36,0x4000000);
  *param_2 = unaff_D7;
  return;
}


// ==== FUN_80014d40 @ 80014d40

void FUN_80014d40(undefined4 param_1,char param_2,byte param_3,undefined4 param_4,
                 undefined4 *param_5)

{
  byte bVar1;
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36;
  undefined1 local_35;
  char local_34;
  uint local_10;
  undefined4 local_c;
  undefined1 *local_8;
  
  local_34 = (char)param_1;
  bVar1 = 0;
  local_36 = 0x14;
  local_35 = (undefined1)((uint)param_1 >> 0x10);
  if (param_2 == '\0') {
    bVar1 = 0x80;
  }
  if ((local_34 == '\b') || (local_34 == '\t')) {
    if (param_2 == '\x02') {
      bVar1 = bVar1 | 8;
    }
    else {
      bVar1 = bVar1 | 4;
    }
  }
  if (((local_34 == '\f') || (local_34 == '\r')) && ((param_3 & 3) != 3)) {
    bVar1 = bVar1 | 1;
  }
  local_10 = (uint)bVar1;
  local_c = param_4;
  local_8 = local_3a;
  FUN_800136c0(0x32,6,&local_36,0x4000000);
  *param_5 = unaff_D7;
  return;
}


// ==== FUN_80014dea @ 80014dea

void FUN_80014dea(undefined4 param_1,undefined4 *param_2)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36;
  undefined1 local_35;
  undefined1 local_34;
  undefined4 local_c;
  undefined1 *local_8;
  
  local_c = 0;
  local_36 = 0x15;
  local_35 = (undefined1)((uint)param_1 >> 0x10);
  local_34 = (undefined1)param_1;
  local_8 = local_3a;
  FUN_800136c0(0x32,6,&local_36,0x4000000);
  *param_2 = unaff_D7;
  return;
}


// ==== FUN_80014e38 @ 80014e38

void FUN_80014e38(undefined2 param_1,byte param_2,undefined4 param_3,undefined4 *param_4)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36 [32];
  undefined4 local_16;
  undefined2 local_12;
  uint local_10;
  undefined4 local_c;
  undefined1 *local_8;
  
  local_c = 0;
  local_36[0] = 0x16;
  local_12 = param_1;
  local_10 = (uint)param_2;
  local_16 = param_3;
  local_8 = local_3a;
  FUN_800136c0(0x32,6,local_36,0x4000000);
  *param_4 = unaff_D7;
  return;
}


// ==== FUN_80014e8e @ 80014e8e

void FUN_80014e8e(undefined4 param_1,undefined1 param_2,undefined4 *param_3)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36;
  undefined1 local_35;
  undefined1 local_34;
  undefined1 local_33;
  undefined4 local_10;
  undefined4 local_c;
  undefined1 *local_8;
  
  local_c = 0;
  local_36 = 0x17;
  local_35 = (undefined1)((uint)param_1 >> 0x10);
  local_34 = (undefined1)param_1;
  local_33 = param_2;
  local_10 = 0x80;
  local_8 = local_3a;
  FUN_800136c0(0x32,6,&local_36,0x4000000);
  *param_3 = unaff_D7;
  return;
}


// ==== FUN_80014eec @ 80014eec

void FUN_80014eec(undefined4 param_1,undefined4 *param_2)

{
  int unaff_D7;
  undefined1 auStack_3c [2];
  undefined1 local_36;
  undefined1 local_35;
  undefined1 local_34;
  undefined4 local_c;
  undefined1 *local_8;
  
  FUN_8001511a(param_1);
  if (unaff_D7 == 0) {
    local_c = 0;
    local_36 = 0x18;
    local_35 = (undefined1)((uint)param_1 >> 0x10);
    local_34 = (undefined1)param_1;
    local_8 = auStack_3c + 2;
    FUN_800136c0(0x32,6,&local_36,0x4000000);
    *param_2 = 0;
  }
  return;
}


// ==== FUN_80014f66 @ 80014f66

void FUN_80014f66(undefined4 param_1,undefined4 param_2,undefined1 param_3,undefined4 param_4,
                 undefined4 *param_5)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36;
  undefined1 local_35;
  undefined1 local_34;
  undefined1 local_33;
  undefined1 auStack_32 [12];
  undefined1 auStack_26 [22];
  undefined4 local_10;
  undefined4 local_c;
  undefined1 *local_8;
  
  local_c = 0;
  local_36 = 0x19;
  local_35 = (undefined1)((uint)param_1 >> 0x10);
  local_34 = (undefined1)param_1;
  local_33 = param_3;
  FUN_80015e48(param_2,auStack_32,0xc);
  FUN_80015e48(param_4,auStack_26,0xc);
  local_10 = 0x80;
  local_8 = local_3a;
  FUN_800136c0(0x32,6,&local_36,0x4000000);
  *param_5 = unaff_D7;
  return;
}


// ==== FUN_80014ff0 @ 80014ff0

void FUN_80014ff0(undefined4 param_1,undefined2 param_2,undefined2 param_3,undefined2 param_4,
                 undefined4 param_5,undefined4 param_6,undefined4 *param_7)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36;
  undefined1 local_35;
  undefined1 local_34;
  undefined2 local_1a;
  undefined2 local_18;
  undefined4 local_16;
  undefined2 local_12;
  undefined4 local_c;
  undefined1 *local_8;
  
  local_36 = 0x1a;
  local_35 = (undefined1)((uint)param_1 >> 0x10);
  local_34 = (undefined1)param_1;
  local_12 = param_2;
  local_1a = param_3;
  local_18 = param_4;
  local_c = param_6;
  local_16 = param_5;
  local_8 = local_3a;
  FUN_800136c0(0x32,6,&local_36,0x4000000);
  *param_7 = unaff_D7;
  return;
}


// ==== FUN_8001505e @ 8001505e

void FUN_8001505e(undefined4 param_1,undefined2 param_2,undefined2 param_3,undefined2 param_4,
                 undefined4 param_5,undefined4 param_6,undefined4 *param_7)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36;
  undefined1 local_35;
  undefined1 local_34;
  undefined2 local_1a;
  undefined2 local_18;
  undefined4 local_16;
  undefined2 local_12;
  undefined4 local_c;
  undefined1 *local_8;
  
  local_36 = 0x1b;
  local_35 = (undefined1)((uint)param_1 >> 0x10);
  local_34 = (undefined1)param_1;
  local_12 = param_2;
  local_1a = param_3;
  local_18 = param_4;
  local_c = param_6;
  local_16 = param_5;
  local_8 = local_3a;
  FUN_800136c0(0x32,6,&local_36,0x4000000);
  *param_7 = unaff_D7;
  return;
}


// ==== FUN_800150cc @ 800150cc

void FUN_800150cc(undefined4 param_1,undefined4 *param_2)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36;
  undefined1 local_35;
  undefined1 local_34;
  undefined4 local_c;
  undefined1 *local_8;
  
  local_c = 0;
  local_36 = 0x1d;
  local_35 = (undefined1)((uint)param_1 >> 0x10);
  local_34 = (undefined1)param_1;
  local_8 = local_3a;
  FUN_800136c0(0x32,6,&local_36,0x4000000);
  *param_2 = unaff_D7;
  return;
}


// ==== FUN_8001511a @ 8001511a

void FUN_8001511a(undefined1 param_1)

{
  switch(param_1) {
  case 8:
  case 9:
  case 0xc:
  case 0xd:
    break;
  default:
  }
  return;
}


// ==== FUN_80015154 @ 80015154

void FUN_80015154(undefined4 param_1)

{
  FUN_800162d4(9,param_1);
  return;
}


// ==== FUN_8001516a @ 8001516a

void FUN_8001516a(void)

{
  FUN_800162d4(10);
  return;
}


// ==== FUN_8001517c @ 8001517c

void FUN_8001517c(undefined1 param_1,undefined4 param_2,ushort param_3,undefined4 param_4,
                 undefined4 *param_5)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36 [2];
  undefined1 local_34;
  undefined1 auStack_32 [28];
  uint local_16;
  undefined1 *local_8;
  
  local_36[0] = 1;
  local_34 = param_1;
  FUN_800161f0(param_2,auStack_32);
  local_16 = (uint)param_3;
  local_8 = local_3a;
  FUN_800136c0(0x32,5,local_36,0x4000000);
  *param_5 = unaff_D7;
  return;
}


// ==== FUN_800151e0 @ 800151e0

void FUN_800151e0(undefined1 param_1,undefined4 param_2,undefined4 param_3,undefined4 *param_4)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36 [2];
  undefined1 local_34;
  undefined1 auStack_32 [42];
  undefined1 *local_8;
  
  local_36[0] = 2;
  local_34 = param_1;
  local_8 = local_3a;
  FUN_800161f0(param_2,auStack_32);
  FUN_800136c0(0x32,5,local_36,0x4000000);
  *param_4 = unaff_D7;
  return;
}


// ==== FUN_80015234 @ 80015234

void FUN_80015234(undefined2 param_1,undefined4 *param_2)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36 [36];
  undefined2 local_12;
  undefined1 *local_8;
  
  local_36[0] = 3;
  local_12 = param_1;
  local_8 = local_3a;
  FUN_800136c0(0x32,5,local_36,0x4000000);
  *param_2 = unaff_D7;
  return;
}


// ==== FUN_80015274 @ 80015274

void FUN_80015274(undefined2 param_1,undefined4 param_2,undefined4 param_3,undefined4 *param_4)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36 [32];
  undefined4 local_16;
  undefined2 local_12;
  undefined4 local_c;
  undefined1 *local_8;
  
  local_36[0] = 4;
  local_12 = param_1;
  local_16 = param_2;
  local_c = param_3;
  local_8 = local_3a;
  FUN_800136c0(0x32,5,local_36,0x4000000);
  *param_4 = unaff_D7;
  return;
}


// ==== FUN_800152c0 @ 800152c0

void FUN_800152c0(undefined2 param_1,undefined4 param_2,undefined4 param_3,undefined4 *param_4)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36 [32];
  undefined4 local_16;
  undefined2 local_12;
  undefined4 local_c;
  undefined1 *local_8;
  
  local_36[0] = 5;
  local_12 = param_1;
  local_16 = param_2;
  local_c = param_3;
  local_8 = local_3a;
  FUN_800136c0(0x32,5,local_36,0x4000000);
  *param_4 = unaff_D7;
  return;
}


// ==== FUN_8001530c @ 8001530c

void FUN_8001530c(undefined1 param_1,undefined4 param_2,undefined4 *param_3)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36 [2];
  undefined1 local_34;
  undefined1 auStack_32 [42];
  undefined1 *local_8;
  
  local_36[0] = 6;
  local_34 = param_1;
  FUN_800161f0(param_2,auStack_32);
  local_8 = local_3a;
  FUN_800136c0(0x32,5,local_36,0x4000000);
  *param_3 = unaff_D7;
  return;
}


// ==== FUN_80015360 @ 80015360

void FUN_80015360(undefined1 param_1,undefined2 param_2,undefined4 *param_3)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36 [2];
  undefined1 local_34;
  undefined2 local_1a;
  undefined1 *local_8;
  
  local_36[0] = 7;
  local_34 = param_1;
  local_1a = param_2;
  local_8 = local_3a;
  FUN_800136c0(0x32,5,local_36,0x4000000);
  *param_3 = unaff_D7;
  return;
}


// ==== FUN_800153a8 @ 800153a8

void FUN_800153a8(undefined1 param_1,undefined4 param_2,undefined4 param_3,undefined4 *param_4)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36 [2];
  undefined1 local_34;
  undefined1 auStack_32 [12];
  undefined1 auStack_26 [30];
  undefined1 *local_8;
  
  local_36[0] = 8;
  local_34 = param_1;
  FUN_800161f0(param_2,auStack_32);
  FUN_800161f0(param_3,auStack_26);
  local_8 = local_3a;
  FUN_800136c0(0x32,5,local_36,0x4000000);
  *param_4 = unaff_D7;
  return;
}


// ==== FUN_8001540c @ 8001540c

void FUN_8001540c(undefined1 param_1,undefined4 *param_2)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36 [2];
  undefined1 local_34;
  undefined1 *local_8;
  
  local_36[0] = 9;
  local_34 = param_1;
  local_8 = local_3a;
  FUN_800136c0(0x32,5,local_36,0x4000000);
  *param_2 = unaff_D7;
  return;
}


// ==== FUN_8001544c @ 8001544c

void FUN_8001544c(undefined1 param_1,undefined4 *param_2)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36 [2];
  undefined1 local_34;
  undefined1 *local_8;
  
  local_36[0] = 10;
  local_34 = param_1;
  local_8 = local_3a;
  FUN_800136c0(0x32,5,local_36,0x4000000);
  *param_2 = unaff_D7;
  return;
}


// ==== FUN_8001548c @ 8001548c

void FUN_8001548c(undefined1 param_1,undefined4 param_2,undefined4 *param_3)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36 [2];
  undefined1 local_34;
  undefined4 local_c;
  undefined1 *local_8;
  
  local_36[0] = 0xb;
  local_34 = param_1;
  local_c = param_2;
  local_8 = local_3a;
  FUN_800136c0(0x32,5,local_36,0x4000000);
  *param_3 = unaff_D7;
  return;
}


// ==== FUN_800154d2 @ 800154d2

void FUN_800154d2(undefined1 param_1,undefined4 param_2,undefined4 *param_3)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36 [2];
  undefined1 local_34;
  undefined1 auStack_32 [42];
  undefined1 *local_8;
  
  local_36[0] = 0xc;
  local_34 = param_1;
  FUN_800161f0(param_2,auStack_32);
  local_8 = local_3a;
  FUN_800136c0(0x32,5,local_36,0x4000000);
  *param_3 = unaff_D7;
  return;
}


// ==== FUN_80015526 @ 80015526

void FUN_80015526(undefined1 param_1,undefined2 param_2,undefined2 param_3,undefined4 param_4,
                 undefined4 *param_5)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36 [2];
  undefined1 local_34;
  undefined2 local_1a;
  undefined2 local_18;
  undefined4 local_c;
  undefined1 *local_8;
  
  local_36[0] = 0xd;
  local_34 = param_1;
  local_1a = param_2;
  local_18 = param_3;
  local_c = param_4;
  local_8 = local_3a;
  FUN_800136c0(0x32,5,local_36,0x4000000);
  *param_5 = unaff_D7;
  return;
}


// ==== FUN_8001557c @ 8001557c

void FUN_8001557c(undefined1 param_1,undefined2 param_2,undefined2 param_3,ushort param_4,
                 undefined4 param_5,undefined4 *param_6)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36 [2];
  undefined1 local_34;
  undefined2 local_1a;
  undefined2 local_18;
  uint local_16;
  undefined4 local_c;
  undefined1 *local_8;
  
  local_36[0] = 0xe;
  local_34 = param_1;
  local_1a = param_2;
  local_18 = param_3;
  local_16 = (uint)param_4;
  local_c = param_5;
  local_8 = local_3a;
  FUN_800136c0(0x32,5,local_36,0x4000000);
  *param_6 = unaff_D7;
  return;
}


// ==== FUN_800155e4 @ 800155e4

void FUN_800155e4(undefined1 param_1,undefined2 param_2,undefined2 param_3,ushort param_4,
                 undefined4 param_5,undefined4 *param_6)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36 [2];
  undefined1 local_34;
  undefined2 local_1a;
  undefined2 local_18;
  uint local_16;
  undefined4 local_c;
  undefined1 *local_8;
  
  local_36[0] = 0xf;
  local_34 = param_1;
  local_1a = param_2;
  local_18 = param_3;
  local_16 = (uint)param_4;
  local_c = param_5;
  local_8 = local_3a;
  FUN_800136c0(0x32,5,local_36,0x4000000);
  *param_6 = unaff_D7;
  return;
}


// ==== FUN_8001564c @ 8001564c

void FUN_8001564c(undefined1 param_1,undefined4 *param_2)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36 [2];
  undefined1 local_34;
  undefined1 *local_8;
  
  local_36[0] = 0x10;
  local_34 = param_1;
  local_8 = local_3a;
  FUN_800136c0(0x32,5,local_36,0x4000000);
  *param_2 = unaff_D7;
  return;
}


// ==== FUN_8001568c @ 8001568c

void FUN_8001568c(undefined1 param_1,undefined4 param_2,undefined4 *param_3)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36 [2];
  undefined1 local_34;
  undefined4 local_c;
  undefined1 *local_8;
  
  local_36[0] = 0x11;
  local_34 = param_1;
  local_c = param_2;
  local_8 = local_3a;
  FUN_800136c0(0x32,5,local_36,0x4000000);
  *param_3 = unaff_D7;
  return;
}


// ==== FUN_800156d2 @ 800156d2

void FUN_800156d2(undefined1 param_1,undefined4 param_2,undefined4 *param_3)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36 [2];
  undefined1 local_34;
  undefined4 local_c;
  undefined1 *local_8;
  
  local_36[0] = 0x12;
  local_34 = param_1;
  local_c = param_2;
  local_8 = local_3a;
  FUN_800136c0(0x32,5,local_36,0x4000000);
  *param_3 = unaff_D7;
  return;
}


// ==== FUN_80015718 @ 80015718

void FUN_80015718(undefined1 param_1,undefined4 *param_2)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36 [2];
  undefined1 local_34;
  undefined1 *local_8;
  
  local_36[0] = 0x13;
  local_34 = param_1;
  local_8 = local_3a;
  FUN_800136c0(0x32,5,local_36,0x4000000);
  *param_2 = unaff_D7;
  return;
}


// ==== FUN_80015758 @ 80015758

void FUN_80015758(undefined1 param_1,char param_2,byte param_3,undefined4 param_4,
                 undefined4 *param_5)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36 [2];
  undefined1 local_34;
  short local_1a;
  uint local_16;
  undefined4 local_c;
  undefined1 *local_8;
  
  local_36[0] = 0x14;
  local_34 = param_1;
  local_1a = (short)param_2;
  local_16 = (uint)param_3;
  local_c = param_4;
  local_8 = local_3a;
  FUN_800136c0(0x32,5,local_36,0x4000000);
  *param_5 = unaff_D7;
  return;
}


// ==== FUN_800157b4 @ 800157b4

void FUN_800157b4(undefined1 param_1,undefined4 *param_2)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36 [2];
  undefined1 local_34;
  undefined1 *local_8;
  
  local_36[0] = 0x15;
  local_34 = param_1;
  local_8 = local_3a;
  FUN_800136c0(0x32,5,local_36,0x4000000);
  *param_2 = unaff_D7;
  return;
}


// ==== FUN_800157f4 @ 800157f4

void FUN_800157f4(undefined1 param_1,undefined4 param_2,undefined1 param_3,undefined4 param_4,
                 undefined4 *param_5)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36 [2];
  undefined1 local_34;
  undefined1 local_33;
  undefined1 auStack_32 [12];
  undefined1 auStack_26 [30];
  undefined1 *local_8;
  
  local_36[0] = 0x19;
  local_34 = param_1;
  FUN_800161f0(param_2,auStack_32);
  local_33 = param_3;
  FUN_800161f0(param_4,auStack_26);
  local_8 = local_3a;
  FUN_800136c0(0x32,5,local_36,0x4000000);
  *param_5 = unaff_D7;
  return;
}


// ==== FUN_80015860 @ 80015860

void FUN_80015860(undefined1 param_1,undefined1 param_2,undefined4 *param_3)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36 [2];
  undefined1 local_34;
  undefined1 local_33;
  undefined1 *local_8;
  
  local_36[0] = 0x17;
  local_34 = param_1;
  local_33 = param_2;
  local_8 = local_3a;
  FUN_800136c0(0x32,5,local_36,0x4000000);
  *param_3 = unaff_D7;
  return;
}


// ==== FUN_800158a8 @ 800158a8

void FUN_800158a8(undefined1 param_1,undefined4 *param_2)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36 [2];
  undefined1 local_34;
  undefined1 *local_8;
  
  local_36[0] = 0x18;
  local_34 = param_1;
  local_8 = local_3a;
  FUN_800136c0(0x32,5,local_36,0x4000000);
  *param_2 = unaff_D7;
  return;
}


// ==== FUN_800158e8 @ 800158e8

void FUN_800158e8(undefined1 param_1,undefined2 param_2,undefined2 param_3,undefined2 param_4,
                 undefined4 param_5,undefined4 param_6,undefined4 *param_7)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36 [2];
  undefined1 local_34;
  undefined2 local_1a;
  undefined2 local_18;
  undefined4 local_16;
  undefined2 local_12;
  undefined4 local_c;
  undefined1 *local_8;
  
  local_36[0] = 0x1a;
  local_34 = param_1;
  local_12 = param_2;
  local_1a = param_3;
  local_18 = param_4;
  local_c = param_6;
  local_16 = param_5;
  local_8 = local_3a;
  FUN_800136c0(0x32,5,local_36,0x4000000);
  *param_7 = unaff_D7;
  return;
}


// ==== FUN_8001594c @ 8001594c

void FUN_8001594c(undefined1 param_1,undefined2 param_2,undefined2 param_3,undefined2 param_4,
                 undefined4 param_5,undefined4 param_6,undefined4 *param_7)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36 [2];
  undefined1 local_34;
  undefined2 local_1a;
  undefined2 local_18;
  undefined4 local_16;
  undefined2 local_12;
  undefined4 local_c;
  undefined1 *local_8;
  
  local_36[0] = 0x1b;
  local_34 = param_1;
  local_12 = param_2;
  local_1a = param_3;
  local_18 = param_4;
  local_c = param_6;
  local_16 = param_5;
  local_8 = local_3a;
  FUN_800136c0(0x32,5,local_36,0x4000000);
  *param_7 = unaff_D7;
  return;
}


// ==== FUN_800159b0 @ 800159b0

void FUN_800159b0(undefined1 param_1,undefined4 *param_2)

{
  undefined4 unaff_D7;
  undefined1 local_3a [4];
  undefined1 local_36 [2];
  undefined1 local_34;
  undefined1 *local_8;
  
  local_36[0] = 0x1d;
  local_34 = param_1;
  local_8 = local_3a;
  FUN_800136c0(0x32,5,local_36,0x4000000);
  *param_2 = unaff_D7;
  return;
}


// ==== FUN_800159f0 @ 800159f0

void FUN_800159f0(ushort param_1,int param_2,int param_3)

{
  undefined1 auStack_8 [4];
  
  if (param_1 == 3) {
LAB_80015a6c:
    FUN_80015d68(*(undefined2 *)(param_2 + 2),param_3);
    FUN_80015d68(*(undefined2 *)(param_2 + 4));
    FUN_80016134();
    FUN_80015d68(*(undefined2 *)(param_2 + 6),auStack_8);
    FUN_80015d14(auStack_8,param_3 + 8,3);
  }
  else {
    if ((3 < param_1) && (param_1 != 0x81)) {
      if (param_1 < 0x82) {
        if (param_1 == 6) {
          FUN_80015e48(param_2,param_3,8);
          FUN_80015e48(param_2 + 8,param_3 + 8,3);
          goto LAB_80015ae2;
        }
      }
      else if (param_1 == 0x83) goto LAB_80015a6c;
    }
    FUN_80015e48(param_2,param_3,0xb);
  }
LAB_80015ae2:
  FUN_80015b4c(param_1,param_2);
  return;
}


// ==== FUN_80015afc @ 80015afc

uint FUN_80015afc(undefined1 param_1,uint param_2)

{
  undefined4 in_D0;
  
  if ((int)param_2 < 0) {
    param_2 = CONCAT31((int3)((uint)in_D0 >> 8),param_1) & 0xffff | param_2 << 0x10;
  }
  return param_2;
}


// ==== FUN_80015b1a @ 80015b1a

int FUN_80015b1a(int param_1)

{
  int iVar1;
  
  iVar1 = param_1 >> 0x10;
  if (-1 < param_1) {
    iVar1 = param_1;
  }
  return iVar1;
}


// ==== FUN_80015b30 @ 80015b30

void FUN_80015b30(void)

{
  return;
}


// ==== FUN_80015b3e @ 80015b3e

void FUN_80015b3e(void)

{
  return;
}


// ==== FUN_80015b4c @ 80015b4c

undefined4 FUN_80015b4c(ushort param_1,ushort *param_2)

{
  if (param_1 == 3) {
LAB_80015b80:
    if ((*param_2 & 0x200) == 0) {
      return 0;
    }
  }
  else {
    if (param_1 < 4) {
      if ((param_1 != 1) && (param_1 == 2)) {
        if (*(char *)((int)param_2 + 0xb) < '\0') {
          return 1;
        }
        return 0;
      }
    }
    else if ((param_1 != 0x81) && (param_1 == 0x83)) goto LAB_80015b80;
    if (*(char *)((int)param_2 + 7) != '@') {
      return 0;
    }
  }
  return 1;
}


// ==== FUN_80015bac @ 80015bac

char FUN_80015bac(char *param_1,char *param_2)

{
  char cVar1;
  int iVar2;
  char *pcVar3;
  char *pcVar4;
  char *pcVar5;
  
  iVar2 = 0;
  pcVar4 = param_2;
  do {
    pcVar3 = pcVar4;
    pcVar5 = param_1;
    if ((*param_1 == '.') || (*param_1 == '\0')) break;
    pcVar5 = param_1 + 1;
    pcVar3 = pcVar4 + 1;
    *pcVar4 = *param_1;
    iVar2 = iVar2 + 1;
    pcVar4 = pcVar3;
    param_1 = pcVar5;
  } while (iVar2 < 8);
  for (; iVar2 < 8; iVar2 = iVar2 + 1) {
    *pcVar3 = ' ';
    pcVar3 = pcVar3 + 1;
  }
  if (*pcVar5 == '.') {
    pcVar5 = pcVar5 + 1;
  }
  iVar2 = 0;
  pcVar4 = param_2 + 8;
  do {
    cVar1 = *pcVar5;
    pcVar3 = pcVar4;
    if (cVar1 == '\0') break;
    cVar1 = *pcVar5;
    pcVar3 = pcVar4 + 1;
    *pcVar4 = cVar1;
    iVar2 = iVar2 + 1;
    pcVar4 = pcVar3;
    pcVar5 = pcVar5 + 1;
  } while (iVar2 < 3);
  for (; iVar2 < 3; iVar2 = iVar2 + 1) {
    *pcVar3 = ' ';
    pcVar3 = pcVar3 + 1;
  }
  return cVar1;
}


// ==== FUN_80015c14 @ 80015c14

void FUN_80015c14(char *param_1,char *param_2)

{
  bool bVar1;
  ushort uVar2;
  char *pcVar3;
  char *pcVar4;
  char *pcVar5;
  
  bVar1 = false;
  uVar2 = 0;
  pcVar5 = param_1;
  do {
    pcVar3 = param_2;
    if (*pcVar5 == ' ') break;
    pcVar3 = param_2 + 1;
    *param_2 = *pcVar5;
    uVar2 = uVar2 + 1;
    param_2 = pcVar3;
    pcVar5 = pcVar5 + 1;
  } while (uVar2 < 8);
  uVar2 = 0;
  pcVar5 = param_1 + 8;
  do {
    if (*pcVar5 == ' ') break;
    pcVar4 = pcVar3;
    if (!bVar1) {
      pcVar4 = pcVar3 + 1;
      *pcVar3 = '.';
      bVar1 = true;
    }
    pcVar3 = pcVar4 + 1;
    *pcVar4 = *pcVar5;
    uVar2 = uVar2 + 1;
    pcVar5 = pcVar5 + 1;
  } while (uVar2 < 3);
  *pcVar3 = '\0';
  return;
}


// ==== FUN_80015c6c @ 80015c6c

void FUN_80015c6c(int param_1)

{
  int iVar1;
  char *pcVar2;
  
  pcVar2 = (char *)(param_1 + 6);
  iVar1 = 0;
  do {
    pcVar2 = pcVar2 + -1;
    if (*pcVar2 != '_') break;
    *pcVar2 = ' ';
    iVar1 = iVar1 + 1;
  } while (iVar1 < 5);
  *(undefined1 *)(param_1 + 6) = 0x20;
  *(undefined1 *)(param_1 + 7) = 0x20;
  return;
}


// ==== FUN_80015ca0 @ 80015ca0

undefined4 FUN_80015ca0(ushort param_1)

{
  undefined4 uVar1;
  
  if ((param_1 < 4) || (5 < param_1)) {
    if ((param_1 < 6) || (7 < param_1)) {
      if ((param_1 < 8) || (9 < param_1)) {
        if ((param_1 < 0xc) || (0xd < param_1)) {
          if (param_1 == 0x10) {
            uVar1 = 4;
          }
          else if (param_1 == 0x11) {
            uVar1 = 5;
          }
          else if (param_1 == 0x12) {
            uVar1 = 6;
          }
          else {
            uVar1 = 1;
          }
        }
        else {
          uVar1 = 0x83;
        }
      }
      else {
        uVar1 = 0x81;
      }
    }
    else {
      uVar1 = 2;
    }
  }
  else {
    uVar1 = 3;
  }
  return uVar1;
}


// ==== FUN_80015d14 @ 80015d14

void FUN_80015d14(undefined1 *param_1,undefined1 *param_2,int param_3)

{
  int iVar1;
  
  iVar1 = 0;
  if (0 < param_3) {
    do {
      *param_2 = *param_1;
      iVar1 = iVar1 + 1;
      param_1 = param_1 + 1;
      param_2 = param_2 + 1;
    } while (iVar1 < param_3);
  }
  return;
}


// ==== FUN_80015d38 @ 80015d38

void FUN_80015d38(int param_1,int param_2,int param_3)

{
  int iVar1;
  undefined1 *puVar2;
  undefined1 *puVar3;
  
  puVar3 = (undefined1 *)(param_3 + param_2);
  puVar2 = (undefined1 *)(param_3 + param_1);
  iVar1 = 0;
  if (0 < param_3) {
    do {
      puVar3 = puVar3 + -1;
      puVar2 = puVar2 + -1;
      *puVar3 = *puVar2;
      iVar1 = iVar1 + 1;
    } while (iVar1 < param_3);
  }
  return;
}


// ==== FUN_80015d68 @ 80015d68

undefined4 FUN_80015d68(ushort param_1,char *param_2)

{
  char cVar1;
  undefined3 uVar2;
  undefined4 uVar3;
  char cVar4;
  char local_8 [4];
  
  local_8[0] = (char)((param_1 / 0x28) / 0x28);
  local_8[1] = (char)((param_1 / 0x28) % 0x28);
  local_8[2] = (char)(param_1 % 0x28);
  cVar4 = '\0';
  do {
    uVar2 = (undefined3)((uint)(int)cVar4 >> 8);
    uVar3 = CONCAT31(uVar2,local_8[cVar4]);
    if (local_8[cVar4] == '\0') {
      *param_2 = ' ';
    }
    else if ((local_8[cVar4] < '\x01') || ('\x1a' < local_8[cVar4])) {
      uVar3 = CONCAT31((int3)((uint)(int)cVar4 >> 8),local_8[cVar4]);
      if (local_8[cVar4] == '\x1b') {
        *param_2 = '$';
      }
      else {
        uVar2 = (undefined3)((uint)(int)cVar4 >> 8);
        uVar3 = CONCAT31(uVar2,local_8[cVar4]);
        if (local_8[cVar4] == '\x1c') {
          *param_2 = '.';
        }
        else {
          cVar1 = local_8[cVar4];
          if ((cVar1 < '\x1e') || (cVar1 = local_8[cVar4], '\'' < cVar1)) {
            uVar3 = CONCAT31(uVar2,cVar1);
            *param_2 = '\x1d';
          }
          else {
            uVar3 = CONCAT31(uVar2,local_8[cVar4] + '\x12');
            *param_2 = local_8[cVar4] + '\x12';
          }
        }
      }
    }
    else {
      uVar3 = CONCAT31(uVar2,local_8[cVar4] + '@');
      *param_2 = local_8[cVar4] + '@';
    }
    param_2 = param_2 + 1;
    cVar4 = cVar4 + '\x01';
  } while (cVar4 < '\x03');
  *param_2 = '\0';
  return uVar3;
}


// ==== FUN_80015e48 @ 80015e48

uint FUN_80015e48(uint *param_1,uint *param_2,int param_3)

{
  uint uVar1;
  ushort uVar2;
  short sVar3;
  uint *puVar4;
  uint *puVar5;
  uint *puVar6;
  uint *puVar7;
  
  if (param_3 == 0) {
    if (*(char *)param_1 == '\0') {
      return 0;
    }
    do {
      puVar4 = (uint *)((int)param_1 + 1);
      *(undefined1 *)param_2 = *(undefined1 *)param_1;
      param_1 = puVar4;
      param_2 = (uint *)((int)param_2 + 1);
    } while (*(char *)puVar4 != '\0');
    return 0;
  }
  uVar1 = (uint)param_2 & 3 | ((uint)param_1 & 3) << 4;
  puVar4 = param_1;
  puVar6 = param_2;
  switch(uVar1) {
  case 0:
    for (; 0x1f < param_3; param_3 = param_3 + -0x20) {
      *param_2 = *param_1;
      param_2[1] = param_1[1];
      param_2[2] = param_1[2];
      param_2[3] = param_1[3];
      param_2[4] = param_1[4];
      param_2[5] = param_1[5];
      param_2[6] = param_1[6];
      param_2[7] = param_1[7];
      param_2 = param_2 + 8;
      param_1 = param_1 + 8;
    }
    for (; 0xf < param_3; param_3 = param_3 + -0x10) {
      *param_2 = *param_1;
      param_2[1] = param_1[1];
      param_2[2] = param_1[2];
      param_2[3] = param_1[3];
      param_2 = param_2 + 4;
      param_1 = param_1 + 4;
    }
    for (; 3 < param_3; param_3 = param_3 + -4) {
      uVar1 = *param_1;
      *param_2 = uVar1;
      param_1 = param_1 + 1;
      param_2 = param_2 + 1;
    }
    if ((param_3 != 0) && (param_3 = param_3 + -1, param_3 != -1)) {
      do {
        do {
          puVar4 = (uint *)((int)param_1 + 1);
          uVar1 = (uint)*(byte *)param_1;
          puVar6 = (uint *)((int)param_2 + 1);
          *(byte *)param_2 = *(byte *)param_1;
          uVar2 = (ushort)((uint)param_3 >> 0x10);
          sVar3 = (short)param_3 + -1;
          param_3 = CONCAT22(uVar2,sVar3);
          param_1 = puVar4;
          param_2 = puVar6;
        } while (sVar3 != -1);
        param_3 = (uint)uVar2 * 0x10000 + -1;
      } while (uVar2 != 0);
    }
    break;
  case 1:
  case 3:
  case 0x10:
  case 0x12:
  case 0x21:
  case 0x23:
  case 0x30:
  case 0x32:
    param_3 = param_3 + -1;
    if (param_3 != -1) {
      do {
        do {
          puVar4 = (uint *)((int)param_1 + 1);
          uVar1 = (uint)*(byte *)param_1;
          puVar6 = (uint *)((int)param_2 + 1);
          *(byte *)param_2 = *(byte *)param_1;
          uVar2 = (ushort)((uint)param_3 >> 0x10);
          sVar3 = (short)param_3 + -1;
          param_3 = CONCAT22(uVar2,sVar3);
          param_1 = puVar4;
          param_2 = puVar6;
        } while (sVar3 != -1);
        param_3 = (uint)uVar2 * 0x10000 + -1;
      } while (uVar2 != 0);
    }
    break;
  case 2:
  case 0x20:
  case 0x22:
    for (; 0xf < param_3; param_3 = param_3 + -0x10) {
      *(ushort *)puVar6 = *(ushort *)puVar4;
      *(ushort *)((int)puVar6 + 2) = (ushort)*puVar4;
      *(ushort *)(puVar6 + 1) = *(ushort *)(puVar4 + 1);
      *(ushort *)((int)puVar6 + 6) = *(ushort *)((int)puVar4 + 6);
      *(ushort *)(puVar6 + 2) = *(ushort *)(puVar4 + 2);
      *(ushort *)((int)puVar6 + 10) = *(ushort *)((int)puVar4 + 10);
      *(ushort *)(puVar6 + 3) = *(ushort *)(puVar4 + 3);
      *(ushort *)((int)puVar6 + 0xe) = *(ushort *)((int)puVar4 + 0xe);
      puVar6 = puVar6 + 4;
      puVar4 = puVar4 + 4;
    }
    for (; 7 < param_3; param_3 = param_3 + -8) {
      *(ushort *)puVar6 = *(ushort *)puVar4;
      *(ushort *)((int)puVar6 + 2) = (ushort)*puVar4;
      *(ushort *)(puVar6 + 1) = *(ushort *)(puVar4 + 1);
      *(ushort *)((int)puVar6 + 6) = *(ushort *)((int)puVar4 + 6);
      puVar6 = puVar6 + 2;
      puVar4 = puVar4 + 2;
    }
    for (; 1 < param_3; param_3 = param_3 + -2) {
      uVar1 = (uint)*(ushort *)puVar4;
      *(ushort *)puVar6 = *(ushort *)puVar4;
      puVar4 = (uint *)((int)puVar4 + 2);
      puVar6 = (uint *)((int)puVar6 + 2);
    }
    goto LAB_8001608a;
  case 0x11:
  case 0x13:
  case 0x31:
    puVar4 = (uint *)((int)param_1 + 1);
    uVar1 = (uint)*(byte *)param_1;
    puVar6 = (uint *)((int)param_2 + 1);
    *(byte *)param_2 = *(byte *)param_1;
    for (param_3 = param_3 + -1; 0xf < param_3; param_3 = param_3 + -0x10) {
      *(ushort *)puVar6 = *(ushort *)puVar4;
      *(ushort *)((int)puVar6 + 2) = (ushort)*puVar4;
      *(ushort *)(puVar6 + 1) = *(ushort *)(puVar4 + 1);
      *(ushort *)((int)puVar6 + 6) = *(ushort *)((int)puVar4 + 6);
      *(ushort *)(puVar6 + 2) = *(ushort *)(puVar4 + 2);
      *(ushort *)((int)puVar6 + 10) = *(ushort *)((int)puVar4 + 10);
      *(ushort *)(puVar6 + 3) = *(ushort *)(puVar4 + 3);
      *(ushort *)((int)puVar6 + 0xe) = *(ushort *)((int)puVar4 + 0xe);
      puVar6 = puVar6 + 4;
      puVar4 = puVar4 + 4;
    }
    for (; 7 < param_3; param_3 = param_3 + -8) {
      *(ushort *)puVar6 = *(ushort *)puVar4;
      *(ushort *)((int)puVar6 + 2) = (ushort)*puVar4;
      *(ushort *)(puVar6 + 1) = *(ushort *)(puVar4 + 1);
      *(ushort *)((int)puVar6 + 6) = *(ushort *)((int)puVar4 + 6);
      puVar6 = puVar6 + 2;
      puVar4 = puVar4 + 2;
    }
    for (; 1 < param_3; param_3 = param_3 + -2) {
      uVar1 = (uint)*(ushort *)puVar4;
      *(ushort *)puVar6 = *(ushort *)puVar4;
      puVar4 = (uint *)((int)puVar4 + 2);
      puVar6 = (uint *)((int)puVar6 + 2);
    }
LAB_8001608a:
    if (param_3 != 0) {
      uVar1 = (uint)*(byte *)puVar4;
      *(byte *)puVar6 = *(byte *)puVar4;
    }
    break;
  case 0x33:
    puVar4 = (uint *)((int)param_1 + 1);
    uVar1 = (uint)*(byte *)param_1;
    puVar6 = (uint *)((int)param_2 + 1);
    *(byte *)param_2 = *(byte *)param_1;
    for (param_3 = param_3 + -1; 0x1f < param_3; param_3 = param_3 + -0x20) {
      *puVar6 = *puVar4;
      puVar6[1] = puVar4[1];
      puVar6[2] = puVar4[2];
      puVar6[3] = puVar4[3];
      puVar6[4] = puVar4[4];
      puVar6[5] = puVar4[5];
      puVar6[6] = puVar4[6];
      puVar6[7] = puVar4[7];
      puVar6 = puVar6 + 8;
      puVar4 = puVar4 + 8;
    }
    for (; 0xf < param_3; param_3 = param_3 + -0x10) {
      *puVar6 = *puVar4;
      puVar6[1] = puVar4[1];
      puVar6[2] = puVar4[2];
      puVar6[3] = puVar4[3];
      puVar6 = puVar6 + 4;
      puVar4 = puVar4 + 4;
    }
    for (; 3 < param_3; param_3 = param_3 + -4) {
      uVar1 = *puVar4;
      *puVar6 = uVar1;
      puVar4 = puVar4 + 1;
      puVar6 = puVar6 + 1;
    }
    if ((param_3 != 0) && (param_3 = param_3 + -1, param_3 != -1)) {
      do {
        do {
          puVar5 = (uint *)((int)puVar4 + 1);
          uVar1 = (uint)*(byte *)puVar4;
          puVar7 = (uint *)((int)puVar6 + 1);
          *(byte *)puVar6 = *(byte *)puVar4;
          uVar2 = (ushort)((uint)param_3 >> 0x10);
          sVar3 = (short)param_3 + -1;
          param_3 = CONCAT22(uVar2,sVar3);
          puVar4 = puVar5;
          puVar6 = puVar7;
        } while (sVar3 != -1);
        param_3 = (uint)uVar2 * 0x10000 + -1;
      } while (uVar2 != 0);
    }
  }
  return uVar1;
}


// ==== FUN_80016134 @ 80016134

uint FUN_80016134(uint *param_1,int param_2,undefined1 param_3)

{
  uint uVar1;
  
  uVar1 = (uint)param_1 & 3;
  if (uVar1 != 0) {
    for (; (param_2 != 0 && (uVar1 = (uint)param_1 & 3, uVar1 != 0));
        param_1 = (uint *)((int)param_1 + 1)) {
      *(undefined1 *)param_1 = param_3;
      param_2 = param_2 + -1;
    }
  }
  if (3 < param_2) {
    uVar1 = CONCAT13(param_3,CONCAT12(param_3,CONCAT11(param_3,param_3)));
    for (; 0x1f < param_2; param_2 = param_2 + -0x20) {
      *param_1 = uVar1;
      param_1[1] = uVar1;
      param_1[2] = uVar1;
      param_1[3] = uVar1;
      param_1[4] = uVar1;
      param_1[5] = uVar1;
      param_1[6] = uVar1;
      param_1[7] = uVar1;
      param_1 = param_1 + 8;
    }
    for (; 0xf < param_2; param_2 = param_2 + -0x10) {
      *param_1 = uVar1;
      param_1[1] = uVar1;
      param_1[2] = uVar1;
      param_1[3] = uVar1;
      param_1 = param_1 + 4;
    }
    for (; 3 < param_2; param_2 = param_2 + -4) {
      *param_1 = uVar1;
      param_1 = param_1 + 1;
    }
  }
  for (; param_2 != 0; param_2 = param_2 + -1) {
    *(undefined1 *)param_1 = param_3;
    param_1 = (uint *)((int)param_1 + 1);
  }
  return uVar1;
}


// ==== FUN_800161f0 @ 800161f0

void FUN_800161f0(char *param_1,char *param_2)

{
  char cVar1;
  
  do {
    cVar1 = *param_1;
    *param_2 = cVar1;
    param_2 = param_2 + 1;
    param_1 = param_1 + 1;
  } while (cVar1 != '\0');
  return;
}


// ==== FUN_80016210 @ 80016210

void FUN_80016210(char *param_1,char *param_2,int param_3)

{
  while( true ) {
    if (param_3 == 0) {
      return;
    }
    if (*param_2 != *param_1) break;
    param_3 = param_3 + -1;
    param_1 = param_1 + 1;
    param_2 = param_2 + 1;
  }
  return;
}


// ==== FUN_80016238 @ 80016238

void FUN_80016238(char *param_1,char *param_2)

{
  char cVar1;
  
  do {
    cVar1 = *param_2;
    *param_1 = cVar1;
    param_1 = param_1 + 1;
    param_2 = param_2 + 1;
  } while (cVar1 != '\0');
  return;
}


// ==== FUN_80016254 @ 80016254

int FUN_80016254(char *param_1)

{
  int iVar1;
  
  iVar1 = 0;
  while( true ) {
    if (*param_1 == '\0') break;
    iVar1 = iVar1 + 1;
    param_1 = param_1 + 1;
  }
  return iVar1;
}


// ==== FUN_8001626c @ 8001626c

void FUN_8001626c(void)

{
  FUN_800162ec();
  return;
}


// ==== FUN_80016274 @ 80016274

void FUN_80016274(void)

{
  FUN_800162ec();
  return;
}


// ==== FUN_8001627c @ 8001627c

void FUN_8001627c(void)

{
  FUN_800162ec();
  return;
}


// ==== FUN_80016284 @ 80016284

void FUN_80016284(void)

{
  FUN_800162ec();
  return;
}


// ==== FUN_8001628c @ 8001628c

void FUN_8001628c(void)

{
  FUN_800162ec();
  return;
}


// ==== FUN_80016294 @ 80016294

void FUN_80016294(void)

{
  FUN_800162ec();
  return;
}


// ==== FUN_8001629c @ 8001629c

void FUN_8001629c(void)

{
  FUN_800162ec();
  return;
}


// ==== FUN_800162a4 @ 800162a4

void FUN_800162a4(void)

{
  FUN_800162ec();
  return;
}


// ==== FUN_800162ac @ 800162ac

void FUN_800162ac(void)

{
  FUN_800162ec();
  return;
}


// ==== FUN_800162b4 @ 800162b4

void FUN_800162b4(void)

{
  FUN_800162ec();
  return;
}


// ==== FUN_800162bc @ 800162bc

void FUN_800162bc(void)

{
  FUN_800162ec();
  return;
}


// ==== FUN_800162c4 @ 800162c4

void FUN_800162c4(void)

{
  FUN_800162ec();
  return;
}


// ==== FUN_800162cc @ 800162cc

void FUN_800162cc(void)

{
  FUN_800162ec();
  return;
}


// ==== FUN_800162d4 @ 800162d4

void FUN_800162d4(void)

{
  FUN_800162f4();
  return;
}


// ==== FUN_800162dc @ 800162dc

void FUN_800162dc(void)

{
  FUN_800162f4();
  return;
}


// ==== FUN_800162e4 @ 800162e4

undefined4 FUN_800162e4(void)

{
  __m68k_trap(4);
  return 0;
}


// ==== FUN_800162ec @ 800162ec

void FUN_800162ec(void)

{
  __m68k_trap(1);
  return;
}


// ==== FUN_800162f4 @ 800162f4

void FUN_800162f4(void)

{
  __m68k_trap(2);
  return;
}


// ==== FUN_800162fc @ 800162fc

void FUN_800162fc(int param_1,uint *param_2)

{
  uint unaff_D7;
  undefined1 local_8 [4];
  
  *(undefined1 **)(param_1 + 4) = local_8;
  FUN_800136c0(0x18,7,param_1,0x8000000);
  *param_2 = *param_2 | unaff_D7;
  *param_2 = *param_2 & 0xf7ffffff;
  return;
}


// ==== FUN_80016344 @ 80016344

void FUN_80016344(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  undefined4 local_1c [2];
  undefined4 local_14;
  undefined4 local_10;
  
  local_1c[0] = 3;
  local_14 = param_2;
  local_10 = param_3;
  FUN_800162fc(local_1c,param_4);
  return;
}


// ==== FUN_8001636c @ 8001636c

void FUN_8001636c(short param_1,undefined4 param_2)

{
  undefined4 local_1c [2];
  int local_14;
  
  local_1c[0] = 6;
  local_14 = (int)param_1;
  FUN_800162fc(local_1c,param_2);
  return;
}


// ==== FUN_80016392 @ 80016392

void FUN_80016392(short param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  undefined4 local_1c [2];
  int local_14;
  undefined4 local_10;
  undefined4 local_c;
  
  local_1c[0] = 4;
  local_14 = (int)param_1;
  local_10 = param_2;
  local_c = param_3;
  FUN_800162fc(local_1c,param_4);
  return;
}


// ==== FUN_800163c4 @ 800163c4

void FUN_800163c4(short param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  undefined4 local_1c [2];
  int local_14;
  undefined4 local_10;
  undefined4 local_c;
  
  local_1c[0] = 5;
  local_14 = (int)param_1;
  local_10 = param_2;
  local_c = param_3;
  FUN_800162fc(local_1c,param_4);
  return;
}


// ==== FUN_800163f6 @ 800163f6

void FUN_800163f6(short param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  undefined4 local_1c [2];
  int local_14;
  undefined4 local_10;
  undefined4 local_c;
  
  local_1c[0] = 7;
  local_14 = (int)param_1;
  local_10 = param_2;
  local_c = param_3;
  FUN_800162fc(local_1c,param_4);
  return;
}


// ==== FUN_80016428 @ 80016428

void FUN_80016428(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  undefined4 local_1c [2];
  undefined4 local_14;
  
  local_1c[0] = 1;
  local_14 = param_2;
  FUN_800162fc(local_1c,param_3);
  return;
}


// ==== FUN_8001644a @ 8001644a

void FUN_8001644a(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  undefined4 local_1c [2];
  undefined4 local_14;
  
  local_1c[0] = 2;
  local_14 = param_2;
  FUN_800162fc(local_1c,param_3);
  return;
}


// ==== FUN_8001646c @ 8001646c

void FUN_8001646c(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5)

{
  undefined4 local_1c [2];
  undefined4 local_14;
  undefined4 local_10;
  undefined4 local_c;
  undefined4 local_8;
  
  local_1c[0] = 9;
  local_10 = param_2;
  local_c = param_3;
  local_8 = param_4;
  local_14 = param_1;
  FUN_800162fc(local_1c,param_5);
  return;
}


// ==== FUN_800164a0 @ 800164a0

void FUN_800164a0(undefined4 param_1,undefined4 param_2)

{
  undefined4 local_1c [5];
  undefined4 local_8;
  
  local_1c[0] = 10;
  local_8 = param_1;
  FUN_800162fc(local_1c,param_2);
  return;
}


// ==== FUN_800164c2 @ 800164c2

void FUN_800164c2(undefined4 param_1,uint *param_2)

{
  uint unaff_D7;
  undefined4 local_1c;
  undefined4 local_18;
  
  local_1c = 8;
  local_18 = param_1;
  FUN_800136c0(0x18,7,&local_1c,0x8000000);
  *param_2 = *param_2 | unaff_D7;
  return;
}


// ==== FUN_800164fe @ 800164fe

void FUN_800164fe(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5)

{
  undefined4 local_1c;
  undefined4 local_18;
  undefined4 local_14;
  undefined4 local_10;
  
  local_1c = 3;
  local_14 = param_2;
  local_10 = param_3;
  local_18 = param_5;
  FUN_800162b4(0x18,7,&local_1c);
  return;
}


// ==== FUN_80016530 @ 80016530

void FUN_80016530(short param_1,undefined4 param_2,undefined4 param_3)

{
  undefined4 local_1c;
  undefined4 local_18;
  int local_14;
  
  local_1c = 6;
  local_14 = (int)param_1;
  local_18 = param_3;
  FUN_800162b4(0x18,7,&local_1c);
  return;
}


// ==== FUN_80016560 @ 80016560

void FUN_80016560(short param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5)

{
  undefined4 local_1c;
  undefined4 local_18;
  int local_14;
  undefined4 local_10;
  undefined4 local_c;
  
  local_1c = 4;
  local_14 = (int)param_1;
  local_10 = param_2;
  local_c = param_3;
  local_18 = param_5;
  FUN_800162b4(0x18,7,&local_1c);
  return;
}


// ==== FUN_8001659c @ 8001659c

void FUN_8001659c(short param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5)

{
  undefined4 local_1c;
  undefined4 local_18;
  int local_14;
  undefined4 local_10;
  undefined4 local_c;
  
  local_1c = 5;
  local_14 = (int)param_1;
  local_10 = param_2;
  local_c = param_3;
  local_18 = param_5;
  FUN_800162b4(0x18,7,&local_1c);
  return;
}


// ==== FUN_800165d8 @ 800165d8

void FUN_800165d8(short param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4,
                 undefined4 param_5)

{
  undefined4 local_1c;
  undefined4 local_18;
  int local_14;
  undefined4 local_10;
  undefined4 local_c;
  
  local_1c = 7;
  local_14 = (int)param_1;
  local_10 = param_2;
  local_c = param_3;
  local_18 = param_5;
  FUN_800162b4(0x18,7,&local_1c);
  return;
}


// ==== FUN_80016614 @ 80016614

void FUN_80016614(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  undefined4 local_1c;
  undefined4 local_18;
  undefined4 local_14;
  
  local_1c = 1;
  local_14 = param_2;
  local_18 = param_4;
  FUN_800162b4(0x18,7,&local_1c);
  return;
}


// ==== FUN_80016640 @ 80016640

void FUN_80016640(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  undefined4 local_1c;
  undefined4 local_18;
  undefined4 local_14;
  
  local_1c = 2;
  local_14 = param_2;
  local_18 = param_4;
  FUN_800162b4(0x18,7,&local_1c);
  return;
}


// ==== FUN_8001666c @ 8001666c

void FUN_8001666c(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  undefined1 auStack_18 [8];
  undefined4 local_10;
  undefined4 local_c;
  
  local_10 = param_1;
  local_c = param_2;
  FUN_80016b7e(auStack_18,0x20,param_3);
  return;
}


// ==== FUN_80016694 @ 80016694

void FUN_80016694(undefined4 param_1,undefined4 param_2)

{
  undefined1 auStack_18 [8];
  undefined4 local_10;
  
  local_10 = param_1;
  FUN_80016b7e(auStack_18,0x21,param_2);
  return;
}


// ==== FUN_800166b6 @ 800166b6

void FUN_800166b6(undefined4 param_1,int param_2,int param_3,undefined4 param_4)

{
  int iVar1;
  int iVar2;
  int unaff_D7;
  undefined1 auStack_18 [8];
  undefined4 local_10;
  int local_c;
  int local_8;
  
  local_10 = param_1;
  local_8 = param_2;
  while( true ) {
    if (param_3 == 0) {
      return;
    }
    if (param_3 < 0x400) {
      iVar1 = 0;
      iVar2 = local_8;
      local_c = param_3;
    }
    else {
      local_c = 0x400;
      iVar2 = local_8 + 0x400;
      iVar1 = param_3 + -0x400;
    }
    FUN_80016b7e(auStack_18,0x22,param_4);
    if (unaff_D7 == -0xed) break;
    local_8 = iVar2;
    param_3 = iVar1;
    if (unaff_D7 < 0) {
      return;
    }
  }
  return;
}


// ==== FUN_80016734 @ 80016734

void FUN_80016734(undefined4 param_1,char *param_2,undefined4 param_3)

{
  char *pcVar1;
  char local_24 [12];
  undefined1 auStack_18 [8];
  undefined4 local_10;
  char *local_c;
  
  local_10 = param_1;
  pcVar1 = local_24;
  for (; (*param_2 != '\0' && (*param_2 != ':')); param_2 = param_2 + 1) {
    *pcVar1 = *param_2;
    pcVar1 = pcVar1 + 1;
  }
  *pcVar1 = '\0';
  local_c = local_24;
  FUN_80016b7e(auStack_18,0x23,param_3);
  return;
}


// ==== FUN_80016778 @ 80016778

void FUN_80016778(int param_1,undefined4 param_2)

{
  undefined1 auStack_18 [8];
  int local_10;
  
  if (param_1 != 0) {
    local_10 = param_1;
    FUN_80016b7e(auStack_18,0x24,param_2);
  }
  return;
}


// ==== FUN_800167a6 @ 800167a6

void FUN_800167a6(undefined4 param_1,undefined4 param_2,undefined1 param_3,undefined4 param_4)

{
  undefined1 auStack_18 [8];
  undefined4 local_10;
  undefined4 local_c;
  undefined1 local_8;
  
  local_10 = param_1;
  local_c = param_2;
  local_8 = param_3;
  FUN_80016b7e(auStack_18,0x25,param_4);
  return;
}


// ==== FUN_800167d6 @ 800167d6

void FUN_800167d6(undefined4 param_1,undefined4 param_2)

{
  undefined1 auStack_18 [8];
  undefined4 local_10;
  
  local_10 = param_1;
  FUN_800162cc(0,100);
  FUN_80016b7e(auStack_18,0x26,param_2);
  return;
}


// ==== FUN_80016804 @ 80016804

void FUN_80016804(undefined4 param_1,int param_2,int param_3,undefined4 param_4)

{
  int iVar1;
  int iVar2;
  int unaff_D7;
  undefined1 auStack_18 [8];
  undefined4 local_10;
  int local_c;
  int local_8;
  
  local_10 = param_1;
  local_8 = param_3;
  while( true ) {
    if (param_2 == 0) {
      return;
    }
    if (param_2 < 0x400) {
      iVar1 = 0;
      iVar2 = local_8;
      local_c = param_2;
    }
    else {
      local_c = 0x400;
      iVar2 = local_8 + 0x400;
      iVar1 = param_2 + -0x400;
    }
    FUN_80016b7e(auStack_18,0x27,param_4);
    if (unaff_D7 == -0xed) break;
    param_2 = iVar1;
    local_8 = iVar2;
    if (unaff_D7 < 0) {
      return;
    }
  }
  return;
}


// ==== FUN_80016892 @ 80016892

void FUN_80016892(undefined4 param_1,int param_2,int param_3,undefined4 param_4)

{
  int iVar1;
  int iVar2;
  int unaff_D7;
  undefined1 auStack_18 [8];
  undefined4 local_10;
  int local_c;
  int local_8;
  
  local_10 = param_1;
  local_8 = param_3;
  do {
    if (param_2 == 0) {
      return;
    }
    if (param_2 < 0x400) {
      iVar1 = 0;
      iVar2 = local_8;
      local_c = param_2;
    }
    else {
      local_c = 0x400;
      iVar2 = local_8 + 0x400;
      iVar1 = param_2 + -0x400;
    }
    FUN_80016b7e(auStack_18,0x28,param_4);
    param_2 = iVar1;
    local_8 = iVar2;
  } while (-1 < unaff_D7);
  return;
}


// ==== FUN_8001690a @ 8001690a

int FUN_8001690a(undefined4 param_1,int param_2,int param_3,int param_4,uint param_5,
                undefined4 param_6)

{
  int in_D1;
  int iVar1;
  int unaff_D7;
  int iVar2;
  undefined1 auStack_18 [8];
  undefined4 local_10;
  uint local_c;
  int local_8;
  
  if (param_4 < param_3) {
    in_D1 = -10;
  }
  else {
    param_3 = param_3 + -1;
    iVar2 = 0;
    local_10 = param_1;
    for (param_4 = param_4 - param_3; 0 < param_4; param_4 = param_4 - unaff_D7) {
      if ((uint)(param_4 * 0x20) < 0x401) {
        iVar1 = param_4;
      }
      else {
        iVar1 = 0x20;
      }
      local_c = param_5 | iVar1 + param_3 & 0xffffU | param_3 << 0x10;
      local_8 = param_2;
      FUN_80016b7e(auStack_18,0x29,param_6);
      in_D1 = unaff_D7;
      if ((unaff_D7 < 0) || (iVar2 = unaff_D7 + iVar2, unaff_D7 < iVar1)) break;
      param_2 = unaff_D7 * 0x20 + param_2;
      param_3 = unaff_D7 + param_3;
    }
    if (iVar2 != 0) {
      in_D1 = iVar2;
    }
  }
  return in_D1;
}


// ==== FUN_800169ba @ 800169ba

void FUN_800169ba(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  undefined1 auStack_18 [8];
  undefined4 local_10;
  undefined4 local_c;
  
  local_10 = param_1;
  local_c = param_2;
  FUN_80016b7e(auStack_18,0x2a,param_3);
  return;
}


// ==== FUN_800169e2 @ 800169e2

void FUN_800169e2(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  undefined1 auStack_18 [8];
  undefined4 local_10;
  undefined4 local_c;
  undefined4 local_8;
  
  local_10 = param_1;
  local_c = param_2;
  local_8 = param_3;
  FUN_80016b7e(auStack_18,0x2b,param_4);
  return;
}


// ==== FUN_80016a10 @ 80016a10

void FUN_80016a10(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  undefined1 auStack_18 [8];
  undefined4 local_10;
  undefined4 local_c;
  
  local_10 = param_1;
  local_c = param_2;
  FUN_80016b7e(auStack_18,0x2c,param_3);
  return;
}


// ==== FUN_80016a38 @ 80016a38

void FUN_80016a38(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  undefined1 auStack_18 [8];
  undefined4 local_10;
  undefined4 local_c;
  
  local_10 = param_1;
  local_c = param_2;
  FUN_80016b7e(auStack_18,0x2d,param_3);
  return;
}


// ==== FUN_80016a60 @ 80016a60

void FUN_80016a60(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  undefined1 auStack_18 [8];
  undefined4 local_10;
  undefined4 local_c;
  
  local_10 = param_1;
  local_c = param_2;
  FUN_80016b7e(auStack_18,0x2e,param_3);
  return;
}


// ==== FUN_80016a88 @ 80016a88

void FUN_80016a88(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  undefined1 auStack_18 [8];
  undefined4 local_10;
  undefined4 local_c;
  
  local_10 = param_1;
  local_c = param_2;
  FUN_80016b7e(auStack_18,0x2f,param_3);
  return;
}


// ==== FUN_80016ab0 @ 80016ab0

void FUN_80016ab0(void)

{
  return;
}


// ==== FUN_80016ab8 @ 80016ab8

/* WARNING: Removing unreachable block (ram,0x80016b1a) */

void FUN_80016ab8(undefined4 param_1,undefined4 param_2,undefined4 param_3)

{
  int unaff_D7;
  undefined1 auStack_58 [64];
  undefined1 auStack_18 [8];
  undefined4 local_10;
  undefined4 local_c;
  
  local_10 = param_1;
  local_c = param_2;
  FUN_80016b7e(auStack_18,0x30,param_3);
  if (unaff_D7 == -0xfc) {
    FUN_8001690a(param_1,auStack_58,1,1,0,param_3);
  }
  return;
}


// ==== FUN_80016b46 @ 80016b46

void FUN_80016b46(undefined4 param_1,undefined4 param_2,undefined4 param_3,undefined4 param_4)

{
  undefined1 auStack_18 [8];
  undefined4 local_10;
  undefined4 local_c;
  undefined4 local_8;
  
  local_10 = param_1;
  local_c = param_2;
  local_8 = param_3;
  FUN_80016b7e(auStack_18,0x31,param_4);
  return;
}


// ==== FUN_80016b74 @ 80016b74

void FUN_80016b74(void)

{
  return;
}


// ==== FUN_80016b7e @ 80016b7e

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_80016b7e(undefined4 *param_1,undefined4 param_2,uint *param_3)

{
  uint uVar1;
  uint unaff_D7;
  undefined4 local_8;
  
  local_8 = 0;
  *param_1 = param_2;
  param_1[1] = &local_8;
  if ((_DAT_0ff03ff8 == -0xfaf800) && (FUN_800162b4(0x14,2,param_1), -1 < (int)unaff_D7)) {
    do {
      FUN_800162cc(0,1000);
      uVar1 = *param_3 | unaff_D7;
      *param_3 = uVar1;
      unaff_D7 = 0;
    } while ((uVar1 & 0x40000400) == 0);
    *param_3 = *param_3 & 0xbffffbff;
  }
  return;
}


