// ==== main @ 013e8024

/* WARNING: This function may have set the stack pointer */

void main(void)

{
  aplmain();
  return;
}


// ==== jmp_m @ 013e8038

void jmp_m(code *UNRECOVERED_JUMPTABLE)

{
                    /* WARNING: Could not recover jumptable at 0x013e803c. Too many branches */
                    /* WARNING: Treating indirect jump as call */
  (*UNRECOVERED_JUMPTABLE)();
  return;
}


// ==== eepwait @ 013e803e

void eepwait(void)

{
  int iVar1;
  
  do {
    iVar1 = FUN_013e8052();
  } while (iVar1 != 1);
  return;
}


// ==== FUN_013e8052 @ 013e8052

void FUN_013e8052(void)

{
  return;
}


// ==== dispinit @ 013e80bc

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void dispinit(void)

{
  _dsc_blink = 0;
  _dsc_rever = 0;
  _dsc_color = 7;
  _dsc_font = 0;
  cursor = Icursor;
  DAT_013ed004 = DAT_013e8080;
  DAT_013ed008 = DAT_013e8084;
  DAT_013ed00c = DAT_013e8088;
  DAT_013ed010 = DAT_013e808c;
  DAT_013ed014 = DAT_013e8090;
  DAT_013ed018 = DAT_013e8094;
  partition = Ipartitio;
  DAT_013ed020 = DAT_013e809c;
  DAT_013ed024 = DAT_013e80a0;
  DAT_013ed028 = DAT_013e80a4;
  DAT_013ed02c = DAT_013e80a8;
  DAT_013ed030 = DAT_013e80ac;
  DAT_013ed034 = DAT_013e80b0;
  DAT_013ed038 = DAT_013e80b4;
  DAT_013ed03c = DAT_013e80b8;
  fillvram(0xd000000,0x4000,0x20);
  fillppup(0xd010000,0x3000,0x20);
  do {
  } while ((_DAT_0d01c9c8 & 1) == 1);
  _DAT_0d01c9a2 = DAT_013ed010._2_2_ | DAT_013ed00c._2_2_ << 8 | cursor._2_2_ << 0xd;
  _DAT_0d01c9c0 = 0x8000;
  _DAT_0d01cffe = 0;
  return;
}


// ==== nrdydsp @ 013e8198

void nrdydsp(void)

{
  locdsc(0x20,0xe);
  coldsc(7);
  attrdsc(9);
  putsdsc("   INSERT DISK  ");
  return;
}


// ==== bootdsp @ 013e81e0

void bootdsp(void)

{
  locdsc(0x20,0xe);
  coldsc(7);
  attrdsc(9);
  putsdsc("  BOOTING UP... ");
  return;
}


// ==== faildsp @ 013e8228

void faildsp(void)

{
  locdsc(0x20,0xe);
  coldsc(7);
  attrdsc(9);
  putsdsc("                ");
  return;
}


// ==== idledsp @ 013e8270

void idledsp(void)

{
  locdsc(0x20,0xe);
  coldsc(7);
  attrdsc(9);
  putsdsc(" BOOTING FAILED ");
  return;
}


// ==== clswpdbx @ 013e82a6

void clswpdbx(void)

{
  attrdsc(1);
  filcdsc(0x14,0x17,0x28,0x20);
  filcdsc(0x14,0x18,0x28,0x20);
  filcdsc(0x14,0x19,0x28,0x20);
  return;
}


// ==== dboxdswp @ 013e8312

void dboxdswp(void)

{
  attrdsc(9);
  filcdsc(0x14,0x17,0x28,0x20);
  filcdsc(0x14,0x18,0xb,0x20);
  filcdsc(0x32,0x18,10,0x20);
  filcdsc(0x14,0x19,0x28,0x20);
  locdsc(0x1f,0x18);
  putsdsc(PTR_s_CHANGE_System_Disks_013ed044);
  return;
}


// ==== bt_prmpt @ 013e83aa

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void bt_prmpt(int param_1)

{
  undefined4 uVar1;
  
  uVar1 = 1;
  if (param_1 == 1) {
    uVar1 = 9;
  }
  attrdsc(uVar1);
  filcdsc(0x14,0xc,0x28,0x20);
  filcdsc(0x14,0xd,0x28,0x20);
  filcdsc(0x14,0xe,0x28,0x20);
  filcdsc(0x14,0xf,0x28,0x20);
  filcdsc(0x14,0x10,0x28,0x20);
  if (param_1 == 1) {
    locdsc(0x1f,0xe);
    _dsc_blink = 1;
    putsdsc("WARM START OK ?");
  }
  return;
}


// ==== filcdsc @ 013e8464

void filcdsc(int param_1,undefined4 param_2,int param_3,char param_4)

{
  if (0x4f - param_1 < param_3) {
    param_3 = 0x4f - param_1;
  }
  locdsc(param_1,param_2);
  fillvram(VRAMCP,(int)(short)param_3,(int)param_4);
  return;
}


// ==== putsdsc @ 013e84b0

void putsdsc(char *param_1)

{
  int unaff_D7;
  
  if (*param_1 != '\0') {
    while ((DAT_013ed004 < 0x4f || (DAT_013ed008 < 0x1c))) {
      *VRAMCP = (short)*param_1 | DAT_013f99aa << 8 | 0x5000U;
      VRAMCP = VRAMCP + 1;
      *VRAMCP = DAT_013f998e | DAT_013f99b2 << 0xe | DAT_013f998a << 0xf;
      VRAMCP = VRAMCP + 1;
      cursor_ri();
      if (unaff_D7 < 0) {
        return;
      }
      param_1 = param_1 + 1;
      if (*param_1 == '\0') {
        return;
      }
    }
  }
  return;
}


// ==== locdsc @ 013e8540

void locdsc(byte param_1,byte param_2)

{
  undefined4 unaff_D7;
  
  DAT_013ed004 = (uint)param_1;
  DAT_013ed008 = (uint)param_2;
  xy2vram(DAT_013ed004,DAT_013ed008);
  VRAMCP = unaff_D7;
  return;
}


// ==== coldsc @ 013e8572

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void coldsc(ushort param_1)

{
  if (param_1 < 0x10) {
    _dsc_color = (uint)param_1;
  }
  return;
}


// ==== attrdsc @ 013e8594

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void attrdsc(byte param_1)

{
  _dsc_blink = (byte)-((param_1 & 0x10) != 0) & 1;
  _dsc_font = (uint)(byte)(param_1 & 3 | (param_1 & 8) >> 1);
  return;
}


// ==== fillvram @ 013e85c8

void fillvram(ushort *param_1,short param_2,char param_3)

{
  ushort *puVar1;
  
  param_2 = param_2 + -1;
  if (-1 < param_2) {
    do {
      puVar1 = param_1 + 1;
      *param_1 = (short)param_3 | DAT_013f99aa << 8 | 0x5000U;
      param_1 = param_1 + 2;
      *puVar1 = DAT_013f998e;
      param_2 = param_2 + -1;
    } while (-1 < param_2);
  }
  return;
}


// ==== fillppup @ 013e8604

void fillppup(short *param_1,short param_2,char param_3)

{
  short *psVar1;
  
  param_2 = param_2 + -1;
  if (-1 < param_2) {
    do {
      psVar1 = param_1 + 1;
      *param_1 = (short)param_3;
      param_1 = param_1 + 2;
      *psVar1 = 0;
      param_2 = param_2 + -1;
    } while (-1 < param_2);
  }
  return;
}


// ==== xy2vram @ 013e8626

void xy2vram(void)

{
  return;
}


// ==== cursor_ri @ 013e86c4

void cursor_ri(void)

{
  DAT_013ed004 = DAT_013ed004 + 1;
  if (0x4f < DAT_013ed004) {
    DAT_013ed008 = DAT_013ed008 + 1;
    if (DAT_013ed008 < 0x1d) {
      DAT_013ed004 = 0;
    }
    else {
      DAT_013ed004 = 0x4f;
      DAT_013ed008 = 0x1c;
    }
  }
  cursor_co();
  return;
}


// ==== cursor_co @ 013e86fe

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void cursor_co(void)

{
  int unaff_D7;
  
  _DAT_0d01c9a2 = DAT_013ed010._2_2_ | DAT_013ed00c._2_2_ << 8 | cursor._2_2_ << 0xd;
  _DAT_0d01c9a4 = DAT_013ed014._2_2_;
  xy2vram(DAT_013ed004,DAT_013ed008);
  DAT_013ed018 = unaff_D7;
  if (unaff_D7 != 0) {
    _DAT_0d01c9a0 = (undefined2)(unaff_D7 + 0xf3000000U >> 2);
    _DAT_0d01cffe = 1;
  }
  return;
}


// ==== asgetdrv @ 013e8792

undefined4 asgetdrv(void)

{
  byte bVar1;
  undefined4 uVar2;
  
  bVar1 = DAT_0f00a7f9 & 7;
  if (bVar1 == 2) {
    uVar2 = 1;
  }
  else if ((bVar1 < 3) || (bVar1 != 4)) {
    uVar2 = 0;
  }
  else {
    uVar2 = 6;
  }
  return uVar2;
}


// ==== aplmain @ 013e87c2

/* WARNING: Removing unreachable block (ram,0x013e897a) */
/* WARNING: Removing unreachable block (ram,0x013e8980) */
/* WARNING: Removing unreachable block (ram,0x013e8968) */
/* WARNING: Removing unreachable block (ram,0x013e896e) */

void aplmain(void)

{
  int iVar1;
  FILE *unaff_D7;
  undefined4 local_8;
  
  local_8 = 0;
  asgetdrv();
  drv_num = unaff_D7;
  fs_mount();
  if ((int)unaff_D7 < 0) {
    idledsp();
    do {
                    /* WARNING: Do nothing block with infinite loop */
    } while( true );
  }
  fdrive(drv_num);
  fopen(bootfnm,iomode);
  if ((int)unaff_D7 < 0) {
    idledsp();
    do {
                    /* WARNING: Do nothing block with infinite loop */
    } while( true );
  }
  ewsl_open();
  if (unaff_D7 == (FILE *)0x0) {
    iVar1 = 2;
  }
  else {
    fclose(unaff_D7);
    if ((int)unaff_D7 < 0) {
      idledsp();
      do {
                    /* WARNING: Do nothing block with infinite loop */
      } while( true );
    }
    iVar1 = 1;
    fs_open(drv_num,bootfnm_f,iomode,&local_8);
    if ((int)unaff_D7 < 0) {
      idledsp();
      do {
                    /* WARNING: Do nothing block with infinite loop */
      } while( true );
    }
    fs_read(drv_num);
    if ((int)unaff_D7 < 0) {
      idledsp();
      do {
                    /* WARNING: Do nothing block with infinite loop */
      } while( true );
    }
  }
  if (iVar1 == 2) {
    ewsl_read(DAT_013ed05c,DAT_013ed04c);
  }
  else {
    fs_read(drv_num);
  }
  if ((int)unaff_D7 < 0) {
    idledsp();
    do {
                    /* WARNING: Do nothing block with infinite loop */
    } while( true );
  }
  if (iVar1 == 2) {
    ewsl_read(DAT_013ed060,DAT_013ed050);
  }
  else {
    fs_read(drv_num);
  }
  if ((int)unaff_D7 < 0) {
    idledsp();
    do {
                    /* WARNING: Do nothing block with infinite loop */
    } while( true );
  }
  if (iVar1 == 2) {
    do {
      ewsl_read(&symbfdmy,0x2000);
      if ((int)unaff_D7 < 0) {
        idledsp();
        do {
                    /* WARNING: Do nothing block with infinite loop */
        } while( true );
      }
    } while (unaff_D7 != (FILE *)0x0);
    ewsl_chec();
    ewsl_clos();
  }
  if (iVar1 == 2) {
    fclose(unaff_D7);
  }
  else {
    fs_clos(drv_num);
  }
  if (-1 < (int)unaff_D7) {
    jmp_m(DAT_013ed05c + 0x22);
    return;
  }
  idledsp();
  do {
                    /* WARNING: Do nothing block with infinite loop */
  } while( true );
}


// ==== abort @ 013e89d2

/* WARNING: Unknown calling convention -- yet parameter storage is locked */

void abort(void)

{
  idledsp();
  do {
                    /* WARNING: Do nothing block with infinite loop */
  } while( true );
}


// ==== dmahset @ 013e89e4

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void dmahset(undefined1 param_1,undefined4 param_2,short param_3)

{
  if (param_2._0_1_ == '\0') {
    DAT_0f00c000 = 0xc0;
  }
  else {
    DAT_0f00c000 = 0xc1;
  }
  piowait();
  DAT_0f008000 = param_1;
  dmawait();
  DAT_0f008007 = param_2._1_1_;
  dmawait();
  _DAT_0f008004 = param_2._2_2_;
  dmawait();
  _DAT_0f008002 = param_3 + -1;
  dmawait();
  return;
}


// ==== dmafc @ 013e8a48

void dmafc(undefined4 param_1)

{
  if (param_1._0_1_ == '\0') {
    DAT_0f00c000 = 0xc0;
  }
  else {
    DAT_0f00c000 = 0xc1;
  }
  piowait();
  return;
}


// ==== getdmact @ 013e8a70

void getdmact(void)

{
  return;
}


// ==== dma_init @ 013e8a7c

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void dma_init(void)

{
  DAT_0f008001 = 3;
  dma_cmd = 0;
  _dma_req = 0;
  _dma_wrmsk = 0xf;
  return;
}


// ==== dcon_off @ 013e8aa2

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void dcon_off(void)

{
  dma_cmd = dma_cmd | 4;
  _DAT_0f008008 = dma_cmd;
  return;
}


// ==== dcon_on @ 013e8ac2

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void dcon_on(void)

{
  dma_cmd = dma_cmd & 0xfffb;
  _DAT_0f008008 = dma_cmd;
  return;
}


// ==== dcon_ons @ 013e8ae2

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void dcon_ons(void)

{
  dma_cmd = 0x230;
  _DAT_0f008008 = 0x230;
  return;
}


// ==== dmod_read @ 013e8afc

void dmod_read(void)

{
  DAT_0f00800b = 0x44;
  return;
}


// ==== dmod_hrea @ 013e8b0e

void dmod_hrea(void)

{
  DAT_0f00800b = 0x44;
  return;
}


// ==== dmod_writ @ 013e8b20

void dmod_writ(void)

{
  DAT_0f00800b = 0x48;
  return;
}


// ==== dmod_hwri @ 013e8b32

void dmod_hwri(void)

{
  DAT_0f00800b = 0x48;
  return;
}


// ==== dreq_set @ 013e8b44

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void dreq_set(ushort param_1)

{
  ushort uVar1;
  
  _dma_req = param_1 | _dma_req;
  uVar1 = _dma_req;
  DAT_0f00800f = DAT_013ef257;
  _dma_req = uVar1;
  return;
}


// ==== dreq_rst @ 013e8b64

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void dreq_rst(ushort param_1)

{
  ushort uVar1;
  
  _dma_req = ~param_1 & _dma_req;
  uVar1 = _dma_req;
  DAT_0f00800f = DAT_013ef257;
  _dma_req = uVar1;
  return;
}


// ==== dmsk_set @ 013e8b86

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void dmsk_set(ushort param_1)

{
  ushort uVar1;
  
  _dma_wrmsk = param_1 | _dma_wrmsk;
  uVar1 = _dma_wrmsk;
  DAT_0f00800e = DAT_013ef259;
  _dma_wrmsk = uVar1;
  return;
}


// ==== dmsk_rst @ 013e8ba6

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void dmsk_rst(ushort param_1)

{
  ushort uVar1;
  
  _dma_wrmsk = ~param_1 & _dma_wrmsk;
  uVar1 = _dma_wrmsk;
  DAT_0f00800e = DAT_013ef259;
  _dma_wrmsk = uVar1;
  return;
}


// ==== fdma_chg @ 013e8bc8

void fdma_chg(undefined1 param_1)

{
  DAT_0f008000 = param_1;
  return;
}


// ==== fdma_init @ 013e8bdc

void fdma_init(undefined1 param_1)

{
  DAT_0f008001 = param_1;
  return;
}


// ==== fdma_cmd @ 013e8bf0

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void fdma_cmd(undefined2 param_1)

{
  _DAT_0f008008 = param_1;
  return;
}


// ==== fdma_sts @ 013e8c04

undefined1 fdma_sts(void)

{
  return DAT_0f00800a;
}


// ==== fdma_seg @ 013e8c18

void fdma_seg(undefined1 param_1)

{
  DAT_0f008007 = param_1;
  return;
}


// ==== fdma_adr @ 013e8c2c

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void fdma_adr(undefined2 param_1)

{
  _DAT_0f008004 = param_1;
  return;
}


// ==== fdma_len @ 013e8c40

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void fdma_len(undefined2 param_1)

{
  _DAT_0f008002 = param_1;
  return;
}


// ==== fdma_mod @ 013e8c54

void fdma_mod(undefined1 param_1)

{
  DAT_0f00800b = param_1;
  return;
}


// ==== fdma_msk @ 013e8c68

void fdma_msk(undefined1 param_1)

{
  DAT_0f00800e = param_1;
  return;
}


// ==== cmdwait @ 013e8c7c

void cmdwait(void)

{
  byte bVar1;
  
  fwait(400);
  do {
    bVar1 = DAT_0f007000;
    fdcwait();
  } while ((bVar1 & 1) != 0);
  fdcwait();
  return;
}


// ==== div_cnv @ 013e8cd0

int div_cnv(int param_1)

{
  param_1 = param_1 + -4;
  fdd_dh_sw = 1;
  switch(param_1) {
  case 0:
    break;
  case 1:
    goto switchD_013e8cec_caseD_1;
  case 2:
    fdd_dh_sw = 0;
    break;
  case 3:
    fdd_dh_sw = 0;
    goto switchD_013e8cec_caseD_1;
  case 4:
    fdd_dh_sw = 2;
    break;
  case 5:
    fdd_dh_sw = 2;
switchD_013e8cec_caseD_1:
    param_1 = 1;
  default:
    goto switchD_013e8cec_default;
  }
  param_1 = 0;
switchD_013e8cec_default:
  return param_1;
}


// ==== fdinit @ 013e8d28

void fdinit(undefined1 param_1)

{
  byte unaff_D7b;
  
  div_cnv(param_1);
  dma_init();
  DAT_0f00b000 = unaff_D7b | 0x80;
  piowait();
  DAT_0f00b001 = 0xff;
  piowait();
  DAT_0f00b001 = 0;
  piowait();
  DAT_0f00b001 = 0x24;
  piowait();
  DAT_0f007000 = 0;
  fdcwait();
  fwait(10000);
  DAT_0f007003 = 10;
  fdcwait();
  DAT_0f007000 = 0x19;
  fdcwait();
  fwait(150000);
  DAT_0f007003 = 0;
  fdcwait();
  DAT_0f007000 = 0x19;
  fdcwait();
  fwait(150000);
  DAT_0f007000 = 0;
  fdcwait();
  fwait(10000);
  fbuzywait(2000000);
  fdcwait();
  return;
}


// ==== fddismou @ 013e8df6

void fddismou(undefined4 param_1)

{
  byte unaff_D7b;
  
  div_cnv(param_1);
  DAT_0f00b000 = unaff_D7b | 0x80;
  piowait();
  DAT_0f00b001 = 0x24;
  piowait();
  DAT_0f00b001 = 0;
  piowait();
  DAT_0f007000 = 0;
  fdcwait();
  cmdwait();
  DAT_0f00b000 = 0x83;
  piowait();
  return;
}


// ==== fwait @ 013e8e58

void fwait(int param_1)

{
  for (; param_1 != 0; param_1 = param_1 + -1) {
  }
  return;
}


// ==== fbuzywait @ 013e8e6c

void fbuzywait(int param_1)

{
  byte bVar1;
  
  param_1 = param_1 >> 1;
  fwait(param_1);
  bVar1 = DAT_0f007000;
  while ((DAT_0f007000 = bVar1, param_1 != 0 && (fdcwait(), (bVar1 & 1) != 0))) {
    param_1 = param_1 + -1;
    bVar1 = DAT_0f007000;
  }
  return;
}


// ==== fddseek @ 013e8eb0

void fddseek(uint param_1,undefined1 param_2)

{
  uint uVar1;
  
  DAT_0f007003 = (undefined1)param_1;
  fdcwait();
  DAT_0f007002 = param_2;
  fdcwait();
  fdset_hea(param_1,0,1);
  uVar1 = (uint)DAT_0f007001;
  fdcwait();
  if (param_1 != uVar1) {
    DAT_0f007000 = 0x15;
    fdcwait();
    cmdwait();
  }
  return;
}


// ==== fdd_busy @ 013e8f2a

void fdd_busy(void)

{
  byte bVar1;
  int iVar2;
  uint unaff_D7;
  
  iVar2 = 0x100000;
  do {
    fdma_sts();
    dmawait();
    if ((unaff_D7 & 8) != 0) break;
    iVar2 = iVar2 + -1;
  } while (iVar2 != 0);
  if (iVar2 != 0) {
    do {
      bVar1 = DAT_0f007000;
      fdcwait();
    } while ((bVar1 & 1) != 0);
  }
  return;
}


// ==== fdd_test @ 013e8f7e

void fdd_test(void)

{
  return;
}


// ==== fdd_nrmrt @ 013e8f86

void fdd_nrmrt(void)

{
  fdset_hea(0,0,0);
  fdma_cmd(4);
  return;
}


// ==== fdd_err @ 013e8fa4

void fdd_err(void)

{
  fdd_nrmrt();
  return;
}


// ==== fdset_hea @ 013e8fb2

void fdset_hea(short param_1,short param_2,short param_3)

{
  byte bVar1;
  
  DAT_0f00b001 = 0;
  if (param_2 != 0) {
    DAT_0f00b001 = 0x40;
  }
  if (0x3b < param_1) {
    DAT_0f00b001 = DAT_0f00b001 | 8;
  }
  if (param_3 != 0) {
    if (fdd_dh_sw == 0) {
      bVar1 = 0;
    }
    else {
      bVar1 = 2;
    }
    DAT_0f00b001 = DAT_0f00b001 | 0x24 | bVar1;
  }
  piowait();
  return;
}


// ==== fdset_dri @ 013e8ffc

void fdset_dri(undefined2 param_1)

{
  byte bVar1;
  
  fdd_dh_sw = 1;
  bVar1 = 0;
  switch(param_1) {
  case 0:
    break;
  case 1:
    goto switchD_013e901a_caseD_1;
  case 2:
    fdd_dh_sw = 0;
    break;
  case 3:
    fdd_dh_sw = 0;
    goto switchD_013e901a_caseD_1;
  case 4:
    fdd_dh_sw = 2;
    break;
  case 5:
    fdd_dh_sw = 2;
switchD_013e901a_caseD_1:
    bVar1 = 1;
  default:
    goto switchD_013e901a_default;
  }
  bVar1 = 0;
switchD_013e901a_default:
  DAT_0f00b000 = bVar1 | 0x80;
  piowait();
  return;
}


// ==== rdwrsec @ 013e9068

void rdwrsec(short param_1,short param_2,short param_3,undefined1 param_4,undefined4 param_5)

{
  int unaff_D7;
  
  fdset_hea((int)param_2,(int)param_3,1);
  dcon_off();
  DAT_0f007002 = param_4;
  fdcwait();
  dmahset(3,param_5,0x200);
  if (param_1 == 0) {
    dmod_hrea();
  }
  else {
    dmod_hwri();
  }
  dmsk_rst(8);
  dcon_ons();
  if (param_1 == 0) {
    DAT_0f007000 = 0x80;
  }
  else {
    DAT_0f007000 = 0xa0;
  }
  fdcwait();
  fdd_busy();
  if (unaff_D7 == 0) {
    fdma_msk(0xf);
    fdcwait();
  }
  else {
    fdma_msk(0xf);
  }
  return;
}


// ==== fdrws @ 013e914c

/* WARNING: Removing unreachable block (ram,0x013e929a) */
/* WARNING: Removing unreachable block (ram,0x013e92a2) */

void fdrws(short param_1,short param_2,int param_3,int param_4,int param_5)

{
  char cVar1;
  int iVar2;
  short sVar3;
  short sVar4;
  char unaff_D7b;
  short sVar5;
  short sVar6;
  
  dma_init();
  fdma_chg(3);
  fdset_dri((int)param_2);
  fdset_hea(0,0,1);
  fwait(150000);
  iVar2 = 0x20000;
  do {
    cVar1 = DAT_0f007000;
    fdcwait();
    if (-1 < cVar1) break;
    iVar2 = iVar2 + -1;
  } while (iVar2 != 0);
  if (iVar2 == 0) {
    fdd_err();
  }
  else {
    if ((fdd_dh_sw == 0) || (fdd_dh_sw == 2)) {
      iVar2 = 9;
    }
    else {
      iVar2 = 0x12;
    }
    sVar6 = (short)(param_3 % iVar2) + 1;
    if ((fdd_dh_sw == 0) || (fdd_dh_sw == 2)) {
      iVar2 = 9;
    }
    else {
      iVar2 = 0x12;
    }
    sVar5 = (short)(param_3 / iVar2);
    sVar4 = sVar5 % 2;
    if (sVar5 < 0) {
      sVar5 = sVar5 + 1;
    }
    sVar5 = sVar5 >> 1;
    for (; param_4 != 0; param_4 = param_4 + -1) {
      sVar3 = 1;
      do {
        fdset_hea((int)sVar5,(int)sVar4,1);
        fddseek((int)sVar5,(int)sVar6);
        if (unaff_D7b == '\0') break;
        sVar3 = sVar3 + -1;
      } while (sVar3 != 0);
      if (unaff_D7b != '\0') {
        fdd_err();
        return;
      }
      rdwrsec((int)param_1,(int)sVar5,(int)sVar4,(int)sVar6,param_5);
      sVar6 = sVar6 + 1;
      if (fdd_dh_sw == 0) {
        iVar2 = 9;
      }
      else if (fdd_dh_sw == 2) {
        iVar2 = 9;
      }
      else {
        iVar2 = 0x12;
      }
      if (iVar2 + 1 <= (int)sVar6) {
        sVar6 = 1;
        if (sVar4 == 0) {
          sVar4 = 1;
        }
        else {
          sVar4 = 0;
          sVar5 = sVar5 + 1;
        }
      }
      param_5 = param_5 + 0x200;
    }
  }
  return;
}


// ==== fs_mount @ 013e9300

void fs_mount(uint param_1)

{
  if (param_1 == 1) {
    fsmount(5);
  }
  else if (param_1 < 2) {
    if (param_1 == 0) {
      fsmount(4);
    }
  }
  else if (param_1 == 6) {
    fsmount(0);
  }
  return;
}


// ==== fs_open @ 013e934a

void fs_open(uint param_1,undefined4 param_2,undefined4 param_3)

{
  if (param_1 == 1) {
    fsopen(5,param_2,param_3);
  }
  else if (param_1 < 2) {
    if (param_1 == 0) {
      fsopen(4,param_2,param_3);
    }
  }
  else if (param_1 == 6) {
    fsopen(0,param_2,param_3);
  }
  return;
}


// ==== fs_read @ 013e93a8

void fs_read(uint param_1,short param_2,undefined4 param_3,undefined4 param_4)

{
  if (param_1 == 1) {
    fsread(5,(int)param_2,param_3,param_4);
  }
  else if (param_1 < 2) {
    if (param_1 == 0) {
      fsread(4,(int)param_2,param_3,param_4);
    }
  }
  else if (param_1 == 6) {
    fsread(0,(int)param_2,param_3,param_4);
  }
  return;
}


// ==== fs_clos @ 013e941c

void fs_clos(uint param_1,short param_2)

{
  if (param_1 == 1) {
    fsclos(5,(int)param_2);
  }
  else if (param_1 < 2) {
    if (param_1 == 0) {
      fsclos(4,(int)param_2);
    }
  }
  else if (param_1 == 6) {
    fsclos(0,(int)param_2);
  }
  return;
}


// ==== hdinit @ 013e9478

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void hdinit(int param_1)

{
  undefined1 local_16;
  char local_15;
  
  _hddmasw = 0;
  dma_init();
  rg_write(0,0x87);
  rg_write(0x18,0);
  hds_wait(0);
  sc_recovt(param_1,&local_16);
  cdb_clr(&local_16);
  local_16 = 1;
  local_15 = *(char *)(param_1 + 9) << 5;
  tx_cmd(&local_16);
  return;
}


// ==== sc_recovt @ 013e94f4

/* WARNING: Removing unreachable block (ram,0x013e95b6) */

void sc_recovt(int param_1,undefined1 *param_2)

{
  int iVar1;
  char unaff_D7b;
  
  do {
    rg_read(0x17);
    cdb_clr(param_2);
    *param_2 = 0;
    param_2[1] = *(char *)(param_1 + 9) << 5;
    rg_read(0x17);
    rg_write(1,0x81);
    rg_write(0x11,0);
    rg_write(0x15,0);
    rg_write(2,0xff);
    rg_write(0xf,0);
    cdb_write(param_2);
    rg_write(0x18,9);
    iVar1 = 10000;
    do {
      rg_read(0x17);
      if (unaff_D7b == '\x16') break;
      iVar1 = iVar1 + -1;
    } while (iVar1 != 0);
    if (unaff_D7b == '\x16') {
      hds_wait(0x85);
      rg_read(0xf);
    }
    iVar1 = 10000;
    do {
      iVar1 = iVar1 + -1;
    } while (iVar1 != 0);
    rg_read(0x17);
  } while( true );
}


// ==== cdb_clr @ 013e95e2

void cdb_clr(int param_1)

{
  *(undefined1 *)(param_1 + 2) = 0;
  *(undefined1 *)(param_1 + 3) = 0;
  *(undefined1 *)(param_1 + 4) = 0;
  *(undefined1 *)(param_1 + 5) = 0;
  return;
}


// ==== hdread @ 013e95fe

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void hdread(undefined4 param_1)

{
  undefined1 auStack_16 [18];
  
  _hddmasw = 0;
  set_cmd(param_1,auStack_16,8);
  dma_read(param_1);
  set_count();
  tx_cmd(auStack_16);
  return;
}


// ==== dma_read @ 013e9648

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void dma_read(undefined4 *param_1)

{
  _hddmasw = 1;
  dcon_off();
  dmahset(2,*param_1,0x200);
  dmod_hrea();
  dmsk_rst(4);
  dcon_ons();
  return;
}


// ==== hdwrite @ 013e9688

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void hdwrite(undefined4 param_1)

{
  undefined1 auStack_16 [18];
  
  _hddmasw = 0;
  set_cmd(param_1,auStack_16,10);
  dma_write(param_1);
  set_count();
  tx_cmd(auStack_16);
  return;
}


// ==== dma_write @ 013e96d2

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void dma_write(undefined4 *param_1)

{
  _hddmasw = 1;
  dcon_off();
  dmahset(2,*param_1,0x200);
  dmod_hwri();
  dmsk_rst(4);
  dcon_ons();
  return;
}


// ==== hddismou @ 013e9712

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void hddismou(undefined4 param_1)

{
  undefined1 auStack_16 [18];
  
  _hddmasw = 0;
  set_cmd(param_1,auStack_16,0xb);
  set_css(param_1,auStack_16);
  tx_cmd(auStack_16);
  return;
}


// ==== set_css @ 013e9758

void set_css(int param_1,int param_2)

{
  *(byte *)(param_2 + 1) = *(char *)(param_1 + 9) << 5 | 2;
  *(undefined1 *)(param_2 + 2) = 0x99;
  *(undefined1 *)(param_2 + 3) = 0;
  return;
}


// ==== set_cmd @ 013e9782

void set_cmd(int param_1,char *param_2,char param_3)

{
  *param_2 = param_3;
  param_2[1] = *(char *)(param_1 + 9) << 5 | (byte)((uint)*(undefined4 *)(param_1 + 4) >> 0x10);
  param_2[2] = (char)((uint)*(undefined4 *)(param_1 + 4) >> 8);
  param_2[3] = (char)*(undefined4 *)(param_1 + 4);
  param_2[4] = '\x01';
  if (param_3 == '\v') {
    param_2[4] = '\0';
  }
  param_2[5] = '\0';
  return;
}


// ==== tx_cmd @ 013e97e0

void tx_cmd(undefined4 param_1)

{
  rg_read(0x17);
  rg_write(1,0x81);
  rg_write(0x11,0);
  rg_write(0x15,0);
  rg_write(2,0xff);
  rg_write(0xf,0);
  cdb_write(param_1);
  rg_write(0x18,9);
  hd_wait(1000000);
  return;
}


// ==== cdb_write @ 013e9854

void cdb_write(undefined1 *param_1)

{
  int iVar1;
  
  rg_write(3,*param_1);
  iVar1 = 5;
  do {
    param_1 = param_1 + 1;
    DAT_0f009001 = *param_1;
    iVar1 = iVar1 + -1;
  } while (0 < iVar1);
  return;
}


// ==== hd_wait @ 013e9888

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void hd_wait(int param_1)

{
  uint uVar1;
  int iVar2;
  uint unaff_D7;
  
  while( true ) {
    if (param_1 == 0) {
      return;
    }
    rg_read(0x17);
    if ((unaff_D7 & 0xff) == 0x16) {
      hds_wait(0x85);
      if ((byte)unaff_D7 != 0) {
        return;
      }
      if ((_hddmasw == 0) || (getdmact(), unaff_D7 == 0xffff)) {
        _hddmasw = 0;
        return;
      }
      return;
    }
    if ((unaff_D7 & 0xff) == 0x4b) break;
    param_1 = param_1 + -1;
  }
  rg_write(0x18,0xa0);
  iVar2 = 100;
  do {
    if ((DAT_0f009000 & 1) != 0) {
      rg_read(0x19);
      uVar1 = unaff_D7 & 3;
      unaff_D7 = (uint)((byte)unaff_D7 & 3);
      if (uVar1 != 0) {
        return;
      }
      break;
    }
    iVar2 = iVar2 + -1;
  } while (iVar2 != 0);
  hds_wait(0x1f);
  if ((char)unaff_D7 == '\0') {
    rg_write(0x18,0xa0);
    iVar2 = 100;
    do {
      if ((DAT_0f009000 & 1) != 0) {
        rg_read(0x19);
        break;
      }
      iVar2 = iVar2 + -1;
    } while (iVar2 != 0);
    hds_wait(0x20);
    rg_write(0x18,3);
    hds_wait(0x85);
  }
  return;
}


// ==== set_count @ 013e99be

void set_count(void)

{
  rg_write(0x12,0);
  rg_write(0x13,2);
  rg_write(0x14,0);
  return;
}


// ==== rg_read @ 013e99ec

undefined1 rg_read(undefined1 param_1)

{
  DAT_0f009000 = param_1;
  scsiwait();
  return DAT_0f009001;
}


// ==== rg_write @ 013e9a12

void rg_write(undefined1 param_1,undefined1 param_2)

{
  DAT_0f009000 = param_1;
  scsiwait();
  DAT_0f009001 = param_2;
  scsiwait();
  return;
}


// ==== hds_wait @ 013e9a46

void hds_wait(char param_1)

{
  int iVar1;
  char unaff_D7b;
  
  iVar1 = 1000000000;
  do {
    rg_read(0x17);
    if (param_1 == unaff_D7b) {
      return;
    }
    iVar1 = iVar1 + -1;
  } while (iVar1 != 0);
  return;
}


// ==== fdcwait @ 013e9a80

void fdcwait(void)

{
  FUN_013e9abe();
  FUN_013e9abe();
  FUN_013e9abe();
  FUN_013e9abe();
  FUN_013e9abe();
  FUN_013e9abe();
  FUN_013e9abe();
  FUN_013e9abe();
  FUN_013e9abe();
  FUN_013e9abe();
  return;
}


// ==== FUN_013e9abe @ 013e9abe

void FUN_013e9abe(void)

{
  return;
}


// ==== siowait @ 013e9ae8

void siowait(void)

{
  return;
}


// ==== dmawait @ 013e9afc

void dmawait(void)

{
  return;
}


// ==== scsiwait @ 013e9afe

void scsiwait(void)

{
  return;
}


// ==== piowait @ 013e9b02

void piowait(void)

{
  return;
}


// ==== fsmount @ 013e9b04

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void fsmount(int param_1)

{
  byte bVar1;
  byte *unaff_D7;
  undefined1 *puVar2;
  undefined1 local_24 [12];
  
  cfcb = &wkfcb;
  if (param_1 == 0) {
    unit_ck();
    cdph = unaff_D7;
    hdiox(0);
    if ((short)unaff_D7 == 0) {
      unit_ck();
      cdph = unaff_D7;
      sdirtop();
      puVar2 = local_24 + 0xc;
      goto LAB_013e9bda;
    }
  }
  else {
    if (5 < param_1) {
      return;
    }
    if (param_1 < 4) {
      return;
    }
    dev_lu = param_1;
    fdinit();
    if (unaff_D7 == (byte *)0x0) {
      unit_ck();
      cdph = unaff_D7;
      get_fat();
      puVar2 = local_24 + 0x1c;
LAB_013e9bda:
      *(undefined4 *)(puVar2 + -4) = 0;
      *(undefined4 *)(puVar2 + -8) = 0x60;
      *(undefined **)(puVar2 + -0xc) = cfcb;
      *(undefined4 *)(puVar2 + -0x10) = 0x13e9bec;
      _pcod = (short)unaff_D7;
      fill();
      bVar1 = *cdph;
      cfcb[1] = bVar1;
      dev_lu = (uint)bVar1;
      return;
    }
  }
  dev_lu = 0xffffff9d;
  return;
}


// ==== fsopen @ 013e9c12

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void fsopen(int param_1,undefined4 param_2)

{
  int iVar1;
  short unaff_D7w;
  
  iVar1 = cfcb;
  if (dev_lu == -99) {
    return;
  }
  *(undefined1 *)(cfcb + 5) = 8;
  *(undefined1 *)(iVar1 + 6) = 1;
  cpybuf(param_2,cfcb + 7,0xb);
  if (param_1 == 0) {
    open_f(cdph,cfcb);
    if (unaff_D7w != 0) {
      dev_lu = 0xffffff9d;
      _pcod = unaff_D7w;
      return;
    }
    io_max = 0x200;
    _pcod = unaff_D7w;
  }
  else if ((param_1 < 6) && (3 < param_1)) {
    open_ms(cfcb);
    if (unaff_D7w != 0) {
      _pcod = unaff_D7w;
      fddismou(dev_lu);
      dev_lu = 0xffffff9d;
      return;
    }
    io_max = sector_pe * byte_per_;
    _pcod = unaff_D7w;
  }
  *(undefined4 *)(cfcb + 0x3c) = *(undefined4 *)(cfcb + 0x30);
  io_left = 0;
  return;
}


// ==== rd_block @ 013e9cf0

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

int rd_block(undefined4 param_1,int param_2)

{
  int iVar1;
  int iVar2;
  short unaff_D7w;
  
  if (*(int *)(cfcb + 0x3c) == 0) {
    iVar1 = 0;
  }
  else {
    if (((param_2 != 1) && (*(int *)(cfcb + 0x3c) < io_max * param_2)) &&
       (param_2 = *(int *)(cfcb + 0x3c) / io_max, param_2 == 0)) {
      param_2 = 1;
    }
    iVar2 = io_max * param_2;
    if (*(int *)(cfcb + 0x3c) < iVar2) {
      iVar2 = *(int *)(cfcb + 0x3c);
    }
    iVar1 = file_com(0,cdph,cfcb,param_1,param_2);
    _pcod = unaff_D7w;
    if (unaff_D7w == 0) {
      iVar1 = *(int *)(cfcb + 0x3c) - iVar2;
      *(int *)(cfcb + 0x3c) = iVar1;
    }
  }
  return iVar1;
}


// ==== fsread @ 013e9d98

void fsread(int param_1,int param_2,uint param_3,undefined1 *param_4)

{
  int unaff_D7;
  
  if ((((dev_lu != -99) && (param_2 == 0x10)) &&
      ((param_1 == 0 || ((param_1 < 6 && (3 < param_1)))))) && (0 < *(int *)(cfcb + 0x3c))) {
    if (io_left != 0) {
      for (; (param_3 != 0 && (io_left != 0)); io_left = io_left + -1) {
        *param_4 = *io_pt;
        param_3 = param_3 - 1;
        io_pt = io_pt + 1;
        param_4 = param_4 + 1;
      }
      if (param_3 == 0) {
        return;
      }
    }
    if (io_max < param_3) {
      rd_block(param_4,param_3 / io_max);
      if (unaff_D7 < 0) {
        return;
      }
      if (unaff_D7 == 0) {
        return;
      }
      param_3 = param_3 - unaff_D7;
      param_4 = param_4 + unaff_D7;
    }
    if (param_3 != 0) {
      rd_block(&fioworkbf,1);
      if ((-1 < unaff_D7) && (unaff_D7 != 0)) {
        io_pt = &fioworkbf;
        for (io_left = unaff_D7; (param_3 != 0 && (io_left != 0)); io_left = io_left + -1) {
          *param_4 = *io_pt;
          param_3 = param_3 - 1;
          io_pt = io_pt + 1;
          param_4 = param_4 + 1;
        }
      }
    }
  }
  return;
}


// ==== fsclos @ 013e9eae

void fsclos(void)

{
  return;
}


// ==== errcdcv @ 013e9ed0

void errcdcv(short param_1,short *param_2)

{
  short sVar1;
  short *psVar2;
  
  psVar2 = &errcvtbl;
  sVar1 = 9;
  do {
    if (param_1 == *psVar2) {
      *param_2 = psVar2[1];
      return;
    }
    sVar1 = sVar1 + -1;
    psVar2 = psVar2 + 2;
  } while (0 < sVar1);
  *param_2 = -0x34;
  return;
}


// ==== unit_ck @ 013e9f00

void unit_ck(char param_1,char *param_2,int param_3)

{
  byte bVar1;
  
  bVar1 = 0;
  do {
    if (*param_2 == param_1) {
      if (param_3 == 0) {
        return;
      }
      *(byte *)(param_3 + 0x2d) = bVar1;
      return;
    }
    bVar1 = bVar1 + 1;
    param_2 = param_2 + 0x30;
  } while (bVar1 < 8);
  return;
}


// ==== hd_iox @ 013e9f36

void hd_iox(char param_1,undefined1 param_2,int param_3,char param_4,int param_5)

{
  short sVar1;
  short unaff_D7w;
  int local_e;
  int local_a;
  char local_6;
  undefined1 local_5;
  
  local_5 = param_2;
  local_e = param_5;
  local_a = 0;
  local_6 = param_1;
  switch(param_1) {
  case '\0':
    hdinit(&local_e);
    if (unaff_D7w != 0) {
      local_6 = 3;
      hddismou(&local_e);
    }
    break;
  case '\x01':
  case '\x02':
    local_a = param_3;
    if (param_4 != '\0') {
      do {
        sVar1 = 3;
        do {
          if (local_6 == '\x01') {
            hdread(&local_e);
          }
          else {
            hdwrite(&local_e);
          }
        } while ((unaff_D7w != 0) && (sVar1 = sVar1 + -1, sVar1 != 0));
        if (unaff_D7w != 0) {
          return;
        }
        param_4 = param_4 + -1;
        if (param_4 == '\0') {
          return;
        }
        local_e = local_e + 0x200;
        local_a = local_a + 1;
      } while (param_4 != '\0');
    }
    break;
  case '\x03':
    hddismou(&local_e);
  }
  return;
}


// ==== file_com @ 013ea004

void file_com(undefined4 param_1,undefined1 *param_2,int param_3,undefined4 param_4,short param_5)

{
  if (*(byte *)(param_3 + 1) < 4) {
    bvefile_c(param_1,*param_2,param_4,(int)param_5);
  }
  else {
    read_ms(param_1,param_2,param_3,param_4,(int)param_5);
  }
  return;
}


// ==== hdiox @ 013ea060

void hdiox(undefined1 param_1,undefined1 *param_2,undefined4 param_3,undefined1 param_4,
          undefined4 param_5,undefined2 *param_6)

{
  *param_6 = 0;
  bvehdiox(param_1,*param_2,param_3,param_4,param_5,param_6);
  return;
}


// ==== sdirtop @ 013ea0aa

void sdirtop(void)

{
  return;
}


// ==== open_f @ 013ea0b4

void open_f(undefined4 param_1,int param_2)

{
  bveopen_f(*(undefined1 *)(param_2 + 1),param_2 + 7,param_2 + 0x30);
  return;
}


// ==== get_fat @ 013ea16e

void get_fat(int *param_1)

{
  int iVar1;
  ushort uVar2;
  ushort uVar3;
  int unaff_D7;
  byte *pbVar4;
  
  pbVar4 = (byte *)*param_1;
  uVar2 = (ushort)*pbVar4;
  uVar3 = uVar2 - 4;
  fdrws(0,(uint)uVar3,(int)*(short *)(&msdph + (uint)uVar3 * 0x14),1,&dirbuf);
  if (unaff_D7 == 0) {
    if (dirbuf != -0x10) {
      pbVar4 = pbVar4 + 0xc0;
      uVar3 = uVar2;
    }
    iVar1 = (uint)uVar3 * 0x14;
    fdrws(0,(uint)uVar3,(int)*(short *)(&msdph + iVar1),(int)*(short *)(&DAT_013ea0f8 + iVar1),
          &dirbuf);
  }
  else {
    uVar3 = uVar2 - 2;
    pbVar4 = pbVar4 + 0x60;
    iVar1 = (uint)uVar3 * 0x14;
    fdrws(0,(uint)uVar3,(int)*(short *)(&msdph + iVar1),(int)*(short *)(&DAT_013ea0f8 + iVar1),
          &dirbuf);
  }
  if ((unaff_D7 == 0) && ((dirbuf == -7 || (dirbuf == -0x10)))) {
    *param_1 = (int)pbVar4;
    fdrws(0,uVar3,0,1,&workbf);
    sector_pe = (uint)DAT_013f187b;
    if (sector_pe == 0) {
      sector_pe = (uint)*(short *)(&DAT_013ea104 + (uint)uVar3 * 0x14);
    }
    byte_per_ = (uint)CONCAT11(DAT_013f187a,DAT_013f1879);
    if (byte_per_ == 0) {
      byte_per_ = *(uint *)(&DAT_013ea100 + (uint)uVar3 * 0x14);
    }
    data_sect = (uint)DAT_013f187e * (uint)CONCAT11(DAT_013f1885,DAT_013f1884) + 1 +
                ((int)(uint)CONCAT11(DAT_013f1880,DAT_013f187f) >> 4);
  }
  return;
}


// ==== open_ms @ 013ea338

/* WARNING: Removing unreachable block (ram,0x013ea3ca) */
/* WARNING: Removing unreachable block (ram,0x013ea410) */

void open_ms(int param_1)

{
  int iVar1;
  int iVar2;
  int unaff_D7;
  undefined *puVar3;
  int iVar4;
  short sVar5;
  
  sVar5 = *(byte *)(param_1 + 1) - 4;
  iVar4 = sVar5 * 0x14;
  iVar1 = (int)*(short *)(&DAT_013ea0fa + iVar4);
  iVar4 = (int)*(short *)(&DAT_013ea0fc + iVar4);
  while ((iVar4 = iVar4 + -1, iVar4 != -1 && (fdrws(0,(int)sVar5,iVar1,1,&workbf), unaff_D7 == 0)))
  {
    puVar3 = &workbf;
    iVar2 = 0;
    do {
      cmpbuf(param_1 + 7,puVar3,0xb);
      puVar3 = puVar3 + 0x20;
      iVar2 = iVar2 + 1;
    } while (iVar2 < 0x10);
    iVar1 = iVar1 + 1;
  }
  return;
}


// ==== revlong @ 013ea436

uint revlong(uint *param_1)

{
  return *param_1 >> 0x18;
}


// ==== read_ms @ 013ea466

void read_ms(int param_1,undefined4 param_2,int param_3,int param_4,short param_5)

{
  short sVar1;
  short sVar2;
  short unaff_D4w;
  int unaff_D7;
  short sVar3;
  short sVar4;
  ushort local_6;
  
  local_6 = (ushort)*(byte *)(param_3 + 1);
  sVar1 = local_6 - 4;
  sVar4 = *(short *)(param_3 + 0x38);
  if (sVar4 != 0xff8) {
    sVar2 = 1;
    sVar3 = (short)unaff_D7;
    if (param_5 < 2) {
      param_5 = 0;
    }
    else {
      param_5 = param_5 + -1;
      if (param_5 != 0) {
        do {
          getcno((int)sVar1,param_2,(int)sVar4);
          unaff_D4w = sVar3;
          if ((sVar3 == 0xff8) || (sVar3 == 0)) break;
          if (sVar4 + 1 == (int)sVar3) {
            sVar2 = sVar2 + 1;
          }
          else {
            if (param_1 == 0) {
              fdrws(0,(int)sVar1,data_sect + sector_pe * (*(ushort *)(param_3 + 0x38) - 2),
                    sector_pe * sVar2,param_4);
              if (unaff_D7 != 0) {
                return;
              }
              param_4 = sector_pe * byte_per_ * sVar2 + param_4;
            }
            *(short *)(param_3 + 0x38) = sVar3;
            sVar2 = 1;
          }
          param_5 = param_5 + -1;
          sVar4 = sVar3;
        } while (param_5 != 0);
      }
    }
    if ((param_1 != 0) ||
       (fdrws(0,(int)sVar1,data_sect + sector_pe * (*(ushort *)(param_3 + 0x38) - 2),
              sector_pe * sVar2,param_4), unaff_D7 == 0)) {
      if (param_5 == 0) {
        getcno((int)sVar1,param_2,(int)sVar4);
        unaff_D4w = sVar3;
      }
      *(short *)(param_3 + 0x38) = unaff_D4w;
    }
  }
  return;
}


// ==== getcno @ 013ea5e4

void getcno(void)

{
  return;
}


// ==== bv_notedr @ 013ea67c

void bv_notedr(undefined4 param_1)

{
  switch(param_1) {
  case 0:
  case 1:
    DAT_0f00a7f9 = 4;
    break;
  default:
    DAT_0f00a7f9 = 1;
    break;
  case 5:
  case 7:
    DAT_0f00a7f9 = 2;
  }
  eepwait();
  DAT_0f00a7fe = 1;
  eepwait();
  return;
}


// ==== bveopen_f @ 013ea6d0

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void bveopen_f(short param_1,undefined4 param_2,undefined4 *param_3)

{
  short unaff_D7w;
  
  get_dir((int)param_1,param_2);
  if ((unaff_D7w != 1) && (get_eent((int)param_1,(int)DAT_013f2188), unaff_D7w != 1)) {
    _c_eent_no = 0;
    c_block_n = 0xffff;
    blockget(0,(int)param_1,&DAT_013ef66e);
    if (unaff_D7w != 1) {
      *param_3 = DAT_013f2178;
    }
  }
  return;
}


// ==== bvefile_c @ 013ea750

void bvefile_c(short param_1,short param_2,int param_3,short param_4)

{
  short unaff_D7w;
  
  if (c_remain_ < param_4) {
    if (c_remain_ != 0) {
      if (param_1 == 0) {
        cpybuf(&DAT_013ef66e + c_move_se * 0x200,param_3,(int)c_remain_ << 9);
        param_3 = c_remain_ * 0x200 + param_3;
      }
      param_4 = param_4 - c_remain_;
      c_remain_ = 0;
      c_move_se = 8;
    }
    if (7 < param_4) {
      for (; 7 < param_4; param_4 = param_4 + -8) {
        blockget((int)param_1,(int)param_2,param_3);
        if (unaff_D7w == 1) {
          return;
        }
        param_3 = param_3 + 0x1000;
      }
    }
    blockget(0,(int)param_2,&DAT_013ef66e);
    if (unaff_D7w == 1) {
      return;
    }
    if (param_4 == 0) {
      return;
    }
  }
  if (param_1 == 0) {
    cpybuf(&DAT_013ef66e + c_move_se * 0x200,param_3,(int)param_4 << 9);
  }
  c_remain_ = c_remain_ - param_4;
  c_move_se = param_4 + c_move_se;
  return;
}


// ==== blockget @ 013ea86c

void blockget(short param_1,short param_2,undefined4 param_3)

{
  short sVar1;
  short unaff_D7w;
  
  c_block_n = c_block_n + 1;
  if (c_block_n < 0xc) {
    if ((&DAT_013f2194)[c_block_n] == 0) {
      return;
    }
    if (param_1 != 0) {
      return;
    }
    sVar1 = (&DAT_013f2194)[c_block_n];
  }
  else {
    if (DAT_013f2192 == 0) {
      return;
    }
    get_eent((int)param_2,(int)DAT_013f2192);
    if (unaff_D7w == 1) {
      return;
    }
    c_block_n = 0;
    if (DAT_013f2194 == 0) {
      c_block_n = 0;
      return;
    }
    sVar1 = DAT_013f2194;
    if (param_1 != 0) {
      c_block_n = 0;
      return;
    }
  }
  get_block((int)param_2,(int)sVar1,param_3);
  return;
}


// ==== get_block @ 013ea920

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void get_block(short param_1,short param_2,undefined4 param_3)

{
  short unaff_D7w;
  undefined1 auStack_6 [2];
  
  bvehdiox(1,(int)param_1,(int)param_2,8,param_3,auStack_6);
  if (unaff_D7w != 1) {
    c_move_se = 0;
    c_remain_ = 8;
    _c_rd_sec = 8;
  }
  return;
}


// ==== get_eent @ 013ea970

void get_eent(short param_1,short param_2)

{
  short sVar1;
  short unaff_D7w;
  undefined1 auStack_6 [2];
  
  if ((-1 < param_2) && (param_2 < 0x400)) {
    sVar1 = param_2;
    if (param_2 < 0) {
      sVar1 = param_2 + 0xf;
    }
    hd_iox(1,(int)param_1,(int)(sVar1 >> 4),1,&dirbuf,auStack_6);
    if (unaff_D7w == 0) {
      cpybuf(&dirbuf + (param_2 % 0x10) * 0x20,&tg_eent,0x20);
    }
  }
  return;
}


// ==== get_root @ 013ea9f4

short get_root(short param_1)

{
  short sVar1;
  uint uVar2;
  short unaff_D7w;
  undefined1 auStack_6 [2];
  
  sVar1 = hd_iox(1,(int)param_1,0x80,1,&dirbuf,auStack_6);
  if (((unaff_D7w == 0) && (sVar1 = DAT_013ef486, DAT_013ef486 == 0x4000)) &&
     (sVar1 = 0, DAT_013ef47a != 0)) {
    sVar1 = 0;
    if ((DAT_013ef48a != 0) && (sVar1 = 0, DAT_013ef48c != 0)) {
      uVar2 = (uint)DAT_013ef48a;
      hd_iox(1,(int)param_1,((int)DAT_013ef48a & 0x7ffffffU) >> 4,1,&dirbuf,auStack_6);
      sVar1 = hd_iox(1,(int)param_1,(int)*(short *)(&DAT_013ef476 + (uVar2 & 0xf) * 0x20) << 3,4,
                     &DAT_013efc6e,auStack_6);
    }
  }
  return sVar1;
}


// ==== fentchk @ 013eaada

short fentchk(short param_1)

{
  short *psVar1;
  
  psVar1 = &DAT_013efc6e;
  while( true ) {
    if (*psVar1 == 0) {
      return 0;
    }
    if (param_1 == *psVar1) break;
    psVar1 = psVar1 + 1;
  }
  return *psVar1;
}


// ==== get_dir @ 013eab00

/* WARNING: Removing unreachable block (ram,0x013eab74) */
/* WARNING: Removing unreachable block (ram,0x013eab8a) */

uint get_dir(short param_1)

{
  undefined2 extraout_D0u;
  ushort extraout_D0u_00;
  uint uVar1;
  short sVar2;
  uint uVar3;
  short unaff_D7w;
  undefined1 *puVar4;
  undefined1 auStack_6 [2];
  
  get_root((int)param_1);
  uVar1 = CONCAT22(extraout_D0u,unaff_D7w);
  if (unaff_D7w != 1) {
    uVar3 = 0x40;
    do {
      uVar1 = hd_iox(1,(int)param_1,uVar3,1,&dirbuf,auStack_6);
      if (unaff_D7w != 0) {
        return uVar1;
      }
      puVar4 = &dirbuf;
      sVar2 = 0x10;
      do {
        uVar1 = CONCAT31((int3)(uVar1 >> 8),puVar4[0xb]) & 0xffffff91;
        if ((puVar4[0xb] & 0x91) == 0) {
          fentchk((int)*(short *)(puVar4 + 0x18));
          uVar1 = (uint)extraout_D0u_00 << 0x10;
        }
        sVar2 = sVar2 + -1;
        puVar4 = puVar4 + 0x20;
      } while (sVar2 != 0);
      uVar3 = uVar3 + 1;
    } while (uVar3 < 0x80);
  }
  return uVar1;
}


// ==== bvehdiox @ 013eabbe

undefined4
bvehdiox(undefined1 param_1,undefined1 param_2,int param_3,undefined1 param_4,undefined4 param_5,
        undefined2 *param_6)

{
  undefined2 extraout_D0u;
  undefined2 extraout_D0u_00;
  undefined2 uVar1;
  short unaff_D7w;
  
  hd_iox(param_1,param_2,param_3 << 3,param_4,param_5);
  uVar1 = extraout_D0u;
  if (unaff_D7w != 0) {
    errcdcv((int)unaff_D7w,param_6);
    uVar1 = extraout_D0u_00;
  }
  return CONCAT22(uVar1,*param_6);
}


// ==== bcmp @ 013eac20

int bcmp(void *__s1,void *__s2,size_t __n)

{
  char cVar1;
  char cVar2;
  
  if (__n != 0) {
    for (; 0 < (int)__n; __n = __n - 1) {
      cVar1 = *(char *)__s2;
      __s2 = (void *)((int)__s2 + 1);
      cVar2 = *(char *)__s1;
      __s1 = (void *)((int)__s1 + 1);
      if (cVar2 != cVar1) {
        return __n;
      }
    }
  }
  return __n;
}


// ==== fdrive @ 013eac46

void fdrive(undefined4 param_1)

{
  DAT_013f21bc = param_1;
  return;
}


// ==== fopen @ 013eac58

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

FILE * fopen(char *__filename,char *__modes)

{
  FILE *in_D0;
  int unaff_D7;
  int iVar1;
  char *pcVar2;
  undefined1 auStack_14 [4];
  char acStack_10 [8];
  char acStack_8 [4];
  
  if ((_DAT_013f21b8 == 0) && (in_D0 = (FILE *)strcmp(__modes,"r"), unaff_D7 == 0)) {
    fill(&_iob,0x14,0);
    iVar1 = 0;
    do {
      pcVar2 = __filename;
      if ((*__filename == '.') || (*__filename == '\0')) break;
      pcVar2 = __filename + 1;
      acStack_10[iVar1] = *__filename;
      iVar1 = iVar1 + 1;
      __filename = pcVar2;
    } while (iVar1 < 8);
    if (*pcVar2 == '.') {
      pcVar2 = pcVar2 + 1;
    }
    for (; iVar1 < 8; iVar1 = iVar1 + 1) {
      acStack_10[iVar1] = ' ';
    }
    for (; (iVar1 < 0xb && (*pcVar2 != '\0')); pcVar2 = pcVar2 + 1) {
      acStack_10[iVar1] = *pcVar2;
      iVar1 = iVar1 + 1;
    }
    for (; iVar1 < 0xb; iVar1 = iVar1 + 1) {
      acStack_10[iVar1] = ' ';
    }
    acStack_10[iVar1] = '\0';
    fs_open(DAT_013f21bc,acStack_10,0,auStack_14);
    DAT_013f99a6 = 0;
    in_D0 = (FILE *)0x1;
    _DAT_013f21b8 = 1;
    DAT_013f999c = &DAT_013f21c8;
    DAT_013f99a0 = 0x2000;
  }
  return in_D0;
}


// ==== fclose @ 013ead3a

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

int fclose(FILE *__stream)

{
  int in_D0;
  int unaff_D7;
  undefined1 auStack_8 [4];
  
  if ((_DAT_013f21b8 != 0) && (__stream == (FILE *)&_iob)) {
    in_D0 = fs_clos(DAT_013f21bc,(int)DAT_013f99a6,auStack_8);
    if (unaff_D7 < 0) {
      uRam013f99a4 = 0x20;
    }
    else {
      _DAT_013f21b8 = 0;
    }
  }
  return in_D0;
}


// ==== FUN_013ead8a @ 013ead8a

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_013ead8a(undefined *param_1)

{
  int unaff_D7;
  undefined1 auStack_8 [4];
  
  if (_DAT_013f21b8 == 0) {
    return;
  }
  if (param_1 != &_iob) {
    return;
  }
  if (__iob < 1) {
    fs_read(DAT_013f21bc,(int)DAT_013f99a6,DAT_013f99a0,DAT_013f999c,auStack_8);
    if (unaff_D7 < 0) {
      __iob = unaff_D7;
      uRam013f99a4 = uRam013f99a4 | 0x20;
      return;
    }
    if (unaff_D7 == 0) {
      __iob = unaff_D7;
      uRam013f99a4 = uRam013f99a4 | 0x10;
      return;
    }
    iRam013f9998 = DAT_013f999c;
    __iob = unaff_D7;
  }
  iRam013f9998 = iRam013f9998 + 1;
  __iob = __iob + -1;
  return;
}


// ==== fread @ 013eae04

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

size_t fread(void *__ptr,size_t __size,size_t __n,FILE *__stream)

{
  size_t in_D0;
  int iVar1;
  int iVar2;
  int unaff_D7;
  undefined1 auStack_8 [4];
  
  if (((_DAT_013f21b8 != 0) && (__stream == (FILE *)&_iob)) && (iVar2 = __n * __size, 0 < iVar2)) {
    while (0 < iVar2) {
      if (__iob < 1) {
        fs_read(DAT_013f21bc,(int)DAT_013f99a6,DAT_013f99a0,DAT_013f999c,auStack_8);
        __iob = unaff_D7;
        if (unaff_D7 < 0) {
          uRam013f99a4 = uRam013f99a4 | 0x20;
          break;
        }
        if (unaff_D7 == 0) {
          uRam013f99a4 = uRam013f99a4 | 0x10;
          break;
        }
        iRam013f9998 = DAT_013f999c;
      }
      else {
        if (iVar2 < __iob) {
          iVar1 = iVar2;
        }
        else {
          iVar1 = __iob;
        }
        cpybuf(iRam013f9998,__ptr,iVar1);
        iRam013f9998 = iVar1 + iRam013f9998;
        __iob = __iob - iVar1;
        __ptr = (void *)(iVar1 + (int)__ptr);
        iVar2 = iVar2 - iVar1;
      }
    }
    in_D0 = __size;
  }
  return in_D0;
}


// ==== FUN_013eaec0 @ 013eaec0

void FUN_013eaec0(void)

{
  uint uVar1;
  uint uVar2;
  uint uVar3;
  
  uVar3 = 0;
  do {
    uVar2 = 0;
    uVar1 = uVar3;
    do {
      if ((uVar1 & 1) == 0) {
        uVar1 = uVar1 >> 1;
      }
      else {
        uVar1 = CONCAT22((ushort)(uVar1 >> 0x11),(short)(uVar1 >> 1)) ^ 0xa001;
      }
      uVar2 = uVar2 + 1;
    } while (uVar2 < 8);
    (&DAT_013f41c8)[uVar3] = (short)uVar1;
    uVar3 = uVar3 + 1;
  } while (uVar3 < 0x100);
  return;
}


// ==== FUN_013eaefa @ 013eaefa

void FUN_013eaefa(byte *param_1,int param_2)

{
  for (; param_2 != 0; param_2 = param_2 + -1) {
    DAT_013f43c8 = (&DAT_013f41c8)[((uint)*param_1 ^ (uint)DAT_013f43c8) & 0xff] ^ DAT_013f43c8 >> 8
    ;
    param_1 = param_1 + 1;
  }
  return;
}


// ==== FUN_013eaf5c @ 013eaf5c

void FUN_013eaf5c(byte param_1)

{
  int iVar1;
  uint uVar2;
  byte unaff_D7b;
  int *piVar3;
  
  if (DAT_013f43ca < param_1) {
    do {
      piVar3 = DAT_013f21c0;
      param_1 = param_1 - DAT_013f43ca;
      DAT_013f43cc = (short)((int)(uint)DAT_013f43ce >> (8 - DAT_013f43ca & 0x3f)) +
                     (DAT_013f43cc << (DAT_013f43ca & 0x3f));
      if (DAT_013f43d0 == 0) {
        DAT_013f43ce = 0;
      }
      else {
        DAT_013f43d0 = DAT_013f43d0 + -1;
        iVar1 = *DAT_013f21c0;
        *DAT_013f21c0 = iVar1 + -1;
        if (iVar1 + -1 < 0) {
          FUN_013ead8a(DAT_013f21c0);
          DAT_013f43ce = unaff_D7b;
        }
        else {
          piVar3 = piVar3 + 1;
          DAT_013f43ce = *(byte *)*piVar3;
          *piVar3 = *piVar3 + 1;
        }
      }
      DAT_013f43ca = 8;
    } while (8 < param_1);
  }
  DAT_013f43ca = DAT_013f43ca - param_1;
  uVar2 = (uint)param_1;
  DAT_013f43cc = (short)((int)(uint)DAT_013f43ce >> (8 - uVar2 & 0x3f)) +
                 (DAT_013f43cc << (uVar2 & 0x3f));
  DAT_013f43ce = DAT_013f43ce << (uVar2 & 0x3f);
  return;
}


// ==== FUN_013eb03e @ 013eb03e

void FUN_013eb03e(undefined1 param_1)

{
  FUN_013eaf5c(param_1);
  return;
}


// ==== FUN_013eb06c @ 013eb06c

void FUN_013eb06c(void)

{
  DAT_013f43cc = 0;
  DAT_013f43ce = 0;
  DAT_013f43ca = 0;
  FUN_013eaf5c(0x10);
  return;
}


// ==== FUN_013eb090 @ 013eb090

void FUN_013eb090(undefined4 param_1,int param_2)

{
  for (; param_2 != 0; param_2 = param_2 + -1) {
  }
  return;
}


// ==== FUN_013eb0b8 @ 013eb0b8

undefined2 FUN_013eb0b8(void)

{
  undefined1 uVar1;
  undefined1 *puVar2;
  
  uVar1 = *DAT_013f43d4;
  puVar2 = DAT_013f43d4 + 1;
  DAT_013f43d4 = DAT_013f43d4 + 2;
  return CONCAT11(*puVar2,uVar1);
}


// ==== FUN_013eb0e8 @ 013eb0e8

int FUN_013eb0e8(void)

{
  byte *pbVar1;
  byte *pbVar2;
  byte *pbVar3;
  
  pbVar1 = (byte *)(DAT_013f43d4 + 1);
  pbVar2 = (byte *)(DAT_013f43d4 + 2);
  pbVar3 = (byte *)(DAT_013f43d4 + 3);
  DAT_013f43d4 = DAT_013f43d4 + 4;
  return (uint)*pbVar1 * 0x100 + (uint)*pbVar2 * 0x10000 + (uint)*pbVar3 * 0x1000000;
}


// ==== FUN_013eb140 @ 013eb140

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_013eb140(FILE *param_1,byte *param_2)

{
  byte bVar1;
  byte *pbVar2;
  int iVar3;
  uint uVar4;
  uint uVar5;
  uint unaff_D7;
  undefined2 uVar6;
  char **ppcVar7;
  undefined4 local_1408;
  byte local_1404 [1024];
  byte abStack_1004 [7];
  byte local_ffd [13];
  byte local_ff0 [4076];
  
  local_1408 = 0;
  fill(param_2,0x126,0);
  iVar3 = param_1->_flags + -1;
  param_1->_flags = iVar3;
  if (iVar3 < 0) {
    FUN_013ead8a(param_1);
    uVar4 = unaff_D7;
  }
  else {
    ppcVar7 = &param_1->_IO_read_ptr;
    bVar1 = **ppcVar7;
    *ppcVar7 = *ppcVar7 + 1;
    uVar4 = (uint)bVar1;
  }
  if ((uVar4 == 0xffffffff) || (uVar4 == 0)) {
    _ewsl_errn = 3;
    return;
  }
  fread(abStack_1004 + 1,1,uVar4 - 1,param_1);
  if ((int)unaff_D7 < (int)(uVar4 - 1)) {
    _ewsl_errn = 5;
    return;
  }
  DAT_013f43d4 = local_ff0;
  param_2[0x13] = local_ff0[0];
  DAT_013f43d4 = DAT_013f43d4 + 1;
  if ((param_2[0x13] != 2) && (fread(abStack_1004 + uVar4,1,2,param_1), (int)unaff_D7 < 2)) {
    _ewsl_errn = 4;
    return;
  }
  DAT_013f43d4 = abStack_1004 + 2;
  *param_2 = (byte)uVar4;
  cpybuf(abStack_1004 + 2,param_2 + 1,5);
  DAT_013f43d4 = local_ffd;
  FUN_013eb0e8();
  *(uint *)(param_2 + 6) = unaff_D7;
  FUN_013eb0e8();
  *(uint *)(param_2 + 10) = unaff_D7;
  FUN_013eb0e8();
  *(uint *)(param_2 + 0xe) = unaff_D7;
  param_2[0x12] = *DAT_013f43d4;
  DAT_013f43d4 = DAT_013f43d4 + 1;
  bVar1 = *DAT_013f43d4;
  param_2[0x13] = bVar1;
  DAT_013f43d4 = DAT_013f43d4 + 1;
  if (bVar1 == 2) {
    uVar5 = 0;
  }
  else {
    FUN_013eb090(abStack_1004 + 2,uVar4);
    if (abStack_1004[1] != unaff_D7) {
      _ewsl_errn = 5;
      return;
    }
    uVar5 = (uint)*DAT_013f43d4;
    DAT_013f43d4 = DAT_013f43d4 + 1;
    iVar3 = 0;
    if (uVar5 != 0) {
      do {
        param_2[iVar3 + 0x14] = *DAT_013f43d4;
        DAT_013f43d4 = DAT_013f43d4 + 1;
        iVar3 = iVar3 + 1;
      } while (iVar3 < (int)uVar5);
    }
    param_2[uVar5 + 0x14] = 0;
  }
  uVar6 = (undefined2)unaff_D7;
  if ((int)(uVar4 - uVar5) < 0x18) {
    if (uVar4 - uVar5 != 0x16) {
      if (uVar4 - uVar5 != 0x14) {
        _ewsl_errn = 4;
        return;
      }
      param_2[0x11a] = 0;
      param_2[0x116] = 0;
      param_2[0x117] = 0;
      param_2[0x118] = 0;
      param_2[0x119] = 0;
      goto LAB_013eb320;
    }
    FUN_013eb0b8();
    *(undefined2 *)(param_2 + 0x114) = uVar6;
    param_2[0x11a] = 0;
  }
  else {
    FUN_013eb0b8();
    *(undefined2 *)(param_2 + 0x114) = uVar6;
    param_2[0x11a] = *DAT_013f43d4;
    DAT_013f43d4 = DAT_013f43d4 + 1;
  }
  param_2[0x116] = 0;
  param_2[0x117] = 0;
  param_2[0x118] = 0;
  param_2[0x119] = 1;
LAB_013eb320:
  if ((param_2[0x11a] == 0x55) && (param_2[0x13] == 0)) {
    param_2[0x11b] = *DAT_013f43d4;
    DAT_013f43d4 = DAT_013f43d4 + 1;
    FUN_013eb0e8();
    *(uint *)(param_2 + 0x11c) = unaff_D7;
    FUN_013eb0b8();
    *(undefined2 *)(param_2 + 0x120) = uVar6;
    FUN_013eb0b8();
    *(undefined2 *)(param_2 + 0x122) = uVar6;
    FUN_013eb0b8();
    *(undefined2 *)(param_2 + 0x124) = uVar6;
    return;
  }
  if (param_2[0x13] != 0) {
    pbVar2 = DAT_013f43d4;
    if (param_2[0x13] != 2) {
      DAT_013f43d4 = abStack_1004 + *param_2;
      pbVar2 = DAT_013f43d4;
    }
    while( true ) {
      FUN_013eb0b8();
      uVar4 = unaff_D7 & 0xffff;
      if (uVar4 == 0) break;
      if (param_2[0x13] != 2) {
        if ((int)(abStack_1004 + -(int)(DAT_013f43d4 + -0x1000)) < (int)uVar4) {
          _ewsl_errn = 4;
          return;
        }
        fread(DAT_013f43d4,1,uVar4,param_1);
        if ((int)unaff_D7 < (int)uVar4) {
          _ewsl_errn = 4;
          return;
        }
      }
      bVar1 = *DAT_013f43d4;
      DAT_013f43d4 = DAT_013f43d4 + 1;
      switch(bVar1) {
      default:
        DAT_013f43d4 = DAT_013f43d4 + (uVar4 - 3);
        break;
      case 1:
        iVar3 = 0;
        if (0 < (int)(uVar4 - 3)) {
          do {
            param_2[iVar3 + 0x14] = *DAT_013f43d4;
            DAT_013f43d4 = DAT_013f43d4 + 1;
            iVar3 = iVar3 + 1;
          } while (iVar3 < (int)(uVar4 - 3));
        }
        param_2[uVar4 + 0x11] = 0;
        break;
      case 2:
        iVar3 = 0;
        if (0 < (int)(uVar4 - 3)) {
          do {
            local_1404[iVar3] = *DAT_013f43d4;
            DAT_013f43d4 = DAT_013f43d4 + 1;
            iVar3 = iVar3 + 1;
          } while (iVar3 < (int)(uVar4 - 3));
        }
        local_1404[uVar4 - 3] = 0;
        FUN_013ebbd6(local_1404,0x2f);
        local_1408 = uVar4 - 3;
        break;
      case 0x40:
        if (((param_2[0x11a] == 0x4d) || (param_2[0x11a] == 0x48)) || (param_2[0x11a] == 0)) {
          FUN_013eb0b8();
          param_2[0x12] = (byte)unaff_D7;
        }
        break;
      case 0x50:
        if (param_2[0x11a] == 0x55) {
          FUN_013eb0b8();
          *(undefined2 *)(param_2 + 0x120) = uVar6;
        }
        break;
      case 0x51:
        if (param_2[0x11a] == 0x55) {
          FUN_013eb0b8();
          *(undefined2 *)(param_2 + 0x124) = uVar6;
          FUN_013eb0b8();
          *(undefined2 *)(param_2 + 0x122) = uVar6;
        }
        break;
      case 0x54:
        if (param_2[0x11a] == 0x55) {
          FUN_013eb0e8();
          *(uint *)(param_2 + 0x11c) = unaff_D7;
        }
      }
    }
    if ((param_2[0x13] != 2) && ((int)DAT_013f43d4 - (int)pbVar2 != 2)) {
      *(int *)(param_2 + 6) = (*(int *)(param_2 + 6) + 2) - ((int)DAT_013f43d4 - (int)pbVar2);
      *param_2 = ((char)DAT_013f43d4 - (char)pbVar2) + -2 + *param_2;
    }
  }
  if (local_1408 == 0) {
    return;
  }
  strcat((char *)local_1404,(char *)(param_2 + 0x14));
  strcpy((char *)(param_2 + 0x14),(char *)local_1404);
  return;
}


// ==== FUN_013eb606 @ 013eb606

void FUN_013eb606(short param_1,undefined1 param_2,short param_3)

{
  ushort uVar1;
  char cVar2;
  ushort uVar3;
  short sVar4;
  short unaff_D7w;
  short sVar5;
  
  FUN_013eb03e(param_2);
  if (unaff_D7w == 0) {
    FUN_013eb03e(param_2);
    sVar5 = 0;
    if (0 < param_1) {
      do {
        (&DAT_013f43d8)[sVar5] = 0;
        sVar5 = sVar5 + 1;
      } while (sVar5 < param_1);
    }
    sVar5 = 0;
    do {
      (&DAT_013f4458)[sVar5] = 0;
      sVar5 = sVar5 + 1;
    } while (sVar5 < 0x100);
  }
  else {
    sVar5 = 0;
    if (0 < unaff_D7w) {
      do {
        uVar3 = DAT_013f43cc >> 0xd;
        if (uVar3 == 7) {
          for (uVar1 = 0x1000; (DAT_013f43cc & uVar1) != 0; uVar1 = uVar1 >> 1) {
            uVar3 = uVar3 + 1;
          }
        }
        if ((short)uVar3 < 7) {
          cVar2 = '\x03';
        }
        else {
          cVar2 = (char)uVar3 + -3;
        }
        FUN_013eaf5c(cVar2);
        (&DAT_013f43d8)[sVar5] = (char)uVar3;
        sVar5 = sVar5 + 1;
        if (param_3 == sVar5) {
          FUN_013eb03e(2);
          sVar4 = unaff_D7w;
          while (sVar4 = sVar4 + -1, -1 < sVar4) {
            (&DAT_013f43d8)[sVar5] = 0;
            sVar5 = sVar5 + 1;
          }
        }
      } while (sVar5 < unaff_D7w);
    }
    for (; sVar5 < param_1; sVar5 = sVar5 + 1) {
      (&DAT_013f43d8)[sVar5] = 0;
    }
    FUN_013eba34((int)param_1,&DAT_013f43d8,8,&DAT_013f4458);
  }
  return;
}


// ==== FUN_013eb71a @ 013eb71a

void FUN_013eb71a(void)

{
  ushort uVar1;
  short sVar2;
  short unaff_D7w;
  short sVar3;
  
  FUN_013eb03e(9);
  if (unaff_D7w == 0) {
    FUN_013eb03e(9);
    sVar3 = 0;
    do {
      (&DAT_013f4658)[sVar3] = 0;
      sVar3 = sVar3 + 1;
    } while (sVar3 < 0x1fe);
    sVar3 = 0;
    do {
      (&DAT_013f4856)[sVar3] = 0;
      sVar3 = sVar3 + 1;
    } while (sVar3 < 0x1000);
  }
  else {
    sVar3 = 0;
    if (0 < unaff_D7w) {
      do {
        sVar2 = (&DAT_013f4458)[DAT_013f43cc >> 8];
        if (0x12 < sVar2) {
          uVar1 = 0x80;
          do {
            if ((DAT_013f43cc & uVar1) == 0) {
              sVar2 = *(short *)(&DAT_013f704c + sVar2 * 2);
            }
            else {
              sVar2 = *(short *)(&DAT_013f6856 + sVar2 * 2);
            }
            uVar1 = uVar1 >> 1;
          } while (0x12 < sVar2);
        }
        FUN_013eaf5c((&DAT_013f43d8)[sVar2]);
        if (sVar2 < 3) {
          if (sVar2 == 0) {
            sVar2 = 1;
          }
          else if (sVar2 == 1) {
            FUN_013eb03e(4);
            sVar2 = unaff_D7w + 3;
          }
          else {
            FUN_013eb03e(9);
            sVar2 = unaff_D7w + 0x14;
          }
          while (sVar2 = sVar2 + -1, -1 < sVar2) {
            (&DAT_013f4658)[sVar3] = 0;
            sVar3 = sVar3 + 1;
          }
        }
        else {
          (&DAT_013f4658)[sVar3] = (char)sVar2 + -2;
          sVar3 = sVar3 + 1;
        }
      } while (sVar3 < unaff_D7w);
    }
    for (; sVar3 < 0x1fe; sVar3 = sVar3 + 1) {
      (&DAT_013f4658)[sVar3] = 0;
    }
    FUN_013eba34(0x1fe,&DAT_013f4658,0xc,&DAT_013f4856);
  }
  return;
}


// ==== FUN_013eb87a @ 013eb87a

void FUN_013eb87a(void)

{
  uint uVar1;
  ushort uVar2;
  ushort uVar3;
  short unaff_D7w;
  
  if (DAT_013f7842 == 0) {
    FUN_013eb03e(0x10);
    DAT_013f7842 = unaff_D7w;
    FUN_013eb606(0x13,5,3);
    FUN_013eb71a();
    FUN_013eb606(0xe,4,0xffffffff);
  }
  DAT_013f7842 = DAT_013f7842 + -1;
  uVar3 = (&DAT_013f4856)[DAT_013f43cc >> 4];
  if (uVar3 < 0x1fe) {
    uVar1 = (uint)(byte)(&DAT_013f4658)[uVar3];
  }
  else {
    FUN_013eaf5c(0xc);
    uVar2 = 0x8000;
    do {
      if ((DAT_013f43cc & uVar2) == 0) {
        uVar3 = *(ushort *)(&DAT_013f704c + (uint)uVar3 * 2);
      }
      else {
        uVar3 = *(ushort *)(&DAT_013f6856 + (uint)uVar3 * 2);
      }
      uVar2 = uVar2 >> 1;
    } while (0x1fd < uVar3);
    uVar1 = (byte)(&DAT_013f4658)[uVar3] - 0xc;
  }
  FUN_013eaf5c(uVar1);
  return;
}


// ==== FUN_013eb964 @ 013eb964

int FUN_013eb964(void)

{
  int iVar1;
  uint uVar2;
  ushort uVar3;
  ushort uVar4;
  
  uVar4 = (&DAT_013f4458)[DAT_013f43cc >> 8];
  if (uVar4 < 0xe) {
    uVar2 = (uint)(byte)(&DAT_013f43d8)[uVar4];
  }
  else {
    FUN_013eaf5c(8);
    uVar3 = 0x8000;
    do {
      if ((DAT_013f43cc & uVar3) == 0) {
        uVar4 = *(ushort *)(&DAT_013f704c + (uint)uVar4 * 2);
      }
      else {
        uVar4 = *(ushort *)(&DAT_013f6856 + (uint)uVar4 * 2);
      }
      uVar3 = uVar3 >> 1;
    } while (0xd < uVar4);
    uVar2 = (byte)(&DAT_013f43d8)[uVar4] - 8;
  }
  iVar1 = FUN_013eaf5c(uVar2);
  if (uVar4 != 0) {
    FUN_013eb03e(uVar4 - 1);
    iVar1 = 1 << (uVar4 - 1 & 0x3f);
  }
  return iVar1;
}


// ==== FUN_013eba20 @ 013eba20

void FUN_013eba20(void)

{
  FUN_013eb06c();
  DAT_013f7842 = 0;
  return;
}


// ==== FUN_013eba34 @ 013eba34

void FUN_013eba34(short param_1,int param_2,short param_3,int param_4)

{
  uint uVar1;
  int iVar2;
  uint uVar3;
  ushort uVar4;
  uint uVar5;
  int iVar6;
  int iVar7;
  uint uVar8;
  ushort *puVar9;
  uint uVar10;
  int iVar11;
  ushort uStack_6c;
  ushort auStack_6a [17];
  ushort auStack_48 [17];
  short asStack_26 [17];
  
  iVar11 = (int)param_1;
  uVar5 = 1;
  do {
    asStack_26[uVar5] = 0;
    auStack_48[uVar5] = (ushort)(1 << (0x10 - uVar5 & 0x3f));
    uVar5 = uVar5 + 1;
  } while (uVar5 < 0x11);
  uVar5 = 0;
  if (param_1 != 0) {
    do {
      asStack_26[*(byte *)(param_2 + uVar5)] = asStack_26[*(byte *)(param_2 + uVar5)] + 1;
      uVar5 = uVar5 + 1;
    } while (uVar5 < (uint)(int)param_1);
  }
  uVar4 = 0;
  uVar5 = 1;
  do {
    auStack_6a[uVar5] = uVar4;
    uVar4 = auStack_48[uVar5] * asStack_26[uVar5] + uVar4;
    uVar5 = uVar5 + 1;
  } while (uVar5 < 0x11);
  if (uVar4 != 0) {
    abort();
  }
  uVar10 = 0x10 - (int)param_3;
  uVar5 = 1;
  if (param_3 != 0) {
    do {
      auStack_6a[uVar5] = (ushort)((int)(uint)auStack_6a[uVar5] >> (uVar10 & 0x3f));
      auStack_48[uVar5] = (ushort)((int)(uint)auStack_48[uVar5] >> (uVar10 & 0x3f));
      uVar5 = uVar5 + 1;
    } while (uVar5 <= (uint)(int)param_3);
  }
  uVar5 = (int)(uint)auStack_6a[(int)param_3 + 1] >> (uVar10 & 0x3f);
  if (uVar5 != 0) {
    for (; uVar5 < (uint)(1 << ((int)param_3 & 0x3fU)); uVar5 = uVar5 + 1) {
      *(undefined2 *)(param_4 + uVar5 * 2) = 0;
    }
  }
  iVar7 = 0;
  if (0 < param_1) {
    uVar5 = (uint)param_3;
    do {
      uVar3 = (uint)*(byte *)(param_2 + iVar7);
      if (uVar3 != 0) {
        uVar8 = (uint)auStack_6a[uVar3];
        uVar1 = uVar8 + auStack_48[uVar3];
        if ((int)uVar5 < (int)uVar3) {
          puVar9 = (ushort *)(param_4 + (uint)(auStack_6a[uVar3] >> (uVar10 & 0x3f)) * 2);
          iVar6 = (uint)auStack_6a[uVar3] << (uVar5 & 0x3f);
          iVar2 = uVar3 - uVar5;
          while (iVar2 = iVar2 + -1, -1 < iVar2) {
            if (*puVar9 == 0) {
              *(undefined2 *)(&DAT_013f704c + iVar11 * 2) = 0;
              *(undefined2 *)(&DAT_013f6856 + iVar11 * 2) = 0;
              *puVar9 = (ushort)iVar11;
              iVar11 = iVar11 + 1;
            }
            if ((short)iVar6 < 0) {
              puVar9 = (ushort *)(&DAT_013f6856 + (uint)*puVar9 * 2);
            }
            else {
              puVar9 = (ushort *)(&DAT_013f704c + (uint)*puVar9 * 2);
            }
            iVar6 = iVar6 << 1;
          }
          *puVar9 = (ushort)iVar7;
        }
        else {
          for (; uVar8 < uVar1; uVar8 = uVar8 + 1) {
            *(ushort *)(param_4 + uVar8 * 2) = (ushort)iVar7;
          }
        }
        uStack_6c = (ushort)uVar1;
        auStack_6a[uVar3] = uStack_6c;
      }
      iVar7 = iVar7 + 1;
    } while (iVar7 < param_1);
  }
  return;
}


// ==== FUN_013ebbd6 @ 013ebbd6

void FUN_013ebbd6(char *param_1,char param_2)

{
  char cVar1;
  
  for (; cVar1 = *param_1, cVar1 != '\0'; param_1 = param_1 + 1) {
    if (((cVar1 == '\\') || (cVar1 == '/')) || (cVar1 == -1)) {
      *param_1 = param_2;
    }
  }
  return;
}


// ==== FUN_013ebc0a @ 013ebc0a

void FUN_013ebc0a(void)

{
  uint uVar1;
  ushort unaff_D7w;
  
  if (DAT_013f7844 < 1) {
    DAT_013f7848 = 0;
    DAT_013f7844 = 0;
    for (; 0 < DAT_013f784c; DAT_013f784c = DAT_013f784c + -1) {
      (&DAT_013f7850)[DAT_013f7844] = (&DAT_013f7850)[DAT_013f9850 & 0x1fff];
      DAT_013f7844 = DAT_013f7844 + 1;
      DAT_013f9850 = DAT_013f9850 + 1;
    }
    if (DAT_013f7844 < 0x2000) {
      while (DAT_013f9854 < DAT_013f9862) {
        FUN_013eb87a();
        if (unaff_D7w < 0x100) {
          (&DAT_013f7850)[DAT_013f7844] = (char)unaff_D7w;
          DAT_013f7844 = DAT_013f7844 + 1;
          DAT_013f9854 = DAT_013f9854 + 1;
        }
        else {
          DAT_013f784c = unaff_D7w - 0xfd;
          FUN_013eb964();
          DAT_013f9850 = (DAT_013f7844 - (uint)unaff_D7w) - 1 & 0x1fff;
          DAT_013f9854 = DAT_013f784c + DAT_013f9854;
          while (0 < DAT_013f784c) {
            uVar1 = DAT_013f9850 & 0x1fff;
            DAT_013f9850 = DAT_013f9850 + 1;
            DAT_013f784c = DAT_013f784c + -1;
            (&DAT_013f7850)[DAT_013f7844] = (&DAT_013f7850)[uVar1];
            DAT_013f7844 = DAT_013f7844 + 1;
            if (0x1fff < DAT_013f7844) {
              return;
            }
          }
        }
        if (0x1fff < DAT_013f7844) {
          return;
        }
      }
    }
  }
  return;
}


// ==== ewsl_read @ 013ebd5a

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void ewsl_read(int param_1,int param_2)

{
  int iVar1;
  
  _ewsl_errn = 0;
  if (DAT_013f21c0 == 0) {
    _ewsl_errn = 10;
  }
  else {
    iVar1 = 0;
    while( true ) {
      if ((param_2 < 1) || (FUN_013ebc0a(), DAT_013f7844 < 1)) goto LAB_013ebe18;
      if (param_2 <= DAT_013f7844) break;
      cpybuf(&DAT_013f7850 + DAT_013f7848,param_1 + iVar1,DAT_013f7844);
      param_2 = param_2 - DAT_013f7844;
      iVar1 = DAT_013f7844 + iVar1;
      DAT_013f7848 = DAT_013f7844 + DAT_013f7848;
      DAT_013f7844 = 0;
    }
    cpybuf(&DAT_013f7850 + DAT_013f7848,param_1 + iVar1,param_2);
    DAT_013f7848 = param_2 + DAT_013f7848;
    DAT_013f7844 = DAT_013f7844 - param_2;
    iVar1 = param_2 + iVar1;
LAB_013ebe18:
    FUN_013eaefa(param_1,iVar1);
  }
  return;
}


// ==== FUN_013ebe2e @ 013ebe2e

void FUN_013ebe2e(void)

{
  int unaff_D7;
  undefined1 local_6 [2];
  
  ewsl_read(local_6,2);
  if (unaff_D7 != 2) {
    abort();
  }
  return;
}


// ==== FUN_013ebe58 @ 013ebe58

void FUN_013ebe58(void)

{
  int unaff_D7;
  undefined1 local_8 [4];
  
  ewsl_read(local_8,4);
  if (unaff_D7 != 4) {
    abort();
  }
  return;
}


// ==== FUN_013ebe80 @ 013ebe80

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void FUN_013ebe80(short *param_1)

{
  undefined4 unaff_D7;
  
  if (0x1b < DAT_013f9862) {
    FUN_013ebe2e();
    *param_1 = (short)unaff_D7;
    if (*param_1 == -0x66d3) {
      FUN_013ebe2e();
      param_1[1] = (short)unaff_D7;
      FUN_013ebe58();
      *(undefined4 *)(param_1 + 2) = unaff_D7;
      FUN_013ebe58();
      *(undefined4 *)(param_1 + 4) = unaff_D7;
      FUN_013ebe58();
      *(undefined4 *)(param_1 + 6) = unaff_D7;
      FUN_013ebe58();
      *(undefined4 *)(param_1 + 8) = unaff_D7;
      FUN_013ebe58();
      *(undefined4 *)(param_1 + 10) = unaff_D7;
      FUN_013ebe58();
      *(undefined4 *)(param_1 + 0xc) = unaff_D7;
      return;
    }
  }
  _ewsl_errn = 9;
  return;
}


// ==== ewsl_open @ 013ebef6

/* WARNING: Removing unreachable block (ram,0x013ebfca) */
/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void ewsl_open(int param_1,undefined4 param_2)

{
  size_t unaff_D7;
  
  _ewsl_errn = 0;
  if (param_1 == 0) {
    _ewsl_errn = 1;
  }
  else if (DAT_013f21c0 == 0) {
    FUN_013eaec0();
    FUN_013eb140(param_1,&DAT_013f9858);
    if (unaff_D7 == 0) {
      return;
    }
    if ((DAT_013f9978 & 0xf000) == 0x8000) {
      strlen("-lh5-");
      bcmp(&DAT_013f9859,"-lh5-",unaff_D7);
      if (unaff_D7 == 0) {
        DAT_013f43d0 = DAT_013f985e;
        DAT_013f43c8 = 0;
        DAT_013f21c0 = param_1;
        FUN_013eba20();
        DAT_013f7848 = 0;
        DAT_013f7844 = 0;
        DAT_013f9850 = 0;
        DAT_013f784c = 0;
        DAT_013f9854 = 0;
        FUN_013ebe80(param_2);
        return;
      }
      _ewsl_errn = 7;
    }
    else {
      _ewsl_errn = 6;
    }
  }
  else {
    _ewsl_errn = 2;
  }
  return;
}


// ==== ewsl_clos @ 013ebfde

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void ewsl_clos(void)

{
  _ewsl_errn = 0;
  if (DAT_013f21c0 == 0) {
    _ewsl_errn = 10;
  }
  else {
    DAT_013f21c0 = 0;
  }
  return;
}


// ==== ewsl_chec @ 013ec008

/* WARNING: Globals starting with '_' overlap smaller symbols at the same address */

void ewsl_chec(void)

{
  if (DAT_013f21c0 == 0) {
    _ewsl_errn = 10;
  }
  else {
    if (DAT_013f996e == 0) {
      _ewsl_errn = 0;
      return;
    }
    if (DAT_013f996c == DAT_013f43c8) {
      _ewsl_errn = 0;
      return;
    }
    _ewsl_errn = 8;
  }
  return;
}


// ==== cpybuf @ 013ec048

void cpybuf(char *param_1,char *param_2,int param_3)

{
  char cVar1;
  ushort uVar2;
  short sVar3;
  char *pcVar4;
  char *pcVar5;
  
  if (param_3 == 0) {
    cVar1 = *param_1;
    while (cVar1 != '\0') {
      *param_2 = *param_1;
      cVar1 = param_1[1];
      param_1 = param_1 + 1;
      param_2 = param_2 + 1;
    }
  }
  else {
    param_3 = param_3 + -1;
    if (param_3 != -1) {
      do {
        do {
          pcVar4 = param_1 + 1;
          pcVar5 = param_2 + 1;
          *param_2 = *param_1;
          uVar2 = (ushort)((uint)param_3 >> 0x10);
          sVar3 = (short)param_3 + -1;
          param_3 = CONCAT22(uVar2,sVar3);
          param_1 = pcVar4;
          param_2 = pcVar5;
        } while (sVar3 != -1);
        param_3 = (uint)uVar2 * 0x10000 + -1;
      } while (uVar2 != 0);
    }
  }
  return;
}


// ==== fill @ 013ec084

void fill(undefined1 *param_1,int param_2,undefined1 param_3)

{
  ushort uVar1;
  short sVar2;
  undefined1 *puVar3;
  
  param_2 = param_2 + -1;
  if (param_2 != -1) {
    do {
      do {
        puVar3 = param_1 + 1;
        *param_1 = param_3;
        uVar1 = (ushort)((uint)param_2 >> 0x10);
        sVar2 = (short)param_2 + -1;
        param_2 = CONCAT22(uVar1,sVar2);
        param_1 = puVar3;
      } while (sVar2 != -1);
      param_2 = (uint)uVar1 * 0x10000 + -1;
    } while (uVar1 != 0);
  }
  return;
}


// ==== cmpbuf @ 013ec0ac

void cmpbuf(char *param_1,char *param_2,int param_3)

{
  while( true ) {
    if (param_3 == 0) {
      return;
    }
    if (*param_2 != *param_1) break;
    param_3 = param_3 + -1;
    param_1 = param_1 + 1;
    param_2 = param_2 + 1;
  }
  return;
}


// ==== strcat @ 013ec0d4

char * strcat(char *__dest,char *__src)

{
  char cVar1;
  char *in_D0;
  
  for (; in_D0 = (char *)((uint)in_D0 & 0xffffff00), *__dest != '\0'; __dest = __dest + 1) {
  }
  do {
    cVar1 = *__src;
    in_D0 = (char *)CONCAT31((int3)((uint)in_D0 >> 8),cVar1);
    *__dest = cVar1;
    __dest = __dest + 1;
    __src = __src + 1;
  } while (cVar1 != '\0');
  return in_D0;
}


// ==== strcpy @ 013ec0f8

char * strcpy(char *__dest,char *__src)

{
  char cVar1;
  char *in_D0;
  
  do {
    cVar1 = *__src;
    in_D0 = (char *)CONCAT31((int3)((uint)in_D0 >> 8),cVar1);
    *__dest = cVar1;
    __dest = __dest + 1;
    __src = __src + 1;
  } while (cVar1 != '\0');
  return in_D0;
}


// ==== strcmp @ 013ec114

int strcmp(char *__s1,char *__s2)

{
  int in_D0;
  
  while( true ) {
    if (*__s2 != *__s1) {
      return (uint)(byte)*__s2;
    }
    in_D0 = CONCAT31((int3)((uint)in_D0 >> 8),*__s1);
    if (*__s1 == 0) break;
    __s1 = __s1 + 1;
    __s2 = __s2 + 1;
  }
  return in_D0;
}


// ==== strlen @ 013ec148

size_t strlen(char *__s)

{
  char cVar1;
  size_t in_D0;
  
  do {
    cVar1 = *__s;
    in_D0 = CONCAT31((int3)(in_D0 >> 8),cVar1);
    __s = __s + 1;
  } while (cVar1 != '\0');
  return in_D0;
}


